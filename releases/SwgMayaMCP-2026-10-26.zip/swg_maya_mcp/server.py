"""SwgMayaMCP — MCP server for Autodesk Maya 2027 + the SwgMayaEditor (MayaModern) plug-in.

Run:  .venv\\Scripts\\python.exe -m swg_maya_mcp
"""

from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path
from typing import Any, Literal

from mcp.server.mcpserver import Image, MCPServer
from mcp.server.mcpserver.exceptions import ToolError

from . import client, godclient, iff, rails
from .terrain import tools as terrain_tools
from .connection import HEADLESS_LOG, BridgeError, MayaConnection

DEFAULT_EXPORT_ROOT = os.environ.get("TITAN_EXPORT_ROOT", "D:/exported")

mcp = MCPServer(
    name="swg-maya",
    version="1.0.0",
    instructions=(
        "Drives Autodesk Maya 2027 with the SwgMayaEditor plug-in for Star Wars Galaxies (Titan) assets. "
        "Works against an interactive Maya running the bridge, or a private headless mayapy started on demand. "
        "Prefer the pob_* tools for buildings: pob_build creates a complete walkable building (rooms, doors, "
        "floors, portals, lights) and pob_export_structure writes .pob + .msh/.apt + .flr. "
        "Use pob_inspect / swg_inspect_floor to verify files without Maya. maya_python is the escape hatch "
        "(assign to `result` to return a value; `args` holds the arguments you pass). "
        "RAILS - follow these; swg_rails explains each (why + enforcing tool) and swg_check verifies exported "
        ".pob/.ans/.flr files against them (exports run it automatically): " + rails.summary()
    ),
)
maya = MayaConnection()


def _py(code: str, timeout: float = 600.0, **args: Any) -> Any:
    try:
        return maya.python(code, args, timeout)
    except BridgeError as exc:
        raise ToolError(str(exc)) from None


# ============================================================================
# General Maya
# ============================================================================

@mcp.tool()
def maya_status() -> dict:
    """Connect (if needed) and report Maya version, scene, SwgMayaEditor plug-in state and data/export roots."""
    info = _py(r"""
import os
loaded = cmds.pluginInfo('SwgMayaEditor', q=True, loaded=True)
result = {
    'maya_version': cmds.about(version=True),
    'batch': cmds.about(batch=True),
    'scene': cmds.file(q=True, sceneName=True) or '(untitled)',
    'modified': cmds.file(q=True, modified=True),
    'plugin_loaded': loaded,
    'plugin_version': cmds.pluginInfo('SwgMayaEditor', q=True, version=True) if loaded else None,
    'plugin_path': cmds.pluginInfo('SwgMayaEditor', q=True, path=True) if loaded else None,
    'TITAN_DATA_ROOT': os.environ.get('TITAN_DATA_ROOT'),
    'TITAN_EXPORT_ROOT': os.environ.get('TITAN_EXPORT_ROOT'),
    'top_level_nodes': [n for n in cmds.ls(assemblies=True) if n not in ('persp', 'top', 'front', 'side')][:50],
}
""")
    info["connection"] = {"kind": maya.kind, "port": maya.port, "mode": maya.mode,
                          "headless_log": str(HEADLESS_LOG) if maya.kind == "headless" else None}
    return info


@mcp.tool()
def maya_connect(mode: Literal["auto", "gui", "headless"] = "auto") -> dict:
    """Switch Maya connection: 'gui' = interactive Maya running the bridge (port 7020), 'headless' = private
    mayapy, 'auto' = gui if available else headless."""
    try:
        maya.reconnect(mode)
    except BridgeError as exc:
        raise ToolError(str(exc)) from None
    return {"kind": maya.kind, "port": maya.port, "mode": maya.mode}


@mcp.tool()
def maya_python(code: str, timeout_seconds: float = 600.0) -> dict:
    """Execute Python inside Maya. `cmds`, `mel`, `om` (maya.api.OpenMaya) are pre-imported; the namespace
    persists between calls. Assign to `result` to return a JSON-able value. Returns result, stdout, stderr."""
    resp = maya.run("python", code, None, timeout_seconds)
    return {k: resp.get(k) for k in ("ok", "result", "stdout", "stderr", "error", "traceback") if resp.get(k) not in (None, "")}


@mcp.tool()
def maya_mel(code: str, timeout_seconds: float = 600.0) -> dict:
    """Execute MEL inside Maya (e.g. SwgMayaEditor commands like `validatePob -root "|bldg"`). Returns the
    command's return value plus captured output."""
    resp = maya.run("mel", code, None, timeout_seconds)
    return {k: resp.get(k) for k in ("ok", "result", "stdout", "stderr", "error", "traceback") if resp.get(k) not in (None, "")}


@mcp.tool()
def maya_scene(action: Literal["new", "open", "save", "save_as", "info"], path: str = "") -> dict:
    """Scene file operations. new discards unsaved changes; save_as needs a path (.ma or .mb)."""
    return _py(r"""
a, p = args['action'], args['path']
if a == 'new':
    cmds.file(new=True, force=True)
elif a == 'open':
    cmds.file(p, open=True, force=True)
elif a == 'save':
    cmds.file(save=True, force=True)
elif a == 'save_as':
    cmds.file(rename=p)
    cmds.file(save=True, force=True, type='mayaBinary' if p.lower().endswith('.mb') else 'mayaAscii')
result = {'scene': cmds.file(q=True, sceneName=True) or '(untitled)', 'modified': cmds.file(q=True, modified=True),
          'nodes': len(cmds.ls()), 'meshes': len(cmds.ls(type='mesh'))}
""", action=action, path=path)


@mcp.tool()
def maya_ls(pattern: str = "*", node_type: str = "", under: str = "", limit: int = 200) -> dict:
    """List nodes (long DAG paths). Filter by name pattern, Maya node type (mesh, transform, joint, ...) or
    restrict to descendants of `under`."""
    return _py(r"""
kw = {'long': True}
if args['node_type']:
    kw['type'] = args['node_type']
if args['under']:
    nodes = cmds.ls(cmds.listRelatives(args['under'], allDescendents=True, fullPath=True) or [], **kw)
    nodes = [n for n in nodes if __import__('fnmatch').fnmatch(n.split('|')[-1], args['pattern'])]
else:
    nodes = cmds.ls(args['pattern'], **kw)
result = {'count': len(nodes), 'nodes': nodes[:args['limit']]}
""", pattern=pattern, node_type=node_type, under=under, limit=limit)


@mcp.tool()
def maya_node(node: str) -> dict:
    """Describe a node: type, parent/children, local+world transform, user-defined attributes (where the SWG
    plug-in keeps its data: external_reference, buildingPortalIndex, swgShaderPath, ...), mesh stats, bbox."""
    return _py(r"""
n = args['node']
if not cmds.objExists(n):
    raise ValueError('no such node: ' + n)
info = {'node': (cmds.ls(n, long=True) or [n])[0], 'type': cmds.nodeType(n)}
if cmds.objectType(n, isAType='dagNode'):
    info['parent'] = (cmds.listRelatives(n, parent=True, fullPath=True) or [None])[0]
    info['children'] = cmds.listRelatives(n, children=True, fullPath=True) or []
if cmds.objectType(n, isAType='transform'):
    info['translate'] = cmds.getAttr(n + '.translate')[0]
    info['rotate'] = cmds.getAttr(n + '.rotate')[0]
    info['scale'] = cmds.getAttr(n + '.scale')[0]
    info['world_bbox'] = cmds.exactWorldBoundingBox(n)
attrs = {}
for a in cmds.listAttr(n, userDefined=True) or []:
    try:
        v = cmds.getAttr(n + '.' + a)
        attrs[a] = v if not isinstance(v, list) else v[:16]
    except Exception as e:
        attrs[a] = '<' + type(e).__name__ + '>'
info['user_attributes'] = attrs
shapes = cmds.listRelatives(n, shapes=True, fullPath=True, type='mesh') or ([n] if cmds.nodeType(n) == 'mesh' else [])
if shapes:
    s = shapes[0]
    info['mesh'] = {'shape': s, 'vertices': cmds.polyEvaluate(s, vertex=True), 'faces': cmds.polyEvaluate(s, face=True),
                    'triangles': cmds.polyEvaluate(s, triangle=True),
                    'shading_groups': sorted(set(cmds.listConnections(s, type='shadingEngine') or []))}
result = info
""", node=node)


@mcp.tool()
def maya_set_attr(node: str, attribute: str, value: Any, create_if_missing: bool = False) -> dict:
    """Set an attribute. Strings, numbers, bools and 2/3-element lists (double2/double3) are supported.
    With create_if_missing, a dynamic attribute of the matching type is added first."""
    return _py(r"""
n, a, v = args['node'], args['attribute'], args['value']
plug = n + '.' + a
if not cmds.attributeQuery(a, node=n, exists=True):
    if not args['create_if_missing']:
        raise ValueError(plug + ' does not exist (pass create_if_missing=True)')
    if isinstance(v, str):
        cmds.addAttr(n, longName=a, dataType='string')
    elif isinstance(v, bool):
        cmds.addAttr(n, longName=a, attributeType='bool')
    elif isinstance(v, int):
        cmds.addAttr(n, longName=a, attributeType='long')
    elif isinstance(v, float):
        cmds.addAttr(n, longName=a, attributeType='double')
    else:
        cmds.addAttr(n, longName=a, attributeType='double3')
        for c in 'XYZ':
            cmds.addAttr(n, longName=a + c, attributeType='double', parent=a)
if isinstance(v, str):
    cmds.setAttr(plug, v, type='string')
elif isinstance(v, (list, tuple)):
    cmds.setAttr(plug, *v, type='double%d' % len(v))
else:
    cmds.setAttr(plug, v)
result = {'attribute': plug, 'value': cmds.getAttr(plug)}
""", node=node, attribute=attribute, value=value, create_if_missing=create_if_missing)


@mcp.tool()
def maya_viewport_capture(width: int = 960, height: int = 540, frame_selection: bool = False,
                          camera: str = "") -> Image:
    """Screenshot of the active viewport (interactive Maya only). Optionally frame the selection first or
    look through a specific camera."""
    path = Path(tempfile.gettempdir()) / "swg_maya_mcp_capture.png"
    _py(r"""
if cmds.about(batch=True):
    raise RuntimeError('viewport capture needs interactive Maya (connect with maya_connect mode=gui)')
panel = cmds.getPanel(withFocus=True)
if cmds.getPanel(typeOf=panel) != 'modelPanel':
    panel = (cmds.getPanel(type='modelPanel') or [None])[0]
if args['camera']:
    cmds.modelPanel(panel, edit=True, camera=args['camera'])
if args['frame_selection']:
    cmds.viewFit(cmds.modelPanel(panel, q=True, camera=True))
cmds.setFocus(panel)
cmds.playblast(frame=[cmds.currentTime(q=True)], format='image', compression='png', viewer=False,
               showOrnaments=False, percent=100, widthHeight=(args['width'], args['height']),
               completeFilename=args['path'], forceOverwrite=True, offScreen=True)
result = args['path']
""", path=str(path), width=width, height=height, frame_selection=frame_selection, camera=camera)
    return Image(data=path.read_bytes(), format="png")


@mcp.tool()
def maya_render(target: str = "", view: Literal["perspective", "cutaway", "eye"] = "perspective", azimuth: float = 35.0,
                elevation: float = 30.0, cut_height: float = 2.5, width: int = 960, height: int = 640,
                eye: list[float] | None = None, look_at: list[float] | None = None, fov: float = 75.0) -> Image:
    """Render an image with Maya Software (works headless). `perspective` frames `target` (default: whole scene)
    from azimuth/elevation degrees; `cutaway` is a top-down orthographic view whose near clip slices everything
    above `cut_height` metres off (roofs/ceilings), like an architectural plan; `eye` places the camera at `eye`
    looking at `look_at` (e.g. inside a room) with a `fov` degree horizontal field of view."""
    path = _py(r"""
import math, os, tempfile
nodes = [args['target']] if args['target'] else [n for n in cmds.ls(assemblies=True, long=True)
                                                  if not cmds.listRelatives(n, shapes=True, type='camera')]
if not nodes:
    raise ValueError('nothing to render')
bb = cmds.exactWorldBoundingBox(*nodes)
c = [(bb[0] + bb[3]) / 2, (bb[1] + bb[4]) / 2, (bb[2] + bb[5]) / 2]
size = max(bb[3] - bb[0], bb[4] - bb[1], bb[5] - bb[2], 1.0)
cam, cam_shape = cmds.camera(name='swg_mcp_render_cam')
cmds.setAttr(cam_shape + '.renderable', 1)  # opened scenes only render cameras flagged renderable
rg = 'defaultRenderGlobals'
saved = {a: cmds.getAttr(rg + '.' + a) for a in ('imageFormat', 'enableDefaultLight', 'imageFilePrefix')}
# Maya Software writes under <workspace images rule>/<camera>/<prefix>; point the images rule at a temp
# folder (an absolute prefix gets glued onto the project path) and pick the newest PNG afterwards.
out_dir = os.path.join(tempfile.gettempdir(), 'swg_mcp_render').replace('\\', '/')
import shutil
shutil.rmtree(out_dir, ignore_errors=True)
os.makedirs(out_dir, exist_ok=True)
saved_images_rule = cmds.workspace(fileRuleEntry='images')
cmds.workspace(fileRule=['images', out_dir])
cmds.setAttr(rg + '.imageFilePrefix', 'frame', type='string')
try:
    if args['view'] == 'eye':
        cmds.xform(cam, translation=args['eye'], worldSpace=True)
        cmds.viewLookAt(cam, pos=args['look_at'])
        cmds.setAttr(cam_shape + '.horizontalFilmAperture', 1.417)
        cmds.setAttr(cam_shape + '.focalLength', 1.417 * 25.4 / 2 / __import__('math').tan(__import__('math').radians(args['fov']) / 2))
        cmds.setAttr(cam_shape + '.nearClipPlane', 0.05)
        cmds.setAttr(cam_shape + '.farClipPlane', 500)
    elif args['view'] == 'cutaway':
        top = bb[4] + 10.0
        cmds.setAttr(cam_shape + '.orthographic', 1)
        cmds.setAttr(cam_shape + '.orthographicWidth', max(bb[3] - bb[0], (bb[5] - bb[2]) * args['width'] / args['height']) * 1.08)
        cmds.xform(cam, translation=(c[0], top, c[2]), rotation=(-90, 0, 0), worldSpace=True)
        cmds.setAttr(cam_shape + '.nearClipPlane', max(0.01, top - args['cut_height']))
        cmds.setAttr(cam_shape + '.farClipPlane', top - bb[1] + 1.0)
    else:
        az, el = math.radians(args['azimuth']), math.radians(args['elevation'])
        dist = size * 1.6
        pos = (c[0] + dist * math.cos(el) * math.sin(az), c[1] + dist * math.sin(el), c[2] + dist * math.cos(el) * math.cos(az))
        cmds.xform(cam, translation=pos, worldSpace=True)
        cmds.viewLookAt(cam, pos=c)
        cmds.setAttr(cam_shape + '.farClipPlane', dist * 10)
    cmds.setAttr(rg + '.imageFormat', 32)            # png
    # Maya applies every cell's lights everywhere (the client confines them to their cell), which blows a
    # many-room building out to white. Exteriors: default light only. Interiors: only the lights of the cell
    # the eye stands in (smallest rN box holding it; all lights when there is no POB), with ambients dimmed.
    interior = args['view'] == 'eye'
    dimmed = {}
    lights = cmds.ls(lights=True, long=True) or []
    keep = set()
    if interior:
        import re as _re
        e = args['eye']
        best, cells = None, 0
        for xf in cmds.ls(type='transform', long=True):
            if not _re.fullmatch(r'r[1-9][0-9]*', xf.rsplit('|', 1)[-1]):
                continue
            cells += 1
            b = cmds.exactWorldBoundingBox(xf)
            if b[0] <= e[0] <= b[3] and b[1] <= e[1] <= b[4] and b[2] <= e[2] <= b[5]:
                vol = (b[3] - b[0]) * (b[4] - b[1]) * (b[5] - b[2])
                if best is None or vol < best[0]:
                    best = (vol, xf)
        if best is None and cells:
            interior = False        # an eye outside every cell of a building: daylight, like the exterior views
        keep = {l for l in lights if best is None or l.startswith(best[1] + '|')} if interior else set()
    cmds.setAttr(rg + '.enableDefaultLight', 0 if interior else 1)
    for l in lights:
        dimmed[l] = cmds.getAttr(l + '.intensity')
        if l not in keep:
            cmds.setAttr(l + '.intensity', 0)
        elif cmds.nodeType(l) == 'ambientLight':
            cmds.setAttr(l + '.intensity', dimmed[l] * (0.5 if len(keep) < len(lights) else 0.15))
        elif cmds.nodeType(l) == 'pointLight':
            # Maya point lights default to no falloff; give them the client's quadratic-ish decay
            dimmed[l + '.decayRate'] = cmds.getAttr(l + '.decayRate')
            cmds.setAttr(l + '.decayRate', 2)
            cmds.setAttr(l + '.intensity', dimmed[l] * 18.0)
    temp_lights = []
    if not interior and lights:
        # the default light is skipped once a scene has lights of its own: add a temporary sun + fill
        sun = cmds.directionalLight(intensity=1.1, rotation=(-50, args['azimuth'] + 35, 0))
        fill = cmds.ambientLight(intensity=0.3)
        temp_lights = [cmds.listRelatives(sun, parent=True)[0], cmds.listRelatives(fill, parent=True)[0]]
    cmds.setAttr(rg + '.currentRenderer', 'mayaSoftware', type='string')
    reported = cmds.render(cam, x=args['width'], y=args['height'])
finally:
    for node, v in locals().get('dimmed', {}).items():
        cmds.setAttr(node if '.' in node else node + '.intensity', v)
    for a, v in saved.items():
        if a == 'imageFilePrefix':
            cmds.setAttr(rg + '.' + a, v or '', type='string')
        else:
            cmds.setAttr(rg + '.' + a, v)
    cmds.workspace(fileRule=['images', saved_images_rule or 'images'])
    cmds.delete(cam, *locals().get('temp_lights', []))
written = [os.path.join(r, f) for r, _, fs in os.walk(out_dir) for f in fs if f.lower().endswith('.png')]
if not written and reported and os.path.exists(reported):
    written = [reported]
if not written:
    raise RuntimeError('render produced no image (reported %s)' % reported)
result = max(written, key=os.path.getmtime)
""", target=target, view=view, azimuth=azimuth, elevation=elevation, cut_height=cut_height, width=width, height=height,
               eye=list(eye or [0, 1.7, 0]), look_at=list(look_at or [0, 1.7, -1]), fov=fov)
    return Image(data=Path(path).read_bytes(), format="png")


# ============================================================================
# SWG asset I/O (SwgMayaEditor)
# ============================================================================

_TRANSLATOR_BY_EXT = {
    ".msh": "SwgMsh", ".apt": "SwgMsh", ".mgn": "SwgMgn", ".skt": "SwgSkt", ".ans": "SwgAns", ".flr": "SwgFlr",
    ".sat": "SwgSat", ".pob": "SwgPob", ".dds": "SwgDds", ".lod": "SwgLod", ".lmg": "SwgLmg", ".lsb": "SwgLsb",
}


@mcp.tool()
def swg_setup(export_root: str = "", plugin_path: str = "") -> dict:
    """Load SwgMayaEditor (optionally from an explicit .mll path) and set the export root (setBaseDir), which
    receives appearance/, shader/, texture/ output. Returns plug-in version and data/export roots."""
    return _py(r"""
import os
p = args['plugin_path']
if p:
    if cmds.pluginInfo('SwgMayaEditor', q=True, loaded=True) and \
            os.path.normcase(cmds.pluginInfo('SwgMayaEditor', q=True, path=True)) != os.path.normcase(p):
        cmds.unloadPlugin('SwgMayaEditor', force=True)
    if not cmds.pluginInfo('SwgMayaEditor', q=True, loaded=True):
        cmds.loadPlugin(p)
elif not cmds.pluginInfo('SwgMayaEditor', q=True, loaded=True):
    cmds.loadPlugin('SwgMayaEditor')
if args['export_root']:
    os.makedirs(args['export_root'], exist_ok=True)
    mel.eval('setBaseDir "%s"' % args['export_root'].replace('\\', '/'))
result = {'plugin_version': cmds.pluginInfo('SwgMayaEditor', q=True, version=True),
          'plugin_path': cmds.pluginInfo('SwgMayaEditor', q=True, path=True),
          'data_root': mel.eval('getDataRootDir'),
          'export_root': args['export_root'] or None}
""", export_root=export_root, plugin_path=plugin_path)


@mcp.tool()
def swg_import(path: str) -> dict:
    """Import an SWG asset via the SwgMayaEditor translator for its extension (.msh .apt .mgn .skt .ans .flr
    .sat .pob .dds .lod .lmg .lsb). Tree paths (appearance/...) resolve against TITAN_DATA_ROOT."""
    ext = Path(path).suffix.lower()
    if ext not in _TRANSLATOR_BY_EXT:
        raise ToolError(f"unsupported extension {ext!r}; expected one of {sorted(_TRANSLATOR_BY_EXT)}")
    return _py(r"""
import os
if not cmds.pluginInfo('SwgMayaEditor', q=True, loaded=True):
    cmds.loadPlugin('SwgMayaEditor')
p = args['path'].replace('\\', '/')
if not os.path.isabs(p):
    root = mel.eval('getDataRootDir') or os.environ.get('TITAN_DATA_ROOT', '')
    p = os.path.join(root, p).replace('\\', '/')
if not os.path.exists(p):
    raise FileNotFoundError(p)
before = set(cmds.ls(assemblies=True, long=True))
cmds.file(p, i=True, type=args['translator'], ignoreVersion=True, mergeNamespacesOnClash=False)
new = [n for n in cmds.ls(assemblies=True, long=True) if n not in before]
result = {'file': p, 'translator': args['translator'], 'new_top_level_nodes': new}
""", path=path, translator=_TRANSLATOR_BY_EXT[ext])


@mcp.tool()
def swg_export_static_mesh(root: str, apt_path: str) -> dict:
    """Export a transform hierarchy as an SWG static mesh: <dir>/<name>.apt + appearance/mesh/<name>.msh plus
    cloned shaders and DDS textures (exportStaticMesh). apt_path should live under <export root>/appearance/."""
    return _py(r"""
cmds.select(args['root'], replace=True)
mel.eval('exportStaticMesh -path "%s"' % args['apt_path'].replace('\\', '/'))
result = {'apt': args['apt_path']}
""", root=root, apt_path=apt_path)


@mcp.tool()
def swg_export_floor(node: str, flr_path: str) -> dict:
    """Export mesh(es) under `node` as a compiled SWG floor (.flr v0006): merged verts, linked neighbours,
    crossable/uncrossable edges, part tags and — inside a POB cell — portal ids on door edges."""
    resp = maya.run("python", r"""
import os
os.makedirs(os.path.dirname(args['flr_path']), exist_ok=True)
cmds.select(args['node'], replace=True)
cmds.file(args['flr_path'], force=True, exportSelected=True, type='SwgFlr')
result = args['flr_path']
""", {"node": node, "flr_path": flr_path})
    if not resp.get("ok"):
        raise ToolError(resp.get("error"))
    report = iff.floor_report(iff.read_flr(flr_path))
    return {"flr": flr_path, "plugin_log": (resp.get("stderr") or "").strip()[-2000:], "report": report}


@mcp.tool()
def swg_inspect_floor(path: str) -> dict:
    """Read a .flr from disk (no Maya needed) and check it the way the engine's FloorMesh would: neighbour
    reciprocity, crossable edges, part count, portal edges and triangle orientation."""
    flr = iff.read_flr(path)
    if flr["version"] != 6:
        return {"path": path, "version": flr["version"], "vertices": len(flr["vertices"]),
                "note": "only v0006 floors are analysed in detail"}
    return {"path": path, "version": 6, **iff.floor_report(flr)}


# ============================================================================
# POB (buildings)
# ============================================================================

@mcp.tool()
def pob_inspect(path: str, data_root: str = "") -> dict:
    """Read a .pob from disk (no Maya needed): cells (name, appearance, floor, canSeeWorld, lights), portals
    (index, clockwise, target, door style), portal geometry bounds, plus pairing/geometry issues. With
    data_root, also checks that referenced appearance/floor files exist."""
    summary = iff.summarize_pob(iff.read_pob(path), floor_root=data_root or None)
    if data_root:
        missing = []
        for c in summary["cells"]:
            for key in ("appearance", "floor"):
                ref = c[key]
                if ref and not (Path(data_root) / ref).exists():
                    missing.append(f"r{c['index']} {key}: {ref}")
        summary["missing_files"] = missing
    return summary


@mcp.tool()
def swg_building_template(name: str, export_root: str = "", base_template: str = "",
                          feather: float = 8.0, flatten: bool = True) -> dict:
    """Make an exported building spawnable: writes object/building/titan/shared_<name>.iff (a shared building
    template derived from a stock player house, portalLayoutFilename -> appearance/<name>.pob) and, with
    flatten, terrain/<name>.lay - a terrain layer that flattens the ground under the r0 floor (pad + ramps)
    to the building origin and feathers `feather` m into the surrounding terrain. The building's ground level
    must be y = 0 (spec ground_y 0). In an offline debug client:
    /scene objectCreate object/building/titan/shared_<name>.iff <x> <z> <heading>."""
    root = Path(export_root or DEFAULT_EXPORT_ROOT)
    data = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
    shared = data.parent.parent.parent / "sys.shared" / "compiled" / "game"
    base = Path(base_template) if base_template else shared / "object/building/player/shared_player_house_naboo_large_style_01.iff"
    pob_rel = f"appearance/{name}.pob"
    if not (root / pob_rel).exists():
        raise ToolError(f"{root / pob_rel} not found - export the building first")
    params: dict[str, str | None] = {"clientDataFile": None}
    result: dict[str, Any] = {}
    if flatten:
        pob = iff.read_pob(root / pob_rel)
        r0_floor = pob["cells"][0].get("floor")
        if not r0_floor:
            raise ToolError("r0 has no floor: nothing to flatten under")
        rect = iff.floor_bounds(root / r0_floor, pad=1.0)
        sfp_rel = f"footprint/building/titan/shared_{name}.sfp"
        result["footprint"] = iff.write_footprint(root / sfp_rel, rect)
        params["structureFootprintFileName"] = sfp_rel
        lay_rel = f"terrain/{name}.lay"
        result["layer"] = iff.flatten_layer(data / iff.STOCK_FLATTEN_LAYER, root / lay_rel, rect, feather)
        params["terrainModificationFileName"] = lay_rel
    try:
        result["template"] = iff.building_template(base, root / f"object/building/titan/shared_{name}.iff", pob_rel, params)
    except ValueError as exc:
        raise ToolError(str(exc)) from None
    result["spawn"] = f"/scene objectCreate object/building/titan/shared_{name}.iff <x> <z> <heading>"
    return result


@mcp.tool()
def pob_floorplan(path: str, data_root: str = "", out_svg: str = "") -> dict:
    """Render a top-down SVG plan of a .pob (no Maya needed): each cell's .flr floor, every portal (door) and
    point light. data_root resolves the cells' floor paths (defaults to the export root). Returns the SVG path."""
    root = data_root or DEFAULT_EXPORT_ROOT
    svg, stats = iff.floorplan_svg(iff.read_pob(path), root)
    out = Path(out_svg) if out_svg else Path(path).with_suffix(".plan.svg")
    out.write_text(svg, encoding="utf-8")
    return {"svg": str(out), **stats}


@mcp.tool()
def pob_create_template(name: str, cells: int = 2) -> dict:
    """Create an empty POB hierarchy (root|r0..rN with mesh / portals / collision|floor0) via createPobTemplate.
    r0 is the exterior cell."""
    return _py(r"""
if not cmds.pluginInfo('SwgMayaEditor', q=True, loaded=True):
    cmds.loadPlugin('SwgMayaEditor')
mel.eval('createPobTemplate -n "%s" -cells %d -layoutSpacing 0' % (args['name'], args['cells']))
result = {'root': cmds.ls('|' + args['name'], long=True)[0],
          'cells': cmds.listRelatives('|' + args['name'], children=True) or []}
""", name=name, cells=cells)


@mcp.tool()
def pob_connect_cells(root: str, from_cell: str, to_cell: str, position: list[float],
                      rotate_y: float = 0.0, width: float = 2.0, height: float = 3.0, door_style: str = "") -> dict:
    """Add a portal (doorway) between two cells. `position` is the door's bottom-centre in building space;
    the door's front is its local -Z (connectPobCells mirrors X), and the front must face INTO `to_cell` (the
    clockwise side): rotate_y=0 faces -Z, 180 faces +Z, 90 faces -X, -90 faces +X. Both cell-side portal nodes get the same placement."""
    return _py(r"""
cmd = 'connectPobCells -root "%s" -from %s -to %s -w %f -h %f' % (args['root'], args['from_cell'], args['to_cell'],
                                                                   args['width'], args['height'])
if args['door_style']:
    cmd += ' -doorStyle "%s"' % args['door_style']
mel.eval(cmd)
pair = cmds.ls(selection=True, long=True)
for xf in pair:
    cmds.setAttr(xf + '.translate', *args['position'], type='double3')
    cmds.setAttr(xf + '.rotate', 0.0, args['rotate_y'], 0.0, type='double3')
result = {'portal_index': cmds.getAttr(pair[0] + '.buildingPortalIndex'), 'nodes': pair}
""", root=root, from_cell=from_cell, to_cell=to_cell, position=list(position), rotate_y=rotate_y,
               width=width, height=height, door_style=door_style)


@mcp.tool()
def pob_set_cell(root: str, cell: str, appearance: str | None = None, floor: str | None = None,
                 name: str | None = None, can_see_world: bool | None = None) -> dict:
    """Set a cell's appearance tree path (rN|mesh.external_reference), floor path (floor0.external_reference),
    display name (pobCellName) and/or canSeeWorld override."""
    return _py(r"""
c = args['root'] + '|' + args['cell']
def put(node, attr, value, kind):
    if not cmds.attributeQuery(attr, node=node, exists=True):
        if kind == 'string':
            cmds.addAttr(node, longName=attr, dataType='string')
        else:
            cmds.addAttr(node, longName=attr, attributeType='bool')
    if kind == 'string':
        cmds.setAttr(node + '.' + attr, value, type='string')
    else:
        cmds.setAttr(node + '.' + attr, value)
if args['appearance'] is not None:
    put(c + '|mesh', 'external_reference', args['appearance'], 'string')
if args['floor'] is not None:
    put(c + '|collision|floor0', 'external_reference', args['floor'], 'string')
if args['name'] is not None:
    put(c, 'pobCellName', args['name'], 'string')
if args['can_see_world'] is not None:
    put(c, 'pobCellCanSeeWorld', bool(args['can_see_world']), 'bool')
result = {'cell': c}
""", root=root, cell=cell, appearance=appearance, floor=floor, name=name, can_see_world=can_see_world)


@mcp.tool()
def pob_validate(root: str) -> dict:
    """Run validatePob + reportPobPortals on a POB root: missing groups, empty references, portal index pairing
    and halves that don't line up in building space."""
    return _py(r"""
report = mel.eval('validatePob -root "%s"' % args['root'])
lines = report.splitlines() if report else []
result = {'report': report, 'warnings': [l.strip() for l in lines if 'WARNING' in l or 'MISSING' in l or 'apart' in l]}
""", root=root)


@mcp.tool()
def pob_build(spec: dict, new_scene: bool = True) -> dict:
    """Generate a complete building in Maya from a room spec: exterior shell (r0) + one cell per room with
    interior walls/floor/ceiling, door cut-outs, walkable floor meshes with door-edge vertices, paired portals
    with correct clockwise orientation, and per-room lights.

    spec = {
      "name": "titan_outpost",
      "rooms": [{"name": "foyer", "min": [-4, 0], "max": [4, 6], "height": 4.0, "color": [r, g, b]}, ...],
      "doors": [{"rooms": ["foyer", "hall"], "width": 2.0, "height": 3.0, "offset": 0.0}],   # shared walls
      "entrances": [{"room": "foyer", "side": "+z", "width": 2.4, "height": 3.2}],          # shell doors
      "lights": true
    }
    min/max are x/z floor corners in metres (Maya Y-up). Rooms must not overlap; doors need a shared wall."""
    return _py("import importlib, swg_mcp.pob_builder as b\nimportlib.reload(b)\n"
               "result = b.build(args['spec'], new_scene=args['new_scene'])", spec=spec, new_scene=new_scene)


@mcp.tool()
def pob_export_structure(root: str, export_root: str = DEFAULT_EXPORT_ROOT, base_name: str = "") -> dict:
    """One-shot structure export (swg_pob_exportStructure): each cell's geometry → appearance/<base>_rN.apt
    (+ mesh/shader/texture), each floor0 mesh → appearance/collision/<base>_rN_collision_floor0.flr, then
    appearance/<base>.pob. Re-reads the written .pob and floors from disk to verify them."""
    resp = maya.run("python", "import importlib, swg_mcp.pob_builder as b\nimportlib.reload(b)\n"
                    "result = b.export(args['root'], args['export_root'], args['base_name'])",
                    {"root": root, "export_root": export_root, "base_name": base_name})
    if not resp.get("ok"):
        raise ToolError(resp.get("error", "") + "\n" + (resp.get("traceback") or "")[-2000:] + "\n" + (resp.get("stderr") or "")[-3000:])
    out = resp["result"]
    pob_path = out.get("pob")
    if not pob_path or not Path(pob_path).exists():
        raise ToolError("export did not produce a .pob; plug-in output:\n" + (resp.get("stderr") or resp.get("stdout") or "")[-4000:])
    try:   # overhead-map shape: the r0 appearance becomes a DTLA .lod with a RADR footprint
        out["exterior_lod"] = iff.write_exterior_lod(export_root, pob_path)
    except (ValueError, OSError) as exc:
        out["exterior_lod"] = {"error": str(exc)}
    out["pob_summary"] = pob_inspect(pob_path, data_root=export_root)  # includes the door-facing check
    floors = {}
    for c in out["cells"]:
        if c["floor"]:
            fp = Path(export_root) / c["floor"]
            if fp.exists():
                seams = iff.open_floor_seams(fp)                 # welded seams would stop the player mid-room
                if seams["seams"]:
                    out.setdefault("floor_seams_opened", {})[c["cell"]] = seams["seams"]
                rep = iff.floor_report(iff.read_flr(fp))
                floors[c["cell"]] = {k: rep[k] for k in ("tris", "parts", "portal_edges_by_portal", "downward_tris", "problems")}
    out["floor_checks"] = floors
    meshes = {}
    for c in out["cells"]:
        apt = Path(export_root) / c["appearance"] if c["appearance"] else None
        msh = apt.parent / "mesh" / (apt.stem + ".msh") if apt else None
        if msh and msh.exists():
            m = iff.read_msh_summary(msh)
            meshes[c["cell"]] = {k: m[k] for k in ("shader_slots", "shaders", "hardpoints")}
    out["mesh_checks"] = meshes
    log = (resp.get("stderr") or "").splitlines()
    out["rails"] = rails.check(pob_path, export_root)
    out["texture_errors"] = sorted({l.strip()[:300] for l in log if "Failed to publish DDS" in l or "Cannot run nvtt" in l})
    out["plugin_log"] = [l for l in (resp.get("stderr") or "").splitlines()
                         if any(k in l for k in ("Export", "Flr", "warning", "error", "ERROR", "wrote"))][-40:]
    return out


# ============================================================================
# Rails (conventions + checks) and animation export
# ============================================================================

@mcp.tool()
def swg_rails(topic: Literal["", "buildings", "animation", "wearables", "pipeline", "terrain"] = "") -> dict:
    """The conventions Titan content must follow, each with the engine behaviour behind it and the tool that
    enforces it. Read before authoring buildings or animations by hand (maya_python)."""
    return rails.rules(topic)


@mcp.tool()
def swg_check(path: str, export_root: str = DEFAULT_EXPORT_ROOT) -> dict:
    """Check an exported file against the rails without Maya. .pob: portal pairing/facing, cell lights, NULL
    collision extents on cell meshes, crossable r0 floor at y 0, exterior .lod radar shape, building template
    (.lay / .sfp). .ans: CKAT, lowercase CrcString-sorted transform names, 30 fps. .flr: floor problems.
    .sat / .mgn (skinned wearables): the .sat -> .lmg -> .mgn chain resolves, the SKMG reads back byte-identical,
    transforms are joints of its skeleton, weights / indices / occlusion zones are valid, shaders exist.
    `ok` is false when any error-level issue is found."""
    try:
        return rails.check(path, export_root)
    except (ValueError, OSError) as exc:
        raise ToolError(str(exc)) from None


@mcp.tool()
def swg_export_animation(out_path: str, start: float | None = None, end: float | None = None,
                         kfat: bool = False) -> dict:
    """Export the scene's skeleton animation (all joints) to a .ans with the rails applied: time unit ntsc
    (30 fps), playback range [start, end] (defaults to the current range), compressed CKAT unless kfat=True.
    Joints must carry the skeleton bind (import the .sat/.skt with importSat first) and keys must be bind +
    offset. Runs swg_check on the result."""
    resp = _py(r"""
import os
cmds.currentUnit(time='ntsc', updateAnimation=True)
if args['start'] is not None and args['end'] is not None:
    cmds.playbackOptions(minTime=args['start'], maxTime=args['end'], animationStartTime=args['start'],
                         animationEndTime=args['end'])
joints = cmds.ls(type='joint')
if not joints:
    raise RuntimeError('no joints in the scene')
missing = [j for j in joints if not cmds.attributeQuery('swgBindRotate', node=j, exists=True)]
os.makedirs(os.path.dirname(args['out']), exist_ok=True)
cmds.select(joints, r=True)
cmds.file(args['out'], force=True, exportSelected=True, type='SwgAns', options='format=kfat' if args['kfat'] else '')
result = {'out': args['out'], 'joints': len(joints), 'joints_without_bind': missing[:20],
          'range': [cmds.playbackOptions(q=True, minTime=True), cmds.playbackOptions(q=True, maxTime=True)]}
""", out=out_path.replace("\\", "/"), start=start, end=end, kfat=kfat)
    resp["rails"] = rails.check(out_path, DEFAULT_EXPORT_ROOT)
    return resp


THEMES = {"tatooine": "tato", "corellia": "corl", "naboo": "nboo"}


def _stock_lods(template: Path, client: Path) -> tuple[str, str, list[str]]:
    """Stock exterior chain of a building template: appearance .apt -> .lod -> its child meshes (tree paths)."""
    apt = iff.template_strings(template).get("appearanceFilename")
    if not apt:
        raise ToolError(f"{template} has no appearanceFilename")
    if not (client / apt).exists():
        raise ToolError(f"{client / apt} not found (only in a packed archive?): extract it into the data tree first")
    lod = iff.parse_iff((client / apt).read_bytes()).first("APT ").forms()[0].first("NAME").data.split(b"\0")[0].decode()
    names: list[str] = []

    def walk(b):
        for c in b.children:
            if c.is_form:
                walk(c)
            elif c.tag == "CHLD":
                names.append(c.data[4:].split(b"\0")[0].decode())
    if lod.endswith(".msh"):
        return apt, lod, [lod]
    walk(iff.parse_iff((client / lod).read_bytes()))
    return apt, lod, ["appearance/" + n if not n.startswith("appearance/") else n for n in names]


@mcp.tool()
def pob_interior_for_stock(template: str, category: str = "", theme: str = "", seed: int = 1,
                           export_root: str = DEFAULT_EXPORT_ROOT) -> dict:
    """Give a stock exterior-only building (e.g. a city filler, object/building/<planet>/shared_filler_*.iff) a
    walkable interior and export it as a POB that overrides the stock template (same tree path, under export_root).
    The stock l0 mesh stays the exterior cell r0 with its own shaders; the entrance is cut where the door is
    painted (door shaders), else on the facade nearest the rooms with nothing in front; rooms fill the largest
    rectangle inside the shell on every storey used. category: tower (lobby + elevator + apartments), house
    (hall + back rooms, stair to an upper floor), slum (1-3 room dwelling), block, historic - default from the name
    and size. Writes .pob/.msh/.flr, the exterior .lod (stock far LODs, radar outline and hardpoints kept), a .sfp
    footprint and the template; returns the plan, files and swg_check result."""
    data = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
    shared = data.parent.parent.parent / "sys.shared" / "compiled" / "game"
    tpl = Path(template) if Path(template).is_absolute() else shared / template
    if not tpl.exists():
        raise ToolError(f"{tpl} not found")
    planet = tpl.parent.name
    theme = theme or THEMES.get(planet, "corl")
    apt, lod, lods = _stock_lods(tpl, data)
    name = "titan_" + Path(apt).stem
    root = Path(export_root)
    out = _py("import importlib, swg_mcp.pob_builder as pb, swg_mcp.filler as fl\n"
              "importlib.reload(pb); importlib.reload(fl)\n"
              "out = fl.build(args['msh'], args['name'], args['theme'], args['category'] or None, args['seed'])\n"
              "out['export'] = pb.export(out['build']['root'], args['export_root'], args['name'])\n"
              "result = out", timeout=1800.0, msh=str(data / lods[0]).replace("\\", "/"), name=name, theme=theme,
              category=category, seed=seed, export_root=str(root).replace("\\", "/"))
    pob = root / f"appearance/{name}.pob"
    out["exterior_lod"] = iff.write_exterior_lod(root, pob, stock_lod=data / lod if lod.endswith(".lod") else None)
    bb = out["bbox"]
    rect = (-bb[3], bb[2], -bb[0], bb[5])          # engine space: the exporter mirrors Maya X
    sfp = f"footprint/building/{planet}/{tpl.stem}.sfp"
    out["footprint"] = iff.write_footprint(root / sfp, rect)
    # flatten the ground under the building and its porch to the building origin, so the player walks off the
    # terrain onto the porch floor (and through its portal edge into the cell) instead of over it
    lay = f"terrain/{name}.lay"
    pad = 6.0
    out["layer"] = iff.flatten_layer(data / iff.STOCK_FLATTEN_LAYER, root / lay,
                                     (rect[0] - pad, rect[1] - pad, rect[2] + pad, rect[3] + pad), 6.0)
    out["template"] = iff.building_template(tpl, root / f"object/building/{planet}/{tpl.name}", f"appearance/{name}.pob",
                                            {"appearanceFilename": "", "structureFootprintFileName": sfp,
                                             "terrainModificationFileName": lay})
    out["rails"] = rails.check(pob, root)
    out["spawn"] = f"/scene objectCreate object/building/{planet}/{tpl.name} <x> <z> <heading>"
    return out


# ----------------------------------------------------------------------------------------------------------------
# offline client: drive the development client through its DevBridge socket (localhost + per-run token)

_client = client.ClientBridge()


def _bridge(cmd: str, timeout: float = 20.0, **fields: Any) -> dict:
    try:
        reply = _client.request(cmd, timeout=timeout, **fields)
    except client.ClientBridgeError as exc:
        raise ToolError(str(exc)) from None
    if not reply.get("ok", False) and "error" in reply:
        raise ToolError(reply["error"])
    return reply


@mcp.tool()
def swg_client_launch(port: int = client.DEFAULT_PORT, export_root: str = "") -> dict:
    """Start the development client (exe/win64_rel/SwgTitan_d.exe) with the export folder on its search path and
    the DevBridge on 127.0.0.1:port; returns once the bridge answers. The offline scene loads on its own; use
    swg_client_state to see when the player is in."""
    global _client
    try:
        out = client.launch(port, export_root or DEFAULT_EXPORT_ROOT)
    except client.ClientBridgeError as exc:
        raise ToolError(str(exc)) from None
    # stay on this client even when another session launches one later (its token is pinned per port)
    _client.close()
    _client = client.ClientBridge(port)
    return out


@mcp.tool()
def swg_client_state() -> dict:
    """Player and camera: world / parent-space position, yaw, cell name and index, building template and pob, plus
    the frame counter and whether a scene is loading. Use it to check where a warp landed and which cell the camera
    is in (camera cell != player cell near a doorway is how portal problems show)."""
    return _bridge("state")["result"]


@mcp.tool()
def swg_client_exec(line: str, settle_frames: int = 0) -> dict:
    """Run a chat line in the client exactly as if typed (e.g. "/scene objectCreate <template> x z heading",
    "/warpme x y z", an alias). Returns the console output it produced. settle_frames > 0 waits that many frames
    and returns the state too (e.g. after a warp)."""
    out = _bridge("exec", line=line)
    res = {"ok": out.get("ok"), "output": out.get("result", "")}
    if settle_frames > 0:
        start = _bridge("state")["result"]["frame"]
        deadline = time.time() + 30.0
        while time.time() < deadline:
            st = _bridge("state")["result"]
            if st["frame"] - start >= settle_frames:
                res["state"] = st
                break
            time.sleep(0.05)
    return res


@mcp.tool()
def swg_client_walk(to: list[float], face: list[float] | None = None, speed: float = 6.0) -> dict:
    """Walk the player to a world point frame by frame under the client's real collision: walls and floor edges stop
    them, floors set the height (stairs, porches), doorways change cell, doors open on approach. Returns outcome
    "arrived" or "blocked" (with where they stopped) and the cells entered. Route through doorways with several
    calls; after /warpme the bridge drops the post-warp float first. `face` turns the player (and chase camera)
    toward a point on arrival."""
    fields: dict[str, Any] = {"to": list(to), "speed": speed}
    if face:
        fields["face"] = list(face)
    return _bridge("walk", timeout=180.0, **fields)["result"]


@mcp.tool()
def swg_client_screenshot(name: str = "") -> Image:
    """Screenshot of the client's own back buffer (no desktop capture, so overlapping windows don't matter)."""
    stem = name or f"mcp_{int(time.time() * 1000)}"
    reply = _bridge("screenshot", path=f"screenshots/{stem}")["result"]
    path = client.CLIENT_DIR / reply["file"]
    deadline = time.time() + 10.0
    while time.time() < deadline and not (path.exists() and path.stat().st_size > 0):
        time.sleep(0.1)
    if not path.exists():
        raise ToolError(f"the client reported {reply['file']} but it was not written")
    time.sleep(0.2)                      # let the writer finish
    data, fmt = client.image_for_mcp(path)
    return Image(data=data, format=fmt)


@mcp.tool()
def swg_client_log(since: int = 0) -> dict:
    """Console output lines (command results, errors) after sequence number `since`; pass the returned `last` next
    time to get only new lines."""
    return _bridge("log", since=since)["result"]


@mcp.tool()
def swg_client_menu(action: str = "", open_menu: bool = False) -> dict:
    """The offline test menu: one-click test actions in categories Vehicles (spawn + mount a swoop, speeder, X-34,
    BARC, AT-ST, jetpack; pick any vehicle; speed readout; dismount), Atmospheric flight (X-wing, TIE, Y-wing, N-1,
    YT-1300 30 m up; presets around the Titan starport at 45,450: approach, hover over the well, aerial view; pick
    any player ship; speed / altitude readout; climb; leave the ship), Animations (play / loop on the player or a
    spawned bantha / dewback; browse the player's or the last spawn's animations, or any species; stop loops), Spawn
    (creatures, stock buildings, the starport; pickers over every template; list / delete spawns), Warp (save / go to
    points, origin, up 50 m), Camera (orbit the player or the last spawn, top-down, back to chase) and Debug views
    (floors, collision extents and meshes, portals, skeletons, hardpoints, FPS, network ids, time of day). No
    arguments lists every action ({id, category, label, console lines}) and the saved points; `action` (an id such as
    "flight.approach") runs it and returns each line's console output (and the lines a wait deferred); open_menu=True
    opens the in-game pop-up menu (also /devmenu in chat)."""
    try:
        return _client.menu(action=action, open_menu=open_menu)
    except client.ClientBridgeError as exc:
        raise ToolError(str(exc)) from None


@mcp.tool()
def swg_client_load_scene(avatar: str = "", terrain: str = "") -> dict:
    """Start the offline single-player scene from the login screen without clicking (Load Scene / Next): `avatar` is
    a player template such as object/creature/player/shared_rodian_female.iff (default human male), `terrain` a
    .trn (default terrain/simple.trn). Poll swg_client_state until the player is in."""
    try:
        return _client.load_scene(avatar=avatar, terrain=terrain)
    except client.ClientBridgeError as exc:
        raise ToolError(str(exc)) from None


@mcp.tool()
def swg_client_camera(mode: str = "info", pos: list[float] | None = None, look: list[float] | None = None,
                      distance: float | None = None, pitch: float | None = None, yaw: float | None = None,
                      target: str = "", pivot: list[float] | None = None) -> dict:
    """Place the client camera for screenshots (then swg_client_screenshot). mode "free": world `pos` [x,y,z] looking
    at `look` (default the player), e.g. an aerial view of a building. "orbit": `distance` m from the player (or the
    look-at target with target="last"), `pitch` degrees down (89 = top-down), `yaw` degrees (default the player's
    heading). "pivot": orbit the world point `pivot` (with distance/yaw/pitch). "chase": back to the normal camera.
    "info": where the camera is."""
    try:
        return _client.camera(mode=mode, pos=pos, look=look, distance=distance, pitch=pitch, yaw=yaw, target=target,
                              pivot=pivot)
    except client.ClientBridgeError as exc:
        raise ToolError(str(exc)) from None


@mcp.tool()
def swg_client_camera(pivot: list[float] | None = None, distance: float = 2.0, yaw: float = 0.0, pitch: float = 0.0,
                      chase: bool = False) -> dict:
    """Aim the free camera at a world point for screenshots: it orbits `pivot` [x,y,z] at `distance` metres, `yaw`
    and `pitch` in degrees (yaw 0 looks along +z, so a character facing -z is seen from the front). chase=True goes
    back to the normal chase camera."""
    try:
        return _client.camera(pivot=pivot, distance=distance, yaw=yaw, pitch=pitch, chase=chase)
    except client.ClientBridgeError as exc:
        raise ToolError(str(exc)) from None


# ----------------------------------------------------------------------------------------------------------------
# God Client: drive world editing through its automation bridge (SwgGodClient GodClientBridge; localhost + per-run
# token in godclient_bridge.json). The user starts the editor (it signs in); these tools only attach to it.

_godclient = godclient.GodClientBridge()


def _god(cmd: str, timeout: float = 20.0, **fields: Any) -> Any:
    try:
        return _godclient.call(cmd, timeout=timeout, **fields)
    except client.ClientBridgeError as exc:
        raise ToolError(str(exc)) from None


@mcp.tool()
def godclient_state() -> dict:
    """The running God Client (SwgGodClient_r.exe with [GodClient] bridgePort set): scene, whether connected or
    single player, the god camera (pivot, distance, yaw, pitch), the cursor's world point, the avatar's cell, the
    selection (network id, template, cell, world and parent-space position, yaw/pitch/roll, scale, and the pending
    ghost transform not applied yet), the copied transform, drop/align-to-terrain toggles, and undo state for
    objects and terrain (armed terrain tool, brush size/strength). ready=false until a scene is loaded. Never
    launch the god client yourself: it signs in with user.cfg; ask the user to start it."""
    return _god("state")


@mcp.tool()
def godclient_load_scene(terrain: str = "", avatar: str = "") -> dict:
    """From the God Client's login screen, load an offline single-player scene, as its Load Scene (Local) button
    does, so the editing tools work without a server: `terrain` a .trn (default terrain/simple.trn), `avatar` a
    player template (default object/creature/player/shared_human_male.iff). Offline, godclient_create places
    objects locally. Poll godclient_state until ready=true. The load is synchronous: the editor (and this bridge)
    stalls for minutes in the release build and calls time out or are refused meanwhile; tell the user to leave
    the window alone until state answers again."""
    fields = {k: v for k, v in (("terrain", terrain), ("avatar", avatar)) if v}
    return {"result": _god("loadscene", timeout=60.0, **fields)}


@mcp.tool()
def godclient_objects(center: list[float] | None = None, radius: float = 64.0, template: str = "",
                      limit: int = 100) -> dict:
    """Loaded objects nearest a world point (default the camera pivot) within `radius` m, nearest first: network
    id, template, world position, cell, distance, whether selected. `template` keeps only templates containing that
    text (e.g. "frn_titan_"). Use the ids with godclient_select."""
    fields: dict[str, Any] = {"radius": radius, "limit": limit}
    if center is not None:
        fields["center"] = list(center)
    if template:
        fields["template"] = template
    return _god("objects", **fields)


@mcp.tool()
def godclient_select(ids: list[str] | None = None, template: str = "", add: bool = False,
                     clear: bool = False) -> dict:
    """Select objects by network id (`ids`) and/or every loaded object of a full template path
    ("object/tangible/.../shared_x.iff"), replacing the selection unless add=True; clear=True (alone) deselects
    all. Replacing or clearing the selection discards unapplied ghosts, like Esc. Objects in another cell than the avatar, or without an appearance, cannot be selected: they come back in
    `rejected` with the reason. Returns the new selection."""
    fields: dict[str, Any] = {"add": add, "clear": clear}
    if ids:
        fields["ids"] = [str(i) for i in ids]
    if template:
        fields["template"] = template
    return _god("select", **fields)


@mcp.tool()
def godclient_create(template: str, pos: list[float], yaw: float = 0.0, select: bool = True) -> dict:
    """Place `template` (full path, object/....iff) in the world cell at world `pos` [x,y,z] with heading `yaw`
    degrees, as a cursor placement does (Recent Templates, buildout files the user chose to open; no dialogs).
    Offline (single player) the object exists at once and comes back as mode "local"; connected, the server creates
    it (mode "server") and, with select=True, it is selected when it arrives, so poll godclient_state. A shared_
    template must be on the search path; a server template in single player edits the area buildout."""
    return _god("create", timeout=60.0, template=template, pos=list(pos), yaw=yaw, select=select)


@mcp.tool()
def godclient_transform(pos: list[float] | None = None, yaw: float | None = None, pitch: float | None = None,
                        roll: float | None = None, scale: list[float] | float | None = None, copy: bool = False,
                        paste: str = "", apply: bool = False) -> dict:
    """Edit the selection's ghosts, as the Set Transform dialog and the transform clipboard do: `pos` [x,y,z] in
    the parent space (world, or the cell for interior objects) moves every selected object there; yaw/pitch/roll in
    degrees replace the whole rotation (applied yaw, then pitch, then roll; a missing angle is 0); `scale` is
    [x,y,z] or one number. copy=True copies the primary selection's transform first; paste="position", "rotation"
    or "all" (with scale) pastes the copied transform onto every selected object. apply=True then moves the objects
    to their ghosts (Ctrl+T), which with drop/align-to-terrain on also drops or aligns them; otherwise the ghosts
    wait for godclient_apply so they can be checked first. Cancel unapplied ghosts with godclient_select(clear=True)
    (godclient_undo would revert the last applied edit instead); undo an applied transform with godclient_undo."""
    fields: dict[str, Any] = {"copy": copy, "apply": apply}
    if pos is not None:
        fields["pos"] = list(pos)
    for key, value in (("yaw", yaw), ("pitch", pitch), ("roll", roll)):
        if value is not None:
            fields[key] = value
    if scale is not None:
        fields["scale"] = list(scale) if isinstance(scale, (list, tuple)) else float(scale)
    if paste:
        fields["paste"] = paste
    return _god("transform", **fields)


@mcp.tool()
def godclient_apply() -> dict:
    """Move the selected objects to their ghosts (Apply Transform, Ctrl+T / Space). Returns the selection."""
    return {"selection": _god("apply")}


@mcp.tool()
def godclient_undo(target: str = "auto") -> dict:
    """Undo one edit. target "auto" is Ctrl+Z (a terrain stroke first while a terrain tool is armed and the
    Terrain dock is open, else the last object edit); "objects" or "terrain" picks one history."""
    return _god("undo", target=target)


@mcp.tool()
def godclient_redo(target: str = "auto") -> dict:
    """Redo one edit; target as for godclient_undo ("auto", "objects" or "terrain")."""
    return _god("redo", target=target)


@mcp.tool()
def godclient_console(line: str, wait: float = 5.0, target: str = "") -> dict:
    """Run a Console dock line: server console text (e.g. "object get <id>", "objvar list <id>") goes to the
    server, and the server's reply (matched by message id) comes back within `wait` seconds (0: don't wait; max 30;
    answered=false when it ran out). "/name args" runs a slash command on `target` (network id; default the primary
    selection), which has no reply. Offline (single player) nothing answers. Later output: godclient_log."""
    fields: dict[str, Any] = {"line": line, "wait": wait}
    if target:
        fields["target"] = target
    return _god("console", timeout=max(20.0, wait + 15.0), **fields)


@mcp.tool()
def godclient_log(since: int = 0) -> dict:
    """Server console replies (with their message ids) and the lines the bridge sent, after sequence number
    `since`; pass the returned `last` next time to get only new lines."""
    return _god("log", since=since)


@mcp.tool()
def godclient_camera(pivot: list[float] | None = None, distance: float | None = None, yaw: float | None = None,
                     pitch: float | None = None, smooth: bool = False) -> dict:
    """Read or aim the god camera (FreeCamera pivot mode): it orbits world `pivot` [x,y,z] at `distance` m, `yaw`
    and `pitch` in degrees (the editor's own FreeCamera::Info values: read them back from a view you like). Any
    subset can be given; none just reads. smooth=True glides there like a bookmark jump. pos_w is the camera's
    position as of the last frame."""
    fields: dict[str, Any] = {"smooth": smooth}
    if pivot is not None:
        fields["pivot"] = list(pivot)
    for key, value in (("distance", distance), ("yaw", yaw), ("pitch", pitch)):
        if value is not None:
            fields[key] = value
    return _god("camera", **fields)


@mcp.tool()
def godclient_screenshot(name: str = "") -> Image:
    """Screenshot of the God Client's game view (its own back buffer, so overlapping windows don't matter), saved
    under exe/win64_rel/screenshots/. Aim it first with godclient_camera."""
    stem = name or f"godclient_{int(time.time() * 1000)}"
    try:
        path = _godclient.screenshot(f"screenshots/{stem}")
        data, fmt = client.image_for_mcp(path)
    except client.ClientBridgeError as exc:
        raise ToolError(str(exc)) from None
    return Image(data=data, format=fmt)


@mcp.tool()
def godclient_terrain_stroke(points: list[list[float]], tool: str = "", size: float = 0.0, strength: float = 0.0,
                             spacing: float = 0.0) -> dict:
    """One terrain brush stroke through world [x, z] points ([x, y, z] works too), as a mouse drag in the 3D view
    makes it (one terrain undo step). `tool`: raise, lower, flatten, smooth, noise, setheight, shader, flora, water
    or radial (empty: the tool armed in the Terrain dock); `size` (m) and `strength` (0..1) are set on the dock
    sliders (0: keep).
    The path is resampled every `spacing` m (default a quarter of the brush size); raise/lower add the dock's
    speed per dab, so a denser path raises more. Other settings (shader family, set-height target, falloff) come
    from the dock. Needs procedural terrain loaded in the Terrain dock; save the .trn from the dock as usual."""
    fields: dict[str, Any] = {"points": [[float(p[0]), float(p[-1])] for p in points]}
    if tool:
        fields["tool"] = tool
    if size > 0:
        fields["size"] = size
    if strength > 0:
        fields["strength"] = strength
    if spacing > 0:
        fields["spacing"] = spacing
    return _god("terrain_stroke", timeout=120.0, **fields)


# ----------------------------------------------------------------------------------------------------------------
# procedural terrain (.trn / .lay): swg_maya_mcp/terrain

terrain_tools.register(mcp)


def main():
    mcp.run("stdio")


if __name__ == "__main__":
    main()
