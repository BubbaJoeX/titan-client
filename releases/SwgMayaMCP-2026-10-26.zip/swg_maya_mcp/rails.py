"""Rails: the conventions Titan content must follow to work in the engine, learned the hard way, as data the MCP
serves (swg_rails) and as file checks it runs (swg_check, and automatically after exports). Each rule says what,
why (the engine behaviour behind it) and which tool enforces it, so a model driving the tools does not have to
rediscover them."""

from __future__ import annotations

import math
import os
import re
import struct
from pathlib import Path
from typing import Any

from . import iff

RULES: dict[str, list[dict[str, str]]] = {
    "buildings": [
        {"id": "ground-y0", "rule": "A building's ground level (entrance floor of r0) is y = 0.",
         "why": "The client puts the object at the terrain height under its origin and the .lay flattens to that "
                "height; anything else floats or sinks.", "enforced_by": "pob_build ground_y, swg_check"},
        {"id": "portal-facing", "rule": "A portal's front (normal of v0,v1,v2) faces INTO its clockwise cell; "
                                        "connectPobCells' local -Z is the front.",
         "why": "Portal::testPenetration uses the side to move the camera/player between cells; inverted doors "
                "trap you in the wrong cell.", "enforced_by": "pob_build, pob_inspect, swg_check"},
        {"id": "r0-crossable", "rule": "r0 (exterior) floor edges that are not walls are crossable; edges at a wall "
                                       "foot are WallBase.",
         "why": "Uncrossable open edges stop the player at the pad rim so the house cannot be reached.",
         "enforced_by": "flr translator (swgFloorOpenEdgesCrossable), swg_check"},
        {"id": "collision-none", "rule": "Building cell meshes export with a NULL collision extent "
                                         "(exportStaticMesh -collision none).",
         "why": "CollisionProperty prefers the appearance extent over the cell 0 CMSH, so a box extent turns the "
                "whole shell into a solid block.", "enforced_by": "pob_export_structure, swg_check"},
        {"id": "doors-optional", "rule": "Only entrances and private rooms need door leaves; open doorways and arches "
                                         "are portals without a door style (spec door style open|arch).",
         "why": "Door hardpoints spawn interactive door objects; too many look wrong and cost draw calls.",
         "enforced_by": "pob_build doors[].style"},
        {"id": "window-portals", "rule": "Windows are non-passable portals (portalPassable 0) from the room to r0, "
                                         "glazed with alpha glass (shader/all_glass_a_aa7.sht).",
         "why": "The cell can then see the world through the window and the world sees in; non-passable keeps "
                "the player and the pathfinder out.", "enforced_by": "pob_build window_portals"},
        {"id": "cell-lights", "rule": "Each interior cell: 1 ambient + 2 parallel + 1-3 point lights "
                                      "(stock layout); daylight parallels come through windows.",
         "why": "Cells are lit only by their own lights; an unlit cell renders black.",
         "enforced_by": "pob_build lights, swg_check"},
        {"id": "uv-world-scale", "rule": "Wall/floor UVs are world-scaled per material (UV_SCALE) along the wall "
                                         "tangent, so textures keep texel density on every room size.",
         "why": "Per-face 0..1 UVs stretch textures on long walls.", "enforced_by": "pob_build"},
        {"id": "radar-lod", "rule": "The r0 appearance is a DTLA .lod with a RADR footprint shape (floor tris at "
                                    "y 0.5); .apt points at the .lod.",
         "why": "OverheadMap draws appearance->getRadarShape(); only .lod and component appearances provide one.",
         "enforced_by": "pob_export_structure (exterior_lod), swg_check"},
        {"id": "template", "rule": "Spawnable buildings need object/building/titan/shared_<name>.iff with "
                                   "portalLayoutFilename, terrainModificationFileName (.lay) and "
                                   "structureFootprintFileName (.sfp).",
         "why": "No .lay = the building sits on raw terrain; no .sfp = no placement footprint.",
         "enforced_by": "swg_building_template, swg_check"},
        {"id": "stock-shell", "rule": "Interiors for stock exterior-only buildings: keep the stock l0 mesh as r0 "
                                      "(pob_interior_for_stock / spec shell), carve stock geometry out of the room "
                                      "volumes, cut the entrance at the painted door (else the clear facade spot) "
                                      "through to past anything in front, line the passage, and override the stock "
                                      "template (appearanceFilename empty + portalLayoutFilename) at its own path.",
         "why": "Stock shells are overlapping boxes with internal partitions and painted doors; anything of r0 "
                "inside a room shows through the entrance portal, and a doorway behind a railing or terrace "
                "cannot be walked through.", "enforced_by": "pob_interior_for_stock, filler.py, _shell_cut"},
        {"id": "keep-stock-lods", "rule": "An exterior .lod replacing a stock one keeps the stock far LODs, RADR "
                                          "outline and hardpoints (client data files hang lights/effects on them).",
         "why": "Missing hardpoints log CdfHpo warnings and drop the effects; one LOD costs frame time in cities.",
         "enforced_by": "write_exterior_lod(stock_lod=...)"},
        {"id": "maya-last-face", "rule": "Deleting every face of a Maya mesh leaves one behind: delete the shape.",
         "why": "A painted-door triangle survived the entrance cut this way.", "enforced_by": "_shell_cut"},
        {"id": "prelit-vertex-colors", "rule": "Interior shaders with c_ effects (c_simple, c_2blend_dirt...: shader "
                                               "suffix _cs8/_cd8/_c2d13...) are prelit: their meshes need color0 vertex "
                                               "colours (baked cell lighting, stock ~0.4-0.7 grey); a_ effects are "
                                               "lit by the cell lights.",
         "why": "Diffuse cell lights skip precalculated-vertex-lighting shaders, so a c_ mesh without color0 renders "
                "black whatever the lights are. Stock interiors bake their lights into color0.",
         "enforced_by": "pob_builder.bake_vertex_lighting (runs in export), ExportStaticMesh colour set -> color0, "
                        "msh import color0 -> swgPrelit, swg_check"},
        {"id": "floor-edge-collision", "rule": "Movement is blocked by floor edges only (WallBase / uncrossable), "
                                               "never by meshes: walls need a floor edge at their foot, fixtures "
                                               "(counters, basins) are holes in the floor, exteriors need an r0 floor "
                                               "skirt whose inner edges sit at the wall foot.",
         "why": "convertToSimpleExtent drops mesh extents (CMSH / ET_Mesh); a wall over open floor or bare terrain "
                "can be walked through.", "enforced_by": "pob_build obstacles, filler.add_skirt, starport_ring.clear_stock"},
        {"id": "floor-seams", "rule": "Floor pieces welded edge to edge leave no blocking edge where the floor goes "
                                      "on at the same height: those open seam edges are crossable.",
         "why": "A T-junction (a vertex of one piece mid-way along the other's edge) leaves both sides without "
                "neighbours, so the floor builder types them uncrossable/WallBase and the player stops mid-room as if "
                "at a wall (the starport checkpoint lanes).", "enforced_by": "iff.open_floor_seams (pob_export_structure, "
                "make_atmo_starport), swg_check"},
        {"id": "terrain-collision-boxes", "rule": "To stop players on the terrain (statics, building exteriors such as "
                                                  "glass walls) put simple extents - boxes, composites of boxes - in the "
                                                  "appearance .lod's APPR collision; floor edges cannot stop someone "
                                                  "stepping up onto a floor from the terrain.",
         "why": "CollisionDetect::testExtents tests a moving sphere against simple / component / detail extents only; "
                "a CMSH (cell or .lod) serves the camera and line of sight. Uncrossable floor edges only hold players "
                "already on the floor.", "enforced_by": "iff.write_static_lod, iff.set_lod_collision_boxes, make_otoh_gunga.glass_collision"},
        {"id": "undersides", "rule": "Every surface seen from below gets a bottom face: stair flights, decks, landings, "
                                     "rims, overhangs, walkway and bridge decks, beams, roofs on posts.",
         "why": "The client back-face culls, so a surface modelled from above only is invisible from under it and the "
                "player looking up sees straight through.", "enforced_by": "pob_builder.close_undersides, kit Piece.box / prism (raised)"},
        {"id": "collision-facing", "rule": "Cell collision (CMSH) triangles face the side the player and camera are "
                                           "on - into the room - as the engine reads them: stock stores them with "
                                           "cross(B-A, C-A) pointing out of the room, which is what exportPob writes "
                                           "for a Maya face pointing in (X mirrored, triangle order kept).",
         "why": "One-sided camera collision: with the front outside the room the chase camera slid through the walls "
                "into the void and every view through a doorway went black.",
         "enforced_by": "exportPob CMSH writer, swg_check (collision-facing)"},
        {"id": "seamless-cuts", "rule": "Cut openings into existing meshes in place (polyCut along the opening's "
                                        "planes, delete the faces inside) so the original shading groups and UVs stay "
                                        "and neighbouring faces share the new vertices; never rebuild clipped faces "
                                        "as separate pieces.",
         "why": "Re-made pieces put new vertices on edges of untouched neighbours: T-junction cracks show the clear "
                "colour as magenta slits.", "enforced_by": "pob_builder._shell_cut / cut_plan_prism"},
        {"id": "wall-thickness", "rule": "Walls are 0.35 m deep (spec wall_thickness; never less than the thickest "
                                         "door leaf in the building + 2 x 0.06 m): partitions inset 0.175 m each "
                                         "side, outside walls inset the whole thickness behind the shell face; "
                                         "openings lined with jambs/head/sill, the walk floor tongued through "
                                         "doorways to the portal on the edge.",
         "why": "Zero-width walls read as paper, z-fight at doorways, and door leaves (up to 0.215 m thick) poke out "
                "of both faces; the portal and floor edges must stay on the edge for cell crossing.",
         "enforced_by": "pob_builder wall_thickness / wall_for_doors"},
        {"id": "door-leaf-fit", "rule": "A doorway with a door leaf is sized to that leaf (stock leaves: 0.08-0.22 m "
                                        "thick, 1.1-3.1 m wide, 2.75-3.9 m tall; +0.1 m width, +0.05 m height); "
                                        "if the leaf cannot fit the shared wall or the headroom, the doorway is "
                                        "left open instead. Pick door styles whose leaf fits the opening.",
         "why": "The client spawns the leaf model at the portal; a 3 m door_corl_metal_s03 in a 1.6 m opening or a "
                "3.3 m historic door under a 2.8 m head clips through the walls and ceiling.",
         "enforced_by": "pob_builder DOOR_LEAF / door_fits, filler_plan._fitting_door"},
        {"id": "min-sizes", "rule": "Rooms >= 3.5 m on every side and >= 16 m2; hallways >= 2.0 m wide (2.25 house, "
                                    "2.5-3.0 commerce/office); interior doorways need >= 1.9 m of shared wall.",
         "why": "Measured over 6492 stock cells: rooms p10 min side 4.5 m / area 38 m2 (p5 22 m2), halls 1.9-2.5 m "
                "in player houses, 2.7-3.7 m municipal. Smaller reads as a closet and the camera clips.",
         "enforced_by": "filler_plan MIN_ROOM / MIN_AREA / MIN_HALL / HALL_W"},
        {"id": "hallways", "rule": "Plan units around hallways like the stock interiors: foyer at the door, a hall "
                                   "running in with rooms off both sides (each its own door) and an end room; rooms "
                                   "open off halls, not through each other. Vary with curved rooms (apse end walls, "
                                   "rounded corners, half-round hall ends). Hall materials come from the planet's "
                                   "stock hallway cells.",
         "why": "Chains of rooms opening into each other read as a maze of closets; stock houses, cantinas and "
                "starports are hall-and-room plans.", "enforced_by": "filler_plan.spine"},
        {"id": "static-collision", "rule": "Static structures (object/static/structure/<theme>) collide through "
                                           "their .lod's APPR collision extent, like stock: .apt -> .lod (DTLA 0007) "
                                           "with an extent box + a collision box, or for pieces with a passage or a "
                                           "curve a composite of boxes (DTAL/CPST/CMPT) that leaves the passage "
                                           "open; plus a RADR footprint. Walls sink 1 m into the terrain.",
         "why": "A static object's collision is its appearance's extent; a bare mesh (NULL extent) is walked "
                "through, a single box over a gate blocks the gate.", "enforced_by": "iff.write_static_lod, kit.py"},
        {"id": "static-kit-names", "rule": "New kit pieces follow the stock names <prefix>_imprv_<piece>_sNN "
                                           "(appearance thm_<name>.apt), in the theme's own folder, with sNN after "
                                           "every stock suffix; templates derive from a stock structure template "
                                           "(only appearanceFilename changes); materials are the planet's stock "
                                           "exterior a_ shaders.",
         "why": "Matches the existing kits (corl_imprv_wall_4x16_s01...) and never shadows a stock piece in the "
                "search path.", "enforced_by": "examples/make_kit.py"},
        {"id": "build-on-stock", "rule": "Extending a stock building: import its .pob (importPob), keep its cells, "
                                         "and graft new cells onto its existing hallways - build the new room "
                                         "against a stock exit portal, re-point that portal from r0 into the room, "
                                         "cut the stock r0 meshes and floor inside the new footprint, merge the "
                                         "r0 floors, renumber portals 0..n-1 in pairs.",
         "why": "The stock hallways, lighting and look stay intact and the new rooms continue them; one POB "
                "exports and loads as one building.", "enforced_by": "starport_ring.merge / clear_stock"},
    ],
    "animation": [
        {"id": "ckat", "rule": "Export compressed CKAT (default); KFAT only with options format=kfat for debugging.",
         "why": "Stock clips are CKAT; CompressedQuaternion::install() must run before compressing or every key "
                "collapses to a constant.", "enforced_by": "SwgAns writer, swg_check"},
        {"id": "names-sorted", "rule": "Transform names are lowercase and sorted by CrcString order (crc32, then "
                                       "strcmp).",
         "why": "The engine binary-searches the transform table; unsorted/mixed-case names leave joints in bind "
                "pose.", "enforced_by": "SwgAns writer, swg_check"},
        {"id": "bind-relative", "rule": "Keys are deltas from the skeleton bind stored on each joint "
                                        "(swgBindRotate/swgBindTranslate); author as bind + offset, never from "
                                        "frame 0.",
         "why": "Engine: local = post * (anim * bind) * pre; translation = bind + anim.",
         "enforced_by": "importSat / SwgAns"},
        {"id": "playback-range", "rule": "Export covers the playback range only, 30 fps (ntsc), keys on every whole "
                                         "frame with linear tangents; loops end on a pose equal to frame 0.",
         "why": "The engine slerps between keys; sparse Euler keys drift.", "enforced_by": "swg_export_animation"},
        {"id": "all_b-axes", "rule": "all_b (hum_m, faces +Z), offsets from bind in degrees: thigh -X hip flexion, "
                                     "shin +X knee bend, spine/root +X lean forward, Head X nod / Y turn / Z tilt, "
                                     "arm +Y raise forward, arm -Z raise sideways ((0,0,-150) overhead), forearm -Y "
                                     "elbow bend.", "why": "Measured by probing; saves trial renders.",
         "enforced_by": "examples/make_twerk.py"},
    ],
    "wearables": [
        {"id": "skmg-0004", "rule": "Skinned wearables are SKMG 0004 .mgn bound to appearance/skeleton/all_b.skt "
                                    "(SKTM), every transform a joint of that skeleton, at most 4 weights per vertex "
                                    "summing to 1; write them with wearable.write_mgn, not the plug-in's .mgn "
                                    "translator.",
         "why": "SkeletalMeshGeneratorTemplate::load_0004 reads the INFO counts, SKTM and TWDT exactly; the plug-in "
                "writer leaves SKTM out and miscounts INFO. Joints of another skeleton (the hum_m_face brows) are "
                "not on the wearer's all_b.", "enforced_by": "examples/make_clothing.py, swg_check"},
        {"id": "appearance-chain", "rule": "The shared template's appearanceFilename is appearance/<name>_f.sat; "
                                           "datatables/appearance/appearance_table maps shared_<name> to the _m/_f "
                                           ".sat per species and gender (:default = the human mesh, :block on "
                                           "wookiee and ithorian); each .sat (SMAT 0003, no animation controller) "
                                           "names one .lmg (MLOD) listing the l0..l3 .mgn.",
         "why": "CreatureObject::isAppearanceWearable swaps the wearable's appearance by template file name and "
                "the wearer's species/gender column; without a row a male wears the female mesh.",
         "enforced_by": "examples/make_clothing.py"},
        {"id": "occlusion", "rule": "Match the stock piece: OITL triangles tagged with body zones, fully-occluded "
                                    "set = the piece's zones, zones-this-occludes and layer as stock (shirt, pants, "
                                    "goggles 1; hat, shoes 2; cape 3 with plain ITL). A piece that occludes a zone "
                                    "covers all of it.",
         "why": "The body (layer 0) drops its triangles in every zone a higher layer occludes, so an occluded zone "
                "the piece does not cover is a hole in the character.", "enforced_by": "swg_check"},
        {"id": "follow-the-skin", "rule": "Body-hugging pieces copy the stock body's skinning: the zone triangles "
                                          "pushed out along the body normal, with the same weights and blend "
                                          "deltas (blend_muscle/fat/skinny, blend_flat_chest on female tops) and "
                                          "a hem lip on open borders.",
         "why": "Weights that differ from the skin under them stretch or poke through when the body bends or the "
                "player changes body shape.", "enforced_by": "make_clothing.derive"},
    ],
    "pipeline": [
        {"id": "export-root", "rule": "Exports go under TITAN_EXPORT_ROOT (D:/exported) with tree paths "
                                      "(appearance/..., object/...); run the client with "
                                      "searchPath_00_8=D:/exported.",
         "why": "Tree paths resolve through the client search path.", "enforced_by": "swg_setup"},
        {"id": "verify-files", "rule": "Verify exports by re-reading them (pob_inspect, swg_inspect_floor, "
                                       "swg_check) before loading the client.",
         "why": "Cheaper than a client restart.", "enforced_by": "pob_export_structure"},
    ],
    "terrain": [
        {"id": "bake-roads", "rule": "Every road and river carries baked height data (one HDTA segment per pair of "
                                     "points); bake after moving points or changing the ground (trn_bake).",
         "why": "AffectorBoundaryPoly::find reads the height data of every road/river; unbaked ones sit at y 0 or "
                "read past the segment list.", "enforced_by": "trn_add_feature bake, trn_bake, trn_validate"},
        {"id": "family-ids", "rule": "Items reference families by id: shader (shader/replace/road/river/ribbon/"
                                     "shader filter), flora, radial, environment, fractal (height fractal, fractal "
                                     "filter, colour ramp fractal), bitmap; the ids must exist in the table.",
         "why": "A missing family paints nothing, or the default family, with no error in release builds.",
         "enforced_by": "trn_validate"},
        {"id": "layer-order", "rule": "Root layers run top to bottom and later ones override earlier ones; inside a "
                                      "layer boundaries OR together, filters AND, affectors run in order, then "
                                      "sublayers with the layer's amount.",
         "why": "TerrainGenerator::Layer::affect; a flatten layer before the hills it should flatten does nothing.",
         "enforced_by": "trn_add_feature (adds features after the ground)"},
        {"id": "no-stock-edits", "rule": "Edited terrains are written to the export root (terrain/<name>.trn), "
                                         "never over stock data.",
         "why": "The export root is on the client search path ahead of the stock trees; stock files stay pristine.",
         "enforced_by": "trn_* out_path checks"},
        {"id": "fine-holes", "rule": "Exact terrain holes use titan's fine exclude (AEXC 0001, trn_add_feature hole): "
                                     "circles / polygons larger than a tile; inside a building .lay name the "
                                     "boundary local... so it moves and turns with the building.",
         "why": "Stock excludes drop whole tiles tested at one corner (about +-3 m off); a fine cut moves crossed "
                "tiles' poles onto the edge, but a hole smaller than a tile only folds its fan. Plain circles in a "
                ".lay are re-centred on the building (offset lost).",
         "enforced_by": "trn_add_feature hole, trn_heights / trn_client_verify (client height emulation)"},
        {"id": "client-check", "rule": "Check terrain in the client with /scene load <name> and the bridge "
                                       "terrain heights (trn_client_verify), on a client launched with its own "
                                       "port.",
         "why": "The generator port matches the engine to float precision; the client is the authority.",
         "enforced_by": "trn_client_verify"},
    ],
}


def rules(topic: str = "") -> dict[str, Any]:
    if topic:
        if topic not in RULES:
            raise ValueError(f"unknown topic {topic!r}; topics: {', '.join(RULES)}")
        return {topic: RULES[topic]}
    return RULES


def summary() -> str:
    """One line per rule, for the server instructions."""
    return " ".join(f"[{t}:{r['id']}] {r['rule']}" for t, rs in RULES.items() for r in rs if t != "pipeline")


# ----------------------------------------------------------------------------
# checks
# ----------------------------------------------------------------------------

def _crc(s: str) -> int:
    crc = 0xFFFFFFFF
    for ch in s.encode("latin1"):
        crc ^= ch << 24
        for _ in range(8):
            crc = ((crc << 1) ^ 0x04C11DB7) & 0xFFFFFFFF if crc & 0x80000000 else (crc << 1) & 0xFFFFFFFF
    return crc ^ 0xFFFFFFFF


def _issue(out: list, level: str, rule: str, msg: str) -> None:
    out.append({"level": level, "rule": rule, "message": msg})


def check_ans(path: str | Path) -> dict[str, Any]:
    root = iff.parse_iff(Path(path).read_bytes())
    issues: list[dict[str, str]] = []
    form = root.first("CKAT") or root.first("KFAT")
    if form is None:
        raise ValueError(f"{path}: not a CKAT/KFAT animation")
    if form.tag == "KFAT":
        _issue(issues, "warn", "ckat", "uncompressed KFAT; stock clips are CKAT")
    ver = form.forms()[0]
    info = iff.Reader(ver.first("INFO").data)
    fps = info.f32()
    frames = info.i16() if form.tag == "CKAT" else info.i32()
    names = [iff.Reader(c.data).string() for c in ver.first("XFRM").chunks("XFIN")]
    bad_case = [n for n in names if n != n.lower()]
    if bad_case:
        _issue(issues, "error", "names-sorted", f"{len(bad_case)} transform names not lowercase, e.g. {bad_case[:3]}")
    keys = [(_crc(n), n.encode("latin1")) for n in names]
    if keys != sorted(keys):
        _issue(issues, "error", "names-sorted", "transform names are not in CrcString order")
    if frames <= 0:
        _issue(issues, "error", "playback-range", "animation has no frames")
    if abs(fps - 30.0) > 0.01:
        _issue(issues, "warn", "playback-range", f"{fps} fps (stock clips are 30)")
    return {"path": str(path), "format": form.tag, "fps": fps, "frames": frames, "transforms": len(names),
            "issues": issues}


def _collision_extent_tag(msh: Path) -> str | None:
    appr = iff.parse_iff(msh.read_bytes()).first("MESH")
    appr = appr.forms()[0].first("APPR") if appr is not None else None
    if appr is None:
        return None
    forms = appr.forms()[0].forms()
    return forms[1].tag if len(forms) > 1 else None


_EFFECT_CACHE: dict[str, str | None] = {}


def _effect(shader: str, roots: list[Path]) -> str | None:
    """effect/xxx.eft a shader template uses (first root that has the .sht)."""
    if shader not in _EFFECT_CACHE:
        _EFFECT_CACHE[shader] = None
        for r in roots:
            f = r / shader
            if f.exists():
                m = re.search(rb"effect[/\\]([A-Za-z0-9_]+)\.eft", f.read_bytes())
                _EFFECT_CACHE[shader] = m.group(1).decode() if m else None
                break
    return _EFFECT_CACHE[shader]


def _prelit_without_color(msh: Path, roots: list[Path]) -> list[str]:
    """Shader primitives of a mesh whose effect is prelit (c_*) but whose vertices carry no color0."""
    out = []
    root = iff.parse_iff(msh.read_bytes())

    def walk(b, tag):
        for c in b.children:
            if c.tag == tag:
                yield c
            if c.is_form:
                yield from walk(c, tag)
    names = [n.data.split(b"\0")[0].decode("latin1") for n in walk(root, "NAME")]
    flags = [struct.unpack_from("<I", v.forms()[0].first("INFO").data)[0] for v in walk(root, "VTXA")]
    for name, fl in zip(names, flags):
        eff = _effect(name, roots)
        if eff and eff.startswith("c_") and not fl & 8:
            out.append(name)
    return out


def _cmsh_facing_in(pob_path: str | Path) -> list[float]:
    """Per interior cell with a CMSH: the fraction of its triangles whose cross(B-A, C-A) points toward the mesh
    centroid (stock: ~0-0.2, i.e. they point out of the room)."""
    root = iff.parse_iff(Path(pob_path).read_bytes())

    def walk(b, tag):
        for c in b.children:
            if c.tag == tag:
                yield c
            if c.is_form:
                yield from walk(c, tag)
    out = []
    for k, cell in enumerate(walk(root, "CELL")):
        if k == 0:
            continue
        cm = next(walk(cell, "CMSH"), None)
        vert = next(walk(cm, "VERT"), None) if cm is not None else None
        indx = next(walk(cm, "INDX"), None) if cm is not None else None
        if vert is None or indx is None or not indx.data:
            continue
        v = [struct.unpack_from("<3f", vert.data, i) for i in range(0, len(vert.data), 12)]
        ix = struct.unpack_from(f"<{len(indx.data) // 4}i", indx.data)
        tris = [(v[ix[i]], v[ix[i + 1]], v[ix[i + 2]]) for i in range(0, len(ix) - 2, 3)]
        cx = [sum(t[j][a] for t in tris for j in range(3)) / (3 * len(tris)) for a in range(3)]
        inn = 0
        for p0, p1, p2 in tris:
            u = [p1[a] - p0[a] for a in range(3)]
            w = [p2[a] - p0[a] for a in range(3)]
            n = (u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0])
            inn += sum(n[a] * (cx[a] - (p0[a] + p1[a] + p2[a]) / 3) for a in range(3)) > 0
        out.append(inn / len(tris))
    return out


def check_pob(path: str | Path, export_root: str | Path) -> dict[str, Any]:
    root = Path(export_root)
    data_root = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
    pob = iff.read_pob(path)
    s = iff.summarize_pob(pob, root)
    issues: list[dict[str, str]] = []
    for msg in s["issues"]:
        _issue(issues, "error", "portal-facing" if "inverted" in msg else "portals", msg)
    for c in pob["cells"]:
        i = c["index"]
        if i > 0 and not c["lights"]:
            _issue(issues, "warn", "cell-lights", f"r{i} has no lights (renders black)")
        apt = root / c["appearance"] if c["appearance"] else None
        if apt and apt.exists():
            stem = Path(c["appearance"]).stem
            msh = root / "appearance/mesh" / f"{stem}.msh"
            if msh.exists():
                tag = _collision_extent_tag(msh)
                if tag not in (None, "NULL"):
                    _issue(issues, "error", "collision-none", f"r{i} mesh has a {tag} collision extent (export with -collision none)")
                if i > 0:
                    dark = _prelit_without_color(msh, [root, data_root])
                    if dark:
                        _issue(issues, "error", "prelit-vertex-colors",
                               f"r{i}: prelit shaders without color0 render black: {', '.join(Path(d).stem for d in dark[:4])}")
        fp = root / c["floor"] if c["floor"] else None
        if fp and fp.exists():
            seams = iff.floor_seam_edges(fp)
            if seams:
                _issue(issues, "error", "floor-seams", f"r{i}: {len(seams)} blocking floor edges where the floor goes on "
                       "(welded seams stop the player mid-room; iff.open_floor_seams)")
        if i == 0:
            if c["appearance"] and not (root / "appearance/lod" / f"{Path(c['appearance']).stem}.lod").exists():
                _issue(issues, "warn", "radar-lod", "r0 has no exterior .lod: the building has no overhead-map shape")
            fp = root / c["floor"] if c["floor"] else None
            if fp and fp.exists():
                rep = iff.floor_report(iff.read_flr(fp))
                if rep["crossable_edges"] == 0:
                    _issue(issues, "error", "r0-crossable", "r0 floor has no crossable edges: the player cannot step onto it")
                ys = [v[1] for v in iff.read_flr(fp)["vertices"]]
                if ys and abs(max(ys)) > 0.5 and abs(min(ys)) > 0.5:
                    _issue(issues, "warn", "ground-y0", f"r0 floor spans y {min(ys):.2f}..{max(ys):.2f}; ground should be y 0")
    facing = _cmsh_facing_in(path)
    if facing and sum(facing) / len(facing) > 0.5:
        _issue(issues, "error", "collision-facing",
               f"cell collision faces out of the rooms ({sum(facing) / len(facing):.2f} of triangles face in, stock "
               "~0.1): the camera passes through walls (re-export with the current exportPob)")
    windows = sum(1 for c in pob["cells"] for p in c["portals"] if not p["passable"] and p["target_cell"] == 0)
    name = Path(path).stem
    tpl = root / f"object/building/titan/shared_{name}.iff"
    if not tpl.exists():       # a template elsewhere (e.g. overriding a stock one) that points at this .pob
        pob_rel = f"appearance/{name}.pob"
        tpl = next((t for t in root.glob("object/building/*/*.iff")
                    if iff.template_strings(t).get("portalLayoutFilename") == pob_rel), tpl)
    if not tpl.exists():
        _issue(issues, "info", "template", f"no template {tpl.relative_to(root)} (swg_building_template)")
    else:
        params = iff.template_strings(tpl)
        for key in ("terrainModificationFileName", "structureFootprintFileName"):
            if not params.get(key):
                _issue(issues, "warn", "template", f"template has no {key}")
    return {"path": str(path), "cells": len(pob["cells"]), "portals": pob["portal_count"], "window_portals": windows,
            "issues": issues}


BODY_ZONES = ["skull", "face", "neck", "sideburn_l", "sideburn_r", "chest", "torso_f", "torso_b", "waist_f",
              "waist_b", "r_arm", "r_forearm", "l_arm", "l_forearm", "r_hand", "l_hand", "r_thigh", "r_shin",
              "r_foot", "l_thigh", "l_shin", "l_foot"]


def _resolve(rel: str, export_root: str | Path) -> Path | None:
    data = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
    for base in (Path(export_root), data):
        if (base / rel).exists():
            return base / rel
    return None


def check_mgn(path: str | Path, export_root: str | Path, skeletons: list[str] | None = None) -> dict[str, Any]:
    from . import wearable
    data = Path(path).read_bytes()
    issues: list[dict[str, str]] = []
    m = wearable.read_mgn(data)
    if wearable.write_mgn(m) != data:
        _issue(issues, "error", "skmg-0004", "does not read back byte-identically (malformed SKMG)")
    joints: set[str] = set()
    for skt in m["skeletons"]:
        f = _resolve(skt, export_root)
        if f is None:
            _issue(issues, "error", "skmg-0004", f"skeleton {skt} not found")
        else:
            joints |= set(wearable.skeleton_joints(f))
    if skeletons is not None and [s.lower() for s in m["skeletons"]] != [s.lower() for s in skeletons]:
        _issue(issues, "warn", "skmg-0004", f"SKTM {m['skeletons']} differs from the .sat skeletons {skeletons}")
    if joints:
        foreign = sorted({t for t in m["transforms"] if t.lower() not in joints})
        if foreign:
            _issue(issues, "error", "skmg-0004", f"transforms not in the skeleton: {foreign}")
    nx, npos, nn = len(m["transforms"]), len(m["positions"]), len(m["normals"])
    bad = [i for i, vw in enumerate(m["weights"]) if not vw or abs(sum(w for _, w in vw) - 1) > 0.01
           or any(not 0 <= j < nx for j, _ in vw)]
    if bad:
        _issue(issues, "error", "skmg-0004", f"{len(bad)} vertices with missing, unnormalised or out-of-range weights")
    many = sum(1 for vw in m["weights"] if len(vw) > 4)
    if many:
        _issue(issues, "warn", "skmg-0004", f"{many} vertices with more than 4 weights")
    zones = m["occlusion_zones"]
    unknown = [z for z in zones if z not in BODY_ZONES]
    if unknown:
        _issue(issues, "warn", "occlusion", f"zones the human body does not have: {unknown}")
    zero = tris = 0
    for s in m["shaders"]:
        nv = len(s["pidx"])
        if any(not 0 <= i < npos for i in s["pidx"]) or (s["nidx"] and any(not 0 <= i < nn for i in s["nidx"])):
            _issue(issues, "error", "skmg-0004", f"{s['name']}: position or normal index out of range")
        if not _resolve(s["name"], export_root):
            _issue(issues, "error", "skmg-0004", f"shader {s['name']} not found")
        for prim in s["prims"]:
            for t in prim["tris"]:
                tris += 1
                if any(not 0 <= i < nv for i in t[1:]):
                    _issue(issues, "error", "skmg-0004", f"{s['name']}: triangle index out of range")
                    break
                # -1 = never occluded (SkeletalMeshGeneratorTemplate skips the test); stock player heads use it
                if prim["type"] == "OITL" and not -1 <= t[0] < len(m["zone_combinations"]):
                    _issue(issues, "error", "occlusion", f"{s['name']}: OITL zone combination {t[0]} out of range")
                    break
                a, b, c = (m["positions"][s["pidx"][i]] for i in t[1:])
                u = [a[k] - c[k] for k in range(3)]
                v = [b[k] - a[k] for k in range(3)]
                zero += (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]) == (0.0, 0.0, 0.0)
    if zero:
        _issue(issues, "warn", "skmg-0004", f"{zero} zero-area triangles (the engine drops them)")
    if m["zones_this_occludes"] and m["fully_occluded"] is None:
        _issue(issues, "warn", "occlusion", "occludes zones but has no fully-occluded set")
    return {"path": str(path), "positions": npos, "triangles": tris, "transforms": nx, "layer": m["occlusion_layer"],
            "zones": zones, "occludes": [zones[i] for i in m["zones_this_occludes"]],
            "blend_targets": [t["name"] for t in m["blend_targets"]], "issues": issues}


def check_sat(path: str | Path, export_root: str | Path) -> dict[str, Any]:
    from . import wearable
    issues: list[dict[str, str]] = []
    sat = wearable.read_sat(path)
    skeletons = [s for s, _ in sat.get("skeletons", [])]
    meshes = []
    for gen in sat.get("mesh_generators", []):
        f = _resolve(gen, export_root)
        if f is None:
            _issue(issues, "error", "appearance-chain", f"{gen} not found")
            continue
        for rel in (wearable.read_lmg(f) if gen.endswith(".lmg") else [gen]):
            mf = _resolve(rel, export_root)
            if mf is None:
                _issue(issues, "error", "appearance-chain", f"{rel} not found")
                continue
            r = check_mgn(mf, export_root, skeletons)
            for i in r["issues"]:
                _issue(issues, i["level"], i["rule"], f"{rel}: {i['message']}")
            meshes.append({k: r[k] for k in ("path", "positions", "triangles", "layer", "zones", "occludes",
                                             "blend_targets")})
    return {"path": str(path), "skeletons": skeletons, "meshes": meshes, "issues": issues}


def check(path: str | Path, export_root: str | Path) -> dict[str, Any]:
    p = Path(path)
    ext = p.suffix.lower()
    if ext == ".ans":
        out = check_ans(p)
    elif ext == ".pob":
        out = check_pob(p, export_root)
    elif ext == ".flr":
        rep = iff.floor_report(iff.read_flr(p))
        out = {"path": str(p), "issues": [{"level": "error", "rule": "floor", "message": m} for m in rep["problems"]]}
        seams = iff.floor_seam_edges(p)
        if seams:
            out["issues"].append({"level": "error", "rule": "floor-seams",
                                  "message": f"{len(seams)} blocking edges where the floor goes on (iff.open_floor_seams)"})
    elif ext == ".sat":
        out = check_sat(p, export_root)
    elif ext == ".mgn":
        out = check_mgn(p, export_root)
    else:
        raise ValueError(f"no rail checks for {ext} files (supported: .pob, .ans, .flr, .sat, .mgn)")
    out["ok"] = not any(i["level"] == "error" for i in out["issues"])
    return out
