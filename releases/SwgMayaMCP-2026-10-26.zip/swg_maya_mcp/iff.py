"""Pure-Python readers for SWG IFF assets used by the POB tools (.pob portal objects, .flr floors).

No Maya required: the MCP server uses these to inspect files on disk and to verify exports.
Coordinates are returned in engine space (left-handed; Maya X = -engine X).
"""

from __future__ import annotations

import copy
import hashlib
import math
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Block:
    tag: str                      # chunk tag, or the form's name for forms
    is_form: bool
    data: bytes = b""             # chunk payload; for forms the whole block, header included
    children: list["Block"] = field(default_factory=list)

    def forms(self, name: str | None = None) -> list["Block"]:
        return [c for c in self.children if c.is_form and (name is None or c.tag == name)]

    def chunks(self, name: str | None = None) -> list["Block"]:
        return [c for c in self.children if not c.is_form and (name is None or c.tag == name)]

    def first(self, name: str) -> "Block | None":
        return next((c for c in self.children if c.tag == name), None)


def parse_iff(data: bytes) -> Block:
    """Parse an IFF byte string into a block tree; returns a synthetic root form."""

    def walk(pos: int, end: int, out: list[Block]) -> None:
        while pos + 8 <= end:
            tag = data[pos:pos + 4].decode("latin1")
            length = struct.unpack(">I", data[pos + 4:pos + 8])[0]
            body_end = pos + 8 + length
            if body_end > end:
                raise ValueError(f"IFF block {tag!r} at {pos} overruns its parent ({body_end} > {end})")
            if tag == "FORM":
                form = Block(data[pos + 8:pos + 12].decode("latin1"), True, data[pos:body_end])
                walk(pos + 12, body_end, form.children)
                out.append(form)
            else:
                out.append(Block(tag, False, data[pos + 8:body_end]))
            pos = body_end

    root = Block("<root>", True)
    walk(0, len(data), root.children)
    return root


class Reader:
    """Little-endian cursor over a chunk payload (SWG chunk data is little-endian)."""

    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def left(self) -> int:
        return len(self.data) - self.pos

    def i8(self) -> int:
        v = struct.unpack_from("<b", self.data, self.pos)[0]
        self.pos += 1
        return v

    def u8(self) -> int:
        v = self.data[self.pos]
        self.pos += 1
        return v

    def i16(self) -> int:
        v = struct.unpack_from("<h", self.data, self.pos)[0]
        self.pos += 2
        return v

    def i32(self) -> int:
        v = struct.unpack_from("<i", self.data, self.pos)[0]
        self.pos += 4
        return v

    def f32(self) -> float:
        v = struct.unpack_from("<f", self.data, self.pos)[0]
        self.pos += 4
        return v

    def vec(self) -> tuple[float, float, float]:
        v = struct.unpack_from("<3f", self.data, self.pos)
        self.pos += 12
        return v

    def string(self) -> str:
        end = self.data.index(b"\0", self.pos)
        s = self.data[self.pos:end].decode("latin1")
        self.pos = end + 1
        return s

    def transform(self) -> list[list[float]]:
        """3x4 row-major float transform."""
        vals = struct.unpack_from("<12f", self.data, self.pos)
        self.pos += 48
        return [list(vals[0:4]), list(vals[4:8]), list(vals[8:12])]


# ----------------------------------------------------------------------------
# POB (FORM PRTO)
# ----------------------------------------------------------------------------

def _version(tag: str) -> int:
    return int(tag) if tag.isdigit() else -1


def _read_portal_geometry(block: Block) -> dict[str, Any]:
    if block.is_form and block.tag == "IDTL":
        ver = block.forms()[0]
        verts_raw = ver.first("VERT").data
        idx_raw = ver.first("INDX").data
        verts = [struct.unpack_from("<3f", verts_raw, i) for i in range(0, len(verts_raw) - 11, 12)]
        indices = list(struct.unpack_from(f"<{len(idx_raw) // 4}i", idx_raw, 0))
        return {"vertices": [list(v) for v in verts], "indices": indices}
    # pre-v4: PRTL chunk = int32 count + verts (convex polygon, fan-triangulated)
    r = Reader(block.data)
    n = r.i32()
    verts = [list(r.vec()) for _ in range(n)]
    indices = [i for t in range(1, n - 1) for i in (0, t, t + 1)]
    return {"vertices": verts, "indices": indices}


def _read_cell_portal(chunk: Block) -> dict[str, Any]:
    v = _version(chunk.tag)
    r = Reader(chunk.data)
    p: dict[str, Any] = {"disabled": False, "passable": True, "door_style": "", "door_hardpoint": None}
    if v >= 5:
        p["disabled"] = bool(r.u8())
    if v >= 2:
        p["passable"] = bool(r.u8())
    p["portal_index"] = r.i32()
    p["clockwise"] = bool(r.u8())
    p["target_cell"] = r.i32()
    if v >= 3:
        p["door_style"] = r.string()
    if v >= 4:
        has_hp = bool(r.u8())
        t = r.transform()
        p["door_hardpoint"] = t if has_hp else None
    return p


def _read_lights(chunk: Block) -> list[dict[str, Any]]:
    r = Reader(chunk.data)
    lights = []
    for _ in range(r.i32()):
        typ = r.i8()
        diffuse = [r.f32() for _ in range(4)]
        specular = [r.f32() for _ in range(4)]
        xf = r.transform()
        lights.append({
            "type": {0: "ambient", 1: "parallel", 2: "point"}.get(typ, typ),
            "diffuse_argb": diffuse,
            "specular_argb": specular,
            "position": [xf[0][3], xf[1][3], xf[2][3]],
            "attenuation": [r.f32(), r.f32(), r.f32()],
        })
    return lights


def read_pob(path: str | Path) -> dict[str, Any]:
    root = parse_iff(Path(path).read_bytes())
    prto = root.forms("PRTO")
    if not prto:
        raise ValueError(f"{path}: not a portal object (no FORM PRTO)")
    ver_form = prto[0].forms()[0]
    version = _version(ver_form.tag)
    r = Reader(ver_form.first("DATA").data)
    n_portals, n_cells = r.i32(), r.i32()

    prts = ver_form.first("PRTS")
    portals = [_read_portal_geometry(b) for b in (prts.children if prts else [])]

    cells = []
    cels = ver_form.first("CELS")
    for i, cell_form in enumerate(cels.forms("CELL") if cels else []):
        cver = cell_form.forms()[0]
        cv = _version(cver.tag)
        r = Reader(cver.first("DATA").data)
        cell: dict[str, Any] = {"index": i}
        n_cell_portals = r.i32()
        cell["can_see_world"] = bool(r.u8())
        cell["name"] = r.string() if cv >= 4 else f"cell_{i}"  # PortalPropertyTemplateCell::load_0004+
        cell["appearance"] = r.string()
        cell["floor"] = (r.string() if r.u8() else "") if cv >= 2 else ""
        cell["portals"] = []
        for b in cver.children:
            if b.is_form and b.tag == "PRTL":
                cell["portals"].extend(_read_cell_portal(c) for c in b.chunks())
            elif not b.is_form and b.tag == "PRTL":
                cell["portals"].append(_read_cell_portal(Block(b.tag, False, b.data)))
        cell["declared_portal_count"] = n_cell_portals
        extent = next((b for b in cver.children if b.is_form and b.tag != "PRTL"), None) if cv >= 5 else None
        cell["collision_extent"] = None if extent is None or extent.tag == "NULL" else {
            "type": extent.tag, "bytes": len(extent.data), "sha1": hashlib.sha1(extent.data).hexdigest()}
        lght = cver.first("LGHT")
        cell["lights"] = _read_lights(lght) if lght is not None else []
        cells.append(cell)

    crc = ver_form.first("CRC ")
    return {
        "path": str(path),
        "version": version,
        "portal_count": n_portals,
        "cell_count": n_cells,
        "portals": portals,
        "cells": cells,
        "crc": struct.unpack("<I", crc.data)[0] if crc is not None and len(crc.data) == 4 else None,
    }


# ----------------------------------------------------------------------------
# FLR (FORM FLOR) — v0006 fully; older versions return vertices only
# ----------------------------------------------------------------------------

def read_flr(path: str | Path) -> dict[str, Any]:
    root = parse_iff(Path(path).read_bytes())
    flor = root.forms("FLOR")
    if not flor:
        raise ValueError(f"{path}: not a floor (no FORM FLOR)")
    ver_form = flor[0].forms()[0]
    version = _version(ver_form.tag)
    out: dict[str, Any] = {"path": str(path), "version": version, "vertices": [], "tris": []}
    vert = ver_form.first("VERT")
    out["blocks"] = [b.tag for b in ver_form.children]
    if version == 6:
        r = Reader(vert.data)
        out["vertices"] = [list(r.vec()) for _ in range(r.i32())]
        r = Reader(ver_form.first("TRIS").data)
        for _ in range(r.i32()):
            corners = [r.i32(), r.i32(), r.i32()]
            index = r.i32()
            neighbors = [r.i32(), r.i32(), r.i32()]
            normal = list(r.vec())
            edge_types = [r.u8(), r.u8(), r.u8()]
            fallthrough = bool(r.u8())
            part = r.i32()
            portal_ids = [r.i32(), r.i32(), r.i32()]
            out["tris"].append({
                "corners": corners, "index": index, "neighbors": neighbors, "normal": normal,
                "edge_types": edge_types, "fallthrough": fallthrough, "part": part, "portal_ids": portal_ids,
            })
        bedg = ver_form.first("BEDG")
        if bedg is not None:
            r = Reader(bedg.data)
            out["boundary_edges"] = []
            for _ in range(r.i32()):
                tri, edge = r.i32(), r.i32()
                r.u8()
                out["boundary_edges"].append((tri, edge))
    elif vert is not None:
        out["vertices"] = [list(v) for v in struct.iter_unpack("<3f", vert.data[: len(vert.data) // 12 * 12])]
    return out


def floor_report(flr: dict[str, Any]) -> dict[str, Any]:
    """Consistency checks matching what the engine's FloorMesh expects from a compiled floor."""
    tris = flr["tris"]
    verts = flr["vertices"]
    problems: list[str] = []
    asym = 0
    up = down = 0
    for i, t in enumerate(tris):
        if t["index"] != i:
            problems.append(f"tri {i}: stored index {t['index']}")
        for k in range(3):
            n = t["neighbors"][k]
            if n >= 0:
                if t["edge_types"][k] != 1:
                    problems.append(f"tri {i} edge {k}: has neighbour but edge type {t['edge_types'][k]}")
                if i not in tris[n]["neighbors"]:
                    asym += 1
        a, b, c = (verts[j] for j in t["corners"])
        cy = (b[2] - a[2]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[2] - a[2])
        up += cy > 0
        down += cy < 0
    if asym:
        problems.append(f"{asym} non-reciprocal neighbour link(s)")
    # FloorMesh::read_0006 peeks a block after TRIS without an end-of-form check: BEDG must be there
    blocks = flr.get("blocks", [])
    if flr.get("version") == 6 and blocks[blocks.index("TRIS") + 1:2 + blocks.index("TRIS")] not in (["BTRE"], ["BEDG"]):
        problems.append(f"no BTRE/BEDG after TRIS (blocks {blocks}): the client's FloorMesh::read_0006 overflows")
    expected = {(i, k) for i, t in enumerate(tris) for k in range(3) if t["neighbors"][k] < 0}
    if "boundary_edges" in flr and set(flr["boundary_edges"]) != expected:
        problems.append("BEDG does not list exactly the boundary edges")
    portal_edges: dict[str, int] = {}
    for t in tris:
        for pid in t["portal_ids"]:
            if pid >= 0:
                portal_edges[str(pid)] = portal_edges.get(str(pid), 0) + 1
    return {
        "vertices": len(verts),
        "tris": len(tris),
        "parts": len({t["part"] for t in tris}),
        "crossable_edges": sum(et == 1 for t in tris for et in t["edge_types"]),
        "boundary_edges": sum(n < 0 for t in tris for n in t["neighbors"]),
        "portal_edges_by_portal": portal_edges,
        "upward_tris": up,
        "downward_tris": down,
        "problems": problems[:50],
    }


def portal_facing_issues(pob: dict[str, Any], floor_root: str | Path | None) -> list[str]:
    """Stock convention (all 642 shipped .pob files): the clockwise cell lies on the front of
    n = cross(v1-v0, v2-v0). Portal::testPenetration relies on it; inverted doors capture the camera/player
    in the wrong cell. Needs the cells' .flr files to locate rooms; skipped when they are not found."""
    if floor_root is None:
        return []
    # per cell: centroids of its floor triangles (what lies right behind a doorway decides the side)
    centres: dict[int, list[list[float]]] = {}
    for c in pob["cells"]:
        fp = Path(floor_root) / c["floor"] if c["floor"] else None
        if fp and fp.exists():
            flr = read_flr(fp)
            v = flr["vertices"]
            if flr["tris"]:
                centres[c["index"]] = [[sum(v[j][k] for j in t["corners"]) / 3 for k in range(3)] for t in flr["tris"]]
            elif v:
                centres[c["index"]] = [v_ for v_ in v]
    # Test the interior side of each portal: exterior (r0) floors wrap around buildings and say nothing.
    # The clockwise cell must be in front; the counter-clockwise cell behind.
    out = []
    for c in pob["cells"]:
        for p in c["portals"]:
            i = p["portal_index"]
            if c["index"] == 0 or c["index"] not in centres or i >= len(pob["portals"]):
                continue
            expect_front = p["clockwise"]
            g = pob["portals"][i]
            if len(g["indices"]) < 3:
                continue
            a, b, d = (g["vertices"][j] for j in g["indices"][:3])
            e1 = [b[k] - a[k] for k in range(3)]
            e2 = [d[k] - a[k] for k in range(3)]
            n = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]]
            nl = math.sqrt(sum(x * x for x in n)) or 1.0
            if abs(n[1]) > 0.7 * nl:
                continue        # a horizontal portal (a floor hatch): the floors round it lie beside it, not behind
            mid = [sum(g["vertices"][j][k] for j in g["indices"][:3]) / 3 for k in range(3)]
            near = sorted(centres[c["index"]], key=lambda q: sum((q[k] - mid[k]) ** 2 for k in range(3)))[:6]
            sides = [sum(n[k] * (q[k] - a[k]) for k in range(3)) / nl for q in near]
            sides = [x for x in sides if abs(x) > 0.05]
            wrong = sum((x < 0) if expect_front else (x > 0) for x in sides)
            if sides and wrong > len(sides) / 2:
                out.append(f"portal {i}: looks inverted relative to cell r{c['index']} (clockwise={bool(expect_front)}); "
                           f"Portal::testPenetration will move the camera/player into the wrong cell")
    return out


def summarize_pob(pob: dict[str, Any], floor_root: str | Path | None = None) -> dict[str, Any]:
    """Compact, model-friendly view of read_pob() output plus pairing checks."""
    pairs: dict[int, list[tuple[int, bool, int]]] = {}
    for cell in pob["cells"]:
        for p in cell["portals"]:
            pairs.setdefault(p["portal_index"], []).append((cell["index"], p["clockwise"], p["target_cell"]))
    issues = []
    for idx, sides in sorted(pairs.items()):
        if len(sides) != 2:
            issues.append(f"portal {idx}: referenced by {len(sides)} cell(s), expected 2")
        elif sides[0][1] == sides[1][1]:
            issues.append(f"portal {idx}: both sides have clockwise={sides[0][1]}")
    for idx, geom in enumerate(pob["portals"]):
        if len(geom["vertices"]) < 3 or not any(any(abs(c) > 1e-6 for c in v) for v in geom["vertices"]):
            issues.append(f"portal {idx}: degenerate geometry")
    issues += portal_facing_issues(pob, floor_root)

    def bounds(vs):
        if not vs:
            return None
        return [[round(min(v[k] for v in vs), 3) for k in range(3)], [round(max(v[k] for v in vs), 3) for k in range(3)]]

    return {
        "path": pob["path"],
        "version": pob["version"],
        "portal_count": pob["portal_count"],
        "cell_count": pob["cell_count"],
        "portals": [{"index": i, "vertex_count": len(g["vertices"]), "bounds": bounds(g["vertices"])}
                    for i, g in enumerate(pob["portals"])],
        "cells": [{
            "index": c["index"], "name": c["name"], "can_see_world": c["can_see_world"],
            "appearance": c["appearance"], "floor": c["floor"], "light_count": len(c["lights"]),
            "collision_extent": (c.get("collision_extent") or {}).get("type"),
            "portals": [{k: p[k] for k in ("portal_index", "clockwise", "target_cell", "passable", "disabled", "door_style")}
                        for p in c["portals"]],
        } for c in pob["cells"]],
        "issues": issues,
    }


# ----------------------------------------------------------------------------
# Plan view
# ----------------------------------------------------------------------------

_PLAN_COLORS = ["#c9b79c", "#9fb4c7", "#b7a3c4", "#a8c49d", "#d4c38f", "#c79f9f", "#9fc7c0", "#c4b49d"]


def floorplan_svg(pob: dict[str, Any], data_root: str | Path, scale: float = 24.0) -> tuple[str, dict[str, Any]]:
    """Top-down SVG of every cell floor (.flr), portal (door) and point light, in Maya orientation
    (x right, -z up the page). Returns (svg_text, stats)."""
    data_root = Path(data_root)
    floors: list[tuple[int, list[list[tuple[float, float]]], tuple[float, float]]] = []
    xs: list[float] = []
    zs: list[float] = []
    missing = []
    for cell in pob["cells"]:
        if not cell["floor"]:
            continue
        fp = data_root / cell["floor"]
        if not fp.exists():
            missing.append(cell["floor"])
            continue
        flr = read_flr(fp)
        v = [(-p[0], p[2]) for p in flr["vertices"]]  # engine -> Maya x
        tris = [[v[i] for i in t["corners"]] for t in flr["tris"]]
        if not tris:
            continue
        cx = sum(p[0] for p in v) / len(v)
        cz = sum(p[1] for p in v) / len(v)
        floors.append((cell["index"], tris, (cx, cz)))
        xs += [p[0] for p in v]
        zs += [p[1] for p in v]
    doors = []
    for i, g in enumerate(pob["portals"]):
        pts = [(-p[0], p[2]) for p in g["vertices"]]
        if len(pts) < 2:
            continue
        # plan footprint of a vertical portal = its two most distant points
        a, b = max(((p, q) for p in pts for q in pts), key=lambda pq: (pq[0][0] - pq[1][0]) ** 2 + (pq[0][1] - pq[1][1]) ** 2)
        doors.append((i, a, b))
        xs += [a[0], b[0]]
        zs += [a[1], b[1]]
    lights = [((-L["position"][0], L["position"][2]), c["index"]) for c in pob["cells"] for L in c["lights"] if L["type"] == "point"]
    if not xs:
        raise ValueError("no floors or portals to draw (are the .flr files under data_root?)")
    pad = 1.5
    x0, x1, z0, z1 = min(xs) - pad, max(xs) + pad, min(zs) - pad, max(zs) + pad
    w, h = (x1 - x0) * scale, (z1 - z0) * scale

    def P(p):
        return f"{(p[0] - x0) * scale:.1f},{(p[1] - z0) * scale:.1f}"

    out = ['<?xml version="1.0" encoding="UTF-8"?>', f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:.0f}" height="{h + 28:.0f}" viewBox="0 -28 {w:.0f} {h + 28:.0f}" '
           f'font-family="Segoe UI, sans-serif" font-size="12">',
           f'<rect x="0" y="-28" width="{w:.0f}" height="{h + 28:.0f}" fill="#1e1f24"/>',
           f'<text x="8" y="-9" fill="#e8e8e8" font-size="14">{Path(pob["path"]).name} — {pob["cell_count"]} cells, '
           f'{pob["portal_count"]} portals (plan view, 1 grid = 1 m)</text>']
    for gx in range(int(x0), int(x1) + 1):
        out.append(f'<line x1="{(gx - x0) * scale:.1f}" y1="0" x2="{(gx - x0) * scale:.1f}" y2="{h:.1f}" stroke="#2b2d33"/>')
    for gz in range(int(z0), int(z1) + 1):
        out.append(f'<line x1="0" y1="{(gz - z0) * scale:.1f}" x2="{w:.1f}" y2="{(gz - z0) * scale:.1f}" stroke="#2b2d33"/>')
    for idx, tris, _ in floors:
        col = _PLAN_COLORS[idx % len(_PLAN_COLORS)]
        for t in tris:
            out.append(f'<polygon points="{" ".join(P(p) for p in t)}" fill="{col}" fill-opacity="0.85" stroke="#00000040" stroke-width="0.6"/>')
    for i, a, b in doors:
        out.append(f'<line x1="{P(a).split(",")[0]}" y1="{P(a).split(",")[1]}" x2="{P(b).split(",")[0]}" y2="{P(b).split(",")[1]}" '
                   f'stroke="#ff7a3d" stroke-width="5" stroke-linecap="round"/>')
        m = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        out.append(f'<text x="{(m[0] - x0) * scale + 6:.1f}" y="{(m[1] - z0) * scale - 6:.1f}" fill="#ffb08a">p{i}</text>')
    for p, _ in lights:
        out.append(f'<circle cx="{(p[0] - x0) * scale:.1f}" cy="{(p[1] - z0) * scale:.1f}" r="4" fill="#ffe680" stroke="#000" stroke-width="0.8"/>')
    names = {c["index"]: c["name"] for c in pob["cells"]}
    for idx, _, (cx, cz) in floors:
        out.append(f'<text x="{(cx - x0) * scale:.1f}" y="{(cz - z0) * scale:.1f}" fill="#111" text-anchor="middle" '
                   f'font-weight="600">r{idx} {names.get(idx, "")}</text>')
    out.append("</svg>")
    return "\n".join(out), {"floors_drawn": len(floors), "doors_drawn": len(doors), "point_lights": len(lights),
                            "missing_floors": missing}


# ----------------------------------------------------------------------------
# MSH (static mesh appearance) summary
# ----------------------------------------------------------------------------

def read_msh_summary(path: str | Path) -> dict[str, Any]:
    """Shader slots, hardpoint names and extent box of an exported static mesh."""
    root = parse_iff(Path(path).read_bytes())

    def find(block, tag):
        for c in block.children:
            if c.tag == tag:
                yield c
            if c.is_form:
                yield from find(c, tag)

    slots, shaders = 0, []
    for sps in find(root, "SPS "):
        ver = sps.forms()[0] if sps.forms() else None
        if ver is not None:
            for prim in ver.forms():
                slots += 1
                name = prim.first("NAME")
                if name is not None:
                    shaders.append(name.data.split(b"\0")[0].decode("latin1"))
    hardpoints = []
    for hp in find(root, "HPNT"):
        r = Reader(hp.data)
        r.transform()
        hardpoints.append(r.string())
    box = next(find(root, "BOX "), None)
    return {"path": str(path), "shader_slots": slots, "shaders": shaders, "hardpoints": hardpoints,
            "box": list(struct.unpack("<6f", box.data)) if box is not None and len(box.data) == 24 else None}


def shader_texcoord_sets(sht_path: str | Path) -> dict[str, int]:
    """A shader's TCSS: texture tag (MAIN, DETA, DOT3, NRML, SPEC ...) -> the vertex texture-coordinate set it reads."""
    sets: dict[str, int] = {}
    stack = [parse_iff(Path(sht_path).read_bytes())]
    while stack:
        b = stack.pop()
        for c in b.children:
            if c.is_form and c.tag == "TCSS" and c.children:
                d = c.children[0].data
                for i in range(0, len(d) - 4, 5):
                    sets[d[i:i + 4][::-1].decode("latin1")] = d[i + 4]
            elif c.is_form:
                stack.append(c)
    return sets


def audit_texcoord_sets(msh_path: str | Path, shader_roots: list[str | Path]) -> list[dict[str, Any]]:
    """Shader primitives of a static mesh whose shader's TCSS reads a texture-coordinate set the vertices don't
    have (they sample garbage: black-blotched bump maps, smeared detail). Empty when the mesh is sound."""
    out = []
    root = parse_iff(Path(msh_path).read_bytes())
    stack = [root]
    while stack:
        b = stack.pop()
        for c in b.children:
            if c.is_form:
                stack.append(c)
        if not (b.is_form and b.tag == "SPS "):
            continue
        for ver in b.forms():
            for prim in ver.forms():
                name = prim.first("NAME")
                rel = name.data.split(b"\0")[0].decode("latin1").replace("\\", "/") if name is not None else ""
                sht = next((Path(r) / rel for r in shader_roots if (Path(r) / rel).exists()), None)
                tcss = shader_texcoord_sets(sht) if sht else {}
                for geo in prim.forms():
                    vtxa = geo.first("VTXA")
                    if vtxa is None or not vtxa.forms() or not tcss:
                        continue
                    flags = struct.unpack("<I", vtxa.forms()[0].first("INFO").data[:4])[0]
                    have, need = (flags >> 8) & 0xF, max(tcss.values()) + 1
                    if have < need:
                        out.append({"shader": rel, "sets": have, "needed": need, "tcss": tcss})
    return out


DETAIL_UV_SCALE = 4.0          # stock detail sets (DETA): exactly 4x the base UVs in the corvette interiors, ~5x on hulls


def fill_texcoord_sets(msh_path: str | Path, shader_roots: list[str | Path]) -> dict[str, Any]:
    """Give every shader primitive of a static mesh the texture-coordinate sets its shader's TCSS reads. The Maya
    exporter writes one 2D set; bump-mapped shaders (a_specmap_cbmp*, *_hue twins: DOT3 at set 1 or 2) and detail
    shaders (DETA at set 1) then sample sets that aren't there and the hull renders black-blotched. Missing DOT3
    sets get per-vertex tangents (+U direction, w = handedness: the stock convention, checked against stock hull
    meshes), other missing sets a copy of the base UVs (DETA scaled by DETAIL_UV_SCALE). Rewrites the file in place
    when anything was added; returns {shader: [old sets, new sets]}."""
    import numpy as np

    def resolve(rel: str) -> Path | None:
        rel = rel.replace("\\", "/")
        for r in shader_roots:
            p = Path(r) / rel
            if p.exists():
                return p
        return None

    root = parse_iff(Path(msh_path).read_bytes())
    changed: dict[str, Any] = {}
    stack = [root]
    while stack:
        b = stack.pop()
        for c in b.children:
            if c.is_form:
                stack.append(c)
        if not (b.is_form and b.tag == "SPS "):
            continue
        for ver in b.forms():
            for prim in ver.forms():
                name = prim.first("NAME")
                sht = resolve(name.data.split(b"\0")[0].decode("latin1")) if name is not None else None
                if sht is None:
                    continue
                tcss = shader_texcoord_sets(sht)
                if not tcss:
                    continue
                wanted = max(tcss.values()) + 1
                dot3 = {s for t, s in tcss.items() if t == "DOT3"}
                base = tcss.get("MAIN", 0)
                for geo in prim.forms():
                    vtxa = geo.first("VTXA")
                    indx = geo.first("INDX")
                    if vtxa is None or indx is None or not vtxa.forms():
                        continue
                    vver = vtxa.forms()[0]
                    info, data = vver.first("INFO"), vver.first("DATA")
                    flags, count = struct.unpack("<II", info.data[:8])
                    have = (flags >> 8) & 0xF
                    if have >= wanted or not (flags & 0x1) or not (flags & 0x4):    # needs position + normal
                        continue
                    dims = [((flags >> (12 + 2 * i)) & 3) + 1 for i in range(have)]
                    head = 6 + (1 if flags & 0x8 else 0) + (1 if flags & 0x10 else 0)     # pos, normal, colours
                    stride = head + sum(dims)
                    v = np.frombuffer(data.data, dtype="<f4").reshape(count, stride).copy()
                    off = [head + sum(dims[:i]) for i in range(have)]
                    P, N = v[:, 0:3], v[:, 3:6]
                    uv = v[:, off[base]:off[base] + 2] if base < have else v[:, off[0]:off[0] + 2]
                    n_idx = struct.unpack("<I", indx.data[:4])[0]
                    width = (len(indx.data) - 4) // max(n_idx, 1)
                    tri = np.frombuffer(indx.data[4:4 + n_idx * width], dtype="<u2" if width == 2 else "<u4")
                    tri = tri.reshape(-1, 3).astype(np.int64)
                    new_sets, new_dims = [], []
                    for s in range(have, wanted):
                        if s in dot3:
                            t = np.zeros_like(P)
                            bt = np.zeros_like(P)
                            p0, p1, p2 = P[tri[:, 0]], P[tri[:, 1]], P[tri[:, 2]]
                            u0, u1, u2 = uv[tri[:, 0]], uv[tri[:, 1]], uv[tri[:, 2]]
                            e1, e2, d1, d2 = p1 - p0, p2 - p0, u1 - u0, u2 - u0
                            det = d1[:, 0] * d2[:, 1] - d2[:, 0] * d1[:, 1]
                            det = np.where(np.abs(det) < 1e-12, 1e-12, det)
                            sdir = (e1 * d2[:, 1:2] - e2 * d1[:, 1:2]) / det[:, None]
                            tdir = (e2 * d1[:, 0:1] - e1 * d2[:, 0:1]) / det[:, None]
                            for k in range(3):
                                np.add.at(t, tri[:, k], sdir)
                                np.add.at(bt, tri[:, k], tdir)
                            t = t - N * np.sum(N * t, 1)[:, None]
                            ln = np.linalg.norm(t, axis=1)
                            # degenerate UVs: any unit vector perpendicular to the normal
                            alt = np.cross(N, np.where(np.abs(N[:, 1:2]) < 0.9, [[0.0, 1.0, 0.0]], [[1.0, 0.0, 0.0]]))
                            t = np.where(ln[:, None] > 1e-6, t / np.maximum(ln, 1e-9)[:, None], alt)
                            t /= np.maximum(np.linalg.norm(t, axis=1), 1e-9)[:, None]
                            w = np.where(np.sum(np.cross(N, t) * bt, 1) < 0.0, -1.0, 1.0)
                            new_sets.append(np.hstack([t, w[:, None]]).astype("<f4"))
                            new_dims.append(4)
                        else:
                            scale = DETAIL_UV_SCALE if tcss.get("DETA") == s else 1.0
                            new_sets.append((uv * scale).astype("<f4"))
                            new_dims.append(2)
                    v = np.hstack([v] + new_sets).astype("<f4")
                    all_dims = dims + new_dims
                    flags = flags & 0xFF
                    flags |= len(all_dims) << 8
                    for i, d in enumerate(all_dims):
                        flags |= (d - 1) << (12 + 2 * i)
                    info.data = struct.pack("<II", flags, count) + info.data[8:]
                    data.data = v.tobytes()
                    changed[name.data.split(b"\0")[0].decode("latin1")] = [dims, all_dims]
    if changed:
        Path(msh_path).write_bytes(serialize_iff(root))
    return changed


# ----------------------------------------------------------------------------
# writing + shared building object templates
# ----------------------------------------------------------------------------

def serialize_iff(block: Block) -> bytes:
    """Inverse of parse_iff (pass the synthetic root or any block)."""
    if block.tag == "<root>":
        return b"".join(serialize_iff(c) for c in block.children)
    if block.is_form:
        body = block.tag.encode("latin1") + b"".join(serialize_iff(c) for c in block.children)
        return b"FORM" + struct.pack(">I", len(body)) + body
    return block.tag.encode("latin1") + struct.pack(">I", len(block.data)) + block.data


def _template_params(root: Block):
    """Every template parameter chunk (XXXX "name\0" + value) in an object template tree."""
    stack = [root]
    while stack:
        b = stack.pop()
        for c in b.children:
            if c.is_form:
                stack.append(c)
            elif c.tag == "XXXX" and b"\0" in c.data:
                yield c


def template_strings(path: str | Path) -> dict[str, str | None]:
    """String-looking parameters of an object template (name -> value, None when unset); the first occurrence
    (the most derived template level) wins."""
    out: dict[str, str | None] = {}
    root = parse_iff(Path(path).read_bytes())
    inner = {id(x) for f in _walk_blocks(root) if f.is_form and f.tag == "PCCV" for x in f.children}
    for c in _template_params(root):
        name, rest = c.data.split(b"\0", 1)
        key = name.decode("latin1")
        if key in out or id(c) in inner:
            continue
        if key == _PCCV:                          # struct list: "var=palette:default, ..." (None when empty)
            out[key] = ", ".join(f"{v['variableName']}={v['palettePathName']}:{v['defaultPaletteIndex']}"
                                 for v in template_palette_vars(path)) or None
            continue
        if not rest or rest[0] not in (0, 1):
            continue
        if rest[:2] == b"\1\1" and rest.count(b"\0") >= 2:      # StringId (objectName ...): 1, 1, table\0, 1, name\0 -> table:name
            table, tail = rest[2:].split(b"\0", 1)
            out[key] = table.decode("latin1") + ":" + tail[1:].split(b"\0", 1)[0].decode("latin1")
            continue
        out[key] = rest[1:].split(b"\0", 1)[0].decode("latin1") if rest[0] == 1 else None
    return out


def building_template(base_template: str | Path, out_path: str | Path, pob: str,
                      strings: dict[str, str | None] | None = None) -> dict[str, Any]:
    """Write a shared building object template (SBOT) derived from a stock one: portalLayoutFilename -> `pob`,
    plus optional string parameter overrides (None clears a parameter, e.g. a stock footprint/client data file
    that does not match the new building)."""
    return derive_template(base_template, out_path, {"portalLayoutFilename": pob, **(strings or {})})


def derive_template(base_template: str | Path, out_path: str | Path,
                    strings: dict[str, str | None], string_ids: dict[str, tuple[str, str] | None] | None = None,
                    palette_vars: list[tuple[str, str, int]] | None = None) -> dict[str, Any]:
    """Write an object template derived from a stock one with string parameters replaced (None clears one).
      string_ids    StringId parameters (objectName, detailedDescription, lookAtText) -> (table, name) or None
      palette_vars  tangible templates: paletteColorCustomizationVariables = [(variableName, palettePathName,
                    defaultPaletteIndex)], e.g. ("/private/index_color_1", "palette/frn_hue.pal", 0) - the
                    customization variables the object gets (CSHD hue shaders read them; /setHue sets them)"""
    root = parse_iff(Path(base_template).read_bytes())
    want = dict(strings)
    ids = dict(string_ids or {})
    done = {}
    for c in _template_params(root):
        name = c.data.split(b"\0", 1)[0].decode("latin1")
        if name in want:
            v = want[name]
            # string parameter: name\0 + 0 (unset) | 1 (set) + value\0
            c.data = name.encode("latin1") + b"\0" + (b"\0" if v is None else b"\1" + v.encode("latin1") + b"\0")
            done[name] = v
        elif name in ids:
            v = ids[name]
            # StringId parameter: name\0 + 0 (unset) | 1 (set) + 1 + table\0 + 1 + name\0
            c.data = name.encode("latin1") + b"\0" + (b"\0" if v is None else
                                                      b"\1\1" + _cstr(v[0]) + b"\1" + _cstr(v[1]))
            done[name] = v
    if palette_vars is not None:
        done["paletteColorCustomizationVariables"] = _set_palette_vars(root, palette_vars)
    missing = sorted((set(want) | set(ids)) - set(done))
    if missing:
        raise ValueError(f"{base_template}: no template parameter(s) {missing}")
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(serialize_iff(root))
    return {"path": str(out), "set": done}


_PCCV = "paletteColorCustomizationVariables"


def _pccv_struct(var: str, palette: str, default: int) -> Block:
    """One paletteColorCustomizationVariables entry as the TemplateCompiler writes it: FORM PCCV {PCNT 3, the three
    parameters}."""
    return _form("PCCV", [_chunk("PCNT", struct.pack("<i", 3)),
                          _chunk("XXXX", b"variableName\0\1" + _cstr(var)),
                          _chunk("XXXX", b"palettePathName\0\1" + _cstr(palette)),
                          _chunk("XXXX", b"defaultPaletteIndex\0\1 " + struct.pack("<i", int(default)))])


def _set_palette_vars(root: Block, palette_vars: list[tuple[str, str, int]]) -> list:
    """Replace the most derived paletteColorCustomizationVariables parameter. A struct list is stored as
    XXXX{name, append flag, count, (1, 'PCCV')} FORM PCCV XXXX{1, 'PCCV'} FORM PCCV ... XXXX{} - the loader leaves
    the chunk for each struct form and enters a fake chunk after it."""
    stack = [root]
    while stack:
        b = stack.pop(0)
        for i, c in enumerate(b.children):
            if c.is_form:
                stack.append(c)
                continue
            if not (c.tag == "XXXX" and c.data.startswith(_PCCV.encode() + b"\0")):
                continue
            j = i + 1                                   # drop the old list's struct forms and continuation chunks
            while j < len(b.children) and ((b.children[j].is_form and b.children[j].tag == "PCCV") or
                                           (not b.children[j].is_form and b.children[j].tag == "XXXX" and
                                            b.children[j].data in (b"", b"\1" + _stag("PCCV")))):
                j += 1
            n = len(palette_vars)
            head = _PCCV.encode() + b"\0" + b"\0" + struct.pack("<i", n)        # append = false
            new = [_chunk("XXXX", head + (b"\1" + _stag("PCCV") if n else b""))]
            for k, (var, pal, default) in enumerate(palette_vars):
                new.append(_pccv_struct(var, pal, default))
                new.append(_chunk("XXXX", b"\1" + _stag("PCCV") if k + 1 < n else b""))
            b.children[i:j] = new
            return [list(v) for v in palette_vars]
    raise ValueError(f"template has no {_PCCV} parameter (not a tangible template?)")


def template_palette_vars(path: str | Path) -> list[dict[str, Any]]:
    """paletteColorCustomizationVariables of the most derived level that sets them: [{variableName,
    palettePathName, defaultPaletteIndex}]."""
    root = parse_iff(Path(path).read_bytes())
    stack = [root]
    while stack:
        b = stack.pop(0)
        for i, c in enumerate(b.children):
            if c.is_form:
                stack.append(c)
                continue
            if c.tag == "XXXX" and c.data.startswith(_PCCV.encode() + b"\0"):
                out = []
                for f in b.children[i + 1:]:
                    if not (f.is_form and f.tag == "PCCV"):
                        if f.is_form or f.data not in (b"", b"\1" + _stag("PCCV")):
                            break
                        continue
                    e = {}
                    for x in f.chunks("XXXX"):
                        k, rest = x.data.split(b"\0", 1)
                        e[k.decode()] = (struct.unpack("<i", rest[2:6])[0] if k == b"defaultPaletteIndex"
                                         else rest[1:].split(b"\0", 1)[0].decode("latin1"))
                    out.append(e)
                if out:
                    return out
    return []


STOCK_FLATTEN_LAYER = "terrain/ply_tatt_house_m_s01.lay"   # outer feathered flatten rect + inner flora-clear rect


def flatten_layer(base_layer: str | Path, out_path: str | Path, flat_rect: tuple[float, float, float, float],
                  feather: float = 8.0, flora_rect: tuple[float, float, float, float] | None = None) -> dict[str, Any]:
    """Write a building terrain layer (.lay) derived from a stock house layer: the outer BREC flattens
    `flat_rect` (engine-space x0, z0, x1, z1 around the building origin) to the building's height and feathers
    `feather` metres into the natural terrain; the inner BREC (flora cleared) covers `flora_rect` (default:
    flat_rect). The client sets the height constant to the terrain height under the building origin, so the
    building's own ground level must be y = 0."""
    root = parse_iff(Path(base_layer).read_bytes())
    recs = []

    def walk(b: Block) -> None:
        for c in b.children:
            if c.is_form and c.tag == "BREC":
                recs.append(c)
            if c.is_form:
                walk(c)
    walk(root)
    if len(recs) < 2:
        raise ValueError(f"{base_layer}: expected outer and inner boundary rectangles")

    def data_chunk(brec: Block) -> Block:
        ver = brec.forms()[0]
        return next(c for c in ver.children if not c.is_form and c.tag == "DATA")

    x0, z0, x1, z1 = flat_rect
    ox0, oz0, ox1, oz1 = x0 - feather, z0 - feather, x1 + feather, z1 + feather
    # BoundaryRectangle feather = 0.5 * min(w, h) * featherDistance
    frac = min(0.95, 2.0 * feather / min(ox1 - ox0, oz1 - oz0))
    outer = data_chunk(recs[0])
    func = struct.unpack_from("<i", outer.data, 16)[0]
    outer.data = struct.pack("<4fif", ox0, oz0, ox1, oz1, func, frac)
    fx0, fz0, fx1, fz1 = flora_rect or flat_rect
    inner = data_chunk(recs[1])
    ifunc = struct.unpack_from("<i", inner.data, 16)[0]
    ifrac = struct.unpack_from("<f", inner.data, 20)[0]
    inner.data = struct.pack("<4fif", fx0, fz0, fx1, fz1, ifunc, ifrac)
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(serialize_iff(root))
    return {"path": str(out), "flat_rect": [x0, z0, x1, z1], "outer_rect": [ox0, oz0, ox1, oz1], "feather_fraction": frac}


STOCK_PIT_LAYER = "terrain/guildhall.lay"     # its "SUNKEN STAIR" sublayer: BREC + AffectorHeightConstant subtract


def add_pit_layer(data_root: str | Path, lay_path: str | Path, pit_rect: tuple[float, float, float, float] | None,
                  depth: float, feather: float = 8.0, pit_polygon: list[tuple[float, float]] | None = None) -> dict[str, Any]:
    """Dig a pit into a building terrain layer (.lay from flatten_layer): a sublayer whose height constant
    SUBTRACTS `depth` metres over `pit_rect` (engine-space x0, z0, x1, z1 around the origin: the flat bottom),
    ramping back up over `feather` metres outside it. Cloned from the stock guildhall's sunken-stair sublayer, which
    SOE shipped disabled: the client set every height constant to the building height. With the titan engine only
    replace constants follow the building (TerrainModificationHelper::setHeight), so add/subtract ones are offsets
    from it."""
    def walk(b: Block, fn) -> Block | None:
        for c in b.children:
            if c.is_form:
                if fn(c):
                    return c
                hit = walk(c, fn)
                if hit is not None:
                    return hit
        return None

    def ihdr(form: Block) -> Block:        # the DATA chunk of a form's IHDR (int active + name)
        ver = form.forms()[0]
        return ver.first("IHDR").forms()[0].chunks("DATA")[0]

    def data_chunk(form: Block) -> Block:
        return next(c for c in form.forms()[0].children if not c.is_form and c.tag == "DATA")

    stock = parse_iff((Path(data_root) / STOCK_PIT_LAYER).read_bytes())
    pit = walk(stock, lambda c: c.tag == "LAYR" and b"SUNKEN STAIR" in ihdr(c).data)
    if pit is None:
        raise ValueError(f"{STOCK_PIT_LAYER}: no SUNKEN STAIR sublayer to clone")
    pit = copy.deepcopy(pit)
    ver = pit.forms()[0]
    brec, ahcn = ver.first("BREC"), ver.first("AHCN")
    for blk in (pit, brec, ahcn):
        d = ihdr(blk)
        d.data = struct.pack("<i", 1) + d.data[4:]
    ihdr(pit).data = struct.pack("<i", 1) + b"landing well pit\0"
    data_chunk(ahcn).data = struct.pack("<if", 2, float(depth))           # TGO_subtract
    if pit_polygon:
        # exact shape (titan engine): flat inside pit_polygon, ramping up over `feather` outside it
        outer = grow_outline(pit_polygon, feather)
        ver.children[ver.children.index(brec)] = local_polygon_boundary(outer, feather, "local landing well pit", 0)
        info = {"pit_points": len(pit_polygon), "outer_extent": [min(p[0] for p in outer), min(p[1] for p in outer),
                                                                 max(p[0] for p in outer), max(p[1] for p in outer)]}
    else:
        x0, z0, x1, z1 = pit_rect
        ox0, oz0, ox1, oz1 = x0 - feather, z0 - feather, x1 + feather, z1 + feather
        frac = min(0.95, 2.0 * feather / min(ox1 - ox0, oz1 - oz0))
        bd = data_chunk(brec)
        bd.data = struct.pack("<4fif", ox0, oz0, ox1, oz1, struct.unpack_from("<i", bd.data, 16)[0], frac)
        info = {"pit_rect": [x0, z0, x1, z1], "outer_rect": [ox0, oz0, ox1, oz1], "feather_fraction": frac}
    root = parse_iff(Path(lay_path).read_bytes())
    main = walk(root, lambda c: c.tag == "LAYR")
    main.forms()[0].children.append(pit)
    Path(lay_path).write_bytes(serialize_iff(root))
    return {"path": str(lay_path), "depth": depth, **info}


def local_circle_boundary(center: tuple[float, float], radius: float, name: str, feather: float = 0.0,
                          feather_function: int = 0) -> Block:
    """A terrain BoundaryCircle (BCIR 0002) in building-local engine x/z. The name must start with "local": titan's
    engine then keeps its offset from the building and turns it with the building; stock circles are re-centred on it.
    `feather` is the fraction of the radius (0..1) that feathers inward."""
    if not name.startswith("local"):
        raise ValueError("building-local circle boundaries must be named local...")
    ihdr = _form("IHDR", [_form("0001", [_chunk("DATA", struct.pack("<i", 1) + name.encode("latin1") + b"\0")])])
    data = struct.pack("<3fif", float(center[0]), float(center[1]), float(radius), feather_function, float(feather))
    return _form("BCIR", [_form("0002", [ihdr, _chunk("DATA", data)])])


def add_exclude_layer(lay_path: str | Path, polygon: list[tuple[float, float]] | None = None, name: str = "local terrain hole",
                      circle: tuple[float, float, float] | None = None, fine: bool = True) -> dict[str, Any]:
    """Cut a hole in the terrain under a building: a sublayer of the building's layer (.lay) with a local boundary
    (engine x/z round the building origin, no feather) - `circle` (x, z, radius) or `polygon` - and an AffectorExclude.
    The terrain has no tiles and no height inside it, so the building's own floors and walls are all there is.
    `fine` (titan engine, AEXC 0001) cuts exactly along the circle/polygon edge: tiles the edge crosses stay, with their
    inside height poles moved onto the edge. Without it (stock, as naboo_wb.lay) whole tiles two poles wide drop by
    one corner, which steps the cut by up to a tile. Replaces an earlier hole or pit sublayer."""
    if (circle is None) == (polygon is None):
        raise ValueError("give either circle or polygon")

    def item_header(name_: str) -> Block:
        return _form("IHDR", [_form("0001", [_chunk("DATA", struct.pack("<i", 1) + name_.encode("latin1") + b"\0")])])

    root = parse_iff(Path(lay_path).read_bytes())
    main = next(c for c in root.children if c.is_form and c.tag == "LAYR")
    ver = main.forms()[0]

    def is_old(c: Block) -> bool:
        if not (c.is_form and c.tag == "LAYR"):
            return False
        data = c.forms()[0].first("IHDR").forms()[0].chunks("DATA")[0].data
        return b"landing well" in data or b"terrain hole" in data or name.encode("latin1") in data
    ver.children = [c for c in ver.children if not is_old(c)]
    # LAYR 0003: IHDR, ADTA (invert boundaries, invert filters, expanded, notes), boundaries, filters, affectors
    hole = _form("LAYR", [_form("0003", [
        item_header(name.replace("local ", "", 1) if name.startswith("local ") else name),
        _chunk("ADTA", struct.pack("<3i", 0, 0, 1) + b"\0"),
        local_circle_boundary(circle[:2], circle[2], name) if circle else local_polygon_boundary(polygon, 0.0, name, 0),
        _form("AEXC", [_form("0001", [item_header("AffectorExclude"), _chunk("DATA", struct.pack("<i", 1))])] if fine else
                      [_form("0000", [item_header("AffectorExclude"), _chunk("DATA", b"")])]),
    ])])
    ver.children.append(hole)
    Path(lay_path).write_bytes(serialize_iff(root))
    if circle:
        x, z, r = circle
        extent = [x - r, z - r, x + r, z + r]
    else:
        extent = [min(p[0] for p in polygon), min(p[1] for p in polygon), max(p[0] for p in polygon), max(p[1] for p in polygon)]
    return {"path": str(lay_path), "fine": fine, "shape": "circle" if circle else f"polygon ({len(polygon)} points)", "extent": extent}


def hull_2d(points: list[tuple[float, float]]) -> list[tuple[float, float]]:
    """Convex hull (counter-clockwise, monotone chain) of x/z points."""
    pts = sorted(set((round(x, 4), round(z, 4)) for x, z in points))
    if len(pts) < 3:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def grow_outline(outline: list[tuple[float, float]], distance: float, segments: int = 12) -> list[tuple[float, float]]:
    """A convex outline pushed out by `distance` with rounded corners (hull of circles round its corners)."""
    if distance <= 0:
        return hull_2d(outline)
    ring = [(x + distance * math.cos(2 * math.pi * k / segments), z + distance * math.sin(2 * math.pi * k / segments))
            for x, z in outline for k in range(segments)]
    return hull_2d(ring)


def local_polygon_boundary(points: list[tuple[float, float]], feather: float, name: str, feather_function: int = 3) -> Block:
    """A terrain BoundaryPolygon (BPOL 0007) in building-local engine x/z. The name must start with "local": titan's
    engine then moves and turns it with the building (BoundaryPoly::setCenter / setRotation); stock polygons stay in
    world space. The feather runs inward from the edge, `feather` metres wide."""
    if not name.startswith("local"):
        raise ValueError("building-local polygon boundaries must be named local...")
    ihdr = _form("IHDR", [_form("0001", [_chunk("DATA", struct.pack("<i", 1) + name.encode("latin1") + b"\0")])])
    data = struct.pack("<i", len(points)) + b"".join(struct.pack("<2f", x, z) for x, z in points)
    data += struct.pack("<ififfi", feather_function, float(feather), 0, 0.0, 2.0, 0) + b"\0"
    return _form("BPOL", [_form("0007", [ihdr, _chunk("DATA", data)])])


def shape_building_layer(lay_path: str | Path, outline: list[tuple[float, float]], feather: float = 12.0,
                         margin: float = 3.0, flora_margin: float = 1.0) -> dict[str, Any]:
    """Make a flatten layer (flatten_layer) follow the building's own footprint instead of a rectangle: the outer
    boundary becomes a local polygon - the outline grown by `margin` is flat, then `feather` metres of smooth ramp -
    and the flora-clear boundary the outline grown by `flora_margin`. Needs the titan engine (local polygons)."""
    root = parse_iff(Path(lay_path).read_bytes())
    main = next(c for c in root.children if c.is_form and c.tag == "LAYR")

    def replace_first_brec(layer: Block, new: Block) -> bool:
        ver = layer.forms()[0]
        for i, c in enumerate(ver.children):
            if c.is_form and c.tag in ("BREC", "BPOL"):
                ver.children[i] = new
                return True
        return False
    flat = grow_outline(outline, margin)
    outer = grow_outline(outline, margin + feather)
    if not replace_first_brec(main, local_polygon_boundary(outer, feather, "local building flatten")):
        raise ValueError(f"{lay_path}: no outer boundary to replace")
    flora = next((c for c in main.forms()[0].children if c.is_form and c.tag == "LAYR"), None)
    if flora is not None:
        replace_first_brec(flora, local_polygon_boundary(grow_outline(outline, flora_margin), 0.0, "local flora clear"))
    Path(lay_path).write_bytes(serialize_iff(root))
    return {"path": str(lay_path), "flat_points": len(flat), "outer_points": len(outer),
            "outer_extent": [min(p[0] for p in outer), min(p[1] for p in outer), max(p[0] for p in outer), max(p[1] for p in outer)]}


def radar_outline(lod_path: str | Path) -> list[tuple[float, float]]:
    """Convex outline (engine x/z) of a building .lod's overhead-map shape (RADR)."""
    lod = parse_iff(Path(lod_path).read_bytes()).first("DTLA").forms()[0]
    radr = lod.first("RADR")
    if radr is None:
        raise ValueError(f"{lod_path}: no RADR shape")
    vert = next((c for c in _walk_blocks(radr) if c.tag == "VERT"), None)
    if vert is None:
        raise ValueError(f"{lod_path}: RADR has no vertices")
    v = [struct.unpack_from("<3f", vert.data, i) for i in range(0, len(vert.data), 12)]
    return hull_2d([(x, z) for x, _, z in v])


def _walk_blocks(b: Block):
    for c in b.children:
        yield c
        if c.is_form:
            yield from _walk_blocks(c)


def floor_bounds(flr_path: str | Path, pad: float = 0.0) -> tuple[float, float, float, float]:
    """Engine-space x/z bounding rectangle of a floor (.flr), grown by `pad`."""
    v = read_flr(flr_path)["vertices"]
    return (min(p[0] for p in v) - pad, min(p[2] for p in v) - pad, max(p[0] for p in v) + pad, max(p[2] for p in v) + pad)


def read_kfat(path: str | Path) -> dict[str, Any]:
    """Uncompressed keyframe animation (.ans FORM KFAT/0003): transforms with their rotation keys
    (frame, (w, x, y, z)) and per-axis translation keys, resolved through the channel tables."""
    root = parse_iff(Path(path).read_bytes())
    kfat = root.first("KFAT")
    if kfat is None:
        raise ValueError(f"{path}: not a KFAT animation")
    ver = kfat.forms()[0]
    info = Reader(ver.first("INFO").data)
    fps = info.f32()
    frames, n_xf, n_rot, n_srot, n_tr, n_str = (info.i32() for _ in range(6))
    xfins = []
    for c in ver.first("XFRM").chunks("XFIN"):
        r = Reader(c.data)
        name = r.string()
        animated = r.i8() != 0
        rot = r.i32()
        mask = struct.unpack_from("<I", r.data, r.pos)[0]; r.pos += 4
        tx, ty, tz = r.i32(), r.i32(), r.i32()
        xfins.append((name, animated, rot, mask, tx, ty, tz))
    rot_ch = []
    arot = ver.first("AROT")
    for c in (arot.chunks("QCHN") if arot else []):
        r = Reader(c.data)
        rot_ch.append([(r.i32(), (r.f32(), r.f32(), r.f32(), r.f32())) for _ in range(r.i32())])
    srot = []
    if ver.first("SROT"):
        r = Reader(ver.first("SROT").data)
        srot = [(r.f32(), r.f32(), r.f32(), r.f32()) for _ in range(n_srot)]
    tr_ch = []
    atrn = ver.first("ATRN")
    for c in (atrn.chunks("CHNL") if atrn else []):
        r = Reader(c.data)
        tr_ch.append([(r.i32(), r.f32()) for _ in range(r.i32())])
    strn = []
    if ver.first("STRN"):
        r = Reader(ver.first("STRN").data)
        strn = [r.f32() for _ in range(n_str)]
    joints = {}
    for name, animated, rot, mask, tx, ty, tz in xfins:
        j = {"rotation": rot_ch[rot] if animated else [(0, srot[rot])]}
        for axis, idx, bit in (("x", tx, 0x08), ("y", ty, 0x10), ("z", tz, 0x20)):
            j["t" + axis] = tr_ch[idx] if mask & bit else [(0, strn[idx] if 0 <= idx < len(strn) else 0.0)]
        joints[name] = j
    return {"fps": fps, "frames": frames, "joints": joints}


# ----------------------------------------------------------------------------
# Exterior detail appearance (radar shape for the overhead map) + structure footprint
# ----------------------------------------------------------------------------

def _chunk(tag: str, data: bytes) -> Block:
    return Block(tag, False, data)


def _form(tag: str, children: list[Block]) -> Block:
    return Block(tag, True, b"", children)


def _idtl(vertices: list[tuple[float, float, float]], indices: list[int]) -> Block:
    vert = b"".join(struct.pack("<3f", *v) for v in vertices)
    indx = b"".join(struct.pack("<i", i) for i in indices)
    return _form("IDTL", [_form("0000", [_chunk("VERT", vert), _chunk("INDX", indx)])])


def write_exterior_lod(export_root: str | Path, pob_path: str | Path, radar_y: float = 0.5,
                       stock_lod: str | Path | None = None, near_range: float | None = None) -> dict[str, Any]:
    """Give a building's exterior (r0) appearance an overhead-map shape, like stock houses: writes
    appearance/lod/<r0>.lod (DTLA 0007: the r0 mesh as its one LOD + a RADR footprint = every interior floor
    flattened to y=radar_y, no TEST/WRIT so nothing seen through windows is occluded) and points the r0 .apt
    at it. Plain mesh appearances have no radar shape, so the building would be missing from the map.
    stock_lod: a stock building .lod the r0 mesh replaces (interior added to a stock exterior): its distance LODs
    stay as the far children (the r0 mesh takes the nearest slot) and its RADR outline is kept.
    near_range: how far out the r0 mesh is drawn before the stock far LODs (default: the stock nearest LOD's range);
    the far LODs' ranges move out with it - for an exterior that adds ground the stock LODs lack (a terrain hole's
    cover), out to where the terrain is drawn from chunks the hole isn't cut in."""
    root = Path(export_root)
    pob = read_pob(pob_path)
    r0 = pob["cells"][0]
    apt_rel = r0["appearance"]
    apt_path = root / apt_rel
    apt = parse_iff(apt_path.read_bytes())
    target = apt.first("APT ").forms()[0].first("NAME").data.split(b"\0")[0].decode("latin1")
    if target.endswith(".lod"):                                   # already done: rebuild from its mesh
        lod = parse_iff((root / target).read_bytes()).first("DTLA").forms()[0]
        kids = [c.data[4:].split(b"\0")[0].decode("latin1") for c in lod.first("DATA").chunks("CHLD")]
        own = [k for k in kids if Path(k).stem == Path(apt_rel).stem]      # stock far LODs may come first
        msh_rel = "appearance/" + (own or kids)[0]
    else:
        msh_rel = target
    msh = parse_iff((root / msh_rel).read_bytes())
    mesh_ver = msh.first("MESH").forms()[0]
    appr = mesh_ver.first("APPR")
    verts: list[tuple[float, float, float]] = []
    idx: list[int] = []
    for c in pob["cells"][1:]:
        fp = root / c["floor"] if c["floor"] else None
        if not fp or not fp.exists():
            continue
        flr = read_flr(fp)
        base = len(verts)
        verts += [(v[0], radar_y, v[2]) for v in flr["vertices"]]
        for t in flr["tris"]:
            a, b_, d = t["corners"]
            idx += [base + a, base + d, base + b_]          # facing up as seen from above
    if not idx:
        raise ValueError(f"{pob_path}: no interior floors to build a radar footprint from")
    child = msh_rel[len("appearance/"):] if msh_rel.startswith("appearance/") else msh_rel
    info = struct.pack("<iff", 0, 0.0, 4096.0)
    chld = [_chunk("CHLD", struct.pack("<i", 0) + child.encode("latin1") + b"\0")]
    radar = _form("RADR", [_chunk("INFO", struct.pack("<i", 1)), _idtl(verts, idx)])
    radar_src = f"{len(idx) // 3} floor tris"
    if stock_lod:
        sv = parse_iff(Path(stock_lod).read_bytes()).first("DTLA").forms()[0]
        r = Reader(sv.first("INFO").data)
        ranges = [(r.i32(), r.f32(), r.f32()) for _ in range(len(r.data) // 12)]
        near_id = min(ranges, key=lambda e: e[1])[0]
        names = {struct.unpack_from("<i", c.data)[0]: c.data[4:] for c in sv.first("DATA").chunks("CHLD")}
        if near_range is not None:
            old_far = next(e[2] for e in ranges if e[0] == near_id)
            shift = max(0.0, near_range - old_far)
            ranges = [(i, 0.0, near_range) if i == near_id else (i, lo + shift, hi + shift) for i, lo, hi in ranges]
        info = b"".join(struct.pack("<iff", *e) for e in ranges)
        chld = [_chunk("CHLD", struct.pack("<i", i) + (child.encode("latin1") + b"\0" if i == near_id else names[i]))
                for i, _, _ in ranges]
        if sv.first("RADR") is not None:
            radar, radar_src = sv.first("RADR"), "stock outline"
        # the stock hardpoints (client data files hang lights / effects on them) replace the r0 mesh's own
        stock_hpts = sv.first("APPR").forms()[0].first("HPTS") if sv.first("APPR") is not None else None
        ours = appr.forms()[0]
        if stock_hpts is not None and stock_hpts.children:
            ours.children = [stock_hpts if c.is_form and c.tag == "HPTS" else c for c in ours.children]
    no_shape = lambda tag: _form(tag, [_chunk("INFO", struct.pack("<i", 0))])
    dtla = _form("DTLA", [_form("0007", [
        appr, _chunk("PIVT", b"\0"), _chunk("INFO", info), _form("DATA", chld), radar,
        no_shape("TEST"), no_shape("WRIT"),
    ])])
    lod_rel = "appearance/lod/" + Path(apt_rel).stem + ".lod"
    (root / lod_rel).parent.mkdir(parents=True, exist_ok=True)
    (root / lod_rel).write_bytes(serialize_iff(_form("<root>", [dtla])))
    new_apt = _form("APT ", [_form("0000", [_chunk("NAME", lod_rel.encode("latin1") + b"\0")])])
    apt_path.write_bytes(serialize_iff(_form("<root>", [new_apt])))
    return {"lod": lod_rel, "mesh": msh_rel, "lods": len(chld), "radar": radar_src}


def _exbx(lo: tuple[float, float, float], hi: tuple[float, float, float]) -> Block:
    """Extent box (EXBX 0001: EXSP sphere + BOX max, min), engine space."""
    c = [(a + b) / 2 for a, b in zip(lo, hi)]
    r = math.sqrt(sum(((b - a) / 2) ** 2 for a, b in zip(lo, hi)))
    sphr = _form("EXSP", [_form("0001", [_chunk("SPHR", struct.pack("<4f", *c, r))])])
    return _form("EXBX", [_form("0001", [sphr, _chunk("BOX ", struct.pack("<6f", *hi, *lo))])])


def _engine_box(box) -> tuple[tuple[float, float, float], tuple[float, float, float]]:
    """Maya-space box ((x0,y0,z0),(x1,y1,z1)) -> engine space (X mirrored)."""
    (x0, y0, z0), (x1, y1, z1) = box
    return (-max(x0, x1), min(y0, y1), min(z0, z1)), (-min(x0, x1), max(y0, y1), max(z0, z1))


def write_static_lod(export_root: str | Path, apt_rel: str, boxes: list, composite: bool,
                     footprint: list | None = None, radar_y: float = 0.5, floor: str | None = None,
                     bounds: list | None = None, lods: list | None = None,
                     lod_ranges: tuple = (45.0, 100.0)) -> dict[str, Any]:
    """Wrap an exported static mesh the way stock static structures are: appearance/lod/<name>.lod (DTLA 0007)
    whose APPR carries the extent box and the COLLISION extent (one box, or for pieces with a passage or a
    curve a composite of boxes - DTAL/CPST/CMPT like stock gates and arches), a RADR footprint, and the mesh as
    its LOD child; the .apt is re-pointed at it. Boxes are Maya space ((x0,y0,z0),(x1,y1,z1)).
    lods: .apt paths of reduced copies, most detailed first (l1, l2...); their meshes become the far children,
    switched at lod_ranges metres. Children go lowest detail first with (index, near, far) INFO rows, like stock
    (nboo_decd_cambylictustree.lod: l3 100-1000, l2 60-100, l1 30-60, l0 0-30)."""
    root = Path(export_root)
    apt_path = root / apt_rel
    apt = parse_iff(apt_path.read_bytes())
    msh_rel = apt.first("APT ").forms()[0].first("NAME").data.split(b"\0")[0].decode("latin1")
    if msh_rel.endswith(".lod"):                                  # rebuilt: take the mesh back out of the lod
        lod = parse_iff((root / msh_rel).read_bytes()).first("DTLA").forms()[0]
        msh_rel = "appearance/" + lod.first("DATA").chunks("CHLD")[-1].data[4:].split(b"\0")[0].decode("latin1")
    eboxes = [_engine_box(b) for b in boxes]
    ext = eboxes + ([_engine_box(bounds)] if bounds else [])
    lo = tuple(min(b[0][k] for b in ext) for k in range(3))
    hi = tuple(max(b[1][k] for b in ext) for k in range(3))
    if not eboxes:                                    # walk-on piece (platform): its floor is all the collision
        coll = _form("NULL", [])
    elif composite and len(eboxes) > 1:
        clo = tuple(min(b[0][k] for b in eboxes) for k in range(3))
        chi = tuple(max(b[1][k] for b in eboxes) for k in range(3))
        parts = _form("CMPT", [_form("0000", [_form("CPST", [_form("0000", [_exbx(*b) for b in eboxes])])])])
        coll = _form("DTAL", [_form("0000", [_form("CPST", [_form("0000", [_exbx(clo, chi), parts])])])])
    else:
        coll = _exbx(*eboxes[0])
    # walkable pieces reference their floor like the stock stairs: FLOR DATA = 1 + path
    flor = _chunk("DATA", b"\1" + floor.encode("latin1") + b"\0") if floor else _chunk("DATA", b"\0")
    # the mesh's own hardpoints (transforms exported under the piece) move up to the lod, where client data
    # files look for them
    msh_appr = parse_iff((root / msh_rel).read_bytes()).first("MESH").forms()[0].first("APPR")
    hpts = msh_appr.forms()[0].first("HPTS") if msh_appr is not None else None
    appr = _form("APPR", [_form("0003", [_exbx(lo, hi), coll, hpts if hpts is not None else _form("HPTS", []),
                                         _form("FLOR", [flor])])])
    child = msh_rel[len("appearance/"):]
    verts, idx = [], []
    for tri in footprint or []:
        base = len(verts)
        verts += [(-p[0], radar_y, p[1]) for p in tri]            # mirrored X flips the winding: swap back
        idx += [base, base + 2, base + 1]
    radar = _form("RADR", [_chunk("INFO", struct.pack("<i", 1)), _idtl(verts, idx)]) if idx else         _form("RADR", [_chunk("INFO", struct.pack("<i", 0))])
    no_shape = lambda tag: _form(tag, [_chunk("INFO", struct.pack("<i", 0))])
    children = [child]
    for rel in lods or []:
        a = parse_iff((root / rel).read_bytes())
        children.append(a.first("APT ").forms()[0].first("NAME").data.split(b"\0")[0].decode("latin1")[len("appearance/"):])
    children = children[::-1]                                     # lowest detail first, as stock
    edges = [0.0] + list(lod_ranges[:len(children) - 1]) + [1024.0]
    info, chld = b"", []
    for i, c in enumerate(children):
        k = len(children) - 1 - i                                 # detail level of this child (0 = full)
        info += struct.pack("<iff", i, edges[k], edges[k + 1])
        chld.append(_chunk("CHLD", struct.pack("<i", i) + c.encode("latin1") + b"\0"))
    dtla = _form("DTLA", [_form("0007", [
        appr, _chunk("PIVT", b"\0"), _chunk("INFO", info), _form("DATA", chld),
        radar, no_shape("TEST"), no_shape("WRIT")])])
    lod_rel = "appearance/lod/" + Path(apt_rel).stem + ".lod"
    (root / lod_rel).parent.mkdir(parents=True, exist_ok=True)
    (root / lod_rel).write_bytes(serialize_iff(_form("<root>", [dtla])))
    apt_path.write_bytes(serialize_iff(_form("<root>", [_form("APT ", [_form("0000", [
        _chunk("NAME", lod_rel.encode("latin1") + b"\0")])])])))
    return {"lod": lod_rel, "mesh": msh_rel, "floor": floor, "lods": len(children),
            "collision": "none" if not eboxes else "composite" if composite and len(eboxes) > 1 else "box",
            "boxes": len(eboxes), "extent": [list(lo), list(hi)]}


def write_footprint(out_path: str | Path, rect: tuple[float, float, float, float], lot: float = 8.0,
                    hard_margin: int = 1) -> dict[str, Any]:
    """Structure footprint (.sfp, FORM FOOT/0000) for placement: `rect` = engine-space x0, z0, x1, z1 around the
    building origin, rounded out to `lot`-metre lots. Cells under the building are 'F' (structure), a ring of
    `hard_margin` lots around them 'H' (hard reservation, like stock houses' approach rows)."""
    x0, z0, x1, z1 = rect
    gx0, gz0 = math.floor(x0 / lot) - hard_margin, math.floor(z0 / lot) - hard_margin
    gx1, gz1 = math.ceil(x1 / lot) + hard_margin, math.ceil(z1 / lot) + hard_margin
    w, h = gx1 - gx0, gz1 - gz0
    rows = []
    for gz in range(gz0, gz1):
        row = ""
        for gx in range(gx0, gx1):
            inner = (math.floor(x0 / lot) <= gx < math.ceil(x1 / lot)) and (math.floor(z0 / lot) <= gz < math.ceil(z1 / lot))
            row += "F" if inner else "H"
        rows.append(row)
    info = struct.pack("<4i2f", w, h, -gx0, -gz0, lot, lot)
    foot = _form("FOOT", [_form("0000", [_chunk("INFO", info),
                                          _chunk("PRNT", b"".join(r.encode() + b"\0" for r in rows))])])
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(serialize_iff(_form("<root>", [foot])))
    return {"path": str(out), "size": [w, h], "pivot": [-gx0, -gz0], "rows": rows}


# ----------------------------------------------------------------------------
# client data files, shaders, textures (authored effects and materials)
# ----------------------------------------------------------------------------

def _cstr(s: str) -> bytes:
    return s.encode("latin1") + b"\0"


def _light_object(light: dict[str, Any]) -> bytes:
    """ClientDataFile readLightObject layout: type (1 steady, 2 flicker), appearance, colour 1/2, range 1/2,
    time 1/2, constant/linear/quadratic attenuation, flags (1 time-of-day aware, 2 on/off aware)."""
    c1 = light.get("rgb", (1.0, 1.0, 1.0))
    c2 = light.get("rgb2", c1)
    r1 = float(light.get("range", 8.0))
    return (struct.pack("<i", int(light.get("type", 1))) + _cstr(light.get("appearance", "")) +
            struct.pack("<3f3f4f3fi", *c1, *c2, r1, float(light.get("range2", r1)),
                        float(light.get("time", 0.0)), float(light.get("time2", 0.0)),
                        float(light.get("constant", 0.1)), float(light.get("linear", 0.0)),
                        float(light.get("quadratic", 0.0)), int(light.get("flags", 0))))


def write_client_data(out_path: str | Path, hardpoint_lights: list[dict[str, Any]] | None = None,
                      hardpoint_children: list[dict[str, str]] | None = None,
                      lights: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """Client data file (.cdf, FORM CLDF/0000) like the stock lamps': HLOB = a light (optionally carrying an
    appearance such as a glow .prt) on a hardpoint, HOBJ = an appearance (particle system, mesh) on a hardpoint,
    LOBJ = a light at an object-space position (engine space). Point an object template's clientDataFile at it;
    hardpoints are looked up in the object's appearance (a .lod's APPR HPTS)."""
    kids = []
    for lt in hardpoint_lights or []:
        kids.append(_chunk("HLOB", _light_object(lt) + _cstr(lt["hardpoint"])))
    for ch in hardpoint_children or []:
        kids.append(_chunk("HOBJ", _cstr(ch["appearance"]) + _cstr(ch["hardpoint"])))
    for lt in lights or []:
        kids.append(_chunk("LOBJ", _light_object(lt) + struct.pack("<3f", *lt["pos"])))
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(serialize_iff(_form("<root>", [_form("CLDF", [_form("0000", kids)])])))
    return {"path": str(out), "hardpoint_lights": len(hardpoint_lights or []),
            "hardpoint_children": len(hardpoint_children or []), "lights": len(lights or [])}


def _stag(tag: str) -> bytes:
    """A shader tag ('MAIN', 'HUEB', 'NRML', 'DOT3' ...) as stored in shader chunks: a little-endian uint32."""
    return tag.encode("latin1")[::-1]


def _stag_name(raw: bytes) -> str:
    return raw[::-1].decode("latin1")


def shader_block(effect: str, texture: str | None = None, emissive: tuple[float, float, float] = (0, 0, 0),
                 alpha_ref: int | list | None = None, specular: tuple[float, float, float] = (0, 0, 0),
                 power: float = 20.0, textures: list | None = None, tcss: list | None = None,
                 tfactors: dict[str, int] | None = None) -> Block:
    """FORM SSHT/0000 in the stock layout: MATS (ambient, diffuse, emissive, specular, power), TXMS, TCSS, TFNS,
    ARVS, effect NAME.
      textures   [(tag, path)] or [(tag, path, 7 DATA bytes after the tag)]; default [("MAIN", texture)]
      tcss       texture coordinate sets [(tag, set)]; default [("MAIN", 0)] (bump effects: DOT3 1, MAIN 0, NRML 0)
      tfactors   {tag: ARGB uint32} texture factors the effect reads (hue effects: HUEB/MAIN 0xffffffff ...)
      alpha_ref  alpha reference for MAIN (int) or [(tag, ref)]"""
    matl = struct.pack("<17f", 1, 1, 1, 1, 1, 1, 1, 1, 0.0, *emissive, 1.0, *specular, power)   # ARGB colours
    txms = []
    for t in textures or [("MAIN", texture)]:
        data = t[2] if len(t) > 2 else b"\0\0\0\0\2\2\2"
        txms.append(_form("TXM ", [_form("0001", [_chunk("DATA", _stag(t[0]) + data), _chunk("NAME", _cstr(t[1]))])]))
    kids = [_form("MATS", [_form("0000", [_chunk("TAG ", _stag("MAIN")), _chunk("MATL", matl)])]),
            _form("TXMS", txms),
            _form("TCSS", [_chunk("0000", b"".join(_stag(t) + bytes([s]) for t, s in tcss or [("MAIN", 0)]))])]
    if tfactors:
        kids.append(_tfns(tfactors))
    if alpha_ref is not None:
        refs = [("MAIN", alpha_ref)] if isinstance(alpha_ref, int) else alpha_ref
        kids.append(_form("ARVS", [_chunk("0000", b"".join(_stag(t) + bytes([r]) for t, r in refs))]))
    kids.append(_chunk("NAME", _cstr(effect.replace("/", "\\"))))
    return _form("SSHT", [_form("0000", kids)])


def _tfns(tfactors: dict[str, int]) -> Block:
    """FORM TFNS/0000: texture factors sorted by tag value, as stock writes them (a std::map of tags)."""
    items = sorted(tfactors.items(), key=lambda kv: struct.unpack("<I", _stag(kv[0]))[0])
    return _form("TFNS", [_chunk("0000", b"".join(_stag(t) + struct.pack("<I", v & 0xFFFFFFFF) for t, v in items))])


def _read_tfns(block: Block) -> dict[str, int]:
    d = block.chunks("0000")[0].data
    return {_stag_name(d[i:i + 4]): struct.unpack_from("<I", d, i + 4)[0] for i in range(0, len(d), 8)}


def write_shader(out_path: str | Path, effect: str, texture: str, emissive: tuple[float, float, float] = (0, 0, 0),
                 alpha_ref: int | None = None, specular: tuple[float, float, float] = (0, 0, 0),
                 power: float = 20.0) -> dict[str, Any]:
    """Single-texture static shader (.sht, FORM SSHT/0000) in the stock layout: MATS (ambient, diffuse, emissive,
    specular, power), the MAIN texture, its coordinate set, an alpha reference for alpha effects (ARVS) and the
    effect (e.g. effect\a_alpha.eft, a_alpha_emis_full.eft, a_emis_full.eft, a_simple.eft)."""
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(serialize_iff(_form("<root>", [shader_block(effect, texture, emissive, alpha_ref, specular, power)])))
    return {"path": str(out), "effect": effect, "texture": texture}


def custom_shader_block(base: bytes | Block | dict, pals: list, tfactors: dict[str, int] | None = None) -> Block:
    """FORM CSHD/0001 (customizable shader, the stock hue shaders *_hue_hc8.sht ...): the base static shader plus
    FORM TFAC with one PAL per palette-driven texture factor. The colour of texture factor `tag` comes from
    palette entry /private/<var> of the object's customization data (`default` when the object lacks the
    variable); hue effects (effect\\h_*.eft) multiply the texture by it.
      base     an SSHT: .sht bytes (FORM SSHT), a parsed block, or shader_block() keyword arguments
      pals     [(var, tag, palette, default)] or (..., private) - e.g. ("index_color_1", "MAIN",
               "palette/frn_hue.pal", 0); var without the /private/ prefix
      tfactors extra texture factors the effect reads, {tag: ARGB} (pal tags missing from the base's TFNS are added
               as 0xffffffff, as stock does)"""
    if isinstance(base, dict):
        ssht = shader_block(**base)
    elif isinstance(base, Block):
        ssht = copy.deepcopy(base)
    else:
        root = parse_iff(bytes(base))
        ssht = root.children[0]
        if ssht.tag == "CSHD":                         # rebuild from a customizable shader's own base
            ssht = ssht.forms()[0].forms("SSHT")[0]
    if ssht.tag != "SSHT":
        raise ValueError(f"base shader is FORM {ssht.tag}, not SSHT")
    ver = ssht.forms()[0]
    tfns = next((c for c in ver.children if c.is_form and c.tag == "TFNS"), None)
    want = _read_tfns(tfns) if tfns is not None else {}
    for t, v in (tfactors or {}).items():
        want.setdefault(t, v)
    for p in pals:
        want.setdefault(p[1], 0xFFFFFFFF)
    if want:
        new = _tfns(want)
        if tfns is not None:
            ver.children[ver.children.index(tfns)] = new
        else:                                          # after TCSS (stock order: MATS TXMS TCSS TFNS ARVS ... NAME)
            names = [c.tag for c in ver.children]
            at = names.index("TCSS") + 1 if "TCSS" in names else len(ver.children) - 1
            ver.children.insert(at, new)
    pal_chunks = []
    for p in pals:
        var, tag, palette, default = p[:4]
        private = p[4] if len(p) > 4 else True
        var = var[len("/private/"):] if var.startswith("/private/") else var
        pal_chunks.append(_chunk("PAL ", _cstr(var) + bytes([1 if private else 0]) + _stag(tag) + _cstr(palette) +
                                 struct.pack("<i", int(default))))
    return _form("CSHD", [_form("0001", [ssht, _form("TFAC", pal_chunks)])])


def write_custom_shader(out_path: str | Path, base: bytes | Block | dict, pals: list,
                        tfactors: dict[str, int] | None = None) -> dict[str, Any]:
    """Write a customizable (hue) shader .sht: FORM CSHD/0001 = base SSHT + TFAC palettes (see custom_shader_block).
    Use a hue effect (effect\\h_color2.eft, h_color2_bump.eft, h_color2_specmap.eft ...) whose MAIN texture alpha
    is the hue mask (h_color2: alpha 0 -> MAIN colour, 1 -> HUEB colour)."""
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(serialize_iff(_form("<root>", [custom_shader_block(base, pals, tfactors)])))
    return {"path": str(out), **read_custom_shader(out)}


def read_custom_shader(path: str | Path | bytes) -> dict[str, Any]:
    """Effect, textures, texture factors and palettes of a .sht (SSHT, or CSHD wrapping one)."""
    root = parse_iff(path if isinstance(path, bytes) else Path(path).read_bytes())
    top = root.children[0]
    ssht, pals = top, []
    if top.tag == "CSHD":
        ver = top.forms()[0]
        ssht = ver.forms("SSHT")[0]
        for tfac in ver.forms("TFAC"):
            for c in tfac.chunks("PAL "):
                var, rest = c.data.split(b"\0", 1)
                pal, tail = rest[5:].split(b"\0", 1)
                pals.append({"var": var.decode("latin1"), "private": bool(rest[0]), "tag": _stag_name(rest[1:5]),
                             "palette": pal.decode("latin1"), "default": struct.unpack("<i", tail[:4])[0]})
    sv = ssht.forms()[0]
    textures = {}
    for txms in sv.forms("TXMS"):
        for txm in txms.forms("TXM "):
            v = txm.forms()[0]
            textures[_stag_name(v.first("DATA").data[:4])] = v.first("NAME").data.split(b"\0")[0].decode("latin1")
    tfns = sv.forms("TFNS")
    name = sv.first("NAME")
    return {"kind": top.tag, "effect": name.data.split(b"\0")[0].decode("latin1") if name else None,
            "textures": textures, "tfactors": {k: f"{v:08x}" for k, v in (_read_tfns(tfns[0]) if tfns else {}).items()},
            "pals": pals}


def replace_strings(src: str | Path, out_path: str | Path, mapping: dict[str, str]) -> dict[str, int]:
    """Copy an IFF asset with whole NUL-terminated strings inside its chunks replaced (e.g. a .msh's SPS shader
    NAMEs, a .lod's CHLD mesh paths, an .apt's NAME). A string only matches whole (not as the tail of a longer
    path). Returns the replacement count per old string; raises if one never matched."""
    import re
    root = parse_iff(Path(src).read_bytes())
    counts = {k: 0 for k in mapping}
    pats = {k: re.compile(rb"(?<![\x21-\x7e])" + re.escape(k.encode("latin1")) + rb"\0") for k in mapping}

    def walk(b):
        for c in b.children:
            if c.is_form:
                walk(c)
                continue
            for k, v in mapping.items():
                c.data, n = pats[k].subn(lambda m: v.encode("latin1") + b"\0", c.data)
                counts[k] += n
    walk(root)
    missing = [k for k, n in counts.items() if not n]
    if missing:
        raise ValueError(f"{src}: string(s) not found: {missing}")
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(serialize_iff(root))
    return counts


def write_dds_rgba(out_path: str | Path, w: int, h: int, rgba: bytes | bytearray, mips: bool = True) -> dict[str, Any]:
    """Uncompressed A8R8G8B8 .dds from top-down RGBA bytes, with a box-filtered mip chain (power-of-two sizes)."""
    levels = [bytes(rgba)]
    lw, lh = w, h
    while mips and (lw > 1 or lh > 1):
        src, nw, nh = levels[-1], max(1, lw // 2), max(1, lh // 2)
        dst = bytearray(nw * nh * 4)
        for y in range(nh):
            for x in range(nw):
                for c in range(4):
                    s = 0
                    for dy in (0, 1):
                        for dx in (0, 1):
                            sx, sy = min(lw - 1, 2 * x + dx), min(lh - 1, 2 * y + dy)
                            s += src[(sy * lw + sx) * 4 + c]
                    dst[(y * nw + x) * 4 + c] = s // 4
        levels.append(bytes(dst))
        lw, lh = nw, nh
    flags = 0x100F | (0x20000 if mips else 0)
    hdr = struct.pack("<4sIIIIIII44x", b"DDS ", 124, flags, h, w, w * 4, 0, len(levels))
    pf = struct.pack("<II4sIIIII", 32, 0x41, b"\0\0\0\0", 32, 0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000)
    caps = struct.pack("<IIII4x", 0x1000 | (0x400008 if mips else 0), 0, 0, 0)
    px = bytearray()
    for lv in levels:
        for i in range(0, len(lv), 4):
            px += bytes((lv[i + 2], lv[i + 1], lv[i], lv[i + 3]))
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(hdr + pf + caps + bytes(px))
    return {"path": str(out), "size": [w, h], "mips": len(levels)}


def read_dds_rgba(path: str | Path) -> tuple[int, int, bytearray]:
    """Top mip of a .dds as top-down RGBA bytes: uncompressed 32-bit (A8R8G8B8 / X8R8G8B8) or DXT1/DXT3/DXT5."""
    b = Path(path).read_bytes()
    if b[:4] != b"DDS ":
        raise ValueError(f"{path}: not a .dds")
    h, w = struct.unpack_from("<II", b, 12)
    pf_flags, fourcc, bits = struct.unpack_from("<I4sI", b, 80)
    masks = struct.unpack_from("<4I", b, 92)
    data, out = b[128:], bytearray(w * h * 4)
    if not pf_flags & 0x4:
        if bits != 32:
            raise ValueError(f"{path}: {bits}-bit uncompressed .dds not handled")
        shifts = [(m & -m).bit_length() - 1 if m else None for m in masks]
        for i in range(w * h):
            px = struct.unpack_from("<I", data, i * 4)[0]
            out[i * 4:i * 4 + 4] = bytes(((px >> s) & 0xFF) if s is not None else 255 for s in shifts)
        return w, h, out
    kind = fourcc.decode("latin1")
    if kind not in ("DXT1", "DXT3", "DXT5"):
        raise ValueError(f"{path}: {kind} not handled")
    block = 8 if kind == "DXT1" else 16
    pos = 0

    def c565(c):
        r, g, bb = (c >> 11) & 31, (c >> 5) & 63, c & 31
        return [(r << 3) | (r >> 2), (g << 2) | (g >> 4), (bb << 3) | (bb >> 2)]
    for by in range(0, h, 4):
        for bx in range(0, w, 4):
            alphas = [255] * 16
            if kind == "DXT3":
                bits64 = int.from_bytes(data[pos:pos + 8], "little")
                alphas = [((bits64 >> (4 * i)) & 15) * 17 for i in range(16)]
            elif kind == "DXT5":
                a0, a1 = data[pos], data[pos + 1]
                tbl = [a0, a1] + ([((6 - i) * a0 + (i + 1) * a1) // 7 for i in range(6)] if a0 > a1 else
                                  [((4 - i) * a0 + (i + 1) * a1) // 5 for i in range(4)] + [0, 255])
                bits48 = int.from_bytes(data[pos + 2:pos + 8], "little")
                alphas = [tbl[(bits48 >> (3 * i)) & 7] for i in range(16)]
            cpos = pos + block - 8
            c0, c1, idx = struct.unpack_from("<HHI", data, cpos)
            p0, p1 = c565(c0), c565(c1)
            if c0 > c1 or kind != "DXT1":
                pal = [p0 + [255], p1 + [255], [(2 * x + y) // 3 for x, y in zip(p0, p1)] + [255],
                       [(x + 2 * y) // 3 for x, y in zip(p0, p1)] + [255]]
            else:
                pal = [p0 + [255], p1 + [255], [(x + y) // 2 for x, y in zip(p0, p1)] + [255], [0, 0, 0, 0]]
            for i in range(16):
                x, y = bx + (i & 3), by + (i >> 2)
                if x < w and y < h:
                    px = pal[(idx >> (2 * i)) & 3]
                    o = (y * w + x) * 4
                    out[o:o + 3] = bytes(px[:3])
                    out[o + 3] = px[3] if kind == "DXT1" else alphas[i]
            pos += block
    return w, h, out


def set_floor_edge_types(flr_path: str | Path, rule) -> dict[str, int]:
    """Re-type the open (boundary) edges of a compiled .flr v0006 in place: rule(a, b, edge_type) -> new type for
    the edge from vertex a to b (engine space; 0 uncrossable, 1 crossable, 2 wall base). Portal edges are left
    alone. The TRIS records and the BEDG boundary list (crossable, uncrossable, wall base groups) are rewritten."""
    path = Path(flr_path)
    root = parse_iff(path.read_bytes())
    ver = root.forms("FLOR")[0].forms()[0]
    if _version(ver.tag) != 6:
        raise ValueError(f"{path}: only FLOR 0006 is supported")
    r = Reader(ver.first("VERT").data)
    verts = [r.vec() for _ in range(r.i32())]
    tris_chunk = ver.first("TRIS")
    data = bytearray(tris_chunk.data)
    count = struct.unpack_from("<i", data, 0)[0]
    REC = 60                                   # 3 corners, index, 3 neighbours, normal, 3 edge types, fall, part, 3 portals
    changed = {0: 0, 1: 0, 2: 0}
    groups: list[list[tuple[int, int]]] = [[], [], []]
    for i in range(count):
        off = 4 + i * REC
        corners = struct.unpack_from("<3i", data, off)
        neighbors = struct.unpack_from("<3i", data, off + 16)
        portals = struct.unpack_from("<3i", data, off + 48)
        for k in range(3):
            if neighbors[k] >= 0:
                continue
            et = data[off + 40 + k]
            if portals[k] < 0:
                new = int(rule(verts[corners[k]], verts[corners[(k + 1) % 3]], et))
                if new != et:
                    data[off + 40 + k] = new
                    changed[new] += 1
                    et = new
            if et <= 2:
                groups[{1: 0, 0: 1, 2: 2}[et]].append((i, k))
    tris_chunk.data = bytes(data)
    bedg = bytearray(struct.pack("<i", sum(len(g) for g in groups)))
    for gi, g in enumerate(groups):
        for tri, edge in g:
            bedg += struct.pack("<iiB", tri, edge, 1 if gi == 0 else 0)
    ver.first("BEDG").data = bytes(bedg)
    path.write_bytes(serialize_iff(root))
    return {"to_uncrossable": changed[0], "to_crossable": changed[1], "to_wallbase": changed[2],
            "crossable": len(groups[0]), "uncrossable": len(groups[1]), "wallbase": len(groups[2])}


def floor_seam_edges(flr_path: str | Path, probe: float = 0.03, height_tol: float = 0.05) -> set[tuple]:
    """Open edges of a floor that are seams, not walls: just past the edge (`probe` metres out from its midpoint)
    the floor goes on at the same height (within `height_tol`). They come from pieces welded edge to edge with
    T-junctions (a vertex of one piece in the middle of the other's edge), which leave both sides without
    neighbours, so movement stops there as if at a wall. Holes cut for fixtures and drops to another level are
    not seams. Keys are (a, b) vertex positions rounded to the millimetre."""
    flr = read_flr(flr_path)
    verts, tris = flr["vertices"], flr["tris"]
    cell = 2.0
    grid: dict[tuple[int, int], list[int]] = {}
    for i, t in enumerate(tris):
        xs = [verts[c][0] for c in t["corners"]]
        zs = [verts[c][2] for c in t["corners"]]
        for gx in range(int(math.floor(min(xs) / cell)), int(math.floor(max(xs) / cell)) + 1):
            for gz in range(int(math.floor(min(zs) / cell)), int(math.floor(max(zs) / cell)) + 1):
                grid.setdefault((gx, gz), []).append(i)

    def height_at(x: float, z: float, skip: int) -> list[float]:
        out = []
        for i in grid.get((int(math.floor(x / cell)), int(math.floor(z / cell))), []):
            if i == skip:
                continue
            a, b, c = (verts[k] for k in tris[i]["corners"])
            d = (b[2] - c[2]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[2] - c[2])
            if abs(d) < 1e-12:
                continue
            l1 = ((b[2] - c[2]) * (x - c[0]) + (c[0] - b[0]) * (z - c[2])) / d
            l2 = ((c[2] - a[2]) * (x - c[0]) + (a[0] - c[0]) * (z - c[2])) / d
            l3 = 1.0 - l1 - l2
            if min(l1, l2, l3) >= -1e-6:
                out.append(l1 * a[1] + l2 * b[1] + l3 * c[1])
        return out

    seams = set()
    for i, t in enumerate(tris):
        for k in range(3):
            if t["neighbors"][k] >= 0 or t["portal_ids"][k] >= 0 or t["edge_types"][k] == 1:
                continue
            a, b = verts[t["corners"][k]], verts[t["corners"][(k + 1) % 3]]
            c = verts[t["corners"][(k + 2) % 3]]
            mx, my, mz = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2
            ex, ez = b[0] - a[0], b[2] - a[2]
            length = math.hypot(ex, ez)
            if length < 1e-4:
                continue
            nx, nz = ez / length, -ex / length                 # a side normal; point it away from the third corner
            if (c[0] - mx) * nx + (c[2] - mz) * nz > 0:
                nx, nz = -nx, -nz
            if any(abs(h - my) <= height_tol for h in height_at(mx + nx * probe, mz + nz * probe, i)):
                seams.add((tuple(round(v, 3) for v in a), tuple(round(v, 3) for v in b)))
    return seams


def open_floor_seams(flr_path: str | Path, probe: float = 0.03, height_tol: float = 0.05) -> dict[str, int]:
    """Make the seam edges of a floor (floor_seam_edges) crossable, in place, so walking across a welded seam no
    longer stops as if at a wall. Holes and level changes keep their edge types."""
    seams = floor_seam_edges(flr_path, probe, height_tol)
    if not seams:
        return {"seams": 0}
    out = set_floor_edge_types(flr_path, lambda a, b, et: 1 if (tuple(round(v, 3) for v in a), tuple(round(v, 3) for v in b)) in seams else et)
    return {"seams": len(seams), **out}


def cell_collision_tris(pob_path: str | Path, cell: int = 0) -> list[tuple[tuple[float, float, float], ...]]:
    """Triangles (engine space, as stored) of a POB cell's CMSH collision extent."""
    root = parse_iff(Path(pob_path).read_bytes())
    cells = [b for b in _walk_blocks(root) if b.is_form and b.tag == "CELL"]
    cm = next((b for b in _walk_blocks(cells[cell]) if b.is_form and b.tag == "CMSH"), None)
    if cm is None:
        return []
    vert = next(b for b in _walk_blocks(cm) if b.tag == "VERT")
    indx = next(b for b in _walk_blocks(cm) if b.tag == "INDX")
    v = [struct.unpack_from("<3f", vert.data, i) for i in range(0, len(vert.data), 12)]
    ix = struct.unpack_from(f"<{len(indx.data) // 4}i", indx.data)
    return [(v[ix[i]], v[ix[i + 1]], v[ix[i + 2]]) for i in range(0, len(ix) - 2, 3)]


def set_lod_collision_mesh(lod_path: str | Path, tris: list) -> dict[str, Any]:
    """Give a .lod's APPR a CMSH collision extent (FORM CMSH/0000/IDTL), replacing what is there (stock building
    exteriors such as ply_all_hangar carry one): the object then blocks players on the terrain, which floor edges
    cannot do. tris: engine-space triangles, wound like stock exteriors (cross(B-A, C-A) away from the solid)."""
    path = Path(lod_path)
    root = parse_iff(path.read_bytes())
    ver = root.first("DTLA").forms()[0].first("APPR").forms()[0]
    verts, idx = [], []
    for t in tris:
        for p in t:
            idx.append(len(verts))
            verts.append(tuple(p))
    cmsh = _form("CMSH", [_form("0000", [_idtl(verts, idx)])])
    slot = next(i for i, c in enumerate(ver.children) if c.is_form and c.tag != "EXBX")   # after the extent box
    ver.children[slot] = cmsh
    path.write_bytes(serialize_iff(root))
    return {"lod": str(path), "triangles": len(tris)}


def set_lod_collision_boxes(lod_path: str | Path, boxes: list) -> dict[str, Any]:
    """Give a .lod's APPR a composite box collision extent (DTAL/CPST bound + CMPT of EXBX, like stock gates and
    write_static_lod): unlike a CMSH, which CollisionDetect::testExtents never tests a moving sphere against,
    boxes block players on the terrain. Boxes are Maya space ((x0, y0, z0), (x1, y1, z1))."""
    path = Path(lod_path)
    root = parse_iff(path.read_bytes())
    ver = root.first("DTLA").forms()[0].first("APPR").forms()[0]
    eboxes = [_engine_box(b) for b in boxes]
    lo = tuple(min(b[0][k] for b in eboxes) for k in range(3))
    hi = tuple(max(b[1][k] for b in eboxes) for k in range(3))
    parts = _form("CMPT", [_form("0000", [_form("CPST", [_form("0000", [_exbx(*b) for b in eboxes])])])])
    coll = _form("DTAL", [_form("0000", [_form("CPST", [_form("0000", [_exbx(lo, hi), parts])])])])
    slot = next(i for i, c in enumerate(ver.children) if c.is_form and c.tag != "EXBX")   # after the extent box
    ver.children[slot] = coll
    path.write_bytes(serialize_iff(root))
    return {"lod": str(path), "boxes": len(eboxes)}
