"""Client ground environments for a terrain - the two files GroundEnvironment loads by the terrain's file name:

  terrain/environment/<name>.iff     FORM ENVM / 0000: night sky, stars, sun (+ second sun), moon (+ second moon),
                                     extra celestial bodies (CELS: moons, rings, ships), time lock, skybox,
                                     distant appearances and planets (DIST / PLAN)
  datatables/environment/<name>.iff  a DataTable with one row per (environment family name, weather index):
                                     sky gradient, cloud layers, lighting colour ramps, fog, shadows, environment
                                     maps, ambient sounds and music, wind (EnvironmentBlockManager)

Both are decoded losslessly (unknown chunks kept as bytes) and written back byte-identically. A generic DataTable
codec (FORM DTII 0000/0001) is here too, for other per-planet tables."""

from __future__ import annotations

import copy
import re
import struct
from pathlib import Path
from typing import Any

from ..iff import parse_iff
from .trn import _decode_chunk, _write, chunk, form, TrnError

# ----------------------------------------------------------------------------------------------------------------
# DataTable (sharedUtility DataTable::load_0000 / load_0001)

_BASIC = {"i": "i", "h": "i", "b": "i", "e": "i", "v": "i", "z": "i", "f": "f", "s": "s", "p": "s"}


def _basic(type_spec: str) -> str:
    return _BASIC.get(type_spec[:1].lower(), "s")


def read_datatable(data: bytes) -> dict[str, Any]:
    root = parse_iff(data).children[0]
    if root.tag != "DTII":
        raise TrnError(f"not a DataTable (FORM {root.tag})")
    ver = root.children[0]
    cols, types, rows = (c.data for c in ver.children)
    n = struct.unpack_from("<i", cols, 0)[0]
    names = cols[4:].split(b"\0")[:n]
    if ver.tag == "0001":
        tspecs = [t.decode("latin1") for t in types.split(b"\0")[:n]]
    else:
        tspecs = [{0: "i", 1: "f", 2: "s"}[v] for v in struct.unpack_from(f"<{n}i", types, 0)]
    nrows = struct.unpack_from("<i", rows, 0)[0]
    pos, out_rows = 4, []
    for _ in range(nrows):
        row = []
        for t in tspecs:
            b = _basic(t)
            if b == "i":
                row.append(struct.unpack_from("<i", rows, pos)[0])
                pos += 4
            elif b == "f":
                row.append(struct.unpack_from("<f", rows, pos)[0])
                pos += 4
            else:
                end = rows.index(b"\0", pos)
                row.append(rows[pos:end].decode("latin1"))
                pos = end + 1
        out_rows.append(row)
    return {"version": ver.tag, "columns": [c.decode("latin1") for c in names], "types": tspecs,
            "rows": out_rows}


def write_datatable(t: dict[str, Any]) -> bytes:
    ver = t.get("version", "0001")
    cols = struct.pack("<i", len(t["columns"])) + b"".join(c.encode("latin1") + b"\0" for c in t["columns"])
    if ver == "0001":
        types = b"".join(s.encode("latin1") + b"\0" for s in t["types"])
    else:
        types = b"".join(struct.pack("<i", {"i": 0, "f": 1, "s": 2}[_basic(s)]) for s in t["types"])
    rows = bytearray(struct.pack("<i", len(t["rows"])))
    for row in t["rows"]:
        for v, s in zip(row, t["types"]):
            b = _basic(s)
            rows += struct.pack("<i", int(v)) if b == "i" else struct.pack("<f", float(v)) if b == "f" else \
                str(v).encode("latin1") + b"\0"
    return form("DTII", form(ver, chunk("COLS", cols), chunk("TYPE", types), chunk("ROWS", bytes(rows))))


def _crc(s: str) -> int:
    crc = 0xFFFFFFFF
    for ch in s.encode("latin1"):
        crc ^= ch << 24
        for _ in range(8):
            crc = ((crc << 1) ^ 0x04C11DB7) & 0xFFFFFFFF if crc & 0x80000000 else (crc << 1) & 0xFFFFFFFF
    return crc ^ 0xFFFFFFFF


def _unquote(s: str) -> str:
    return s[1:-1] if len(s) >= 2 and s[0] == s[-1] == '"' else s


def _mangle(spec: str, value: str) -> Any:
    """DataTableColumnType::mangleValue + DataTableWriter::_getNewCell for one .tab cell."""
    t = spec[:1].lower()
    default = spec[spec.index("[") + 1:spec.rindex("]")] if "[" in spec and spec.endswith("]") else ""
    if value == "":
        if default in ("required", "unique"):
            raise TrnError(f"empty cell in a {default} column ({spec})")
        value = default
    if t in ("s", "p"):
        return value
    if t == "f":
        m = re.match(r"\s*[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?", value)     # atof
        return float(m.group(0)) if m else 0.0
    if t == "i":
        m = re.match(r"\s*([-+]?)(0[xX][0-9a-fA-F]+|\d+)", value)               # strtol(.., 0)
        return int(m.group(1) + m.group(2), 0) if m else 0
    if t == "b":
        if value not in ("0", "1"):
            raise TrnError(f"bool cell {value!r}")
        return int(value)
    if t == "h":
        v = _crc(value.lower().replace("\\", "/")) if value else 0
        return v - (1 << 32) if v >= 1 << 31 else v
    if t == "e":
        labels = dict(p.split("=") for p in spec[spec.index("(") + 1:spec.index(")")].split(",") if "=" in p)
        if value not in labels:
            raise TrnError(f"enum value {value!r} not in {sorted(labels)}")
        return int(labels[value], 0)
    raise TrnError(f"column type {spec!r} is not supported here (use DataTableTool)")


def compile_tab(text: str) -> dict[str, Any]:
    """A .tab source (column names, type specs, rows; tab separated) as a DataTable (DTII 0001) model, with the
    engine writer's rules: comment columns dropped, empty cells take the column default, enums / bools / hashes
    turned into ints."""
    lines = [ln.rstrip("\r") for ln in text.split("\n")]
    while lines and not lines[-1].strip():
        lines.pop()
    names = [_unquote(c) for c in lines[0].split("\t")]
    specs = [_unquote(c) for c in lines[1].split("\t")]
    if len(names) != len(specs):
        raise TrnError("column names and types differ in count")
    keep = [i for i, s in enumerate(specs) if s[:1].lower() != "c"]
    rows = []
    for ln in lines[2:]:
        cells = ln.split("\t")
        cells += [""] * (len(names) - len(cells))
        rows.append([_mangle(specs[i], _unquote(cells[i])) for i in keep])
    return {"version": "0001", "columns": [names[i] for i in keep], "types": [specs[i] for i in keep], "rows": rows}


# ----------------------------------------------------------------------------------------------------------------
# environment table: friendly names for the EnvironmentBlockManager columns (in file order)

ENV_COLUMNS = [
    ("family", "Environment Family Name"), ("weather_index", "Weather Index"),
    ("sky_gradient", "Gradient Sky Texture (256x256 dds)"),
    ("cloud_bottom_shader", "Cloud Layer Bottom Shader (sht)"), ("cloud_bottom_size", "Cloud Layer Bottom Shader Size"),
    ("cloud_bottom_speed", "Cloud Layer Bottom Speed"),
    ("cloud_top_shader", "Cloud Layer Top Shader (sht)"), ("cloud_top_size", "Cloud Layer Top Shader Size"),
    ("cloud_top_speed", "Cloud Layer Top Speed"),
    ("lighting_ramps", "Lighting Color Ramps (256x8 tga)"), ("shadows", "Shadows Enabled"), ("fog", "Fog Enabled"),
    ("fog_min_density", "Minimum Fog Density"), ("fog_max_density", "Maximum Fog Density"),
    ("camera_appearance", "Attached Camera AppearanceTemplate"),
    ("day_environment_map", "Day Environment Map (dds)"), ("night_environment_map", "Night Environment Map (dds)"),
    ("day_sound_1", "Day Ambient Sound 1 (2d .snd)"), ("day_sound_2", "Day Ambient Sound 2 (2d .snd)"),
    ("night_sound_1", "Night Ambient Sound 1 (2d .snd)"), ("night_sound_2", "Night Ambient Sound 2 (2d .snd)"),
    ("first_music", "First Music (2d .snd)"), ("sunrise_music", "Sunrise Music (2d .snd)"),
    ("sunset_music", "Sunset Music (2d .snd)"), ("wind_speed_scale", "Wind Speed Scale"),
]
_ALIAS = {a: c for a, c in ENV_COLUMNS}
_COLUMN_ALIAS = {c: a for a, c in ENV_COLUMNS}


def env_rows(table: dict) -> list[dict[str, Any]]:
    """Rows as {friendly name: value} (unknown columns keep their own names)."""
    return [{_COLUMN_ALIAS.get(c, c): v for c, v in zip(table["columns"], row)} for row in table["rows"]]


def set_env_row(table: dict, values: dict[str, Any], template_family: str | None = None) -> dict[str, Any]:
    """Add or change the row for (family, weather_index): values use friendly or real column names; a new row
    starts as a copy of `template_family`'s row with the same weather index (else the first row)."""
    cols = table["columns"]
    idx = {c: i for i, c in enumerate(cols)}
    real = {}
    for k, v in values.items():
        c = _ALIAS.get(k, k)
        if c not in idx:
            raise TrnError(f"environment tables have no column {k!r}; columns: {[a for a, _ in ENV_COLUMNS]}")
        real[c] = v
    fam_col, wi_col = idx["Environment Family Name"], idx["Weather Index"]
    fam = real.get("Environment Family Name")
    if fam is None:
        raise TrnError("a row needs its environment family name (family)")
    wi = int(real.get("Weather Index", 0))
    row = next((r for r in table["rows"] if r[fam_col] == fam and r[wi_col] == wi), None)
    if row is None:
        src = next((r for r in table["rows"] if r[fam_col] == (template_family or "") and r[wi_col] == wi), None) \
            or next((r for r in table["rows"] if r[wi_col] == wi), None) or table["rows"][0]
        row = list(src)
        row[fam_col], row[wi_col] = fam, wi
        table["rows"].append(row)
    for c, v in real.items():
        row[idx[c]] = v
    return dict(zip([_COLUMN_ALIAS.get(c, c) for c in cols], row))


# ----------------------------------------------------------------------------------------------------------------
# ENVM (GroundEnvironment::Data::load_0000)

_BODY = [("shader", "s"), ("size", "f"), ("glow_shader", "s"), ("glow_size", "f")]
ENVM_CHUNKS: dict[str, tuple[str, list]] = {
    "NSKY": ("night_sky", [("shader", "s")]),
    "STAR": ("stars", [("color_ramp", "s"), ("count", "i")]),
    "SUN ": ("sun", _BODY),
    "SSUN": ("second_sun", _BODY + [("yaw", "f"), ("pitch", "f")]),
    "MOON": ("moon", _BODY),
    "SMOO": ("second_moon", _BODY + [("yaw", "f"), ("pitch", "f")]),
    "CELS": ("celestial", _BODY + [("yaw", "f"), ("pitch", "f"), ("pitch_direction", "f"), ("cycle_time", "f")]),
    "TLOK": ("time_lock", [("locked", "b8"), ("time", "f")]),
    "SKYB": ("skybox", [("cube_map", "b8"), ("texture_mask", "s")]),
}
_DIST = [("appearance", "s"), ("direction_x", "f"), ("direction_y", "f"), ("direction_z", "f"), ("orientation_x", "f"),
         ("orientation_y", "f"), ("orientation_z", "f"), ("infinite", "B"), ("flag", "i")]
_PLAN = [("appearance", "s"), ("direction_x", "f"), ("direction_y", "f"), ("direction_z", "f"), ("orientation_x", "f"),
         ("orientation_y", "f"), ("orientation_z", "f"), ("halo_roll", "f"), ("halo_scale", "f"), ("infinite", "B")]
KIND_TAG = {v[0]: k for k, v in ENVM_CHUNKS.items()} | {"distant": "DIST", "planet": "PLAN"}
SINGLE = {"night_sky", "stars", "sun", "second_sun", "moon", "second_moon", "time_lock", "skybox"}


def read_envm(data: bytes) -> dict[str, Any]:
    root = parse_iff(data).children[0]
    if root.tag != "ENVM":
        raise TrnError(f"not an environment file (FORM {root.tag})")
    ver = root.children[0]
    entries = []
    for c in ver.children:
        try:
            if not c.is_form and c.tag in ENVM_CHUNKS:
                kind, spec = ENVM_CHUNKS[c.tag]
                e = {"kind": kind, **_decode_chunk(c.data, spec)}
            elif c.is_form and c.tag in ("DIST", "PLAN"):
                spec = _DIST if c.tag == "DIST" else _PLAN
                e = {"kind": "distant" if c.tag == "DIST" else "planet",
                     **_decode_chunk(c.children[0].data, spec)}
            else:
                raise TrnError("unknown")
            if _encode_entry(e) != (c.data if c.is_form else chunk(c.tag, c.data)):
                raise TrnError("re-encoding differs")
        except (TrnError, struct.error, ValueError, IndexError):
            e = {"kind": "raw", "tag": c.tag, "raw": c.data if c.is_form else chunk(c.tag, c.data)}
        entries.append(e)
    return {"version": ver.tag, "entries": entries}


def _encode_entry(e: dict) -> bytes:
    if e["kind"] == "raw":
        return e["raw"]
    if e["kind"] in ("distant", "planet"):
        tag, spec = ("DIST", _DIST) if e["kind"] == "distant" else ("PLAN", _PLAN)
        return form(tag, chunk("0000", _write(spec, e)))
    tag = KIND_TAG[e["kind"]]
    return chunk(tag, _write(ENVM_CHUNKS[tag][1], e))


def write_envm(m: dict) -> bytes:
    return form("ENVM", form(m.get("version", "0000"), *[_encode_entry(e) for e in m["entries"]]))


def envm_defaults(kind: str) -> dict[str, Any]:
    tag = KIND_TAG[kind]
    spec = _DIST if tag == "DIST" else _PLAN if tag == "PLAN" else ENVM_CHUNKS[tag][1]
    base = {"s": "", "f": 0.0, "i": 0, "B": 0, "b8": False}
    out = {"kind": kind, **{n: base[t] for n, t in spec}}
    if kind in ("sun", "moon", "second_sun", "second_moon", "celestial"):
        out["size"] = 0.5
    if kind == "planet":
        out["halo_scale"] = 1.0
    return out


def set_envm(m: dict, kind: str, values: dict | None, index: int | None = None) -> dict | None:
    """Set a single entry (sun, moon, stars, ...: values None removes it) or add / change / remove a celestial,
    distant appearance or planet (index None adds; values None with an index removes). Angles are degrees."""
    if kind not in KIND_TAG:
        raise TrnError(f"unknown sky entry {kind!r}; kinds: {sorted(KIND_TAG)}")
    entries = m["entries"]
    if kind in SINGLE:
        cur = next((e for e in entries if e["kind"] == kind), None)
        if values is None:
            if cur is not None:
                entries.remove(cur)
            return None
        if cur is None:
            cur = envm_defaults(kind)
            entries.append(cur)
    else:
        same = [e for e in entries if e["kind"] == kind]
        if index is None:
            if values is None:
                raise TrnError("give an index to remove")
            cur = envm_defaults(kind)
            entries.append(cur)
        else:
            if not 0 <= index < len(same):
                raise TrnError(f"{kind} index {index} out of range ({len(same)})")
            cur = same[index]
            if values is None:
                entries.remove(cur)
                return None
    bad = set(values) - set(cur) - {"kind"}
    if bad:
        raise TrnError(f"{kind} has no {sorted(bad)}; fields: {sorted(k for k in cur if k != 'kind')}")
    cur.update(values)
    return cur


# ----------------------------------------------------------------------------------------------------------------
# both files

def paths(game_root: str | Path, name: str) -> tuple[Path, Path]:
    root = Path(game_root)
    return root / "terrain" / "environment" / f"{name}.iff", root / "datatables" / "environment" / f"{name}.iff"


def load(name: str, roots: list[str | Path]) -> tuple[dict, dict, list[str]]:
    """The sky and table of `name`, from the first root that has each."""
    sky = table = None
    found = []
    for r in roots:
        s, t = paths(r, name)
        if sky is None and s.exists():
            sky = read_envm(s.read_bytes())
            found.append(str(s))
        if table is None and t.exists():
            table = read_datatable(t.read_bytes())
            found.append(str(t))
    if sky is None or table is None:
        raise TrnError(f"no environment {name!r} (sky {'found' if sky else 'missing'}, table "
                       f"{'found' if table else 'missing'}) in {roots}")
    return sky, table, found


def save(name: str, sky: dict, table: dict, out_root: str | Path) -> list[str]:
    s, t = paths(out_root, name)
    for p, data in ((s, write_envm(sky)), (t, write_datatable(table))):
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    return [str(s), str(t)]


def summary(sky: dict, table: dict) -> dict[str, Any]:
    return {"sky": [{k: v for k, v in e.items() if k != "raw"} | ({"raw_bytes": len(e["raw"])} if "raw" in e else {})
                    for e in sky["entries"]],
            "families": sorted({r[0] for r in table["rows"]}),
            "rows": env_rows(table)}


def check_families(table: dict, families: list[str]) -> list[str]:
    """Environment family names of a terrain that have no weather-0 row (EnvironmentBlockManager falls back to its
    default block for them)."""
    have = {(r[0], r[1]) for r in table["rows"]}
    return [f for f in families if (f, 0) not in have]


def copy_from(template: str, roots: list[str | Path]) -> tuple[dict, dict]:
    sky, table, _ = load(template, roots)
    return copy.deepcopy(sky), copy.deepcopy(table)
