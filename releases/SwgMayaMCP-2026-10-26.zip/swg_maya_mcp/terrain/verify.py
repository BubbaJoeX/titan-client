"""Check a terrain in the offline development client through the DevBridge: put the .trn on the client's search
path (<export root>/terrain/<name>.trn), load it with /scene load, warp to sample areas, read the client's own
generated heights (bridge "terrain" command) and compare them with this package's generator.

Launching a client rewrites %LOCALAPPDATA%/SwgTitan/devbridge.json, which every other bridge user reads; a client
launched here therefore keeps its token to itself (PinnedBridge) and the previous file is put back, so other
sessions' swg_client_* tools stay on their own client."""

from __future__ import annotations

import json
import math
import shutil
import time
from pathlib import Path
from typing import Any

from .. import client
from . import generator
from .trn import TerrainDoc


class PinnedBridge(client.ClientBridge):
    """A bridge to one known client (port + token), independent of the shared token file."""

    def __init__(self, info: dict[str, Any]):
        super().__init__()
        self.pinned = dict(info)

    def _connect(self) -> None:
        if self.sock is not None:
            return
        import socket
        self.info = dict(self.pinned)
        try:
            self.sock = socket.create_connection(("127.0.0.1", int(self.info["port"])), timeout=5.0)
        except OSError as exc:
            raise client.ClientBridgeError(f"cannot connect to the pinned client on port {self.info['port']} "
                                           f"(pid {self.info.get('pid')}): {exc}") from None


_pinned: dict[int, PinnedBridge] = {}


def launch_own(port: int, export_root: str) -> dict[str, Any]:
    """Start a client on `port`, pin its token, restore the shared token file."""
    previous = client.TOKEN_FILE.read_bytes() if client.TOKEN_FILE.exists() else None
    info = client.launch(port, export_root)
    mine = json.loads(client.TOKEN_FILE.read_text(encoding="utf-8"))
    if previous is not None:
        client.TOKEN_FILE.write_bytes(previous)
    _pin_file(port).write_text(json.dumps(mine), encoding="utf-8")
    _pinned[port] = PinnedBridge(mine)
    return {**info, "pinned": True, "token_file_restored": previous is not None}


def _pin_file(port: int) -> Path:
    """Per-port token of a client launched here (same private folder as devbridge.json)."""
    return client.TOKEN_FILE.with_name(f"devbridge_{port}.json")


def bridge_for(port: int | None) -> client.ClientBridge:
    """The pinned bridge for a client launched here (also by an earlier server run), else the shared one."""
    if port is not None and port not in _pinned and _pin_file(port).exists():
        info = json.loads(_pin_file(port).read_text(encoding="utf-8"))
        if client._pid_alive(int(info.get("pid", 0))):
            _pinned[port] = PinnedBridge(info)
    if port is not None and port in _pinned:
        return _pinned[port]
    b = client.ClientBridge()
    if port is not None:
        info = client._token_info()
        if int(info.get("port", -1)) != port:
            raise client.ClientBridgeError(f"no client launched here on port {port} and the token file points at "
                                           f"port {info.get('port')}; launch one (launch=True)")
    return b


def _wait_scene(b: client.ClientBridge, timeout: float = 240.0, terrain: str = "") -> dict[str, Any]:
    """Wait until a scene is up. A client still at the login screen (no player, not loading) is sent into the
    offline scene with the bridge's loadscene command (terrain default: simple)."""
    deadline = time.time() + timeout
    last = None
    asked = False
    while time.time() < deadline:
        try:
            st = b.request("state", timeout=30.0).get("result", {})
            last = st
            if not st.get("scene_loading") and st.get("player"):
                return st
            if not asked and not st.get("scene_loading") and not st.get("player") and st.get("frame", 0) > 50:
                b.request("loadscene", timeout=60.0, **({"terrain": terrain} if terrain else {}))
                asked = True
        except client.ClientBridgeError:
            pass
        time.sleep(1.0)
    raise client.ClientBridgeError(f"the scene did not finish loading within {timeout:.0f} s (last state {last})")


def deploy(doc_path: str | Path, export_root: str | Path) -> tuple[Path, str]:
    """Copy the .trn to <export_root>/terrain/ when it is elsewhere; returns (deployed path, scene name)."""
    src = Path(doc_path)
    dst_dir = Path(export_root) / "terrain"
    dst = dst_dir / src.name
    if src.resolve() != dst.resolve():
        dst_dir.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
    return dst, src.stem


def sample_points(doc: TerrainDoc, center: tuple[float, float], radius: float, step: float | None = None,
                  pole_aligned: bool = True) -> list:
    """Points in a square round `center`. Pole-aligned (default): multiples of the pole spacing, where the client's
    height is a generated pole. Otherwise exactly every `step` metres from the centre (between poles too, e.g. to
    test a hole's edge geometry)."""
    d = generator.pole_spacing(doc)
    if pole_aligned:
        step = max(d, round((step or max(d, radius / 8)) / d) * d)
        cx, cz = round(center[0] / d) * d, round(center[1] / d) * d
    else:
        step = step or d / 2
        cx, cz = center
    n = int(radius // step)
    return [[cx + i * step, cz + j * step] for j in range(-n, n + 1) for i in range(-n, n + 1)]


def place_buildings(doc: TerrainDoc, buildings: list[dict], resolve, b: client.ClientBridge | None = None,
                    spawn: bool = False) -> tuple[TerrainDoc, list[dict]]:
    """Add building terrain layers to `doc` like the client (generator.place_layer). buildings: [{layer: .lay
    path, x, z, yaw (deg), height (default: the client's height at the origin when a bridge is given, else the
    generator's), template (spawned with /scene objectCreate when spawn=True)}]."""
    info = []
    for bd in buildings:
        x, z, yaw = float(bd["x"]), float(bd["z"]), float(bd.get("yaw", 0.0))
        if spawn and b is not None and bd.get("template"):
            b.request("exec", line=f"/scene objectCreate {bd['template']} {x} {z} {yaw}", timeout=30.0)
            time.sleep(3.0)
        height = bd.get("height")
        if height is None and b is not None:
            height = b.request("terrain", points=[[x, z]], timeout=30.0).get("result", [None])[0]
        lay = TerrainDoc.load(resolve(bd["layer"]))
        doc = generator.place_layer(doc, lay, x, z, yaw, height)
        info.append({"layer": bd["layer"], "x": x, "z": z, "yaw": yaw, "height": height})
    return doc, info


def compare(doc: TerrainDoc, b: client.ClientBridge, areas: list[dict], tolerance: float = 0.25,
            data_roots: list[str] | None = None, warp: bool = True, settle_seconds: float = 4.0) -> list[dict]:
    """Client heights against client_heights over each area ({center, radius, step, pole_aligned})."""
    results = []
    for area in areas:
        cx, cz = area.get("center", [0.0, 0.0])
        pts = sample_points(doc, (cx, cz), float(area.get("radius", 64.0)), area.get("step"),
                            area.get("pole_aligned", True))
        expect = generator.heights_at(doc, pts, data_roots=data_roots)
        if warp:
            ground = next((e for e in expect if e is not None), 0.0)
            b.request("exec", line=f"/warpme {cx} {ground + 2.0} {cz}", timeout=30.0)
            time.sleep(settle_seconds)
        got: list = []
        for i in range(0, len(pts), 4000):
            r = b.request("terrain", points=pts[i:i + 4000], timeout=60.0)
            got += r.get("result", [])
        diffs, worst, holes = [], [], []
        for p, e, g in zip(pts, expect, got):
            if g is None or e is None:
                if (g is None) != (e is None):
                    holes.append({"x": p[0], "z": p[1], "expected": e, "client": g})
                continue
            diffs.append(abs(g - e))
            worst.append((abs(g - e), p, e, g))
        worst.sort(key=lambda t: -t[0])
        n_holes = sum(1 for e, g in zip(expect, got) if e is None and g is None)
        stats = {"center": [cx, cz], "points": len(pts), "compared": len(diffs), "holes_both": n_holes,
                 "mismatched_holes": len(holes), "hole_mismatches": holes[:8],
                 "max_abs_diff": max(diffs) if diffs else None,
                 "mean_abs_diff": sum(diffs) / len(diffs) if diffs else None,
                 "within_tolerance": sum(1 for d in diffs if d <= tolerance),
                 "worst": [{"x": p[0], "z": p[1], "expected": round(e, 3), "client": g} for _, p, e, g in worst[:5]]}
        stats["ok"] = bool(diffs) and stats["within_tolerance"] == len(diffs) and not holes
        results.append(stats)
    return results


def verify(doc_path: str | Path, export_root: str, port: int | None = None, launch: bool = False,
           areas: list[dict] | None = None, tolerance: float = 0.25, load: bool = True,
           data_roots: list[str] | None = None, settle_seconds: float = 4.0, buildings: list[dict] | None = None,
           resolve=Path, spawn: bool = True) -> dict[str, Any]:
    """Load the terrain in the client and compare heights. `areas`: [{"center": [x, z], "radius": r, "step": s,
    "pole_aligned": bool}] (default: the map centre, 64 m). `buildings` (see place_buildings) are spawned after the
    load and their terrain layers added to the expectation. Returns per-area statistics and the worst points."""
    doc = TerrainDoc.load(doc_path)
    out: dict[str, Any] = {}
    if load:
        deployed, scene = deploy(doc_path, export_root)
        out.update(deployed=str(deployed), scene=scene)
    if launch and (port is None or port not in _pinned):
        out["launched"] = launch_own(port or client.DEFAULT_PORT + 7, export_root)
        port = out["launched"]["port"]
    b = bridge_for(port)
    out["state_before"] = _wait_scene(b)
    if load:
        reply = b.request("exec", line=f"/scene load {out['scene']}", timeout=60.0)
        out["load_output"] = reply.get("result", "")
        time.sleep(2.0)
        out["state_after_load"] = _wait_scene(b)
    if buildings:
        doc, out["buildings"] = place_buildings(doc, buildings, resolve, b, spawn)
    out["areas"] = compare(doc, b, areas or [{"center": [0.0, 0.0], "radius": 64.0}], tolerance, data_roots,
                           settle_seconds=settle_seconds)
    out["ok"] = all(r["ok"] for r in out["areas"])
    out["port"] = port
    return out
