"""Lossless reader/writer for procedural terrain files (.trn, FORM PTAT) and terrain layer files (.lay).

The model is plain Python data (dicts / lists / numbers / strings / bytes) that mirrors the engine's own classes
(sharedTerrain TerrainGenerator, Layer, Boundary*, Filter*, Affector*, *Group, BakedTerrain, PackedIntegerMap).
Every record is decoded with the exact layout of its version (the engine's load_XXXX) and re-encoded the same way;
a record whose re-encoding does not reproduce its original bytes (an unknown version, trailing data) is kept as
raw bytes instead, so a file always writes back byte-identically. New records are written in the engine's current
save() versions (LATEST).

Layout notes (all little-endian; strings are NUL-terminated latin-1):
  PTAT/<0013|0014|0015>: DATA (map + flora tiling parameters), TGEN, BakedTerrain, [0015: PIMP flora map, PFPM
  flora height map]. TGEN/0000: SGRP shader families, FGRP flora, RGRP radial flora, EGRP environment, MGRP
  fractal families, [MGRP bitmap families], LYRS (root layers). A .lay is SGRP FGRP RGRP EGRP MGRP LAYR at the root.
  LAYR/0003: IHDR (active, name), ADTA (invert boundaries, invert filters, expanded, notes), then boundaries,
  filters, affectors and sublayers in file order (the editor saves them grouped in that order).
"""

from __future__ import annotations

import copy
import struct
from pathlib import Path
from typing import Any, Iterator

from ..iff import Block, parse_iff

# ----------------------------------------------------------------------------------------------------------------
# tag tables (TerrainGeneratorType.def, TerrainGeneratorLoader)

BOUNDARIES = {"BCIR": "circle", "BREC": "rectangle", "BPOL": "polygon", "BPLN": "polyline"}
FILTERS = {"FHGT": "height", "FFRA": "fractal", "FSLP": "slope", "FDIR": "direction", "FSHD": "shader",
           "FBIT": "bitmap"}
AFFECTORS = {
    "AHCN": "height_constant", "AHFR": "height_fractal", "AHTR": "height_terrace",
    "ACCN": "color_constant", "ACRH": "color_ramp_height", "ACRF": "color_ramp_fractal",
    "ASCN": "shader_constant", "ASRP": "shader_replace",
    "AFSC": "flora_static_collidable", "AFSN": "flora_static_non_collidable",
    "AFDN": "flora_dynamic_near", "AFDF": "flora_dynamic_far",
    "AEXC": "exclude", "APAS": "passable", "AROA": "road", "ARIV": "river", "AENV": "environment",
    "ARIB": "ribbon",
}
# tags the loader still skips (no longer used by the engine)
OBSOLETE = {"BALL", "BSPL", "AHSM", "AHBM", "ACBM", "ASBM", "AFBM", "AFCN", "ARCN"}
TYPE_TO_TAG = {**{v: k for k, v in BOUNDARIES.items()}, **{v: k for k, v in FILTERS.items()},
               **{v: k for k, v in AFFECTORS.items()}}

# versions the engine's save() writes today
LATEST = {"BCIR": "0002", "BREC": "0004", "BPOL": "0007", "BPLN": "0003",
          "FHGT": "0002", "FFRA": "0005", "FSLP": "0002", "FDIR": "0000", "FSHD": "0000", "FBIT": "0001",
          "AHCN": "0000", "AHFR": "0003", "AHTR": "0004", "ACCN": "0000", "ACRH": "0000", "ACRF": "0001",
          "ASCN": "0001", "ASRP": "0001", "AFSC": "0004", "AFSN": "0004", "AFDN": "0002", "AFDF": "0002",
          "AEXC": "0000", "APAS": "0000", "AROA": "0006", "ARIV": "0006", "AENV": "0000", "ARIB": "0005",
          "LAYR": "0003", "SGRP": "0006", "FGRP": "0008", "RGRP": "0004", "EGRP": "0002", "MGRP": "0000",
          "PTAT": "0015", "BAKE": "0001"}

FEATHER_FUNCTIONS = ["linear", "ease_in", "ease_out", "ease_in_out"]
OPERATIONS = ["replace", "add", "subtract", "multiply"]
WATER_TYPES = {-1: "invalid", 0: "water", 1: "lava"}
COMBINATION_RULES = ["add", "multiply", "crest", "turbulence", "crest_clamp", "turbulence_clamp"]


class TrnError(ValueError):
    pass


# ----------------------------------------------------------------------------------------------------------------
# field codec: a spec is a list of (name, type); type is one of
#   i int32, I uint32, f float32, B uint8, b int32 bool, b8 uint8 bool, s string, rgb 3 x uint8,
#   pts int32 count + (x, z) floats, flist int32 count + floats, ptsh int32 count + (x, z, height) floats,
#   ("list", spec) int32 count + records

class _Reader:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def take(self, fmt: str):
        v = struct.unpack_from(fmt, self.data, self.pos)
        self.pos += struct.calcsize(fmt)
        return v

    def string(self) -> str:
        end = self.data.index(b"\0", self.pos)
        s = self.data[self.pos:end].decode("latin1")
        self.pos = end + 1
        return s

    def left(self) -> int:
        return len(self.data) - self.pos


def _read(r: _Reader, spec: list) -> dict:
    out: dict[str, Any] = {}
    for name, typ in spec:
        if isinstance(typ, tuple):
            n = r.take("<i")[0]
            out[name] = [_read(r, typ[1]) for _ in range(n)]
        elif typ == "i":
            out[name] = r.take("<i")[0]
        elif typ == "I":
            out[name] = r.take("<I")[0]
        elif typ == "f":
            out[name] = r.take("<f")[0]
        elif typ == "B":
            out[name] = r.take("<B")[0]
        elif typ == "b":
            v = r.take("<i")[0]
            out[name] = bool(v) if v in (0, 1) else v
        elif typ == "b8":
            v = r.take("<B")[0]
            out[name] = bool(v) if v in (0, 1) else v
        elif typ == "s":
            out[name] = r.string()
        elif typ == "rgb":
            out[name] = list(r.take("<3B"))
        elif typ == "pts":
            n = r.take("<i")[0]
            out[name] = [list(r.take("<2f")) for _ in range(n)]
        elif typ == "ptsh":
            n = r.take("<i")[0]
            out[name] = [list(r.take("<3f")) for _ in range(n)]
        elif typ == "flist":
            n = r.take("<i")[0]
            out[name] = list(r.take(f"<{n}f")) if n else []
        else:
            raise TrnError(f"bad field type {typ}")
    return out


def _bool32(v) -> bytes:
    return struct.pack("<i", int(v) if not isinstance(v, bool) else (1 if v else 0))


def _write(spec: list, d: dict) -> bytes:
    out = bytearray()
    for name, typ in spec:
        v = d[name]
        if isinstance(typ, tuple):
            out += struct.pack("<i", len(v))
            for rec in v:
                out += _write(typ[1], rec)
        elif typ == "i":
            out += struct.pack("<i", int(v))
        elif typ == "I":
            out += struct.pack("<I", int(v) & 0xFFFFFFFF)
        elif typ == "f":
            out += struct.pack("<f", float(v))
        elif typ == "B":
            out += struct.pack("<B", int(v))
        elif typ == "b":
            out += _bool32(v)
        elif typ == "b8":
            out += struct.pack("<B", int(v) if not isinstance(v, bool) else (1 if v else 0))
        elif typ == "s":
            out += str(v).encode("latin1") + b"\0"
        elif typ == "rgb":
            out += struct.pack("<3B", *[int(c) for c in v])
        elif typ == "pts":
            out += struct.pack("<i", len(v)) + b"".join(struct.pack("<2f", float(p[0]), float(p[1])) for p in v)
        elif typ == "ptsh":
            out += struct.pack("<i", len(v)) + b"".join(
                struct.pack("<3f", float(p[0]), float(p[1]), float(p[2])) for p in v)
        elif typ == "flist":
            out += struct.pack("<i", len(v)) + (struct.pack(f"<{len(v)}f", *[float(x) for x in v]) if v else b"")
        else:
            raise TrnError(f"bad field type {typ}")
    return bytes(out) + d.get("_trailing", b"")


def _decode_chunk(data: bytes, spec: list) -> dict:
    """Read a chunk with its version's layout. Bytes after the layout (stock files have a few records written by an
    older editor build) are kept as "_trailing": the engine never reads them, but they are written back."""
    r = _Reader(data)
    out = _read(r, spec)
    if r.left():
        out["_trailing"] = data[r.pos:]
    return out


# ----------------------------------------------------------------------------------------------------------------
# IFF byte helpers

def chunk(tag: str, payload: bytes) -> bytes:
    return tag.encode("latin1") + struct.pack(">I", len(payload)) + payload


def form(tag: str, *children: bytes) -> bytes:
    body = tag.encode("latin1") + b"".join(children)
    return b"FORM" + struct.pack(">I", len(body)) + body


def _block_bytes(b: Block) -> bytes:
    return b.data if b.is_form else chunk(b.tag, b.data)


def _version_form(b: Block) -> Block:
    if len(b.children) != 1 or not b.children[0].is_form:
        raise TrnError(f"{b.tag}: expected one version form")
    return b.children[0]


# ----------------------------------------------------------------------------------------------------------------
# layer item layouts: (tag, version) -> (layout, spec)
#   D: chunk DATA;  P: FORM DATA { PARM };  H: FORM DATA { [HDTA], DATA };  R: FORM DATA { DATA }

_FF = [("feather_function", "i"), ("feather_distance", "f")]
_WATER_REC = [("local_water_table", "b"), ("local_global_water_table", "b"), ("water_height", "f"),
              ("water_shader_size", "f"), ("water_shader", "s")]
_FLORA = [("family_id", "i"), ("operation", "i"), ("remove_all", "b"), ("density_override", "b"),
          ("density_override_density", "f")]

LAYOUTS: dict[tuple[str, str], tuple[str, list]] = {
    # boundaries
    ("BCIR", "0002"): ("D", [("center_x", "f"), ("center_z", "f"), ("radius", "f")] + _FF),
    ("BREC", "0002"): ("D", [("x0", "f"), ("z0", "f"), ("x1", "f"), ("z1", "f")] + _FF),
    ("BREC", "0003"): ("D", [("x0", "f"), ("z0", "f"), ("x1", "f"), ("z1", "f")] + _FF + _WATER_REC),
    ("BREC", "0004"): ("D", [("x0", "f"), ("z0", "f"), ("x1", "f"), ("z1", "f")] + _FF + _WATER_REC
                       + [("water_type", "i")]),
    ("BPOL", "0005"): ("D", [("points", "pts")] + _FF + [("local_water_table", "b"), ("water_height", "f"),
                                                         ("water_shader_size", "f"), ("water_shader", "s")]),
    ("BPOL", "0007"): ("D", [("points", "pts")] + _FF + [("local_water_table", "b"), ("water_height", "f"),
                                                         ("water_shader_size", "f"), ("water_type", "i"),
                                                         ("water_shader", "s")]),
    ("BPLN", "0001"): ("D", [("points", "pts")] + _FF + [("width", "f")]),
    ("BPLN", "0003"): ("D", [("points", "pts")] + _FF + [("width", "f")]),
    # filters
    ("FHGT", "0002"): ("D", [("low_height", "f"), ("high_height", "f")] + _FF),
    ("FFRA", "0005"): ("P", [("family_id", "i")] + _FF + [("low", "f"), ("high", "f"), ("scale_y", "f")]),
    ("FSLP", "0002"): ("D", [("min_angle", "f"), ("max_angle", "f")] + _FF),
    ("FDIR", "0000"): ("D", [("min_angle", "f"), ("max_angle", "f")] + _FF),
    ("FSHD", "0000"): ("D", [("family_id", "i")]),
    ("FBIT", "0000"): ("P", [("family_id", "i")] + _FF + [("low", "f"), ("high", "f")]),
    ("FBIT", "0001"): ("P", [("family_id", "i")] + _FF + [("low", "f"), ("high", "f"), ("gain", "f")]),
    # affectors
    ("AHCN", "0000"): ("D", [("operation", "i"), ("height", "f")]),
    ("AHFR", "0003"): ("P", [("family_id", "i"), ("operation", "i"), ("scale_y", "f")]),
    ("AHTR", "0004"): ("D", [("fraction", "f"), ("height", "f")]),
    ("ACCN", "0000"): ("D", [("operation", "i"), ("color", "rgb")]),
    ("ACRH", "0000"): ("D", [("operation", "i"), ("low_height", "f"), ("high_height", "f"), ("image", "s")]),
    ("ACRF", "0001"): ("P", [("family_id", "i"), ("operation", "i"), ("image", "s")]),
    ("ASCN", "0001"): ("D", [("family_id", "i"), ("use_feather_clamp_override", "b"),
                             ("feather_clamp_override", "f")]),
    ("ASRP", "0001"): ("D", [("source_family_id", "i"), ("destination_family_id", "i"),
                             ("use_feather_clamp_override", "b"), ("feather_clamp_override", "f")]),
    ("AFSC", "0004"): ("D", _FLORA), ("AFSN", "0004"): ("D", _FLORA),
    ("AFDN", "0002"): ("D", _FLORA), ("AFDF", "0002"): ("D", _FLORA),
    ("AEXC", "0000"): ("D", []),
    ("AEXC", "0001"): ("D", [("fine", "b")]),     # titan: cut along the layer's boundary edge, not whole tiles
    ("APAS", "0000"): ("D", [("passable", "b8"), ("feather_threshold", "f")]),
    ("AENV", "0000"): ("D", [("family_id", "i"), ("use_feather_clamp_override", "b"),
                             ("feather_clamp_override", "f")]),
    ("AROA", "0005"): ("H", [("points", "pts"), ("width", "f"), ("family_id", "i")] + _FF
                       + [("feather_function_shader", "i"), ("feather_distance_shader", "f")]),
    ("AROA", "0006"): ("H", [("points", "pts"), ("heights", "flist"), ("width", "f"), ("family_id", "i")] + _FF
                       + [("feather_function_shader", "i"), ("feather_distance_shader", "f"),
                          ("has_fixed_heights", "b")]),
    ("ARIV", "0005"): ("H", [("points", "pts"), ("width", "f"), ("bank_family_id", "i"),
                             ("bottom_family_id", "i")] + _FF
                       + [("trench_depth", "f"), ("velocity", "f"), ("has_local_water_table", "b"),
                          ("local_water_table_depth", "f"), ("local_water_table_width", "f"),
                          ("local_water_table_shader_size", "f"), ("local_water_table_shader", "s")]),
    ("ARIV", "0006"): ("H", [("points", "pts"), ("width", "f"), ("bank_family_id", "i"),
                             ("bottom_family_id", "i")] + _FF
                       + [("trench_depth", "f"), ("velocity", "f"), ("has_local_water_table", "b"),
                          ("local_water_table_depth", "f"), ("local_water_table_width", "f"),
                          ("local_water_table_shader_size", "f"), ("local_water_table_shader", "s"),
                          ("water_type", "i")]),
    ("ARIB", "0005"): ("R", [("points", "ptsh"), ("width", "f"), ("water_shader_size", "f"), ("velocity", "f"),
                             ("cap_width", "f"), ("terrain_shader_family_id", "i"),
                             ("feather_function_terrain_shader", "i"), ("feather_distance_terrain_shader", "f"),
                             ("water_shader", "s"), ("water_type", "i")]),
}


def defaults(tag: str, version: str | None = None) -> dict[str, Any]:
    """Default parameters for a new record (the engine constructors' defaults where they matter)."""
    version = version or LATEST[tag]
    _, spec = LAYOUTS[(tag, version)]
    base = {"f": 0.0, "i": 0, "I": 0, "B": 0, "b": False, "b8": False, "s": "", "rgb": [255, 255, 255], "pts": [],
            "ptsh": [], "flist": []}
    out = {name: copy.deepcopy(base[typ]) if not isinstance(typ, tuple) else [] for name, typ in spec}
    special = {
        "BCIR": {"radius": 10.0, "feather_distance": 0.0},
        "BREC": {"water_shader_size": 2.0, "water_type": 0},
        "BPOL": {"water_shader_size": 2.0, "water_type": 0},
        "BPLN": {"width": 4.0},
        "FHGT": {"high_height": 100.0},
        "FFRA": {"family_id": 1, "low": 0.0, "high": 1.0, "scale_y": 1.0},
        "FSLP": {"max_angle": 90.0},
        "FDIR": {"min_angle": -180.0, "max_angle": 180.0},
        "FBIT": {"family_id": 1, "low": 0.0, "high": 1.0},
        "AHFR": {"family_id": 1, "operation": 1, "scale_y": 50.0},
        "AHTR": {"fraction": 0.5, "height": 10.0},
        "ACRH": {"high_height": 100.0},
        "ASCN": {"family_id": 1}, "ASRP": {"source_family_id": 1, "destination_family_id": 1},
        "AFSC": {"family_id": 1}, "AFSN": {"family_id": 1}, "AFDN": {"family_id": 1}, "AFDF": {"family_id": 1},
        "APAS": {"passable": False, "feather_threshold": 0.5},
        "AENV": {"family_id": 1},
        "AROA": {"width": 8.0, "family_id": 1, "feather_distance": 0.5, "feather_distance_shader": 0.5},
        "ARIV": {"width": 16.0, "bank_family_id": 1, "bottom_family_id": 1, "feather_distance": 0.5,
                 "trench_depth": 2.0, "local_water_table_depth": 2.0, "local_water_table_width": 4.0,
                 "local_water_table_shader_size": 2.0},
        "ARIB": {"width": 8.0, "water_shader_size": 2.0, "cap_width": 8.0, "terrain_shader_family_id": 1},
    }
    out.update(special.get(tag, {}))
    return out


def kind_of(tag: str) -> str:
    if tag == "LAYR":
        return "layer"
    if tag in BOUNDARIES:
        return "boundary"
    if tag in FILTERS:
        return "filter"
    if tag in AFFECTORS:
        return "affector"
    return "unknown"


def type_of(tag: str) -> str:
    return BOUNDARIES.get(tag) or FILTERS.get(tag) or AFFECTORS.get(tag) or ("layer" if tag == "LAYR" else tag)


# ----------------------------------------------------------------------------------------------------------------
# item header (LayerItem::load_0000 / load_0001)

def _decode_ihdr(b: Block) -> dict:
    if not (b.is_form and b.tag == "IHDR"):
        raise TrnError("missing IHDR")
    ver = _version_form(b)
    data = ver.chunks("DATA")[0].data
    r = _Reader(data)
    out: dict[str, Any] = {"active": r.take("<i")[0], "name": r.string()}
    out["active"] = bool(out["active"]) if out["active"] in (0, 1) else out["active"]
    if ver.tag == "0000":
        out["ihdr_version"] = "0000"
        out["tool_color"] = list(r.take("<3B"))
    elif ver.tag != "0001":
        raise TrnError(f"IHDR version {ver.tag}")
    if r.left():
        raise TrnError("IHDR trailing bytes")
    return out


def _encode_ihdr(item: dict) -> bytes:
    payload = _bool32(item.get("active", True)) + str(item.get("name", "")).encode("latin1") + b"\0"
    ver = item.get("ihdr_version", "0001")
    if ver == "0000":
        payload += struct.pack("<3B", *item.get("tool_color", [255, 255, 255]))
    return form("IHDR", form(ver, chunk("DATA", payload)))


# ----------------------------------------------------------------------------------------------------------------
# height data (HeightData, FORM HDTA / 0001 / SGMT*)

def _decode_hdta(b: Block) -> list[list[list[float]]]:
    ver = _version_form(b)
    if b.tag != "HDTA" or ver.tag != "0001":
        raise TrnError(f"height data {b.tag}/{ver.tag}")
    segs = []
    for c in ver.children:
        if c.is_form or c.tag != "SGMT" or len(c.data) % 12:
            raise TrnError("bad SGMT")
        segs.append([list(struct.unpack_from("<3f", c.data, i)) for i in range(0, len(c.data), 12)])
    return segs


def _encode_hdta(segments: list) -> bytes:
    return form("HDTA", form("0001", *[chunk("SGMT", b"".join(struct.pack("<3f", *map(float, p)) for p in s))
                                       for s in segments]))


# ----------------------------------------------------------------------------------------------------------------
# layer items

def _decode_item(b: Block) -> dict:
    if not b.is_form:
        raise TrnError(f"chunk {b.tag} inside a layer")
    if b.tag == "LAYR":
        return _decode_layer(b)
    tag = b.tag
    ver = _version_form(b)
    key = (tag, ver.tag)
    if key not in LAYOUTS:
        raise TrnError(f"no layout for {tag}/{ver.tag}")
    layout, spec = LAYOUTS[key]
    kids = ver.children
    item: dict[str, Any] = {"kind": kind_of(tag), "type": type_of(tag), "tag": tag, "version": ver.tag}
    item.update(_decode_ihdr(kids[0]))
    rest = kids[1:]
    if layout == "D":
        if len(rest) != 1 or rest[0].is_form or rest[0].tag != "DATA":
            raise TrnError(f"{tag}: expected DATA")
        item["params"] = _decode_chunk(rest[0].data, spec)
    else:
        if len(rest) != 1 or not rest[0].is_form or rest[0].tag != "DATA":
            raise TrnError(f"{tag}: expected FORM DATA")
        inner = rest[0].children
        if layout == "P":
            if len(inner) != 1 or inner[0].tag != "PARM":
                raise TrnError(f"{tag}: expected PARM")
            item["params"] = _decode_chunk(inner[0].data, spec)
        elif layout == "R":
            if len(inner) != 1 or inner[0].tag != "DATA" or inner[0].is_form:
                raise TrnError(f"{tag}: expected DATA")
            item["params"] = _decode_chunk(inner[0].data, spec)
        else:  # H
            hd = None
            if inner and inner[0].is_form:
                hd = _decode_hdta(inner[0])
                inner = inner[1:]
            if len(inner) != 1 or inner[0].tag != "DATA":
                raise TrnError(f"{tag}: expected DATA")
            item["params"] = _decode_chunk(inner[0].data, spec)
            item["height_data"] = hd
    return item


def _encode_item(item: dict) -> bytes:
    if "raw" in item:
        return item["raw"]
    if item.get("kind") == "layer":
        return _encode_layer(item)
    tag, ver = item["tag"], item["version"]
    layout, spec = LAYOUTS[(tag, ver)]
    payload = _write(spec, item["params"])
    head = _encode_ihdr(item)
    if layout == "D":
        body = chunk("DATA", payload)
    elif layout == "P":
        body = form("DATA", chunk("PARM", payload))
    elif layout == "R":
        body = form("DATA", chunk("DATA", payload))
    else:
        hd = item.get("height_data")
        body = form("DATA", *([_encode_hdta(hd)] if hd is not None else []), chunk("DATA", payload))
    return form(tag, form(ver, head, body))


def _raw_item(b: Block, why: str) -> dict:
    item: dict[str, Any] = {"kind": "obsolete" if b.tag in OBSOLETE else kind_of(b.tag), "type": type_of(b.tag),
                            "tag": b.tag, "raw": _block_bytes(b), "raw_reason": why}
    try:
        ver = _version_form(b)
        item["version"] = ver.tag
        if ver.children and ver.children[0].tag == "IHDR":
            item.update(_decode_ihdr(ver.children[0]))
    except (TrnError, IndexError, struct.error, ValueError):
        pass
    return item


def _checked(b: Block, decode, encode) -> dict:
    """Decode a block and keep the result only if it re-encodes to the same bytes."""
    try:
        model = decode(b)
        if encode(model) == _block_bytes(b):
            return model
        why = "re-encoding differs"
    except (TrnError, IndexError, struct.error, ValueError, KeyError) as exc:
        why = str(exc) or type(exc).__name__
    return _raw_item(b, why)


def _decode_layer(b: Block) -> dict:
    ver = _version_form(b)
    if ver.tag not in ("0003", "0004"):
        raise TrnError(f"layer version {ver.tag}")
    kids = ver.children
    layer: dict[str, Any] = {"kind": "layer", "type": "layer", "tag": "LAYR", "version": ver.tag}
    layer.update(_decode_ihdr(kids[0]))
    adta = kids[1]
    if adta.is_form or adta.tag != "ADTA":
        raise TrnError("missing ADTA")
    spec = [("invert_boundaries", "b"), ("invert_filters", "b")]
    spec += [("unused", "i")] if ver.tag == "0004" else []
    spec += [("expanded", "b"), ("notes", "s")]
    adta_fields = _decode_chunk(adta.data, spec)
    if "_trailing" in adta_fields:
        adta_fields["adta_trailing"] = adta_fields.pop("_trailing")
    layer.update(adta_fields)
    layer["items"] = [_checked(c, _decode_item, _encode_item) for c in kids[2:]]
    return layer


def _encode_layer(layer: dict) -> bytes:
    if "raw" in layer:
        return layer["raw"]
    ver = layer.get("version", "0003")
    spec = [("invert_boundaries", "b"), ("invert_filters", "b")]
    spec += [("unused", "i")] if ver == "0004" else []
    spec += [("expanded", "b"), ("notes", "s")]
    vals = {"invert_boundaries": False, "invert_filters": False, "unused": 0, "expanded": True, "notes": ""}
    vals.update({k: layer[k] for k in vals if k in layer})
    adta = _write(spec, vals) + layer.get("adta_trailing", b"")
    return form("LAYR", form(ver, _encode_ihdr(layer), chunk("ADTA", adta),
                             *[_encode_item(i) for i in layer.get("items", [])]))


def new_layer(name: str, active: bool = True, notes: str = "", invert_boundaries: bool = False,
              invert_filters: bool = False) -> dict:
    return {"kind": "layer", "type": "layer", "tag": "LAYR", "version": "0003", "active": active, "name": name,
            "invert_boundaries": invert_boundaries, "invert_filters": invert_filters, "expanded": True,
            "notes": notes, "items": []}


def new_item(type_or_tag: str, name: str = "", params: dict | None = None, active: bool = True) -> dict:
    """A boundary / filter / affector record in the current save version, defaults filled in."""
    tag = type_or_tag if type_or_tag in LATEST and type_or_tag not in ("LAYR", "PTAT", "BAKE") else \
        TYPE_TO_TAG.get(type_or_tag)
    if tag is None or (tag, LATEST.get(tag, "")) not in LAYOUTS:
        raise TrnError(f"unknown item type {type_or_tag!r}; one of {sorted(TYPE_TO_TAG)}")
    p = defaults(tag)
    for k, v in (params or {}).items():
        if tag == "AEXC" and k == "fine":
            continue
        if k not in p:
            raise TrnError(f"{type_of(tag)} has no parameter {k!r}; parameters: {sorted(p)}")
        p[k] = v
    version = LATEST[tag]
    if tag == "AEXC" and (params or {}).get("fine"):      # titan fine exclusion (AffectorExclude 0001)
        version, p = "0001", {"fine": True}
    item = {"kind": kind_of(tag), "type": type_of(tag), "tag": tag, "version": version, "active": active,
            "name": name or type_of(tag), "params": p}
    if tag in ("AROA", "ARIV"):
        item["height_data"] = []
    return item


# ----------------------------------------------------------------------------------------------------------------
# family groups

_SFAM = {
    "0006": [("id", "i"), ("name", "s"), ("surface_properties", "s"), ("color", "rgb"), ("shader_size", "f"),
             ("feather_clamp", "f"), ("children", ("list", [("shader", "s"), ("weight", "f")]))],
    "0004": [("id", "i"), ("name", "s"), ("color", "rgb"), ("shader_size", "f"), ("feather_clamp", "f"),
             ("children", ("list", [("shader", "s"), ("weight", "f")]))],
}
_FFAM = {"0008": [("id", "i"), ("name", "s"), ("color", "rgb"), ("density", "f"), ("floats", "b"),
                  ("children", ("list", [("appearance", "s"), ("weight", "f"), ("should_sway", "b"),
                                         ("displacement", "f"), ("period", "f"), ("align_to_terrain", "b"),
                                         ("should_scale", "b"), ("min_scale", "f"), ("max_scale", "f")]))]}
_RFAM = {
    "0004": [("id", "i"), ("name", "s"), ("color", "rgb"), ("density", "f"),
             ("children", ("list", [("shader", "s"), ("weight", "f"), ("distance", "f"), ("min_width", "f"),
                                    ("max_width", "f"), ("min_height", "f"), ("max_height", "f"),
                                    ("maintain_aspect_ratio", "b"), ("should_sway", "b"), ("displacement", "f"),
                                    ("period", "f"), ("align_to_terrain", "b"), ("create_plus", "b")]))],
    "0003": [("id", "i"), ("name", "s"), ("color", "rgb"), ("density", "f"),
             ("children", ("list", [("shader", "s"), ("weight", "f"), ("distance", "f"), ("width", "f"),
                                    ("height", "f"), ("should_sway", "b"), ("displacement", "f"), ("period", "f"),
                                    ("align_to_terrain", "b"), ("create_plus", "b")]))],
}
_EFAM = [("id", "i"), ("name", "s"), ("color", "rgb"), ("feather_clamp", "f")]
_MFRC = {
    "0001": [("seed", "I"), ("use_bias", "b"), ("bias", "f"), ("use_gain", "b"), ("gain", "f"), ("octaves", "i"),
             ("frequency", "f"), ("amplitude", "f"), ("scale_x", "f"), ("scale_y", "f"), ("offset_x", "f"),
             ("offset_y", "f"), ("combination_rule", "i")],
    "0000": [("seed", "I"), ("use_bias", "b"), ("bias", "f"), ("use_gain", "b"), ("gain", "f"), ("octaves", "i"),
             ("frequency", "f"), ("amplitude", "f"), ("scale_x", "f"), ("scale_y", "f"),
             ("combination_rule", "i")],
}
GROUP_TAGS = {"shader": "SGRP", "flora": "FGRP", "radial": "RGRP", "environment": "EGRP", "fractal": "MGRP",
              "bitmap": "MGRP"}
_CHUNK_FAMILIES = {"SGRP": ("SFAM", _SFAM), "FGRP": ("FFAM", _FFAM), "RGRP": ("RFAM", _RFAM)}


def _decode_group(b: Block, name: str) -> dict:
    ver = _version_form(b)
    fams = []
    if b.tag in _CHUNK_FAMILIES:
        ctag, specs = _CHUNK_FAMILIES[b.tag]
        if ver.tag not in specs:
            raise TrnError(f"{b.tag} version {ver.tag}")
        for c in ver.children:
            if c.is_form or c.tag != ctag:
                raise TrnError(f"{b.tag}: unexpected {c.tag}")
            fams.append(_decode_chunk(c.data, specs[ver.tag]))
    elif b.tag == "EGRP":
        for c in ver.children:
            if not c.is_form or c.tag != "EFAM":
                raise TrnError("EGRP: expected EFAM")
            data = c.children[0]
            r = _Reader(data.data)
            fam = _read(r, _EFAM)
            if r.left():
                fam["extra_data"] = data.data[r.pos:]
            if len(c.children) > 1:
                fam["extra_blocks"] = [_block_bytes(x) for x in c.children[1:]]
            fams.append(fam)
    elif name == "fractal":
        for c in ver.children:
            data, mfrc = c.children[0], c.children[1]
            fam = _decode_chunk(data.data, [("id", "i"), ("name", "s")])
            mv = _version_form(mfrc)
            fam.update(_decode_chunk(mv.children[0].data, _MFRC[mv.tag]))
            if "_trailing" in fam or len(c.children) != 2:
                raise TrnError("fractal family with extra data")
            if mv.tag != "0001":
                fam["mfrc_version"] = mv.tag
            fams.append(fam)
    else:  # bitmap
        for c in ver.children:
            fams.append(_decode_chunk(c.children[0].data, [("id", "i"), ("name", "s"), ("bitmap", "s")]))
    return {"version": ver.tag, "families": fams}


def _encode_group(g: dict | None, name: str) -> bytes:
    if g is None:
        return b""
    if "raw" in g:
        return g["raw"]
    tag = GROUP_TAGS[name]
    ver = g.get("version", LATEST[tag])
    parts = []
    for fam in g["families"]:
        if tag in _CHUNK_FAMILIES:
            ctag, specs = _CHUNK_FAMILIES[tag]
            parts.append(chunk(ctag, _write(specs[ver], fam)))
        elif tag == "EGRP":
            parts.append(form("EFAM", chunk("DATA", _write(_EFAM, fam) + fam.get("extra_data", b"")),
                              *fam.get("extra_blocks", [])))
        elif name == "fractal":
            mv = fam.get("mfrc_version", "0001")
            parts.append(form("MFAM", chunk("DATA", _write([("id", "i"), ("name", "s")], fam)),
                              form("MFRC", form(mv, chunk("DATA", _write(_MFRC[mv], fam))))))
        else:
            parts.append(form("MFAM", chunk("DATA", _write([("id", "i"), ("name", "s"), ("bitmap", "s")], fam))))
    return form(tag, form(ver, *parts))


def _checked_group(b: Block, name: str) -> dict:
    try:
        g = _decode_group(b, name)
        if _encode_group(g, name) == _block_bytes(b):
            return g
        why = "re-encoding differs"
    except (TrnError, IndexError, struct.error, ValueError, KeyError) as exc:
        why = str(exc) or type(exc).__name__
    return {"raw": _block_bytes(b), "raw_reason": why, "families": []}


FAMILY_DEFAULTS: dict[str, dict[str, Any]] = {
    "shader": {"name": "", "surface_properties": "", "color": [255, 255, 255], "shader_size": 2.0,
               "feather_clamp": 1.0, "children": []},
    "flora": {"name": "", "color": [0, 255, 0], "density": 1.0, "floats": False, "children": []},
    "radial": {"name": "", "color": [0, 255, 255], "density": 1.0, "children": []},
    "environment": {"name": "", "color": [255, 0, 255], "feather_clamp": 1.0},
    "fractal": {"name": "", "seed": 0, "use_bias": False, "bias": 0.5, "use_gain": False, "gain": 0.7,
                "octaves": 2, "frequency": 4.0, "amplitude": 0.5, "scale_x": 0.01, "scale_y": 0.01,
                "offset_x": 0.0, "offset_y": 0.0, "combination_rule": 0},
    "bitmap": {"name": "", "bitmap": ""},
}
CHILD_DEFAULTS: dict[str, dict[str, Any]] = {
    "shader": {"shader": "", "weight": 1.0},
    "flora": {"appearance": "", "weight": 1.0, "should_sway": False, "displacement": 0.0, "period": 1.0,
              "align_to_terrain": False, "should_scale": False, "min_scale": 1.0, "max_scale": 1.0},
    "radial": {"shader": "", "weight": 1.0, "distance": 16.0, "min_width": 1.0, "max_width": 1.0,
               "min_height": 1.0, "max_height": 1.0, "maintain_aspect_ratio": False, "should_sway": False,
               "displacement": 0.0, "period": 1.0, "align_to_terrain": False, "create_plus": False},
}


# ----------------------------------------------------------------------------------------------------------------
# PTAT header, baked terrain, packed maps

_TILING = []
for _g in ("collidable", "non_collidable", "radial", "far_radial"):
    _TILING += [(f"{_g}_min_distance", "f"), (f"{_g}_max_distance", "f"), (f"{_g}_tile_size", "f"),
                (f"{_g}_tile_border", "f"), (f"{_g}_seed", "I")]
_HEAD = [("name", "s"), ("map_width", "f"), ("chunk_width", "f"), ("tiles_per_chunk", "i"),
         ("use_global_water_table", "b"), ("global_water_table_height", "f"), ("global_water_table_shader_size", "f"),
         ("global_water_table_shader", "s"), ("environment_cycle_time", "f")]
_LEGACY_0013 = [("legacy_s0", "s"), ("legacy_s1", "s"), ("legacy_f0", "f"), ("legacy_s2", "s"), ("legacy_f1", "f"),
                ("legacy_s3", "s"), ("legacy_f2", "f"), ("legacy_s4", "s"), ("legacy_f3", "f"), ("legacy_i0", "i"),
                ("legacy_s5", "s")]
HEADER_SPECS = {"0013": _HEAD + _LEGACY_0013 + _TILING, "0014": _HEAD + _TILING,
                "0015": _HEAD + _TILING + [("legacy_map", "b8")]}


def _decode_baked(b: Block) -> dict:
    if b.tag == "0001":
        names = [c.tag for c in b.children]
        if names != ["DATA", "WMAP", "SMAP"]:
            raise TrnError(f"baked terrain blocks {names}")
        out = {"version": "0001"}
        out.update(_decode_chunk(b.children[0].data, [("map_width", "f"), ("chunk_width", "f"), ("width", "i"),
                                                      ("height", "i")]))
        out["water"] = b.children[1].data
        out["slope"] = b.children[2].data
        return out
    return {"version": b.tag, "raw": _block_bytes(b)}


def _encode_baked(bk: dict | None) -> bytes:
    if bk is None:
        return b""
    if "raw" in bk:
        return bk["raw"]
    head = _write([("map_width", "f"), ("chunk_width", "f"), ("width", "i"), ("height", "i")], bk)
    return form("0001", chunk("DATA", head), chunk("WMAP", bk["water"]), chunk("SMAP", bk["slope"]))


def _decode_pimp(b: Block) -> dict:
    v = _version_form(b)
    cntl, data = v.children
    out = _decode_chunk(cntl.data, [("width", "i"), ("height", "i"), ("bits_per_element", "i"),
                                    ("minimum_value", "i")])
    out["data"] = data.data
    return out


def _encode_pimp(m: dict) -> bytes:
    return form("PIMP", form("0000", chunk("CNTL", _write([("width", "i"), ("height", "i"), ("bits_per_element", "i"),
                                                          ("minimum_value", "i")], m)), chunk("DATA", m["data"])))


def _decode_pfpm(b: Block) -> dict:
    pimp, ver = b.children
    out = {"map": _decode_pimp(pimp)}
    out.update(_decode_chunk(ver.children[0].data, [("resolution", "f")]))
    return out


def _encode_pfpm(m: dict) -> bytes:
    return form("PFPM", _encode_pimp(m["map"]), form("0000", chunk("CNTL", struct.pack("<f", m["resolution"]))))


EMPTY_PIMP = {"width": 0, "height": 0, "bits_per_element": 0, "minimum_value": 0, "data": b""}


# ----------------------------------------------------------------------------------------------------------------
# document

def _parse_path(path: str | list[int] | None) -> list[int]:
    if path is None or path == "" or path == []:
        return []
    if isinstance(path, list):
        return [int(i) for i in path]
    return [int(p) for p in str(path).strip("/").split("/") if p != ""]


class TerrainDoc:
    """A whole .trn (kind "trn") or .lay (kind "lay") in model form."""

    def __init__(self, kind: str, model: dict):
        self.kind = kind
        self.model = model

    # ---- io

    @classmethod
    def from_bytes(cls, data: bytes) -> "TerrainDoc":
        root = parse_iff(data)
        top = root.children
        if len(top) == 1 and top[0].is_form and top[0].tag == "PTAT":
            return cls("trn", _decode_ptat(top[0]))
        if top and top[0].is_form and top[0].tag == "SGRP":
            return cls("lay", _decode_lay(top))
        if len(top) == 1 and top[0].is_form and top[0].tag == "STAT":
            # space zones (SpaceTerrainAppearanceTemplate): sky, lights, planets, dust - not procedural; kept as is
            ver = _version_form(top[0])
            return cls("space", {"raw": data, "version": ver.tag, "layers": [], "groups": {},
                                 "sections": [c.tag for c in ver.children]})
        raise TrnError(f"not a terrain file (top level {[b.tag for b in top][:4]})")

    @classmethod
    def load(cls, path: str | Path) -> "TerrainDoc":
        doc = cls.from_bytes(Path(path).read_bytes())
        doc.path = str(path)
        return doc

    def to_bytes(self) -> bytes:
        if self.kind == "space":
            return self.model["raw"]
        return _encode_ptat(self.model) if self.kind == "trn" else _encode_lay(self.model)

    def save(self, path: str | Path) -> dict[str, Any]:
        data = self.to_bytes()
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
        return {"path": str(p), "bytes": len(data)}

    # ---- navigation

    @property
    def layers(self) -> list[dict]:
        return self.model["layers"]

    @property
    def header(self) -> dict:
        return self.model.get("header", {})

    def node(self, path: str | list[int]) -> dict:
        idx = _parse_path(path)
        if not idx:
            raise TrnError("empty path")
        items = self.layers
        node = None
        for depth, i in enumerate(idx):
            if not 0 <= i < len(items):
                raise TrnError(f"path {'/'.join(map(str, idx))}: index {i} out of range at depth {depth} "
                               f"({len(items)} entries)")
            node = items[i]
            items = node.get("items", [])
        return node

    def container(self, path: str | list[int]) -> list[dict]:
        """The item list of a layer path ([] / "" = the root layer list)."""
        idx = _parse_path(path)
        if not idx:
            return self.layers
        node = self.node(idx)
        if node.get("kind") != "layer" or "raw" in node:
            raise TrnError(f"{path} is not an editable layer")
        return node["items"]

    def walk(self) -> Iterator[tuple[str, dict, int]]:
        def rec(items, prefix, depth):
            for i, it in enumerate(items):
                p = f"{prefix}{i}"
                yield p, it, depth
                if it.get("kind") == "layer":
                    yield from rec(it.get("items", []), p + "/", depth + 1)
        yield from rec(self.layers, "", 0)

    def group(self, name: str) -> dict:
        if name not in GROUP_TAGS:
            raise TrnError(f"unknown family group {name!r}; one of {sorted(GROUP_TAGS)}")
        g = self.model["groups"].get(name)
        if g is None:
            g = self.model["groups"][name] = {"version": LATEST[GROUP_TAGS[name]], "families": []}
        if "raw" in g:
            raise TrnError(f"{name} group is not decodable ({g.get('raw_reason')}); it can only be kept as is")
        return g

    def family(self, name: str, family_id: int) -> dict | None:
        g = self.model["groups"].get(name)
        if not g:
            return None
        return next((f for f in g["families"] if f.get("id") == family_id), None)

    def raw_records(self) -> list[dict[str, str]]:
        out = []
        for p, it, _ in self.walk():
            if "raw" in it:
                out.append({"path": p, "tag": it.get("tag", ""), "reason": it.get("raw_reason", "")})
        for name, g in self.model["groups"].items():
            if g and "raw" in g:
                out.append({"path": f"group:{name}", "tag": GROUP_TAGS[name], "reason": g.get("raw_reason", "")})
        bk = self.model.get("baked")
        if bk and "raw" in bk and bk.get("version") == "0001":
            out.append({"path": "baked", "tag": "0001", "reason": "undecoded"})
        return out


def _decode_tgen(b: Block) -> tuple[dict, list]:
    ver = _version_form(b)
    if ver.tag != "0000":
        raise TrnError(f"TGEN version {ver.tag}")
    groups: dict[str, Any] = {k: None for k in GROUP_TAGS}
    layers: list = []
    mgrp_seen = 0
    order = []
    for c in ver.children:
        if c.tag == "MGRP":
            name = "fractal" if mgrp_seen == 0 else "bitmap"
            mgrp_seen += 1
        elif c.tag == "LYRS":
            layers = [_checked(x, _decode_item, _encode_item) for x in c.children]
            order.append("LYRS")
            continue
        else:
            name = {v: k for k, v in GROUP_TAGS.items() if k not in ("fractal", "bitmap")}.get(c.tag)
            if name is None:
                raise TrnError(f"TGEN: unexpected {c.tag}")
        groups[name] = _checked_group(c, name)
        order.append(name)
    return groups, layers, order


def _decode_ptat(b: Block) -> dict:
    ver = _version_form(b)
    if ver.tag not in HEADER_SPECS:
        raise TrnError(f"PTAT version {ver.tag} (the engine loads 0013-0015)")
    kids = ver.children
    model: dict[str, Any] = {"version": ver.tag}
    model["header"] = _decode_chunk(kids[0].data, HEADER_SPECS[ver.tag])
    groups, layers, order = _decode_tgen(kids[1])
    model["groups"], model["layers"], model["tgen_order"] = groups, layers, order
    rest = kids[2:]
    model["baked"] = None
    if rest and rest[0].is_form and rest[0].tag in ("0000", "0001"):
        try:
            bk = _decode_baked(rest[0])
            if _encode_baked(bk) != _block_bytes(rest[0]):
                raise TrnError("baked re-encoding differs")
        except (TrnError, struct.error, ValueError):
            bk = {"version": rest[0].tag, "raw": _block_bytes(rest[0])}
        model["baked"] = bk
        rest = rest[1:]
    model["flora_map"] = model["flora_height_map"] = None
    extra = []
    for c in rest:
        if c.tag == "PIMP" and model["flora_map"] is None:
            model["flora_map"] = _decode_pimp(c)
        elif c.tag == "PFPM" and model["flora_height_map"] is None:
            model["flora_height_map"] = _decode_pfpm(c)
        else:
            extra.append(_block_bytes(c))
    if extra:
        model["extra_blocks"] = extra
    return model


def _encode_tgen(model: dict) -> bytes:
    order = model.get("tgen_order") or ["shader", "flora", "radial", "environment", "fractal", "bitmap", "LYRS"]
    parts = []
    for name in order:
        if name == "LYRS":
            parts.append(form("LYRS", *[_encode_item(l) for l in model["layers"]]))
        else:
            parts.append(_encode_group(model["groups"].get(name), name))
    return form("TGEN", form("0000", *parts))


def _encode_ptat(model: dict) -> bytes:
    ver = model.get("version", "0015")
    parts = [chunk("DATA", _write(HEADER_SPECS[ver], model["header"])), _encode_tgen(model),
             _encode_baked(model.get("baked"))]
    if ver == "0015" or model.get("flora_map") is not None:
        fm = model.get("flora_map") or EMPTY_PIMP
        parts.append(_encode_pimp(fm))
    if ver == "0015" or model.get("flora_height_map") is not None:
        hm = model.get("flora_height_map") or {"map": EMPTY_PIMP, "resolution": 0.0}
        parts.append(_encode_pfpm(hm))
    parts += model.get("extra_blocks", [])
    return form("PTAT", form(ver, *parts))


def _decode_lay(top: list[Block]) -> dict:
    groups: dict[str, Any] = {k: None for k in GROUP_TAGS}
    order = []
    layers = []
    for c in top:
        if c.tag == "LAYR":
            layers.append(_checked(c, _decode_item, _encode_item))
            order.append("LAYR")
            continue
        name = {"SGRP": "shader", "FGRP": "flora", "RGRP": "radial", "EGRP": "environment",
                "MGRP": "fractal"}.get(c.tag)
        if name is None:
            raise TrnError(f".lay: unexpected {c.tag}")
        groups[name] = _checked_group(c, name)
        order.append(name)
    return {"groups": groups, "layers": layers, "lay_order": order}


def _encode_lay(model: dict) -> bytes:
    order = model.get("lay_order") or ["shader", "flora", "radial", "environment", "fractal", "LAYR"]
    out = []
    layers = iter(model["layers"])
    for name in order:
        if name == "LAYR":
            out.extend(_encode_item(l) for l in layers)
        else:
            out.append(_encode_group(model["groups"].get(name), name))
    out.extend(_encode_item(l) for l in layers)
    return b"".join(out)


def roundtrip(path: str | Path) -> dict[str, Any]:
    """Load and re-encode a file; report whether the bytes match and which records stayed raw."""
    data = Path(path).read_bytes()
    doc = TerrainDoc.from_bytes(data)
    out = doc.to_bytes()
    first = next((i for i, (a, b) in enumerate(zip(data, out)) if a != b), None)
    if first is None and len(data) != len(out):
        first = min(len(data), len(out))
    return {"path": str(path), "kind": doc.kind, "bytes": len(data), "identical": out == data,
            "first_difference": first, "raw_records": doc.raw_records()}
