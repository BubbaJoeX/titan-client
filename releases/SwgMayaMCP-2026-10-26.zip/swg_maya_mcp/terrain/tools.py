"""MCP tools for procedural terrain (.trn) and terrain layer (.lay) files: trn_* (registered by server.py)."""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any, Literal

from mcp.server.mcpserver import Image
from mcp.server.mcpserver.exceptions import ToolError

from .. import client
from . import author, env, generator, planet, trn, verify
from .trn import TerrainDoc, TrnError

EXPORT_ROOT = os.environ.get("TITAN_EXPORT_ROOT", "D:/exported")
DATA_ROOTS = [p for p in os.environ.get(
    "TITAN_DATA_ROOTS", "D:/titan/data/sku.0/sys.client/compiled/game;D:/titan/data/sku.0/sys.shared/compiled/game"
).split(";") if p]


def _resolve(path: str) -> Path:
    """Absolute paths as given; relative ones (e.g. "terrain/naboo.trn") in the export root, then the data roots."""
    p = Path(path)
    if p.is_absolute():
        return p
    for root in [EXPORT_ROOT] + DATA_ROOTS:
        for cand in (Path(root) / p, Path(root) / "terrain" / p):
            if cand.exists():
                return cand
    return Path(EXPORT_ROOT) / p


def _is_stock(p: Path) -> bool:
    rp = str(p.resolve()).lower().replace("\\", "/")
    return any(rp.startswith(str(Path(r).resolve()).lower().replace("\\", "/")) for r in DATA_ROOTS)


def _target(path: str, out_path: str) -> Path:
    t = _resolve(out_path) if out_path else _resolve(path)
    if out_path and not Path(out_path).is_absolute():
        t = Path(EXPORT_ROOT) / out_path
    if _is_stock(t):
        raise ToolError(f"{t} is stock game data: write the edited file elsewhere (out_path, e.g. "
                        f"terrain/{t.name} in the export root {EXPORT_ROOT})")
    return t


def _load(path: str) -> TerrainDoc:
    p = _resolve(path)
    if not p.exists():
        raise ToolError(f"{path}: not found (looked in {EXPORT_ROOT} and {DATA_ROOTS})")
    try:
        return TerrainDoc.load(p)
    except (TrnError, ValueError) as exc:
        raise ToolError(f"{p}: {exc}") from None


def _save(doc: TerrainDoc, path: str, out_path: str) -> dict[str, Any]:
    t = _target(path, out_path)
    return doc.save(t)


def _jsonable(v: Any) -> Any:
    if isinstance(v, (bytes, bytearray)):
        return {"bytes": len(v)}
    if isinstance(v, dict):
        return {k: _jsonable(x) for k, x in v.items() if k != "raw"} | ({"raw": {"bytes": len(v["raw"])}}
                                                                       if "raw" in v else {})
    if isinstance(v, list):
        return [_jsonable(x) for x in v]
    return v


def _edit(path: str, out_path: str, fn) -> dict[str, Any]:
    doc = _load(path)
    try:
        result = fn(doc)
    except TrnError as exc:
        raise ToolError(str(exc)) from None
    saved = _save(doc, path, out_path)
    issues = author.validate(doc)
    return {"result": _jsonable(result), "saved": saved, "errors": issues["errors"],
            "warnings": issues["warnings"][:20]}


def _summary(it: dict) -> str:
    p = it.get("params") or {}
    t = it.get("tag")
    if t == "BCIR":
        return f"c=({p['center_x']:.1f},{p['center_z']:.1f}) r={p['radius']:.1f} feather={p['feather_distance']:.2f}"
    if t == "BREC":
        return f"[{p['x0']:.1f},{p['z0']:.1f} .. {p['x1']:.1f},{p['z1']:.1f}] feather={p['feather_distance']:.2f}"
    if "points" in p:
        return f"{len(p['points'])} points" + (f" width={p['width']:.1f}" if "width" in p else "")
    keys = [k for k in p if k != "_trailing"][:4]
    return " ".join(f"{k}={round(p[k], 3) if isinstance(p[k], float) else p[k]}" for k in keys)


def register(mcp) -> None:
    register_env(mcp)
    register_planet_tool(mcp)

    @mcp.tool()
    def trn_inspect(path: str, max_depth: int = -1, max_items: int = 400, under: str = "") -> dict:
        """Read a .trn / .lay (no client needed): map settings, family tables (shader, flora, radial, environment,
        fractal, bitmap: ids and names), the layer tree (path, kind, type, name, active, key parameters), counts by
        type, and validation. Paths like "2/0/1" address items (layer 2, its item 0, ...) in every other trn_ tool.
        Relative paths are looked up in the export root, then the stock data (e.g. "terrain/tatooine.trn")."""
        doc = _load(path)
        out: dict[str, Any] = {"path": str(_resolve(path)), "kind": doc.kind}
        if doc.kind == "space":
            out.update(version=doc.model["version"], sections=doc.model["sections"],
                       note="space zone (SpaceTerrainAppearanceTemplate): sky / lights / planets, not procedural")
            return out
        if doc.kind == "trn":
            out["version"] = doc.model["version"]
            out["header"] = doc.header
            h = doc.header
            out["derived"] = {"chunks_per_side": h["map_width"] / h["chunk_width"],
                              "tile_width": h["chunk_width"] / h["tiles_per_chunk"],
                              "pole_spacing": generator.pole_spacing(doc)}
            bk = doc.model.get("baked") or {}
            out["baked_terrain"] = _jsonable({k: v for k, v in bk.items() if k not in ("water", "slope")})
        out["families"] = {g: (None if v is None else ({"raw": v.get("raw_reason")} if "raw" in v else
                                                      [{"id": f["id"], "name": f["name"]} for f in v["families"]]))
                           for g, v in doc.model["groups"].items()}
        counts: dict[str, int] = {}
        tree = []
        for p, it, depth in doc.walk():
            counts[it.get("type", it.get("tag"))] = counts.get(it.get("type", it.get("tag")), 0) + 1
            if under and not (p == under or p.startswith(under.rstrip("/") + "/")):
                continue
            if max_depth >= 0 and depth > max_depth:
                continue
            if len(tree) < max_items:
                e = {"path": p, "kind": it.get("kind"), "type": it.get("type"), "name": it.get("name", ""),
                     "active": it.get("active")}
                if "raw" in it:
                    e["raw"] = it.get("raw_reason")
                elif it.get("kind") == "layer":
                    e["items"] = len(it["items"])
                    if it.get("invert_boundaries") or it.get("invert_filters"):
                        e["invert"] = {"boundaries": it["invert_boundaries"], "filters": it["invert_filters"]}
                else:
                    e["summary"] = _summary(it)
                tree.append(e)
        out["counts"] = counts
        out["tree"] = tree
        out["tree_truncated"] = len(tree) >= max_items
        v = author.validate(doc)
        out["errors"], out["warnings"] = v["errors"], v["warnings"][:30]
        return out

    @mcp.tool()
    def trn_get(path: str, item: str) -> dict:
        """One layer item in full (all parameters; roads/rivers include their baked height data). For a layer, its
        own settings and a one-line list of its items."""
        doc = _load(path)
        try:
            node = doc.node(item)
        except TrnError as exc:
            raise ToolError(str(exc)) from None
        out = _jsonable({k: v for k, v in node.items() if k != "items"})
        if node.get("kind") == "layer":
            out["items"] = [{"index": i, "kind": c.get("kind"), "type": c.get("type"), "name": c.get("name"),
                             "active": c.get("active")} for i, c in enumerate(node.get("items", []))]
        out["parameter_help"] = _param_help(node.get("tag", ""))
        return out

    @mcp.tool()
    def trn_families(path: str, group: Literal["shader", "flora", "radial", "environment", "fractal", "bitmap"],
                     family_id: int | None = None) -> dict:
        """A family table in full (or one family): shader families (children = shader templates with weights,
        size, feather clamp, surface properties), flora (appearance children, sway, scale), radial (near/far
        billboard shaders), environment, fractal (MultiFractal: seed, octaves, frequency, amplitude, scale,
        offset, bias, gain, combination rule) and bitmap (image) families, plus which items use each."""
        doc = _load(path)
        g = doc.model["groups"].get(group)
        if g is None:
            return {"group": group, "present": False, "families": []}
        if "raw" in g:
            return {"group": group, "raw": g.get("raw_reason")}
        fams = [f for f in g["families"] if family_id is None or f["id"] == family_id]
        return {"group": group, "version": g["version"],
                "families": [{**_jsonable(f), "used_by": author.family_users(doc, group, f["id"])[:20]}
                             for f in fams]}

    @mcp.tool()
    def trn_family_set(path: str, group: Literal["shader", "flora", "radial", "environment", "fractal", "bitmap"],
                       family: dict, out_path: str = "") -> dict:
        """Add a family, or replace the one with the same id (no id = next free id). Fields per group:
        shader {name, surface_properties, color [r,g,b], shader_size, feather_clamp, children [{shader, weight}]};
        flora {name, color, density, floats, children [{appearance, weight, should_sway, displacement, period,
        align_to_terrain, should_scale, min_scale, max_scale}]}; radial {name, color, density, children [{shader,
        weight, distance, min_width, max_width, min_height, max_height, maintain_aspect_ratio, should_sway,
        displacement, period, align_to_terrain, create_plus}]}; environment {name, color, feather_clamp};
        fractal {name, seed, octaves, frequency, amplitude, scale_x, scale_y, offset_x, offset_y, use_bias, bias,
        use_gain, gain, combination_rule 0 add/1 multiply/2 crest/3 turbulence/4 crest_clamp/5 turbulence_clamp};
        bitmap {name, bitmap "terrain/x.tga" (8-bit grey)}. Saves to out_path (default: in place; stock files need
        an out_path)."""
        return _edit(path, out_path, lambda d: author.add_family(d, group, family))

    @mcp.tool()
    def trn_family_remove(path: str, group: Literal["shader", "flora", "radial", "environment", "fractal", "bitmap"],
                          family_id: int, out_path: str = "") -> dict:
        """Remove a family; reports items that still reference it (validation then lists them as errors)."""
        return _edit(path, out_path, lambda d: author.remove_family(d, group, family_id))

    @mcp.tool()
    def trn_new(path: str, name: str = "", settings: dict | None = None, overwrite: bool = False) -> dict:
        """Create an empty terrain (PTAT 0015, the TerrainEditor's current format): map settings (defaults: 4096 m
        map, 8 m chunks, 2 tiles per chunk = 2 m pole spacing, no global water), empty family tables, no layers.
        Relative paths go to the export root (e.g. "terrain/mytest.trn"; the client loads terrain/<name>.trn).
        settings: any trn_set_map key."""
        t = _target(path, "")
        if t.exists() and not overwrite:
            raise ToolError(f"{t} exists (overwrite=True to replace it)")
        try:
            doc = author.new_terrain(name or f"terrain/{t.name}", **(settings or {}))
        except TrnError as exc:
            raise ToolError(str(exc)) from None
        return {"saved": doc.save(t), "header": doc.header}

    @mcp.tool()
    def trn_set_map(path: str, settings: dict, out_path: str = "") -> dict:
        """Change map settings: map_width (m, even number of chunks), chunk_width (m), tiles_per_chunk (tile =
        chunk / tiles; height poles every half tile), use_global_water_table, global_water_table_height /
        _shader / _shader_size, environment_cycle_time (s), legacy_map, and the flora tiling of collidable,
        non_collidable, radial and far_radial flora (<group>_min_distance, _max_distance, _tile_size,
        _tile_border, _seed). Re-bake (trn_bake) after changing map, chunk or water settings."""
        return _edit(path, out_path, lambda d: author.set_map(d, **settings))

    @mcp.tool()
    def trn_add(path: str, parent: str, type: str, name: str = "", params: dict | None = None,
                active: bool = True, index: int | None = None, layer_options: dict | None = None,
                out_path: str = "") -> dict:
        """Add a layer or a layer item. parent: "" (root, layers only) or a layer path. type: "layer" or one of
        boundaries circle, rectangle, polygon, polyline; filters height, fractal, slope, direction, shader,
        bitmap; affectors height_constant, height_fractal, height_terrace, color_constant, color_ramp_height,
        color_ramp_fractal, shader_constant, shader_replace, flora_static_collidable, flora_static_non_collidable,
        flora_dynamic_near, flora_dynamic_far, exclude, passable, road, river, environment, ribbon. params override
        the defaults (trn_get on any item lists its parameters; trn_rails / README explain them). Without an
        index the item goes after the last item of its kind (boundaries, filters, affectors, sublayers - the
        editor's order; affectors run in list order). layer_options for layers: invert_boundaries,
        invert_filters, expanded, notes. Prefer trn_add_feature for flatten pads, roads, rivers and ribbons."""
        def fn(d):
            if type == "layer":
                return {"path": author.add_layer(d, parent, name or "layer", **(layer_options or {}))}
            return {"path": author.add_item(d, parent, type, name, params, active, index)}
        return _edit(path, out_path, fn)

    @mcp.tool()
    def trn_update(path: str, item: str, params: dict | None = None, name: str | None = None,
                   active: bool | None = None, layer_options: dict | None = None, out_path: str = "") -> dict:
        """Change an item's parameters (only those given), name or active flag; for layers, layer_options
        (invert_boundaries, invert_filters, expanded, notes)."""
        return _edit(path, out_path, lambda d: author.update(d, item, params, name, active, layer_options))

    @mcp.tool()
    def trn_remove(path: str, item: str, out_path: str = "") -> dict:
        """Delete an item or a whole layer (with its sublayers)."""
        return _edit(path, out_path, lambda d: {"removed": {"type": author.remove(d, item).get("type")}})

    @mcp.tool()
    def trn_move(path: str, item: str, new_parent: str, index: int | None = None, out_path: str = "") -> dict:
        """Move an item or layer to another layer ("" = root, layers only) or position; root layers run in order,
        later ones override earlier ones."""
        return _edit(path, out_path, lambda d: {"path": author.move(d, item, new_parent, index)})

    @mcp.tool()
    def trn_add_feature(path: str, feature: Literal["flatten", "road", "river", "ribbon", "hole"], spec: dict,
                        parent: str = "", bake: bool = True, out_path: str = "") -> dict:
        """Add a whole feature in its own layer.
        flatten: {shape: {rect [x0,z0,x1,z1]} | {circle [x,z,r]} | {polygon [[x,z],...]}, height, feather (m,
          outward, default 8), feather_function 0-3 (default 3 ease in/out), shader_family, clear_flora (true),
          operation replace|add|subtract|multiply, name}.
        road: {points [[x,z],...], width, shader_family, heights (one per point = fixed-height road; omit to follow
          the baked ground profile), feather (0-1 of half width), shader_feather, name}.
        river: {points, width, bank_family, bottom_family, trench_depth, water (local water table), water_depth,
          water_width, water_shader (e.g. "wter_aqua"), water_shader_size, velocity, water_type water|lava, name}.
        ribbon: {points [[x,z,height],...], width, water_shader, terrain_shader_family, water_shader_size,
          velocity, cap_width, shader_feather, water_type, name}.
        hole: {shape: {circle [x,z,r]} | {polygon [[x,z],...]}, fine (true: titan's exact cut along the edge, make
          it larger than a tile; false: stock whole-tile cut), local (name it "local..." so a building .lay carries
          and turns it), name}.
        Layers run in order, so add features after the ground layers. bake=True bakes road/river height data."""
        fns = {"flatten": author.add_flatten, "road": author.add_road, "river": author.add_river,
               "ribbon": author.add_ribbon, "hole": author.add_hole}

        def fn(d):
            try:
                lp = fns[feature](d, parent=parent, **spec)
            except TypeError as exc:
                raise TrnError(f"{feature} spec: {exc}") from None
            res: dict[str, Any] = {"layer": lp}
            if bake and feature in ("road", "river"):
                res["baked"] = generator.bake_height_data(d, data_roots=DATA_ROOTS)
            return res
        return _edit(path, out_path, fn)

    @mcp.tool()
    def trn_bake(path: str, height_data: bool = True, water_and_slope: bool = True, out_path: str = "") -> dict:
        """The TerrainEditor's bakes, done by this package's generator: road and river height data (terrain
        profile sampled every ~8 m with roads/rivers off, then smoothed (roads) or terraced downhill (rivers); the
        engine reads it for every road and river) and the BakedTerrain water / steep-slope chunk maps (server
        placement). Large maps take a while (a 16 km map at 8 m chunks is ~4 M samples)."""
        def fn(d):
            res = {}
            if height_data:
                res["height_data"] = generator.bake_height_data(d, data_roots=DATA_ROOTS)
            if water_and_slope and d.kind == "trn":
                t0 = time.time()
                res["water_and_slope"] = generator.bake_terrain(d, data_roots=DATA_ROOTS)
                res["water_and_slope"]["seconds"] = round(time.time() - t0, 1)
            return res
        return _edit(path, out_path, fn)

    @mcp.tool()
    def trn_heights(path: str, points: list[list[float]], roads_and_rivers: bool = True,
                    buildings: list[dict] | None = None) -> dict:
        """Terrain height (world y) at x/z points as the client reports it, from this package's port of the engine
        generator: the point's full-detail tile fan, null in holes (stock exclude tiles, and titan's fine exclude
        cut along the boundary edge). buildings: [{layer ".lay", x, z, yaw degrees, height}] adds building terrain
        layers the way the client places them (height default: the terrain height at the origin). These are the
        values trn_client_verify compares with the client."""
        doc = _load(path)
        try:
            if buildings:
                doc, _ = verify.place_buildings(doc, buildings, _resolve)
        except (TrnError, KeyError, OSError) as exc:
            raise ToolError(str(exc)) from None
        return {"heights": generator.heights_at(doc, points, roads_and_rivers, DATA_ROOTS),
                "pole_spacing": generator.pole_spacing(doc)}

    @mcp.tool()
    def trn_preview(path: str, center: list[float] | None = None, size: float = 0.0, resolution: int = 192,
                    mode: Literal["height", "shader", "both"] = "both", out_png: str = ""):
        """Top-down preview (north = +z up) of the generated terrain: hillshaded heights, shader families in their
        family colours, or both; global water blue, holes magenta. center/size in metres (default: whole map).
        Returns the image and height statistics."""
        doc = _load(path)
        mw = float(doc.header.get("map_width", 1024.0)) if doc.kind == "trn" else 256.0
        size = size or mw
        cx, cz = center or [0.0, 0.0]
        n = max(16, min(int(resolution), 512))
        d = size / (n - 1)
        g = generator.evaluate(doc, cx - size / 2, cz - size / 2, d, n, n, data_roots=DATA_ROOTS)
        png, stats = generator.preview_png(doc, g, mode)
        if out_png:
            Path(out_png).parent.mkdir(parents=True, exist_ok=True)
            Path(out_png).write_bytes(png)
            stats["file"] = out_png
        return [Image(data=png, format="png"), stats]

    @mcp.tool()
    def trn_validate(path: str) -> dict:
        """Check a terrain: family ids every item references exist, roads/rivers are baked, polygon / polyline
        point counts, feather ranges, map / chunk / tile sizes, items outside the map, raw records, editor order."""
        doc = _load(path)
        return author.validate(doc)

    @mcp.tool()
    def trn_roundtrip(path: str = "", folder: str = "") -> dict:
        """Byte-identity check: load and re-write each file without changes and compare. path = one file;
        folder = every .trn / .lay under it (default: the stock terrain folder). Also lists records kept as raw
        bytes (none for stock files)."""
        files = [_resolve(path)] if path else sorted(
            p for root in ([folder] if folder else [str(Path(DATA_ROOTS[0]) / "terrain")])
            for p in Path(root).rglob("*") if p.suffix.lower() in (".trn", ".lay"))
        results, failures, raw = [], [], 0
        for f in files:
            try:
                r = trn.roundtrip(f)
            except (TrnError, ValueError) as exc:
                failures.append({"path": str(f), "error": str(exc)})
                continue
            raw += len(r["raw_records"])
            if not r["identical"] or r["raw_records"]:
                failures.append(r)
            results.append(r)
        return {"files": len(files), "identical": sum(1 for r in results if r["identical"]),
                "raw_records": raw, "problems": failures[:50]}

    @mcp.tool()
    def trn_upgrade(path: str, out_path: str = "") -> dict:
        """Rewrite every record in the TerrainEditor's current save versions (PTAT 0015, LAYR 0003, BREC 0004,
        BPOL 0007, AROA/ARIV 0006, SGRP 0006, RGRP 0004, ...), dropping bytes the engine never reads - what
        loading and saving in the editor does. Not needed for the engine (it loads every version)."""
        return _edit(path, out_path, author.upgrade)

    @mcp.tool()
    def trn_example(path: str = "terrain/titan_trn_test.trn", map_width: float = 2048.0, bake: bool = True) -> dict:
        """Write the example terrain that uses every feature: all six family tables, all four boundary types,
        all six filters, all eighteen affectors (incl. two roads - fixed-height and baked - a river with a local
        water table, a ribbon stream), nested and filtered layers, a flat pad, a lake with a local water table, a
        hole, and a global water table; baked and validated. Load it in the client with /scene load
        <name> (trn_client_verify does that)."""
        doc = author.example_terrain(Path(path).stem, map_width)
        res: dict[str, Any] = {}
        if bake:
            res["height_data"] = generator.bake_height_data(doc, data_roots=DATA_ROOTS)
            res["water_and_slope"] = generator.bake_terrain(doc, data_roots=DATA_ROOTS)
        res["saved"] = doc.save(_target(path, ""))
        res["validation"] = author.validate(doc)
        res["types"] = sorted({it["type"] for _, it, _ in doc.walk()})
        return res

    @mcp.tool()
    def trn_client_verify(path: str, areas: list[dict] | None = None, port: int | None = None, launch: bool = False,
                          tolerance: float = 0.25, load: bool = True, screenshot: bool = True,
                          buildings: list[dict] | None = None, spawn: bool = True):
        """Check a terrain in the offline development client (DevBridge): copy it to <export root>/terrain/,
        `/scene load <name>`, warp to each area, read the client's generated heights at pole positions (bridge
        `terrain`) and compare them with trn_heights. areas: [{center [x,z], radius m, step m}] (default centre,
        64 m). launch=True starts a client of our own on `port` (default 7038) with its token pinned here, so other
        sessions' swg_client_* tools keep their client; without it, the client in devbridge.json is used (it must
        be in a scene). areas may set pole_aligned=false with a fine step to test between poles (hole edges).
        buildings: [{layer ".lay", x, z, yaw, height?, template?}] - spawned with /scene objectCreate (spawn=True,
        template given) and their terrain layers added to the expectation; height defaults to the client's height at
        the origin. load=False compares the scene the client already has. Returns per-area max / mean differences,
        mismatched holes, the worst points, and a screenshot."""
        p = _resolve(path)
        try:
            res = verify.verify(p, EXPORT_ROOT, port, launch, areas, tolerance, load, DATA_ROOTS,
                                buildings=buildings, resolve=_resolve, spawn=spawn)
        except (client.ClientBridgeError, TrnError) as exc:
            raise ToolError(str(exc)) from None
        if not screenshot:
            return res
        try:
            b = verify.bridge_for(res.get("port"))
            reply = b.request("screenshot", path=f"screenshots/trn_verify_{int(time.time())}")["result"]
            shot = client.CLIENT_DIR / reply["file"]
            deadline = time.time() + 10.0
            while time.time() < deadline and not (shot.exists() and shot.stat().st_size > 0):
                time.sleep(0.1)
            time.sleep(0.2)
            data, fmt = client.image_for_mcp(shot)
            return [res, Image(data=data, format=fmt)]
        except (client.ClientBridgeError, KeyError, OSError) as exc:
            res["screenshot_error"] = str(exc)
            return res


def _env_roots(out_root: str) -> list[str]:
    return [r for r in [out_root, EXPORT_ROOT] if r] + DATA_ROOTS


def _env_out(out_root: str) -> str:
    root = out_root or EXPORT_ROOT
    if _is_stock(Path(root) / "terrain") and not out_root:
        raise ToolError("give out_root to write into the game data tree")
    return root


def register_env(mcp) -> None:

    @mcp.tool()
    def env_inspect(name: str, terrain: str = "", out_root: str = "") -> dict:
        """A terrain's client environment (the files GroundEnvironment loads by the terrain's name): the sky
        (terrain/environment/<name>.iff: night sky, stars, sun / second sun, moon / second moon, celestial bodies,
        time lock, skybox, distant appearances, planets) and the environment table (datatables/environment/
        <name>.iff: per environment family and weather index - sky gradient, clouds, lighting ramps, fog,
        shadows, environment maps, ambient sounds, music, wind). With `terrain`, also lists the terrain's
        environment families that have no row. Looks in out_root, the export root, then stock."""
        try:
            sky, table, found = env.load(name, _env_roots(out_root))
        except TrnError as exc:
            raise ToolError(str(exc)) from None
        out = {"files": found, **_jsonable(env.summary(sky, table))}
        if terrain:
            doc = _load(terrain)
            fams = [f["name"] for f in (doc.model["groups"].get("environment") or {"families": []})["families"]]
            out["terrain_families"] = fams
            out["families_without_rows"] = env.check_families(table, fams)
        return out

    @mcp.tool()
    def env_create(name: str, template: str = "tatooine", out_root: str = "", overwrite: bool = False) -> dict:
        """Start a terrain's environment as a copy of a stock one (both files; e.g. "lok", "tatooine",
        "mustafar"), written to out_root (default: the export root; the client finds it by the terrain's file
        name). Edit it with env_edit."""
        root = _env_out(out_root)
        if any(p.exists() for p in env.paths(root, name)) and not overwrite:
            raise ToolError(f"{name} environment exists in {root} (overwrite=True to replace)")
        try:
            sky, table = env.copy_from(template, _env_roots(""))
        except TrnError as exc:
            raise ToolError(str(exc)) from None
        return {"written": env.save(name, sky, table, root), **_jsonable(env.summary(sky, table))}

    @mcp.tool()
    def env_edit(name: str, sky: list[dict] | None = None, rows: list[dict] | None = None,
                 remove_rows: list[list] | None = None, template_family: str = "", out_root: str = "") -> dict:
        """Edit a terrain's environment (read from out_root / export root / stock, written to out_root, default the
        export root).
        sky: [{kind, index?, values}] - kind one of night_sky {shader}, stars {color_ramp, count}, sun / moon
        {shader, size, glow_shader, glow_size}, second_sun / second_moon (+ yaw, pitch degrees), time_lock
        {locked, time}, skybox {cube_map, texture_mask}, celestial {shader, size, glow_shader, glow_size, yaw,
        pitch, pitch_direction, cycle_time} (moons, rings, ships; several), distant {appearance, direction_x/y/z,
        orientation_x/y/z, infinite, flag}, planet {appearance, direction_x/y/z, orientation_x/y/z, halo_roll,
        halo_scale, infinite}. values null removes (single kinds, or the indexed celestial / distant / planet);
        no index adds a new celestial / distant / planet.
        rows: [{family, weather_index, sky_gradient, cloud_bottom_shader, cloud_bottom_size, cloud_bottom_speed,
        cloud_top_shader, cloud_top_size, cloud_top_speed, lighting_ramps, shadows, fog, fog_min_density,
        fog_max_density, camera_appearance, day_environment_map, night_environment_map, day_sound_1/2,
        night_sound_1/2, first_music, sunrise_music, sunset_music, wind_speed_scale}] - adds or changes the row
        for (family, weather_index); new rows copy template_family's row. remove_rows: [[family, weather_index]]."""
        try:
            s, t, _ = env.load(name, _env_roots(out_root))
            changed = []
            for op in sky or []:
                r = env.set_envm(s, op["kind"], op.get("values"), op.get("index"))
                changed.append({"kind": op["kind"], "now": r})
            for row in rows or []:
                changed.append({"row": env.set_env_row(t, row, template_family or None)})
            for fam, wi in remove_rows or []:
                t["rows"] = [r for r in t["rows"] if not (r[0] == fam and r[1] == int(wi))]
        except (TrnError, KeyError) as exc:
            raise ToolError(str(exc)) from None
        return {"written": env.save(name, s, t, _env_out(out_root)), "changed": _jsonable(changed)}


def register_planet_tool(mcp) -> None:

    @mcp.tool()
    def trn_register_planet(name: str, path: str, display_name: str, regions: list[dict] | None = None,
                            environment: str = "", env_template: str = "tatooine", map_image: bool = True,
                            repo: str = "D:/titan") -> dict:
        """Add a ground planet to the server, client and god client data in the repository (one-time backups
        <file>.pre-<name>): terrain/<name>.trn into the game data, the client environment (from `environment` -
        a name whose env files exist in the export root, e.g. made with env_create / env_edit - else a copy of
        env_template), loading tips, the display name (string/en/planet_n.stf), the planet map
        texture/ui_map_<name>.dds (rendered from the terrain), universe/planets.mif + .iff, the planet CRC string
        table, region tables (regions: [{name, x, z, radius} | {name, x0, z0, x1, z1}, geographical, buildable]),
        startPlanet=<name> in exe/linux/localOptions.cfg, and SwgGodClient's buildout-editor planet list (C++: the
        god client needs a rebuild for that list). The WSL server starts planets from TITAN_PLANETS."""
        doc_path = _resolve(path)
        try:
            envs = env.load(environment, [EXPORT_ROOT] + DATA_ROOTS)[:2] if environment else None
            return planet.register(repo, name, doc_path, display_name, regions, envs, env_template,
                                   map_image=map_image, data_roots=DATA_ROOTS)
        except (TrnError, OSError, ValueError) as exc:
            raise ToolError(str(exc)) from None


_HELP = {
    "feather_function": "0 linear, 1 ease in, 2 ease out, 3 ease in/out",
    "feather_distance": "circle / rectangle / filters / roads: 0-1 fraction of the radius / half the shorter side / "
                        "the range / half width; polygon: metres inward from the edge",
    "operation": "0 replace, 1 add, 2 subtract, 3 multiply",
    "water_type": "-1 invalid, 0 water, 1 lava",
    "min_angle": "degrees (slope: 0 flat - 90 vertical; direction: -180..180 of the downhill facing)",
    "family_id": "id in the matching family table (trn_families)",
}


def _param_help(tag: str) -> dict:
    if (tag, trn.LATEST.get(tag, "")) not in trn.LAYOUTS:
        return {}
    keys = [k for k, _ in trn.LAYOUTS[(tag, trn.LATEST[tag])][1]]
    return {k: v for k, v in _HELP.items() if k in keys}
