"""Authoring on top of the .trn model: new terrains, family tables, layer items in the editor's order, feature
helpers (flatten pads, roads, rivers, ribbons), the editor's save-time upgrade, validation, and an example
terrain that uses every boundary, filter, affector and family type."""

from __future__ import annotations

import copy
import math
from typing import Any

from . import trn
from .trn import TerrainDoc, TrnError

# PTAT defaults: ProceduralTerrainAppearanceTemplate::WriterData plus the flora tiling of stock simple.trn
HEADER_DEFAULTS: dict[str, Any] = {
    "name": "", "map_width": 4096.0, "chunk_width": 8.0, "tiles_per_chunk": 2, "use_global_water_table": False,
    "global_water_table_height": 0.0, "global_water_table_shader_size": 2.0, "global_water_table_shader": "",
    "environment_cycle_time": 3600.0,
    "collidable_min_distance": 0.0, "collidable_max_distance": 64.0, "collidable_tile_size": 8.0,
    "collidable_tile_border": 2.0, "collidable_seed": 0,
    "non_collidable_min_distance": 0.0, "non_collidable_max_distance": 64.0, "non_collidable_tile_size": 4.0,
    "non_collidable_tile_border": 0.5, "non_collidable_seed": 0,
    "radial_min_distance": 0.0, "radial_max_distance": 20.0, "radial_tile_size": 1.0, "radial_tile_border": 0.0,
    "radial_seed": 0,
    "far_radial_min_distance": 128.0, "far_radial_max_distance": 512.0, "far_radial_tile_size": 32.0,
    "far_radial_tile_border": 8.0, "far_radial_seed": 0,
    "legacy_map": False,
}

KIND_ORDER = {"boundary": 0, "filter": 1, "affector": 2, "layer": 3}

# which family group each item's family id points into
FAMILY_REFS: dict[str, list[tuple[str, str]]] = {
    "ASCN": [("family_id", "shader")], "ASRP": [("source_family_id", "shader"), ("destination_family_id", "shader")],
    "FSHD": [("family_id", "shader")], "AROA": [("family_id", "shader")],
    "ARIV": [("bank_family_id", "shader"), ("bottom_family_id", "shader")],
    "ARIB": [("terrain_shader_family_id", "shader")],
    "AFSC": [("family_id", "flora")], "AFSN": [("family_id", "flora")],
    "AFDN": [("family_id", "radial")], "AFDF": [("family_id", "radial")],
    "AENV": [("family_id", "environment")],
    "AHFR": [("family_id", "fractal")], "FFRA": [("family_id", "fractal")], "ACRF": [("family_id", "fractal")],
    "FBIT": [("family_id", "bitmap")],
}


def new_terrain(name: str = "", **header: Any) -> TerrainDoc:
    """An empty 0015 terrain: header defaults, empty family tables, no layers, empty bake and flora maps."""
    h = dict(HEADER_DEFAULTS)
    for k, v in header.items():
        if k not in h:
            raise TrnError(f"unknown map setting {k!r}; settings: {sorted(h)}")
        h[k] = v
    h["name"] = name or h["name"]
    model = {"version": "0015", "header": h,
             "groups": {g: {"version": trn.LATEST[trn.GROUP_TAGS[g]], "families": []} for g in trn.GROUP_TAGS},
             "layers": [], "tgen_order": ["shader", "flora", "radial", "environment", "fractal", "bitmap", "LYRS"],
             "baked": {"version": "0000", "raw": trn.form("0000")}, "flora_map": dict(trn.EMPTY_PIMP),
             "flora_height_map": {"map": dict(trn.EMPTY_PIMP), "resolution": 0.0}}
    return TerrainDoc("trn", model)


def set_map(doc: TerrainDoc, **settings: Any) -> dict[str, Any]:
    """Change map / chunk / tile / water / environment / flora tiling settings (ProceduralTerrainAppearanceTemplate
    DATA). map_width must be a multiple of chunk_width; tile width = chunk_width / tiles_per_chunk and the
    distance between height poles is half a tile."""
    if doc.kind != "trn":
        raise TrnError("map settings live in .trn files")
    h = doc.header
    for k, v in settings.items():
        if k not in h:
            raise TrnError(f"unknown map setting {k!r}; settings: {sorted(h)}")
        h[k] = type(h[k])(v) if isinstance(h[k], (int, float)) and not isinstance(h[k], bool) else v
    return {k: h[k] for k in settings}


# ----------------------------------------------------------------------------------------------------------------
# families

def add_family(doc: TerrainDoc, group: str, family: dict[str, Any]) -> dict[str, Any]:
    """Add a family (or replace the one with the same id); a missing id takes the next free one. Children get the
    group's child defaults filled in."""
    g = doc.group(group)
    fam = copy.deepcopy(trn.FAMILY_DEFAULTS[group])
    unknown = set(family) - set(fam) - {"id"} - ({"mfrc_version"} if group == "fractal" else set())
    if unknown:
        raise TrnError(f"{group} families have no {sorted(unknown)}; fields: {sorted(fam)}")
    fam.update(copy.deepcopy(family))
    if group in trn.CHILD_DEFAULTS:
        kids = []
        for c in fam.get("children", []):
            kd = dict(trn.CHILD_DEFAULTS[group])
            if group == "radial" and g["version"] == "0003":
                kd = {"shader": "", "weight": 1.0, "distance": 16.0, "width": 1.0, "height": 1.0, "should_sway": False,
                      "displacement": 0.0, "period": 1.0, "align_to_terrain": False, "create_plus": False}
            bad = set(c) - set(kd)
            if bad:
                raise TrnError(f"{group} children have no {sorted(bad)}; fields: {sorted(kd)}")
            kd.update(c)
            kids.append(kd)
        fam["children"] = kids
    if group == "shader" and g["version"] == "0004":
        fam.pop("surface_properties", None)
    ids = [f["id"] for f in g["families"]]
    if "id" not in fam or fam["id"] is None:
        fam["id"] = max(ids, default=0) + 1
    fam = {"id": fam.pop("id"), **fam}
    for i, f in enumerate(g["families"]):
        if f["id"] == fam["id"]:
            g["families"][i] = fam
            return fam
    g["families"].append(fam)
    return fam


def remove_family(doc: TerrainDoc, group: str, family_id: int) -> dict[str, Any]:
    g = doc.group(group)
    before = len(g["families"])
    g["families"] = [f for f in g["families"] if f["id"] != family_id]
    users = family_users(doc, group, family_id)
    return {"removed": before - len(g["families"]), "still_referenced_by": users}


def family_users(doc: TerrainDoc, group: str, family_id: int) -> list[str]:
    out = []
    for path, it, _ in doc.walk():
        for field, grp in FAMILY_REFS.get(it.get("tag", ""), []):
            if grp == group and "params" in it and it["params"].get(field) == family_id:
                out.append(f"{path} {it['tag']} {it.get('name', '')}".strip())
    return out


# ----------------------------------------------------------------------------------------------------------------
# items

def insert(doc: TerrainDoc, parent: str, item: dict, index: int | None = None) -> str:
    """Insert into a layer's item list (parent "" = the root layer list, which takes layers only). Without an index
    the item goes after the last item of its kind, keeping the editor's boundaries / filters / affectors / sublayers
    order. Returns the new item's path."""
    items = doc.container(parent)
    if parent in ("", None) and item.get("kind") != "layer":
        raise TrnError("only layers go at the root; give a layer path as parent")
    if index is None:
        rank = KIND_ORDER.get(item.get("kind"), 2)
        index = len(items)
        for i, it in enumerate(items):
            if KIND_ORDER.get(it.get("kind"), 2) > rank:
                index = i
                break
    index = max(0, min(index, len(items)))
    items.insert(index, item)
    return f"{parent.strip('/')}/{index}".lstrip("/") if parent else str(index)


def add_layer(doc: TerrainDoc, parent: str = "", name: str = "layer", **opts: Any) -> str:
    return insert(doc, parent, trn.new_layer(name, **opts))


def add_item(doc: TerrainDoc, parent: str, type_or_tag: str, name: str = "", params: dict | None = None,
             active: bool = True, index: int | None = None) -> str:
    item = trn.new_item(type_or_tag, name, params, active)
    return insert(doc, parent, item, index)


def update(doc: TerrainDoc, path: str, params: dict | None = None, name: str | None = None,
           active: bool | None = None, layer: dict | None = None) -> dict:
    node = doc.node(path)
    if "raw" in node:
        raise TrnError(f"{path} ({node.get('tag')}) is kept as raw bytes ({node.get('raw_reason')}); it can be "
                       "moved or removed but not edited")
    if name is not None:
        node["name"] = name
    if active is not None:
        node["active"] = bool(active)
    if params:
        if node.get("kind") == "layer":
            raise TrnError("layers have no params; use layer={invert_boundaries, invert_filters, expanded, notes}")
        bad = set(params) - set(node["params"])
        if bad:
            raise TrnError(f"{node['type']} has no {sorted(bad)}; parameters: {sorted(node['params'])}")
        node["params"].update(params)
    if layer:
        if node.get("kind") != "layer":
            raise TrnError("layer options only apply to layers")
        allowed = {"invert_boundaries", "invert_filters", "expanded", "notes"}
        bad = set(layer) - allowed
        if bad:
            raise TrnError(f"layers have no {sorted(bad)}; options: {sorted(allowed)}")
        node.update(layer)
    return node


def remove(doc: TerrainDoc, path: str) -> dict:
    idx = trn._parse_path(path)
    parent = "/".join(map(str, idx[:-1]))
    items = doc.container(parent)
    return items.pop(idx[-1])


def move(doc: TerrainDoc, path: str, new_parent: str, index: int | None = None) -> str:
    node = doc.node(path)
    if new_parent and (new_parent + "/").startswith(path.strip("/") + "/"):
        raise TrnError("cannot move a layer into itself")
    # resolve the target before removing (paths shift)
    target = doc.container(new_parent)
    remove(doc, path)
    if index is None:
        return insert_at_list(doc, new_parent, target, node)
    target.insert(max(0, min(index, len(target))), node)
    return _path_of(doc, node)


def insert_at_list(doc: TerrainDoc, parent: str, items: list, node: dict) -> str:
    rank = KIND_ORDER.get(node.get("kind"), 2)
    index = next((i for i, it in enumerate(items) if KIND_ORDER.get(it.get("kind"), 2) > rank), len(items))
    items.insert(index, node)
    return _path_of(doc, node)


def _path_of(doc: TerrainDoc, node: dict) -> str:
    for p, it, _ in doc.walk():
        if it is node:
            return p
    raise TrnError("node not found")


# ----------------------------------------------------------------------------------------------------------------
# features

def _boundary_for(shape: dict, feather: float, feather_function: int, name: str) -> dict:
    """shape: {"rect": [x0, z0, x1, z1]} | {"circle": [x, z, r]} | {"polygon": [[x, z], ...]}; the flat area is the
    shape, feathered `feather` metres outward (the boundary grows by `feather`)."""
    if "rect" in shape:
        x0, z0, x1, z1 = shape["rect"]
        ox0, oz0, ox1, oz1 = min(x0, x1) - feather, min(z0, z1) - feather, max(x0, x1) + feather, max(z0, z1) + feather
        frac = min(1.0, 2.0 * feather / min(ox1 - ox0, oz1 - oz0)) if feather > 0 else 0.0
        return trn.new_item("rectangle", name, {"x0": ox0, "z0": oz0, "x1": ox1, "z1": oz1,
                                                 "feather_function": feather_function, "feather_distance": frac})
    if "circle" in shape:
        x, z, r = shape["circle"]
        outer = r + feather
        return trn.new_item("circle", name, {"center_x": x, "center_z": z, "radius": outer,
                                              "feather_function": feather_function,
                                              "feather_distance": feather / outer if outer else 0.0})
    if "polygon" in shape:
        from ..iff import grow_outline
        pts = shape["polygon"]
        outer = grow_outline([tuple(p) for p in pts], feather) if feather > 0 else [tuple(p) for p in pts]
        return trn.new_item("polygon", name, {"points": [list(p) for p in outer], "feather_function": feather_function,
                                               "feather_distance": float(feather)})
    raise TrnError("shape needs rect [x0, z0, x1, z1], circle [x, z, r] or polygon [[x, z], ...]")


def add_flatten(doc: TerrainDoc, shape: dict, height: float, feather: float = 8.0, feather_function: int = 3,
                parent: str = "", name: str = "flatten", shader_family: int | None = None,
                clear_flora: bool = True, operation: str = "replace") -> str:
    """A flat pad: a layer with a boundary round `shape` (flat inside, eased `feather` m outward), a height
    constant, optionally a shader constant, and flora / radial removal. Add it after the layers that make the
    ground so it overrides them. Returns the layer path."""
    lp = add_layer(doc, parent, name)
    insert(doc, lp, _boundary_for(shape, feather, feather_function, f"{name} area"))
    insert(doc, lp, trn.new_item("height_constant", f"{name} height",
                                 {"operation": trn.OPERATIONS.index(operation), "height": float(height)}))
    if shader_family is not None:
        insert(doc, lp, trn.new_item("shader_constant", f"{name} shader", {"family_id": int(shader_family)}))
    if clear_flora:
        for t in ("flora_static_collidable", "flora_static_non_collidable", "flora_dynamic_near",
                  "flora_dynamic_far"):
            insert(doc, lp, trn.new_item(t, f"{name} clear {t.split('_', 1)[1]}", {"remove_all": True}))
    return lp


def _layer_for(doc: TerrainDoc, parent: str, name: str) -> str:
    """Roads / rivers / ribbons sit in their own layer (no boundary: they bound themselves)."""
    return add_layer(doc, parent, name)


def add_road(doc: TerrainDoc, points: list, width: float = 8.0, shader_family: int = 1,
             heights: list[float] | None = None, feather: float = 0.5, shader_feather: float = 0.25,
             feather_function: int = 3, parent: str = "", name: str = "road") -> str:
    """A road (AffectorRoad 0006) in its own layer. With `heights` (one per point) it uses fixed heights (ramped
    between control points, feathered into the ground); without, its height follows the baked terrain profile
    (bake_height_data / trn_bake). Height data is baked either way: the engine reads it for every road."""
    params = {"points": [list(map(float, p[:2])) for p in points], "width": float(width),
              "family_id": int(shader_family), "feather_function": feather_function,
              "feather_distance": float(feather), "feather_function_shader": feather_function,
              "feather_distance_shader": float(shader_feather)}
    if heights is not None:
        if len(heights) != len(points):
            raise TrnError("heights needs one value per point")
        params.update(heights=[float(h) for h in heights], has_fixed_heights=True)
    lp = _layer_for(doc, parent, name)
    insert(doc, lp, trn.new_item("road", name, params))
    return lp


def add_river(doc: TerrainDoc, points: list, width: float = 16.0, bank_family: int = 1, bottom_family: int = 1,
              trench_depth: float = 3.0, feather: float = 0.5, water: bool = True, water_depth: float = 1.0,
              water_width: float = 8.0, water_shader: str = "", water_shader_size: float = 2.0,
              velocity: float = 1.0, water_type: str = "water", parent: str = "", name: str = "river") -> str:
    """A river (AffectorRiver 0006) in its own layer: cuts `trench_depth` m below the baked profile (which steps
    only downhill), banks and bottom in the given shader families, and optionally a local water table
    `water_depth` m under the profile, `water_width` m wide."""
    wt = {v: k for k, v in trn.WATER_TYPES.items()}[water_type]
    params = {"points": [list(map(float, p[:2])) for p in points], "width": float(width),
              "bank_family_id": int(bank_family), "bottom_family_id": int(bottom_family), "feather_function": 0,
              "feather_distance": float(feather), "trench_depth": float(trench_depth), "velocity": float(velocity),
              "has_local_water_table": bool(water), "local_water_table_depth": float(water_depth),
              "local_water_table_width": float(water_width), "local_water_table_shader_size": float(water_shader_size),
              "local_water_table_shader": water_shader, "water_type": wt}
    lp = _layer_for(doc, parent, name)
    insert(doc, lp, trn.new_item("river", name, params))
    return lp


def add_hole(doc: TerrainDoc, shape: dict, parent: str = "", fine: bool = True, local: bool = False,
             name: str = "hole") -> str:
    """A hole in the terrain: a layer with a circle {"circle": [x, z, r]} or polygon {"polygon": [[x, z], ...]}
    boundary and an exclude affector. fine (titan, AEXC 0001): tiles inside are dropped and the edge poles of
    crossed tiles move onto the boundary, so the cut follows the shape (chords between those poles); make it
    larger than a tile (chunk_width / tiles_per_chunk). fine=False is the stock cut: whole tiles, tested at each
    tile's corner pole. local=True names the boundary "local..." so a building layer (.lay) carries it along and
    turns it with the building."""
    lp = add_layer(doc, parent, name)
    bname = ("local " if local else "") + name
    if "circle" in shape:
        x, z, r = shape["circle"]
        insert(doc, lp, trn.new_item("circle", bname, {"center_x": float(x), "center_z": float(z), "radius": float(r)}))
    elif "polygon" in shape:
        insert(doc, lp, trn.new_item("polygon", bname, {"points": [list(map(float, q)) for q in shape["polygon"]]}))
    else:
        raise TrnError("hole shape needs circle [x, z, r] or polygon [[x, z], ...]")
    insert(doc, lp, trn.new_item("exclude", f"{name} cut", {"fine": True} if fine else None))
    return lp


def add_ribbon(doc: TerrainDoc, points: list, width: float = 8.0, water_shader: str = "",
               terrain_shader_family: int = 1, water_shader_size: float = 2.0, velocity: float = 1.0,
               cap_width: float = 8.0, shader_feather: float = 0.25, water_type: str = "water", parent: str = "",
               name: str = "ribbon") -> str:
    """A water ribbon (AffectorRibbon 0005): a strip of water following [x, z, height] points (streams,
    waterfalls), painting the terrain shader family underneath. It does not change height."""
    wt = {v: k for k, v in trn.WATER_TYPES.items()}[water_type]
    params = {"points": [[float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0] for p in points],
              "width": float(width), "water_shader_size": float(water_shader_size), "velocity": float(velocity),
              "cap_width": float(cap_width), "terrain_shader_family_id": int(terrain_shader_family),
              "feather_function_terrain_shader": 0, "feather_distance_terrain_shader": float(shader_feather),
              "water_shader": water_shader, "water_type": wt}
    lp = _layer_for(doc, parent, name)
    insert(doc, lp, trn.new_item("ribbon", name, params))
    return lp


# ----------------------------------------------------------------------------------------------------------------
# editor save (upgrade every record to the current save version)

def upgrade(doc: TerrainDoc) -> dict[str, int]:
    """What TerrainEditor's save does to an older file: every record in its current version (LATEST), the
    ignored tails dropped. Records kept raw stay raw."""
    counts: dict[str, int] = {}

    def bump(key):
        counts[key] = counts.get(key, 0) + 1

    def item(it: dict):
        if "raw" in it:
            return
        if it.get("ihdr_version") == "0000":
            it.pop("ihdr_version")
            it.pop("tool_color", None)
            bump("IHDR 0000")
        if it.get("kind") == "layer":
            if it["version"] != "0003":
                bump(f"LAYR {it['version']}")
                it["version"] = "0003"
                it.pop("unused", None)
            it.pop("adta_trailing", None)
            for c in it["items"]:
                item(c)
            return
        tag, ver = it["tag"], it["version"]
        p = it["params"]
        p.pop("_trailing", None)
        if ver == trn.LATEST[tag] or (tag, ver) == ("AEXC", "0001"):    # titan's fine exclude is newer than stock
            return
        fresh = trn.defaults(tag)
        fresh.update({k: v for k, v in p.items() if k in fresh})
        if tag == "AROA" and ver == "0005":
            fresh["heights"], fresh["has_fixed_heights"] = [], False
        it["params"], it["version"] = fresh, trn.LATEST[tag]
        bump(f"{tag} {ver}")

    for layer in doc.layers:
        item(layer)
    for name, g in doc.model["groups"].items():
        if not g or "raw" in g:
            continue
        tag = trn.GROUP_TAGS[name]
        for f in g["families"]:
            f.pop("_trailing", None)
            f.pop("extra_data", None)
            f.pop("extra_blocks", None)
            f.pop("mfrc_version", None)
            if name == "shader":
                f.setdefault("surface_properties", "")
                g["families"][g["families"].index(f)] = {"id": f["id"], "name": f["name"],
                                                         "surface_properties": f["surface_properties"],
                                                         **{k: v for k, v in f.items()
                                                            if k not in ("id", "name", "surface_properties")}}
            if name == "radial" and g["version"] == "0003":
                for c in f["children"]:
                    w, h = c.pop("width"), c.pop("height")
                    c.update(min_width=w, max_width=w, min_height=h, max_height=h, maintain_aspect_ratio=False)
                    order = list(trn.CHILD_DEFAULTS["radial"])
                    c_sorted = {k: c[k] for k in order}
                    c.clear()
                    c.update(c_sorted)
            for c in f.get("children", []):
                c.pop("_trailing", None)
        if g["version"] != trn.LATEST[tag]:
            bump(f"{tag} {g['version']}")
            g["version"] = trn.LATEST[tag]
    if doc.kind == "trn":
        m = doc.model
        if m["version"] != "0015":
            bump(f"PTAT {m['version']}")
            h = {k: v for k, v in m["header"].items() if not k.startswith("legacy_")}
            h["legacy_map"] = True          # the template loads pre-0015 maps as legacy
            m["header"] = h
            m["version"] = "0015"
            m.setdefault("flora_map", None)
            m["flora_map"] = m["flora_map"] or dict(trn.EMPTY_PIMP)
            m["flora_height_map"] = m.get("flora_height_map") or {"map": dict(trn.EMPTY_PIMP), "resolution": 0.0}
        m["header"].pop("_trailing", None)
    return counts


# ----------------------------------------------------------------------------------------------------------------
# validation

def validate(doc: TerrainDoc) -> dict[str, Any]:
    """Problems the engine would trip on (errors) or that are likely mistakes (warnings)."""
    errors: list[str] = []
    warnings: list[str] = []
    if doc.kind == "space":
        return {"errors": [], "warnings": ["space zone (STAT): not procedural, nothing to check"], "ok": True}
    if doc.kind == "trn":
        h = doc.header
        mw, cw, tpc = h["map_width"], h["chunk_width"], h["tiles_per_chunk"]
        if cw <= 0 or tpc <= 0:
            errors.append(f"chunk_width {cw} and tiles_per_chunk {tpc} must be positive")
        elif abs(mw / cw - round(mw / cw)) > 1e-6 or int(round(mw / cw)) % 2:
            errors.append(f"map_width {mw} must be an even number of chunks ({cw} m)")
        if tpc & (tpc - 1):
            warnings.append(f"tiles_per_chunk {tpc} is not a power of two (stock: 2 or 8)")
        if doc.model["version"] != "0015":
            warnings.append(f"PTAT {doc.model['version']}: loads (engine reads 0013-0015) but the editor saves 0015 "
                            "(trn_save upgrade=true)")
        bk = doc.model.get("baked") or {}
        if bk.get("version") == "0001" and (bk.get("map_width") != mw or bk.get("chunk_width") != cw):
            warnings.append("baked terrain was made for a different map / chunk size: re-bake (trn_bake)")
        if h.get("use_global_water_table") and not h.get("global_water_table_shader"):
            warnings.append("global water table on but no water shader")
        half = mw / 2
    else:
        half = None
    ids: dict[str, set] = {}
    for name, g in doc.model["groups"].items():
        if not g:
            continue
        seen = set()
        for f in g["families"]:
            if f["id"] in seen:
                errors.append(f"{name} family id {f['id']} used twice")
            seen.add(f["id"])
            if name in ("shader", "flora", "radial") and not f.get("children"):
                warnings.append(f"{name} family {f['id']} {f.get('name')!r} has no children")
            if name == "bitmap" and not f.get("bitmap"):
                warnings.append(f"bitmap family {f['id']} has no image")
        ids[name] = seen
    for path, it, depth in doc.walk():
        if "raw" in it:
            warnings.append(f"{path} {it.get('tag')} kept raw ({it.get('raw_reason')})")
            continue
        tag = it["tag"]
        if it.get("kind") == "layer":
            kids = it["items"]
            ranks = [KIND_ORDER.get(c.get("kind"), 2) for c in kids]
            if ranks != sorted(ranks):
                warnings.append(f"{path} layer {it.get('name')!r}: items not in boundaries/filters/affectors/sublayers "
                                "order (the editor re-sorts on save; evaluation order is unchanged)")
            if depth == 0 and it.get("active") and not any(c.get("kind") == "boundary" for c in kids) and any(
                    c.get("tag") == "AEXC" and c.get("active") for c in kids):
                warnings.append(f"{path}: an exclude affector without boundaries removes the whole terrain")
            continue
        p = it["params"]
        for field, grp in FAMILY_REFS.get(tag, []):
            fid = p.get(field)
            if grp in ids and fid not in ids[grp]:
                errors.append(f"{path} {tag} {it.get('name')!r}: {field} {fid} is not a {grp} family")
            elif grp not in ids:
                errors.append(f"{path} {tag}: no {grp} family table")
        if tag in ("BCIR", "BREC", "FHGT", "FFRA", "FSLP", "FDIR", "FBIT") and not 0 <= p.get(
                "feather_distance", 0.0) <= 1:
            warnings.append(f"{path} {tag}: feather_distance {p['feather_distance']} is a 0-1 fraction (clamped)")
        if tag == "BPOL" and len(p["points"]) < 3:
            errors.append(f"{path} polygon needs 3+ points")
        if tag in ("BPLN", "AROA", "ARIV", "ARIB") and len(p["points"]) < 2:
            errors.append(f"{path} {tag} needs 2+ points")
        if tag in ("AROA", "ARIV"):
            hd = it.get("height_data") or []
            if len(hd) != max(len(p["points"]) - 1, 0) or any(len(s) < 2 for s in hd):
                errors.append(f"{path} {tag} {it.get('name')!r}: height data not baked ({len(hd)} segments for "
                              f"{len(p['points'])} points): the engine reads it for every road/river (trn_bake)")
            if tag == "AROA" and p.get("has_fixed_heights") and len(p.get("heights", [])) != len(p["points"]):
                errors.append(f"{path} road: fixed heights need one height per point")
        if half is not None and tag in ("BCIR", "BREC", "BPOL", "BPLN"):
            xs = ([p["x0"], p["x1"]] if tag == "BREC" else [p["center_x"]] if tag == "BCIR"
                  else [q[0] for q in p["points"]])
            zs = ([p["z0"], p["z1"]] if tag == "BREC" else [p["center_z"]] if tag == "BCIR"
                  else [q[1] for q in p["points"]])
            if xs and (max(map(abs, xs)) > half or max(map(abs, zs)) > half):
                warnings.append(f"{path} {tag} {it.get('name')!r} reaches outside the map (+-{half:g} m)")
    return {"errors": errors, "warnings": warnings, "ok": not errors}


# ----------------------------------------------------------------------------------------------------------------
# example: every feature

def example_terrain(name: str = "titan_trn_test", map_width: float = 2048.0) -> TerrainDoc:
    """A small terrain that uses every family table, boundary, filter and affector type, with stock assets:
    fractal hills, a terraced mesa, a plateau with a flat pad (rectangle) and a round pad (circle), a lake basin
    (polygon, local water table), a road with fixed heights and a baked road, a river, a ribbon stream, a polyline
    trail, slope / direction / height / fractal / shader / bitmap filtered painting, colour, flora, radial,
    environment, passable and exclude affectors. Bake roads/rivers and the water/slope map before saving
    (trn_example does)."""
    doc = new_terrain(f"terrain/{name}.trn", map_width=float(map_width), chunk_width=8.0, tiles_per_chunk=2,
                      use_global_water_table=True, global_water_table_height=-20.0,
                      global_water_table_shader="wter_spec", global_water_table_shader_size=32.0,
                      environment_cycle_time=3600.0)
    # families (stock shader / flora / radial names, see simple.trn and 09.trn)
    sh = {n: add_family(doc, "shader", {"name": n, "color": c, "children": [{"shader": s} for s in kids]})["id"]
          for n, c, kids in [("grass", [80, 160, 60], ["grss_clumpydark", "grss_dant_yellow"]),
                             ("dirt", [150, 110, 70], ["dirt_bigcracks", "dirt_everdirt"]),
                             ("rock", [120, 120, 120], ["dirt_coolmud"]),
                             ("road", [200, 200, 200], ["corellia_concrete_a_hcb13"]),
                             ("riverbed", [60, 60, 140], ["dirt_coolmud"]),
                             ("snow", [240, 240, 255], ["grss_dath_mintgreen"])]}
    trees = add_family(doc, "flora", {"name": "trees", "density": 0.3, "children": [
        {"appearance": "decd_whitebirchtreebranches.apt", "should_sway": True, "displacement": 0.01, "period": 0.1}]})["id"]
    rocks = add_family(doc, "flora", {"name": "rocks", "density": 0.2, "children": [
        {"appearance": "decd_dath_azerontree.apt"}]})["id"]
    grass = add_family(doc, "radial", {"name": "grass", "density": 1.0, "children": [
        {"shader": "radl_grss_lightgreen_tall", "distance": 16.0, "min_width": 0.8, "max_width": 1.2,
         "min_height": 0.8, "max_height": 1.2, "should_sway": True, "displacement": 0.25, "period": 0.35}]})["id"]
    env_day = add_family(doc, "environment", {"name": "default"})["id"]
    env_mist = add_family(doc, "environment", {"name": "mist"})["id"]
    hills = add_family(doc, "fractal", {"name": "hills", "seed": 12345, "octaves": 4, "frequency": 2.0,
                                        "amplitude": 0.5, "scale_x": 0.004, "scale_y": 0.004})["id"]
    noise = add_family(doc, "fractal", {"name": "patches", "seed": 777, "octaves": 2, "scale_x": 0.03,
                                        "scale_y": 0.03})["id"]
    mask = add_family(doc, "bitmap", {"name": "mask", "bitmap": "terrain/tatt_heightmap_jawa_tradepost.tga"})["id"]

    # 1 base: fractal hills everywhere, grass, default environment, colour ramps
    base = add_layer(doc, "", "base")
    add_item(doc, base, "height_fractal", "hills", {"family_id": hills, "operation": 0, "scale_y": 60.0})
    add_item(doc, base, "shader_constant", "grass", {"family_id": sh["grass"]})
    add_item(doc, base, "environment", "day", {"family_id": env_day})
    add_item(doc, base, "color_ramp_height", "height tint", {"low_height": -10.0, "high_height": 80.0,
                                                              "image": "terrain/echo_base_colorramp_base_snow.tga"})
    add_item(doc, base, "color_ramp_fractal", "patch tint", {"family_id": noise, "operation": 3,
                                                              "image": "terrain/tatt_colorramp_base_sand.tga"})
    add_item(doc, base, "flora_dynamic_near", "grass", {"family_id": grass, "operation": 1})
    add_item(doc, base, "flora_dynamic_far", "grass far", {"family_id": grass, "operation": 1})

    # 2 painting by filters (sublayers of a filters layer)
    paint = add_layer(doc, "", "painting")
    steep = add_layer(doc, paint, "steep rock")
    add_item(doc, steep, "slope", "steep", {"min_angle": 30.0, "max_angle": 90.0, "feather_distance": 0.2})
    add_item(doc, steep, "shader_constant", "rock", {"family_id": sh["rock"]})
    add_item(doc, steep, "flora_static_collidable", "rocks", {"family_id": rocks, "operation": 1})
    north = add_layer(doc, paint, "north faces")
    add_item(doc, north, "direction", "north", {"min_angle": -45.0, "max_angle": 45.0, "feather_distance": 0.1})
    add_item(doc, north, "slope", "some slope", {"min_angle": 10.0, "max_angle": 90.0})
    add_item(doc, north, "color_constant", "shade", {"operation": 3, "color": [200, 200, 220]})
    high = add_layer(doc, paint, "peaks")
    add_item(doc, high, "height", "high", {"low_height": 45.0, "high_height": 500.0, "feather_distance": 0.1})
    add_item(doc, high, "shader_constant", "snow", {"family_id": sh["snow"]})
    patches = add_layer(doc, paint, "dirt patches")
    add_item(doc, patches, "fractal", "patches", {"family_id": noise, "low": 0.6, "high": 1.0, "scale_y": 1.0,
                                                  "feather_distance": 0.2})
    add_item(doc, patches, "shader", "only on grass", {"family_id": sh["grass"]})
    add_item(doc, patches, "shader_replace", "grass to dirt", {"source_family_id": sh["grass"],
                                                               "destination_family_id": sh["dirt"]})
    woods = add_layer(doc, paint, "woods", invert_filters=False)
    add_item(doc, woods, "circle", "woods area", {"center_x": -500.0, "center_z": 500.0, "radius": 300.0,
                                                  "feather_function": 3, "feather_distance": 0.3})
    add_item(doc, woods, "bitmap", "mask", {"family_id": mask, "low": 0.0, "high": 1.0})
    add_item(doc, woods, "flora_static_collidable", "trees", {"family_id": trees, "operation": 1})
    add_item(doc, woods, "flora_static_non_collidable", "undergrowth", {"family_id": rocks, "operation": 1,
                                                                        "density_override": True,
                                                                        "density_override_density": 0.2})
    add_item(doc, woods, "environment", "mist", {"family_id": env_mist, "use_feather_clamp_override": True,
                                                 "feather_clamp_override": 0.5})

    # 3 landforms
    mesa = add_layer(doc, "", "terraced mesa")
    add_item(doc, mesa, "circle", "mesa", {"center_x": 500.0, "center_z": 500.0, "radius": 220.0,
                                           "feather_function": 3, "feather_distance": 0.5})
    add_item(doc, mesa, "height_constant", "raise", {"operation": 1, "height": 40.0})
    add_item(doc, mesa, "height_terrace", "terraces", {"fraction": 0.6, "height": 8.0})
    lake = add_layer(doc, "", "lake basin")
    add_item(doc, lake, "polygon", "lake", {"points": [[-600.0, -350.0], [-350.0, -420.0], [-250.0, -250.0],
                                                       [-380.0, -120.0], [-620.0, -180.0]],
                                            "feather_function": 3, "feather_distance": 60.0,
                                            "local_water_table": True, "water_height": -2.0,
                                            "water_shader_size": 8.0, "water_shader": "wter_aqua"})
    add_item(doc, lake, "height_constant", "basin", {"operation": 0, "height": -8.0})
    add_item(doc, lake, "flora_static_collidable", "no trees", {"family_id": trees, "remove_all": True})
    add_item(doc, lake, "flora_dynamic_near", "no grass", {"family_id": grass, "remove_all": True})

    # 4 flat pads
    add_flatten(doc, {"rect": [-60.0, -60.0, 60.0, 60.0]}, height=12.0, feather=24.0, name="landing pad",
                shader_family=sh["road"])
    add_flatten(doc, {"circle": [300.0, -300.0, 40.0]}, height=20.0, feather=20.0, name="round pad",
                shader_family=sh["dirt"])

    # 5 roads, river, ribbon, trail
    add_road(doc, [[60.0, 0.0], [200.0, 40.0], [300.0, -260.0]], width=10.0, shader_family=sh["road"],
             heights=[12.0, 16.0, 20.0], name="pad road")
    add_road(doc, [[-60.0, 0.0], [-300.0, 100.0], [-500.0, 450.0]], width=8.0, shader_family=sh["dirt"],
             name="woods road")
    add_river(doc, [[-900.0, 300.0], [-700.0, 120.0], [-560.0, -180.0], [-400.0, -280.0]], width=24.0,
              bank_family=sh["dirt"], bottom_family=sh["riverbed"], trench_depth=4.0, water=True, water_depth=1.5,
              water_width=12.0, water_shader="wter_aqua", name="river")
    add_ribbon(doc, [[650.0, 380.0, 44.0], [700.0, 300.0, 30.0], [720.0, 200.0, 18.0]], width=6.0,
               water_shader="wter_aqua", terrain_shader_family=sh["riverbed"], name="mesa stream")
    trail = add_layer(doc, "", "trail")
    add_item(doc, trail, "polyline", "trail", {"points": [[0.0, -60.0], [40.0, -300.0], [-100.0, -600.0]],
                                               "width": 3.0, "feather_distance": 0.5})
    add_item(doc, trail, "shader_constant", "trail dirt", {"family_id": sh["dirt"], "use_feather_clamp_override": True,
                                                           "feather_clamp_override": 0.5})
    add_item(doc, trail, "passable", "trail passable", {"passable": True, "feather_threshold": 0.5})

    # 6 a fenced-off zone and a hole
    block = add_layer(doc, "", "impassable cliff zone")
    add_item(doc, block, "rectangle", "zone", {"x0": 600.0, "z0": -700.0, "x1": 800.0, "z1": -500.0})
    add_item(doc, block, "passable", "impassable", {"passable": False, "feather_threshold": 0.0})
    hole = add_layer(doc, "", "cave mouth")
    add_item(doc, hole, "circle", "hole", {"center_x": 700.0, "center_z": -600.0, "radius": 12.0})
    add_item(doc, hole, "exclude", "hole")
    return doc
