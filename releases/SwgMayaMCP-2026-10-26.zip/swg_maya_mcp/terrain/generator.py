"""Pure-Python port of the terrain generator's height path (TerrainGenerator::Layer::affect and the boundaries,
filters and affectors that shape height, shader families and holes), for previews, expected heights in client
checks and the editor's bakes:

  * evaluate(doc, x0, z0, spacing, nx, nz) -> heights, shader family ids and exclude flags on a pole grid,
  * bake_height_data(doc) -> road / river HDTA (EditorTerrain::buildHeightData + MapView's 8 m sampling +
    HeightData::createRoadData / createRiverData),
  * bake_terrain(doc) -> BakedTerrain water / steep-slope bitmaps (EditorTerrain::bakeTerrain),
  * preview_png(...) -> a hillshaded height map (or shader-family map) as PNG bytes,
  * place_layer(...) -> a building's terrain layer (.lay) placed into a world terrain the way the client does it
    (ClientObjectTerrainModificationNotification: setPosition / setRotation / setHeight),
  * client_heights(...) -> heights the way the client's TerrainObject::getHeight answers them: the tile's
    8-triangle fan (with titan's fine exclusion: tiles inside a fine exclude dropped, edge poles moved onto the
    boundary edge), None in holes.

Order and fuzzy logic follow the engine: boundaries OR together (max of feathered amounts), filters AND (min), each
layer passes amount * parent amount to its affectors and sublayers. Colour, flora, environment and passable
affectors do not change height and are skipped. Bitmap filters pass (1.0) unless their image can be read.
"""

from __future__ import annotations

import copy
import math
import struct
import zlib
from pathlib import Path
from typing import Any

from .fractal import MultiFractal
from .trn import TerrainDoc


def _clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def _feather(fn: int, t: float) -> float:
    """Feather::feather(0, 1, t)."""
    if fn == 1:
        return t * t
    if fn == 2:
        return math.sqrt(t) if t > 0 else 0.0
    if fn == 3:
        return (3.0 - 2.0 * t) * t * t
    return t


def _interp(lo: float, v: float, hi: float, feather: float) -> float:
    """computeFeatheredInterpolant (exclusive range)."""
    if not (lo < v < hi):
        return 0.0
    f = feather * (hi - lo) * 0.5
    if f > 0 and v < lo + f:
        return (v - lo) / f
    if f > 0 and v > hi - f:
        return (hi - v) / f
    return 1.0


# ----------------------------------------------------------------------------------------------------------------
# boundaries

class _Boundary:
    def __init__(self, item: dict):
        p = item["params"]
        self.tag = item["tag"]
        self.ff = int(p.get("feather_function", 0))
        fd = float(p.get("feather_distance", 0.0))
        if self.tag == "BCIR":
            self.cx, self.cz, self.r = p["center_x"], p["center_z"], p["radius"]
            self.fd = _clamp(fd, 0.0, 1.0)
            self.bbox = (self.cx - self.r, self.cz - self.r, self.cx + self.r, self.cz + self.r)
        elif self.tag == "BREC":
            x0, x1 = sorted((p["x0"], p["x1"]))
            z0, z1 = sorted((p["z0"], p["z1"]))
            self.fd = _clamp(fd, 0.0, 1.0)
            self.rect = (x0, z0, x1, z1)
            self.feather = 0.5 * min(x1 - x0, z1 - z0) * self.fd
            self.bbox = self.rect
            # a building layer's rectangle is local to the building: BoundaryRectangle::setCenter / setRotation
            self.transform = item.get("_transform")          # (center x, center z, yaw radians) or None
            if self.transform:
                cx, cz, yaw = self.transform
                c, s_ = math.cos(yaw), math.sin(yaw)
                corners = [(cx + c * x + s_ * z, cz - s_ * x + c * z) for x in (x0, x1) for z in (z0, z1)]
                self.bbox = (min(q[0] for q in corners), min(q[1] for q in corners),
                             max(q[0] for q in corners), max(q[1] for q in corners))
        else:
            self.pts = [tuple(q) for q in p["points"]]
            self.fd = fd
            xs = [q[0] for q in self.pts] or [0.0]
            zs = [q[1] for q in self.pts] or [0.0]
            pad = p.get("width", 0.0) if self.tag == "BPLN" else 0.0
            self.width = p.get("width", 0.0)
            self.bbox = (min(xs) - pad, min(zs) - pad, max(xs) + pad, max(zs) + pad)

    def within(self, x: float, z: float) -> float:
        b = self.bbox
        if x < b[0] or x > b[2] or z < b[1] or z > b[3]:
            return 0.0
        if self.tag == "BCIR":
            d2 = (self.cx - x) ** 2 + (self.cz - z) ** 2
            r2 = self.r * self.r
            if d2 > r2:
                return 0.0
            inner = (self.r * (1.0 - self.fd)) ** 2
            if d2 <= inner:
                return 1.0
            return 1.0 - (d2 - inner) / (r2 - inner)
        if self.tag == "BREC":
            x0, z0, x1, z1 = self.rect
            if self.transform:                                # rotateTranslate_p2l
                cx, cz, yaw = self.transform
                c, s_ = math.cos(yaw), math.sin(yaw)
                dx, dz = x - cx, z - cz
                x, z = c * dx - s_ * dz, s_ * dx + c * dz
            if not (x0 <= x <= x1 and z0 <= z <= z1):
                return 0.0
            if self.fd == 0.0:
                return 1.0
            f = self.feather
            d = min(f, x - x0, x1 - x, z - z0, z1 - z)
            return 1.0 if d >= f else d / f
        if self.tag == "BPOL":
            return self._polygon(x, z)
        return self._polyline(x, z)

    def has_exact_edge(self) -> bool:
        """Boundary::hasExactEdge: circles, and polygons with 3+ points."""
        return self.tag == "BCIR" or (self.tag == "BPOL" and len(self.pts) >= 3)

    def nearest_edge(self, x: float, z: float) -> tuple[float, float] | None:
        """Boundary::getNearestEdgePoint (titan): radial for circles, nearest point on the segments for polygons."""
        if self.tag == "BCIR":
            dx, dz = x - self.cx, z - self.cz
            d = math.sqrt(dx * dx + dz * dz)
            if d < 1e-4:
                return (self.cx + self.r, self.cz)
            return (self.cx + dx * self.r / d, self.cz + dz * self.r / d)
        if self.tag == "BPOL" and len(self.pts) >= 2:
            best, bd = None, 0.0
            n = len(self.pts)
            for i in range(n):
                ax, az = self.pts[i]
                bx, bz = self.pts[(i + 1) % n]
                ex, ez = bx - ax, bz - az
                ll = ex * ex + ez * ez
                t = _clamp(((x - ax) * ex + (z - az) * ez) / ll, 0.0, 1.0) if ll > 0 else 0.0
                px, pz = ax + ex * t, az + ez * t
                dd = (px - x) ** 2 + (pz - z) ** 2
                if best is None or dd < bd:
                    best, bd = (px, pz), dd
            return best
        return None

    def _polygon(self, x: float, z: float) -> float:
        pts = self.pts
        n = len(pts)
        inside = False
        j = n - 1
        for i in range(n):
            xi, zi = pts[i]
            xj, zj = pts[j]
            if ((zi <= z < zj) or (zj <= z < zi)) and x < (xj - xi) * (z - zi) / (zj - zi) + xi:
                inside = not inside
            j = i
        if not inside:
            return 0.0
        if self.fd == 0.0:
            return 1.0
        fd2 = self.fd * self.fd
        d2 = fd2
        for px, pz in pts:
            d2 = min(d2, (x - px) ** 2 + (z - pz) ** 2)
        j = n - 1
        for i in range(n):
            x1, z1 = pts[j]
            x2, z2 = pts[i]
            den = (x1 - x2) ** 2 + (z1 - z2) ** 2
            if den:
                u = ((x - x1) * (x2 - x1) + (z - z1) * (z2 - z1)) / den
                if 0 <= u <= 1:
                    d2 = min(d2, (x - (x1 + u * (x2 - x1))) ** 2 + (z - (z1 + u * (z2 - z1))) ** 2)
            j = i
        if abs(fd2 - d2) > 0.0001:
            return math.sqrt(d2) / self.fd
        return 1.0

    def _polyline(self, x: float, z: float) -> float:
        w2 = self.width * self.width
        d2 = _polyline_distance2(self.pts, x, z, w2)
        if d2 < w2:
            nf = self.width * (1.0 - self.fd)
            if d2 < nf * nf:
                return 1.0
            return 1.0 - (math.sqrt(d2) - nf) / (self.width - nf)
        return 0.0


def _polyline_distance2(pts, x, z, start):
    d2 = start
    for px, pz in pts:
        d2 = min(d2, (x - px) ** 2 + (z - pz) ** 2)
    for i in range(len(pts) - 1):
        x1, z1 = pts[i]
        x2, z2 = pts[i + 1]
        den = (x2 - x1) ** 2 + (z2 - z1) ** 2
        if den:
            u = ((x - x1) * (x2 - x1) + (z - z1) * (z2 - z1)) / den
            if 0 <= u <= 1:
                d2 = min(d2, (x - (x1 + u * (x2 - x1))) ** 2 + (z - (z1 + u * (z2 - z1))) ** 2)
    return d2


# ----------------------------------------------------------------------------------------------------------------
# roads and rivers (AffectorBoundaryPoly::find + HeightData)

class _Poly:
    def __init__(self, item: dict):
        p = item["params"]
        self.pts = [tuple(q[:2]) for q in p["points"]]
        self.width = float(p["width"])
        self.hd = item.get("height_data") or []
        lengths = [0.0]
        for i in range(1, len(self.pts)):
            lengths.append(math.dist(self.pts[i - 1], self.pts[i]))
        self.lengths = lengths
        self.totals = []
        acc = 0.0
        for v in lengths:
            acc += v
            self.totals.append(acc)
        xs = [q[0] for q in self.pts] or [0.0]
        zs = [q[1] for q in self.pts] or [0.0]
        w = self.width
        self.bbox = (min(xs) - w, min(zs) - w, max(xs) + w, max(zs) + w)

    def _hd_point(self, seg: int, idx: int) -> float:
        try:
            return self.hd[seg][idx][1]
        except IndexError:
            return 0.0

    def find(self, x: float, z: float, half_width: float, ignore_height: bool = False):
        """Returns (distance_to_center, height, t) or None."""
        pts = self.pts
        if not pts:
            return None
        w2 = half_width * half_width
        d2 = w2
        height = 0.0
        t_along = 0.0
        n = len(pts)
        for i, (px, pz) in enumerate(pts):
            dd = (x - px) ** 2 + (z - pz) ** 2
            if dd < d2:
                d2 = dd
                t_along = self.totals[i]
                if not ignore_height:
                    height = self._hd_point(i, 0) if i != n - 1 else self._hd_point(i - 1, -1)
        seg, res, search = 0, None, False
        for i in range(n - 1):
            x1, z1 = pts[i]
            x2, z2 = pts[i + 1]
            den = (x2 - x1) ** 2 + (z2 - z1) ** 2
            if not den:
                continue
            t = ((x - x1) * (x2 - x1) + (z - z1) * (z2 - z1)) / den
            if 0 <= t <= 1:
                lx, lz = x1 + t * (x2 - x1), z1 + t * (z2 - z1)
                dd = (x - lx) ** 2 + (z - lz) ** 2
                if dd < d2:
                    d2, seg, res = dd, i, (lx, lz)
                    search = not ignore_height
                    t_along = self.totals[i] + t * self.lengths[i + 1]
        if d2 >= w2:
            return None
        if search:
            height = _segment_height(self.hd[seg], res) if seg < len(self.hd) and len(self.hd[seg]) >= 2 else 0.0
        return math.sqrt(d2), height, t_along


def _segment_height(seg: list, pos: tuple[float, float]) -> float:
    """HeightData::Segment::find: interpolate along the segment's dominant axis."""
    a, b = seg[0], seg[-1]
    px = _clamp(pos[0], min(a[0], b[0]), max(a[0], b[0]))
    pz = _clamp(pos[1], min(a[2], b[2]), max(a[2], b[2]))
    w, h = b[0] - a[0], b[2] - a[2]
    axis, v = (0, px) if abs(w) >= abs(h) else (2, pz)
    pts = seg if (w if axis == 0 else h) >= 0 else list(reversed(seg))
    prev = pts[0]
    for cur in pts:
        if cur[axis] >= v:
            span = cur[axis] - prev[axis]
            t = (v - prev[axis]) / span if span else 0.0
            return prev[1] + t * (cur[1] - prev[1])
        prev = cur
    return pts[-1][1]


def _ramped_height(poly: _Poly, heights: list[float], ff: int, fd: float, x: float, z: float, terrain: float):
    """AffectorRoad::getRampedHeight (roads with fixed control-point heights)."""
    pts = poly.pts
    w2 = (poly.width / 2.0) ** 2
    d2, found = w2, -1
    for i, (px, pz) in enumerate(pts):
        dd = (x - px) ** 2 + (z - pz) ** 2
        if dd < d2:
            d2, found = dd, i
    for i in range(len(pts) - 1):
        x1, z1 = pts[i]
        x2, z2 = pts[i + 1]
        den = (x2 - x1) ** 2 + (z2 - z1) ** 2
        if not den:
            continue
        u = ((x - x1) * (x2 - x1) + (z - z1) * (z2 - z1)) / den
        if 0 <= u <= 1:
            dd = (x - (x1 + u * (x2 - x1))) ** 2 + (z - (z1 + u * (z2 - z1))) ** 2
            if dd < d2:
                d2, found = dd, i
    if d2 >= w2 or found < 0:
        return None
    mult = 1.0
    nf = (poly.width / 2.0) * (1.0 - fd)
    if d2 >= nf * nf and poly.width / 2.0 - nf > 0:
        mult = _feather(ff, 1.0 - (math.sqrt(d2) - nf) / (poly.width / 2.0 - nf))
    start = heights[found] if found < len(heights) else 0.0
    height = start
    if found != len(pts) - 1 and found + 1 < len(heights):
        p1, p2 = pts[found], pts[found + 1]
        total = math.dist(p1, p2)
        proj = ((x - p1[0]) * (p2[0] - p1[0]) + (z - p1[1]) * (p2[1] - p1[1])) / total if total else 0.0
        if total and 0 <= proj <= total:
            height = start + proj / total * (heights[found + 1] - start)
    return terrain + (height - terrain) * mult


# ----------------------------------------------------------------------------------------------------------------
# evaluation

class Grid:
    def __init__(self, x0: float, z0: float, spacing: float, nx: int, nz: int):
        self.x0, self.z0, self.d, self.nx, self.nz = x0, z0, spacing, nx, nz
        n = nx * nz
        self.height = [0.0] * n
        self.shader = [-1] * n
        self.exclude = [False] * n
        self._normals = None
        self.fine_layers: list = []
        self.tile_excluded: set[tuple[int, int]] = set()     # (pole i, pole j) of excluded tiles' origin poles
        self.moved: dict[int, tuple[float, float]] = {}      # pole index -> x/z moved onto an exact edge

    def xs(self, i):
        return self.x0 + (i % self.nx) * self.d

    def zs(self, i):
        return self.z0 + (i // self.nx) * self.d

    def normals(self):
        """Vertex normals from the current heights (central differences; the engine averages plane normals)."""
        if self._normals is None:
            nx, nz, d, h = self.nx, self.nz, self.d, self.height
            out = []
            for k in range(nx * nz):
                i, j = k % nx, k // nx
                il, ir = max(i - 1, 0), min(i + 1, nx - 1)
                jl, jr = max(j - 1, 0), min(j + 1, nz - 1)
                dx = (h[j * nx + ir] - h[j * nx + il]) / (max(ir - il, 1) * d)
                dz = (h[jr * nx + i] - h[jl * nx + i]) / (max(jr - jl, 1) * d)
                m = math.sqrt(dx * dx + 1.0 + dz * dz)
                out.append((-dx / m, 1.0 / m, -dz / m))
            self._normals = out
        return self._normals

    def dirty(self):
        self._normals = None


class Evaluator:
    def __init__(self, doc: TerrainDoc, roads_and_rivers: bool = True, data_roots: list[str] | None = None):
        self.doc = doc
        self.roads_and_rivers = roads_and_rivers
        self.data_roots = [Path(r) for r in (data_roots or [])]
        self._fractals: dict[int, MultiFractal] = {}
        self._images: dict[int, Any] = {}
        self._cache: dict[int, Any] = {}

    # ---- family lookups

    def fractal(self, fid: int) -> MultiFractal | None:
        if fid not in self._fractals:
            fam = self.doc.family("fractal", fid)
            self._fractals[fid] = MultiFractal.from_family(fam) if fam else None
        return self._fractals[fid]

    def shader_clamp(self, fid: int) -> float:
        fam = self.doc.family("shader", fid)
        return float(fam.get("feather_clamp", 1.0)) if fam else 1.0

    def bitmap(self, fid: int):
        if fid not in self._images:
            fam = self.doc.family("bitmap", fid)
            self._images[fid] = _load_gray_tga(fam.get("bitmap", ""), self.data_roots) if fam else None
        return self._images[fid]

    def _prepared(self, item: dict):
        key = id(item)
        if key not in self._cache:
            tag = item["tag"]
            if tag in ("BCIR", "BREC", "BPOL", "BPLN"):
                self._cache[key] = _Boundary(item)
            elif tag in ("AROA", "ARIV", "ARIB"):
                self._cache[key] = _Poly(item)
            else:
                self._cache[key] = None
        return self._cache[key]

    # ---- the layer walk

    def run(self, grid: Grid) -> Grid:
        ones = [1.0] * (grid.nx * grid.nz)
        grid.fine_layers = []
        for layer in self.doc.layers:
            if layer.get("kind") == "layer" and layer.get("active") and "raw" not in layer:
                self._layer(layer, ones, grid)
        _apply_fine_exclusion(grid)
        return grid

    def _layer(self, layer: dict, prev: list[float], g: Grid) -> None:
        items = [i for i in layer.get("items", []) if i.get("active") and "raw" not in i]
        bounds = [self._prepared(i) for i in items if i["kind"] == "boundary"]
        filters = [i for i in items if i["kind"] == "filter"]
        affectors = [i for i in items if i["kind"] == "affector"]
        subs = [i for i in items if i["kind"] == "layer"]
        if not affectors and not subs:
            return
        # Layer::hasFineExclusion: the generator cuts along this layer's boundaries after every layer ran
        if bounds and not layer.get("invert_boundaries") and any(
                a["tag"] == "AEXC" and a.get("params", {}).get("fine") for a in affectors):
            g.fine_layers.append(bounds)
        only_subs = not bounds and not filters and not affectors
        if only_subs:
            for s in subs:
                self._layer(s, prev, g)
            return
        inv_b, inv_f = bool(layer.get("invert_boundaries")), bool(layer.get("invert_filters"))
        if bounds and not inv_b:
            gx0, gz0 = g.x0, g.z0
            gx1, gz1 = g.x0 + (g.nx - 1) * g.d, g.z0 + (g.nz - 1) * g.d
            if all(b.bbox[2] < gx0 or b.bbox[0] > gx1 or b.bbox[3] < gz0 or b.bbox[1] > gz1 for b in bounds):
                return
        n = g.nx * g.nz
        amount = [0.0] * n if subs else None
        affect_subs = False
        for k in range(n):
            pa = prev[k]
            if pa <= 0.0 and not subs:
                continue
            x, z = g.xs(k), g.zs(k)
            if bounds:
                fz = 0.0
                for b in bounds:
                    v = b.within(x, z)
                    if v > 0.0:
                        v = _feather(b.ff, v)
                        if v > fz:
                            fz = v
                            if fz >= 1.0:
                                break
            else:
                fz = 1.0
            if inv_b:
                fz = 1.0 - fz
            if fz > 0.0:
                for f in filters:
                    v = self._filter(f, x, z, k, g, layer)
                    fz = min(fz, _feather(int(f["params"].get("feather_function", 0)), v))
                    if fz == 0.0:
                        break
                if inv_f:
                    fz = 1.0 - fz
                if fz > 0.0:
                    affect_subs = True
                    a = fz * pa
                    for af in affectors:
                        self._affect(af, x, z, k, a, g)
            if amount is not None:
                amount[k] = fz * pa
        if affect_subs:
            for s in subs:
                self._layer(s, amount, g)

    def _filter(self, f: dict, x: float, z: float, k: int, g: Grid, layer: dict) -> float:
        p, tag = f["params"], f["tag"]
        fd = _clamp(float(p.get("feather_distance", 0.0)), 0.0, 1.0)
        if tag == "FHGT":
            return _interp(p["low_height"], g.height[k], p["high_height"], fd)
        if tag == "FFRA":
            mf = self.fractal(p["family_id"])
            if mf is None:
                return 0.0
            return _interp(p["low"], p["scale_y"] * mf.value2(x, z), p["high"], fd)
        if tag == "FSLP":
            lo = _clamp(math.radians(p["min_angle"]), 0.0, math.pi / 2)
            hi = _clamp(math.radians(p["max_angle"]), 0.0, math.pi / 2)
            ny = g.normals()[k][1]
            return _interp(math.sin(math.pi / 2 - hi), ny, math.sin(math.pi / 2 - lo), fd)
        if tag == "FDIR":
            nx_, _, nz_ = g.normals()[k]
            theta = math.atan2(nx_, nz_) / (2 * math.pi) + 0.5
            lo = max(-math.pi, math.radians(p["min_angle"])) / (2 * math.pi)
            hi = min(math.pi, math.radians(p["max_angle"])) / (2 * math.pi)
            if not (lo <= theta <= hi):
                return 0.0
            fa = (hi - lo) * fd * 0.5
            if lo + fa <= theta <= hi - fa or fa == 0:
                return 1.0
            return min(fa, hi - theta, theta - lo) / fa
        if tag == "FSHD":
            return 1.0 if g.shader[k] == p["family_id"] else 0.0
        if tag == "FBIT":
            img = self.bitmap(p["family_id"])
            if img is None:
                return 1.0
            return _bitmap_filter(img, p, fd, x, z, self._layer_extent(layer))
        return 1.0

    def _layer_extent(self, layer: dict):
        key = ("extent", id(layer))
        if key not in self._cache:
            bs = [self._prepared(i) for i in layer.get("items", []) if i.get("kind") == "boundary"]
            if bs:
                self._cache[key] = (min(b.bbox[0] for b in bs), min(b.bbox[1] for b in bs),
                                    max(b.bbox[2] for b in bs), max(b.bbox[3] for b in bs))
            else:
                w = float(self.doc.header.get("map_width", 16384.0)) / 2
                self._cache[key] = (-w, -w, w, w)
        return self._cache[key]

    def _affect(self, a: dict, x: float, z: float, k: int, amount: float, g: Grid) -> None:
        if amount <= 0.0:
            return
        p, tag = a["params"], a["tag"]
        h = g.height
        if tag == "AHCN":
            op, v = p["operation"], p["height"]
            if op == 1:
                h[k] += amount * v
            elif op == 2:
                h[k] -= amount * v
            elif op == 3:
                h[k] += (h[k] * v - h[k]) * amount
            else:
                h[k] = amount * v + (1.0 - amount) * h[k]
            g.dirty()
        elif tag == "AHFR":
            mf = self.fractal(p["family_id"])
            if mf is None:
                return
            fv = p["scale_y"] * mf.value2(x, z)
            op = p["operation"]
            if op == 1:
                h[k] += amount * fv
            elif op == 2:
                h[k] -= amount * fv
            elif op == 3:
                h[k] += (h[k] * fv - h[k]) * amount
            else:
                h[k] += (fv - h[k]) * amount
            g.dirty()
        elif tag == "AHTR":
            th = p["height"]
            if th > 0:
                o = h[k]
                low = o - ((th + math.fmod(o, th)) if o < 0 else math.fmod(o, th))
                mid, high = low + th * p["fraction"], low + th
                nh = low
                if o > mid:
                    nh = low + (high - low) * ((o - mid) / (high - mid))
                h[k] = o + (nh - o) * amount
                g.dirty()
        elif tag == "ASCN":
            clamp_ = p["feather_clamp_override"] if p["use_feather_clamp_override"] else self.shader_clamp(p["family_id"])
            if amount >= clamp_:
                g.shader[k] = p["family_id"]
        elif tag == "ASRP":
            if g.shader[k] == p["source_family_id"]:
                clamp_ = (p["feather_clamp_override"] if p["use_feather_clamp_override"]
                          else self.shader_clamp(p["destination_family_id"]))
                if amount >= clamp_:
                    g.shader[k] = p["destination_family_id"]
        elif tag == "AEXC":
            if not p.get("fine"):                       # fine cuts happen per tile after all layers
                g.exclude[k] = True
        elif tag in ("AROA", "ARIV") and self.roads_and_rivers:
            self._road_river(a, x, z, k, g)
        elif tag == "ARIB":
            poly = self._prepared(a)
            if not (poly.bbox[0] <= x <= poly.bbox[2] and poly.bbox[1] <= z <= poly.bbox[3]):
                return
            r = poly.find(x, z, poly.width / 2.0, ignore_height=True)
            if r and r[0] <= poly.width / 2.0 * (1.0 - p["feather_distance_terrain_shader"]):
                g.shader[k] = p["terrain_shader_family_id"]

    def _road_river(self, a: dict, x: float, z: float, k: int, g: Grid) -> None:
        poly = self._prepared(a)
        b = poly.bbox
        if not (b[0] <= x <= b[2] and b[1] <= z <= b[3]):
            return
        p = a["params"]
        half = poly.width * 0.5
        r = poly.find(x, z, half)
        if r is None:
            return
        dist, desired, t_along = r
        orig = g.height[k]
        fd = _clamp(float(p.get("feather_distance", 0.0)), 0.0, 1.0)
        if a["tag"] == "AROA":
            fixed = bool(p.get("has_fixed_heights"))
            if dist <= half * (1.0 - fd):
                if fixed:
                    v = _ramped_height(poly, p.get("heights", []), p["feather_function"], fd, x, z, orig)
                    g.height[k] = orig if v is None else v
                else:
                    g.height[k] = desired
            else:
                t = dist / half
                if fixed:
                    v = _ramped_height(poly, p.get("heights", []), p["feather_function"], fd, x, z, orig)
                    g.height[k] = orig if v is None else v
                else:
                    g.height[k] = desired + (orig - desired) * t
            if dist <= half * (1.0 - _clamp(p.get("feather_distance_shader", 0.0), 0.0, 1.0)):
                g.shader[k] = p["family_id"]
        else:
            mf = self._cache.get(("river_fractal",))
            if mf is None:
                mf = MultiFractal()
                mf.scale_x = mf.scale_y = 0.01
                mf.use_gain, mf.gain = True, 0.9
                mf.octaves = 3
                self._cache[("river_fractal",)] = mf
            desired -= p["trench_depth"]
            sub = half * mf.value1(t_along)
            feather = sub * (1.0 - fd)
            if dist <= feather:
                g.height[k] = desired
                g.shader[k] = p["bottom_family_id"]
            elif dist <= sub:
                t = dist / sub
                g.height[k] = desired + (orig - desired) * t * t
                g.shader[k] = p["bank_family_id"]
        g.dirty()


def evaluate(doc: TerrainDoc, x0: float, z0: float, spacing: float, nx: int, nz: int,
             roads_and_rivers: bool = True, data_roots: list[str] | None = None) -> Grid:
    return Evaluator(doc, roads_and_rivers, data_roots).run(Grid(x0, z0, spacing, nx, nz))


def pole_spacing(doc: TerrainDoc) -> float:
    """Distance between height poles: tile width / 2 (ProceduralTerrainAppearance)."""
    h = doc.header
    return float(h.get("chunk_width", 32.0)) / max(int(h.get("tiles_per_chunk", 8)), 1) / 2.0


def heights_at(doc: TerrainDoc, points: list, roads_and_rivers: bool = True,
               data_roots: list[str] | None = None) -> list[float | None]:
    """Terrain height at world x/z points as the client reports it (client_heights): None in holes."""
    return client_heights(doc, points, roads_and_rivers, data_roots)


def generator_heights(doc: TerrainDoc, points: list, roads_and_rivers: bool = True,
                      data_roots: list[str] | None = None) -> list[float]:
    """The generator's own height at each point (a pole of a 3 x 3 patch round it), ignoring holes."""
    ev = Evaluator(doc, roads_and_rivers, data_roots)
    d = pole_spacing(doc)
    return [ev.run(Grid(float(x) - d, float(z) - d, d, 3, 3)).height[4] for x, z in points]


def _apply_fine_exclusion(g: Grid) -> None:
    """TerrainGenerator::_applyFineExclusion on the grid. Poles inside (isWithin >= 0.5) a fine layer's boundaries
    are flagged 1 (the layer has exact edges) or 2 (it has not: the pole itself is excluded); a tile (two poles
    wide, on the world tile grid) with all nine poles flagged is dropped, and in a tile the edge crosses the
    flagged-1 poles move to the nearest edge point of the layers they are in."""
    if not g.fine_layers:
        return
    n = g.nx * g.nz
    flags = [0] * n
    exact = [all(b.has_exact_edge() for b in bs) for bs in g.fine_layers]
    for k in range(n):
        x, z = g.xs(k), g.zs(k)
        for li, bs in enumerate(g.fine_layers):
            if any(b.within(x, z) >= 0.5 for b in bs):
                flags[k] = max(flags[k], 1 if exact[li] else 2)
        if flags[k] == 2:
            g.exclude[k] = True
    if not any(flags):
        return
    i0 = int(round(g.x0 / g.d))
    j0 = int(round(g.z0 / g.d))
    snap = set()
    for j in range((-j0) % 2, g.nz - 2, 2):                  # tiles start on even world pole indices
        for i in range((-i0) % 2, g.nx - 2, 2):
            ks = [(j + dz) * g.nx + i + dx for dz in range(3) for dx in range(3)]
            count = sum(1 for k in ks if flags[k])
            if count == 9:
                g.tile_excluded.add((i0 + i, j0 + j))
            elif count:
                snap.update(k for k in ks if flags[k] == 1)
    for k in snap:
        x, z = g.xs(k), g.zs(k)
        best, bd = None, 0.0
        for li, bs in enumerate(g.fine_layers):
            if not exact[li]:
                continue
            for b in bs:
                if b.within(x, z) < 0.5:
                    continue
                e = b.nearest_edge(x, z)
                if e is None:
                    continue
                dd = (e[0] - x) ** 2 + (e[1] - z) ** 2
                if best is None or dd < bd:
                    best, bd = e, dd
        if best is not None:
            g.moved[k] = best


# vertex order of a tile (ClientChunk constructionIndirectionArray) and its 8-triangle fan (IBP_center)
_TILE_VERTS = [(1, 1), (0, 1), (0, 2), (1, 2), (2, 2), (2, 1), (2, 0), (1, 0), (0, 0)]
_TILE_FAN = [(0, i, i % 8 + 1) for i in range(1, 9)]


def _tile_height(g: Grid, ti: int, tj: int, x: float, z: float) -> float | None:
    """ShaderSet::getHeightAt for one full-detail tile whose origin is world pole (ti, tj): the first fan triangle
    whose x/z contains the point (edges inclusive), height on its plane."""
    i0 = int(round(g.x0 / g.d))
    j0 = int(round(g.z0 / g.d))
    li, lj = ti - i0, tj - j0
    if li < 0 or lj < 0 or li + 2 >= g.nx or lj + 2 >= g.nz:
        return None
    if (ti, tj) in g.tile_excluded or g.exclude[lj * g.nx + li]:
        return None
    vs = []
    for dx, dz in _TILE_VERTS:
        k = (lj + dz) * g.nx + li + dx
        mx, mz = g.moved.get(k, (g.xs(k), g.zs(k)))
        vs.append((mx, g.height[k], mz))
    for a, b, c in _TILE_FAN:
        p0, p1, p2 = vs[a], vs[b], vs[c]

        def side(q0, q1):
            nx_, nz_ = -(q1[2] - q0[2]), q1[0] - q0[0]
            return nx_ * x + nz_ * z - (nx_ * q0[0] + nz_ * q0[2])
        if side(p0, p1) <= 0 and side(p1, p2) <= 0 and side(p2, p0) <= 0:
            ux, uy, uz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
            vx, vy, vz = p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]
            nx_, ny_, nz_ = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
            if abs(ny_) < 1e-12:
                continue
            return p0[1] - (nx_ * (x - p0[0]) + nz_ * (z - p0[2])) / ny_
    return None


def client_heights(doc: TerrainDoc, points: list, roads_and_rivers: bool = True,
                   data_roots: list[str] | None = None, cell: float = 128.0) -> list[float | None]:
    """Heights as the client's TerrainObject::getHeight returns them at full detail: the point's tile fan (then
    its neighbours', which a moved edge vertex can stretch over the point), None in holes. Points are evaluated in
    pole-aligned patches of about `cell` metres."""
    d = pole_spacing(doc)
    tw = 2.0 * d
    ev = Evaluator(doc, roads_and_rivers, data_roots)
    groups: dict[tuple[int, int], list[int]] = {}
    for idx, (x, z) in enumerate(points):
        groups.setdefault((int(math.floor(x / cell)), int(math.floor(z / cell))), []).append(idx)
    out: list[float | None] = [None] * len(points)
    for idxs in groups.values():
        txs = [math.floor(points[i][0] / tw) for i in idxs]
        tzs = [math.floor(points[i][1] / tw) for i in idxs]
        tx0, tz0 = min(txs) - 2, min(tzs) - 2
        nx = (max(txs) + 3 - tx0) * 2 + 1
        nz = (max(tzs) + 3 - tz0) * 2 + 1
        g = ev.run(Grid(tx0 * tw, tz0 * tw, d, nx, nz))
        for i, tx, tz in zip(idxs, txs, tzs):
            x, z = points[i]
            for ddz in (0, -1, 1):
                for ddx in (0, -1, 1):
                    h = _tile_height(g, 2 * (tx + ddx), 2 * (tz + ddz), x, z)
                    if h is not None:
                        out[i] = h
                        break
                if out[i] is not None:
                    break
    return out


def place_layer(world: TerrainDoc, layer_doc: TerrainDoc, x: float, z: float, yaw_degrees: float = 0.0,
                height: float | None = None) -> TerrainDoc:
    """A copy of `world` with a building's terrain layer added the way the client places it
    (ClientObjectTerrainModificationNotification::updateTerrain): TerrainModificationHelper::setPosition and
    setRotation on every active boundary of the layer and its active sublayers - rectangles take the building
    transform; circles named "local..." and polygons / polylines named "local..." keep their offset and turn with
    the building (titan); other circles move their centre onto the building; other polygons stay in world space -
    and setHeight on the active TGO_replace height constants (titan leaves add / subtract as offsets). `height`
    defaults to the world terrain's generated height at the origin (generateHeight_expensive without the layer).
    The layer goes after the world's own layers, as ProceduralTerrainAppearance::addLayer appends it."""
    yaw = math.radians(yaw_degrees)
    if height is None:
        g = Evaluator(world).run(Grid(x, z, pole_spacing(world), 1, 1))
        height = g.height[0]
    c, s_ = math.cos(yaw), math.sin(yaw)

    def to_world(px, pz):
        return (x + c * px + s_ * pz, z - s_ * px + c * pz)

    def place(layer: dict) -> None:
        for it in layer.get("items", []):
            if "raw" in it or not it.get("active"):
                continue
            tag = it.get("tag")
            p = it.get("params", {})
            local = str(it.get("name", "")).startswith("local")
            if tag == "BREC":
                it["_transform"] = (x, z, yaw)
            elif tag == "BCIR":
                if local:
                    p["center_x"], p["center_z"] = to_world(p["center_x"], p["center_z"])
                else:
                    p["center_x"], p["center_z"] = x, z
            elif tag in ("BPOL", "BPLN") and local:
                p["points"] = [list(to_world(q[0], q[1])) + list(q[2:]) for q in p["points"]]
            elif tag == "AHCN" and p.get("operation", 0) == 0:
                p["height"] = float(height)
            elif it.get("kind") == "layer":
                place(it)

    placed = []
    for layer in layer_doc.layers:
        lc = copy.deepcopy(layer)
        if lc.get("kind") == "layer" and "raw" not in lc:
            place(lc)
        placed.append(lc)
    model = dict(world.model)
    model["layers"] = list(world.layers) + placed
    return TerrainDoc(world.kind, model)


# ----------------------------------------------------------------------------------------------------------------
# bakes

def bake_height_data(doc: TerrainDoc, step: float = 8.0, data_roots: list[str] | None = None) -> list[dict]:
    """Fill every road / river affector's height data the way the TerrainEditor's Bake Rivers/Roads does: terrain
    height (roads and rivers off) sampled every ~8 m along each segment, then averaged (roads) or terraced downhill
    (rivers). Ribbons carry their own heights and are skipped."""
    report = []
    ev = Evaluator(doc, roads_and_rivers=False, data_roots=data_roots)
    d = pole_spacing(doc)

    def h(x, z):
        return ev.run(Grid(x - d, z - d, d, 3, 3)).height[4]

    for path, it, _ in doc.walk():
        if it.get("tag") not in ("AROA", "ARIV") or "raw" in it:
            continue
        pts = it["params"]["points"]
        segs = []
        for j in range(len(pts) - 1):
            (sx, sz), (ex, ez) = pts[j], pts[j + 1]
            length = math.dist((sx, sz), (ex, ez))
            nseg = 1 + int(length / step)
            stepl = length / nseg
            ux, uz = ((ex - sx) / length, (ez - sz) / length) if length else (0.0, 0.0)
            seg = []
            cx, cz = sx, sz
            for _ in range(nseg - 1):
                seg.append([cx, h(cx, cz), cz])
                cx += ux * stepl
                cz += uz * stepl
            seg.append([ex, h(ex, ez), ez])
            if len(seg) < 2:
                seg.insert(0, [sx, h(sx, sz), sz])
            segs.append(seg)
        if it["tag"] == "AROA":
            _road_data(segs)
        else:
            _river_data(segs)
        # store as float32, the file's precision
        it["height_data"] = [[[_f32(v) for v in p] for p in s] for s in segs]
        report.append({"path": path, "name": it.get("name"), "type": it["type"], "segments": len(segs),
                       "points": sum(len(s) for s in segs)})
    return report


def _f32(x: float) -> float:
    return struct.unpack("<f", struct.pack("<f", x))[0]


def _road_data(segs: list) -> None:
    for i in range(1, len(segs)):
        segs[i][0] = list(segs[i - 1][-1])
    for s in segs:
        if len(s) > 3:
            new = [s[0]]
            for i in range(1, len(s) - 1):
                new.append([s[i][0], (s[i - 1][1] + s[i][1] + s[i + 1][1]) / 3.0, s[i][2]])
            new.append(s[-1])
            s[:] = new


def _river_data(segs: list) -> None:
    eps = math.sin(math.radians(5.0)) * 4.0
    minimum = 3.4e38
    for i, s in enumerate(segs):
        for j, pt in enumerate(s):
            if j == 0:
                if i == 0:
                    minimum = pt[1]
                else:
                    pt[1] = minimum
            elif pt[1] >= minimum + eps:
                minimum += eps
                pt[1] = minimum
            elif pt[1] < minimum:
                minimum = pt[1]
            else:
                pt[1] = minimum


def _below_water(doc: TerrainDoc, waters: list, x: float, y: float, z: float) -> bool:
    hd = doc.header
    if hd.get("use_global_water_table") and y < hd.get("global_water_table_height", 0.0):
        return True
    for b, height in waters:
        if y < height and b.within(x, z) > 0:
            return True
    return False


def bake_terrain(doc: TerrainDoc, data_roots: list[str] | None = None) -> dict[str, Any]:
    """BakedTerrain water / steep-slope maps like the editor's Bake Terrain (roads and rivers off). Note the editor's
    own quirk, kept here: it samples 8 m cells (3 x 3 poles 4 m apart) while indexing them as map chunks, so only the
    middle (map / chunk * 8) metres of the map are sampled."""
    hd = doc.header
    mapw, chunkw = float(hd["map_width"]), float(hd["chunk_width"])
    n = int(mapw / chunkw)
    half = n // 2
    width, height = n // 8, n
    water = bytearray(width * height)
    slope = bytearray(width * height)
    ev = Evaluator(doc, roads_and_rivers=False, data_roots=data_roots)
    g = ev.run(Grid(-half * 8.0, -half * 8.0, 4.0, 2 * n + 1, 2 * n + 1))
    waters = []
    for _, it, _ in doc.walk():
        if it.get("tag") in ("BREC", "BPOL") and it.get("active") and "raw" not in it:
            p = it["params"]
            if p.get("local_water_table"):
                waters.append((_Boundary(it), p.get("water_height", 0.0)))
    nwater = nslope = 0
    for cz in range(-half, half):
        for cx in range(-half, half):
            ys = []
            wet = False
            for j in range(3):
                for i in range(3):
                    gi = (cx + half) * 2 + i
                    gj = (cz + half) * 2 + j
                    y = g.height[gj * g.nx + gi]
                    ys.append(y)
                    if not wet and _below_water(doc, waters, cx * 8.0 + i * 4.0, y, cz * 8.0 + j * 4.0):
                        wet = True
            x, yrow = cx + int(mapw / chunkw * 0.5), cz + int(mapw / chunkw * 0.5)
            bit = 1 << (x % 8)
            if wet:
                water[yrow * width + (x >> 3)] |= bit
                nwater += 1
            if max(ys) - min(ys) > 4.0:
                slope[yrow * width + (x >> 3)] |= bit
                nslope += 1
    doc.model["baked"] = {"version": "0001", "map_width": mapw, "chunk_width": chunkw, "width": width,
                          "height": height, "water": bytes(water), "slope": bytes(slope)}
    return {"chunks": n * n, "water_chunks": nwater, "steep_chunks": nslope}


# ----------------------------------------------------------------------------------------------------------------
# images

def _load_gray_tga(name: str, roots: list[Path]):
    """An 8-bit greyscale (or the first channel of a 24/32-bit) uncompressed TGA as (w, h, rows bottom-up)."""
    if not name:
        return None
    cands = [Path(name)] + [r / name for r in roots] + [r / "terrain" / Path(name).name for r in roots]
    for c in cands:
        if c.is_file():
            data = c.read_bytes()
            idlen, _, itype = data[0], data[1], data[2]
            w, h, bpp, desc = struct.unpack_from("<HHBB", data, 12)
            if itype not in (2, 3):
                return None
            px = bpp // 8
            pos = 18 + idlen
            vals = [data[pos + i * px] for i in range(w * h)]
            rows = [vals[r * w:(r + 1) * w] for r in range(h)]
            if desc & 0x20:
                rows.reverse()
            return (w, h, rows)
    return None


def _bitmap_filter(img, p: dict, fd: float, x: float, z: float, extent) -> float:
    w, h, rows = img
    ex0, ez0, ex1, ez1 = extent
    sx = min((x - ex0) * w / max(ex1 - ex0, 1e-6), w - 1.0)
    sy = min((z - ez0) * h / max(ez1 - ez0, 1e-6), h - 1.0)
    if sx < 0 or sy < 0:
        return 0.0
    x0, y0 = int(sx), int(sy)
    x1, y1 = min(x0 + 1, w - 1), min(y0 + 1, h - 1)
    dx, dy = sx - x0, sy - y0
    v = (rows[y0][x0] * (1 - dx) * (1 - dy) + rows[y0][x1] * dx * (1 - dy) + rows[y1][x0] * (1 - dx) * dy
         + rows[y1][x1] * dx * dy) / 255.0 + p.get("gain", 0.0)
    v = 0.0 if v < 0 else (0.99999 if v >= 1 else v)
    return _interp(p["low"], v, p["high"], fd) * v


def _png(w: int, h: int, rows: list[bytes]) -> bytes:
    raw = b"".join(b"\0" + r for r in rows)

    def ch(tag: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + ch(b"IDAT", zlib.compress(raw, 6)) + ch(b"IEND", b""))


def _family_rgb(doc: TerrainDoc, fid: int) -> tuple[int, int, int]:
    fam = doc.family("shader", fid)
    if fam:
        return tuple(fam.get("color", [128, 128, 128]))
    return (40, 40, 40)


def preview_png(doc: TerrainDoc, g: Grid, mode: str = "height", water: bool = True) -> tuple[bytes, dict]:
    """Hillshaded height map (north = +z at the top), shader-family colours (the families' editor colours), or
    both; excluded poles are magenta, water below the global table is blue."""
    hs = [v for v, ex in zip(g.height, g.exclude) if not ex] or [0.0]
    lo, hi = min(hs), max(hs)
    span = hi - lo or 1.0
    norms = g.normals()
    wl = doc.header.get("global_water_table_height", 0.0) if doc.header.get("use_global_water_table") else None
    rows = []
    for j in range(g.nz - 1, -1, -1):
        row = bytearray()
        for i in range(g.nx):
            k = j * g.nx + i
            if g.exclude[k]:
                row += bytes((255, 0, 255))
                continue
            nx_, ny_, nz_ = norms[k]
            shade = _clamp(0.35 + 0.65 * (-0.5 * nx_ + 0.7 * ny_ + 0.5 * nz_), 0.0, 1.0)
            t = (g.height[k] - lo) / span
            if mode == "shader":
                base = _family_rgb(doc, g.shader[k])
            elif mode == "height":
                base = (int(60 + 150 * t), int(90 + 130 * t), int(50 + 110 * t))
            else:  # both
                fam = _family_rgb(doc, g.shader[k])
                base = tuple(int(c * (0.5 + 0.5 * t)) for c in fam)
            c = [int(_clamp(v * shade, 0, 255)) for v in base]
            if water and wl is not None and g.height[k] < wl:
                c = [int(c[0] * 0.3), int(c[1] * 0.5), int(min(255, c[2] * 0.6 + 120))]
            row += bytes(c)
        rows.append(bytes(row))
    stats = {"min_height": lo, "max_height": hi, "size": [g.nx, g.nz], "spacing": g.d,
             "origin": [g.x0, g.z0], "excluded_poles": sum(g.exclude)}
    return _png(g.nx, g.nz, rows), stats
