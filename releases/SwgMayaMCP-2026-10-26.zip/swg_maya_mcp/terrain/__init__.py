"""Procedural terrain (.trn) and terrain layer (.lay) tools: a lossless reader/writer for the engine's IFF format
(trn), a pure-Python port of the generator's height path (generator, fractal) for previews and bakes, authoring
helpers (author) and the offline-client check (verify). The MCP tools live in tools.py."""
