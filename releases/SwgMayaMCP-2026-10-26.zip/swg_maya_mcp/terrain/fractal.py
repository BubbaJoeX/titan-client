"""Port of sharedFractal MultiFractal (Perlin noise octaves, combination rules, bias / gain) and the sharedRandom
RandomGenerator that seeds it (Numerical Recipes ran1). Values match the engine to float precision: the engine
computes in float32, this module in double, so heights agree to a few millimetres, not bit for bit."""

from __future__ import annotations

import math
import struct

_B, _BM, _N = 256, 255, 4096
_IM, _NTAB, _IA, _IQ, _IR = 2147483647, 322, 16807, 127773, 2836


def _f32(x: float) -> float:
    return struct.unpack("<f", struct.pack("<f", x))[0]


_NDIV = _f32(1.0 + _f32(float(_IM - 1)) / float(_NTAB))   # RandomGenerator::NDIV, a float


class RandomGenerator:
    """sharedRandom RandomGenerator (ran1 with a 322-entry shuffle table)."""

    def __init__(self, seed: int = 0):
        self.iv = [0] * _NTAB
        self.set_seed(seed)

    def set_seed(self, seed: int) -> None:
        self.iy = 0
        s = seed & 0xFFFFFFFF
        s = s - (1 << 32) if s >= (1 << 31) else s     # static_cast<int32>(newSeed)
        self.idnum = -s

    def random(self) -> int:
        if self.idnum <= 0 or not self.iy:
            self.idnum = 1 if -self.idnum < 1 else -self.idnum
            for j in range(_NTAB + 7, -1, -1):
                k = int(self.idnum / _IQ)
                self.idnum = _IA * (self.idnum - k * _IQ) - _IR * k
                if self.idnum < 0:
                    self.idnum += _IM
                if j < _NTAB:
                    self.iv[j] = self.idnum
            self.iy = self.iv[0]
        k = int(self.idnum / _IQ)
        self.idnum = _IA * (self.idnum - k * _IQ) - _IR * k
        if self.idnum < 0:
            self.idnum += _IM
        j = int(_f32(_f32(float(self.iy)) / _NDIV))
        self.iy = self.iv[j]
        self.iv[j] = self.idnum
        return self.iy


class NoiseGenerator:
    def __init__(self, seed: int = 0):
        self.init(seed)

    def init(self, seed: int) -> None:
        rnd = RandomGenerator(seed)
        p = [0] * (_B + _B + 2)
        g1 = [0.0] * (_B + _B + 2)
        g2 = [[0.0, 0.0] for _ in range(_B + _B + 2)]
        for i in range(_B):
            p[i] = i
            g1[i] = _f32(float((rnd.random() % (_B + _B)) - _B) / _B)
            for j in range(2):
                g2[i][j] = _f32(float((rnd.random() % (_B + _B)) - _B) / _B)
            s = math.sqrt(g2[i][0] ** 2 + g2[i][1] ** 2)
            if s:
                g2[i] = [_f32(g2[i][0] / s), _f32(g2[i][1] / s)]
        i = _B
        while True:
            i -= 1
            if i == 0:
                break
            k = p[i]
            j = rnd.random() % _B
            p[i] = p[j]
            p[j] = k
        for i in range(_B + 2):
            p[_B + i] = p[i]
            g1[_B + i] = g1[i]
            g2[_B + i] = list(g2[i])
        self.p, self.g1, self.g2 = p, g1, g2

    @staticmethod
    def _setup(v: float):
        t = v + _N
        it = int(t)
        ft = it - (1 if (t < 0 and t != it) else 0)
        b0 = ft & _BM
        b1 = (b0 + 1) & _BM
        r0 = t - ft
        return b0, b1, r0, r0 - 1.0

    def value1(self, x: float) -> float:
        bx0, bx1, rx0, rx1 = self._setup(x)
        sx = (3.0 - 2.0 * rx0) * rx0 * rx0
        u = rx0 * self.g1[self.p[bx0]]
        v = rx1 * self.g1[self.p[bx1]]
        return u + sx * (v - u)

    def value2(self, x: float, y: float) -> float:
        p, g2 = self.p, self.g2
        bx0, bx1, rx0, rx1 = self._setup(x)
        by0, by1, ry0, ry1 = self._setup(y)
        sx = (3.0 - 2.0 * rx0) * rx0 * rx0
        sy = (3.0 - 2.0 * ry0) * ry0 * ry0
        i, j = p[bx0], p[bx1]
        b00, b10, b01, b11 = p[i + by0], p[j + by0], p[i + by1], p[j + by1]
        q = g2[b00]
        u = rx0 * q[0] + ry0 * q[1]
        q = g2[b10]
        v = rx1 * q[0] + ry0 * q[1]
        a = u + sx * (v - u)
        q = g2[b01]
        u = rx0 * q[0] + ry1 * q[1]
        q = g2[b11]
        v = rx1 * q[0] + ry1 * q[1]
        b = u + sx * (v - u)
        return a + sy * (b - a)


def _bias(a: float, b: float) -> float:
    if a <= 0.0:
        return 0.0
    return a ** (math.log(b) / math.log(0.5))


def _gain(a: float, b: float) -> float:
    if a < 0.001:
        return 0.0
    if a > 0.999:
        return 1.0
    p = math.log(1.0 - b) / math.log(0.5)
    if a < 0.5:
        return (2.0 * a) ** p * 0.5
    return 1.0 - (2.0 * (1.0 - a)) ** p * 0.5


class MultiFractal:
    """MultiFractal with the engine's setter semantics (setNumberOfOctaves does NOT recompute the total amplitude;
    only setAmplitude does - AffectorRiver relies on that)."""

    def __init__(self):
        self.seed = 0
        self.scale_x = self.scale_y = 0.01
        self.offset_x = self.offset_y = 0.0
        self.octaves = 2
        self.frequency = 4.0
        self.amplitude = 0.5
        self.use_bias, self.bias = False, 0.5
        self.use_gain, self.gain = False, 0.7
        self.rule = 0
        self.noise = NoiseGenerator(0)
        self._init_total_amplitude()

    @classmethod
    def from_family(cls, fam: dict) -> "MultiFractal":
        """Build from a fractal family record (MultiFractalReaderWriter::load order)."""
        m = cls()
        m.set_seed(int(fam.get("seed", 0)))
        m.use_bias, m.bias = bool(fam.get("use_bias")), float(fam.get("bias", 0.5))
        m.use_gain, m.gain = bool(fam.get("use_gain")), float(fam.get("gain", 0.7))
        m.octaves = int(fam.get("octaves", 2))
        m.frequency = float(fam.get("frequency", 4.0))
        m.set_amplitude(float(fam.get("amplitude", 0.5)))
        m.scale_x, m.scale_y = float(fam.get("scale_x", 0.01)), float(fam.get("scale_y", 0.01))
        m.offset_x, m.offset_y = float(fam.get("offset_x", 0.0)), float(fam.get("offset_y", 0.0))
        m.rule = int(fam.get("combination_rule", 0))
        return m

    def set_seed(self, seed: int) -> None:
        if seed != self.seed:
            self.seed = seed
            self.noise.init(seed)

    def set_amplitude(self, amplitude: float) -> None:
        self.amplitude = amplitude
        self._init_total_amplitude()

    def _init_total_amplitude(self) -> None:
        total, amp = 0.0, 1.0
        for _ in range(self.octaves):
            total += amp
            amp *= self.amplitude
        self.oo_total = 1.0 / total if total else 1.0

    def _combine(self, sample, x: float) -> float:
        freq, amp, total = 1.0, 1.0, 0.0
        rule = self.rule
        for _ in range(self.octaves):
            n = sample(freq)
            if rule in (0, 1):
                total += amp * n
            elif rule == 2:
                total += amp * (1.0 - abs(n))
            elif rule == 3:
                total += amp * abs(n)
            elif rule == 4:
                total += amp * (1.0 - min(max(n, 0.0), 1.0))
            elif rule == 5:
                total += amp * min(max(n, 0.0), 1.0)
            freq *= self.frequency
            amp *= self.amplitude
        if rule in (0, 1):
            return (total * self.oo_total + 1.0) * 0.5
        return total * self.oo_total

    def _finish(self, r: float) -> float:
        if self.use_bias:
            r = _bias(r, self.bias)
        if self.use_gain:
            r = _gain(r, self.gain)
        return r

    def value2(self, x: float, y: float) -> float:
        """MultiFractal::getValueCache(x, y): scale, then offset inside each octave."""
        x *= self.scale_x
        y *= self.scale_y
        ox, oy, nz = self.offset_x, self.offset_y, self.noise.value2
        return self._finish(self._combine(lambda f: nz(x * f + ox * f, y * f + oy * f), x))

    def value1(self, x: float) -> float:
        """MultiFractal::getValue(x) (rivers use it along their length)."""
        x = x * self.scale_x + self.offset_x
        nz = self.noise.value1
        return self._finish(self._combine(lambda f: nz(x * f), x))
