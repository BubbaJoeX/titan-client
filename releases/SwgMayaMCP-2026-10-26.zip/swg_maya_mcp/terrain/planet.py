"""Register a new ground planet (scene) with the server, the client and the god client - the data side of what a
stock planet has, each step idempotent and with a one-time backup (<file>.pre-<planet>) of every file it changes:

  server   exe/linux/localOptions.cfg startPlanet=<name> (CentralServer starts it; GameServer checks it),
           universe/planets.mif + planets.iff (Planet("<name>")), misc/planet_crc_string_table .txt + .iff (scene
           name <-> id), datatables/region/planets.tab + .iff row and region_<name>.tab + .iff (named regions)
  client   terrain/<name>.trn (the PlanetServer and the client both load terrain/<scene>.trn), the environment
           files (env.py), datatables/loading/<name>.iff (loading-screen tips), string/en/planet_n.stf
           (display name), texture/ui_map_<name>.dds (planet map, also the god client's buildout editor map)
  god      SwgGodClient BuildoutEditorWindow's planet list (C++: needs a god client rebuild)

Paths follow the repository layout (D:/titan: data/, dsrc/, exe/linux/, client/src/)."""

from __future__ import annotations

import re
import shutil
import struct
from pathlib import Path
from typing import Any

from ..iff import Block, parse_iff, serialize_iff
from . import env, generator
from .trn import TerrainDoc, TrnError

GAME = "data/sku.0/sys.client/compiled/game"
SHARED = "data/sku.0/sys.shared/compiled/game"
SERVER = "data/sku.0/sys.server/compiled/game"
DSRC_SERVER = "dsrc/sku.0/sys.server/compiled/game"
DSRC_SHARED = "dsrc/sku.0/sys.shared/compiled/game"


def _backup(p: Path, name: str) -> None:
    b = p.with_name(p.name + f".pre-{name}")
    if p.exists() and not b.exists():
        shutil.copyfile(p, b)


def _write(p: Path, data: bytes, name: str, log: list) -> None:
    if p.exists() and p.read_bytes() == data:
        log.append(f"unchanged {p}")
        return
    _backup(p, name)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    log.append(f"wrote {p}")


# ---- compiled string tables (StringTable .stf: 0xABCD, version 1)

def read_stf(data: bytes) -> dict[str, Any]:
    """Text entries (id, crc, text) and name entries (id, name) keep their own file order."""
    magic, ver, next_id, n = struct.unpack_from("<IBII", data, 0)
    if magic != 0xABCD:
        raise TrnError("not a string table")
    pos = 13
    texts = []
    for _ in range(n):
        sid, crc, ln = struct.unpack_from("<III", data, pos)
        pos += 12
        texts.append([sid, crc, data[pos:pos + ln * 2].decode("utf-16-le")])
        pos += ln * 2
    names = []
    for _ in range(n):
        sid, ln = struct.unpack_from("<II", data, pos)
        pos += 8
        names.append([sid, data[pos:pos + ln].decode("latin1")])
        pos += ln
    return {"version": ver, "next_id": next_id, "texts": texts, "names": names}


def write_stf(t: dict) -> bytes:
    out = bytearray(struct.pack("<IBII", 0xABCD, t["version"], t["next_id"], len(t["texts"])))
    for sid, crc, text in t["texts"]:
        out += struct.pack("<III", sid, crc, len(text)) + text.encode("utf-16-le")
    for sid, name in t["names"]:
        out += struct.pack("<II", sid, len(name)) + name.encode("latin1")
    return bytes(out)


def stf_set(t: dict, name: str, text: str) -> None:
    sid = next((i for i, n in t["names"] if n == name), None)
    if sid is not None:
        for e in t["texts"]:
            if e[0] == sid:
                e[2] = text
        return
    sid = t["next_id"]
    t["next_id"] += 1
    t["texts"].append([sid, t["texts"][-1][1] if t["texts"] else 0xFFFFFFFF, text])   # the latest entries' crc
    t["names"].append([sid, name])


# ---- CRC string table (FORM CSTB)

def read_cstb(data: bytes) -> list[str]:
    ver = parse_iff(data).children[0].children[0]
    blocks = {c.tag: c.data for c in ver.children}
    n = struct.unpack_from("<i", blocks["DATA"], 0)[0]
    offs = struct.unpack_from(f"<{n}I", blocks["STRT"], 0)
    s = blocks["STNG"]
    return [s[o:s.index(b"\0", o)].decode("latin1") for o in offs]


def write_cstb(strings: list[str]) -> bytes:
    items = sorted({(env._crc(x), x) for x in strings})
    stng = bytearray()
    offs = []
    for _, x in items:
        offs.append(len(stng))
        stng += x.encode("latin1") + b"\0"
    ver = Block("0000", True, children=[Block("DATA", False, struct.pack("<i", len(items))),
                                        Block("CRCT", False, b"".join(struct.pack("<I", c) for c, _ in items)),
                                        Block("STRT", False, struct.pack(f"<{len(offs)}I", *offs)),
                                        Block("STNG", False, bytes(stng))])
    return serialize_iff(Block("CSTB", True, children=[ver]))


# ---- DDS (uncompressed A8R8G8B8, one mip)

def write_dds(w: int, h: int, rgb_rows: list[bytes]) -> bytes:
    hdr = struct.pack("<4sIIIIIII44x", b"DDS ", 124, 0x100F, h, w, w * 4, 0, 1)
    pf = struct.pack("<II4sIIIII", 32, 0x41, b"\0\0\0\0", 32, 0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000)
    caps = struct.pack("<IIII4x", 0x1000, 0, 0, 0)
    px = bytearray()
    for row in rgb_rows:
        for i in range(0, len(row), 3):
            px += bytes((row[i + 2], row[i + 1], row[i], 255))
    return hdr + pf + caps + bytes(px)


def ui_map(doc: TerrainDoc, size: int = 1024, data_roots: list[str] | None = None) -> bytes:
    """A planet map image like the stock ui_map_<planet>.dds: the whole map, north up, shaded terrain in the
    shader families' colours."""
    mw = float(doc.header["map_width"])
    d = mw / size
    g = generator.evaluate(doc, -mw / 2 + d / 2, -mw / 2 + d / 2, d, size, size, data_roots=data_roots)
    png_rows = []
    lo = min(g.height)
    hi = max(g.height) or 1.0
    norms = g.normals()
    for j in range(size - 1, -1, -1):
        row = bytearray()
        for i in range(size):
            k = j * size + i
            fam = doc.family("shader", g.shader[k])
            base = fam["color"] if fam else [128, 128, 128]
            nx, ny, nz = norms[k]
            shade = max(0.0, min(1.0, 0.45 + 0.55 * (-0.5 * nx + 0.7 * ny + 0.5 * nz)))
            t = 0.75 + 0.25 * (g.height[k] - lo) / (hi - lo or 1.0)
            row += bytes(int(max(0, min(255, c * shade * t))) for c in base)
        png_rows.append(bytes(row))
    return write_dds(size, size, png_rows)


# ---- the steps

def register(repo: str | Path, name: str, trn_path: str | Path, display_name: str,
             regions: list[dict] | None = None, environment: tuple[dict, dict] | None = None,
             env_template: str = "tatooine", loading_template: str = "general", map_image: bool = True,
             data_roots: list[str] | None = None) -> dict[str, Any]:
    """Every registration step; returns what changed. regions: [{name, x, z, radius} | {name, x0, z0, x1, z1},
    optional geographical (desert, canyon, mountains, ...), buildable 0/1]."""
    repo = Path(repo)
    log: list[str] = []
    notes: list[str] = []
    if not re.fullmatch(r"[a-z][a-z0-9_]*", name):
        raise TrnError("planet names are lower case scene ids (letters, digits, _)")
    doc = TerrainDoc.load(trn_path)
    if doc.kind != "trn":
        raise TrnError(f"{trn_path} is not a procedural terrain")
    game = repo / GAME

    # client + server terrain (both read terrain/<scene>.trn through the shared search paths)
    _write(game / "terrain" / f"{name}.trn", Path(trn_path).read_bytes(), name, log)

    # environment
    sky, table = environment or env.copy_from(env_template, [str(game)])
    s_path, t_path = env.paths(game, name)
    _write(s_path, env.write_envm(sky), name, log)
    _write(t_path, env.write_datatable(table), name, log)
    fams = [f["name"] for f in (doc.model["groups"].get("environment") or {"families": []})["families"]]
    missing = env.check_families(table, fams)
    if missing:
        notes.append(f"environment families without a table row (default block used): {missing}")

    # loading tips
    lt = game / "datatables" / "loading" / f"{loading_template}.iff"
    if lt.exists() and not (game / "datatables" / "loading" / f"{name}.iff").exists():
        _write(game / "datatables" / "loading" / f"{name}.iff", lt.read_bytes(), name, log)

    # display name
    for lang in ("en",):
        p = game / "string" / lang / "planet_n.stf"
        t = read_stf(p.read_bytes())
        stf_set(t, name, display_name)
        _write(p, write_stf(t), name, log)

    # planet map
    if map_image:
        _write(game / "texture" / f"ui_map_{name}.dds", ui_map(doc, data_roots=data_roots), name, log)

    # server: planets.mif / planets.iff
    mif = repo / DSRC_SERVER / "universe" / "planets.mif"
    text = mif.read_bytes().decode("latin1")
    if f'Planet("{name}")' not in text:
        anchor = text.rindex('Planet("')
        line_end = text.index("\n", anchor)
        indent = text[text.rindex("\n", 0, anchor) + 1:anchor]
        text = text[:line_end + 1] + f'{indent}Planet("{name}")' + ("\r" if text[line_end - 1] == "\r" else "") \
            + "\n" + text[line_end + 1:]
        _backup(mif, name)
        mif.write_text(text, encoding="latin1", newline="")
        log.append(f"wrote {mif}")
    piff = repo / SERVER / "universe" / "planets.iff"
    root = parse_iff(piff.read_bytes()).children[0]
    ver = root.children[0]
    if not any(c.data == name.encode() + b"\0" for c in ver.children):
        ver.children.append(Block("PLNT", False, name.encode() + b"\0"))
    _write(piff, serialize_iff(root), name, log)

    # planet CRC string table
    ctxt = repo / DSRC_SHARED / "misc" / "planet_crc_string_table.txt"
    ciff = repo / SHARED / "misc" / "planet_crc_string_table.iff"
    names = read_cstb(ciff.read_bytes())
    if name not in names:
        names.append(name)
    _write(ciff, write_cstb(names), name, log)
    if ctxt.exists():
        raw = ctxt.read_bytes().decode("latin1")
        have = [x.strip() for x in raw.splitlines() if x.strip()]
        merged = have + [x for x in sorted(names) if x not in have]       # keep the .txt in sync with the .iff
        if merged != have:
            eol = "\r\n" if "\r\n" in raw else "\n"
            _write(ctxt, (eol.join(merged) + eol).encode("latin1"), name, log)

    # regions
    if regions is not None:
        _regions(repo, name, doc, regions, log)

    # server config
    cfg = repo / "exe" / "linux" / "localOptions.cfg"
    text = cfg.read_bytes().decode("latin1")
    if not re.search(rf"^\s*startPlanet={re.escape(name)}\s*$", text, re.M):
        m = list(re.finditer(r"^startPlanet=(?!space_).*$", text, re.M))
        pos = m[-1].end() if m else text.index("[CentralServer]") + len("[CentralServer]")
        eol = "\r\n" if "\r\n" in text else "\n"
        text = text[:pos] + eol + f"startPlanet={name}" + text[pos:]
        _backup(cfg, name)
        cfg.write_text(text, encoding="latin1", newline="")
        log.append(f"wrote {cfg}")

    # god client
    bew = repo / "client/src/game/client/application/SwgGodClient/src/BuildoutEditorWindow.cpp"
    if bew.exists():
        src = bew.read_bytes().decode("latin1")
        if f'm_planetCombo->insertItem("{name}");' not in src:
            last = list(re.finditer(r'^(\s*)m_planetCombo->insertItem\("[^"]+"\);\r?$', src, re.M))[-1]
            eol = "\r\n" if src[last.end() - 1:last.end()] == "\r" or "\r\n" in src else "\n"
            line = f'{last.group(1)}m_planetCombo->insertItem("{name}");'
            src = src[:last.end()].rstrip("\r") + ("\r" if eol == "\r\n" else "") + "\n" + line + \
                ("\r" if eol == "\r\n" else "") + src[last.end():].lstrip("\r")
            _backup(bew, name)
            bew.write_text(src, encoding="latin1", newline="")
            log.append(f"wrote {bew} (god client buildout editor planet list: rebuild SwgGodClient)")
    notes.append("server: the WSL run directory takes its planet list from TITAN_PLANETS (default tatooine); start "
                 f"with TITAN_PLANETS=\"tatooine {name}\" (titan.sh config/start)")
    return {"changed": [x for x in log if x.startswith("wrote")], "unchanged": [x for x in log if
                                                                                x.startswith("unchanged")],
            "notes": notes + [x for x in log if x.startswith(("clipped", "skipped", "renamed"))]}


GEO_TYPES = ["desert", "forest", "jungle", "plateau", "oasis", "canyon", "lake", "lakeshore", "beach", "ocean",
             "underwater", "river", "volcano", "swamp", "plains", "prairie", "mountains", "hills"]


def _region_rows(planet: str, regions: list[dict], half: float, log: list,
                 taken: set[str] | None = None) -> list[dict]:
    """The default whole-planet rows plus `regions`, each fitted inside the planet rectangle: RegionMaster loads
    every planet's table on every game server and FATALs on a region outside its planet's bounds (planets.tab) or
    on a name already used anywhere (a region's crc is its name, across all planets). So the default rows carry the
    planet's name, a circle that would cross the edge becomes its bounding box clipped to the bounds, and a name
    another planet already uses (`taken`, lower case) gets the planet's name in front."""
    taken = set(taken or ())
    out = [{"name": f"{planet}_mission_default", "x0": -half, "z0": -half, "x1": half, "z1": half,
            "geographical": "wasteland", "min_difficulty": 1, "max_difficulty": 90, "spawnable": "mission",
            "visible": 0, "notify": 0},
           {"name": f"{planet}_world_spawner", "x0": -half, "z0": -half, "x1": half, "z1": half,
            "geographical": "default", "min_difficulty": 10, "max_difficulty": 30, "spawnable": "default",
            "visible": 0, "notify": 0}]
    for r in regions:
        r = dict(r)
        if r["name"].lower() in taken or any(r["name"].lower() == o["name"].lower() for o in out):
            new = f"{planet} {r['name']}"
            log.append(f"renamed region {r['name']!r} to {new!r}: the name is already used")
            r["name"] = new
        if "radius" in r:
            x, z, rad = r["x"], r["z"], r["radius"]
            if abs(x) + rad <= half and abs(z) + rad <= half:
                out.append(r)
                continue
            r.pop("radius")
            r.update(x0=x - rad, z0=z - rad, x1=x + rad, z1=z + rad)
        x0, z0 = max(-half, min(r["x0"], r["x1"])), max(-half, min(r["z0"], r["z1"]))
        x1, z1 = min(half, max(r["x0"], r["x1"])), min(half, max(r["z0"], r["z1"]))
        if x1 <= x0 or z1 <= z0:
            log.append(f"skipped region {r['name']!r}: outside the planet")
            continue
        if (x0, z0, x1, z1) != (r["x0"], r["z0"], r["x1"], r["z1"]):
            log.append(f"clipped region {r['name']!r} to the planet bounds")
        r.update(x0=x0, z0=z0, x1=x1, z1=z1)
        out.append(r)
    return out


def _regions(repo: Path, name: str, doc: TerrainDoc, regions: list[dict], log: list) -> None:
    rdir = repo / DSRC_SERVER / "datatables" / "region"
    template = (rdir / "region_lok.tab").read_bytes().decode("latin1").replace("\r\n", "\n").split("\n")
    head, types = template[0], template[1]
    cols = head.split("\t")
    ptab = rdir / "planets.tab"
    ptext = ptab.read_bytes().decode("latin1")
    m = re.search(rf"^{name}\t[^\t]*\t([-0-9.]+)\t([-0-9.]+)\t([-0-9.]+)\t([-0-9.]+)", ptext, re.M)
    half = min(abs(float(v)) for v in m.groups()) if m else float(doc.header["map_width"]) / 2 - 192.0
    taken = set()
    for other in rdir.glob("region_*.tab"):
        if other.stem != f"region_{name}":
            for ln in other.read_bytes().decode("latin1").splitlines()[2:]:
                if ln.strip():
                    taken.add(ln.split("\t", 1)[0].strip().strip('"').lower())
    for other in (repo / SERVER / "datatables" / "region").glob("region_*.iff"):
        if other.stem != f"region_{name}":
            try:
                taken.update(str(row[0]).lower() for row in env.read_datatable(other.read_bytes())["rows"])
            except (TrnError, ValueError, IndexError, struct.error):
                pass
    rows = []
    for r in _region_rows(name, regions, half, log, taken):
        cells = dict.fromkeys(cols, "")
        cells["regionName"] = r["name"]
        if "radius" in r:
            cells.update(geometry="circle", minX_or_centerX=r["x"], minZ_or_centerZ=r["z"], maxX_or_radius=r["radius"])
        else:
            cells.update(geometry="rectangle", minX_or_centerX=r["x0"], minZ_or_centerZ=r["z0"],
                         maxX_or_radius=r["x1"], maxZ=r["z1"])
        cells.update(pvpType="normal", geographicalType=r.get("geographical", "desert"),
                     minDifficultyType=r.get("min_difficulty", 1), maxDifficultyType=r.get("max_difficulty", 90),
                     spawnableType=r.get("spawnable", "mission"), missionType=r.get("mission", "other"),
                     buildable=int(r.get("buildable", 1)), municipal=0, visible=int(r.get("visible", 1)),
                     notify=int(r.get("notify", 1)))
        rows.append("\t".join(f"{v:g}" if isinstance(v, float) else str(v) for v in (cells[c] for c in cols)))
    tab = "\r\n".join([head, types] + rows) + "\r\n"
    rtab = rdir / f"region_{name}.tab"
    _write(rtab, tab.encode("latin1"), name, log)
    _write(repo / SERVER / "datatables" / "region" / f"region_{name}.iff",
           env.write_datatable(env.compile_tab(tab)), name, log)
    ptab = rdir / "planets.tab"
    text = ptab.read_bytes().decode("latin1")
    if not re.search(rf"^{name}\t", text, re.M):
        half = float(doc.header["map_width"]) / 2 - 192.0
        eol = "\r\n" if "\r\n" in text else "\n"
        text = text.rstrip("\r\n") + eol + f"{name}\tdatatables/region/region_{name}.iff\t{-half:g}\t{-half:g}\t" \
                                           f"{half:g}\t{half:g}" + eol
        _write(ptab, text.encode("latin1"), name, log)
    _write(repo / SERVER / "datatables" / "region" / "planets.iff",
           env.write_datatable(env.compile_tab(ptab.read_bytes().decode("latin1"))), name, log)
