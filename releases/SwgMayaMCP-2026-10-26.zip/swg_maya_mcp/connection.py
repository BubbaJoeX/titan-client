"""Connection to the in-Maya bridge (maya/swg_mcp/bridge.py).

Mode (SWG_MAYA_MCP_MODE):
  auto     — use an interactive Maya that is running the bridge (port 7020); otherwise start headless mayapy
  gui      — interactive Maya only
  headless — always use a private mayapy process (port 7021), started on first use
"""

from __future__ import annotations

import atexit
import itertools
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

MAYA_PKG_DIR = Path(__file__).resolve().parent.parent / "maya"
DEFAULT_GUI_PORT = int(os.environ.get("SWG_MAYA_MCP_PORT", "7020"))
DEFAULT_HEADLESS_PORT = int(os.environ.get("SWG_MAYA_MCP_HEADLESS_PORT", "7021"))
DEFAULT_MAYAPY = os.environ.get("SWG_MAYAPY", r"C:\Program Files\Autodesk\Maya2027\bin\mayapy.exe")
MAYA_ENV = Path(os.environ.get("SWG_MAYA_ENV", Path.home() / "Documents" / "maya" / "2027" / "Maya.env"))
HEADLESS_LOG = Path(tempfile.gettempdir()) / "swg_maya_mcp_headless.log"


class BridgeError(RuntimeError):
    pass


class _Socket:
    def __init__(self, port: int, timeout: float):
        self.sock = socket.create_connection(("127.0.0.1", port), timeout=timeout)
        self.buf = b""
        self.lock = threading.Lock()
        self.ids = itertools.count(1)

    def call(self, payload: dict, timeout: float) -> dict:
        with self.lock:
            payload = dict(payload, id=next(self.ids))
            self.sock.settimeout(timeout)
            self.sock.sendall(json.dumps(payload).encode("utf-8") + b"\n")
            while b"\n" not in self.buf:
                chunk = self.sock.recv(1 << 20)
                if not chunk:
                    raise ConnectionError("bridge closed the connection")
                self.buf += chunk
            line, self.buf = self.buf.split(b"\n", 1)
            return json.loads(line)

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass


def _maya_env() -> dict[str, str]:
    """KEY=VALUE pairs from Maya.env (mayapy does not read it); existing environment wins."""
    env: dict[str, str] = {}
    if not MAYA_ENV.exists():
        return env
    for raw in MAYA_ENV.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key.endswith("+"):
            continue  # PATH+= style appends; not needed headless
        env[key] = value.strip()
    return env


class MayaConnection:
    def __init__(self):
        self.mode = os.environ.get("SWG_MAYA_MCP_MODE", "auto").lower()
        self._sock: _Socket | None = None
        self._proc: subprocess.Popen | None = None
        self.kind: str | None = None  # "gui" | "headless"
        self.port: int | None = None
        self._lock = threading.Lock()
        atexit.register(self.shutdown)

    # -- lifecycle -------------------------------------------------------------------------------

    def _try_gui(self) -> bool:
        try:
            self._sock = _Socket(DEFAULT_GUI_PORT, timeout=1.5)
            self._sock.call({"lang": "ping"}, timeout=5)
        except OSError:
            self._sock = None
            return False
        self.kind, self.port = "gui", DEFAULT_GUI_PORT
        return True

    def _start_headless(self):
        # Reuse a headless bridge only if it actually runs Python: a Maya wedged inside a command still answers
        # pings on its socket thread. Ports held by wedged/foreign processes are skipped.
        port = None
        for candidate in range(DEFAULT_HEADLESS_PORT, DEFAULT_HEADLESS_PORT + 10):
            try:
                sock = _Socket(candidate, timeout=1.0)
            except OSError:
                port = candidate  # nothing listening: start ours here
                break
            try:
                info = sock.call({"lang": "ping"}, timeout=5).get("result") or {}
                if info.get("standalone") and sock.call({"lang": "python", "code": "result = 1"}, timeout=10).get("ok"):
                    self._sock, self.kind, self.port = sock, "headless", candidate
                    return
            except (OSError, ValueError):
                pass
            sock.close()
        if port is None:
            raise BridgeError(f"ports {DEFAULT_HEADLESS_PORT}-{DEFAULT_HEADLESS_PORT + 9} are all busy")
        mayapy = Path(DEFAULT_MAYAPY)
        if not mayapy.exists():
            raise BridgeError(f"mayapy not found at {mayapy} (set SWG_MAYAPY)")
        env = dict(os.environ)
        for k, v in _maya_env().items():
            env.setdefault(k, v)
        env["SWG_MAYA_MCP_PARENT_PID"] = str(os.getpid())
        env["PYTHONPATH"] = os.pathsep.join(filter(None, [str(MAYA_PKG_DIR), env.get("PYTHONPATH", "")]))
        log = open(HEADLESS_LOG, "w", encoding="utf-8", errors="replace")
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        self._proc = subprocess.Popen(
            [str(mayapy), str(MAYA_PKG_DIR / "swg_mcp" / "bridge.py"), "--standalone", "--port", str(port)],
            stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=env, creationflags=flags,
            cwd=tempfile.gettempdir(),
        )
        deadline = time.time() + float(os.environ.get("SWG_MAYA_MCP_STARTUP_TIMEOUT", "240"))
        while time.time() < deadline:
            if self._proc.poll() is not None:
                raise BridgeError(f"headless mayapy exited with {self._proc.returncode}; see {HEADLESS_LOG}")
            try:
                self._sock = _Socket(port, timeout=1.0)
                self._sock.call({"lang": "ping"}, timeout=5)
                self.kind, self.port = "headless", port
                return
            except OSError:
                time.sleep(1.0)
        raise BridgeError(f"headless mayapy did not start within the timeout; see {HEADLESS_LOG}")

    def ensure(self):
        with self._lock:
            if self._sock is not None:
                return
            if self.mode in ("auto", "gui") and self._try_gui():
                pass
            elif self.mode == "gui":
                raise BridgeError(
                    f"No interactive Maya bridge on 127.0.0.1:{DEFAULT_GUI_PORT}. In Maya's Script Editor (Python): "
                    "import swg_mcp.bridge; swg_mcp.bridge.start()")
            else:
                self._start_headless()
            # make the repo's swg_mcp package importable in GUI Maya too (no stale copies)
            self._raw("python", f"import sys\np = {str(MAYA_PKG_DIR)!r}\nif p not in sys.path: sys.path.insert(0, p)", 30)

    def reconnect(self, mode: str | None = None):
        with self._lock:
            if self._sock:
                self._sock.close()
            self._sock = None
            if mode:
                self.mode = mode
        self.ensure()

    def shutdown(self):
        if self._proc and self._proc.poll() is None:
            try:
                if self._sock:
                    self._sock.call({"lang": "shutdown"}, timeout=10)
            except Exception:
                pass
            try:
                self._proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self._proc.kill()
        if self._sock:
            self._sock.close()
            self._sock = None

    # -- requests --------------------------------------------------------------------------------

    def _raw(self, lang: str, code: str, timeout: float, args: dict | None = None) -> dict:
        try:
            return self._sock.call({"lang": lang, "code": code, "args": args or {}}, timeout=timeout)
        except (OSError, ConnectionError, ValueError) as exc:
            if self._sock:
                self._sock.close()
            self._sock = None
            note = "the next call reconnects"
            if self.kind == "headless" and self._proc and self._proc.poll() is None:
                self._proc.kill()  # our private Maya is stuck inside a command; start a fresh one next time
                self._proc = None
                note = "the headless Maya was stuck and has been killed; the next call starts a fresh one"
            raise BridgeError(f"lost connection to Maya ({type(exc).__name__}: {exc}); {note}") from exc

    def run(self, lang: str, code: str, args: dict | None = None, timeout: float = 600.0) -> dict:
        self.ensure()
        return self._raw(lang, code, timeout, args)

    def python(self, code: str, args: dict | None = None, timeout: float = 600.0):
        """Run Python in Maya; return `result` or raise BridgeError with Maya's traceback and output."""
        resp = self.run("python", code, args, timeout)
        if not resp.get("ok"):
            raise BridgeError(_format_failure(resp))
        return resp.get("result")


def _format_failure(resp: dict) -> str:
    parts = [resp.get("error") or "Maya request failed"]
    tb = (resp.get("traceback") or "").strip().splitlines()
    if tb:
        parts.append("\n".join(tb[-8:]))
    for key in ("stderr", "stdout"):
        text = (resp.get(key) or "").strip()
        if text:
            parts.append(f"{key}:\n{text[-3000:]}")
    return "\n".join(parts)
