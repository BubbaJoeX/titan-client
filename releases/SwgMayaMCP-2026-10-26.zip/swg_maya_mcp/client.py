"""Drive the offline SWG client through its developer bridge (clientGame DevBridge, development builds only).

The client listens on 127.0.0.1:<devBridgePort> when started with `-s ClientGame devBridgePort=<port>` and writes
%LOCALAPPDATA%/SwgTitan/devbridge.json ({port, token, pid}) at start-up; every request carries that token. One JSON
object per line each way: ping, state (player / camera position, cell, building), exec (a line run as if typed in
chat, with the console output it produced), screenshot (engine writes <path>.<tga|jpg|bmp>), log (console output
since a sequence number), menu (the offline test menu's actions: list, run one, open the in-game menu)."""

from __future__ import annotations

import json
import os
import socket
import struct
import subprocess
import time
import zlib
from pathlib import Path
from typing import Any

CLIENT_DIR = Path(os.environ.get("TITAN_CLIENT_DIR", "D:/titan/exe/win64_rel"))
CLIENT_EXE = os.environ.get("TITAN_CLIENT_EXE", "SwgTitan_d.exe")
DEFAULT_PORT = int(os.environ.get("TITAN_DEVBRIDGE_PORT", "7031"))
TOKEN_FILE = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "SwgTitan" / "devbridge.json"


class ClientBridgeError(RuntimeError):
    pass


def pinned_token_file(port: int) -> Path:
    """Per-port copy of the token: the client writes only devbridge.json, which the most recent launch overwrites,
    so launch() pins each client's token here and ClientBridge(port) reads it (several sessions, several clients)."""
    return TOKEN_FILE.with_name(f"devbridge_{port}.json")


def _token_info(port: int | None = None) -> dict[str, Any]:
    path = pinned_token_file(port) if port is not None and pinned_token_file(port).exists() else TOKEN_FILE
    if not path.exists():
        raise ClientBridgeError(f"{path} not found: is a development client running with devBridgePort set "
                                "(swg_client_launch)?")
    info = json.loads(path.read_text(encoding="utf-8"))
    if port is not None and int(info.get("port", 0)) != port:
        raise ClientBridgeError(f"no token pinned for port {port} (devbridge.json is for port {info.get('port')}); "
                                "launch the client with launch(port=...)")
    return info


def _pid_alive(pid: int) -> bool:
    out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True).stdout
    return str(pid) in out


class ClientBridge:
    """One TCP connection to the running client (reconnects when the client restarts). Pass `port` to talk to the
    client launched on that port (its pinned token); without it, the most recently launched client."""

    def __init__(self, port: int | None = None) -> None:
        self.port = port
        self.sock: socket.socket | None = None
        self.buf = b""
        self.info: dict[str, Any] = {}
        self.next_id = 0

    def _token_info(self) -> dict[str, Any]:
        """{port, token, pid} of the process to talk to (godclient.GodClientBridge reads the editor's own file)."""
        return _token_info(self.port)

    def _connect(self) -> None:
        info = self._token_info()
        if self.sock is not None and info == self.info:
            return
        self.close()
        self.info = info
        try:
            self.sock = socket.create_connection(("127.0.0.1", int(info["port"])), timeout=5.0)
        except OSError as exc:
            alive = _pid_alive(int(info.get("pid", 0)))
            raise ClientBridgeError(f"cannot connect to 127.0.0.1:{info['port']} ({exc}); client pid {info.get('pid')} "
                                    f"{'is running' if alive else 'is not running'}") from None

    def close(self) -> None:
        if self.sock is not None:
            try:
                self.sock.close()
            except OSError:
                pass
        self.sock = None
        self.buf = b""

    def request(self, cmd: str, timeout: float = 20.0, **fields: Any) -> dict[str, Any]:
        """Send one request and wait for its reply. The client answers once per frame, so a loading screen or a
        long frame delays it."""
        for attempt in (0, 1):
            self._connect()
            self.next_id += 1
            msg = {"id": self.next_id, "cmd": cmd, "token": self.info["token"], **fields}
            try:
                assert self.sock is not None
                self.sock.settimeout(timeout)
                self.sock.sendall((json.dumps(msg) + "\n").encode("utf-8"))
                deadline = time.time() + timeout
                while b"\n" not in self.buf:
                    if time.time() > deadline:
                        raise ClientBridgeError(f"no reply to {cmd} within {timeout:.0f} s")
                    chunk = self.sock.recv(65536)
                    if not chunk:
                        raise ConnectionResetError("client closed the connection")
                    self.buf += chunk
                line, self.buf = self.buf.split(b"\n", 1)
                reply = json.loads(line.decode("utf-8", errors="replace"))
                if reply.get("error") == "bad token":
                    raise ClientBridgeError("bad token (stale token file?)")
                return reply
            except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, socket.timeout) as exc:
                self.close()
                self.info = {}
                if attempt:
                    raise ClientBridgeError(f"bridge connection lost: {exc}") from None
        raise ClientBridgeError("unreachable")

    def load_scene(self, avatar: str = "", terrain: str = "") -> dict[str, Any]:
        """From the login screen, start the offline single-player scene (what Load Scene / Next do there) as the
        player template `avatar` (default shared_human_male) on `terrain` (default terrain/simple.trn)."""
        fields = {k: v for k, v in (("avatar", avatar), ("terrain", terrain)) if v}
        reply = self.request("loadscene", timeout=60.0, **fields)
        return {"ok": bool(reply.get("ok")), "result": reply.get("result", reply.get("error"))}

    def camera(self, pivot: list[float] | None = None, distance: float = 2.0, yaw: float = 0.0, pitch: float = 0.0,
               chase: bool = False) -> dict[str, Any]:
        """Free camera orbiting the world point `pivot` (degrees; yaw 0 looks along +z) for framed screenshots, or
        back to the chase camera with chase=True."""
        fields: dict[str, Any] = {"mode": "chase"} if chase else {"pivot": list(pivot or [0, 1, 0]), "distance": distance,
                                                                   "yaw": yaw, "pitch": pitch}
        reply = self.request("camera", **fields)
        return {"ok": bool(reply.get("ok")), "result": reply.get("result", reply.get("error"))}

    def menu(self, action: str = "", open_menu: bool = False) -> dict[str, Any]:
        """The offline test menu (clientGame DevTestMenu): no arguments lists the actions ({id, category, label,
        lines}) and saved warp points; `action` runs one (e.g. "vehicle.swoop", "flight.xwing") and returns each
        console line it ran with that line's output; `open_menu` opens the in-game menu (/devtest menu)."""
        fields: dict[str, Any] = {}
        if open_menu:
            fields["open"] = 1
        elif action:
            fields["action"] = action
        reply = self.request("menu", timeout=60.0, **fields)
        if not reply.get("ok") and "error" in reply:
            raise ClientBridgeError(reply["error"])
        return {"ok": bool(reply.get("ok")), **(reply["result"] if isinstance(reply.get("result"), dict)
                                                else {"error": reply.get("result")})}

    def camera(self, mode: str = "info", pos: list[float] | None = None, look: list[float] | None = None,
               distance: float | None = None, pitch: float | None = None, yaw: float | None = None,
               target: str = "", pivot: list[float] | None = None) -> dict[str, Any]:
        """Place the client's camera for screenshots. mode "free": at world `pos` looking at `look` (default: the
        player), for aerial shots. "orbit": `distance` m from the player (or the look-at target with target="last"),
        `pitch` degrees down, `yaw` degrees (default: the player's heading). "pivot": orbit the world point `pivot`.
        "chase": back to the normal chase camera. "info": where the camera is."""
        fields: dict[str, Any] = {}
        if mode == "pivot":
            fields["pivot"] = list(pivot or [0.0, 0.0, 0.0])
        else:
            fields["mode"] = mode
        if pos is not None:
            fields["pos"] = list(pos)
        if look is not None:
            fields["look"] = list(look)
        for key, value in (("distance", distance), ("pitch", pitch), ("yaw", yaw)):
            if value is not None:
                fields[key] = int(round(value)) if mode == "orbit" else value
        if target:
            fields["target"] = target
        reply = self.request("camera", timeout=20.0, **fields)
        return {"ok": bool(reply.get("ok")), "result": reply.get("result", reply.get("error"))}


def launch(port: int = DEFAULT_PORT, export_root: str = "D:/exported", extra_args: list[str] | None = None) -> dict[str, Any]:
    """Start the development client with the export folder on its search path and the bridge on `port`, then wait
    until the bridge answers (the client writes a fresh token file at start-up)."""
    exe = CLIENT_DIR / CLIENT_EXE
    if not exe.exists():
        raise ClientBridgeError(f"{exe} not found")
    stale = TOKEN_FILE.stat().st_mtime if TOKEN_FILE.exists() else 0.0
    # Offline only: exe/win64_rel/login.cfg (included by titan_d.cfg) holds a saved login with
    # autoConnectToLoginServer=true, so a plain launch signs in to a running server by itself.
    args = [str(exe), "--", "-s", "SharedFile", f"searchPath_00_8={export_root}", "-s", "ClientGame",
            f"devBridgePort={port}", "autoConnectToLoginServer=false", "loginServerPort0=1"] + list(extra_args or [])
    proc = subprocess.Popen(args, cwd=str(CLIENT_DIR))
    deadline = time.time() + 180.0
    pinned = pinned_token_file(port)
    while time.time() < deadline:
        if proc.poll() is not None:
            raise ClientBridgeError(f"client exited during start-up (code {proc.returncode})")
        if TOKEN_FILE.exists() and TOKEN_FILE.stat().st_mtime > stale:
            try:
                info = json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
            except ValueError:
                info = {}
            if int(info.get("pid", 0)) == proc.pid:
                pinned.write_text(json.dumps(info), encoding="utf-8")
                bridge = ClientBridge(port)
                try:
                    bridge.request("ping", timeout=5.0)
                    bridge.close()
                    return {"pid": proc.pid, "port": port, "exe": str(exe), "token_file": str(pinned)}
                except ClientBridgeError:
                    pass
        time.sleep(1.0)
    raise ClientBridgeError("the bridge did not answer within 180 s")


# ----------------------------------------------------------------------------------------------------------------
# screenshots: the engine writes TGA / BMP / JPG; MCP images want PNG or JPEG

def _png(width: int, height: int, rows: list[bytes]) -> bytes:
    raw = b"".join(b"\0" + r for r in rows)

    def chunk(tag: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def _tga_to_png(data: bytes) -> bytes:
    idlen, _, itype = data[0], data[1], data[2]
    w, h, bpp, desc = struct.unpack_from("<HHBB", data, 12)
    if itype not in (2, 10) or bpp not in (24, 32):
        raise ClientBridgeError(f"unsupported TGA (type {itype}, {bpp} bpp)")
    px = bpp // 8
    pos = 18 + idlen
    if itype == 2:
        pix = data[pos:pos + w * h * px]
    else:                                   # RLE
        out = bytearray()
        while len(out) < w * h * px:
            hdr = data[pos]
            pos += 1
            n = (hdr & 0x7F) + 1
            if hdr & 0x80:
                out += data[pos:pos + px] * n
                pos += px
            else:
                out += data[pos:pos + n * px]
                pos += n * px
        pix = bytes(out)
    rows = []
    for y in range(h):
        r = pix[y * w * px:(y + 1) * w * px]
        rows.append(b"".join(bytes((r[i + 2], r[i + 1], r[i])) for i in range(0, len(r), px)))
    if not desc & 0x20:                      # origin bottom-left
        rows.reverse()
    return _png(w, h, rows)


def _bmp_to_png(data: bytes) -> bytes:
    off = struct.unpack_from("<I", data, 10)[0]
    w, h = struct.unpack_from("<ii", data, 18)
    bpp = struct.unpack_from("<H", data, 28)[0]
    if bpp not in (24, 32):
        raise ClientBridgeError(f"unsupported BMP ({bpp} bpp)")
    px = bpp // 8
    stride = (w * px + 3) & ~3
    rows = []
    for y in range(abs(h)):
        r = data[off + y * stride:off + y * stride + w * px]
        rows.append(b"".join(bytes((r[i + 2], r[i + 1], r[i])) for i in range(0, len(r), px)))
    if h > 0:
        rows.reverse()
    return _png(w, abs(h), rows)


def image_for_mcp(path: Path) -> tuple[bytes, str]:
    data = path.read_bytes()
    ext = path.suffix.lower()
    if ext in (".jpg", ".jpeg"):
        return data, "jpeg"
    if ext == ".tga":
        return _tga_to_png(data), "png"
    if ext == ".bmp":
        return _bmp_to_png(data), "png"
    raise ClientBridgeError(f"unknown screenshot format {ext}")
