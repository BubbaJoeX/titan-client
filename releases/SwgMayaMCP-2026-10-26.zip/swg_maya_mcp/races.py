"""Player race remaster helpers (examples/make_races.py drives them).

Everything works on read_mgn dicts (wearable.py), in engine space: +Y up, +Z forward (toes point +Z), X left/right
mirrored against Maya. Nothing here changes vertex counts, indices, weights or existing blend targets, so the
skeleton, the occlusion zones and every wearable fitted to the stock body keep working.

  body morphs   new blend targets driven by new /shared_owner/ variables (shared_owner, so a wearable carrying
                a blend target of the same name follows the body):
                  blend_chest_large  fuller chest (female bodies), the counterpart of stock blend_flat_chest
                  blend_glutes       rounder buttocks (all bodies)
                  blend_bulge        fuller groin (male bodies)
                Regions are found on each mesh from its own geometry and skinning, so every LOD and species gets a
                matching shape. Normal and DOT3 deltas are recomputed from the morphed surface.
  seam welding  normals of coincident border vertices of two meshes (neck, wrist) averaged so lighting has no
                seam; DOT3 tangents re-orthogonalised.
  preview       a tiny software renderer (numpy + PIL) for front/side/back checks without Maya.
"""

from __future__ import annotations

import math
from collections import defaultdict
from typing import Any

import numpy as np

MORPHS = {
    "blend_chest_large": "female",
    "blend_glutes": "all",
    "blend_bulge": "male",
}


# ----------------------------------------------------------------------------
# mesh helpers
# ----------------------------------------------------------------------------

def corners(m) -> list[tuple[int, int, int | None]]:
    """(position index, normal index, dot3 index) per shader vertex, all shaders concatenated."""
    out = []
    for s in m["shaders"]:
        n = s["nidx"] or s["pidx"]
        d = s["dot3idx"] or [None] * len(s["pidx"])
        out.extend(zip(s["pidx"], n, d))
    return out


def triangles(m) -> list[tuple[tuple[int, int, int | None], ...]]:
    """Triangles as corner triples (pidx, nidx, dot3idx)."""
    out = []
    for s in m["shaders"]:
        n = s["nidx"] or s["pidx"]
        d = s["dot3idx"] or [None] * len(s["pidx"])
        for pr in s["prims"]:
            for t in pr["tris"]:
                out.append(tuple((s["pidx"][i], n[i], d[i]) for i in t[1:]))
    return out


def dominant_joints(m) -> list[str]:
    return [m["transforms"][max(w, key=lambda t: t[1])[0]] if w else "" for w in m["weights"]]


def vertex_normals(m, P: np.ndarray) -> np.ndarray:
    """Area-weighted normals per normal index for positions P, keeping the mesh's own split normals (a normal
    index only gathers the faces that use it). Orientation follows the stored normals."""
    N0 = np.array(m["normals"], dtype=float)
    acc = np.zeros_like(N0)
    for (a, na, _), (b, nb, _), (c, nc, _) in triangles(m):
        f = np.cross(P[b] - P[a], P[c] - P[a])
        for n in (na, nb, nc):
            acc[n] += f
    sign = np.sign(np.einsum("ij,ij->i", acc, N0))
    sign[sign == 0] = 1
    acc *= sign[:, None]
    ln = np.linalg.norm(acc, axis=1)
    ok = ln > 1e-12
    out = N0.copy()
    out[ok] = acc[ok] / ln[ok, None]
    return out


def smoothstep_falloff(r: np.ndarray) -> np.ndarray:
    """1 at r=0, 0 at r>=1, C1 smooth."""
    t = np.clip(1.0 - r, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


# ----------------------------------------------------------------------------
# landmarks
# ----------------------------------------------------------------------------

def landmarks(m) -> dict[str, Any]:
    """Body landmarks from geometry + skinning: height, crotch height, hip width, glute and groin centres."""
    P = np.array(m["positions"], dtype=float)
    N = np.array(m["normals"], dtype=float)
    dom = dominant_joints(m)
    # vertex normal per position (first normal that uses it)
    pn = np.zeros_like(P)
    for p, n, _ in corners(m):
        if not pn[p].any():
            pn[p] = N[n]
    height = P[:, 1].max()
    pelvis = np.array([d in ("root", "lthigh", "rthigh", "spine1") for d in dom])
    legs = np.array([d in ("lthigh", "rthigh", "lshin", "rshin") for d in dom])
    # crotch: lowest root-skinned point near the midline (thigh-skinned inner legs reach the midline lower down)
    mid = np.array([d == "root" for d in dom]) & (np.abs(P[:, 0]) < 0.05)
    crotch_y = P[mid, 1].min() if mid.any() else 0.555 * height
    if not 0.5 * height <= crotch_y <= 0.62 * height:              # fur skirts (Wookiee) hang below the crotch
        crotch_y = 0.555 * height
    band = pelvis & (P[:, 1] > crotch_y) & (P[:, 1] < crotch_y + 0.18 * height)
    hip_half = np.abs(P[band, 0]).max() if band.any() else 0.17
    out = {"height": height, "crotch_y": crotch_y, "hip_half": hip_half, "pn": pn}
    # glutes: per side, the most backward (min z) pelvis/thigh vertex above the crotch
    for side, sgn in (("l", 1.0), ("r", -1.0)):
        # at half the hip width, a little above the crotch, on the back surface
        sel = (pelvis | legs) & (P[:, 0] * sgn > 0.01) & (pn[:, 2] < -0.2)
        if sel.any():
            aim = np.array([sgn * 0.5 * hip_half, crotch_y + 0.055 * height])
            i = np.flatnonzero(sel)[np.argmin(np.linalg.norm(P[sel][:, :2] - aim, axis=1))]
            out[f"glute_{side}"] = np.array([aim[0], aim[1], P[i, 2]])
    # groin: the most forward midline vertex just above the crotch
    sel = (pelvis | legs) & (np.abs(P[:, 0]) < 0.03) & (P[:, 1] > crotch_y - 0.01) & \
          (P[:, 1] < crotch_y + 0.07 * height) & (pn[:, 2] > 0.2)
    if sel.any():
        i = np.flatnonzero(sel)[np.argmax(P[sel, 2])]
        out["groin"] = P[i].copy()
    return out


# ----------------------------------------------------------------------------
# morphs
# ----------------------------------------------------------------------------

def _region(P, centre, radii):
    d = (P - centre) / np.asarray(radii, dtype=float)
    return smoothstep_falloff(np.sqrt((d * d).sum(1)))


def morph_offsets(m, name: str, amount: float = 1.0) -> np.ndarray:
    """Position offsets (n x 3) of morph `name` on mesh m (zeros where it doesn't apply)."""
    P = np.array(m["positions"], dtype=float)
    lm = landmarks(m)
    pn = lm["pn"]
    H = lm["height"] / 1.56                                         # scale against the human female body
    off = np.zeros_like(P)
    if name == "blend_glutes":
        for side in ("l", "r"):
            c = lm.get(f"glute_{side}")
            if c is None:
                continue
            c = c + np.array([0.0, 0.0, 0.04 * H])                  # centre inside the cheek
            w = _region(P, c, (0.11 * H, 0.13 * H, 0.16 * H))
            w *= np.clip(-pn[:, 2] * 1.4 + 0.15, 0.0, 1.0)          # back-facing surface only
            push = pn * 0.045 * H + np.array([0.0, 0.006 * H, -0.012 * H])
            off += w[:, None] * push
    elif name == "blend_bulge":
        c = lm.get("groin")
        if c is not None:
            c = c + np.array([0.0, 0.025 * H, -0.03 * H])
            w = _region(P, c, (0.065 * H, 0.08 * H, 0.09 * H))
            w *= np.clip(pn[:, 2] * 1.4, 0.0, 1.0)                  # front-facing surface only
            off += w[:, None] * (pn * 0.028 * H + np.array([0.0, -0.004 * H, 0.008 * H]))
    elif name == "blend_chest_large":
        flat = next((t for t in m["blend_targets"] if t["name"] == "blend_flat_chest"), None)
        if flat is not None and flat["positions"]:
            idx = np.array([i for i, _ in flat["positions"]])
            D = np.array([d for _, d in flat["positions"]], dtype=float)
            mag = np.linalg.norm(D, axis=1)
            # the inverse of flattening, rounded out along the normal, with a little natural drop
            off[idx] = -D * 0.8 + pn[idx] * mag[:, None] * 0.6 + np.array([0.0, -0.15, 0.0]) * mag[:, None]
            # spread a soft rim around the flat_chest region so the bigger shape has no crease at its edge
            core = P[idx]
            centres = [core[core[:, 0] > 0].mean(0) if (core[:, 0] > 0).any() else None,
                       core[core[:, 0] < 0].mean(0) if (core[:, 0] < 0).any() else None]
            rim = np.zeros(len(P), dtype=bool)
            rim[idx] = True
            for c in centres:
                if c is None:
                    continue
                w = _region(P, c, (0.11 * H, 0.11 * H, 0.12 * H)) * np.clip(pn[:, 2] * 1.5, 0, 1)
                w[rim] *= 0.5
                off += w[:, None] * pn * 0.016 * H
    else:
        raise KeyError(name)
    return off * amount


def add_blend_target(m, name: str, offsets: np.ndarray, eps: float = 1e-5) -> dict[str, Any] | None:
    """Append (or replace) blend target `name` on m from per-position offsets, with recomputed normal and DOT3
    deltas. Returns a summary, or None if the offsets are all zero."""
    P = np.array(m["positions"], dtype=float)
    moved = np.flatnonzero(np.linalg.norm(offsets, axis=1) > eps)
    if not len(moved):
        return None
    N0 = vertex_normals(m, P)
    N1 = vertex_normals(m, P + offsets)
    Nstored = np.array(m["normals"], dtype=float)
    dN = N1 - N0
    nmoved = np.flatnonzero(np.linalg.norm(dN, axis=1) > 1e-4)
    target = {"name": name, "positions": [(int(i), tuple(float(x) for x in offsets[i])) for i in moved],
              "normals": [(int(i), tuple(float(x) for x in dN[i])) for i in nmoved],
              "dot3": None, "hardpoints": None, "_present": ["POSN", "NORM"]}
    if m.get("dot3"):
        T = np.array(m["dot3"], dtype=float)
        d3n = {}
        for _, n, d in corners(m):
            if d is not None:
                d3n.setdefault(d, n)
        dd = []
        for d, n in d3n.items():
            if np.linalg.norm(dN[n]) <= 1e-4:
                continue
            nn = Nstored[n] + dN[n]
            nn /= np.linalg.norm(nn)
            t = T[d, :3]
            t1 = t - nn * float(nn @ t)
            ln = np.linalg.norm(t1)
            if ln < 1e-6:
                continue
            t1 = t1 / ln * np.linalg.norm(t)
            dd.append((int(d), tuple(float(x) for x in (t1 - t))))
        target["dot3"] = dd
        target["_present"].append("DOT3")
    target["_counts"] = (len(target["positions"]), len(target["normals"]))
    m["blend_targets"] = [t for t in m["blend_targets"] if t["name"] != name] + [target]
    return {"name": name, "positions": len(target["positions"]), "normals": len(target["normals"]),
            "max_offset_mm": round(float(np.linalg.norm(offsets, axis=1).max()) * 1000, 1)}


# ----------------------------------------------------------------------------
# seams
# ----------------------------------------------------------------------------

def border_positions(m) -> set[int]:
    count = defaultdict(int)
    for (a, _, _), (b, _, _), (c, _, _) in triangles(m):
        for e in ((a, b), (b, c), (c, a)):
            count[tuple(sorted(e))] += 1
    out = set()
    for e, c in count.items():
        if c == 1:
            out.update(e)
    return out


def weld_seam_normals(meshes: dict[str, Any], tol: float = 0.0008, max_angle: float = 45.0) -> dict[str, int]:
    """Average the normals of coincident border vertices across meshes (and their DOT3 tangents follow), so the
    neck/wrist joins light as one surface. Pairs further apart than max_angle are left alone (real creases)."""
    pts = []                                                   # (mesh, normal index, pos)
    for name, m in meshes.items():
        P = np.array(m["positions"], dtype=float)
        bset = border_positions(m)
        for p, n, _ in corners(m):
            if p in bset:
                pts.append((name, n, P[p]))
    grid = defaultdict(list)
    for k, (_, _, p) in enumerate(pts):
        grid[tuple(np.floor(p / tol).astype(int))].append(k)
    groups, seen = [], set()
    for k, (name, n, p) in enumerate(pts):
        if k in seen:
            continue
        cell = np.floor(p / tol).astype(int)
        g = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    for j in grid.get((cell[0] + dx, cell[1] + dy, cell[2] + dz), ()):
                        if j not in seen and np.linalg.norm(pts[j][2] - p) <= tol:
                            g.append(j)
        seen.update(g)
        if len({pts[j][0] for j in g}) > 1:
            groups.append(g)
    changed = defaultdict(int)
    for g in groups:
        keys = {(pts[j][0], pts[j][1]) for j in g}
        vecs = [np.array(meshes[mn]["normals"][ni], dtype=float) for mn, ni in keys]
        avg = np.sum(vecs, axis=0)
        if np.linalg.norm(avg) < 1e-6:
            continue
        avg /= np.linalg.norm(avg)
        if max(math.degrees(math.acos(float(np.clip(v @ avg, -1, 1)))) for v in vecs) > max_angle:
            continue
        for mn, ni in keys:
            if not np.allclose(meshes[mn]["normals"][ni], avg, atol=1e-6):
                meshes[mn]["normals"][ni] = tuple(float(x) for x in avg)
                changed[mn] += 1
    for mn in changed:
        reorthogonalize_dot3(meshes[mn])
    return dict(changed)


def reorthogonalize_dot3(m) -> None:
    if not m.get("dot3"):
        return
    N = np.array(m["normals"], dtype=float)
    d3n = {}
    for _, n, d in corners(m):
        if d is not None:
            d3n.setdefault(d, n)
    T = [list(t) for t in m["dot3"]]
    for d, n in d3n.items():
        t = np.array(T[d][:3])
        t1 = t - N[n] * float(N[n] @ t)
        ln = np.linalg.norm(t1)
        if ln > 1e-6:
            T[d][:3] = list(t1 / ln * np.linalg.norm(t))
    m["dot3"] = [tuple(t) for t in T]


# ----------------------------------------------------------------------------
# preview
# ----------------------------------------------------------------------------

def render(meshes: list[dict[str, Any]], view: str = "front", size: int = 512, offsets: list | None = None,
           color=(205, 170, 150)):
    """Flat-ish shaded orthographic render (PIL Image) of read_mgn meshes: view front | back | side | left."""
    from PIL import Image
    tris_all = []
    for k, m in enumerate(meshes):
        P = np.array(m["positions"], dtype=float)
        if offsets and offsets[k] is not None:
            P = P + offsets[k]
        for (a, _, _), (b, _, _), (c, _, _) in triangles(m):
            tris_all.append((P[a], P[b], P[c]))
    T = np.array(tris_all)                                          # t x 3 x 3
    rot = {"front": lambda v: np.stack([-v[..., 0], v[..., 1], v[..., 2]], -1),
           "back": lambda v: np.stack([v[..., 0], v[..., 1], -v[..., 2]], -1),
           "side": lambda v: np.stack([v[..., 2], v[..., 1], -v[..., 0]], -1),
           "left": lambda v: np.stack([-v[..., 2], v[..., 1], v[..., 0]], -1)}[view]
    V = rot(T)
    lo, hi = V.reshape(-1, 3).min(0), V.reshape(-1, 3).max(0)
    span = max(hi[0] - lo[0], hi[1] - lo[1]) * 1.05
    cx, cy = (lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2
    S = size / span
    X = (V[..., 0] - cx) * S + size / 2
    Y = size / 2 - (V[..., 1] - cy) * S
    Z = V[..., 2]
    fn = np.cross(V[:, 1] - V[:, 0], V[:, 2] - V[:, 0])
    fn /= np.linalg.norm(fn, axis=1, keepdims=True) + 1e-12
    zbuf = np.full((size, size), -1e9)
    img = np.zeros((size, size, 3), dtype=float) + 30
    light = np.array([0.35, 0.5, 0.8])
    light /= np.linalg.norm(light)
    for t in range(len(V)):
        xs, ys, zs = X[t], Y[t], Z[t]
        x0, x1 = int(max(0, math.floor(xs.min()))), int(min(size - 1, math.ceil(xs.max())))
        y0, y1 = int(max(0, math.floor(ys.min()))), int(min(size - 1, math.ceil(ys.max())))
        if x1 < x0 or y1 < y0:
            continue
        gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        d = (ys[1] - ys[2]) * (xs[0] - xs[2]) + (xs[2] - xs[1]) * (ys[0] - ys[2])
        if abs(d) < 1e-12:
            continue
        l0 = ((ys[1] - ys[2]) * (gx - xs[2]) + (xs[2] - xs[1]) * (gy - ys[2])) / d
        l1 = ((ys[2] - ys[0]) * (gx - xs[2]) + (xs[0] - xs[2]) * (gy - ys[2])) / d
        l2 = 1 - l0 - l1
        inside = (l0 >= -1e-6) & (l1 >= -1e-6) & (l2 >= -1e-6)
        if not inside.any():
            continue
        z = l0 * zs[0] + l1 * zs[1] + l2 * zs[2]
        sub = zbuf[y0:y1 + 1, x0:x1 + 1]
        upd = inside & (z > sub)
        sub[upd] = z[upd]
        shade = 0.25 + 0.75 * abs(float(fn[t] @ light))
        img[y0:y1 + 1, x0:x1 + 1][upd] = np.array(color) * shade
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))


# ----------------------------------------------------------------------------
# textures
# ----------------------------------------------------------------------------
#
# Only the compiled DXT textures exist (no source art), so the remaster is a clean 2x (4x for tiny eye/mouth maps)
# reconstruction that keeps every channel's meaning:
#   colour  MAIN / HUEB: chroma de-blocked (DXT quantises colour per 4x4 block), Lanczos upscale, luminance unsharp
#           mask; alpha (hue mask / alpha test) upscaled without sharpening
#   normal  CNRM (DXT5nm: X in alpha, Y in green): Lanczos upscale of X/Y, optional micro detail (pores / scales)
#           added as a height-field gradient, R and B kept as stock (0)
#   spec    SPEC: Lanczos upscale, light sharpening (the mask lives in alpha)
# Output is uncompressed A8R8G8B8 with a full box-filtered mip chain, written at the stock path under D:/exported.

def _pil(ch: np.ndarray):
    from PIL import Image
    return Image.fromarray(np.clip(ch, 0, 255).astype(np.uint8), "L")


def _resize(ch: np.ndarray, w: int, h: int) -> np.ndarray:
    from PIL import Image
    return np.asarray(_pil(ch).resize((w, h), Image.LANCZOS), dtype=float)


def _blur(ch: np.ndarray, radius: float) -> np.ndarray:
    from PIL import ImageFilter
    return np.asarray(_pil(ch).filter(ImageFilter.GaussianBlur(radius)), dtype=float)


def _blur_f(a: np.ndarray, radius: float) -> np.ndarray:
    """Gaussian blur of a float field (separable, wrap-around)."""
    r = max(1, int(radius * 3))
    k = np.exp(-0.5 * (np.arange(-r, r + 1) / radius) ** 2)
    k /= k.sum()
    out = sum(np.roll(a, i, axis=1) * w for i, w in zip(range(-r, r + 1), k))
    return sum(np.roll(out, i, axis=0) * w for i, w in zip(range(-r, r + 1), k))


def unsharp(ch: np.ndarray, radius: float, amount: float, threshold: float = 1.0) -> np.ndarray:
    low = _blur(ch, radius)
    d = ch - low
    d[np.abs(d) < threshold] = 0
    return np.clip(ch + amount * d, 0, 255)


def deblock(ch: np.ndarray, strength: float = 0.7) -> np.ndarray:
    """Soften the 4x4 DXT block edges: pixels on either side of a block boundary move toward a local blur,
    scaled down where the step is a real edge (larger than the block quantisation)."""
    h, w = ch.shape
    m = np.zeros((h, w))
    idx_x = np.arange(w) % 4
    idx_y = np.arange(h) % 4
    m[:, (idx_x == 0) | (idx_x == 3)] += 0.5
    m[(idx_y == 0) | (idx_y == 3), :] += 0.5
    low = _blur_f(ch, 0.9)
    d = low - ch
    keep = np.clip(1.0 - np.abs(d) / 24.0, 0.0, 1.0)              # leave strong edges alone
    return ch + d * m * keep * strength


def micro_detail(h: int, w: int, kind: str, seed: int) -> tuple[np.ndarray, np.ndarray]:
    """Tangent-space gradient (dX, dY) of a procedural height field: 'pores' (fine skin), 'scales' (reptile)."""
    rng = np.random.default_rng(seed)
    if kind == "pores":
        f = _blur_f(rng.standard_normal((h, w)), 0.8) * 0.6 + _blur_f(rng.standard_normal((h, w)), 2.0) * 0.4
        amp = 6.0
    elif kind == "scales":
        cells = max(8, w // 10)                                   # Worley-style cells, about 10 px across
        pts = rng.random((cells * cells, 2)) * [w, h]
        yy, xx = np.mgrid[0:h, 0:w]
        f = np.full((h, w), 1e9)
        for px, py in pts:
            dx = np.minimum(np.abs(xx - px), w - np.abs(xx - px))
            dy = np.minimum(np.abs(yy - py), h - np.abs(yy - py))
            np.minimum(f, dx * dx + dy * dy, out=f)
        f = -np.sqrt(f)
        f = _blur_f(f, 0.7)
        amp = 2.2
    else:
        raise KeyError(kind)
    f = (f - f.mean()) / (f.std() + 1e-9)
    gx = (np.roll(f, -1, 1) - np.roll(f, 1, 1)) * 0.5
    gy = (np.roll(f, -1, 0) - np.roll(f, 1, 0)) * 0.5
    return -gx * amp, gy * amp


def remaster_rgba(rgba: np.ndarray, kind: str, factor: int = 2, detail: str | None = None,
                  seed: int = 0) -> np.ndarray:
    """rgba: HxWx4 uint8 (top-down). Returns the remastered (H*factor)x(W*factor)x4 uint8."""
    h, w = rgba.shape[:2]
    W2, H2 = w * factor, h * factor
    src = rgba.astype(float)
    out = np.zeros((H2, W2, 4))
    if kind == "color":
        r, g, b = src[..., 0], src[..., 1], src[..., 2]
        y = 0.299 * r + 0.587 * g + 0.114 * b
        cb, cr = b - y, r - y
        cb, cr = _blur_f(cb, 0.7), _blur_f(cr, 0.7)              # DXT colour blocking lives in chroma
        y = deblock(y)
        Y = unsharp(_resize(y, W2, H2), 1.2 * factor / 2, 0.45, 1.0)
        CB = _resize(np.clip(cb + 128, 0, 255), W2, H2) - 128
        CR = _resize(np.clip(cr + 128, 0, 255), W2, H2) - 128
        R = Y + CR
        B = Y + CB
        G = (Y - 0.299 * R - 0.114 * B) / 0.587
        out[..., 0], out[..., 1], out[..., 2] = R, G, B
        out[..., 3] = _resize(src[..., 3], W2, H2)
    elif kind == "normal":
        X = _resize(src[..., 3], W2, H2)
        Y = _resize(src[..., 1], W2, H2)
        if detail:
            dx, dy = micro_detail(H2, W2, detail, seed)
            X, Y = X + dx, Y + dy
        out[..., 0] = _resize(src[..., 0], W2, H2)
        out[..., 1] = Y
        out[..., 2] = _resize(src[..., 2], W2, H2)
        out[..., 3] = X
    elif kind == "spec":
        for c in range(4):
            out[..., c] = unsharp(_resize(src[..., c], W2, H2), 1.0 * factor / 2, 0.3, 2.0)
    else:
        for c in range(4):
            out[..., c] = _resize(src[..., c], W2, H2)
    return np.clip(np.rint(out), 0, 255).astype(np.uint8)


def write_dds_argb(path, rgba: np.ndarray, mips: bool = True) -> dict[str, Any]:
    """Uncompressed A8R8G8B8 .dds from a top-down HxWx4 RGBA array, with a box-filtered mip chain (numpy;
    same layout as iff.write_dds_rgba)."""
    import struct
    from pathlib import Path
    h, w = rgba.shape[:2]
    levels = [rgba.astype(np.uint8)]
    while mips and (levels[-1].shape[0] > 1 or levels[-1].shape[1] > 1):
        a = levels[-1].astype(np.uint32)
        lh, lw = a.shape[:2]
        if lh > 1:
            a = (a[0::2] + a[1::2])
        else:
            a = a * 2
        if lw > 1:
            a = (a[:, 0::2] + a[:, 1::2])
        else:
            a = a * 2
        levels.append((a // 4).astype(np.uint8))
    flags = 0x100F | (0x20000 if mips else 0)
    hdr = struct.pack("<4sIIIIIII44x", b"DDS ", 124, flags, h, w, w * 4, 0, len(levels))
    pf = struct.pack("<II4sIIIII", 32, 0x41, b"\0\0\0\0", 32, 0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000)
    caps = struct.pack("<IIII4x", 0x1000 | (0x400008 if mips else 0), 0, 0, 0)
    body = b"".join(lv[..., [2, 1, 0, 3]].tobytes() for lv in levels)
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(hdr + pf + caps + body)
    return {"path": str(out), "size": [w, h], "mips": len(levels)}
