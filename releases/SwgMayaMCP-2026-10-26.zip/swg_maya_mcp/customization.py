"""Customization data codecs: the asset customization manager (customization/asset_customization_manager.iff,
FORM ACST/0000), the customization id manager (customization_id_manager.iff, FORM CIDM/0001) and palettes
(.pal, RIFF PAL).

ACST follows AssetCustomizationManager::load_0000 table for table, and read_acst / write_acst round-trip the stock
file byte for byte. The tables (all ids start at 1):
  NAME  one block of NUL-terminated strings (palette and variable names), addressed by byte offset
  PNOF  palette id -> name offset (uint16)            VNOF  variable id -> name offset (uint16)
  DEFV  default id -> default value (int32)           IRNG  int range id -> [min, max) (2 x int32)
  RTYP  range id -> type (uint16: 0x8000 | palette id, or int range id)
  UCMP  variable usage id -> (variable id, range id, default id) (3 x uint16)
  ULST  usage list (uint32 usage ids)                 UIDX  asset id -> (ULST start, count) (sorted by asset id)
  LLST  link list (uint32 asset ids)                  LIDX  asset id -> (LLST start, count) (sorted by asset id)
  CIDX  asset name crc -> asset id (sorted by crc)
An asset's customization variables are its own usages plus, recursively, those of the assets it links to
(.sat -> .lmg -> .mgn -> .sht / .trt ...). Usage records are shared between assets, so changing one asset's
variable means a new usage record and a new ULST run for that asset (add_asset_variable does this).

CIDM maps persisted variable ids to names. CustomizationData version 4 (Titan) persists ids up to 0x7f + 255
(see CustomizationData.cpp); stock version 2 data only reaches 127.
"""

from __future__ import annotations

import re
import struct
from pathlib import Path
from typing import Any

from .iff import Block, parse_iff, serialize_iff
from .rails import _crc

MAX_CUSTOMIZATION_ID = 0x7F + 255


def _chunk(tag: str, data: bytes) -> Block:
    return Block(tag, False, data)


def _form(tag: str, children: list[Block]) -> Block:
    return Block(tag, True, b"", children)


def asset_crc(name: str) -> int:
    """CrcString crc of a normalised asset path (lower case, forward slashes)."""
    return _crc(name.replace("\\", "/").lower())


# ----------------------------------------------------------------------------
# ACST
# ----------------------------------------------------------------------------

def read_acst(path_or_bytes) -> dict[str, Any]:
    data = path_or_bytes if isinstance(path_or_bytes, bytes) else Path(path_or_bytes).read_bytes()
    ver = parse_iff(data).first("ACST").forms()[0]
    if ver.tag != "0000":
        raise ValueError(f"ACST version {ver.tag} not supported")
    c = {b.tag: b.data for b in ver.children}

    def arr(fmt, tag):
        n = struct.calcsize("<" + fmt)
        d = c[tag]
        return [struct.unpack_from("<" + fmt, d, i) for i in range(0, len(d), n)]

    a = {
        "names": c["NAME"],
        "pnof": [x[0] for x in arr("H", "PNOF")],
        "vnof": [x[0] for x in arr("H", "VNOF")],
        "defv": [x[0] for x in arr("i", "DEFV")],
        "irng": arr("ii", "IRNG"),
        "rtyp": [x[0] for x in arr("H", "RTYP")],
        "ucmp": arr("HHH", "UCMP"),
        "ulst": [x[0] for x in arr("I", "ULST")],
        "uidx": [list(x) for x in arr("IIB", "UIDX")],
        "llst": [x[0] for x in arr("I", "LLST")],
        "lidx": [list(x) for x in arr("IIB", "LIDX")],
        "cidx": [list(x) for x in arr("II", "CIDX")],
    }
    return a


def write_acst(a: dict[str, Any]) -> bytes:
    def pack(fmt, rows):
        return b"".join(struct.pack("<" + fmt, *(r if isinstance(r, (list, tuple)) else (r,))) for r in rows)

    kids = [_chunk("NAME", bytes(a["names"])), _chunk("PNOF", pack("H", a["pnof"])),
            _chunk("VNOF", pack("H", a["vnof"])), _chunk("DEFV", pack("i", a["defv"])),
            _chunk("IRNG", pack("ii", a["irng"])), _chunk("RTYP", pack("H", a["rtyp"])),
            _chunk("UCMP", pack("HHH", a["ucmp"])), _chunk("ULST", pack("I", a["ulst"])),
            _chunk("UIDX", pack("IIB", sorted(a["uidx"]))), _chunk("LLST", pack("I", a["llst"])),
            _chunk("LIDX", pack("IIB", sorted(a["lidx"]))), _chunk("CIDX", pack("II", sorted(a["cidx"])))]
    return serialize_iff(_form("<root>", [_form("ACST", [_form("0000", kids)])]))


def _name_at(a, offset: int) -> str:
    end = a["names"].index(b"\0", offset)
    return a["names"][offset:end].decode("latin1")


def _add_name(a, name: str) -> int:
    """Offset of `name` in the name block, appending it if missing (offsets are uint16)."""
    needle = name.encode("latin1") + b"\0"
    blob = bytes(a["names"])
    pos = 0
    while True:
        pos = blob.find(needle, pos)
        if pos < 0:
            break
        if pos == 0 or blob[pos - 1] == 0:
            return pos
        pos += 1
    off = len(blob)
    if off + len(needle) > 0xFFFF:
        raise ValueError("ACST name block is full (uint16 offsets)")
    a["names"] = blob + needle
    return off


def variable_name(a, variable_id: int) -> str:
    return _name_at(a, a["vnof"][variable_id - 1])


def palette_name(a, palette_id: int) -> str:
    return _name_at(a, a["pnof"][palette_id - 1])


def asset_id(a, name: str) -> int | None:
    crc = asset_crc(name)
    return next((aid for c, aid in a["cidx"] if c == crc), None)


def _index_entry(table, aid):
    return next((e for e in table if e[0] == aid), None)


def describe_usage(a, usage_id: int) -> dict[str, Any]:
    var, rng, dflt = a["ucmp"][usage_id - 1]
    rt = a["rtyp"][rng - 1]
    out = {"usage": usage_id, "variable": variable_name(a, var), "default": a["defv"][dflt - 1]}
    if rt & 0x8000:
        out["palette"] = palette_name(a, rt & 0x7FFF)
    else:
        out["range"] = tuple(a["irng"][(rt & 0x7FFF) - 1])
    return out


def asset_variables(a, name: str, recursive: bool = True) -> list[dict[str, Any]]:
    """Customization variables an asset declares (and, recursively, the assets it links to)."""
    aid = asset_id(a, name)
    if aid is None:
        return []
    out, seen = [], set()

    def visit(i, depth):
        if i in seen:
            return
        seen.add(i)
        u = _index_entry(a["uidx"], i)
        if u:
            for uid in a["ulst"][u[1]:u[1] + u[2]]:
                out.append({**describe_usage(a, uid), "asset_id": i, "depth": depth})
        if recursive:
            lk = _index_entry(a["lidx"], i)
            if lk:
                for j in a["llst"][lk[1]:lk[1] + lk[2]]:
                    visit(j, depth + 1)
    visit(aid, 0)
    return out


def asset_links(a, name: str) -> list[int]:
    aid = asset_id(a, name)
    lk = _index_entry(a["lidx"], aid) if aid else None
    return a["llst"][lk[1]:lk[1] + lk[2]] if lk else []


def _variable_id(a, name: str) -> int:
    for i, off in enumerate(a["vnof"]):
        if _name_at(a, off) == name:
            return i + 1
    a["vnof"].append(_add_name(a, name))
    return len(a["vnof"])


def _default_id(a, value: int) -> int:
    if value in a["defv"]:
        return a["defv"].index(value) + 1
    a["defv"].append(value)
    return len(a["defv"])


def _int_range_id(a, rng: tuple[int, int]) -> int:
    """Range id (RTYP index) of an int range, adding the IRNG and RTYP entries if missing."""
    rng = tuple(rng)
    if rng in [tuple(r) for r in a["irng"]]:
        irid = [tuple(r) for r in a["irng"]].index(rng) + 1
    else:
        a["irng"].append(rng)
        irid = len(a["irng"])
    if irid in a["rtyp"]:
        return a["rtyp"].index(irid) + 1
    a["rtyp"].append(irid)
    return len(a["rtyp"])


def _usage_id(a, var_id: int, range_id: int, default_id: int) -> int:
    key = (var_id, range_id, default_id)
    for i, u in enumerate(a["ucmp"]):
        if tuple(u) == key:
            return i + 1
    a["ucmp"].append(key)
    return len(a["ucmp"])


def add_asset_variable(a, asset: str, variable: str, rng: tuple[int, int], default: int = 0) -> dict[str, Any]:
    """Declare (or re-range) an int customization variable on an existing asset, e.g.
    add_asset_variable(a, "appearance/mesh/hum_f_body_l0.mgn", "/shared_owner/blend_glutes", (0, 256)).
    The asset's usage list is rewritten as a fresh ULST run so no other asset changes."""
    aid = asset_id(a, asset)
    if aid is None:
        raise KeyError(f"{asset} is not in the asset customization manager")
    uid = _usage_id(a, _variable_id(a, variable), _int_range_id(a, rng), _default_id(a, default))
    entry = _index_entry(a["uidx"], aid)
    old = a["ulst"][entry[1]:entry[1] + entry[2]] if entry else []
    keep = [u for u in old if a["ucmp"][u - 1][0] != a["ucmp"][uid - 1][0]]
    run = keep + [uid]
    if len(run) > 255:
        raise ValueError(f"{asset}: too many variables")
    start = len(a["ulst"])
    a["ulst"].extend(run)
    if entry:
        entry[1], entry[2] = start, len(run)
    else:
        a["uidx"].append([aid, start, len(run)])
    return describe_usage(a, uid)


# ----------------------------------------------------------------------------
# CIDM
# ----------------------------------------------------------------------------

def read_cidm(path_or_bytes) -> list[str]:
    """Variable names by id (index 0 = id 1)."""
    data = path_or_bytes if isinstance(path_or_bytes, bytes) else Path(path_or_bytes).read_bytes()
    d = parse_iff(data).first("CIDM").forms()[0].first("DATA").data
    out, pos = [], 0
    while pos < len(d):
        vid = struct.unpack_from("<h", d, pos)[0]
        end = d.index(b"\0", pos + 2)
        if vid != len(out) + 1:
            raise ValueError(f"CIDM ids not consecutive at {vid}")
        out.append(d[pos + 2:end].decode("latin1"))
        pos = end + 1
    return out


def write_cidm(names: list[str]) -> bytes:
    if len(names) > MAX_CUSTOMIZATION_ID:
        raise ValueError(f"{len(names)} customization ids exceed {MAX_CUSTOMIZATION_ID}")
    d = b"".join(struct.pack("<h", i + 1) + n.encode("latin1") + b"\0" for i, n in enumerate(names))
    return serialize_iff(_form("<root>", [_form("CIDM", [_form("0001", [_chunk("DATA", d)])])]))


def append_cidm_mif(mif_path: str | Path, names: list[str]) -> list[tuple[int, str]]:
    """Append variable names to a customization_id_manager.mif source (ids continue the existing ones; names
    already present are left alone). Keeps the file's line endings."""
    p = Path(mif_path)
    raw = p.read_bytes().decode("latin1")
    nl = "\r\n" if "\r\n" in raw else "\n"
    have = {n: int(i) for i, n in re.findall(r'int16\s+(\d+)\s+cstring\s+"([^"]+)"', raw)}
    nxt = max(have.values(), default=0) + 1
    added = []
    for n in names:
        if n not in have:
            added.append((nxt, n))
            have[n] = nxt
            nxt += 1
    if added:
        if nxt - 1 > MAX_CUSTOMIZATION_ID:
            raise ValueError(f"customization ids would exceed {MAX_CUSTOMIZATION_ID}")
        block = "".join(f"{nl}\t\t\tint16\t{i}{nl}\t\t\tcstring\t\"{n}\"{nl}" for i, n in added)
        last = raw.rindex("cstring")
        eol = raw.index(nl, last)
        raw = raw[:eol + len(nl)] + block[len(nl):] + raw[eol + len(nl):]
        p.write_bytes(raw.encode("latin1"))
    return added


# ----------------------------------------------------------------------------
# palettes
# ----------------------------------------------------------------------------

def read_pal(path_or_bytes) -> list[tuple[int, int, int, int]]:
    """RGBA entries of a RIFF PAL (.pal)."""
    b = path_or_bytes if isinstance(path_or_bytes, bytes) else Path(path_or_bytes).read_bytes()
    if b[:4] != b"RIFF" or b[8:12] != b"PAL ":
        raise ValueError("not a RIFF PAL")
    n = struct.unpack_from("<H", b, 22)[0]
    return [tuple(b[24 + i * 4:28 + i * 4]) for i in range(n)]


def write_pal(colors) -> bytes:
    body = struct.pack("<HH", 0x300, len(colors)) + b"".join(bytes(c[:3]) + bytes([c[3] if len(c) > 3 else 0]) for c in colors)
    data = b"data" + struct.pack("<I", len(body)) + body
    return b"RIFF" + struct.pack("<I", len(data) + 4) + b"PAL " + data


# ----------------------------------------------------------------------------
# string tables
# ----------------------------------------------------------------------------

def read_stf(path_or_bytes) -> dict[str, Any]:
    """String table (.stf): {"next_id", "flag", "entries": [(id, crc, name, text)]} in file order."""
    b = path_or_bytes if isinstance(path_or_bytes, bytes) else Path(path_or_bytes).read_bytes()
    magic, flag, next_id, n = struct.unpack_from("<IBII", b, 0)
    if magic != 0xABCD:
        raise ValueError("not a string table")
    pos, texts = 13, []
    for _ in range(n):
        sid, crc, ln = struct.unpack_from("<III", b, pos)
        pos += 12
        texts.append((sid, crc, b[pos:pos + ln * 2].decode("utf-16-le")))
        pos += ln * 2
    names, name_order = {}, []
    for _ in range(n):
        sid, ln = struct.unpack_from("<II", b, pos)
        pos += 8
        names[sid] = b[pos:pos + ln].decode("latin1")
        name_order.append(sid)
        pos += ln
    return {"flag": flag, "next_id": next_id, "entries": [(sid, crc, names[sid], t) for sid, crc, t in texts],
            "name_order": name_order}


def write_stf(stf: dict[str, Any]) -> bytes:
    e = stf["entries"]
    out = bytearray(struct.pack("<IBII", 0xABCD, stf.get("flag", 1), stf["next_id"], len(e)))
    for sid, crc, _, text in e:
        out += struct.pack("<III", sid, crc, len(text)) + text.encode("utf-16-le")
    by_id = {sid: name for sid, _, name, _ in e}
    order = [sid for sid in stf.get("name_order", []) if sid in by_id]
    order += [sid for sid in by_id if sid not in order]           # the name section has its own order
    for sid in order:
        out += struct.pack("<II", sid, len(by_id[sid])) + by_id[sid].encode("latin1")
    return bytes(out)


def stf_set(stf: dict[str, Any], name: str, text: str) -> None:
    for i, (sid, crc, n, _) in enumerate(stf["entries"]):
        if n == name:
            stf["entries"][i] = (sid, crc, n, text)
            return
    sid = stf["next_id"]
    stf["entries"].append((sid, 0xFFFFFFFF, name, text))
    stf["next_id"] = sid + 1
