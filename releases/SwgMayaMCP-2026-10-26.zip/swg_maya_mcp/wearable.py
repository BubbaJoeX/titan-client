"""Skinned wearables: pure-Python codec for skeletal mesh generators (.mgn, FORM SKMG 0004), mesh LOD lists
(.lmg, FORM MLOD) and skeletal appearance templates (.sat, FORM SMAT), plus the helpers the clothing pipeline
(examples/make_clothing.py) builds on.

read_mgn / write_mgn follow SkeletalMeshGeneratorTemplate::load_0004 field for field and write every stock .mgn
back byte-identical (tests: examples/make_clothing.py --roundtrip). Coordinates are engine space (Maya X = -engine X).

Wearable chain, as stock does it (measured on goggles_s01, hat_chef_s01, shirt_s03, pants_s01, shoes_s01,
cape_reb_s01):
  shared template appearanceFilename = appearance/<name>_f.sat
  datatables/appearance/appearance_table: shared_<name> -> appearance/<name>_m.sat (male human) / _f.sat ...
  <name>_m.sat (SMAT 0003: MSGN appearance/mesh/<name>_m.lmg, SKTI appearance/skeleton/all_b.skt)
  <name>_m.lmg (MLOD 0000: NAME appearance/mesh/<name>_m_l0.mgn ...)
  <name>_m_l0.mgn (SKMG 0004: SKTM all_b.skt, joints, weights, blend targets, occlusion zones, shaders)
"""

from __future__ import annotations

import struct
from pathlib import Path
from typing import Any

from .iff import Block, Reader, parse_iff, serialize_iff


def _chunk(tag: str, data: bytes) -> Block:
    return Block(tag, False, data)


def _form(tag: str, children: list[Block]) -> Block:
    return Block(tag, True, b"", children)


def _cstr(s: str) -> bytes:
    return s.encode("latin1") + b"\0"


def _strings(data: bytes) -> list[str]:
    return [s.decode("latin1") for s in data.split(b"\0")[:-1]]


# ----------------------------------------------------------------------------
# SKMG 0004
# ----------------------------------------------------------------------------

def _read_hardpoints(r: Reader) -> list[dict[str, Any]]:
    out = []
    for _ in range(r.i16()):
        name, parent = r.string(), r.string()
        rot = struct.unpack_from("<4f", r.data, r.pos)            # w, x, y, z
        r.pos += 16
        out.append({"name": name, "parent": parent, "rotation": rot, "position": r.vec()})
    return out


def _write_hardpoints(hps: list[dict[str, Any]]) -> bytes:
    b = bytearray(struct.pack("<h", len(hps)))
    for h in hps:
        b += _cstr(h["name"]) + _cstr(h["parent"]) + struct.pack("<4f", *h["rotation"]) + struct.pack("<3f", *h["position"])
    return bytes(b)


def _indexed_vectors(data: bytes, count: int) -> list[tuple[int, tuple[float, float, float]]]:
    return [(struct.unpack_from("<i", data, i * 16)[0], struct.unpack_from("<3f", data, i * 16 + 4)) for i in range(count)]


def _pack_indexed(items) -> bytes:
    return b"".join(struct.pack("<i3f", i, *v) for i, v in items)


def read_mgn(path_or_bytes: str | Path | bytes) -> dict[str, Any]:
    data = path_or_bytes if isinstance(path_or_bytes, bytes) else Path(path_or_bytes).read_bytes()
    skmg = parse_iff(data).first("SKMG")
    if skmg is None:
        raise ValueError("not a SKMG file")
    ver = skmg.forms()[0]
    if ver.tag != "0004":
        raise ValueError(f"SKMG version {ver.tag} not supported (0004 only)")
    m: dict[str, Any] = {"extra": {}}
    it = iter(ver.children)
    info = Reader(next(it).data)
    (m["max_transforms_per_vertex"], m["max_transforms_per_shader"], n_skt, n_xf, n_pos, n_twd, n_norm, n_psd,
     n_blt) = (info.i32() for _ in range(9))
    n_oz, n_ozc, n_zto, m["occlusion_layer"] = info.i16(), info.i16(), info.i16(), info.i16()
    rest = list(it)
    by = {}
    for c in rest:
        by.setdefault(c.tag, []).append(c)
    m["skeletons"] = _strings(by["SKTM"][0].data)
    if len(m["skeletons"]) != n_skt:
        m["_skeleton_count"] = n_skt                               # a few stock files: INFO count != names
    m["transforms"] = _strings(by["XFNM"][0].data)
    pos = by["POSN"][0].data
    m["positions"] = [struct.unpack_from("<3f", pos, i * 12) for i in range(n_pos)]
    counts = struct.unpack_from(f"<{n_pos}i", by["TWHD"][0].data)
    twdt = by["TWDT"][0].data
    weights, k = [], 0
    for c in counts:
        weights.append([struct.unpack_from("<if", twdt, (k + j) * 8) for j in range(c)])
        k += c
    assert k == n_twd
    m["weights"] = weights
    nd = by["NORM"][0].data if "NORM" in by else b""
    m["normals"] = [struct.unpack_from("<3f", nd, i * 12) for i in range(n_norm)]
    m["dot3"] = None
    if "DOT3" in by:
        d = by["DOT3"][0].data
        n = struct.unpack_from("<i", d)[0]
        m["dot3"] = [struct.unpack_from("<4f", d, 4 + i * 16) for i in range(n)]
    m["hardpoints"] = {"static": None, "dynamic": None}
    if "HPTS" in by:
        for c in by["HPTS"][0].children:
            m["hardpoints"]["static" if c.tag == "STAT" else "dynamic"] = _read_hardpoints(Reader(c.data))
    m["blend_targets"] = []
    if n_blt:
        for blt in by["BLTS"][0].forms("BLT "):
            bi = Reader(blt.first("INFO").data)
            npos_, nnorm_ = bi.i32(), bi.i32()
            t = {"name": bi.string(), "positions": [], "normals": [], "dot3": None, "hardpoints": None,
                 "_counts": (npos_, nnorm_)}
            for c in blt.children[1:]:
                if c.tag == "POSN":
                    t["positions"] = _indexed_vectors(c.data, len(c.data) // 16)
                elif c.tag == "NORM":
                    t["normals"] = _indexed_vectors(c.data, len(c.data) // 16)
                elif c.tag == "DOT3":
                    n = struct.unpack_from("<i", c.data)[0]
                    t["dot3"] = _indexed_vectors(c.data[4:], n)
                elif c.tag == "HPTS":
                    r = Reader(c.data)
                    hl = []
                    for _ in range(r.i16()):
                        idx = r.i16()
                        dp = r.vec()
                        dq = struct.unpack_from("<4f", r.data, r.pos)
                        r.pos += 16
                        hl.append((idx, dp, dq))
                    t["hardpoints"] = hl
            t["_present"] = [c.tag for c in blt.children[1:]]
            m["blend_targets"].append(t)
    m["occlusion_zones"] = _strings(by["OZN "][0].data) if "OZN " in by else []
    assert len(m["occlusion_zones"]) == n_oz
    m["fully_occluded"] = None
    if "FOZC" in by:
        d = by["FOZC"][0].data
        n = struct.unpack_from("<H", d)[0]
        m["fully_occluded"] = list(struct.unpack_from(f"<{n}h", d, 2))
    m["zone_combinations"] = []
    if n_ozc:
        r = Reader(by["OZC "][0].data)
        for _ in range(n_ozc):
            m["zone_combinations"].append([r.i16() for _ in range(r.i16())])
    m["zones_this_occludes"] = list(struct.unpack_from(f"<{n_zto}h", by["ZTO "][0].data)) if n_zto else []
    shaders = []
    for psdt in by.get("PSDT", []):
        s: dict[str, Any] = {"name": _strings(psdt.first("NAME").data)[0]}
        pidx = psdt.first("PIDX").data
        nv = struct.unpack_from("<i", pidx)[0]
        s["pidx"] = list(struct.unpack_from(f"<{nv}i", pidx, 4))
        s["nidx"] = list(struct.unpack_from(f"<{nv}i", psdt.first("NIDX").data)) if psdt.first("NIDX") else None
        s["dot3idx"] = list(struct.unpack_from(f"<{nv}i", psdt.first("DOT3").data)) if psdt.first("DOT3") else None
        s["colors"] = psdt.first("VDCL").data if psdt.first("VDCL") else None
        s["tc_dims"], s["tc_sets"] = [], []
        if psdt.first("TXCI"):
            d = psdt.first("TXCI").data
            n = struct.unpack_from("<i", d)[0]
            s["tc_dims"] = list(struct.unpack_from(f"<{n}i", d, 4))
            for dim, c in zip(s["tc_dims"], psdt.first("TCSF").chunks("TCSD")):
                s["tc_sets"].append(list(struct.unpack_from(f"<{nv * dim}f", c.data)))
        prims = []
        for c in psdt.first("PRIM").children[1:]:
            if c.tag == "ITL ":
                n = struct.unpack_from("<i", c.data)[0]
                f = struct.unpack_from(f"<{n * 3}i", c.data, 4)
                prims.append({"type": "ITL", "tris": [(-1,) + f[i:i + 3] for i in range(0, n * 3, 3)]})
            else:
                n = struct.unpack_from("<i", c.data)[0]
                tris = [struct.unpack_from("<h3i", c.data, 4 + i * 14) for i in range(n)]
                prims.append({"type": "OITL", "tris": tris})
        s["prims"] = prims
        shaders.append(s)
    m["shaders"] = shaders
    assert len(shaders) == n_psd
    m["extra"] = {c.tag: c for c in rest if c.tag in ("TRTS",)}
    m["_order"] = [c.tag for c in rest]
    return m


def write_mgn(m: dict[str, Any]) -> bytes:
    """SKMG 0004 bytes for a read_mgn-shaped dict. Optional keys may be omitted for new meshes."""
    weights = m["weights"]
    n_twd = sum(len(w) for w in weights)
    hps = m.get("hardpoints") or {}
    blts = m.get("blend_targets") or []
    zones = m.get("occlusion_zones") or []
    combos = m.get("zone_combinations") or []
    zto = m.get("zones_this_occludes") or []
    info = struct.pack("<9i", m.get("max_transforms_per_vertex", max((len(w) for w in weights), default=0)),
                       m.get("max_transforms_per_shader", len(m["transforms"])), m.get("_skeleton_count", len(m["skeletons"])),
                       len(m["transforms"]), len(m["positions"]), n_twd, len(m["normals"]), len(m["shaders"]), len(blts))
    info += struct.pack("<4h", len(zones), len(combos), len(zto), m.get("occlusion_layer", 0))
    kids = [_chunk("INFO", info),
            _chunk("SKTM", b"".join(_cstr(s) for s in m["skeletons"])),
            _chunk("XFNM", b"".join(_cstr(s) for s in m["transforms"])),
            _chunk("POSN", b"".join(struct.pack("<3f", *p) for p in m["positions"])),
            _chunk("TWHD", b"".join(struct.pack("<i", len(w)) for w in weights)),
            _chunk("TWDT", b"".join(struct.pack("<if", i, w) for vw in weights for i, w in vw)),
            _chunk("NORM", b"".join(struct.pack("<3f", *n) for n in m["normals"]))]
    if m.get("dot3") is not None:
        kids.append(_chunk("DOT3", struct.pack("<i", len(m["dot3"])) + b"".join(struct.pack("<4f", *d) for d in m["dot3"])))
    if hps.get("static") is not None or hps.get("dynamic") is not None:
        h = []
        if hps.get("static") is not None:
            h.append(_chunk("STAT", _write_hardpoints(hps["static"])))
        if hps.get("dynamic") is not None:
            h.append(_chunk("DYN ", _write_hardpoints(hps["dynamic"])))
        kids.append(_form("HPTS", h))
    if blts:
        forms = []
        for t in blts:
            present = t.get("_present") or ["POSN", "NORM"] + (["DOT3"] if t.get("dot3") is not None else []) + \
                (["HPTS"] if t.get("hardpoints") is not None else [])
            counts = t.get("_counts") or (len(t["positions"]), len(t["normals"]))
            bk = [_chunk("INFO", struct.pack("<2i", *counts) + _cstr(t["name"]))]
            for tag in present:
                if tag == "POSN":
                    bk.append(_chunk("POSN", _pack_indexed(t["positions"])))
                elif tag == "NORM":
                    bk.append(_chunk("NORM", _pack_indexed(t["normals"])))
                elif tag == "DOT3":
                    bk.append(_chunk("DOT3", struct.pack("<i", len(t["dot3"])) + _pack_indexed(t["dot3"])))
                elif tag == "HPTS":
                    bk.append(_chunk("HPTS", struct.pack("<h", len(t["hardpoints"])) + b"".join(
                        struct.pack("<h3f4f", i, *dp, *dq) for i, dp, dq in t["hardpoints"])))
            forms.append(_form("BLT ", bk))
        kids.append(_form("BLTS", forms))
    if zones:
        kids.append(_chunk("OZN ", b"".join(_cstr(z) for z in zones)))
    if m.get("fully_occluded") is not None:
        f = m["fully_occluded"]
        kids.append(_chunk("FOZC", struct.pack("<H", len(f)) + struct.pack(f"<{len(f)}h", *f)))
    if combos:
        kids.append(_chunk("OZC ", b"".join(struct.pack("<h", len(c)) + struct.pack(f"<{len(c)}h", *c) for c in combos)))
    if zto:
        kids.append(_chunk("ZTO ", struct.pack(f"<{len(zto)}h", *zto)))
    for s in m["shaders"]:
        nv = len(s["pidx"])
        sk = [_chunk("NAME", _cstr(s["name"])),
              _chunk("PIDX", struct.pack(f"<i{nv}i", nv, *s["pidx"]))]
        if s.get("nidx") is not None:
            sk.append(_chunk("NIDX", struct.pack(f"<{nv}i", *s["nidx"])))
        if s.get("dot3idx") is not None:
            sk.append(_chunk("DOT3", struct.pack(f"<{nv}i", *s["dot3idx"])))
        if s.get("colors") is not None:
            sk.append(_chunk("VDCL", s["colors"]))
        if s.get("tc_dims"):
            sk.append(_chunk("TXCI", struct.pack(f"<i{len(s['tc_dims'])}i", len(s["tc_dims"]), *s["tc_dims"])))
            sk.append(_form("TCSF", [_chunk("TCSD", struct.pack(f"<{len(t)}f", *t)) for t in s["tc_sets"]]))
        pk = [_chunk("INFO", struct.pack("<i", len(s["prims"])))]
        for p in s["prims"]:
            if p["type"] == "ITL":
                pk.append(_chunk("ITL ", struct.pack("<i", len(p["tris"])) +
                                 b"".join(struct.pack("<3i", *t[1:]) for t in p["tris"])))
            else:
                pk.append(_chunk("OITL", struct.pack("<i", len(p["tris"])) +
                                 b"".join(struct.pack("<h3i", *t) for t in p["tris"])))
        sk.append(_form("PRIM", pk))
        kids.append(_form("PSDT", sk))
    for b in (m.get("extra") or {}).values():
        kids.append(b)
    return serialize_iff(_form("SKMG", [_form("0004", kids)]))


# ----------------------------------------------------------------------------
# MLOD / SMAT
# ----------------------------------------------------------------------------

def write_lmg(mgns: list[str]) -> bytes:
    return serialize_iff(_form("MLOD", [_form("0000", [_chunk("INFO", struct.pack("<h", len(mgns)))] +
                                              [_chunk("NAME", _cstr(n)) for n in mgns])]))


def read_lmg(path_or_bytes) -> list[str]:
    data = path_or_bytes if isinstance(path_or_bytes, bytes) else Path(path_or_bytes).read_bytes()
    ver = parse_iff(data).first("MLOD").forms()[0]
    return [_strings(c.data)[0] for c in ver.chunks("NAME")]


def write_sat(mesh_generators: list[str], skeletons: list[tuple[str, str]], create_animation_controller: bool = False,
              animation_state_graph: str | None = None, lat: list[tuple[str, str]] | None = None) -> bytes:
    """SMAT 0003 like stock wearables: INFO (mesh generator count, skeleton count, create-controller flag),
    MSGN names, SKTI (skeleton path, attachment transform name) pairs, optional LATX/ASG.
    Creatures and vehicles need the controller and an LATX (skeleton -> logical animation table, vehicles use
    appearance/lat/monstrosity.lat): without one the skeleton is never evaluated and the mesh renders as garbage."""
    info = struct.pack("<iiB", len(mesh_generators), len(skeletons), 1 if create_animation_controller else 0)
    kids = [_chunk("INFO", info), _chunk("MSGN", b"".join(_cstr(n) for n in mesh_generators)),
            _chunk("SKTI", b"".join(_cstr(s) + _cstr(a) for s, a in skeletons))]
    if lat:
        kids.append(_chunk("LATX", struct.pack("<h", len(lat)) + b"".join(_cstr(s) + _cstr(t) for s, t in lat)))
    return serialize_iff(_form("SMAT", [_form("0003", kids)]))


def write_skt(joints: list[dict[str, Any]]) -> bytes:
    """Skeleton template (FORM SKTM 0002, one detail level) like stock vehicle skeletons
    (pv_speeder_bike.skt: root + joint2). joints: [{name, parent (index, -1 = root), pre, post, bind_rotation
    (quaternions w, x, y, z; default identity), bind_translation (engine space), rotation_order (0 = xyz)}]."""
    ident = (1.0, 0.0, 0.0, 0.0)
    q = lambda key: b"".join(struct.pack("<4f", *j.get(key, ident)) for j in joints)
    kids = [_chunk("INFO", struct.pack("<i", len(joints))),
            _chunk("NAME", b"".join(_cstr(j["name"]) for j in joints)),
            _chunk("PRNT", b"".join(struct.pack("<i", j.get("parent", -1)) for j in joints)),
            _chunk("RPRE", q("pre")), _chunk("RPST", q("post")),
            _chunk("BPTR", b"".join(struct.pack("<3f", *j.get("bind_translation", (0.0, 0.0, 0.0))) for j in joints)),
            _chunk("BPRO", q("bind_rotation")),
            _chunk("JROR", b"".join(struct.pack("<i", j.get("rotation_order", 0)) for j in joints))]
    return serialize_iff(_form("SKTM", [_form("0002", kids)]))


def read_sat(path_or_bytes) -> dict[str, Any]:
    data = path_or_bytes if isinstance(path_or_bytes, bytes) else Path(path_or_bytes).read_bytes()
    ver = parse_iff(data).first("SMAT").forms()[0]
    out: dict[str, Any] = {"version": ver.tag}
    for c in ver.children:
        if c.tag == "MSGN":
            out["mesh_generators"] = _strings(c.data)
        elif c.tag == "SKTI":
            s = _strings(c.data)
            out["skeletons"] = list(zip(s[0::2], s[1::2]))
        elif c.tag == "INFO":
            out["info"] = c.data
        else:
            out.setdefault("other", []).append(c.tag)
    return out


def skeleton_joints(path_or_bytes) -> list[str]:
    """Joint names of a skeleton template (.skt, FORM SLOD/SKTM), lowercased like mesh transform names."""
    data = path_or_bytes if isinstance(path_or_bytes, bytes) else Path(path_or_bytes).read_bytes()
    out = []
    stack = [parse_iff(data)]
    while stack:
        b = stack.pop()
        for c in b.children:
            if c.is_form:
                stack.append(c)
            elif c.tag == "NAME" and b.tag.isdigit():
                out += [n.lower() for n in _strings(c.data)]
    return out


# ----------------------------------------------------------------------------
# measuring
# ----------------------------------------------------------------------------

def mgn_summary(m: dict[str, Any]) -> dict[str, Any]:
    """What a stock wearable's .mgn binds to and how it occludes (the clothing pipeline matches these)."""
    ys = [p[1] for p in m["positions"]] or [0]
    used = sorted({m["transforms"][i] for vw in m["weights"] for i, _ in vw})
    zones = m["occlusion_zones"]
    return {
        "skeletons": m["skeletons"], "joints": used, "positions": len(m["positions"]),
        "max_weights": max((len(w) for w in m["weights"]), default=0),
        "y_range": (round(min(ys), 3), round(max(ys), 3)),
        "shaders": [s["name"] for s in m["shaders"]],
        "triangles": sum(len(p["tris"]) for s in m["shaders"] for p in s["prims"]),
        "prim_types": sorted({p["type"] for s in m["shaders"] for p in s["prims"]}),
        "blend_targets": [t["name"] for t in m["blend_targets"]],
        "occlusion_layer": m["occlusion_layer"], "zones": zones,
        "fully_occluded": [zones[i] for i in m["fully_occluded"]] if m["fully_occluded"] is not None else None,
        "zone_combinations": [[zones[i] for i in c] for c in m["zone_combinations"]],
        "zones_this_occludes": [zones[i] for i in m["zones_this_occludes"]],
        "hardpoints": {k: [h["name"] + "@" + h["parent"] for h in v] for k, v in m["hardpoints"].items() if v},
    }
