"""Reference evaluation of a skeleton posed by a keyframe animation, written from the engine's own code
(clientSkeletalAnimation Skeleton.cpp / KeyframeSkeletalAnimation.cpp) so Maya imports and exports can be checked
against what the game will show. Engine space, column vectors, Hamilton quaternions (w, x, y, z)."""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any

from .iff import Reader, parse_iff, read_kfat

Quat = tuple[float, float, float, float]
Vec = tuple[float, float, float]


def qmul(a: Quat, b: Quat) -> Quat:
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return (aw * bw - ax * bx - ay * by - az * bz, aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx, aw * bz + ax * by - ay * bx + az * bw)


def qrot(q: Quat, v: Vec) -> Vec:
    w, x, y, z = q
    p = qmul(qmul(q, (0.0, *v)), (w, -x, -y, -z))
    return p[1], p[2], p[3]


def slerp(a: Quat, b: Quat, t: float) -> Quat:
    d = sum(x * y for x, y in zip(a, b))
    if d < 0:
        b, d = tuple(-x for x in b), -d
    if 1.0 - d > 1e-6:
        th = math.acos(min(1.0, d))
        s = math.sin(th)
        c1, c2 = math.sin(th - t * th) / s, math.sin(t * th) / s
    else:
        c1, c2 = 1.0 - t, t
    q = tuple(c1 * x + c2 * y for x, y in zip(a, b))
    n = math.sqrt(sum(x * x for x in q))
    return tuple(x / n for x in q)


def read_skt(path: str | Path) -> list[dict[str, Any]]:
    """Single skeleton template (FORM SKTM 0001/0002): name, parent, pre/post/bind rotations, bind translation."""
    root = parse_iff(Path(path).read_bytes())

    def find(b):                        # SLOD wraps one SKTM per LOD: take the first (LOD 0)
        for c in b.children:
            if c.is_form and c.tag == "SKTM":
                return c
            if c.is_form:
                hit = find(c)
                if hit:
                    return hit
        return None
    sktm = find(root)
    ver = sktm.forms()[0]
    count = Reader(ver.first("INFO").data).i32()
    names_r = Reader(ver.first("NAME").data)
    names = [names_r.string() for _ in range(count)]
    prnt = Reader(ver.first("PRNT").data)
    parents = [prnt.i32() for _ in range(count)]

    def quats(tag):
        r = Reader(ver.first(tag).data)
        return [(r.f32(), r.f32(), r.f32(), r.f32()) for _ in range(count)]
    pre, post, bind_r = quats("RPRE"), quats("RPST"), quats("BPRO")
    t = Reader(ver.first("BPTR").data)
    bind_t = [t.vec() for _ in range(count)]
    return [{"name": names[i], "parent": parents[i], "pre": pre[i], "post": post[i], "bind_rot": bind_r[i],
             "bind_t": bind_t[i]} for i in range(count)]


def _sample_rotation(keys: list, frame: float) -> Quat:
    if frame <= keys[0][0]:
        return keys[0][1]
    for (f0, q0), (f1, q1) in zip(keys, keys[1:]):
        if f0 <= frame <= f1:
            return slerp(q0, q1, (frame - f0) / (f1 - f0) if f1 > f0 else 0.0)
    return keys[-1][1]


def _sample_float(keys: list, frame: float) -> float:
    if frame <= keys[0][0]:
        return keys[0][1]
    for (f0, v0), (f1, v1) in zip(keys, keys[1:]):
        if f0 <= frame <= f1:
            return v0 + (v1 - v0) * ((frame - f0) / (f1 - f0) if f1 > f0 else 0.0)
    return keys[-1][1]


def pose(skeleton: list[dict[str, Any]], animation: dict[str, Any] | None, frame: float) -> dict[str, Vec]:
    """Engine world (skeleton-space) position of every joint at `frame`."""
    anim = {k.lower(): v for k, v in ((animation or {}).get("joints") or {}).items()}
    world_rot: list[Quat] = []
    world_pos: list[Vec] = []
    out = {}
    for i, j in enumerate(skeleton):
        a = anim.get(j["name"].lower())
        delta = _sample_rotation(a["rotation"], frame) if a else (1.0, 0.0, 0.0, 0.0)
        dt = tuple(_sample_float(a["t" + ax], frame) for ax in "xyz") if a else (0.0, 0.0, 0.0)
        local_rot = qmul(j["post"], qmul(qmul(delta, j["bind_rot"]), j["pre"]))
        local_pos = tuple(b + d for b, d in zip(j["bind_t"], dt))
        p = j["parent"]
        if p < 0:
            wr, wp = local_rot, local_pos
        else:
            wr = qmul(world_rot[p], local_rot)
            off = qrot(world_rot[p], local_pos)
            wp = tuple(a_ + b_ for a_, b_ in zip(world_pos[p], off))
        world_rot.append(wr)
        world_pos.append(wp)
        out[j["name"]] = wp
    return out


def pose_from_files(skt: str | Path, kfat: str | Path, frame: float) -> dict[str, Vec]:
    return pose(read_skt(skt), read_kfat(kfat), frame)
