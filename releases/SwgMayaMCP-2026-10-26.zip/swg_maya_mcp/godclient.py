"""Drive the God Client (exe/win64_rel/SwgGodClient_r.exe) through its automation bridge (SwgGodClient GodClientBridge.cpp).

The editor listens on 127.0.0.1:<port> when SwgGodClient.cfg sets `[GodClient] bridgePort=<port>`, and writes
%LOCALAPPDATA%/SwgTitan/godclient_bridge.json ({port, token, pid}) at start-up; it deletes the file on exit. It never
touches the game client's devbridge.json. Same framing as the DevBridge (client.py): one JSON object per line each
way, every request carries the token, and the editor answers between frames. The god client signs in with the
credentials in user.cfg, so tools never launch it: the user starts it and these calls attach to it."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

from .client import ClientBridge, ClientBridgeError

GODCLIENT_DIR = Path(os.environ.get("TITAN_GODCLIENT_DIR", "D:/titan/exe/win64_rel"))
TOKEN_FILE = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "SwgTitan" / "godclient_bridge.json"


class GodClientBridge(ClientBridge):
    """One TCP connection to the running God Client; reconnects when the editor restarts with a new token."""

    def __init__(self) -> None:
        super().__init__(None)

    def _token_info(self) -> dict[str, Any]:
        if not TOKEN_FILE.exists():
            raise ClientBridgeError(f"{TOKEN_FILE} not found: is the God Client running with [GodClient] bridgePort set "
                                    f"in {GODCLIENT_DIR / 'SwgGodClient.cfg'}?")
        try:
            return json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
        except ValueError:
            raise ClientBridgeError(f"{TOKEN_FILE} is not readable JSON (being written?)") from None

    def call(self, cmd: str, timeout: float = 20.0, **fields: Any) -> Any:
        """Send one command and return its result; a refused command raises with the editor's reason."""
        reply = self.request(cmd, timeout=timeout, **fields)
        if not reply.get("ok"):
            raise ClientBridgeError(str(reply.get("error") or reply.get("result") or f"{cmd} failed"))
        return reply.get("result")

    def screenshot(self, path: str) -> Path:
        """Back-buffer screenshot; `path` is relative to the editor's folder, the engine adds the extension.
        Returns the written file once it is complete."""
        reply = self.call("screenshot", path=path)
        if not reply.get("ok"):
            raise ClientBridgeError(f"screenshot failed: {reply.get('error', '')}")
        file = Path(reply["file"])
        deadline = time.time() + 10.0
        while time.time() < deadline and not (file.exists() and file.stat().st_size > 0):
            time.sleep(0.1)
        if not file.exists():
            raise ClientBridgeError(f"the editor reported {file} but it was not written")
        time.sleep(0.2)                      # let the writer finish
        return file
