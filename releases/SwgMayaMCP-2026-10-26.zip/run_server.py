"""Launcher that works from any working directory (MCP clients often start servers elsewhere)."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from swg_maya_mcp.server import main  # noqa: E402

main()
