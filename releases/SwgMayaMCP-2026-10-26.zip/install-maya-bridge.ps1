# Make interactive Maya 2027 start the SwgMayaMCP bridge (127.0.0.1:7020) on launch.
#
# Adds a guarded block to Documents\maya\2027\scripts\userSetup.py that puts this repo's maya\ folder on
# sys.path and starts swg_mcp.bridge after the UI is up. Re-running is safe; -Uninstall removes the block.
# Without this, the MCP server still works: it falls back to a private headless mayapy.
param(
    [switch] $Uninstall,
    [string] $MayaScriptsDir = (Join-Path $env:USERPROFILE "Documents\maya\2027\scripts")
)

$ErrorActionPreference = "Stop"
$pkgDir = (Join-Path $PSScriptRoot "maya") -replace '\\', '/'
$userSetup = Join-Path $MayaScriptsDir "userSetup.py"
$begin = "# >>> SwgMayaMCP bridge >>>"
$end = "# <<< SwgMayaMCP bridge <<<"
$block = @"
$begin
def _swg_mcp_bridge_start():
    import sys
    p = r"$pkgDir"
    if p not in sys.path:
        sys.path.insert(0, p)
    try:
        import swg_mcp.bridge
        swg_mcp.bridge.start()
    except Exception as exc:  # never break Maya startup
        print("// SwgMayaMCP bridge not started: %s" % exc)

import maya.utils
maya.utils.executeDeferred(_swg_mcp_bridge_start)
$end
"@

New-Item -ItemType Directory -Force -Path $MayaScriptsDir | Out-Null
$existing = if (Test-Path $userSetup) { Get-Content -Raw $userSetup } else { "" }
$pattern = "(?s)\r?\n?" + [regex]::Escape($begin) + ".*?" + [regex]::Escape($end) + "\r?\n?"
$stripped = [regex]::Replace($existing, $pattern, "`n").TrimEnd()

if ($Uninstall) {
    [IO.File]::WriteAllText($userSetup, $(if ($stripped) { $stripped + "`n" } else { "" }))
    Write-Host "Removed SwgMayaMCP bridge from $userSetup"
    return
}

$content = if ($stripped) { $stripped + "`n`n" + $block + "`n" } else { $block + "`n" }
[IO.File]::WriteAllText($userSetup, $content)  # UTF-8 without BOM
Write-Host "Installed SwgMayaMCP bridge autostart in $userSetup (restart Maya)."
