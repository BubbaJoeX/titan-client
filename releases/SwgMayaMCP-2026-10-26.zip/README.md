# SwgMayaMCP

MCP server that drives **Autodesk Maya 2027** with the **SwgMayaEditor** plug-in (`client/src/engine/client/application/MayaModern`) for Titan / SWG assets — with first-class tools for building **POB** structures (portal objects).

It talks to Maya through a small bridge (`maya/swg_mcp/bridge.py`) over line-delimited JSON on `127.0.0.1`:

| Mode | When | How |
|------|------|-----|
| **gui** | You have Maya open and want to watch/edit live | Bridge runs inside Maya on port **7020** (see *Interactive Maya*) |
| **headless** | No Maya open (CI, batch, quick checks) | Server starts a private `mayapy` on port **7021** on first use and stops it on exit |
| **auto** (default) | — | gui if port 7020 answers, otherwise headless |

Unlike the older `support/MCP/MayaMCP` (MEL `commandPort` + string-pasted Python), requests carry arguments as JSON (no quoting/injection issues), results come back as JSON with Maya's traceback **and the plug-in's own `std::cerr` output** (headless), and each request runs on Maya's main thread.

## Setup

```powershell
cd D:\titan\support\MCP\SwgMayaMCP
python -m venv .venv            # Python 3.10+
.venv\Scripts\pip install -r requirements.txt
```

Register it with your MCP client. Claude Code (project scope) — `D:\titan\.mcp.json`:

```json
{
  "mcpServers": {
    "swg-maya": {
      "command": "D:/titan/support/MCP/SwgMayaMCP/.venv/Scripts/python.exe",
      "args": ["D:/titan/support/MCP/SwgMayaMCP/run_server.py"]
    }
  }
}
```

The same block works in Claude Desktop's `claude_desktop_config.json`.

### Interactive Maya (optional)

```powershell
.\install-maya-bridge.ps1          # adds a guarded block to Documents\maya\2027\scripts\userSetup.py
.\install-maya-bridge.ps1 -Uninstall
```

Or start it once from Maya's Script Editor (Python):

```python
import sys; sys.path.insert(0, r"D:/titan/support/MCP/SwgMayaMCP/maya")
import swg_mcp.bridge; swg_mcp.bridge.start()
```

### Environment

| Variable | Default | Purpose |
|----------|---------|---------|
| `SWG_MAYA_MCP_MODE` | `auto` | `auto` / `gui` / `headless` |
| `SWG_MAYA_MCP_PORT` | `7020` | interactive bridge port |
| `SWG_MAYA_MCP_HEADLESS_PORT` | `7021` | private mayapy port |
| `SWG_MAYAPY` | `C:\Program Files\Autodesk\Maya2027\bin\mayapy.exe` | headless interpreter |
| `SWG_MAYA_ENV` | `Documents\maya\2027\Maya.env` | read for headless runs (`TITAN_DATA_ROOT`, `MAYA_PLUG_IN_PATH`, …) |
| `TITAN_EXPORT_ROOT` | `D:/exported` | default export root for POB tools |

Headless output is logged to `%TEMP%\swg_maya_mcp_headless.log`. The plug-in is loaded from `MAYA_PLUG_IN_PATH` (Maya.env), i.e. whatever `MayaModern\scripts\Deploy-ToMayaPlugIns.ps1` last deployed.

## Tools

**Maya** — `maya_status`, `maya_connect`, `maya_python` (escape hatch: assign `result`), `maya_mel`, `maya_scene` (new/open/save/save_as/info), `maya_ls`, `maya_node` (incl. SWG custom attributes), `maya_set_attr`, `maya_render` (Maya Software; perspective or roof-sliced top-down cutaway — works headless), `maya_viewport_capture` (gui only).

**SWG assets** — `swg_setup` (load plug-in, `setBaseDir`), `swg_import` (any SwgMayaEditor translator by extension), `swg_export_static_mesh`, `swg_export_floor` (compiled `.flr`), `swg_inspect_floor` (no Maya).

**POB** — `pob_build` (whole building from a room spec), `pob_export_structure` (msh + flr + pob, then re-verified from disk), `pob_create_template`, `pob_connect_cells`, `pob_set_cell`, `pob_validate`, `pob_inspect` (no Maya), `pob_floorplan` (SVG plan from the exported files, no Maya).

**Rails** — `swg_rails` (the conventions content must follow, each with the engine behaviour behind it and the tool that enforces it; also summarised in the server instructions), `swg_check` (verifies an exported `.pob`/`.ans`/`.flr`/`.sat`/`.mgn` against them, no Maya; `pob_export_structure` and `swg_export_animation` run it automatically), `swg_export_animation` (playback range, 30 fps, CKAT). Rules live in `swg_maya_mcp/rails.py`; add new lessons there, with a check where a file can show them.

**Buildings** — `swg_building_template` (spawnable SBOT + terrain flatten `.lay` + `.sfp` footprint), `pob_interior_for_stock` (interior for a stock exterior-only building such as a city filler: the stock mesh stays r0, the entrance is cut at the painted door, rooms by category — tower / house / slum / block / historic — and the stock template is overridden at its own path; `examples/make_fillers.py` runs it over every filler with review renders).

Plans follow the stock interiors: a foyer, a hallway with rooms off it (curved apse ends, rounded corners, half-round hall ends), minimum sizes measured over the stock cells (rooms 3.5 m / 16 m², halls 2.0–3.0 m), 0.3 m partition walls with lined openings, hall materials taken from each planet's stock hallway cells. Entrance and window openings are cut into the stock mesh in place (`polyCut`, no T-junction cracks; original materials and UVs kept). Every cell mesh gets its cell lights baked into vertex colour (color0) on export, because the stock interior shaders are prelit (`c_` effects) and render black without it.

**Worldbuilding kit**: `maya/swg_mcp/kit.py` (`examples/make_kit.py [theme ...]`) builds modular static pieces for `object/static/structure/<theme>`. Themes are Corellia, Naboo, Tatooine, Dantooine, Dathomir, Endor, Lok, Rori, Talus and Yavin, each in its own stock exterior materials and architecture. The pieces are `wall_4x8`, `wall_4x16`, `column`, `gate_sm`, `arch_sm`, `wall_curve` (90°, 8 m radius) and `wall_low_1x8`. Names follow the stock kits (`<prefix>_imprv_<piece>_sNN`, suffixes after the stock ones), and templates derive from `corl_imprv_wall_4x16_s01`. Collision lives in each piece's `.lod`, like stock: a box, or a composite of post boxes that leaves gate and arch passages open. Review renders land in `%TEMP%/swg_kit`.

The kit now has 37 pieces in every theme (370 in all, each with a `.lod` and template; `kit.json` in `%TEMP%/swg_kit` lists them). Beyond walls and gates it covers every stock structure type: pillars, fences, beams, a pergola, a gazebo, planters, fountains, braziers, platforms, stairs, bridges and walkways. The new pieces snap to the existing ones:

- **Stairs:** `stair_medium` (4 m wide, 3 m rise, which is the walkway deck height) and `stair_large` (6 m wide, 4 m rise). `stair_small` tops out at 2 m.
- **Landing:** `landing_4x4`, a platform 2 m up (the top of `stair_small`), railed on two sides.
- **Walkway network** (3 m wide on a 3 m deck, like `walkway_elevated`, whose ends sit at x = ±4):
  - nodes: `walkway_corner`, `walkway_t`, `walkway_cross` and `walkway_end`, each a 3 m square with railings on its closed sides;
  - `walkway_ramp`: from the deck down to the ground over 10 m;
  - `walkway_stair`: a 3 m flight up to the deck.
- **Caps:** `wall_end_cap` (finishes a wall run), `wall_coping_8` (a coping course that sits on an 8 m wall) and `column_cap` (a finial for the column top).

Everything held up off the ground has a bottom face, so looking up from below never sees through: boxes and prisms that start above the ground, and ramp rails. Static structures can't take player hue; see the hueable furniture variants.

**Corellia bridge junctions** — `maya/swg_mcp/corl_bridge.py` (`examples/make_corl_bridges.py`) adds junctions for the stock Corellia bridges (`corl_imprv_bridge_sm/lg/insert_s01/s02`).

The stock bridges were measured: 7.5 m over the parapets, a walk floor 5.5 m wide at y 0 at the ends, and a bulging marble or concrete parapet beam up to y 1.0 with a pipe rail. A bridge's floor ends are crossable, so a junction whose floor arms end exactly where a bridge's floor begins hands the player over.

The pieces are `object/static/structure/corellia/shared_corl_imprv_bridge_<piece>_<style>.iff`:

- `4way`: a plus-shaped deck with rounded corner pylons in the beam profile, the rail wrapping each corner.
- `3way`: a T, with the −z side closed by a parapet.
- `corner`: an L, with −z and −x closed.
- `4way_lit`: a lamp post on each pylon, with a light and the stock blue streetlamp glow from a client data file.

Each comes in style `s01` (marble, dark lit strips) and `s02` (concrete, metal strips). Pylon and parapet feet are wall-base floor edges and only the arm ends are crossable. Collision is a composite of boxes.

To place one, put the junction down, then stock bridges with their ends on its open edges: for `bridge_sm`, centre the bridge 3.75 + 8.12 m out.

**Otoh Gunga set** — `maya/swg_mcp/otoh_gunga.py` (`examples/make_otoh_gunga.py [hub] [pieces]`) builds the Gungan bubble city of Naboo as a modular set. It has clusters of glowing see-through bubbles with warm amber light inside, bronze ribs in a pointed-arch lattice, small bubbles on stalks, hanging pods and blue-lit lower spheres. Underwater rendering is not supported, so the set stands on land: by a lake, each bubble is cut off at the ground or sits on its stalk.

- **Hub** — `object/building/titan/shared_nboo_otoh_hub.iff`, a POB with 7 cells. A round hall (r 9 m) has a 7 m glow dome, and a foyer opens to the south with a stock Naboo door. Tubes run east and west to two domed pods.
  - pob_build makes the cells, portals, floors, cell lights and collision. `hub_interior` then dresses the inside:
    - glow-shader dome faces;
    - interior ribs with glow nodes;
    - a lantern column standing on a floor hole;
    - hanging glow pods.
  - `hub_exterior` adds the outer bubble skins on r0 (hub and pods). They have arched openings where the foyer and tubes pass through. It also adds:
    - rib lattices;
    - collars around the openings;
    - an entrance arch;
    - the effect hardpoints.
  - pob_build's exterior domes stay under the skins as a thin glow veil (lit windows and floor bands), which gives the lit-from-inside depth.
  - Inside, the walls are lit amber glass panes in bronze mullions (`wall_in`). The hall and pod floors are a radial amber-and-bronze inlay (`floor_mosaic`): its rosette sits on the texture's tile corner, and each room's floor tile size divides the room centre's x, so planar floor UVs centre a rosette in every room.
- **Pieces** — `object/static/structure/naboo/shared_nboo_otoh_<piece>_s01.iff`:
  - `pod_sm` (a bubble on a stalk), `pod_md` (a ground bubble), `pod_hanging` (a gooseneck with a pod);
  - `sphere_blue` (a blue-lit cluster), `tube` (a walkable glass connector, 8 m, with its own floor), `stalk` (a 12 m lamp stalk);
  - `rib_arch` and `rib_lattice` (the frames on their own);
  - `dome_lg` (a 15.7 m dome: clear skin over a lit mosaic gallery on a bronze column, with bubbles floating inside), `bubble_cluster` (six small lit bubbles on curved stalks of different heights, from one root).
  - Each piece is a `.lod` with collision boxes, a radar footprint and the mesh's hardpoints, and three detail levels: full up to 45 m, about 45 % of the faces to 100 m, and about 20 % beyond (`_export_lods`: `polyReduce` keeping UV and open borders). `iff.write_static_lod(lods=[...])` writes them lowest detail first with (index, near, far) rows, like stock `nboo_decd_cambylictustree.lod`.
  - Flat stone and mosaic tops are planar-mapped discs (`disc`); lathe UVs smeared them into radial streaks.
- **Materials** — `examples/otoh_materials.py` generates the textures (tileable noise and cell patterns, pure Python). It writes `shader/nboo_otoh_*.sht` with `iff.write_shader`. The shader files use the stock layout and are byte-identical to a stock `.sht` when given the same inputs.
  - Bubble skins (mostly clear, bright caustic veins), the veil under them and the interior domes are `a_alpha_emis_full`: see-through and drawn full-bright, so they glow at night and by day.
  - Cores, the blue spheres and the interior glass walls are `a_emis_full`.
  - Ribs and the floor mosaic are `a_simple` with specular.
  - Plinths, pads and the foyer and tube floors use stock `gungan_brick01_asb13`.
  - All of these are `a_` effects, lit normally, so no `color0` is needed.
- **Effects** — `iff.write_client_data` writes `clientdata/client_shared_nboo_otoh_*.cdf`:
  - `HLOB`: an amber or blue light on a hardpoint, carrying a stock glow sprite (`pt_light_streetlamp_gold`, `pt_light_sm_lamp_gold`, `pt_light_streetlamp_blue`);
  - `HOBJ`: stock particles on a hardpoint (`pt_bubble_trail` rising from the hub spire, `pt_flocking_glowzees` over the hub).
  - Templates point `clientDataFile` at them. `iff.write_static_lod` now carries the mesh's hardpoints into the `.lod`, where client data files look for them.

Checked:
- `swg_check` passes on the hub `.pob` (no issues) and on the tube floor.
- All 9 templates spawn in the x64 Debug client.
- A walk from the shore goes world → foyer → hall → tube_east → pod_east → hall → tube_west → pod_west, with the right cell each step. The only block is the lantern's floor hole.
- Screenshots show the glowing bubbles at dusk and night on a Naboo lake shore (Naboo ~(790, 1060)).

- **Sealed glass** — the stone pad round the domes (terrain base, margin 0.6 m) lies inside the skins. The skin openings over the foyer and tubes (elliptic arches 5 m wide) cover the pad strips that run out beside them, so walking along the pad never crosses glass.
  - `seal_pad` re-types the r0 floor after export with `iff.set_floor_edge_types`: every open rim edge becomes uncrossable except the entrance front (porch edge and ramp, z > 13.1). The helper rewrites TRIS and BEDG; with an identity rule it writes the file back byte-identical.
  - A coarse band of each skin (ground to 4.2 m, same openings) is built into r0's collision extent (`bubble_skin_collision`). Uncrossable edges only stop players on the floor: someone on the terrain steps up onto a floor from below without crossing an edge.
  - Mesh extents never block a moving player: `CollisionDetect::testExtents` only tests simple, component and detail extents; a CMSH (cell or `.lod`) serves the camera and line of sight. In the client, neither an r0 CMSH band nor one copied into the `.lod` stopped terrain walkers.
  - So `glass_collision` gives the r0 `.lod` a composite of 0.9 m boxes every metre along each skin's foot, outside the pad rim, skipping the openings, plus fences along the pad strips that run out through them (`iff.set_lod_collision_boxes`, the same form as the kit's gate collision). Players on the terrain can then only step onto the pad from the porch in front of the door.

Known gaps:
- The box fence has not been walked in the client yet: the client closed before the retest. A box of the same kind on the stalk piece does stop the walker, and the rim seal has been walked: going out from the pad ring was blocked, and the entrance still goes in and out.
- Whether the particle glows and bubbles show was not confirmed in screenshots.
- The script runs Maya through its own MCP server, so close any other headless Maya first.

Review renders and the hub `.mb` checkpoints land in `%TEMP%/swg_otoh`.

**Clothing (skinned wearables)**: `swg_maya_mcp/wearable.py` reads and writes skeletal mesh generators (`.mgn`, FORM SKMG 0004), mesh LOD lists (`.lmg`) and skeletal appearance templates (`.sat`). `examples/make_clothing.py` builds a test set of six wearables on the shared humanoid skeleton `all_b.skt`, for human male and female, and compiles their templates. `--local-table` compiles only `appearance_table` in Python (the same bytes as DataTableTool) and deploys it, for when the server is busy. Sync the server copy afterwards.

`read_mgn` / `write_mgn` follow `SkeletalMeshGeneratorTemplate::load_0004` field for field. 27,318 of the 28,525 stock `.mgn` files write back byte-identical. Of the rest, 1,195 are the older SKMG 0003, 4 differ and 8 are malformed or not SKMG. `--roundtrip` reruns that check. Don't use the plug-in's `.mgn` translator to write wearables: it leaves out SKTM and miscounts INFO, so the client can't load its files. Maya imports the results fine (`importSat`), which is how the review renders are made.

The pieces were measured against stock first (`--measure`):

| Piece | Stock reference | Layer | Zones (occluded / hidden on the body) | Blend targets | Built from |
|---|---|---|---|---|---|
| `titan_hat_s01` | `hat_chef_s01` | 2 | skull / skull | head blends touching the skull | head skull zone pushed out, crown raised, flat brim and band at the hairline; head joint only |
| `titan_goggles_s01` | `goggles_s01` | 1 | face / none | none | procedural cups sealed to the face, domed alpha lenses, bridge, strap round the head; head joint only |
| `titan_shirt_s01` | `shirt_s03` | 1 | chest, torso_f/b, arms, forearms / same | muscle, fat, skinny (+ flat_chest on the female) | body zones pushed out 11 mm |
| `titan_pants_s01` | `pants_s01` | 1 | waist_f/b, thighs, shins / same | muscle, fat, skinny | body zones pushed out 9 mm |
| `titan_shoes_s01` | `shoes_s01` | 2 | feet / same | none | foot zones pushed out 12 mm with a flattened sole |
| `titan_cape_s01` | `cape_reb_s01` | 3 | none (plain ITL, like stock) | muscle, fat, skinny | procedural cloth over the back, double-sided with a lining |

How the pieces are built:

- **Following the skin.** Body-hugging pieces copy the stock `hum_m` / `hum_f` body and head meshes. They take the triangles of their occlusion zones, pushed out along the averaged body normal, with the stock weights, normals and blend deltas vertex for vertex. They deform exactly like the skin under them and follow body-shape sliders.
  - Every open border gets a hem: a lip from the offset surface back into the skin, in the piece's trim shader, so no gap shows at cuffs, waist or ankles.
  - Each LOD of a piece is derived from the matching body LOD (l0 to l3).
  - Head vertices weighted to face-skeleton joints (brows) are moved onto `head`, because a wearable is bound to `all_b` alone.
- **Cape.** It hangs from a fold over the shoulders down the back to about 0.6 m, clear of the back and buttocks, and falls straight past the lumbar hollow.
  - The top rows take the nearest torso vertex's weights (spine, clavicles), so it follows the back and shoulders.
  - Below the hips it blends to root 0.2 plus the thighs (0.6 on the same side, 0.2 on the other), so the hem swings with the stride without the legs poking through.
- **Species heads.** Lenses go where the stock goggles have theirs, since most species heads have no eye joints (mon calamari eyes sit at the sides). The goggles scale to the stock lens size.
  - Hat brim: at the forehead hairline, at least 3 cm above the eyes. It is lifted in smooth ramps over anything under it, such as bothan and trandoshan brows. Its radius covers 5 cm below the brim plane too (the sullustan skull bulges there).
  - Skull-zone protrusions are pulled onto the cranium under the crown (rodian ears). Twi'lek lekku are not: they get wrapped, as stock twilek hats do.
- **Remastered race bodies.** `Source` also takes blend targets that the `D:/exported` copy of a body `.mgn` has beyond stock (`make_races.py`: `blend_chest_large`, `blend_glutes`, `blend_bulge`), when the vertex count matches. The shirt, pants and cape follow those sliders.
- **Materials.** Hue shaders as stock: CSHD with `effect\h_simple.eft` and `/private/index_color_1` on the main fabric (`index_color_2` on the trim, band and lining), using the `wr_cloth_general`, `wr_leather` and `wr_metal` palettes. The textures are generated light-grey weave, twill and leather patterns. The goggle lenses are a plain `a_alpha` shader. None of the six stock types has hardpoints, so these have none.
- **Appearance chain.** The shared template's `appearanceFilename` is `appearance/<name>_f.sat`, as in stock. `datatables/appearance/appearance_table` maps `shared_<name>` per species and gender:
  - human male and female: `_m.sat` / `_f.sat`;
  - species meshes where stock has them (`<name>_<sp>_m/f.sat`, built from that species' head or body):
    - hat: rodian, moncal, wookiee, twilek, trandoshan, bothan, sullustan;
    - goggles: rodian, moncal, wookiee, trandoshan, bothan, sullustan, ithorian (on `ithorian.skt`);
    - cape: wookiee, ithorian;
  - the other `all_b` species: `:default`, the human mesh;
  - shirt and pants on wookiee and ithorian, and the hat on ithorian: `:block`, as in stock;
  - shoes: `:hide` on trandoshan and wookiee, like stock shoes.
- **Templates.** The shared `.tpf` derives from `object/tangible/wearables/base/shared_base_<hat|eyes|shirt|pants|shoes|cape>.iff`, which sets the arrangement (slot). The server `.tpf` derives from `wearables_base.iff`. They compile with `titan.sh sync`, along with the `.tab` (DataTableTool), then `titan.sh crc`.
  - `deploy_client` copies the compiled shared templates and `appearance_table.iff` into `D:/exported`. The development client loads templates from there; it would not create them from its `sys.shared` copy.
  - Restart the client after the table changes: it reads the table at start-up.

Checked:

- `swg_check` on all 40 clothing `.sat` files passes (12 human + 28 species). It follows the `.sat` -> `.lmg` -> 4 `.mgn` chain and checks that each SKMG reads back byte-identical, every transform is an `all_b` joint, weights sum to 1 with at most 4 per vertex, and indices, zone combinations and shaders are valid. A stock `shirt_s03_m.sat` passes the same check.
- Maya renders on `importSat` with the stock walk (`all_b_loc_walk_male` / `_female`) show no stretching. The cape clears the legs at the stride extremes.
- In the x64 Debug client, `/scene equip object/tangible/wearables/<dir>/shared_titan_<piece>_s01.iff` dresses the player. This worked for:
  - human male: front, back and side, idle, real locomotion and the walk clip in place;
  - human female: idle and walk;
  - zabrak male (`:default`);
  - hat and goggles (and the full set where the species can wear it) on rodian, moncal, wookiee, ithorian, twilek, bothan, trandoshan and sullustan;
  - the race body sliders, through `/devtest custom set /shared_owner/blend_chest_large|blend_glutes|blend_bulge 255`, reshape the shirt, pants and cape with no skin showing through.
  - Offline `/scene equip` ignores `:block`/`:hide` and draws the human mesh, so test only the pieces a species can wear.
  - The client log confirmed the appearance swap (`appearance/titan_goggles_s01_m.sat` on the male).
  - Use `/scene load simple <avatar>` to switch species/gender: `human_male`, `human_female`, `zabrak_male`... In this client `/scene load tatooine` stayed black.
  - `/scene playAnimation all_b_loc_walk_male.ans 1` loops a walk in place. The bridge serves one connection at a time, so a `walk` request is cut short by any other request.

Known gaps:
- The shirt, pants and shoes have human meshes only, as stock does (`:default` / `:block` / `:hide`).
- The object names (`wearables_name:titan_*`) have no string table entries.

**Lifeday pajamas**: `examples/make_pajamas.py` builds a two-piece Lifeday pajama set for every playable species and gender, on the clothing pipeline above (`make_clothing.Source` / `Mesh` / `derive`):

| Piece | Slot (stock base) | Layer | Zones (occluded / hidden on the body) |
|---|---|---|---|
| `titan_lifeday_pj_top_s01` | shirt (`shared_base_shirt`) | 1 | chest, torso_f/b, arms, forearms / same |
| `titan_lifeday_pj_bottoms_s01` | pants (`shared_base_pants`) | 1 | waist_f/b, thighs, shins / same |

- **Species.** The set follows the stock Lifeday wearables (`jacket_lifeday_09`). Each piece has its own meshes for human `_m`/`_f`, wookiee `_wke_m`/`_wke_f` and ithorian `_ith_m`/`_ith_f`, derived from the stock `hum_*`, `wke_*` and `ith_*` body meshes. All of them are on `all_b.skt` except the ithorians, which are on `ithorian.skt`. The other species use the human mesh through `:default`, so every `appearance_table` column is filled and none is `:block`.
  - The wookiee bodies' fur-fringe shader (`wke_alpha_*`) is left out, so only the skin surface is copied.
  - Their multi-zone triangle combinations (`waist_f`+`waist_b`) count as the first zone.
- **Layers on one skin.** Each mesh has four shaders over the same skinned surface, all with the body's weights and blend deltas:
  - fabric: CSHD `h_simple` with `/private/index_color_1` (`wr_cloth_general`; default deep green top, red plaid bottoms);
  - hems: `index_color_2`, cream;
  - lights: bulbs 4 mm out;
  - logo: 3 mm out, top only;
  - button placket: 2.5 mm out, down the front of the top.
  - The hue therefore changes the fabric and hems and never the lights or logo.
- **Glowing, fading lights.** The bulbs are geometry. `bulbs()` places them by Poisson-disk sampling over the fabric triangles, 8.5 cm apart (wider on lower LODs: 68 on a human top at l0, about 16 at l3), and keeps them clear of the logo and placket. Each bulb is a 6 cm square on the face normal, skinned rigidly to its point (the barycentric blend of the triangle's weights and blend deltas) and tagged with that triangle's occlusion zone. It maps one whole red or green cell of the bulb tile, so no texture seam can cut a bulb (the first version box-projected the tile over the fabric and halved bulbs where the projection axis changed). The shader is a FORM `SWTS` switch-texture shader, the same layout as the stock animated screens (`anim_console_screen_aef11.sht`): a base shader `titan_lifeday_pj_lights_base.sht` (`a_alpha_emis_full_bloom`, not hued), a `DTST` switcher (12 states, 0.11 s each) and one `TEXT` per frame. Red and green bulbs fade in opposite phase on a cosine, with a halo that grows as they brighten. `write_switch_texture_shader` writes the format.
- **Logo.** `evolve-logo.png` (`PAJAMA_LOGO`) is padded onto a 1024×256 alpha texture. It is planar-mapped on the chest and, larger, across the back of the top, with clamp addressing (TXM DATA address mode 2) so it doesn't repeat. It uses lit `a_alpha` with specular for the chrome.
- **Button placket.** Below the chest logo, a cream band with stitched edges and pearl buttons runs from under the logo down to the hem, a 5.6 cm tile (about 4.3 cm of band) with one button every 7.5 cm. It is a 64×128 tile, clamped across and wrapped down, in lit `a_alpha`, and is not hued.
- **Textures.** From Poly Haven (CC0): `cotton_jersey` (colormass / Rico Cilliers) for the top and the `fabric_pattern_05` plaid (Rob Tuytel) for the bottoms. These are the 1k diffuse maps, turned to greyscale at a set brightness so the palette tints them. Download them into `POLYHAVEN_DIR/dl_<asset>/`. The script uses Pillow, so run it with a Python that has it.
- **Templates and table.** The `.tpf` files are written and compiled the same way as the clothing set. The shared ones declare `paletteColorCustomizationVariables` `/private/index_color_1` (fabric) and `/private/index_color_2` (hems) on `wr_cloth_general`, which makes the pieces hueable. The `appearance_table` rows sit next to the clothing rows; the first run backs up the table to `.tab.pre-pajamas`. `deploy_client` copies the compiled shared templates and the table into `D:/exported`.
- **Engine: animated shaders on skinned meshes.** `SkeletalAppearance2::alter` never altered its shader primitives, so SWTS / SWSH shaders froze on their first frame on anything worn. It now alters the display LOD's primitives, as `MeshAppearance` does. Each primitive owns a modifiable shader, so every wearer's switcher runs on its own. This is in the x64 Debug client deployed to `exe/win64_rel` from 07:24 on 2026-10-22.

Run: `python examples/make_pajamas.py [--no-compile] [--hue-test N]` (POLYHAVEN_DIR = folder holding `dl_cotton_jersey/` and `dl_fabric_pattern_05/`). `--hue-test N` also writes `shared_titan_lifeday_pj_top_s01_hueN`, the same top with fabric index N, to compare hues in the client.

Checked:
- `swg_check` passes on all 12 `.sat` files (48 meshes).
- Maya walk renders (`importSat` of the body plus both pieces, stock `all_b_loc_walk_*`) of human male, wookiee male and ithorian female show no stretching. Maya can't read SWTS, so the review render swaps in a bulb frame.
- In the x64 Debug client, `/scene equip` worked on all six bodies (human, wookiee and ithorian, male and female) and on rodian male (human mesh through `:default`). The bulbs fade between red and green across frames taken 0.1 s apart. The logo reads on the chest and back, and the button placket on the chest. The wookiee fur fringe in the occluded zones is hidden under the bottoms.
- Hue, in the client: `/devtest custom set /private/index_color_1 <n> <object id>` on the worn top (160 → navy) and bottoms (252 → purple) recolours only the fabric. The bulbs, logo and placket keep their colours. `/devtest custom list <id>` shows the variables. The equipped pieces get ids right after the player's.
- Body shape: with `/shared_owner/blend_fat` 255 plus `blend_muscle` 200, and then `blend_skinny` 255 on the player, the pajamas follow the body through the copied blend targets, with no skin poking through.
- Test recipe: the bridge `loadscene` (no click), `camera` orbit (yaw 180 front, 0 back), launch flags `-s ClientGraphics windowed=1 -s Direct3d9 screenShotBackBuffer=1 -s Direct3d9 antiAlias=0` (the back-buffer screenshot fails with antialiasing).

Known gaps:
- Offline, an object's customization variables come from its shaders' TFAC defaults, not from the template's `paletteColorCustomizationVariables` defaults. The `--hue-test` variant therefore still starts green; set the hue with `/devtest custom set`. A server-created item gets the template values.
- No string table entries for the object names.

**Extending a stock building** — `maya/swg_mcp/starport_ring.py` (`examples/make_atmo_starport.py`; with `--no-maya` it only redoes the exterior .lod, template and terrain layer from the last export) builds the Atmo Flight Starport onto the stock ring starport `mun_all_starport_s01_u01`. It imports the stock POB and keeps its cells, then adds:

- **Side halls:** two curved, two-storey halls in the courtyard. Downstairs is a glazed concourse with content rooms behind it. Upstairs, open observation rooms span the whole hall, with a control room over each lift. One roof height sits just under the stock ring roof, so the rim reads as one ring.
- **Arm exits:** re-pointed into new access rooms, so the existing hallways lead on into the halls. The old wide exits become maintenance doors.
- **Sub-ring:** an underground corridor all the way round under the courtyard's edge (24 cells), with a cantina under the main entrance. Each hall's down lift reaches it.
- **Landing well and checkpoint:** described below.

Stock geometry and floor inside the new footprint are cut away, and the result exports as one POB.

The landing well (`bays`, `bay_fixtures`, `lounge_fittings`) is a round shaft 70 m across (r 35) in the middle of the courtyard, open to the sky, with six levels of hangar bays round it. Bays are 24 m high, the levels are 26 m apart, and the bottom is a landing pad 163 m down. It is sized for the landable POB ships in `titan_vessels.tab`: VT-49, YKL-37R, YT-2400, YT-1300 and the transport shuttle. The yacht (90.5 m) is longer than the courtyard is wide, so it lands on two raised pads outside the ring (`pads`).

- **Bays:** five per level, opening off the shaft: 2 large (46 × 72 m), 2 medium (32 × 58 m) and the shuttle bay (34 × 58 m). They are centred on half-grid angles (`BAYS`). Bays are r0, exterior space, so a ship flies down the shaft and straight in. Each has deck-grating floors, a ceiling with two light strips, and side and back walls. The mouth edges onto the shaft are uncrossable floor edges on every level but the bottom (`make_atmo_starport.mouth_edges`).
- **Lounges:** each bay has a private lounge (cell) against its back wall on every level, for renting the docks out. It is glazed onto the bay with a door to it, and has a bar with a marble top, stools, a lit back bar, an L-sofa and a low table, all holes in the walk floor.
- **Lifts:** each bay column has one lift behind its lounges, from the bottom level up to an access corridor that runs in at the sub-ring's level to the sub-ring.
- **Shuttle bay (reserved):** bay 1's top level (`SHUTTLE_BAY`, `SHUTTLE_LEVEL`) belongs to the shuttle service. It sits under the east hall's departures end. The hall's lift next to the departures exit (`east_gate_lift`, kind `"gate"`) runs on down through the bay's ceiling, so from the ticket hall the route is departures arm, exit room, concourse, one lift down, and a door opening beside the shuttle's berth. The lift stands in the bay clear of the berth: the bay is 2 m wider than a medium one for it. `shuttle_berth()` gives the berth pose (engine space; the shuttle backs in facing the shaft). The make script saves it under `"shuttle"` in `build/titan_atmo_starport.json`.
- **Terrain hole and apron:** terrain over an r0 bay would hold anyone in it up at the surface, because the footprint stands on the higher of terrain and floor. So the terrain hole (`exclude_polygon`, a fine exclusion) is the shaft's rim plus every bay's plan out to the back of its lift, one simple polygon. Where bays reach past the stock building, `apron` closes the ground over them: paving (render) and r0 walk floor at the field's height, with the yacht pads cut out. After export, `make_atmo_starport.apron_edges` types its edges along the stock building's outline as wall bases. The flatten layer's hull includes the hole.

**Bay finish (quality pass).** The bays use the stock space-station hangar set: `newbie_hangar_wall_asb14` panels, `newbie_hangar_trim_asb14` for the shaft and ceilings, ribs every 8 m (`landingpad_side_a_asb14`) each with two emissive `newbie_hangar_light_asbe22` lamps, and a `newbie_hangar_tooth_asb14` warning band at every mouth.
- **Avoid the `d21` detail-map variants** (`neutral_spc_hangar_asbd21` and similar): they crashed the client as soon as the building spawned, probably because they need a second UV set.
- **Ground over the hole.** The courtyard paving now also runs in front of the halls, from the rim to the glazing. Under the stock building's outline, a paving fill 5 cm down covers the gaps the terrain hole opened between the ring's parts.
- **Draw distance.** `write_exterior_lod(..., near_range=550)` draws the full exterior out to 550 m and moves the stock far LODs (which have no apron) out behind it, so no void shows where nearby terrain chunks are cut.

**Shuttle service in the well.** `object/building/titan/titan_atmo_starport.iff` is built on `base_starport` (`make_templates.SERVER_BASE_BY_PREFIX`), so it registers a travel point. Its rows in `datatables/structure/municipal/starport.tab` place:

- the arrival point in front of the gate lift;
- a travel terminal in the east concourse (`east_boarding3`) and one in the bay;
- the transport at the berth;
- the ticket collector by the gate door.

`titan_vessel_services.tab` has new `well`, `well_x`, `well_z` and `well_top` columns, giving the shaft's building-local centre and its rim height. `travel.initializeStarport` turns them into `vessel.service.well` (world space) on the pad controller.

`shuttle_service.java` then flies the vessel to a hover 30 m over the shaft, sinks it down the shaft, and backs it into the bay onto the berth (`wellIn`, 37 s after the approach). Departure is the reverse, nose first (`wellOut`), and the climb-out starts from the hover. The pad's height is the bay floor (the controller's own y), not the terrain. A starport placed in the world needs `travel.VAR_TRAVEL_POINT_NAME` set to register its travel point.

The stock entry hall (foyer4) becomes a security checkpoint. A barrier line with three screening lanes (scanner arches, X-ray belts) and an exit lane splits the public side from the departures side, with queue stanchions on the public side. Everything standing on the floor is a hole in the walk floor.

`round_towers` rounds the stock corner towers: the 12-sided domes and 20-sided drums get 7.5° segments, pushed out onto the true circle.

Stock collision is turned into authored meshes (`stock_collision_mesh`) where the building changes, so cuts and additions reach the exported CMSH. This covers r0 and the two arms; the verbatim stock bytes would otherwise win.

**Control tower** (`control_tower`) — the stock control tower over the south of the ring is now part of the building, without changing its outline. It has 4 new cells:

- **Passage:** a door in the back wall of the gallery under the ring's south face (z −51.2), and a corridor through the ring building.
- **Lift:** rises inside the stock pillar from the field level to 26 m.
- **Vestibule:** at the head's level, between the lift and the control room.
- **Control room:** fills the stock tower head (33 × 11 m) round the lift and vestibule, glazed all round. Its window portals look out through the stock window band.

Nothing is added outside the stock tower and ring. Each room cuts the stock only up to its own top (`clear_stock`), so a passage or a stair flight under the ring building no longer slots the ring's face and roof above it. The halls' whole volume is cleared by full-height hall-sector cuts instead.

**Roofs and field** — the top of the building reads as one surface:

- `hall_roofs` replaces the builder's per-room roof patches over each hall (their seams and T-junctions showed as lines) with one welded roof.
- `roof_edges` runs one continuous coping round each hall roof. Its top is just over the highest stock roof along it, and its outer face runs down under the stock roof's cut edge, so hall roof, coping and stock roof meet with no gap or step.
- `courtyard_paving` paves the courtyard from the well's kerb to the ring's wall feet, flush with the field deck, 4 cm over the walk floor (y 0). Only rooms standing in its plane are cut out of it. The landing pads sit on it.
- `pads` raises the two landing pads to the well's kerb height (it ran between them), with a guard rail round each and a stair centred on each north edge toward the well, mirror images. Their decks and stair ramps are r0 walk floor, the field floor is cut out under them, and after export `make_atmo_starport.pad_edges` types the railed deck edges uncrossable and the field's edge round the pads a wall base.
- `top_collision` adds the hall roofs, the coping, the paving and the pads to r0's collision (the camera's CMSH), which the shell's own collision left out.

**Doors** (`pob_builder`) — an opening that takes a door leaf is cut to the leaf (`DOOR_LEAF` + `DOOR_FIT_W/H`), between rooms and at entrances, whatever width the spec asks. A closed door closes its portal, so the cell behind isn't drawn through a gap round the leaf; it showed as void. `_door_casing` frames each such opening on both wall faces, 4 cm proud and 6 cm in over the cut, past the fit gap. Porches draw only their landing; the ramp under the steps stays walk floor only.

**Closing open faces** — two generic passes in `pob_builder` run on the merged building before export:

- `close_undersides(root)` gives a bottom face to every up-facing render polygon that has open space under it. That means nothing facing down within 0.8 m below it, and either open air or a floor more than 0.8 m down. This covers stair flights, decks, landings, rims, porches and overhangs. It adds a flipped copy in the same material per face; since the client back-face culls, the two coplanar faces don't fight. Ground floors lying on the terrain are skipped. This added 2,235 faces on the starport.
- `line_doorways(root)` adds jambs and a soffit to doorways with a see-through slot beside them. It aims from inside the cell at points just beside each jamb and over the lintel. A ray that crosses the portal plane without meeting a wall of either cell marks a slot, which gets a reveal to the wall in the cell's material. This lined 18 doorways on the starport, between stock cells and between the new halls and their side rooms.

**Offline client tools** — `swg_client_launch` starts the development client (`exe/win64_rel/SwgTitan_d.exe`) with `D:/exported` on its search path and its DevBridge (clientGame `DevBridge.cpp`) on `127.0.0.1:7031`. Then:

- `swg_client_state`: player and camera position, yaw, cell and building.
- `swg_client_exec`: runs any chat line as if typed (spawn, warp, aliases) and returns its console output.
- `swg_client_screenshot`: the client's own back buffer as an image, so overlapping windows don't matter.
- `swg_client_log`: console output since a sequence number.
- Bridge `cellwarp` (scripts: `ClientBridge().request("cellwarp", cell="tower_bridge", to=[x, y, z])`) puts the player into a named cell of the nearest building that has one, at a world position. Use it for rooms that walking cannot reach offline: lifts are server-driven, and `/warpme` and `/devtest` warps always land in the world cell.
- `swg_client_menu`: the offline test menu (below). With no arguments it lists the actions and saved points. `action="flight.xwing"` runs one action and returns each console line it ran, with that line's output. `open_menu=True` opens the menu in the client.

**Offline test menu** — In the Load Scene client, type `/devmenu` (or `/devtest menu`) in chat. A pop-up menu opens with one submenu per category, and picking an entry runs it. Each entry is a short list of console lines. They reuse the stock commands (`/scene mountShip`, `/scene playAnimation`, `/scene wanderCreate`, `/scene setTime`...), and `/devtest` verbs fill the gaps those commands have offline. One example: `/mount` is shadowed by the server command of the same name, so offline it does nothing, and vehicles use `/devtest mount` instead.

| Category | Actions |
|---|---|
| Vehicles | swoop, speeder bike, X-34, BARC, AT-ST, jetpack (each spawned beside you and mounted); dismount |
| Atmospheric flight | X-wing, TIE, Y-wing, N-1, YT-1300 (spawned 30 m up ahead of you, then piloted with `/scene mountShip`); climb 100 m; leave the ship (to the ground) |
| Animations | wave, salute, laugh, jump, dance loop and flex loop on the player; looping emotes on a spawned bantha or dewback; stop loops on the player or the last spawn |
| Spawn | bantha, rancor, wandering dewback, following bantha, Naboo and Tatooine fillers, the cantina, the Titan atmo starport (needs `D:/exported`); list or delete what the menu spawned |
| Warp | save the point `quick` and go back to it, world origin, up 50 m, list saved points; every saved point also gets its own menu entry |
| Debug views | toggles for floors, collision extents and meshes, footprints, path nodes, portals, skeletons, hardpoint names, ship extents, the FPS plot; network ids on/off; noon/night |

The `/devtest` verbs work on their own too (`/devtest` with no verb prints the help):

- `spawn <template> [dist] [height] [mount]` places an object ahead of you on the terrain. Later lines refer to its id as `$last`.
- `spawns`, `clear` list or delete what `/devtest` spawned.
- `target last|clear|<id>` sets the look-at target without a mouse.
- `mount last|<id>` rides a creature vehicle; `dismount` gets you out of a vehicle or ship and puts you on the ground beside it.
- `animstop` stops the loop track.
- `point save|go|delete <name>` / `point list` manage saved points. They are stored in `exe/win64_rel/devtest_points.txt`.
- `goto <x> <z> [above]` warps onto the terrain; `hop <m>` moves you up.
- `flag <section> <name> [0|1|toggle]` sets any debug flag.
- `wait <frames>` (inside an action) runs the lines after it that many frames later. A creature spawned this frame has no animation controller yet, so the creature animation actions wait 5 frames.
- `list` shows every action; `run <action>` runs one.

The actions are a table in clientGame `DevTestMenu.cpp`, and the pop-up and parser are in swgClientUserInterface `SwgCuiCommandParserDevTest.cpp`. Both are compiled only in development builds. To add an action, add a row to the table: it appears in the menu, `/devtest list`, the bridge and `swg_client_menu` without other changes. Bridge protocol: `{"cmd":"menu"}`, `{"cmd":"menu","action":"<id>"}` (the reply has `steps`, each line with its output, and `deferred`, the lines queued behind a `wait`), `{"cmd":"menu","open":1}`.

Checked in the x64 Debug client: the menu and its submenus; swoop mounted, driven and dismounted; X-wing and N-1 boarded 30 m up with the space HUD over the planet, climbed and left; player emotes and the dance loop; a bantha's looping emote (after the wait); creature and Tatooine filler spawns (the filler's interior is walkable); warp save, origin and go; debug flags and network ids. The floor and extent overlays set their flags, but nothing showed on open terrain. Vehicle and flight actions dismount first, so you can switch from one to another directly. Scripts use `ClientBridge().menu(...)`.

The bridge only exists in development builds (`PRODUCTION == 0`), is off unless `[ClientGame] devBridgePort` is set, and only answers requests that carry the per-run token the client writes to `%LOCALAPPDATA%\SwgTitan\devbridge.json`. Protocol: one JSON object per line (`{"id", "cmd", "token", ...}`). The same calls work from a plain script through `swg_maya_mcp.client.ClientBridge`. Each launch overwrites that one file, so `client.launch(port)` also pins the token to `devbridge_<port>.json`. `ClientBridge(port)` and the `swg_client_*` tools after `swg_client_launch` stay on that client when other sessions launch theirs. Each client takes about 0.4 GB of RAM and some GPU memory; with more than three open, new ones fail with "Direct3D could not be correctly initialized".

**God Client tools.** The `godclient_*` tools drive a running God Client (`SwgGodClient_r.exe`) through its own automation bridge (SwgGodClient `GodClientBridge.cpp`). Set `[GodClient] bridgePort=7201` in `exe/win64_rel/SwgGodClient.cfg` to turn it on. The editor then writes `%LOCALAPPDATA%\SwgTitan\godclient_bridge.json`, not `devbridge.json`. The God Client signs in with `user.cfg`, so the tools never launch it: the user starts it and the tools attach.
- `godclient_state`: scene, camera, cursor, selection, pending ghosts, undo state.
- `godclient_load_scene`: an offline scene from the login screen. The release editor stalls for minutes while it loads, so leave it alone.
- `godclient_objects`, `godclient_select`: find objects and select them.
- `godclient_create`: place a template.
- `godclient_transform`, `godclient_apply`: ghost and apply transforms.
- `godclient_undo`, `godclient_redo`.
- `godclient_console`, `godclient_log`: server console with replies.
- `godclient_camera`, `godclient_screenshot`.
- `godclient_terrain_stroke`: one brush stroke through world points.

Scripts use `swg_maya_mcp.godclient.GodClientBridge().call(cmd, ...)`. The protocol and command fields are in `docs/client/god-client-bridge.md`.

**Terrain pits** — `iff.add_pit_layer` adds a sublayer to a building's `.lay`: an AffectorHeightConstant set to *subtract* over a rectangle, with a feathered ramp outside it. Only works with the titan engine. Stock `TerrainModificationHelper::setHeight` overwrote every height constant with the building height, which is why SOE shipped the guildhall/theater "SUNKEN STAIR" pits disabled. Titan overwrites only *replace* constants, so add/subtract constants stay offsets from the building. No active stock building layer uses add/subtract, so stock terrain is unchanged. The server needs the same engine change to agree on ground height in the pit.

**Terrain holes** — `iff.add_exclude_layer` adds a sublayer that removes the terrain inside a shape. The shape is a `circle=(x, z, r)` or a `polygon`, in building-local engine x/z. Inside it there are no terrain tiles and no height, so only the building's own floors show; the Atmo starport uses one over its landing well. With `fine=True` (the default; titan engine, `AEXC` version `0001`), the cut follows the circle or polygon edge exactly. Tiles the edge crosses keep the part outside it, with their inside height poles moved onto the edge, so rendering, collision and height queries all stop at the shape. Stock exclusion (`fine=False`, as in `naboo_wb.lay`) drops whole tiles, two poles wide, by one corner, which steps the cut by up to a tile. Only full-detail terrain chunks are cut, so from far away the terrain is closed over the hole. Boundaries named `local…` (circles and polygons) keep their offset from the building and turn with it; stock circles are re-centred on the building instead. The server needs the same engine change.

### Building spec (`pob_build`)

```json
{
  "name": "titan_outpost",
  "rooms": [
    {"name": "foyer", "min": [-4, 0],  "max": [4, 6],  "height": 4.0},
    {"name": "hall",  "min": [-4, -8], "max": [4, 0],  "height": 5.0},
    {"name": "east",  "min": [4, -8],  "max": [12, 0], "height": 4.0, "color": [0.5, 0.6, 0.5]}
  ],
  "doors":     [{"rooms": ["foyer", "hall"]}, {"rooms": ["hall", "east"], "offset": -1.5, "width": 2.0, "height": 3.0}],
  "entrances": [{"room": "foyer", "side": "+z", "width": 2.4, "height": 3.2}],
  "lights": true
}
```

`min`/`max` are x/z floor corners in metres (Maya Y-up). Each room becomes a cell (`r1…`); `r0` is the exterior shell (walls not shared with another room + roofs, with entrance cut-outs). Doors go on walls two rooms share. The builder:

* cuts door openings without T-junctions and adds door-jamb vertices to the floor, so each doorway is a real floor edge;
* places both halves of each portal identically and orients them so the `clockwise` cell lies on the portal's front side — the convention measured across all 642 stock `.pob` files;
* adds one ambient + one point light per room.

`pob_export_structure` then calls the plug-in's `swg_pob_exportStructure`, which writes `appearance/<base>_rN.apt` (+ `mesh/`, `shader/`, `texture/`), `appearance/collision/<base>_rN_collision_floor0.flr` and `appearance/<base>.pob`, and the tool re-reads them to report pairing issues, missing files and floor problems.

## Terrain (`trn_*`)

Procedural terrain (`.trn`, FORM PTAT) and building terrain layers (`.lay`), no Maya needed. Code: `swg_maya_mcp/terrain/` (`trn.py` format, `generator.py` + `fractal.py` port of the engine generator, `author.py` authoring and validation, `verify.py` client check, `tools.py` MCP tools). Relative paths are looked up in the export root, then the stock data (`terrain/tatooine.trn`). Edits of stock files must go to an `out_path`; new and edited terrains live in `<export root>/terrain/`, where the client finds them.

| Tool | What |
|------|------|
| `trn_inspect` | map settings, family tables, layer tree with item paths (`"2/0/1"`), counts, validation |
| `trn_get`, `trn_families` | one item in full (roads/rivers with height data), a family table in full and who uses each family |
| `trn_new`, `trn_set_map` | new 0015 terrain; map width, chunk width, tiles per chunk, global water, environment cycle, flora tiling |
| `trn_family_set`, `trn_family_remove` | shader, flora, radial, environment, fractal (MultiFractal) and bitmap families |
| `trn_add`, `trn_update`, `trn_remove`, `trn_move` | layers and every boundary / filter / affector type (below) |
| `trn_add_feature` | flatten pad (rect / circle / polygon), road (fixed heights or ground profile), river (trench, banks, local water), ribbon (water strip) — each in its own layer, roads/rivers baked |
| `trn_bake` | the editor's bakes: road/river height data and the BakedTerrain water / steep-slope maps |
| `trn_heights`, `trn_preview` | heights at points as the client reports them (holes, building layers); hillshaded / shader-family PNG preview |
| `trn_validate` | family references, unbaked roads, point counts, feather ranges, map/chunk sizes, items off the map |
| `trn_roundtrip`, `trn_upgrade` | byte-identity check (a file or a folder); rewrite in current save versions (editor save) |
| `trn_example` | a terrain using every feature, baked and validated |
| `trn_client_verify` | `/scene load` it in the offline client and compare the client's heights with the generator's |
| `env_inspect`, `env_create`, `env_edit` | the terrain's client environment: sky file `terrain/environment/<name>.iff` (night sky, stars, sun, moons, celestial bodies such as rings, time lock, skybox, distant appearances, planets) and table `datatables/environment/<name>.iff` (per environment family and weather: sky gradient, clouds, lighting ramps, fog, shadows, environment maps, sounds, music, wind) |
| `trn_register_planet` | add a ground planet to the server, client and god client data (see *New planets*) |

**Types.** Boundaries `circle` BCIR, `rectangle` BREC (local water tables), `polygon` BPOL (local water tables; feather in metres), `polyline` BPLN. Filters `height` FHGT, `fractal` FFRA, `slope` FSLP, `direction` FDIR, `shader` FSHD, `bitmap` FBIT. Affectors `height_constant` AHCN, `height_fractal` AHFR, `height_terrace` AHTR, `color_constant` ACCN, `color_ramp_height` ACRH, `color_ramp_fractal` ACRF, `shader_constant` ASCN, `shader_replace` ASRP, `flora_static_collidable` AFSC, `flora_static_non_collidable` AFSN, `flora_dynamic_near` AFDN, `flora_dynamic_far` AFDF, `exclude` AEXC, `passable` APAS, `road` AROA, `river` ARIV, `environment` AENV, `ribbon` ARIB. Feather functions 0 linear, 1 ease in, 2 ease out, 3 ease in/out; operations 0 replace, 1 add, 2 subtract, 3 multiply. Evaluation: root layers in order; in a layer, boundaries OR (max), filters AND (min), affectors in order with amount × parent amount, then sublayers.

**Format and round trip.** Every record is decoded with its version's exact layout (the engine's `load_XXXX`) and re-encoded the same way; anything that would not re-encode identically is kept as raw bytes (none in stock data). All 182 stock procedural `.trn`/`.lay` files under `sys.client/compiled/game/terrain` write back byte-identical, every record decoded. Explained leftovers: a few stock records hold bytes after their version's layout (an older editor build wrote them; the engine never reads them) — kept as `_trailing` and written back; the 30 `space_*.trn` files are space zones (FORM STAT, not procedural) and are passed through unchanged; `test_layout_tatooine.lay` is not IFF (a `SWGODLAY` file). New records use the editor's current save versions; `trn_upgrade` converts old ones (PTAT 0013/0014 → 0015, BREC 0002/3 → 0004, BPOL 0005 → 0007, AROA/ARIV 0005 → 0006, SGRP 0004 → 0006, RGRP 0003 → 0004, LAYR 0004 → 0003).

**Generator port.** `generator.py` follows `TerrainGenerator::Layer::affect` and the boundary / filter / affector code for heights, shader families and holes; `fractal.py` ports MultiFractal and its ran1 seed generator. It computes in double where the engine uses float32, so heights agree to millimetres. Colour, flora, environment and passable affectors don't change height and are not evaluated; bitmap filters read 8-bit TGAs from the data roots (pass when missing). Bakes follow the editor: road/river profiles sampled every ~8 m with roads and rivers off, roads averaged, rivers terraced downhill; water/slope maps with the editor's 8 m-cell quirk.

**New planets.** `trn_register_planet` (`terrain/planet.py`) adds a ground planet to the repository, idempotently and with a one-time `<file>.pre-<name>` backup of each file it changes: `terrain/<name>.trn` in the game data (the PlanetServer and the client both load `terrain/<scene>.trn`), the client environment, loading tips (`datatables/loading/<name>.iff`), the display name (`string/en/planet_n.stf`), the planet map `texture/ui_map_<name>.dds` rendered from the terrain (uncompressed, 1024²), `universe/planets.mif` + `.iff`, the planet CRC string table (`.txt` + `.iff`), `datatables/region/planets` + `region_<name>` (`.tab` + `.iff`), `startPlanet=<name>` in `exe/linux/localOptions.cfg`, and SwgGodClient's buildout-editor planet list (C++, so the god client needs a rebuild for that one list; its terrain dock finds `.trn` files by itself). The WSL server (`D:\titan\wsl\titan.sh`) starts the planets in `TITAN_PLANETS`. Optional per-planet tables it does not touch: travel, spawning limits, cloning, city limits, buildouts, `base_player.java` waypoint planets, and the client's ticket / waypoint planet lists (C++). The `.tab` compiler in `env.py` (`compile_tab`) reproduces every stock region and environment table byte for byte; for other tables (bit vectors, packed objvars) use DataTableTool. `examples/make_geonosis.py --register` builds and registers Geonosis.

**Environments.** The client loads both environment files by the terrain's file name, and the table's rows by the terrain's environment family names (`env_inspect terrain=...` lists families without a row). Both formats round-trip byte-identically over all stock files (615 skies and DataTables checked); `env.py` also has a generic DataTable reader/writer.

**Holes and building layers.** `trn_heights` and `trn_client_verify` answer the way the client's `TerrainObject::getHeight` does, not just pole values. The answer is the point's full-detail tile fan (8 triangles round the centre pole, `IBP_center`), or none in a hole. That includes:
- stock exclude (AEXC 0000): a whole tile goes when its corner pole is excluded;
- titan's fine exclude (AEXC 0001, `_applyFineExclusion`): tiles with all 9 poles inside the layer's boundaries go, and in crossed tiles the inside poles move onto the boundary edge (circles radially, polygons onto the nearest segment).

So the cut follows chords between edge poles, and a hole smaller than a tile only folds its fan. `trn_add_feature hole` makes either kind of hole.

`generator.place_layer` adds a building `.lay` the way `ClientObjectTerrainModificationNotification` does:
- rectangles take the building transform;
- circles and polygons named `local...` keep their offset and turn with the building;
- other circles are re-centred on the building;
- `setHeight` changes only replace-height constants.

The `buildings` argument of `trn_heights` / `trn_client_verify` uses it, spawning the template with `/scene objectCreate` in the client check.

Parity, checked on 2026-10-23 with `examples/terrain_parity_starport.py` (the Atmo starport's `.lay` at (45, 450) in the Simple scene: 0.25 m tiles, fine hole of r 29):
- **Heights:** every point where both have terrain matches exactly (over 34k points next to the player).
- **Hole membership:** agrees on 99.6% of 66k points in 10 m patches on the hole edge. The rest lie within one tile of the edge.

Further from the player the client draws coarser chunks, so compare near the player.

**Client check.** `trn_client_verify` copies the terrain to `<export root>/terrain/`, runs `/scene load <name>`, warps to each area and asks the bridge's `terrain` command for heights at pole positions (multiples of half a tile), then compares. `launch=True` starts a client of its own (default port 7038) and keeps its token in the server: the shared `devbridge.json` is put back, so other sessions' `swg_client_*` tools stay on their client.

## Player races (`examples/make_races.py`)

A faithful remaster of the ten playable species, both sexes: the stock look, cleaner and sharper, with more customization. Stock files are not touched; everything is written under `D:/exported` at the stock paths, which the client and the server search first. `titan_races_report.json` (next to the meshes) lists every output file with what changed.

```powershell
python examples/make_races.py                       # everything, all races
python examples/make_races.py human rodian          # some species (meshes + textures); the tables always cover all
python examples/make_races.py --only meshes|textures|custom|tables
```

- **Meshes** (`appearance/mesh/<species>_*.mgn`, 224 files): vertex order, skin weights, occlusion zones and the existing blend targets stay as they are, so stock and Titan wearables still fit. What changes:
  - coincident border normals of body, head, arms and hands are welded (no shading seam at the Trandoshan neck or the Mon Cal wrists);
  - DOT3 tangents are re-orthogonalised;
  - body meshes get the new blend targets `blend_chest_large` (female), `blend_glutes` (all) and `blend_bulge` (male);
  - stock `trn_f_arms_l*` name their skeleton `skeleton/all_b.skt`; it is written as `appearance/skeleton/all_b.skt`.
- **Textures** (`texture/*.dds` of every l0/l1 race shader, and `texturerenderer/<species>_face.trt` at 2x):
  - 2x uncompressed reconstruction, 4x for maps of 64 px or less, with DXT de-blocking, Lanczos scaling, sharpening and normal-map micro detail (pores, Trandoshan scales);
  - every channel keeps its meaning (hue masks, spec masks, DXT5nm X/Y).
- **Sliders:**
  - the three new `/shared_owner/` variables get ids 127–129, which CustomizationData version 4 persists (client and server);
  - `customization_data` adds Chest Size, Glutes and Bulge, plus the stock blend targets no slider exposed (Wookiee nose, Mon Cal female ears, Trandoshan female torso);
  - `palette_columns` gives twice the colours at character creation.
- **Client loose copies:** the client finds `exe/win64_rel/customization/customization_id_manager.iff` and `asset_customization_manager.iff` next to its exe before any search path, `D:/exported` included. `make_races.py` therefore writes the new ids and declarations there too, keeping a `.pre-races` backup and rebuilding from that backup on re-runs. Without this, `/devtest custom persist` silently drops ids 127–129 (format version 2). With it, every humanoid persists as format version 4.
- **Server:** run `titan.sh sync` on the customization tables and meshes after a rebuild (only file arguments are synced, not directories).
- **Checks in the client:** use `/devtest custom list|set <var> <value> [id]|persist` (offline, the server command table shadows `/customization`). `examples/race_shots.py before|after <out dir> [species_sex ...]` (move the race outputs aside for `before`, and restart the client) compares stock with the remaster for every race (wide lineup, face close-up, slider row, stock clothing on the new body). It places the free camera with the bridge's `camera` command and frames faces by measuring the head against the sky, because spawned NPCs vary in scale.

## POI props (`examples/make_poi_props.py`)

`maya/swg_mcp/props.py` builds four placeable static props for each adventurer planet, each themed on the factions in that planet's point-of-interest tables (`dsrc/sku.0/sys.server/compiled/game/datatables/poi`):

| Planet | Props |
|---|---|
| Tatooine | Jawa scrap pile, Tusken bone totem, moisture vaporator, spice crate stack |
| Corellia | CorSec barrier, smuggler cargo stack, Selonian marker stone, swoop-gang barricade |
| Naboo | Gungan totem, Trade Federation crates, swamp drying rack, market stall |
| Lok | Nym fuel drums, pirate loot pile, warning beacon, Imperial barrier |
| Endor | Ewok totem, Ewok drum, Dulok fetish, marauder barricade |
| Yavin 4 | rebel supply cache, abandoned comm mast, Hutt scavenger crates, Massassi temple idol |
| Rori | Gungan fishing rack, shield post, dock post, kaadu trough |
| Dathomir | Nightsister banner, Singing Mountain ward stones, prison pylon, bone altar |
| Dantooine | Janta hide rack, Kunga totem pole, Mokk bone fence, tribal firepit |
| Talus | militia sandbag wall, bandit loot crates, watch post, signal flag |

```powershell
.venv\Scripts\python.exe examples/make_poi_props.py [planet ...]      # take D:/titan/.locks/maya first
python examples/poi_props_shots.py D:/exported/titan_poi_props_shots   # client check: one client, port 7061
```

- **Geometry:** props are built from `kit.Piece` primitives (box, prism, log, rail), plus oriented boxes, cones, orbs and double-sided cloth. Crates, banners, flags, drums and the Gungan orb use one texture per face (fit UVs); everything else is world-scaled like the kit.
- **Materials:** stock exterior `a…` shaders only (the `MATS` table). Hue (`h…`) and prelit (`c…`) effects render wrong outdoors.
- **Outputs:** each prop is written like a kit piece:
  - `appearance/thm_<prefix>_poi_<prop>_sNN.apt` pointing at a `.lod`, which carries the collision (a box, or a composite of boxes) and a RADR footprint;
  - the template `object/static/structure/<dir>/shared_<name>.iff`, derived from `corl_imprv_wall_4x16_s01`, with suffixes after any stock name.
- **Review:** renders go to `%TEMP%/swg_poi_props/poi_<planet>.png`, and `props.json` lists every template.
- **Client check:** `poi_props_shots.py` spawns each planet's four props in a row and writes a wide shot, a framed shot per prop and `poi_<planet>_sheet.jpg`.
- **Spawn one:** `/scene objectCreate object/static/structure/tatooine/shared_tato_poi_moisture_vaporator_s01.iff 0 8 180`.
- **Maya preview:** in the render, textures Maya cannot preview show green. The client shows them correctly.

## Themed furniture sets (`examples/make_furniture_sets.py`)

`maya/swg_mcp/furniture.py` (with the group plug-ins in `frn_groups/`) builds three furniture sets, five pieces each (the first two of each set are the signature pieces), plus two interactable pieces. Every piece also gets a details pass (`detail_<piece>`: trims, hardware, props, greebles), run after its base builder:

| Set | Pieces |
|---|---|
| Hutt palace | lounging throne (seat), Sarlacc maw bed (bed), palace hookah, velvet pouf (seat), banquet table with a gorg jar |
| Rebel Alliance | X-wing cockpit lounger (seat), Yavin war-room holotable, Echo Base survival bunk (bed), supply-crate bench (seat), gear locker |
| Galactic Empire | meditation pod (seat), Star Destroyer conference table, officer's bunk (bed), officer's chair (seat), holo-crest pedestal |
| Interactable | superlaser fire-control station (sit and work the console), Hutt feasting lounge (sit and eat) |

Eight themed groups of six followed (48 pieces). Each group has one interactable station, one seat, one lamp that emits light and three supporting pieces. Two groups extend the Hutt and Imperial sets, and six are new themes:

| Group (module) | Interactable (station) | Seat | Lamp | Supporting |
|---|---|---|---|---|
| Hutt palace ext. (`hutt2`) | palace gong (`gong`) | rancor-hide chaise | brass brazier | carbonite slab, rancor skull trophy, treasure chest |
| Galactic Empire ext. (`imp2`) | IT-O interrogation rig (`console`) | Emperor's throne | corridor light pillar | probe droid, E-11 weapon rack, cargo crates |
| Sith / Mustafar (`sith`) | dark shrine (`kneel`) | obsidian throne | lava brazier | hooded statue, saber rack, obsidian table |
| Jedi Temple (`jedi`) | meditation mat (`meditate`) | council chair | temple lantern | archive shelf, training remote, fountain |
| Naboo royal (`nab`) | tea service (`pour`) | royal settee | globe lamp | column planter, side table, folding screen |
| Cloud City (`bsp`) | data terminal (`terminal`) | pod chair | light sculpture | coffee table, planter, cloud window |
| Kashyyyk (`wok`) | hide frame (`tan`) | root chair | glow lantern | bowcaster rack, carved totem, storage baskets |
| Mos Eisley cantina (`can`) | bar counter (`wipe`) | alcove booth | neon sign | dejarik table, band stand, sabacc table |

```powershell
.venv\Scripts\python.exe examples/make_furniture_sets.py [piece ...]   # take D:/titan/.locks/maya first
python examples/make_templates.py frn_titan                            # dsrc .tpf + WSL compile + CRC (tables/server locks)
python examples/viewer_shot.py D:/exported/appearance/frn_titan_hutt_throne.apt throne.png
# the groups: the venv has mcp but no numpy, the system python the reverse
python examples/frn_materials.py D:/exported                                         # all textures + shaders
.venv\Scripts\python.exe examples/make_furniture_sets.py --build-only raw.json piece ... # Maya exports
python examples/make_furniture_sets.py --finish raw.json                             # .lod, templates, .cdf, strings, anims
python examples/frn_preview.py sith --out <dir>                                      # Maya-free preview + lint
```

- **Group plug-ins:** each group is two files. `maya/swg_mcp/frn_groups/<group>.py` holds the geometry: `PIECES`, `SLOTS`, `UV`, `SMOOTH`, `COLORS`. `examples/frn_sets/<group>.py` holds the materials (`MATS`), names and descriptions (`INFO`) and lights (`LIGHTS`). `furniture.py` and `frn_materials.all_mats()` / `make_furniture_sets` merge them, and a module that fails to import is reported in `ERRORS` instead of breaking the others. Kinds: `interact` derives from the stock chair template (it is sat on); `lamp` derives from the stock lit lamp (`shared_frn_all_lamp_free_s01_lit`).
- **Preview and lint without Maya:** `examples/frn_preview.py` runs the geometry with `maya.cmds` stubbed and renders four textured views with a numpy rasteriser. Back faces show magenta: the client culls them, so magenta means a hole in game; culled glow and glass back faces are skipped. It marks hardpoints and draws a 1.8 m scale post. Lint covers floor contact, face budget (LOD0 ≤ 8000, LOD3 ≤ 1200), hardpoints per kind, slot and material mapping, and INFO/LIGHTS consistency.
- **Stations** (`station_hardpoints(P, activity, spot, yaw)`): the piece carries `foot` plus a hardpoint named after the activity, at the spot where the player stands, facing its yaw. `/sit` (or radial Sit) aligns the player there. Once seated, the client hook (GamePlaybackScript `cs_stations`) drops the chair pose, snaps the player onto the hardpoint and loops the activity; `/stand` replaces the chair-stand transition with the way out. Activities:

  | Activity | Animation |
  |---|---|
  | `meditate` | `all_b_force_standing_to_meditation` → `all_b_force_meditation` → `..._to_standing` |
  | `kneel` | `all_b_idl_kneeling_idle1` → `all_b_std_kneeling_to_standing`; no way in, because the crouch transitions carry 0.4 m of root motion |
  | `gong` | `all_b_dnc_musician_gong_dance` |
  | `wipe` | `all_b_int_wipe_surface`; reaches about 0.4 m forward at 0.9 m |
  | `pour` | `all_b_int_standing_pour_container` |
  | `terminal` | `all_b_int_use_data_terminal` |
  | `tan` | `all_b_int_skin_creature` (crouched) |
  | `console` | `all_b_int_use_console` (standing) |

  Beds are the `bed` station. Late joiners see a player already at a station through `GamePlaybackScript::isStation`. The script copies the animations into the export tree.
- **Lamps:** `light_hardpoint(P, pos, name)` plus a `LIGHTS` entry writes `clientdata/furniture/client_shared_frn_titan_<piece>.cdf`, an HLOB light on the hardpoint. The template's `clientDataFile` points at it, like the stock lit lamps (`client_shared_lamp_interior_on.cdf`: colour about 0.003, range 20, linear attenuation 0.00195). The glowing parts are `a_emis_full` / `a_alpha_emis_full`.
- **Test lights on Tatooine:** the offline "Simple" terrain has no environment (magenta sky) and ignores `/scene setTime`. The bridge's `loadscene` with `terrain="terrain/tatooine.trn"` gives the real sky and day/night (`setTime 0.88` = night).
- **Client test pitfalls:**
  - `/sit` does nothing while the bridge's free camera is active: switch back to `mode="chase"` first. `/sit <chair id>` is more reliable than the look-at target.
  - The chair must be the closest chair whose origin is within 2 m (3D), so stand the player on the piece's `foot` hardpoint (engine x = -Maya x).
  - `/devtest clear` can leave stragglers, so relaunch the client between test scenes.
  - `/devtest anim <name> [loop|action] [once]` plays any animation on the player, for tuning station spots.

- **Outputs:** `appearance/frn_titan_<piece>.apt` → `appearance/lod/frn_titan_<piece>.lod` with 4 detail levels (12 / 30 / 80 m), the extent box, NULL collision and the mesh's hardpoints, the same layout as stock furniture. Templates are `object/tangible/furniture/titan/shared_frn_titan_<piece>.iff`, derived from a stock template of the same kind (chair, bed, table, lamp, armoire). Names and descriptions come from `string/en/frn_titan_n.stf` and `frn_titan_d.stf`. On the server, seats use `chair_base` (`make_templates.is_chair`: a `foot` hardpoint and no `bed`), and everything else uses `furniture_base`.
- **Materials:** `examples/frn_materials.py` generates 37 textures and shaders as `frn_titan_*` with numpy: velvet, silk, brass, sandstone frieze, Sarlacc flesh and bone, olive panels, X-wing hull, flight-suit quilting, the starbird and Imperial crests, gloss black, leather, red light strips and holograms. The effects are `a_simple`, `a_specmap`, `a_emis_full`, `a_alpha` and `a_alpha_emis_full`. `a_envmask_specmap` with `env_all_metl` tiles into a mirror-ball checker on furniture, so it isn't used.
- **Sitting** uses the stock chair mechanics:
  - a chair is any appearance with a `foot` hardpoint (`TangibleObject::canSitOn`);
  - `/sit` with the piece targeted runs `playback/change_posture_align.pst`, which aligns the player's feet to `foot`;
  - the sitting_chair transition then slides the root 0.38 m back.
  - So, like stock (`frn_all_mdrn_chair_s01`, `couch_lg_s1`), `foot` sits on the floor 0.175 m in front of the seat edge, and seats are about 0.46 m high. The player must be within 2 m of the object origin.
- **Lying** needs the client hook in `clientGame/.../playback/GamePlaybackScript.cpp` (`alterBedRest`, deployed in `exe/win64_rel/SwgTitan_d.exe`):
  - beds carry `foot` and a `bed` hardpoint (identity rotation, 0.85 m in front of where the body lies);
  - the sit script aligns the player to `bed`;
  - 0.6 s after the sitting posture arrives, the hook stops the state machine's chair transition on the action track, snaps the player onto `bed` and plays the stock bed animations on the loop track: `all_b_std_standing_to_laying_bed_multi.ans`, then `all_b_idl_sleeping_idle1.ans` looping;
  - on `/stand` it swaps the chair-stand transition for `all_b_std_laying_to_standing_bed_multi.ans`.
  - The body lies across +z with its underside about 0.34 m up and the head toward Maya +x, so mattresses top out at about 0.36 m and pillows go at +x.
  - The three animations exist only in the loose data, not in the client paks, so the build script copies them into the export tree.
- **Seat activities** use the same hook: a chair whose appearance has a `use_console` or `eat` hardpoint (the position doesn't matter) is sat on normally, and 0.6 s after seating the activity loop replaces the sitting_chair loop on the loop track: `all_b_int_sitting_use_console.ans` or `all_b_int_eat_sitting.ans`. `/stand` leaves through the stock chair-stand transition. Add more activities in `cs_seatActivities` (GamePlaybackScript.cpp).
- **New templates and the server:** the WSL server reads mirrors (`/root/titan-data`, `/root/titan-exported`). After new templates, mirror the files and the built CRC tables, then restart the cluster: until it restarts, server-spawned new objects show only a selection gizmo in the God client. Start it from a persistent `wsl.exe` window, because a `titan.sh start` inside a short-lived `wsl.exe` call dies with it.
- **Media pieces (video screens, magic-painting frames, RT camera droid)** are in the same module and script:
  - **Video screens** (`imp_` / `reb_` / `hutt_video_screen`, templates `furniture/titan/shared_frn_titan_*_video_screen.iff`): the 16:9 display surface uses shader `frn_titan_<theme>_video_screen.sht` (`a_emis_full`, a standby image).
  - **Painting frames** (`gilded_` / `hutt_` / `reb_` / `imp_painting`, templates `object/tangible/painting/titan/shared_frn_titan_*_painting.iff`): the name contains "painting", so the client treats them as paintings. The 1.2 x 0.9 m canvas uses `frn_titan_painting_canvas.sht`, and they hang like stock paintings: picture toward Maya +x, wall at x = 0, bottom edge at y = 0. Frames are mitred mouldings (`_frame_ring`).
  - **Screen surfaces rule (client):** when an appearance has shaders whose name contains `screen` or `canvas`, `ShaderPrimitiveSet::setTexture` / `setTextureScroll` of the MAIN tag change only those (other tags, such as `REP0` on resource containers, still reach every primitive). Stock appearances with such shaders (console and monitor screens) now also take a video on their screen only. Video, magic-painting and RT-camera textures therefore land on the display or canvas and never on the frame, and `TangibleObject` spawns no floating overlay quads for such objects. Appearances without screen shaders behave as before. The rule has to live in `ShaderPrimitiveSet`, because `MeshAppearance::setTexture` is deferred until the next `alter()`, and a filter set around the call is gone by then. Static objects aren't altered every frame, so `TangibleObject::applyScreenSurfaceTexture` also calls `scheduleForAlter()`.
  - **Camera droid** (`cam_droid`, template `device/shared_frn_titan_rt_cam_droid.iff`, server template based on `device/rt_camera.iff`, so it keeps the `item.rt_camera` script): a cam droid hovering 1.55 m over a charging pad. The client renders the RT feed from the appearance's `lens` hardpoint when there is one (RtCameraManager), not from the floor.
  - **Test without the server:** in the debug client, `/devtest screentex <id|last> <texture>` pushes a texture through the same path as video, painting and RT textures. `/devtest rtfeed <camera> <screen> [fov]` registers an RT feed locally. `objectCreate` headings are degrees (0 faces +z, 90 faces +x), and paintings face -x at heading 0, so a droid at heading 90 on their -x side films the pictures. The RT render draws a starfield sky instead of the scene sky.
  - **God client:** these hooks are in the client engine, so the user's Release `SwgGodClient_r.exe` (and `SwgTitan_r.exe`) must be rebuilt with them (`swg.sln "-t:SwgGodClient;SwgTitan" -p:Configuration=Release -p:Platform=x64`), not only the debug client.
- **Client test recipe:**
  - spawn with heading 0 behind the player, for example `/scene objectCreate object/tangible/furniture/titan/shared_frn_titan_reb_bunk.iff 0 1.2 0`;
  - target it with `/devtest target <id>`, then `/sit`;
  - use free cameras only: the bridge's orbit camera turns the player's heading and leaves seated players misaligned.
- **Screenshots:** in `D:/exported/titan_furniture_shots` (`vw_*` from the Viewer, everything else from the client).

## Boardable vessels (`examples/make_titan_vessels.py`)

`maya/swg_mcp/vessels.py` turns two ships into POB ships players walk into, and the scripts in `script/space/vessel/` fly them in the ground scenes.

| Vessel | Template | What it is |
|---|---|---|
| Starport transport | `object/ship/player/player_titan_transport_shuttle.iff` | The stock transport hull with window strips and a doorway; a ramp cell (r1) and a 30-seat cabin (r2) with the cabin screen. The stock ramp and landing struts are animated parts. |
| SoroSuub yacht variant | `object/ship/player/player_titan_sorosuub_yacht.iff` | The stock yacht POB with clear canopy glass and its r0 portals enabled (see in as well as out), three portholes each side of the stateroom, a boarding door through the lobby's port wall, a ramp cell (r12), a slide-out boarding plank and three folding landing legs. Unchanged cells keep the stock mesh and floor files. |

```powershell
# take D:/titan/.locks/maya; the yacht and the transport build in Maya, then the .lod, templates and tables
python examples/make_titan_vessels.py transport [--no-maya] [--no-compile]
python examples/make_titan_vessels.py yacht [--no-maya] [--no-compile]
python examples/make_titan_vessels.py hyperspace          # the tunnel seen from the windows in transit
python examples/make_cabin_media.py [--only travel_guide,hyperspace,fractal]   # the cabin screen's channels (ffmpeg on PATH)
```

- **Order matters:** the POB export rewrites `appearance/<name>_r0.apt`, so after any Maya build run the script's finish step (`--no-maya` is enough). It writes the exterior `.lod` that carries the part hardpoints; without it the ramp and legs hang at the origin. Then mirror the exports to the server (`titan.sh sync /mnt/d/exported/...`), run `titan.sh crc` for new templates and restart the cluster. A ship whose `.pob` the server can't find crash-loops the game server (`PortalPropertyTemplate::getNumberOfCells`).
- **Yacht build stages** (each is one `maya_python` call; long single calls have crashed Maya): `yacht_import` (stock POB, shapes reversed, untouched cells flagged `swgExcludeFromStaticMeshExport` and their floor previews dropped so the `.pob` keeps the stock files), `yacht_openings` (door notch, portholes), `yacht_ramp_cell`, `yacht_parts`, then `pob_builder.export`. `build_yacht` chains them.
- **Moving parts** are hp_dyn `part` rows (`TangibleObject` packs them; the client's `HpDynPartDynamics` eases between states): `rot` turns about a hardpoint-space axis, `move` slides along one, and a `rot` part with a slide vector (fields 11-13, objvars `mx my mz`) sits slid in when stowed, slides home, then turns. The yacht's plank uses that: it runs out from under the lobby floor, then tilts 30° to the ground. Its legs fold forward under the belly and swing down 90°, so a stowed strut never pokes into a cabin. Axes and slides are mirrored in X (and rotation senses flipped) by `engine_part` when the table is written.
- **Shuttle service** (`shuttle_service.java`): `travel.initializeStarport` creates a pad controller (an invisible object) in place of the stock creature transport for the starports in `datatables/space/titan_vessel_services.tab` (Tatooine, Naboo and Corellia starports). It parks a transport, opens the ramp for `GROUND_TIME`, departs (lift-off and a 56 s climb-out), and after `AIR_TIME` brings the next one in on a 40 s approach. Walking up the ramp with a ticket runs the stock `boardShuttle` command, which now books a seat (`vessel.bookPassenger`) instead of warping: the cabin admits the passenger (cell permissions) and the ticket goes when the doors close. At the jump point, passengers bound off-planet enter hyperspace: they are warped to the destination planet, where `vessel_passenger` puts them aboard the same flight's transit vessel, hovering in the hyperspace tunnel, until the ETA (`45 s + 30 s` per galaxy-map grid square, `titan_hyperspace.tab`), then it lands at the destination's service. Passengers for another port on the same planet cruise there.
- **Vessels are reused, never destroyed in service.** Destroying POB ships in an atmospheric-flight scene corrupts the game server's heap: within seconds to minutes a later allocation lands on live memory and the server dies in `SpaceVisibilityManager` tree code, `_int_malloc` or trigger-volume code (the cluster shows "loading" while TaskManager restarts it). Measured on 2026-10-24: 48 yachts created and kept for 5 minutes ran clean; destroying them crashed the server within 30 s. Create/destroy batches of 4 crashed it every 3-12 batches; the X-wing (no POB) never did. The heap shims used to bound it rule out a double delete, a delete'd block being written, and the allocator handing out a live block; the exact engine line is still open. So `vesselRetire` moves a service vessel 7 km away and 2 km up and stows it (`STATE_STOWED`, listed in the service's `vessel.service.spares`); the next arrival, clone or hyperspace transit takes a stowed vessel before creating one. Only a vessel whose service is gone is destroyed. A private yacht that gets destroyed still carries the risk.
- **Engine fixes found on the way** (server rebuild): `WatchedByList::remove` no longer writes one past its vector and drops another watcher when a watcher isn't on the list; `SpaceVisibilityManager::moveObject/removeObject` use `find()` (no nullptr entries for untracked objects); `TriggerVolume::contentsChanged` no longer runs `set_difference` over an unordered set (space scenes).
- **Tickets:** travel points exist only for running planets. With `TITAN_PLANETS="tatooine geonosis"`, Tatooine terminals sell Tatooine trips only (Geonosis has no starport), and Naboo, Corellia and Lok show routes with no destinations (`destination_invalid`). Add a planet with a starport to `D:\titan\wsl\local.env` to sell interplanetary tickets.
- **Private flight** (`vessel_controller.java`, yacht): the owner's radial has Flight → Lower/Raise Ramp, Take Off (ramp up, legs fold, 45 m hover) and Land Here (descends onto its legs where it hovers).
- **Cabin** (`interior_rows_transport`, `datatables/ship_interiors/titan_transport_shuttle.tab`): 30 stock `frn_chair_falcon_passenger_s01` seats facing the `frn_titan_veh_wall_monitor` on the front bulkhead, and four `frn_titan_veh_ceiling_speaker`s down the aisle (both from the furniture group `veh`: `maya/swg_mcp/frn_groups/veh.py`, `examples/frn_sets/veh.py`, built with `make_furniture_sets.py`; write the materials before the Maya build, or the meshes get `_sgN` fallback shaders and the glass is no `screen` surface).
- **Cabin media** (`cabin_media.java` on the monitor): channels from `datatables/space/titan_cabin_media.tab`, written by `make_cabin_media.py`: Blender Studio's open movies on YouTube first (`STREAMS`; the client resolves YouTube, Vimeo and Twitch links with `exe/win64_rel/yt-dlp.exe`), then the rendered HoloNet Travel Guide, Hyperspace Cam and Fractal Drift (`file:///` URLs: this machine only). Radial: Next / Previous / Channel Guide / Play a Video Link... / Turn Off. A screen plays muted until a speaker is linked (`video_emitter.parent_id`); `cabin_media` links the cabin's ceiling speakers, and the client takes the loudest linked speaker for the listener. VLC needs `vlc/plugins/plugins.dat` (`vlc-cache-gen.exe plugins`) or its first start scans every plugin on the main thread.
- **Cabin access** (`vessel.syncCabinAccess`, each vessel tick): booked passengers, anyone aboard, and while boarding every ticket holder within 64 m. The server's move validation expels a player who moves in a cell they may not enter (that was the jump to the ramp corner on the way off), and the cabin door stalled ticket holders until their booking went through. Ship interiors load within 40 m of the hull (a `PortalTriggerVolume` on POB ships in ground scenes, `ShipObject::onAddedToWorld`), not in one burst as you step aboard.
- **Server tests without a client:** `titan.sh vessel tatooine list|status <oid>|cabin <oid>|depart <svc>|arrive <svc>|restart <svc>|near <x> <z> <r>|park <template> <x> <z> <heading>|ramp|takeoff|land <oid>`. `list` also shows each service's stowed vessels. `travel` prints every planet's travel points, costs and routes; `terminals` runs the route checks of a ticket purchase from every travel terminal; `stress <n> [template] [mode]` spawns test ships. Console handlers have no owner script, so their `messageTo` calls need a delay > 0.
- **Offline client:** `/devtest vessel <id|last> hpdyn part <slot> <apt> rot|move ax ay az amount seconds delay state [mx my mz] | ...`, `fly <dx> <dy> <dz> <seconds> [yaw]`, `video <url> [aspect]` (plays a stream on a screen locally), `furnish <template> <cell> <x> <y> <z> <heading>` (an interior piece in a cell: the buildout table offline). The bridge's chase camera keeps a fixed world heading, so turn the vessel (spawn heading) rather than the player for interior shots; free and orbit cameras don't track cells.
- **Screenshots:** `D:/exported/titan_vessel_shots`.

### Lambda, corvette, Nebulon-B (`maya/swg_mcp/vessel_fleet.py`)

| Vessel | Template | What it is |
|---|---|---|
| Lambda shuttle | `object/ship/player/player_titan_lambda_shuttle.iff` | The stock `lambda_player.pob` (hull + cabin). The stock ramp drops from a hatch in the corridor deck under the cockpit (cell `hatch_ramp`), the wings fold up 135° on landing, four folding legs. Clear canopy, see-in portal enabled. Ground 3.4 m under the hull frame. |
| Corellian corvette | `object/ship/player/player_titan_corellian_corvette.iff` | The player corvette (`corellian_corvette_2005e3.pob`: bridge, officers' quarters, halls; kept as stock files) extended aft through a doorway cut in hall61: spine hall, cross hall, starboard lounge and port crew quarters (five hull windows each), a companionway down into the keel, an embarkation room on a lower deck and a 29 m ventral ramp (stowed slid into the keel). Rests on its engine block and four forward legs; ground 27.4 m under the main deck. |
| Nebulon-B frigate | `object/ship/player/player_titan_nebulon_frigate.iff` | A new interior in the stock exterior's lower forward section: embarkation room in the bottom disc plate, one lift cell whose four landings are stacked floors (the stock elevator terminals' `elevatorMove` runs between them), medical bay (bacta tanks), crew deck, bridge hall and a bridge with a forward window band. 26 m ramp forward out of the bottom plate; two legs under the plates, two 89 m struts under the engine block. Ground 148.6 m under the hull frame. |

```powershell
# take D:/titan/.locks/maya; paint shaders, Maya build, .lod, templates, tables (numpy in the venv)
.venv\Scripts\python.exe examples/make_titan_vessels.py lambda|corvette|nebulon [--no-maya] [--no-compile]
.venv\Scripts\python.exe examples/vessel_paint.py lambda|corvette|nebulon     # paint shaders only
```

- **Scale:** the stock SWG hulls are kept (Lambda 26 m tall with the fin, corvette 266 m, Nebulon-B 472 m): the
  interiors are cut to the player and the hulls keep their proportions to each other.
- **Paint (player customization):** `examples/vessel_paint.py` turns each stock hull shader into a two-zone hue
  shader the way the stock JTL paint jobs are built (`h_color2w_*`: MAIN alpha = hull plating mask,
  `/private/index_color_1`; HUEB alpha = trim mask, `/private/index_color_2`; SPEC = the stock spec mask) on
  `palette/titan_ship_paint.pal` (64 colours, entry 0 white = the stock look). The templates declare both
  variables; the owner's radial **Paint → Hull Colour / Trim Colour** opens the colour picker. Hp_dyn parts (the
  Lambda's wings) wear the owner's customization: the client pushes it to every part after each hp_dyn update and
  each appearance-data change (`pushCustomizationToHpDynParts`, `TangibleObject.cpp`); a part made before the owner
  had customization data would otherwise never follow a repaint. Stock detail shaders
  (`a_specmap_cbmp_detail`) lose their DETA map and take the plain `DOT3 1, MAIN 0, NRML 0` coordinate sets: the
  re-exported hull has one UV set, and the stock sets (DETA 1, DOT3 2) render garbage on it.
- **Floor hatches:** a ramp cell named `hatch*` lies under a deck people also walk over. The engine crosses a portal
  into a hatch cell only while that cell admits the player (`Portal::isPassable`, and the position-change cell
  transition in `CellProperty.cpp`, which is what actually moves a walker between cells and never asked about
  passability), and a footprint keeps no floor contact in another cell when either side is a hatch
  (`Footprint::sweepContacts`), so walking over the closed hatch stays on the deck and stepping into the open one
  puts you on the ramp. `vessel.setRamp` opens / shuts the cell (staff included while shut). Client and server
  copies of the shared files changed.
- **Room kit** (`wall`, `split_floor`, `ceiling`, `room_lights`, `finish_cell`, `wall_windows`, `ramp_cell`): box
  rooms with doorways, split walk floors (doorway edges on their portals), deck plating, ceiling light strips,
  stock-layout lights, windows cut through the hull (one portal per window: a band portal lets hull structure show
  over the wall between them) and the generic open-air ramp cell with its well.
- **Furniture:** `FURNISH` in `make_titan_vessels.py` (lounge couches and tables, quarters bunks, medbay bacta tanks
  and beds, bridge consoles) becomes each ship's `datatables/ship_interiors/<name>.tab`.
- **Offline checks:** spawn with `/scene objectCreate`, raise it by the landed height (`/devtest vessel <id> fly 0
  <h> 0 0.5`), apply the parts row from `titan_vessels.tab` with `hpdyn part ...`. Lifts are server-driven: the
  bridge `cellwarp` (cell `lift`, a landing's height) reaches the upper decks.
- **Landing gear:** `_gear_faces` models an oleo leg in the stock JTL / YT-1300 style: trunnion and yoke at the
  hinge, a painted upper cylinder with bands and a gland nut, two hydraulic lines, a polished piston, scissor torque
  links, a twin drag brace up to a belly mount ahead of the leg (it folds into the hull when stowed) and an
  articulated foot (ankle clevis, eight ribs over the plate, dark sole). Legs longer than 8x their scale (about forty
  cylinder radii) read as poles, so `_truss_faces` builds those (the Nebulon's 89 m engine supports) as triangulated
  truss towers: three longerons, a ring every bay, a zig-zag up each face, a hydraulic spine, collar and footing.
  Both are modelled
  stowed along +z from the hinge; `landing_leg` / `landing_leg_scaled` export them per slot (Lambda 1x, corvette
  `CV_GEAR_SCALE` 6.5x, Nebulon legs 5x, engine trusses 9x). `GEAR_MATERIALS` are lit `a_` shaders (Imperial trim
  and gate metal, polished grey piston, dark blued pads): `c_` shaders are prelit and render black without vertex
  colours, which is also why the ramp-well materials moved off the blacksun transport `c_` shaders.
- **Textures of re-exported stock geometry:** two exporter mismatches made the hulls look wrong. (1) The SwgPob /
  SwgMsh importers keep UVs as stored but `exportStaticMesh` writes `1 - v` by default, so every re-exported stock
  surface sampled its texture atlas upside down; `vessel_fleet.mark_uv_direct` sets `swgExportUvDirect` on the
  shading groups of imported stock faces (and `swap_shaders` on its own), our built geometry keeps the default.
  (2) The exporter writes one texture-coordinate set, but the bump-mapped hull shaders read DOT3 tangents (set 1 or
  2) and the detail shaders (interiors, gear, ramps) DETA at set 1: `iff.fill_texcoord_sets` (run by
  `make_titan_vessels.finish` on every vessel mesh) adds per-vertex tangents in the stock convention (+U, w =
  handedness; checked against stock hull meshes) and detail UVs at 4x the base set (the stock corvette interiors).
  `iff.audit_texcoord_sets(msh, roots)` lists any primitive whose shader reads a set its vertices lack.
- **Hull collision (walkers on the terrain):** `hull_collision_boxes` bins the hull into boxes; `landed_collision`
  keeps only the boxes that reach within `HEADROOM` (2 m) of the ground - a walker passes under the rest, which is
  how the ramp foot under the Lambda's nose and the big hulls' bellies are reached - and adds a post per deployed leg
  (ground to hinge, footpad radius). The boxes are the exterior .lod's APPR collision. Engine side
  (`sharedCollision/CollisionProperty.cpp`): templates with a portal layout are filed `Q_Static` (creatures only
  resolve against statics), and a creature collides with a ship only while it is in the world cell, so the boxes never
  stop anyone on the ramp or inside.
- **Deeds** (`object/tangible/titan/vessel_deed/titan_<name>_deed.iff`, script `space.vessel.vessel_deed`): from the
  owner's inventory, **Call Vessel** flies the ship in (the first call creates it and makes the caller its owner) and
  sets it down broadside at the deed's clearance (22 / 55 / 75 m): ahead of the caller, else to their left, right or
  behind - the first pad whose hull plan (the deed's `half_width`, `length_aft`, `length_fore` objvars, from the
  build's hull boxes) is level (3 m plus 2 cm per metre of hull, sampled down the keel and both sides) and clear of
  buildings, installations and statics, and 10 m clear of other vessels' hulls (each called vessel carries its plan
  as `vessel.hull`, so the check measures keel to keel); with none it says so. A ship parked or boarding elsewhere is
  brought round the same way. An owner waiting outside finds the ramp lowered on touchdown.
  **Send Vessel Away** lifts an empty landed ship off and stows it (never destroyed: see the POB rule). Grant one with
  `titan.sh vessel tatooine deed object/tangible/titan/vessel_deed/titan_lambda_shuttle_deed.iff <firstname>`.
  Ships take their `titan_vessels.tab` `shipName` (`vessel.nameVessel`) while they still wear the template name.
- **Owner controls:** the hull's radial and a helm console inside (`terminal_command_console` on the Lambda's aft
  cabin bulkhead and mid-bridge on the corvette, the bridge command console on the Nebulon; FURNISH rows with
  `HELM`, which becomes the interior table's `strScripts`) show the same `vessel.addFlightMenu`: Flight (Lower /
  Raise Ramp, Take Off, Land Here), Paint (Hull / Trim Colour) and Name Vessel (filtered input box). From inside
  the hull cannot be targeted ("You can't see that object"), so the console (`space.vessel.vessel_helm`) relays the
  pick to the ship (`vessel_controller.vesselHelm`). Private vessels skip the shuttle-service ticket check and greet
  their owner as they board. Interior rows are created with the ship: a ship called before a row existed does not
  get it. The hull radial is out of reach on the corvette and Nebulon (its origin stands 27 / 148 m up), so the deed
  also offers Lower / Raise Vessel Ramp within 400 m of a landed ship.
- **Logging out aboard:** stock `space_transition.handleLogout` packs an owner's ship when they log out inside it
  (outside atmospheric-flight scenes it lands at the fallback launch point 5, 195, 5); it now leaves Titan vessels
  where they are. The game server's login containment restore does not take POB ship cells on a ground scene and
  ejects the character under the vessel's frame, so `space.vessel.vessel_aboard` (given to anyone who walks up a
  ramp, by `vessel_cell`) records the cell and position on logout aboard a private vessel and puts them back there
  two seconds after login.
- **Hot reload caveat:** `titan.sh sync` reloads a script's class but not its nested classes, so a new field on
  `vessel.Config` fails every `getConfig` until a cluster restart (the hull plan is read by `vessel.getHullPlan`
  instead). `vessel_controller.vesselTick` re-arms before its work and carries a generation, so one failing tick no
  longer ends a vessel's loop; `titan.sh vessel <scene> retick all` restarts every loop on a scene and
  `titan.sh vessel <scene> restart <service oid>` resets a stuck shuttle service.
- **Live test recipe** (server not in auth mode): launch the client with `autoConnectToLoginServer=false` (never the
  saved `login.cfg` account), set `/Login.flow.InputPage.UsernameTextbox` Text to `test` with the bridge `ui` op, press
  `/Login.pageButtonsBottom.Next.buttonNext`, then `/AvSel.pageButtonsBottom.Next.buttonNext`. The bridge
  `menuselect` command (`{"cmd":"menuselect","oid":"<oid>","item":"SERVER_MENU1"}`) sends what clicking a radial item
  sends, so deed and ship radials run without the mouse. Script dialogs (SUI) open as copies under `/GroundHUD`
  (`/GroundHUD.inputBox.cmbInput.ComboTextbox` LocalText, then `.btnOk`; `/Script.*` are the hidden prototypes).
  `titan.sh vessel tatooine paint <oid> hull|trim <index>` sets
  what the colour picker's OK sets; `titan.sh vessel tatooine warp <firstname> <x> <z>` moves a test character (the
  flat basin round -3500, -5800 takes the corvette and the Nebulon).
- **Not testable offline:** the shut hatch (the offline client admits every cell), the lift terminals, the Paint
  radial (server colour picker), deeds.
- **Screenshots:** `docs/vessel_fleet/` - the three ships landed live in the basin (`fleet_basin_live`,
  `corvette_landed_live`, `lambda_landed_live`, default paint), gear and truss close-ups, the corvette engines
  against the stock POB, interiors, helm and paint picker.

## Battle of Naboo heroic (`examples/make_naboo_battle.py`)

The art for the Historical heroic "The Battle of Naboo, as told by Jar Jar Binks" (design and contract:
`docs/content/battle-of-naboo/README.md` in the monorepo): the `adventure_heroic` scene, the Trade Federation
vehicles, the Gungan Grand Army pieces, the B1 deploy animations and the Historical quest marker.

```powershell
python examples/naboo_battle_materials.py D:/exported [preview.png]      # system Python (numpy + Pillow)
.venv\Scripts\python.exe examples/make_adventure_heroic.py [--register]   # scene; --register needs .locks/tables
python examples/make_naboo_battle.py aat                                    # AAT skeletal appearance, no Maya
.venv\Scripts\python.exe examples/make_naboo_battle.py [piece ...]         # static pieces, takes .locks/maya
.venv\Scripts\python.exe examples/make_b1_unfold.py                        # B1 power_up / power_down, takes .locks/maya
python examples/geo_preview.py swg_mcp.naboo_battle mtt_preview out.png --state open   # renders without Maya
```

| Piece | Appearance | Notes |
|---|---|---|
| MTT | `titan_hrc_nboo_mtt.apt` + `_mtt_lid`, `_mtt_chin`, `_mtt_rack`, `_mtt_rack_empty` | 34 m, khaki (the orthographic references). The parts are hp_dyn `part` rows on `hp_lid` (rot X -100), `hp_chin` (rot X +70), `hp_rack` (move Z 10 m); the rack carries 112 folded B1s. Composite collision boxes. |
| AAT | `titan_hrc_nboo_aat.sat` + `_aat_turret.apt` | Skinned hull on a two-joint vehicle skeleton (root, joint2), written by Python (`wearable.write_skt` / `write_mgn` / `write_sat`). The turret is an hp_dyn part on `hp_turret`, rot Y 360, state = yaw / 360. |
| Gungan | `_shield_dome` (r 150 m, two-sided), `_shield_generator`, `_hand_shield`, `_booma`, `_catapult`, `_plasma_shell` | Emissive alpha membranes (`a_alpha_emis_full`). |
| B1 | `titan_hrc_nboo_b1.sat`, `lat/titan_hrc_nboo_b1.lat`, `animation/titan_hrc_b1_unfold.ans`, `titan_hrc_b1_power_down.ans` | Stock mesh and skeleton; the .lat adds `std_power_up` / `std_power_down`, which the stock `all_b.ash` actions `power_up` / `power_down` play. |
| Marker | `titan_info_disk_historical.apt` | Gold medal disc with the Aurebesh Herf, the stock info disc's size. Client: an hp_dyn `app` row whose hardpoint is `@interesting` replaces the interesting marker (`TangibleObject::applyDynamicHardpointsState`). |

- **Geometry** uses the `furniture.F` primitives (`maya/swg_mcp/naboo_battle.py`); the module imports outside Maya with
  `maya.*` stubbed, so `geo_preview.py` (numpy rasteriser, textures from the export tree) renders every piece while
  another session holds Maya. Builders take `lod` (three detail levels, `DET`).
- **Creature appearances need an animation controller.** A `.sat` without the controller flag and an `LATX` row
  (skeleton -> `.lat`; vehicles use `appearance/lat/monstrosity.lat`) is never evaluated: the mesh renders as
  garbage and blacks out the frame. `wearable.write_sat(..., create_animation_controller=True, lat=[...])`.
- **Creature, not vehicle.** A template with a vehicle game object type draws its saddle appearance and hides the
  `.sat` mesh (stock vehicle `.mgn`s are 10 cm placeholder boxes). The AAT renders when its template derives from a
  creature (`object/mobile/shared_atst.iff`).
- **Hand-written `.mgn`**: engine space is Maya with X mirrored; triangles wind so `cross(b - a, c - a)` follows the
  normal (stock rule, checked on a stock vehicle mesh); V is flipped like the static exporter (`1 - v`).
- **Animation joints:** `importSat` renames the B1 root joint `root__battle_droid_l0` (a clash with the LOD group),
  so look joints up by the name before `__`. Poses are world-space rotations applied parent first
  (`cmds.rotate(..., relative=True, worldSpace=True)`), so the rig's joint axes don't matter.
- **Offline checks:** test templates live under `object/tangible/titan/test/` and `object/mobile/titan/test/`
  (derived from a stock table and from the AT-ST); `/devtest spawn|spawnat`, `/devtest vessel <id|last> hpdyn part
  <hp> <apt> rot|move ax ay az amount seconds delay state`, `/scene playAnimation <ans> 1` on the look-at target.
  Screenshots are black unless the client window is in front.

## Tests

```powershell
.venv\Scripts\python.exe tests\smoke_test.py [export_root]   # real MCP stdio client, headless Maya; prints PASS/FAIL
.venv\Scripts\python.exe -m unittest tests.test_terrain -v      # terrain: stock round trip, authoring, generator, trn_ tools over stdio
```
