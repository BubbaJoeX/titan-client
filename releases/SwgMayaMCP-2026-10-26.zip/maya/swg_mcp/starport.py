"""Atmo Flight Starport — runs inside Maya with SwgMayaEditor loaded.

An open landing field with eight pads (two rows of four) inside a ring of 24 m deep halls, a second floor on the
ring and two control towers at the middle of the left and right sides:

  ground ring   terminal, cantina, shop arcade, hangar bays (double height, wide doors to the field), customs,
                security, med bay, lounge (fountain), cargo, workshops; every ground segment opens onto the field,
                the front ones also to the outside, and the ring is walkable all the way round
  second floor  observation lounges glazed toward the field, VIP lounge, offices, crew quarters, control ops
  towers        lift shafts serving the ground, the second floor and a glass control deck above the roofline

SWG blocks movement with floor edges, not meshes: the field and a skirt around the outside are r0 floors whose
edges along the walls the exporter tags as wall feet; their doorway edges carry the portals."""

from __future__ import annotations

import math

import maya.cmds as cmds

from . import pob_builder as pb
from . import filler as F
from . import filler_plan as FP

W, D = 150.0, 110.0          # outer footprint (x, z)
RING = 24.0                  # hall depth
F0, F1 = 0.0, 5.0            # ground / second floor
H1, H2 = 4.6, 4.6            # room heights (slab 0.4 between)
HANGAR_H = F1 + H2           # double height, same roofline
TOP = 15.0                   # tower control deck floor
TOWER = 10.0

SP = lambda n: "shader/" + n + ".sht"
MAT = {
    "spaceport": {"wall": SP("spaceport_metl_panel3_cs8"), "floor": SP("intr_tech_floor_c_cs8"),
                  "ceiling": SP("intr_tech_ceilingb_cs8"), "trim": SP("spaceport_metl_trim_cs8")},
    "spaceport_b": {"wall": SP("spaceport_metl_panel5_cs8"), "floor": SP("intr_tech_floor_c_cs8"),
                    "ceiling": SP("intr_tech_ceilingb_cs8"), "trim": SP("spaceport_metl_base_cs8")},
    "hangar": {"wall": SP("spaceport_metl_panel5_cs8"), "floor": SP("floor_garage_floor_02"),
               "ceiling": SP("intr_tech_ceilinga_cs8"), "trim": SP("spaceport_metl_base_cs8")},
    "cantina": {"wall": SP("corl_stco_cantina_wall_fallback_c2d13"), "floor": SP("corl_metl_cantina_floor_cds16"),
                "ceiling": SP("z_intr_tech_ceilinga_cs8"), "trim": SP("corl_stco_cantina_trim_cs8")},
    "lounge": {"wall": SP("z_intr_assoc_marble_white_gloss_ces17"), "floor": SP("corl_metal_dark_tiled_a2sda29_phong"),
               "ceiling": SP("intr_hotel_ceiling_a1_cs8"), "trim": SP("intr_hoteltrim_cs8")},
    "vip": {"wall": SP("z_intr_assoc_marblered_ces17"), "floor": SP("floor_carpet_red"),
            "ceiling": SP("intr_hotel_ceiling_a1_cs8"), "trim": SP("intr_hoteltrim_cs8")},
    "office": {"wall": SP("z_intr_tech_wall_panelb_cs8"), "floor": SP("floor_carpet_teal"),
               "ceiling": SP("z_intr_tech_ceilinga_cs8"), "trim": SP("intr_tech_trimb_cs8")},
    "med": {"wall": SP("intr_medicalwall_tech_b_cd8"), "floor": SP("hospital_floor_grey_cd8_phong"),
            "ceiling": SP("hospital_ceiling_a_cd8"), "trim": SP("intr_tech_trimb_cs8")},
    "quarters": {"wall": SP("ply_corl_stucco_fallback_c2d13"), "floor": SP("floor_carpet_brown"),
                 "ceiling": SP("ply_corl_ceiling_a_cs8"), "trim": SP("ply_corl_accent_c_cs8")},
    "cargo": {"wall": SP("corellia_concrete_b_cs10"), "floor": SP("corl_stco_cantina_floor_grate_cs8"),
              "ceiling": SP("intr_tech_ceilinga_cs8"), "trim": SP("intr_tech_trimb_cs8")},
    "lift": {"wall": SP("intr_medicalwall_tech_b_cd8"), "floor": SP("floor_garage_floor_02"),
             "ceiling": SP("intr_tech_ceilingb_cs8"), "trim": SP("spaceport_metl_trim_cs8")},
}
FIXTURE = SP("spaceport_luma_lightstrip2_cs8")
PAD_DECK = SP("landingpad_deck_a_ad8")
PAD_SIDE = SP("landingpad_side_a_asb14")
LIGHT = dict(FP.ROLE_LIGHT)
LIGHT["hangar"] = {"ambient": 1.0, "ambient_rgb": (0.34, 0.36, 0.40), "rgb": (0.95, 0.97, 1.0), "intensity": 1.3}
LIGHT["terminal"] = {"ambient": 1.0, "ambient_rgb": (0.38, 0.39, 0.42), "rgb": (1.0, 0.97, 0.92), "intensity": 1.3}
LIGHT["observation"] = {"ambient": 1.0, "ambient_rgb": (0.40, 0.40, 0.44), "rgb": (1.0, 0.95, 0.88), "intensity": 1.0}
LIGHT["control"] = {"ambient": 1.0, "ambient_rgb": (0.30, 0.34, 0.42), "rgb": (0.75, 0.9, 1.0), "intensity": 1.0}
LIGHT["vip"] = {"ambient": 1.0, "ambient_rgb": (0.36, 0.30, 0.30), "rgb": (1.0, 0.82, 0.62), "intensity": 1.0}

# segments: (kind, length along the side); north/south run west->east, east/west run south->north
NORTH = [("cargo", 26), ("hangar", 30), ("market", 38), ("hangar", 30), ("med", 26)]
SOUTH = [("security", 26), ("terminal", 34), ("cantina", 30), ("lounge", 34), ("customs", 26)]
EAST = [("workshop", 26), ("tower", TOWER), ("crew", 26)]
WEST = [("crew", 26), ("tower", TOWER), ("workshop", 26)]
UPPER = {"cargo": "quarters", "market": "observation", "med": "offices", "security": "offices", "terminal": "observation",
         "cantina": "vip", "lounge": "observation", "customs": "offices", "workshop": "control", "crew": "quarters"}


class Plan:
    def __init__(self, seed=3):
        self.rooms = {}       # name -> dict(rect, floor_y, height, role, mat, extra)
        self.doors = []
        self.entrances = []
        self.decor = []
        self.count = {}
        self.rng = FP.Rand(seed)
        self.inner_doors = []     # (side of the field edge, u, width) for the field floor's door edges
        self.outer_doors = []     # (side of the outer wall, u, width) for the skirt's door edges

    def room(self, rect, fy, h, role, mat, **extra):
        self.count[role] = self.count.get(role, 0) + 1
        name = f"{role}{self.count[role]}"
        self.rooms[name] = {"rect": tuple(round(v, 3) for v in rect), "floor_y": fy, "height": h, "role": role,
                            "mat": mat, **extra}
        return name

    def link(self, a, b, width=1.8, style="open", y=None, near=None):
        d = {"rooms": [a, b], "width": width, "height": 2.8 if width <= 2.4 else 3.6}
        if style == "arch":
            d["style"] = "arch"
        elif style == "door":
            d.update({"style": "door", "door_style": "door_corl_metal_s03", "height": 2.8})
        if y is not None:
            d["y"] = y
        if near is not None:
            d["near"] = list(near)
        self.doors.append(d)

    def best_pair(self, A, B, fy):
        best = None
        for a in A:
            for b in B:
                ra, rb = self.rooms[a], self.rooms[b]
                if abs(ra["floor_y"] - fy) > 0.05 or abs(rb["floor_y"] - fy) > 0.05:
                    continue
                s = FP.shared(ra["rect"], rb["rect"])
                if s and s[3] - s[2] >= 2.2 and (best is None or s[3] - s[2] > best[2]):
                    best = (a, b, s[3] - s[2], s)
        return best

    def bsp_rooms(self, rect, target, kind, fy, h, entry_pt, mat, role_map=None, cap=None):
        cap = cap or {"home": 6, "office": 5, "workshop": 4, "cantina": 3}.get(kind, 5)
        target = max(target, FP.area(rect) / cap)
        leaves, links = FP.bsp(rect, target, self.rng)
        e = FP.leaf_at(leaves, entry_pt)
        roles = FP.assign_roles(leaves, links, e, kind, self.rng)
        if role_map:
            roles = {i: role_map.get(r, r) for i, r in roles.items()}
        names = [self.room(lf, fy, h, roles[i], mat(roles[i]) if callable(mat) else mat) for i, lf in enumerate(leaves)]
        for a, b, s in links:
            private = roles[a] in FP.PRIVATE or roles[b] in FP.PRIVATE
            self.link(names[a], names[b], width=1.6, style="door" if private else "arch")
        return names, names[e]


def _strip_rects(side):
    """Segment rectangles of one side of the ring, with the side's field-facing direction."""
    x0, z0, x1, z1 = -W / 2, -D / 2, W / 2, D / 2
    out = []
    if side in ("north", "south"):
        segs = NORTH if side == "north" else SOUTH
        za, zb = (z1 - RING, z1) if side == "north" else (z0, z0 + RING)
        u = x0
        for kind, ln in segs:
            out.append((kind, (u, za, u + ln, zb)))
            u += ln
    else:
        segs = EAST if side == "east" else WEST
        xa, xb = (x1 - RING, x1) if side == "east" else (x0, x0 + RING)
        u = z0 + RING
        for kind, ln in segs:
            out.append((kind, (xa, u, xb, u + ln)))
            u += ln
    return out


FIELD_SIDE = {"north": "-z", "south": "+z", "east": "-x", "west": "+x"}       # wall facing the field
OUT_SIDE = {"north": "+z", "south": "-z", "east": "+x", "west": "-x"}


def _edge_mid(rect, side):
    x0, z0, x1, z1 = rect
    return {"+x": (x1, (z0 + z1) / 2), "-x": (x0, (z0 + z1) / 2), "+z": ((x0 + x1) / 2, z1), "-z": ((x0 + x1) / 2, z0)}[side]


def plan():
    P = Plan()
    ground_by, upper_by = {}, {}
    towers = []
    for side in ("south", "east", "north", "west"):
        ground_groups, upper_groups = ground_by.setdefault(side, []), upper_by.setdefault(side, [])
        fs, os_ = FIELD_SIDE[side], OUT_SIDE[side]
        for kind, rect in _strip_rects(side):
            field_pt = _edge_mid(rect, fs)
            out_pt = _edge_mid(rect, os_)
            # corner segments of the north/south rows reach past the field: only real frontage gets a doorway
            frontage = True
            if side in ("north", "south"):
                lo, hi = max(rect[0], -W / 2 + RING), min(rect[2], W / 2 - RING)
                frontage = hi - lo >= 4.0
                field_pt = ((lo + hi) / 2, field_pt[1]) if frontage else field_pt
            g, u = [], []
            if kind == "tower":
                # lift shaft on the outer wall, tower lobby between it and the field, landing above the lobby
                if side in ("east", "west"):
                    sx0, sx1 = (rect[2] - TOWER, rect[2]) if side == "east" else (rect[0], rect[0] + TOWER)
                    shaft = (sx0, rect[1], sx1, rect[3])
                    lobby = (rect[0], rect[1], sx0, rect[3]) if side == "east" else (sx1, rect[1], rect[2], rect[3])
                else:
                    raise ValueError("towers sit on the east/west sides")
                lift = P.room(shaft, F0, TOP + 4.4 - F0, "lift", MAT["lift"], levels=[F1, TOP], elevator=True,
                              tower_side=os_)
                tl = P.room(lobby, F0, H1, "lobby", MAT["lounge"])
                tu = P.room(lobby, F1, H2, "corridor", MAT["spaceport"])
                P.link(tl, lift, width=2.4, near=_edge_mid(shaft, fs))
                P.link(tu, lift, width=2.4, y=F1, near=_edge_mid(shaft, fs))
                g, u = [tl], [tu]
                towers.append(lift)
                P.inner_doors.append((fs, tl, field_pt, 3.0))
            elif kind == "hangar":
                hname = P.room(rect, F0, HANGAR_H, "hangar", MAT["hangar"], light="hangar")
                g = [hname]
                P.inner_doors.append((fs, hname, field_pt, 6.0))
            elif kind == "terminal":
                hname = P.room(rect, F0, H1, "terminal", MAT["spaceport"], light="terminal")
                g = [hname]
                P.inner_doors.append((fs, hname, field_pt, 3.0))
                P.outer_doors.append((os_, hname, out_pt, 3.0))
                r = rect
                along_x = side in ("north", "south")
                # two ticket counters along the long axis, a banner wall
                for k in (0.3, 0.7):
                    c = (r[0] + (r[2] - r[0]) * k, (r[1] + r[3]) / 2) if along_x else ((r[0] + r[2]) / 2, r[1] + (r[3] - r[1]) * k)
                    P.decor.append({"room": hname, "type": "counter", "rect": (c[0] - 2.2, c[1] - 0.4, c[0] + 2.2, c[1] + 0.4)
                                    if along_x else (c[0] - 0.4, c[1] - 2.2, c[0] + 0.4, c[1] + 2.2), "y": F0,
                                    "shader": SP("corl_metal_med_comp_a2sda27")})
            elif kind == "lounge":
                hname = P.room(rect, F0, H1, "lounge", MAT["lounge"], light="lobby")
                g = [hname]
                P.inner_doors.append((fs, hname, field_pt, 3.0))
                P.outer_doors.append((os_, hname, out_pt, 2.4))
                cx, cz = (rect[0] + rect[2]) / 2, (rect[1] + rect[3]) / 2
                P.decor.append({"room": hname, "type": "basin", "rect": (cx - 2.6, cz - 2.6, cx + 2.6, cz + 2.6), "y": F0,
                                "water": SP("corl_fountain_water_aaes23"), "rim": SP("corl_fountain_marble_red_asa15")})
                for dx in (-9.0, 9.0):
                    P.decor.append({"room": hname, "type": "rug", "rect": (cx + dx - 2.5, cz - 2.0, cx + dx + 2.5, cz + 2.0),
                                    "y": F0 + 0.012, "shader": SP("frn_all_rug_nym_aac12")})
            elif kind == "cantina":
                names, entry = P.bsp_rooms(rect, 140.0, "cantina", F0, H1, field_pt,
                                           lambda r: MAT["cantina"] if r == "cantina" else MAT["cargo"])
                g = names
                P.inner_doors.append((fs, entry, field_pt, 2.4))
            elif kind == "market":
                # gallery along the field, four shops behind it
                along_x = side in ("north", "south")
                gal_d = 8.0
                if side == "north":
                    gal = (rect[0], rect[1], rect[2], rect[1] + gal_d)
                    back = (rect[0], rect[1] + gal_d, rect[2], rect[3])
                else:
                    gal = (rect[0], rect[3] - gal_d, rect[2], rect[3])
                    back = (rect[0], rect[1], rect[2], rect[3] - gal_d)
                gname = P.room(gal, F0, H1, "gallery", MAT["spaceport_b"], light="lobby")
                g = [gname]
                n_shop = 4
                step = (back[2] - back[0]) / n_shop
                for i in range(n_shop):
                    sr = (back[0] + i * step, back[1], back[0] + (i + 1) * step, back[3])
                    sname = P.room(sr, F0, H1, "shop", MAT["spaceport"] if i % 2 else MAT["lounge"], light="shop")
                    P.link(gname, sname, width=3.0)
                    wall = sr[1] + 0.6 if side == "south" else sr[3] - 0.6
                    cx = (sr[0] + sr[2]) / 2
                    zz = sr[1] + 1.2 if side == "north" else sr[3] - 1.2
                    P.decor.append({"room": sname, "type": "counter", "rect": (cx - 1.8, zz - 0.3, cx + 1.8, zz + 0.3),
                                    "y": F0, "shader": SP("thed_whitemarble_as9")})
                    g.append(sname)
                P.inner_doors.append((fs, gname, field_pt, 3.0))
            else:
                kind_map = {"security": ("office", 70.0, MAT["office"]), "customs": ("office", 70.0, MAT["office"]),
                            "med": ("office", 45.0, MAT["med"]), "cargo": ("workshop", 150.0, MAT["cargo"]),
                            "workshop": ("workshop", 90.0, MAT["spaceport_b"]), "crew": ("home", 45.0, MAT["quarters"])}
                k, target, mat = kind_map[kind]
                names, entry = P.bsp_rooms(rect, target, k, F0, H1, field_pt, mat)
                g = names
                P.inner_doors.append((fs, entry, field_pt, 2.4))
                if kind in ("security", "customs", "cargo"):
                    oentry = FP.leaf_at([P.rooms[n]["rect"] for n in names], out_pt)
                    P.outer_doors.append((os_, names[oentry], out_pt, 2.4))
            # second floor
            if kind not in ("hangar", "tower"):
                up = UPPER[kind]
                if up == "observation":
                    uname = P.room(rect, F1, H2, "observation", MAT["lounge"], light="observation", windows_side=fs)
                    u = [uname]
                    cx, cz = (rect[0] + rect[2]) / 2, (rect[1] + rect[3]) / 2
                    P.decor.append({"room": uname, "type": "rug", "rect": (cx - 4.0, cz - 3.0, cx + 4.0, cz + 3.0),
                                    "y": F1 + 0.012, "shader": SP("frn_all_rug_senate")})
                elif up == "vip":
                    uname = P.room(rect, F1, H2, "vip", MAT["vip"], light="vip", windows_side=fs)
                    u = [uname]
                else:
                    k, target, mat = {"offices": ("office", 40.0, MAT["office"]), "quarters": ("home", 30.0, MAT["quarters"]),
                                      "control": ("office", 50.0, MAT["spaceport"])}[up]
                    names, _ = P.bsp_rooms(rect, target, k, F1, H2, field_pt, mat,
                                           role_map={"lobby": "control"} if up == "control" else None)
                    u = names
            ground_groups.append(g)
            upper_groups.append(u)
    # walk the ring in order (south west->east, east south->north, north east->west, west north->south), linking
    # each segment to the next on both floors
    order = lambda by: by["south"] + by["east"] + by["north"][::-1] + by["west"][::-1]
    for groups, fy in ((order(ground_by), F0), (order(upper_by), F1)):
        n = len(groups)
        for i in range(n):
            a, b = groups[i], groups[(i + 1) % n]
            if not a or not b:
                continue
            pair = P.best_pair(a, b, fy)
            if pair:
                P.link(pair[0], pair[1], width=2.4, style="arch", y=fy if fy != F0 else None)
    # entrances: field doorways and outside doorways
    fx0, fz0, fx1, fz1 = -W / 2 + RING, -D / 2 + RING, W / 2 - RING, D / 2 - RING
    P.inner_doors = [(fs, room, pt, w) for fs, room, pt, w in P.inner_doors
                     if fx0 + w / 2 + 0.3 <= pt[0] <= fx1 - w / 2 - 0.3 or fs in ("+x", "-x")]
    for fs, room, pt, w in P.inner_doors:
        P.entrances.append({"room": room, "side": fs, "at": list(pt), "width": w, "height": 3.2 if w <= 3 else 5.0})
    for os_, room, pt, w in P.outer_doors:
        P.entrances.append({"room": room, "side": os_, "at": list(pt), "width": w, "height": 3.2,
                            "door_style": "door_corl_metal_s01", "door_hardpoint": True})
    return P, towers


def spec_from(P, name):
    rooms = []
    for nm, v in P.rooms.items():
        m = v["mat"]
        room = {"name": nm, "min": [v["rect"][0], v["rect"][1]], "max": [v["rect"][2], v["rect"][3]],
                "floor_y": v["floor_y"], "height": v["height"],
                "materials": {"wall": {"shader": m["wall"]}, "floor": {"shader": m["floor"]},
                              "ceiling": {"shader": m["ceiling"]}, "trim": {"shader": m["trim"]},
                              "fixture": {"shader": FIXTURE}},
                "light": dict(LIGHT.get(v.get("light") or v["role"], LIGHT["hall"]))}
        for k in ("levels", "elevator"):
            if v.get(k):
                room[k] = v[k]
        r = v["rect"]
        if v.get("windows_side"):
            sd = v["windows_side"]
            along_x = sd in ("+z", "-z")
            lo, hi = (r[0], r[2]) if along_x else (r[1], r[3])
            n = int((hi - lo) // 4.0)
            lst = []
            for i in range(n):
                u = lo + (hi - lo) * (i + 0.5) / n
                at = (u, r[3] if sd == "+z" else r[1]) if along_x else (r[2] if sd == "+x" else r[0], u)
                lst.append({"side": sd, "at": list(at), "width": 2.4, "height": 2.4, "sill": 1.0})
            room["windows"] = {"list": lst, "auto": False}
        if v.get("tower_side"):
            # glass control deck: windows all round the top level
            lst = []
            for sd in ("+x", "-x", "+z", "-z"):
                along_x = sd in ("+z", "-z")
                lo, hi = (r[0], r[2]) if along_x else (r[1], r[3])
                for u in (lo + (hi - lo) * 0.25, lo + (hi - lo) * 0.75):
                    at = (u, r[3] if sd == "+z" else r[1]) if along_x else (r[2] if sd == "+x" else r[0], u)
                    lst.append({"side": sd, "at": list(at), "width": 3.0, "height": 2.4, "sill": TOP - v["floor_y"] + 1.0})
            room["windows"] = {"list": lst, "auto": False}
        obstacles = [list(d["rect"]) for d in P.decor if d["room"] == nm and d["type"] in ("basin", "counter")]
        if obstacles:
            room["obstacles"] = [[a - 0.05, b - 0.05, c + 0.05, e + 0.05] for a, b, c, e in obstacles]
        if v["role"] == "cantina":
            w, d = r[2] - r[0], r[3] - r[1]
            if d >= 10 and w >= 10:      # stage on the wall away from the field doorway (south side: outer wall)
                st = {"min": [r[0] + 2.0, r[1] + 0.4], "max": [r[2] - 2.0, r[1] + 3.0], "height": 0.6,
                      "ramp": {"side": "+z", "width": 1.6, "length": 1.8}}
                room["stages"] = [st]
                P.decor.append({"room": nm, "type": "backdrop", "stage": st, "y": v["floor_y"], "rect": r,
                                "shader": SP("corl_theater_fabric_ad8")})
        rooms.append(room)
    return {
        "name": name, "rooms": rooms, "doors": P.doors, "entrances": P.entrances, "lights": True, "trim": True,
        "flat_terrain": True, "ground_y": 0.0, "collision_meshes": True, "window_portals": True,
        "shell_materials": {"shader": SP("all_concrete_a_fallback_a2d13")},
        "trim_materials": {"shader": SP("spaceport_metl_trim_cs8")},
        "exterior": {"roof": {"shader": SP("all_roof_a_ads16")}, "trim": {"shader": SP("all_trim_c_asb13")},
                     "window": {"color": (0.5, 0.6, 0.75)}},
        "shell_color": (0.62, 0.62, 0.64),
    }


def _ring_points(rect, doors, y):
    """Rectangle outline (CCW in x/z) with the doorway jambs on its edges as extra vertices."""
    x0, z0, x1, z1 = rect
    pts = []
    edges = [((x0, z0), (x1, z0), "-z"), ((x1, z0), (x1, z1), "+x"), ((x1, z1), (x0, z1), "+z"), ((x0, z1), (x0, z0), "-x")]
    for a, b, sd in edges:
        pts.append((a[0], y, a[1]))
        ts = []
        for dsd, pt, w in doors:
            if dsd != sd:
                continue
            along_x = sd in ("+z", "-z")
            u = pt[0] if along_x else pt[1]
            for uu in (u - w / 2, u + w / 2):
                full = (b[0] - a[0]) if along_x else (b[1] - a[1])
                t = (uu - (a[0] if along_x else a[1])) / full
                if 0 < t < 1:
                    ts.append(t)
        for t in sorted(ts):
            pts.append((a[0] + (b[0] - a[0]) * t, y, a[1] + (b[1] - a[1]) * t))
    return pts


def build(name="titan_atmo_starport", export_root="D:/exported"):
    cmds.file(new=True, force=True)
    P, towers = plan()
    spec = spec_from(P, name)
    out = pb.build(spec, new_scene=False)
    root = out["root"]
    # field floor (doorway jambs on its edges) and the outside skirt around the ring
    field = (-W / 2 + RING, -D / 2 + RING, W / 2 - RING, D / 2 - RING)
    field_doors = []
    for fs, room, pt, w in P.inner_doors:
        # the field floor edge faces the hall: its side is the opposite of the hall's field side
        field_doors.append(({"-z": "+z", "+z": "-z", "-x": "+x", "+x": "-x"}[fs], pt, w))
    ring = _ring_points(field, field_doors, F0)
    floor_grp = f"{root}|r0|collision|floor0"
    f1 = pb._facet_mesh([(ring, [])], "field_floor", floor_grp, up=True)
    outer = (-W / 2, -D / 2, W / 2, D / 2)
    hole = _ring_points(outer, [(sd, pt, w) for sd, room, pt, w in P.outer_doors], F0)
    pad = 4.0
    rim = [(outer[0] - pad, F0, outer[1] - pad), (outer[2] + pad, F0, outer[1] - pad),
           (outer[2] + pad, F0, outer[3] + pad), (outer[0] - pad, F0, outer[3] + pad)]
    f2 = pb._facet_mesh([(rim, [hole])], "outside_skirt", floor_grp, up=True)
    for m in (f1, f2):
        cmds.sets(m, edit=True, forceElement="initialShadingGroup")
        pb._hide_helper(m)
    # landing pads on the field: deck + kerb (render only; ships and players walk the field floor)
    deck = pb.MeshAccumulator(fit=True)
    kerb = pb.MeshAccumulator(2.0)
    fx0, fz0, fx1, fz1 = field
    pw, gap_x = 18.0, ((fx1 - fx0) - 4 * 18.0) / 5
    gap_z = ((fz1 - fz0) - 2 * 18.0) / 3
    for row in range(2):
        for col in range(4):
            x0 = fx0 + gap_x + col * (pw + gap_x)
            z0 = fz0 + gap_z + row * (pw + gap_z)
            x1, z1, y = x0 + pw, z0 + pw, F0 + 0.03
            deck.facing([(x0, y, z0), (x1, y, z0), (x1, y, z1), (x0, y, z1)], (0, 1, 0))
            for a, b, nrm in (((x0, z0), (x1, z0), (0, 0, -1)), ((x1, z0), (x1, z1), (1, 0, 0)),
                              ((x1, z1), (x0, z1), (0, 0, 1)), ((x0, z1), (x0, z0), (-1, 0, 0))):
                kerb.facing([(a[0], F0, a[1]), (b[0], F0, b[1]), (b[0], y, b[1]), (a[0], y, a[1])], nrm)
    mg = f"{root}|r0|mesh"
    for acc, nm, sh in ((deck, "landing_pads", PAD_DECK), (kerb, "landing_pad_kerbs", PAD_SIDE)):
        m = acc.build(nm, mg)
        cmds.sets(m, edit=True, forceElement=pb._material(f"swg_{name}_{nm}", (0.5, 0.5, 0.52), None, sh))
    field_paving = pb._facet_mesh([([(p[0], F0 + 0.01, p[2]) for p in ring], [])], "field_paving", mg, up=True, uv_scale=6.0)
    cmds.sets(field_paving, edit=True, forceElement=pb._material(f"swg_{name}_paving", (0.55, 0.55, 0.55), None,
                                                                SP("all_concrete_b_fallback_a2d13")))
    decor = FP.build_decor(root, P.decor, out["rooms"], name)
    exp = pb.export(root, export_root, name)
    return {"root": root, "cells": out["cells"], "rooms": len(P.rooms), "decor": decor, "export": exp,
            "towers": towers, "entrances": len(P.entrances)}
