"""SwgMayaMCP bridge — runs inside Maya and executes requests from the MCP server.

Protocol: one JSON object per line over TCP (localhost only).
    request : {"id": 1, "lang": "python" | "mel", "code": "...", "args": {...}}
    response: {"id": 1, "ok": true, "result": <json>, "stdout": "...", "stderr": "...",
               "error": "...", "traceback": "..."}

Python requests run in a persistent namespace (cmds, mel, om, args are pre-bound). Assign to `result`
to return a value. Everything executes on Maya's main thread.

GUI Maya (Script Editor or userSetup.py):
    import swg_mcp.bridge; swg_mcp.bridge.start()          # 127.0.0.1:7020
Headless (spawned by the MCP server automatically, or by hand):
    mayapy bridge.py --standalone --port 7021
"""

from __future__ import annotations

import io
import json
import os
import queue
import socket
import sys
import tempfile
import threading
import time
import traceback

DEFAULT_PORT = 7020
_server = None


def _jsonable(value):
    try:
        json.dumps(value)
        return value
    except TypeError:
        if isinstance(value, (list, tuple, set)):
            return [_jsonable(v) for v in value]
        if isinstance(value, dict):
            return {str(k): _jsonable(v) for k, v in value.items()}
        return repr(value)


class _Executor:
    """Runs requests; owns the persistent namespace."""

    def __init__(self, capture_native_stderr: bool):
        import maya.cmds as cmds
        import maya.mel as mel
        import maya.api.OpenMaya as om

        self.namespace = {"cmds": cmds, "mel": mel, "om": om, "__name__": "__swg_mcp__"}
        # Plug-in diagnostics go to std::cerr; in mayapy we can capture them at the fd level.
        self.capture_native_stderr = capture_native_stderr

    def run(self, request: dict) -> dict:
        lang = request.get("lang", "python")
        code = request.get("code", "")
        out, err = io.StringIO(), io.StringIO()
        response = {"id": request.get("id"), "ok": True, "result": None}
        native = _NativeStderr() if self.capture_native_stderr else None
        old_out, old_err = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = out, err
        try:
            if native:
                native.__enter__()
            if lang == "mel":
                import maya.mel as mel
                response["result"] = _jsonable(mel.eval(code))
            else:
                ns = self.namespace
                ns["args"] = request.get("args") or {}
                ns.pop("result", None)
                exec(compile(code, "<swg_mcp>", "exec"), ns)
                response["result"] = _jsonable(ns.get("result"))
        except Exception as exc:  # report, never kill the bridge
            response.update(ok=False, error=f"{type(exc).__name__}: {exc}", traceback=traceback.format_exc())
        finally:
            sys.stdout, sys.stderr = old_out, old_err
            native_text = native.__exit__() if native else ""
        response["stdout"] = out.getvalue()[-20000:]
        response["stderr"] = (err.getvalue() + native_text)[-20000:]
        return response


class _NativeStderr:
    """Redirect fd 2 (C++ std::cerr from the plug-in) into a temp file for the duration of a request."""

    def __enter__(self):
        sys.__stderr__.flush()
        self._tmp = tempfile.TemporaryFile(mode="w+b")
        self._saved = os.dup(2)
        os.dup2(self._tmp.fileno(), 2)
        return self

    def __exit__(self, *exc) -> str:
        try:
            sys.__stderr__.flush()
        except Exception:
            pass
        os.dup2(self._saved, 2)
        os.close(self._saved)
        self._tmp.seek(0)
        text = self._tmp.read().decode("utf-8", "replace")
        self._tmp.close()
        return text


class BridgeServer:
    def __init__(self, port: int, dispatch):
        self.port = port
        self._dispatch = dispatch
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind(("127.0.0.1", port))
        self._sock.listen(4)
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._accept_loop, name="swg_mcp_bridge", daemon=True)

    def start(self):
        self._thread.start()

    def stop(self):
        self._stop.set()
        try:
            self._sock.close()
        except OSError:
            pass

    def _accept_loop(self):
        while not self._stop.is_set():
            try:
                conn, _ = self._sock.accept()
            except OSError:
                return
            threading.Thread(target=self._client_loop, args=(conn,), daemon=True).start()

    def _client_loop(self, conn: socket.socket):
        buf = b""
        with conn:
            while not self._stop.is_set():
                try:
                    data = conn.recv(65536)
                except OSError:
                    return
                if not data:
                    return
                buf += data
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if not line.strip():
                        continue
                    try:
                        request = json.loads(line)
                    except ValueError as exc:
                        response = {"ok": False, "error": f"bad request: {exc}"}
                    else:
                        if request.get("lang") == "ping":
                            response = {"id": request.get("id"), "ok": True, "result": _ping_info()}
                        else:
                            response = self._dispatch(request)
                    try:
                        conn.sendall(json.dumps(response).encode("utf-8") + b"\n")
                    except OSError:
                        return


def _ping_info() -> dict:
    info = {"pid": os.getpid(), "standalone": _STANDALONE, "port": _server.port if _server else None}
    return info


_STANDALONE = False


def start(port: int | None = None) -> int:
    """Start the bridge inside an interactive Maya session (idempotent). Returns the port."""
    global _server
    if _server is not None:
        return _server.port
    import maya.utils

    port = port or int(os.environ.get("SWG_MAYA_MCP_PORT", DEFAULT_PORT))
    executor = _Executor(capture_native_stderr=False)

    def dispatch(request):
        return maya.utils.executeInMainThreadWithResult(executor.run, request)

    _server = BridgeServer(port, dispatch)
    _server.start()
    print(f"// SwgMayaMCP bridge listening on 127.0.0.1:{port}")
    return port


def stop():
    global _server
    if _server is not None:
        _server.stop()
        _server = None


def _run_standalone(port: int):
    """mayapy entry point: Maya runs on this (main) thread; socket threads hand work over a queue."""
    global _server, _STANDALONE
    _STANDALONE = True
    import maya.standalone

    maya.standalone.initialize(name="python")
    executor = _Executor(capture_native_stderr=True)
    jobs: "queue.Queue[tuple[dict, queue.Queue]]" = queue.Queue()

    def dispatch(request):
        reply: queue.Queue = queue.Queue(maxsize=1)
        jobs.put((request, reply))
        return reply.get()

    _server = BridgeServer(port, dispatch)
    _server.start()
    print(f"SWG_MCP_BRIDGE_READY port={port}", flush=True)
    parent = int(os.environ.get("SWG_MAYA_MCP_PARENT_PID", "0"))
    try:
        while True:
            try:
                request, reply = jobs.get(timeout=2.0)
            except queue.Empty:
                if parent and not _pid_alive(parent):
                    break  # MCP server went away; don't linger
                continue
            if request.get("lang") == "shutdown":
                reply.put({"id": request.get("id"), "ok": True, "result": "bye"})
                break
            reply.put(executor.run(request))
    finally:
        _server.stop()
        try:
            maya.standalone.uninitialize()
        except Exception:
            pass


def _pid_alive(pid: int) -> bool:
    if sys.platform == "win32":
        import ctypes

        handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(handle)
        return code.value == 259  # STILL_ACTIVE
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="SwgMayaMCP bridge")
    parser.add_argument("--standalone", action="store_true", help="initialize maya.standalone (mayapy)")
    parser.add_argument("--port", type=int, default=int(os.environ.get("SWG_MAYA_MCP_PORT", DEFAULT_PORT)))
    ns = parser.parse_args()
    # make `import swg_mcp.*` work when launched by path
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if not ns.standalone:
        parser.error("outside of an interactive Maya session use --standalone")
    _run_standalone(ns.port)
