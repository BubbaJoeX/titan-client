"""Door-driven floor plans, room roles, lighting and decor for stock filler shells (see filler.py).

Every painted ground-level door of the stock shell becomes a real entrance. A tower gets one lobby that wraps an
elevator core and reaches all its doors, with corridor apartments above; a building with several doors is split
into units (shop, flat, cantina, workshop), one per door; a building with one door fills its whole free footprint.
Units big enough get a corridor spine like the stock interiors: a foyer at the door, a hallway (stock hall widths and
materials) with rooms off both sides and an end room, some curved (apse end walls, rounded outer corners); smaller
units fall back to a binary space partition. Every room meets the minimum sizes below and gets a role that picks its
light palette, floor material and decor: rugs, tapestries, curtains, fountain basins, glass-topped counters, a
cantina stage, domed halls.
All coordinates are Maya world space (x, z plan); every rectangle is (x0, z0, x1, z1)."""

from __future__ import annotations

import math
import os

import maya.cmds as cmds

from . import pob_builder
from . import filler as F

DOOR_W, DOOR_H = 2.4, 3.4          # fits every stock door leaf (<= 2.2 x 3.32) with its clearance
# Minimum sizes, measured over the stock interiors (6492 cells): rooms p10 min side 4.5 m / area 38 m2 (p5 22 m2),
# hallways 1.9-2.5 m wide in player houses, 2.7-3.7 m in municipal buildings. Plans never go below these.
MIN_ROOM = 3.5                 # smallest room side
MIN_AREA = 16.0                # smallest room area
MIN_HALL = 2.0                 # narrowest hallway
HALL_W = {"home": 2.25, "apartment": 2.25, "parlor": 2.5, "shop": 2.75, "office": 3.0}    # hallway width by unit kind
WALL = 0.35                    # wall thickness: the thickest door leaf (0.215) + 6 cm each side (pob_builder)
PASS = 1.9                     # shared wall needed for an interior doorway

THEME_DECOR = {
    "tato": {"rug": "shader/frn_all_tcg_rug_s01_aa7.sht", "hanging": "shader/frn_all_tapestry_efol21_scenary_s01.sht",
             "curtain": "shader/thm_tatt_watto_drape_cs6.sht", "stage_cloth": "shader/camo_tato_theater_fabric_ad8.sht",
             "carpet": "shader/floor_carpet_sand.sht", "tile": "shader/tato_concreteb_asb13.sht",
             "counter": "shader/tato_concreteb_asb13.sht", "basin": None, "rim": None,
             "private_arch": True},
    "corl": {"rug": "shader/frn_all_rug_nym_aac12.sht", "hanging": "shader/corellia_bannera_ad8.sht",
             "curtain": "shader/corl_theater_fabric_ad8.sht", "stage_cloth": "shader/corl_theater_fabric_ad8.sht",
             "carpet": "shader/floor_carpet_teal.sht", "tile": "shader/ply_corl_floor_a_cs9.sht",
             "counter": "shader/corl_metal_med_comp_a2sda27.sht", "basin": "shader/corl_fountain_water_aaes23.sht",
             "rim": "shader/corl_fountain_marble_red_asa15.sht", "private_arch": False},
    "nboo": {"rug": "shader/frn_all_rug_senate.sht", "hanging": "shader/banner_theed_palace.sht",
             "curtain": "shader/naboo_curtains_cpd17.sht", "stage_cloth": "shader/naboo_curtains_cpd17.sht",
             "carpet": "shader/floor_carpet_blue.sht", "tile": "shader/thed_tile_floorb_asb13.sht",
             "counter": "shader/thed_whitemarble_as9.sht", "basin": "shader/corl_fountain_water_ripple_ae9.sht",
             "rim": "shader/thed_whitemarble_as9.sht", "private_arch": True},
}
# interior material palettes per theme and style, mined from the stock interiors of each planet's buildings;
# each entry lists alternatives (a unit picks one variant, rooms vary floors by role)
def _sh(*names):
    return ["shader/" + n + ".sht" for n in names]


STYLES = {
    "tato": {
        "home": {"wall": _sh("tatt_stco_player_wall_fallback_c2d13", "tatt_stco_player_wall_dirt_cd8"),
                 "floor": _sh("tatt_stco_player_floor_cs8", "tatt_stco_player_floor_b_fallback_c2d13"),
                 "ceiling": _sh("tatt_stco_player_ceiling_cs8", "thm_tatt_jabba_inner_ceila_c2d13"),
                 "trim": _sh("tato_trimb_cs8", "stco_cantina_trim_cs8")},
        "commerce": {"wall": _sh("despot_metl_panel_ce9", "metl_brown_rough_cs8", "tatt_stco_player_wall_dirt_cd8"),
                     "floor": _sh("despot_metl_floor_panel2_cs9", "despot_metl_floor_panel3_cs9", "tatt_stco_player_floor_cs8"),
                     "ceiling": _sh("despot_intr_ceiling_cs9", "despot_intr_ceiling_a1_cs9"),
                     "trim": _sh("despot_intr_tech_trim_ce9", "tato_trimb_cs8")},
        "cantina": {"wall": _sh("tatt_stco_player_wall_dirt_cd8"), "floor": _sh("stco_cantina_floor_grate_cs8"),
                    "ceiling": _sh("despot_intr_ceiling_a1_cs9"), "trim": _sh("stco_cantina_trim_cs8")},
        "office": {"wall": _sh("despot_tech_wall_cs9", "despot_metal_panel_square_cs9"),
                   "floor": _sh("intr_tech_floorb_cs8", "despot_metl_floor_base_cs9"),
                   "ceiling": _sh("intr_tech_ceilinga_cs8"), "trim": _sh("intr_tech_trimb_cs8")},
        "utility": {"wall": _sh("rock_cave_gray_walla_sloped_cs8", "metl_brown_rough_cs8"),
                    "floor": _sh("rock_cave_gray_floora_cs8", "tatt_tusken_rock_floor_cs8"),
                    "ceiling": _sh("tatt_tusken_rock_ceiling_cs8", "despot_intr_ceiling_cs9"), "trim": _sh("tato_trimb_cs8")},
        "lobby": {"wall": _sh("tatt_stco_player_wall_fallback_c2d13"), "floor": _sh("tatt_stco_player_floor_b_fallback_c2d13"),
                  "ceiling": _sh("thm_tatt_jabba_inner_ceila_c2d13"), "trim": _sh("stco_cantina_trim_cs8")},
        "hall": {"wall": _sh("tatt_stco_player_wall_fallback_c2d13", "despot_tech_wall_cs9"),
                 "floor": _sh("metl_watto_grate_cs9", "despot_metl_floor_panel3_cs9"),
                 "ceiling": _sh("tatt_stco_player_ceiling_cs8", "despot_intr_ceiling_a1_cs9"),
                 "trim": _sh("metl_jnkshp_trim_cs8", "despot_metl_trim_cs9")},
    },
    "corl": {
        "home": {"wall": _sh("ply_corl_stucco_fallback_c2d13", "ply_corl_stucco_fallback_c2d15", "z_intr_assoc_stucco_fallback_c2d13"),
                 "floor": _sh("ply_corl_floor_a_cs9", "ply_corl_ranch_marble"),
                 "ceiling": _sh("ply_corl_ceiling_a_cs8"), "trim": _sh("ply_corl_accent_c_cs8", "intr_hoteltrim_cs8")},
        "commerce": {"wall": _sh("z_intr_commerce_wall_a_cd8", "z_intr_assoc_wall_gloss_ces17"),
                     "floor": _sh("intr_cptl_floor_cs8", "corl_metal_dark_tiled_a2sda29_phong"),
                     "ceiling": _sh("intr_hotel_ceiling_a1_cs8", "ply_corl_ceiling_a_cs8"), "trim": _sh("intr_cptl_trim_cs8")},
        "cantina": {"wall": _sh("corl_stco_cantina_wall_fallback_c2d13"),
                    "floor": _sh("corl_metl_cantina_floor_cds16", "corl_stco_cantina_floor_grate_cs8"),
                    "ceiling": _sh("z_intr_tech_ceilinga_cs8"), "trim": _sh("corl_stco_cantina_trim_cs8")},
        "office": {"wall": _sh("z_intr_tech_wall_panelb_cs8", "z_intr_tech_wall_flata_cs8"),
                   "floor": _sh("intr_tech_floorb_cs8", "intr_cptl_floor_cs8"),
                   "ceiling": _sh("z_intr_tech_ceilinga_cs8"), "trim": _sh("intr_tech_trimb_cs8")},
        "utility": {"wall": _sh("corellia_concrete_b_cs10"), "floor": _sh("corl_stco_cantina_floor_grate_cs8"),
                    "ceiling": _sh("intr_tech_ceilinga_cs8"), "trim": _sh("intr_tech_trimb_cs8")},
        "lobby": {"wall": _sh("z_intr_assoc_marble_white_gloss_ces17", "z_intr_assoc_marbleblack_gloss_ces17",
                              "z_intr_assoc_marblered_ces17"),
                  "floor": _sh("corl_metal_dark_tiled_a2sda29_phong", "intr_cptl_floor_cs8"),
                  "ceiling": _sh("intr_hotel_ceiling_a1_cs8"), "trim": _sh("intr_hoteltrim_cs8")},
        "bath": {"wall": _sh("intr_medicalwall_tech_b_cd8"), "floor": _sh("hospital_floor_grey_cd8_phong", "intr_medicalfloor_fallback_cs8"),
                 "ceiling": _sh("hospital_ceiling_a_cd8"), "trim": _sh("intr_tech_trimb_cs8")},
        "hall": {"wall": _sh("ply_corl_stucco_fallback_c2d13", "intr_cptl_marble_a1_cs8"),
                 "floor": _sh("ply_corl_floor_a_cs9", "intr_tech_floorb_cs8"),
                 "ceiling": _sh("ply_corl_ceiling_a_cs8"), "trim": _sh("corellia_verticala_trim_cds16", "intr_cptl_marble_trim_cs8")},
    },
    "nboo": {
        "home": {"wall": _sh("ply_nboo_marblewhite_ces17", "thed_stone_deco_cs8", "z_intr_assoc_stucco_fallback_c2d13"),
                 "floor": _sh("ply_nboo_marblefloordec_ces17", "thed_marble_floor_lighta_cs8"),
                 "ceiling": _sh("intr_hotel_ceiling_a1_cs8"), "trim": _sh("thed_palace_trim_a1_cs8", "naboo_trim_a1_cs8")},
        "commerce": {"wall": _sh("z_intr_assoc_wall_gloss_ces17", "z_intr_assoc_stucco_fallback_c2d13"),
                     "floor": _sh("ply_nboo_marblefloortrim_cs8", "thed_marble_floor_lighta_cs8"),
                     "ceiling": _sh("intr_hotel_ceiling_a1_cs8"), "trim": _sh("intr_hoteltrim_cs8")},
        "cantina": {"wall": _sh("nboo_stco_cantina_wall_fallback_c2d13", "nboo_stco_cantina_wall_white_fallback_c2d13"),
                    "floor": _sh("nboo_metl_cantina_floor_cds16", "nboo_metl_cantina_floor_b_cds16"),
                    "ceiling": _sh("z_intr_tech_ceilinga_cs8"), "trim": _sh("naboo_trim_a1_cs8")},
        "office": {"wall": _sh("z_intr_assoc_wall_gloss_ces17"), "floor": _sh("ply_nboo_marblefloortrim_cs8"),
                   "ceiling": _sh("intr_tech_ceilinga_cs8"), "trim": _sh("intr_cptl_trim_cs8")},
        "utility": {"wall": _sh("thed_stone_deco_cs8"), "floor": _sh("thed_tile_floorb_asb13"),
                    "ceiling": _sh("intr_tech_ceilinga_cs8"), "trim": _sh("naboo_trim_a1_cs8")},
        "lobby": {"wall": _sh("nboo_intr_palace_marble_grey_ce9", "nboo_intr_throne_marble_red_cd8"),
                  "floor": _sh("nboo_intr_palace_floor_ce9", "nboo_intr_throne_floor_ce9"),
                  "ceiling": _sh("intr_hotel_ceiling_a1_cs8"), "trim": _sh("thed_palace_trim_a1_cs8")},
        "bath": {"wall": _sh("z_intr_assoc_marble_white_gloss_ces17"), "floor": _sh("thed_tile_floorb_asb13"),
                 "ceiling": _sh("intr_hotel_ceiling_a1_cs8"), "trim": _sh("thed_palace_trim_a1_cs8")},
        "hall": {"wall": _sh("thed_stone_deco_cs8", "ply_nboo_marblewhite_ces17"),
                 "floor": _sh("ply_nboo_marblefloortrim_cs8", "thed_marble_floor_lighta_cs8"),
                 "ceiling": _sh("intr_hotel_ceiling_a1_cs8"), "trim": _sh("thed_palace_trim_a1_cs8", "thed_overarch_cs8")},
    },
}
ROLE_STYLE = {"hall": "home", "kitchen": "home", "bedroom": "home", "study": "home", "parlor": "home", "bath": "bath",
              "shop": "commerce", "cantina": "cantina", "office": "office", "lobby": "lobby", "corridor": "hall",
              "storage": "utility", "workshop": "utility", "vestibule": "lobby", "stair": "home"}
CARPETS = {"tato": _sh("tatt_stco_player_floor_b_fallback_c2d13"), "corl": _sh("floor_carpet_teal", "floor_carpet_brown", "floor_carpet_red"),
           "nboo": _sh("ply_nboo_carpetred_cd8", "ply_nboo_carpetteal_cd8", "ply_nboo_carpetblue_cd8")}

# Coherent interior palettes, each one stock interior family (player houses, hotels/commerce, tech offices,
# industrial, cantinas): every room of a unit - hallways included - takes the unit's set, and wet rooms only swap
# the floor for that family's tile. Mixing families per room (stucco + tech panels + hospital tile + carpet)
# clashed. "wet" = bath/kitchen floor.
def _set(wall, floor, ceiling, trim, wet=None):
    return {"wall": "shader/" + wall + ".sht", "floor": "shader/" + floor + ".sht", "ceiling": "shader/" + ceiling + ".sht",
            "trim": "shader/" + trim + ".sht", "wet": "shader/" + (wet or floor) + ".sht"}


PALETTES = {
    "tato": {"home": _set("tatt_stco_player_wall_fallback_c2d13", "tatt_stco_player_floor_cs8", "tatt_stco_player_ceiling_cs8",
                          "tato_trimb_cs8", "tatt_stco_player_floor_b_fallback_c2d13"),
             "commerce": _set("despot_tech_wall_cs9", "despot_metl_floor_panel3_cs9", "despot_intr_ceiling_a1_cs9",
                              "despot_metl_trim_cs9", "despot_metl_floor_base_cs9"),
             "cantina": _set("tatt_stco_player_wall_dirt_cd8", "stco_cantina_floor_grate_cs8", "tatt_stco_player_ceiling_cs8",
                             "stco_cantina_trim_cs8")},
    "corl": {"home": _set("ply_corl_stucco_fallback_c2d13", "ply_corl_floor_a_cs9", "ply_corl_ceiling_a_cs8",
                          "ply_corl_accent_c_cs8", "ply_corl_ranch_marble"),
             "commerce": _set("z_intr_assoc_wall_gloss_ces17", "intr_cptl_floor_cs8", "intr_hotel_ceiling_a1_cs8",
                              "intr_hoteltrim_cs8"),
             "office": _set("z_intr_tech_wall_panelb_cs8", "intr_tech_floorb_cs8", "z_intr_tech_ceilinga_cs8", "intr_tech_trimb_cs8"),
             "cantina": _set("corl_stco_cantina_wall_fallback_c2d13", "corl_metl_cantina_floor_cds16", "z_intr_tech_ceilinga_cs8",
                             "corl_stco_cantina_trim_cs8")},
    "nboo": {"home": _set("ply_nboo_marblewhite_ces17", "ply_nboo_marblefloordec_ces17", "intr_hotel_ceiling_a1_cs8",
                          "thed_palace_trim_a1_cs8", "ply_nboo_marblefloortrim_cs8"),
             "commerce": _set("thed_stone_deco_cs8", "thed_marble_floor_lighta_cs8", "intr_hotel_ceiling_a1_cs8",
                              "naboo_trim_a1_cs8", "ply_nboo_marblefloortrim_cs8"),
             "office": _set("nboo_intr_palace_marble_grey_ce9", "nboo_intr_palace_floor_ce9", "intr_hotel_ceiling_a1_cs8",
                            "thed_palace_trim_a1_cs8"),
             "cantina": _set("nboo_stco_cantina_wall_fallback_c2d13", "nboo_metl_cantina_floor_cds16", "intr_hotel_ceiling_a1_cs8",
                             "naboo_trim_a1_cs8")},
}
# unit kind -> palette (falls back to "home")
KIND_PALETTE = {"home": "home", "apartment": "home", "parlor": "home", "shop": "commerce", "workshop": "commerce",
                "office": "office", "cantina": "cantina"}

GLASS = "shader/all_glass_a_aa7.sht"
SLUM_CLOTH = "shader/fabric_canvas_scummy_a_as8.sht"

# light palettes by room role (stock-like: tinted ambient + warm/cool point lights, same overall level as stock)
ROLE_LIGHT = {
    "lobby": {"ambient": 1.0, "ambient_rgb": (0.36, 0.36, 0.40), "rgb": (1.0, 0.95, 0.86), "intensity": 1.15},
    "hall": {"ambient": 1.0, "ambient_rgb": (0.40, 0.36, 0.32), "rgb": (1.0, 0.86, 0.66), "intensity": 1.0},
    "parlor": {"ambient": 1.0, "ambient_rgb": (0.40, 0.35, 0.31), "rgb": (1.0, 0.84, 0.62), "intensity": 1.0},
    "shop": {"ambient": 1.0, "ambient_rgb": (0.40, 0.40, 0.40), "rgb": (1.0, 0.97, 0.90), "intensity": 1.3},
    "cantina": {"ambient": 1.0, "ambient_rgb": (0.22, 0.20, 0.28), "rgb": (1.0, 0.62, 0.36), "intensity": 1.2},
    "bedroom": {"ambient": 1.0, "ambient_rgb": (0.30, 0.27, 0.26), "rgb": (1.0, 0.78, 0.55), "intensity": 0.85},
    "bath": {"ambient": 1.0, "ambient_rgb": (0.38, 0.42, 0.45), "rgb": (0.85, 0.95, 1.0), "intensity": 0.9},
    "kitchen": {"ambient": 1.0, "ambient_rgb": (0.38, 0.37, 0.35), "rgb": (1.0, 0.95, 0.85), "intensity": 1.0},
    "office": {"ambient": 1.0, "ambient_rgb": (0.34, 0.37, 0.44), "rgb": (0.85, 0.92, 1.0), "intensity": 1.05},
    "study": {"ambient": 1.0, "ambient_rgb": (0.34, 0.33, 0.33), "rgb": (1.0, 0.88, 0.70), "intensity": 0.9},
    "storage": {"ambient": 1.0, "ambient_rgb": (0.28, 0.28, 0.28), "rgb": (0.95, 0.90, 0.75), "intensity": 0.8},
    "workshop": {"ambient": 1.0, "ambient_rgb": (0.32, 0.32, 0.32), "rgb": (0.95, 0.95, 0.88), "intensity": 1.1},
    "corridor": {"ambient": 1.0, "ambient_rgb": (0.33, 0.33, 0.35), "rgb": (1.0, 0.93, 0.80), "intensity": 0.9},
    "lift": {"ambient": 1.0, "ambient_rgb": (0.32, 0.36, 0.42), "rgb": (0.70, 0.90, 1.0), "intensity": 1.0},
    "vestibule": {"ambient": 1.0, "ambient_rgb": (0.36, 0.35, 0.34), "rgb": (1.0, 0.92, 0.80), "intensity": 0.9},
}
PRIVATE = {"bedroom", "bath", "office", "study"}


class Rand(F._Rand):
    def uniform(self, a, b):
        return a + (b - a) * self.next(1000) / 1000.0

    def choice(self, seq):
        return seq[self.next(len(seq))]


def q4(v):
    return round(v * 4) / 4


def rect_poly(r):
    return [[r[0], r[1]], [r[2], r[1]], [r[2], r[3]], [r[0], r[3]]]


def area(r):
    return (r[2] - r[0]) * (r[3] - r[1])


def shared(a, b):
    """Shared wall of two touching rectangles: (axis, coord, lo, hi) with overlap hi - lo, or None."""
    eps = 1e-3
    for ax, (a0, a1, b0, b1, o0, o1, p0, p1) in (
            (0, (a[0], a[2], b[0], b[2], a[1], a[3], b[1], b[3])),    # wall at constant x
            (1, (a[1], a[3], b[1], b[3], a[0], a[2], b[0], b[2]))):   # wall at constant z
        for c in ((a1, b0), (a0, b1)):
            if abs(c[0] - c[1]) < eps:
                lo, hi = max(o0, p0), min(o1, p1)
                if hi - lo > eps:
                    return ax, c[0], lo, hi
    return None


# ============================================================================
# doors painted on the stock shell
# ============================================================================

def find_doors(tris, grid, bbox, f_guess=0.15):
    """Ground-level painted doors: clusters of door-shader triangles about door sized, on a vertical facade
    plane, with the side they face (toward the outside of the shell)."""
    door_tris = [t for t in tris if "door" in t[3].lower() and "window" not in t[3].lower()]
    clusters = []
    for t in door_tris:
        c = [sum(p[k] for p in t[:3]) / 3 for k in range(3)]
        for g in clusters:
            if any(abs(c[0] - q[0]) < 1.5 and abs(c[2] - q[2]) < 1.5 and abs(c[1] - q[1]) < 4 for q in g["pts"]):
                g["pts"].append(c)
                g["tris"].append(t)
                break
        else:
            clusters.append({"pts": [c], "tris": [t]})
    inside = F.interior_mask(tris, grid, f_guess + 1.2, dilate=1, erode=0)

    def is_inside(x, z):
        i, j = grid.cell(x, z)
        return 0 <= i < grid.nx and 0 <= j < grid.nz and inside[i][j]

    out = []
    for g in clusters:
        vs = [p for t in g["tris"] for p in t[:3]]
        lo = [min(v[k] for v in vs) for k in range(3)]
        hi = [max(v[k] for v in vs) for k in range(3)]
        h = hi[1] - lo[1]
        dx, dz = hi[0] - lo[0], hi[2] - lo[2]
        if not (2.0 <= h <= 8.0 and lo[1] < 2.2 and min(dx, dz) < 0.35 and 0.8 <= max(dx, dz) <= 3.6):
            continue                                 # balcony doors, antenna caps, whole-texture shaders
        c = ((lo[0] + hi[0]) / 2, (lo[2] + hi[2]) / 2)
        if dx < dz:          # plane x = const
            cands = {"+x": (c[0] + 1.2, c[1]), "-x": (c[0] - 1.2, c[1])}
        else:
            cands = {"+z": (c[0], c[1] + 1.2), "-z": (c[0], c[1] - 1.2)}
        outside = [s for s, p in cands.items() if not is_inside(*p)]
        if len(outside) == 1:
            side = outside[0]
        else:                # both or neither: the nearer face of the building box
            gaps = {"-x": c[0] - bbox[0], "+x": bbox[3] - c[0], "-z": c[1] - bbox[2], "+z": bbox[5] - c[1]}
            side = min((s for s in cands), key=gaps.get)
        ax_u = 0 if dx >= dz else 2
        out.append({"c": c, "side": side, "bottom": lo[1], "width": max(dx, dz), "top": hi[1],
                    "outline": door_outline(g["tris"], ax_u)})
    return out


def door_outline(tris, ax_u):
    """Outer boundary loop of a painted door's triangles in its plane, as [(u, y)] (u = world x or z)."""
    key = lambda p: (round(p[ax_u], 3), round(p[1], 3))
    count = {}
    for t in tris:
        ks = [key(p) for p in t[:3]]
        for i in range(3):
            a, b = ks[i], ks[(i + 1) % 3]
            if a == b:
                continue
            e = (a, b) if a < b else (b, a)
            count[e] = count.get(e, 0) + 1
    edges = [e for e, n in count.items() if n == 1]
    nbr = {}
    for a, b in edges:
        nbr.setdefault(a, []).append(b)
        nbr.setdefault(b, []).append(a)
    loops, seen = [], set()
    for start in nbr:
        if start in seen:
            continue
        loop, prev, cur = [start], None, start
        seen.add(start)
        while True:
            nxt = [q for q in nbr[cur] if q != prev and (q not in seen or (q == start and len(loop) > 2))]
            if not nxt:
                break
            q = nxt[0]
            if q == start:
                break
            loop.append(q)
            seen.add(q)
            prev, cur = cur, q
        if len(loop) >= 3:
            loops.append(loop)
    if not loops:
        return None
    per = lambda L: sum(math.hypot(L[i][0] - L[i - 1][0], L[i][1] - L[i - 1][1]) for i in range(len(L)))
    return [list(p) for p in max(loops, key=per)]


def fit_doorway(outline, uc, y_floor, want_w=DOOR_W, want_h=DOOR_H):
    """Largest doorway (width, height) centred on uc that stays inside a painted door outline."""
    if not outline:
        return want_w, want_h
    us = [p[0] for p in outline]
    w = min(want_w, (min(uc - min(us), max(us) - uc)) * 2 - 0.12)

    def top_at(u):          # lowest outline crossing above the floor at this u
        ys = []
        for i in range(len(outline)):
            (u0, y0), (u1, y1) = outline[i - 1], outline[i]
            if (u0 - u) * (u1 - u) <= 0 and u0 != u1:
                y = y0 + (y1 - y0) * (u - u0) / (u1 - u0)
                if y > y_floor + 1.0:
                    ys.append(y)
        return min(ys) if ys else y_floor + want_h
    h = min(top_at(uc - w / 2 + 0.02), top_at(uc), top_at(uc + w / 2 - 0.02)) - y_floor - 0.06
    return max(1.1, round(w, 2)), max(2.2, min(want_h, round(h, 2)))


def find_windows(tris, grid, bbox, f_guess=0.15):
    """Painted windows: clusters of window-shader triangles on vertical facade planes (curtain walls included),
    with the side they face."""
    win = [t for t in tris if "window" in t[3].lower() and "door" not in t[3].lower()]
    clusters = []
    for t in win:
        c = [sum(p[k] for p in t[:3]) / 3 for k in range(3)]
        for g in clusters:
            lo, hi = g["lo"], g["hi"]
            if lo[0] - 0.8 <= c[0] <= hi[0] + 0.8 and lo[2] - 0.8 <= c[2] <= hi[2] + 0.8 and lo[1] - 0.8 <= c[1] <= hi[1] + 0.8:
                g["tris"].append(t)
                for p in t[:3]:
                    for k in range(3):
                        lo[k], hi[k] = min(lo[k], p[k]), max(hi[k], p[k])
                break
        else:
            vs = t[:3]
            clusters.append({"tris": [t], "lo": [min(v[k] for v in vs) for k in range(3)],
                             "hi": [max(v[k] for v in vs) for k in range(3)]})
    inside = F.interior_mask(tris, grid, f_guess + 1.2, dilate=1, erode=0)

    def is_inside(x, z):
        i, j = grid.cell(x, z)
        return 0 <= i < grid.nx and 0 <= j < grid.nz and inside[i][j]
    out = []
    for g in clusters:
        lo, hi = g["lo"], g["hi"]
        dx, dz = hi[0] - lo[0], hi[2] - lo[2]
        if min(dx, dz) > 1.0 or max(dx, dz) < 0.5 or hi[1] - lo[1] < 0.6 or min(dx, dz) > 0.6 * max(dx, dz):
            continue
        c = ((lo[0] + hi[0]) / 2, (lo[2] + hi[2]) / 2)
        if dx < dz:
            cands = {"+x": (c[0] + 1.2, c[1]), "-x": (c[0] - 1.2, c[1])}
        else:
            cands = {"+z": (c[0], c[1] + 1.2), "-z": (c[0], c[1] - 1.2)}
        outside = [sd for sd, pt in cands.items() if not is_inside(*pt)]
        if len(outside) != 1:
            continue
        side = outside[0]
        ax = 1 if side in ("+z", "-z") else 0
        # the frame's outermost face is the facade plane
        out.append({"side": side, "plane": (hi[2] if side == "+z" else lo[2]) if ax == 1 else (hi[0] if side == "+x" else lo[0]),
                    "u0": lo[0] if ax == 1 else lo[2], "u1": hi[0] if ax == 1 else hi[2], "y0": lo[1], "y1": hi[1]})
    return out


# ============================================================================
# binary space partition into rooms
# ============================================================================

def bsp(rect, target, rng, min_side=MIN_ROOM):
    """Split a rectangle into rooms of about `target` m2 with varied proportions. Returns (leaves, links): links
    are (leaf index a, leaf index b, (axis, coord, lo, hi)) for one doorway across every split, so the rooms form
    a tree - every room reachable. A split whose two sides can't share a wide enough doorway is undone."""
    def rec(r):
        w, d = r[2] - r[0], r[3] - r[1]
        if area(r) <= target * 1.3 or (w < 2 * min_side and d < 2 * min_side) or area(r) < 2 * MIN_AREA:
            return [r], []
        if w >= 2 * min_side and (d < 2 * min_side or w > d * 1.2 or (w >= d * 0.83 and rng.next(2) == 0)):
            ax = 0
        else:
            ax = 1
        lo, hi = (r[0], r[2]) if ax == 0 else (r[1], r[3])
        cut = q4(lo + (hi - lo) * rng.uniform(0.34, 0.66))
        cut = min(max(cut, lo + min_side), hi - min_side)
        a = (r[0], r[1], cut, r[3]) if ax == 0 else (r[0], r[1], r[2], cut)
        b = (cut, r[1], r[2], r[3]) if ax == 0 else (r[0], cut, r[2], r[3])
        la, ka = rec(a)
        lb, kb = rec(b)
        best = None
        for i, ra in enumerate(la):
            for j, rb in enumerate(lb):
                s = shared(ra, rb)
                if s and (best is None or s[3] - s[2] > best[2][3] - best[2][2]):
                    best = (i, j, s)
        if best is None or best[2][3] - best[2][2] < PASS:
            return [r], []
        off = len(la)
        links = ka + [(i + off, j + off, s) for i, j, s in kb] + [(best[0], best[1] + off, best[2])]
        return la + lb, links
    return rec(rect)


def _frame(rect, entry_pt):
    """Local frame of a rectangle seen from the entrance: (side, W, D, to_world(u, v)); u runs along the entrance
    wall, v from it into the rectangle."""
    x0, z0, x1, z1 = rect
    side = min((("+z", abs(entry_pt[1] - z1)), ("-z", abs(entry_pt[1] - z0)), ("+x", abs(entry_pt[0] - x1)),
                ("-x", abs(entry_pt[0] - x0))), key=lambda t: t[1])[0]
    if side in ("+z", "-z"):
        W, D = x1 - x0, z1 - z0
        f = (lambda u, v: (x0 + u, z1 - v)) if side == "+z" else (lambda u, v: (x0 + u, z0 + v))
        u_e = entry_pt[0] - x0
    else:
        W, D = z1 - z0, x1 - x0
        f = (lambda u, v: (x1 - v, z0 + u)) if side == "+x" else (lambda u, v: (x0 + v, z0 + u))
        u_e = entry_pt[1] - z0
    return side, W, D, f, u_e


def _poly_world(f, pts):
    """Local (u, v) ring -> world plan polygon, counter-clockwise the way pob_builder wants it (interior left)."""
    w = [list(f(u, v)) for u, v in pts]
    if pob_builder._area([tuple(p) for p in w]) < 0:
        w.reverse()
    return w


def _lbox(f, u0, v0, u1, v1):
    a, b = f(u0, v0), f(u1, v1)
    return (min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1]))     # exact: polys use the same map


def _arc(c, rx, ry, a0, a1, n):
    return [(c[0] + rx * math.cos(a0 + (a1 - a0) * k / n), c[1] + ry * math.sin(a0 + (a1 - a0) * k / n)) for k in range(n + 1)]


def spine(rect, target, kind, entry_pt, rng):
    """Corridor plan like the stock interiors: optional foyer at the entrance, a hallway running into the unit with
    rooms off one or both sides (each its own door onto the hall), an end room across the far end - sometimes an
    apse with a curved end wall - and rounded outer corners on some side rooms. Every room >= MIN_ROOM x MIN_ROOM
    and >= MIN_AREA; the hall HALL_W wide (never under MIN_HALL). Returns None when the unit is too small.
    Result: rooms [(role, rect, poly or None)], links [(i, j, style)], entry index."""
    side, W, D, f, u_e = _frame(rect, entry_pt)
    hw = HALL_W.get(kind, 2.4)
    if W < hw + MIN_ROOM or D < 2 * MIN_ROOM + 1.0 or W * D < 3 * MIN_AREA + hw * D:
        return None
    hw = q4(max(MIN_HALL, min(hw, W - MIN_ROOM)))      # on the 0.25 m grid like every other coordinate
    # hall position: centred on the door when rooms fit on both sides, else along the wall nearer the door
    if W >= hw + 2 * MIN_ROOM:
        c0 = min(max(u_e - hw / 2, MIN_ROOM), W - hw - MIN_ROOM)
    else:
        c0 = 0.0 if u_e < W / 2 else W - hw
    c0 = q4(c0)
    door_in_hall = c0 + 0.1 <= u_e - DOOR_W / 2 and u_e + DOOR_W / 2 <= c0 + hw - 0.1
    fd = 0.0
    if not door_in_hall or (D >= 14.0 and rng.next(2)):
        fd = q4(max(MIN_ROOM, min(5.0, D * 0.28)))
        if D - fd < 2 * MIN_ROOM:
            return None
    # end room across the far end when there is depth to spare
    ed = 0.0
    if D - fd >= MIN_ROOM + 2 * MIN_ROOM:
        ed = q4(max(MIN_ROOM, min(6.0, (D - fd) * 0.3)))
        if W * ed < MIN_AREA:
            ed = 0.0
    v0, v1 = fd, D - ed
    rooms, links = [], []

    def add(role, u0, va, u1, vb, poly=None):
        rooms.append((role, _lbox(f, u0, va, u1, vb), _poly_world(f, poly) if poly else None))
        return len(rooms) - 1

    hall_poly = None
    if not ed and rng.next(3) == 0 and hw >= 2.0:          # hall ends in a half-round bay
        r = hw / 2
        hall_poly = [(c0, v0), (c0 + hw, v0), (c0 + hw, v1 - r)] + _arc((c0 + r, v1 - r), r, r, 0.0, math.pi / 2, 4)[1:] + \
            _arc((c0 + r, v1 - r), r, r, math.pi / 2, math.pi, 4)[1:] + [(c0, v0)]
        hall_poly = hall_poly[:-1]
    hall = add("corridor", c0, v0, c0 + hw, v1, hall_poly)
    entry = hall
    if fd:
        foyer = add("foyer", 0.0, 0.0, W, fd)
        links.append((foyer, hall, "open"))
        entry = foyer
    if ed:
        apse = None
        if W >= 5.0 and ed >= 4.0 and rng.next(2):          # curved end wall
            sag = min(ed - 2.5, W * 0.3)
            apse = [(0.0, v1), (W, v1), (W, D - sag)] + _arc((W / 2, D - sag), W / 2, sag, 0.0, math.pi, 10)[1:-1] + [(0.0, D - sag)]
        end = add("end", 0.0, v1, W, D, apse)
        links.append((hall, end, "arch"))
    # side rooms
    for (ua, ub, outer) in ((0.0, c0, 0.0), (c0 + hw, W, W)):
        depth = ub - ua
        if depth < MIN_ROOM - 1e-6:
            continue
        L = v1 - v0
        front = max(MIN_ROOM, min(L, target / depth))
        n = max(1, int(L // front))
        while n > 1 and (L / n < MIN_ROOM or (L / n) * depth < MIN_AREA):
            n -= 1
        cuts = [v0]
        for k in range(1, n):
            jitter = rng.uniform(-0.18, 0.18) * L / n
            cuts.append(q4(v0 + k * L / n + jitter))
        cuts.append(v1)
        for k in range(n):
            va, vb = cuts[k], cuts[k + 1]
            if vb - va < MIN_ROOM - 1e-6:
                continue
            poly = None
            if depth >= 4.0 and vb - va >= 4.0 and rng.next(3) == 0:      # rounded outer corners
                rr = min(1.5, depth * 0.3, (vb - va) * 0.3)
                if outer == 0.0:
                    poly = [(ub, va), (ub, vb), (rr, vb)] + _arc((rr, vb - rr), rr, rr, math.pi / 2, math.pi, 4)[1:] + \
                        _arc((rr, va + rr), rr, rr, math.pi, 1.5 * math.pi, 4)
                else:
                    poly = [(ua, va), (W - rr, va)] + _arc((W - rr, va + rr), rr, rr, -math.pi / 2, 0.0, 4)[1:] + \
                        _arc((W - rr, vb - rr), rr, rr, 0.0, math.pi / 2, 4) + [(ua, vb)]
            i = add("side", ua, va, ub, vb, poly)
            links.append((hall, i, "door"))
    return rooms, links, entry


def _fitting_door(styles, width, height, rng):
    """A door style whose leaf fits a width x height opening (stock leaves differ by up to 1.5 m), or "" for an
    open doorway: a leaf bigger than its opening clips through the jambs and head."""
    fits = [st for st in styles if pob_builder.door_fits(st, width, height)]
    return fits[rng.next(len(fits))] if fits else ""


def leaf_at(leaves, pt):
    for i, r in enumerate(leaves):
        if r[0] - 0.05 <= pt[0] <= r[2] + 0.05 and r[1] - 0.05 <= pt[1] <= r[3] + 0.05:
            return i
    return min(range(len(leaves)), key=lambda i: (max(leaves[i][0] - pt[0], 0, pt[0] - leaves[i][2]) ** 2 +
                                                  max(leaves[i][1] - pt[1], 0, pt[1] - leaves[i][3]) ** 2))


def assign_roles(leaves, links, entry_idx, kind, rng):
    """Role per leaf by graph depth and size. kind: home | shop | cantina | office | workshop | apartment."""
    adj = {i: [] for i in range(len(leaves))}
    for a, b, _ in links:
        adj[a].append(b)
        adj[b].append(a)
    depth = {entry_idx: 0}
    order = [entry_idx]
    for i in order:
        for j in adj[i]:
            if j not in depth:
                depth[j] = depth[i] + 1
                order.append(j)
    roles = {}
    first = {"home": "hall", "apartment": "hall", "shop": "shop", "cantina": "cantina", "office": "lobby",
             "workshop": "workshop", "parlor": "parlor"}.get(kind, "hall")
    roles[entry_idx] = first
    rest = sorted((i for i in range(len(leaves)) if i != entry_idx), key=lambda i: (-depth.get(i, 0), area(leaves[i])))
    if kind in ("home", "apartment", "parlor"):
        small = [i for i in rest if area(leaves[i]) < 11.0]
        if small:
            roles[small[0]] = "bath"
        for i in sorted(rest, key=lambda i: -area(leaves[i])):
            if i in roles:
                continue
            if "kitchen" not in roles.values() and depth.get(i, 0) <= 1:
                roles[i] = "kitchen"
            elif kind == "parlor" and "study" not in roles.values():
                roles[i] = "study"
            else:
                roles[i] = "bedroom"
    elif kind in ("shop", "cantina"):
        for n, i in enumerate(rest):
            roles[i] = ("storage", "office", "kitchen", "storage")[n % 4] if kind == "cantina" else ("storage", "office", "workshop")[n % 3]
    else:
        for n, i in enumerate(rest):
            roles[i] = ("office", "storage", "office", "bath")[n % 4]
    return roles


# ============================================================================
# plan
# ============================================================================

def plan(name, tris, bbox, theme, category=None, seed=1):
    grid = F.Grid(bbox)
    H = bbox[4]
    rng = Rand(seed)
    th = F.THEMES[theme]
    deco = THEME_DECOR[theme]
    doors = find_doors(tris, grid, bbox)
    f0 = 0.15
    if doors:
        b = min(d["bottom"] for d in doors)
        if 0.0 < b < 2.0:
            f0 = round(max(f0, b + 0.02), 2)

    def storey_mask(k):
        y = f0 + k * F.STOREY
        return F.mask_and([F.interior_mask(tris, grid, y + dy) for dy in (0.3, 1.8, F.ROOM_H - 0.1)])

    m0 = storey_mask(0)
    r = F.largest_rect(m0)
    if r is None or (r[2] - r[0]) * F.RES < 4.0 or (r[3] - r[1]) * F.RES < 4.0:
        m0 = F.mask_and([F.interior_mask(tris, grid, f0 + dy, dilate=2) for dy in (0.3, 1.8, F.ROOM_H - 0.1)])
        r = F.largest_rect(m0)
    if r is None or (r[2] - r[0]) * F.RES < 3.5 or (r[3] - r[1]) * F.RES < 3.5:
        raise ValueError(f"{name}: no usable interior found in the shell")
    R = tuple(q4(v) for v in (grid.x(r[0]) + 0.05, grid.z(r[1]) + 0.05, grid.x(r[2]) - 0.05, grid.z(r[3]) - 0.05))

    def cells(box):              # grid cells of a box (inset: boxes are snapped to 0.25 m, the grid is 0.5 m)
        i0, j0 = grid.cell(box[0] + 0.15, box[1] + 0.15)
        i1, j1 = grid.cell(box[2] - 0.15, box[3] - 0.15)
        return (i0, j0, i1 + 1, j1 + 1)

    def facade(side, at, y):
        n = F.SIDE_N[side]
        hits = F.ray_hits(tris, (at[0], y, at[1]), (n[0], 0.0, n[1]))
        return max(hits) if hits else 0.0

    def beyond(side, pt, d):
        n = F.SIDE_N[side]
        t = (abs(n[1]), abs(n[0]))
        far = 0.0
        for hy in (0.4, 1.4, 2.4):
            for du in (-0.8, 0.0, 0.8):
                o = (pt[0] + n[0] * (d + 0.05) + t[0] * du, f0 + hy, pt[1] + n[1] * (d + 0.05) + t[1] * du)
                hits = F.ray_hits(tris, o, (n[0], 0.0, n[1]), 8.0)
                if hits:
                    far = max(far, max(hits))
        return far

    def edge_point(side, u):
        """Point on R's `side` edge at along-coordinate u."""
        return {"+x": (R[2], u), "-x": (R[0], u), "+z": (u, R[3]), "-z": (u, R[1])}[side]

    def span(side):
        return (R[0], R[2]) if side in ("+z", "-z") else (R[1], R[3])

    # a painted door recessed in an alcove can sit behind the free rectangle's edge: pull that edge back to
    # the door plane so the doorway starts at the painted door (and the cut removes it)
    R = list(R)
    for d in doors:
        lo, hi = span(d["side"])
        u = d["c"][0] if d["side"] in ("+z", "-z") else d["c"][1]
        if not (lo + DOOR_W / 2 <= u <= hi - DOOR_W / 2):
            continue
        plane = d["c"][1] if d["side"] in ("+z", "-z") else d["c"][0]
        k = {"+x": 2, "-x": 0, "+z": 3, "-z": 1}[d["side"]]
        sign = 1 if d["side"] in ("+x", "+z") else -1
        if sign * (R[k] - plane) > -0.1 and abs(R[k] - plane) < 4.0:
            R[k] = q4(plane - sign * 0.15 - sign * 0.124)
    R = tuple(R)

    # doors that open onto the free rectangle
    usable = []
    for d in doors:
        lo, hi = span(d["side"])
        u = d["c"][0] if d["side"] in ("+z", "-z") else d["c"][1]
        if lo + DOOR_W / 2 + 0.2 <= u <= hi - DOOR_W / 2 - 0.2:
            if all(e["side"] != d["side"] or abs(e["u"] - u) > 3.0 for e in usable):
                usable.append({**d, "u": u})
    if not usable:
        best = None
        for sd, n in F.SIDE_N.items():
            lo, hi = span(sd)
            for k in (0.5, 0.3, 0.7):
                u = q4(lo + (hi - lo) * k)
                pt = edge_point(sd, u)
                dd = facade(sd, pt, f0 + 1.2)
                bb = beyond(sd, pt, dd)
                # never through a gazebo, terrace or balustrade standing in front of the facade
                score = dd + (100.0 if bb > 0.6 else 0.0) + 0.3 * abs(k - 0.5) - 0.01 * (hi - lo)
                if best is None or score < best[0]:
                    best = (score, {"c": pt, "side": sd, "bottom": f0, "width": DOOR_W, "u": u})
        usable = [best[1]]

    cat = category or ("slum" if "slum" in name else "block" if "block" in name or "bldg_" in name else
                       "historic" if "historic" in name else "house")

    def count_storeys(box, limit):
        n = 1
        while n < limit and H > f0 + (n + 1) * F.STOREY:
            if not F.rect_inside(storey_mask(n), cells(box)):
                break
            n += 1
        return n

    if cat == "slum" and len(usable) == 1 and area(R) > 110:
        # a big slum block is a row of small dwellings: more doorways along the same facade where it is clear
        d0 = usable[0]
        lo, hi = span(d0["side"])
        n_units = max(2, min(4, int(round((hi - lo) / 10.0))))
        step = (hi - lo) / n_units
        for i in range(n_units):
            u = q4(lo + step * (i + 0.5))
            if abs(u - d0["u"]) < step * 0.6:
                continue
            pt = edge_point(d0["side"], u)
            dd = facade(d0["side"], pt, f0 + 1.2)
            if dd < 4.0 and beyond(d0["side"], pt, dd) < 0.6:
                usable.append({"c": pt, "side": d0["side"], "bottom": f0, "width": DOOR_W, "u": u})

    storeys = 1 if cat == "slum" else count_storeys(R, 6)
    T = R
    if cat != "slum" and H > 24:
        # towers often step back above the podium: stack the floors where the upper storeys fit (T, inside R),
        # the ground floor keeps the whole footprint
        up = F.mask_and([m0] + [storey_mask(k) for k in (1, 2, 3)])
        i0, j0, i1, j1 = cells(R)
        for i in range(len(up)):
            for j in range(len(up[0])):
                if not (i0 <= i < i1 and j0 <= j < j1):
                    up[i][j] = False
        t = F.largest_rect(up)
        if t and (t[2] - t[0]) * F.RES >= 4.5 and (t[3] - t[1]) * F.RES >= 4.5:
            T = tuple(q4(v) for v in (grid.x(t[0]) + 0.05, grid.z(t[1]) + 0.05, grid.x(t[2]) - 0.05, grid.z(t[3]) - 0.05))
            T = (max(T[0], R[0]), max(T[1], R[1]), min(T[2], R[2]), min(T[3], R[3]))
            st_t = count_storeys(T, 6)
            if st_t >= 4:
                cat, storeys = "tower", st_t

    P = Planner(R, f0, H, theme, th, deco, rng)
    P.cat = cat
    if cat == "tower":
        P.tower(usable, storeys, T)
    elif len(usable) >= 2:
        P.units(usable, cat)
    else:
        P.single(usable[0], cat, storeys)

    # entrances (a vestibule where the facade stands well off the rooms)
    entrances = []
    loose = None
    for d in usable:
        side, u = d["side"], d["u"]
        p0 = edge_point(side, u)
        entry = P.room_at(p0, side)
        if P.rooms[entry].get("curved"):       # an entrance needs a straight wall: square this room off again
            P.rooms[entry]["poly"] = None
            P.rooms[entry]["curved"] = False
        reveal = max(0.3, facade(side, p0, f0 + 1.2) + 0.03)
        at = p0
        if reveal > 1.6:
            n = F.SIDE_N[side]
            t = (abs(n[1]), abs(n[0]))
            depth = q4(reveal - 0.5)
            q0 = (p0[0] - t[0] * 1.6, p0[1] - t[1] * 1.6)
            q1 = (p0[0] + t[0] * 1.6 + n[0] * depth, p0[1] + t[1] * 1.6 + n[1] * depth)
            vbox = (min(q0[0], q1[0]), min(q0[1], q1[1]), max(q0[0], q1[0]), max(q0[1], q1[1]))
            if loose is None:
                loose = F.mask_and([F.interior_mask(tris, grid, f0 + dy, dilate=1, erode=0) for dy in (0.3, 1.8, 3.3)])
            er = P.rooms[entry]["rect"]
            ov = shared(er, vbox)
            if depth >= 0.75 and ov and ov[3] - ov[2] >= 1.8 and F.rect_inside(loose, cells(vbox)) and P.free(vbox):
                vname = P.add_room(vbox, f0, 3.4, "vestibule")
                P.link(entry, vname, style="arch", width=min(2.0, ov[3] - ov[2] - 0.2))
                entry = vname
                at = (p0[0] + n[0] * depth, p0[1] + n[1] * depth)
                reveal = max(0.3, facade(side, at, f0 + 1.2) + 0.03)
        clear = beyond(side, at, reveal - 0.03)
        style = th.get(cat) if cat in ("historic", "slum") else None
        dw, dh = DOOR_W, DOOR_H
        outline = d.get("outline")
        door_depth = None
        if outline and at == p0:
            dw, dh = fit_doorway(outline, u, f0)
            plane = d["c"][1] if side in ("+z", "-z") else d["c"][0]
            edge_c = {"+x": R[2], "-x": R[0], "+z": R[3], "-z": R[1]}[side]
            door_depth = round(abs(plane - edge_c), 3)
        else:
            outline = None
        entrances.append({"room": entry, "side": side, "at": list(at), "width": dw, "height": dh,
                          "outline": [[q[0] - u, q[1]] for q in outline] if outline else None,
                          "door_depth": door_depth,
                          "door_style": _fitting_door([style] if style else th["entrance"], dw, dh, rng),
                          "reveal": reveal, "cut_beyond": round(clear + 0.4, 2),
                          "porch": {"depth": reveal + clear + 1.0, "width": dw,
                                    "steps": max(1, int(round(f0 / 0.2))), "run": 0.35}})
        P.entrance_marks.append((entry, side, at))

    P.finish_roles()
    P.place_windows(find_windows(tris, grid, bbox, f0), entrances)
    # unfurnished, like walking into a new house: only hard fixtures (built-in fountain basins) are kept
    decor = [it for it in P.decor_plan(entrances) if it["type"] == "basin"]
    rooms_spec = P.spec_rooms()
    by_name = {r["name"]: r for r in rooms_spec}
    for it in decor:
        if it["type"] in ("basin", "counter") and it["room"] in by_name:
            r = it["rect"]
            by_name[it["room"]].setdefault("obstacles", []).append([r[0] - 0.05, r[1] - 0.05, r[2] + 0.05, r[3] + 0.05])
    spec = {
        "name": name, "rooms": rooms_spec, "doors": P.spec_doors(), "entrances": entrances, "lights": True,
        "trim": True, "flat_terrain": True, "ground_y": 0.0, "collision_meshes": True, "window_portals": True,
        "wall_thickness": WALL,
        "trim_materials": {"shader": th["trim"]}, "exterior": {"porch": {"shader": th["porch"]}},
        "shell_color": th["color"],
    }
    info = {"category": cat, "front": usable[0]["side"], "doors": len(usable), "painted_doors": len(doors),
            "storeys": storeys if cat == "tower" else P.storeys, "free": list(R), "floor_y": f0, "height": H,
            "reveal": round(entrances[0]["reveal"], 2), "rooms": len(P.rooms),
            "roles": sorted({v["role"] for v in P.rooms.values()})}
    return spec, info, decor


class Planner:
    def __init__(self, R, f0, H, theme, th, deco, rng):
        self.R, self.f0, self.H, self.theme, self.th, self.deco, self.rng = R, f0, H, theme, th, deco, rng
        self.rooms = {}          # name -> {rect | poly, floor_y, height, role, extra}
        self.links = []          # (a, b, {style, width, y, near})
        self.entrance_marks = []
        self.storeys = 1
        self.count = {}
        self.cat = None

    # -- bookkeeping -------------------------------------------------------------------------------------
    def _name(self, role):
        self.count[role] = self.count.get(role, 0) + 1
        return f"{role}{self.count[role]}"

    def add_room(self, rect, floor_y, height, role, poly=None, **extra):
        name = self._name(role)
        self.rooms[name] = {"rect": rect, "poly": poly, "floor_y": round(floor_y, 3), "height": round(height, 3),
                            "role": role, "unit": getattr(self, "unit", 0), "kind": getattr(self, "unit_kind", None), **extra}
        return name

    def link(self, a, b, style=None, width=None, y=None, near=None):
        self.links.append((a, b, {"style": style, "width": width, "y": y, "near": near}))

    def free(self, box):
        for v in self.rooms.values():
            r = v["rect"]
            if abs(v["floor_y"] - self.f0) < 0.05 and box[0] < r[2] - 0.01 and box[2] > r[0] + 0.01 and \
                    box[1] < r[3] - 0.01 and box[3] > r[1] + 0.01:
                return False
        return True

    def room_at(self, pt, side):
        n = F.SIDE_N[side]
        q = (pt[0] - n[0] * 0.2, pt[1] - n[1] * 0.2)
        for name, v in self.rooms.items():
            if abs(v["floor_y"] - self.f0) > 0.05 or v.get("slope"):
                continue
            poly = v["poly"] or rect_poly(v["rect"])
            if pob_builder._inside(q, poly):
                return name
        raise ValueError(f"no ground room behind the doorway at {pt}")

    MAX_ROOMS = {"home": 7, "apartment": 3, "shop": 4, "cantina": 3, "workshop": 3, "parlor": 6, "office": 5}

    SIDE_ROLES = {"home": ("kitchen", "bedroom", "bath", "bedroom", "study"),
                  "apartment": ("kitchen", "bedroom", "bath", "bedroom"),
                  "parlor": ("study", "bedroom", "kitchen", "bath", "bedroom"),
                  "shop": ("storage", "office", "workshop", "storage"),
                  "office": ("office", "office", "storage", "bath", "office")}
    END_ROLE = {"home": "hall", "apartment": "hall", "parlor": "parlor", "shop": "shop", "office": "office"}
    FOYER_ROLE = {"home": "vestibule", "apartment": "vestibule", "parlor": "vestibule", "shop": "shop", "office": "lobby"}

    def partition(self, rect, target, kind, entry_pt, floor_y, height, extra_entries=(), spine_ok=True):
        self.unit = getattr(self, "unit", 0) + 1
        self.unit_kind = kind
        target = max(target, MIN_AREA)
        if spine_ok and kind in self.SIDE_ROLES and self.cat != "slum":
            sp = spine(rect, target, kind, entry_pt, self.rng)
            if sp:
                return self._spine_rooms(sp, kind, floor_y, height)
        cap = 5 if self.cat == "slum" else self.MAX_ROOMS.get(kind, 6)
        target = max(target, area(rect) / cap)
        leaves, links = bsp(rect, target, self.rng)
        e = leaf_at(leaves, entry_pt)
        roles = assign_roles(leaves, links, e, kind, self.rng)
        names = [self.add_room(lf, floor_y, height, roles[i]) for i, lf in enumerate(leaves)]
        for a, b, s in links:
            ra, rb = roles[a], roles[b]
            private = ra in PRIVATE or rb in PRIVATE
            style = "door" if private else ("arch" if self.deco["private_arch"] or self.rng.next(2) else "open")
            self.link(names[a], names[b], style=style, width=1.6 if private else 1.5)
        return names, names[e]

    def _spine_rooms(self, sp, kind, floor_y, height):
        rooms, links, entry = sp
        side_roles = list(self.SIDE_ROLES[kind])
        # the biggest side room takes the first role (kitchen / study / storage...), the smallest a bath
        sides = sorted((i for i, r in enumerate(rooms) if r[0] == "side"), key=lambda i: -area(rooms[i][1]))
        role_of = {}
        for k, i in enumerate(sides):
            role_of[i] = side_roles[k % len(side_roles)]
        bath = next((i for i in sides if role_of[i] == "bath"), None)
        if bath is not None and bath != sides[-1]:
            role_of[bath], role_of[sides[-1]] = role_of[sides[-1]], "bath"
        names = []
        for i, (kind_i, rect, poly) in enumerate(rooms):
            role = {"corridor": "corridor", "foyer": self.FOYER_ROLE[kind], "end": self.END_ROLE[kind]}.get(kind_i) or role_of[i]
            names.append(self.add_room(rect, floor_y, height, role, poly=poly, curved=bool(poly)))
        for a, b, style in links:
            rb = self.rooms[names[b]]["role"]
            private = rb in PRIVATE
            if style == "door" and not private:
                style = "arch" if self.deco["private_arch"] else "open"
            ha, hb = self.rooms[names[a]], self.rooms[names[b]]
            sh = shared(ha["rect"], hb["rect"])
            w = 1.6 if private else min(2.0, max(1.5, (sh[3] - sh[2]) - 0.6)) if sh else 1.5
            self.link(names[a], names[b], style=style, width=w)
        return names, names[entry]

    # -- layouts -------------------------------------------------------------------------------------------
    def single(self, door, cat, storeys=1):
        """Whole free footprint for one entrance: open BSP plan; two storeys with a stair when it fits."""
        R, f0 = self.R, self.f0
        kind = {"slum": "home", "house": "home", "historic": "parlor", "block": "shop"}.get(cat, "home")
        target = {"slum": 13.0, "house": 22.0, "historic": 26.0, "block": 28.0}.get(cat, 22.0)
        h1 = min(4.2, self.H - f0 - 0.4)
        p0 = self._edge_pt(door)
        two = cat in ("house", "historic", "block") and storeys >= 2 and self.H > f0 + 2 * F.STOREY + 0.5 and \
            (R[2] - R[0]) >= 9.0 and (R[3] - R[1]) >= 9.0 and F.ROOM_H < h1
        if two and self._stair_house(door, kind, target):
            return
        self.partition(R, target, kind, p0, f0, h1)
        self._hall_features()

    def units(self, doors, cat):
        """One unit per door: shops, flats, a cantina - each partitioned into its own rooms."""
        R = self.R
        sides = {d["side"] for d in doors}
        zs = {"+z", "-z"} & sides
        xs = {"+x", "-x"} & sides
        main = "z" if len([d for d in doors if d["side"] in ("+z", "-z")]) >= len([d for d in doors if d["side"] in ("+x", "-x")]) else "x"
        halves = []
        if main == "z":
            if len(zs) == 2:
                mid = q4((R[1] + R[3]) / 2)
                halves = [((R[0], mid, R[2], R[3]), "+z"), ((R[0], R[1], R[2], mid), "-z")]
            else:
                halves = [(R, next(iter(zs)))]
        else:
            if len(xs) == 2:
                mid = q4((R[0] + R[2]) / 2)
                halves = [((mid, R[1], R[2], R[3]), "+x"), ((R[0], R[1], mid, R[3]), "-x")]
            else:
                halves = [(R, next(iter(xs)))]
        h1 = min(4.2, self.H - self.f0 - 0.4)
        kinds = {"historic": ["parlor", "shop"], "slum": ["home"]}.get(
            cat, ["shop", "home", "cantina", "workshop", "shop", "home"])
        n_unit = 0
        for half, side in halves:
            ds = sorted([d for d in doors if d["side"] == side], key=lambda d: d["u"])
            if not ds:
                continue
            along_x = side in ("+z", "-z")
            lo, hi = (half[0], half[2]) if along_x else (half[1], half[3])
            cuts = [lo] + [q4((a["u"] + b["u"]) / 2) for a, b in zip(ds, ds[1:])] + [hi]
            for i, d in enumerate(ds):
                a, b = cuts[i], cuts[i + 1]
                box = (a, half[1], b, half[3]) if along_x else (half[0], a, half[2], b)
                kind = kinds[n_unit % len(kinds)]
                if kind == "cantina" and area(box) < 55:
                    kind = "shop"
                n_unit += 1
                target = {"shop": 26.0, "home": 14.0 if cat == "slum" else 18.0, "cantina": 60.0, "workshop": 30.0,
                          "parlor": 24.0}[kind]
                self.partition(box, target, kind, self._edge_pt(d), self.f0, h1)
        # doors on the cross sides open into whatever unit is behind them (room_at in plan())
        self._hall_features()

    def tower(self, doors, storeys, T=None):
        """Elevator core at the edge of the stacking area T; ground floor = the whole footprint around it
        (lobby at the core + offices/shops), corridor apartments above (one wrap-around flat per floor in a
        slim tower)."""
        R, f0 = self.R, self.f0
        T = T or R
        self.storeys = storeys
        floors = max(1, min(storeys - 1, 3))
        cw = 3.2
        small = min(R[2] - R[0], R[3] - R[1])
        if small < cw + 3.0:                 # slim tower: narrower lift so a lobby fits beside it
            cw = q4(max(2.2, small - 2.2))
        counts = {s: sum(d["side"] == s for d in doors) for s in F.SIDE_N}
        k_of = {"+x": 2, "-x": 0, "+z": 3, "-z": 1}
        # prefer a T side that is also an R side (outer wall), then the side with fewest doors
        side = min(F.SIDE_N, key=lambda s: (abs(T[k_of[s]] - R[k_of[s]]) > 0.3, counts[s],
                                             -((T[2] - T[0]) if s in ("+z", "-z") else (T[3] - T[1]))))
        along_x = side in ("+z", "-z")
        lo, hi = (T[0], T[2]) if along_x else (T[1], T[3])
        mid = q4((lo + hi) / 2 - cw / 2)
        for d in doors:
            if d["side"] == side and mid - 1.5 < d["u"] < mid + cw + 1.5:
                mid = q4(d["u"] + 1.6) if d["u"] + 1.6 + cw < hi - 1 else q4(d["u"] - 1.6 - cw)
        mid = min(max(mid, lo), hi - cw)
        full = small < cw + 3.0 + 2.2         # slim: the lift spans the whole side opposite the entrance
        if full and doors:
            side = {"+x": "-x", "-x": "+x", "+z": "-z", "-z": "+z"}[doors[0]["side"]]
            along_x = side in ("+z", "-z")
            lo, hi = (T[0], T[2]) if along_x else (T[1], T[3])
            mid, cw_along = lo, hi - lo
        else:
            cw_along = cw
        e = T[k_of[side]]
        core = {"+z": (mid, e - cw, mid + cw_along, e), "-z": (mid, e, mid + cw_along, e + cw),
                "+x": (e - cw, mid, e, mid + cw_along), "-x": (e, mid, e + cw, mid + cw_along)}[side]
        levels = [f0 + k * F.STOREY for k in range(1, floors + 1)]
        lift = self.add_room(core, f0, floors * F.STOREY + F.ROOM_H, "lift", levels=levels, elevator=True)
        # upper floors inside T: a corridor along the core, units off it
        slim = min(T[2] - T[0], T[3] - T[1]) < cw + 2.4 + MIN_ROOM
        if along_x:
            cz0 = core[1] - 2.4 if side == "+z" else core[3]
            corr = (T[0], cz0, T[2], cz0 + 2.4)
            up_bands = [(T[0], core[1], core[0], core[3]), (core[2], core[1], T[2], core[3]),
                        (T[0], T[1], T[2], cz0) if side == "+z" else (T[0], cz0 + 2.4, T[2], T[3])]
        else:
            cx0 = core[0] - 2.4 if side == "+x" else core[2]
            corr = (cx0, T[1], cx0 + 2.4, T[3])
            up_bands = [(core[0], T[1], core[2], core[1]), (core[0], core[3], core[2], T[3]),
                        (T[0], T[1], cx0, T[3]) if side == "+x" else (cx0 + 2.4, T[1], T[2], T[3])]
        # stairs as well as the lift (lifts need server scripts; offline only stairs work): a switchback column
        # beside the corridor, carved out of every floor
        col = None if slim or floors < 1 else self._stair_column(corr, up_bands[2], along_x)
        if col:
            up_bands = up_bands[:2] + [col["rest"]]
        # ground: R minus the core as bands; the band at the core's open face is the lobby
        n = F.SIDE_N[side]
        face = ((core[0] + core[2]) / 2 - n[0] * (cw / 2 + 0.3), (core[1] + core[3]) / 2 - n[1] * (cw / 2 + 0.3))
        bands = [b for b in self._minus_rect(R, core) if min(b[2] - b[0], b[3] - b[1]) >= 1.6]
        if col:
            bands = [p for b in bands for p in self._sub_rect(b, col["rect"]) if min(p[2] - p[0], p[3] - p[1]) >= 1.6]
        lobby_band = next((b for b in bands if b[0] <= face[0] <= b[2] and b[1] <= face[1] <= b[3]), None)
        if lobby_band is None:
            raise ValueError("tower core has no lobby in front of it")
        groups = []
        for b in bands:
            kind = "office" if b is lobby_band else self.rng.choice(["shop", "office", "workshop"])
            ept = face if b is lobby_band else ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
            names, entry = self.partition(b, 40.0 if b is lobby_band else 26.0, kind, ept, f0, F.ROOM_H,
                                          spine_ok=b is not lobby_band)     # the lobby room must touch the core
            groups.append((b, names, entry))
            if b is lobby_band:
                self.rooms[entry]["role"] = "lobby"
                sh = shared(self.rooms[entry]["rect"], core)
                self.link(entry, lift, style="open", width=min(2.0, (sh[3] - sh[2] - 0.2) if sh else 2.0), near=list(face))
        # join neighbouring bands (each band to the lobby band if they touch, else to any band already joined)
        joined = [g for g in groups if g[0] is lobby_band]
        rest = [g for g in groups if g[0] is not lobby_band]
        for _ in range(4):
            for g in list(rest):
                for h in joined:
                    pair = self._best_pair(g[1], h[1])
                    if pair:
                        self.link(pair[0], pair[1], style="arch" if self.deco["private_arch"] else "open", width=1.6)
                        joined.append(g)
                        rest.remove(g)
                        break
        landings = self._stair_rooms(col, [f0] + levels) if col else {}
        for y in levels:
            if slim:
                if full:
                    rest = [b for b in self._minus_rect(T, core) if min(b[2] - b[0], b[3] - b[1]) >= 1.6]
                    flat = self.add_room(max(rest, key=area), y, F.ROOM_H, "hall")
                else:
                    flat = self.add_room(T, y, F.ROOM_H, "hall", poly=self._minus_edge_rect(T, core, side))
                self.link(flat, lift, style="door", width=1.6, y=y, near=list(face))
                continue
            c = self.add_room(corr, y, F.ROOM_H, "corridor")
            self.link(c, lift, style="open", width=2.0, y=y)
            if round(y, 3) in landings:
                self.link(c, landings[round(y, 3)], style="open", width=1.6, y=y)
            for band in up_bands:
                if min(band[2] - band[0], band[3] - band[1]) < MIN_ROOM:
                    continue
                for unit in self._units_along(band, corr):
                    sh = shared(unit, corr)
                    if not sh or sh[3] - sh[2] < PASS:
                        continue
                    ept = ((sh[2] + sh[3]) / 2, sh[1]) if sh[0] == 1 else (sh[1], (sh[2] + sh[3]) / 2)
                    names, entry = self.partition(unit, 28.0, "apartment", ept, y, F.ROOM_H)
                    self.link(c, entry, style="door", width=1.6, near=list(ept))
        self._hall_features()

    STAIR_LANE, STAIR_RUN, STAIR_LAND = 1.4, 6.0, 2.2

    def _stair_column(self, corr, band, along_x):
        """Switchback stair column in `band` against the corridor, at the band's low end: two lanes (alternate
        flights) between landings at both ends, each landing on the corridor side. None when the band can't spare
        it (it must still hold apartments)."""
        L = 2 * self.STAIR_LAND + self.STAIR_RUN
        W = 2 * self.STAIR_LANE
        if along_x:
            if band[2] - band[0] < L + MIN_ROOM or band[3] - band[1] < W + MIN_ROOM:
                return None
            near_low = abs(band[3] - corr[1]) < 0.05           # band below the corridor (z)
            w0, w1 = (band[3] - W, band[3]) if near_low else (band[1], band[1] + W)
            u0 = band[0]
            mk = lambda a0, a1, b0, b1: (a0, b0, a1, b1)
        else:
            if band[3] - band[1] < L + MIN_ROOM or band[2] - band[0] < W + MIN_ROOM:
                return None
            near_low = abs(band[2] - corr[0]) < 0.05
            w0, w1 = (band[2] - W, band[2]) if near_low else (band[0], band[0] + W)
            u0 = band[1]
            mk = lambda a0, a1, b0, b1: (b0, a0, b1, a1)
        lane_near = (w1 - self.STAIR_LANE, w1) if near_low else (w0, w0 + self.STAIR_LANE)
        lane_far = (w0, w0 + self.STAIR_LANE) if near_low else (w1 - self.STAIR_LANE, w1)
        a = (u0, u0 + self.STAIR_LAND)
        b = (u0 + self.STAIR_LAND + self.STAIR_RUN, u0 + L)
        fl = (a[1], b[0])
        bu1, bw0, bw1 = (band[2], band[1], band[3]) if along_x else (band[3], band[0], band[2])
        return {"rect": mk(u0, u0 + L, w0, w1), "ends": [mk(*a, w0, w1), mk(*b, w0, w1)],
                "rest": mk(u0 + L, bu1, bw0, bw1),       # the band beyond the column, full depth, on the corridor
                "lanes": [mk(*fl, *lane_near), mk(*fl, *lane_far)], "along_x": along_x}

    def _stair_rooms(self, col, ys):
        """Landings at alternating ends of the column (one per floor) and a flight per floor gap in alternating
        lanes, so each flight starts where the last one ended. Returns {floor y: landing}; the ground landing is
        joined to the ground room it borders."""
        landings = {}
        for j, y in enumerate(ys):
            landings[round(y, 3)] = self.add_room(col["ends"][j % 2], y, F.ROOM_H, "corridor")
        for k in range(len(ys) - 1):
            lane = col["lanes"][k % 2]
            e0, e1 = col["ends"][k % 2], col["ends"][(k + 1) % 2]
            c0 = ((e0[0] + e0[2]) / 2, (e0[1] + e0[3]) / 2)
            c1 = ((e1[0] + e1[2]) / 2, (e1[1] + e1[3]) / 2)
            lc = ((lane[0] + lane[2]) / 2, (lane[1] + lane[3]) / 2)
            if col["along_x"]:
                frm, to = (lane[0] if c0[0] < c1[0] else lane[2], lc[1]), (lane[2] if c0[0] < c1[0] else lane[0], lc[1])
            else:
                frm, to = (lc[0], lane[1] if c0[1] < c1[1] else lane[3]), (lc[0], lane[3] if c0[1] < c1[1] else lane[1])
            ceiling = ys[k + 1] + 2.6
            fl = self.add_room(lane, ys[k], ceiling - ys[k], "stair")
            self.rooms[fl]["slope"] = {"from": frm, "to": to, "y0": ys[k], "y1": ys[k + 1], "ceiling": ceiling}
            self.link(landings[round(ys[k], 3)], fl, style="open", width=1.1, y=ys[k], near=list(frm))
            self.link(fl, landings[round(ys[k + 1], 3)], style="open", width=1.1, y=ys[k + 1], near=list(to))
        ground = landings[round(ys[0], 3)]
        best = None
        for nm, v in self.rooms.items():
            if nm == ground or abs(v["floor_y"] - ys[0]) > 0.05 or v.get("poly") or v["role"] in ("lift", "stair"):
                continue
            sh = shared(self.rooms[ground]["rect"], v["rect"])
            if sh and sh[3] - sh[2] >= PASS and (best is None or sh[3] - sh[2] > best[1]):
                best = (nm, sh[3] - sh[2])
        if best:
            self.link(ground, best[0], style="open", width=1.6, y=ys[0])
        return landings

    @staticmethod
    def _sub_rect(b, c):
        """Rectangle b minus rectangle c (clipped to b) as up to four rectangles; b itself when they don't overlap."""
        x0, z0, x1, z1 = max(b[0], c[0]), max(b[1], c[1]), min(b[2], c[2]), min(b[3], c[3])
        if x1 - x0 < 1e-3 or z1 - z0 < 1e-3:
            return [b]
        return [r for r in Planner._minus_rect(b, (x0, z0, x1, z1)) if r[2] - r[0] > 1e-3 and r[3] - r[1] > 1e-3]

    def _best_pair(self, names_a, names_b):
        best = None
        for a in names_a:
            for b in names_b:
                ra, rb = self.rooms[a], self.rooms[b]
                if abs(ra["floor_y"] - rb["floor_y"]) > 0.05 or ra.get("poly") or rb.get("poly"):
                    continue
                sh = shared(ra["rect"], rb["rect"])
                if sh and sh[3] - sh[2] >= PASS and (best is None or sh[3] - sh[2] > best[2]):
                    best = (a, b, sh[3] - sh[2])
        return best

    @staticmethod
    def _minus_rect(R, c):
        """R minus an inner rectangle c, as up to four rectangles (two full-width strips, two side pieces)."""
        out = []
        if c[1] > R[1] + 1e-3:
            out.append((R[0], R[1], R[2], c[1]))
        if c[3] < R[3] - 1e-3:
            out.append((R[0], c[3], R[2], R[3]))
        if c[0] > R[0] + 1e-3:
            out.append((R[0], max(c[1], R[1]), c[0], min(c[3], R[3])))
        if c[2] < R[2] - 1e-3:
            out.append((c[2], max(c[1], R[1]), R[2], min(c[3], R[3])))
        return out

    # -- helpers -------------------------------------------------------------------------------------------
    def _edge_pt(self, d):
        R = self.R
        return {"+x": (R[2], d["u"]), "-x": (R[0], d["u"]), "+z": (d["u"], R[3]), "-z": (d["u"], R[1])}[d["side"]]

    def _units_along(self, band, corr):
        """Apartment units along a band, each about 8 m of corridor frontage."""
        along_x = (band[2] - band[0]) >= (band[3] - band[1]) if shared(band, corr) is None else shared(band, corr)[0] == 1
        lo, hi = (band[0], band[2]) if along_x else (band[1], band[3])
        n = max(1, min(3, int((hi - lo) // 9.5)))
        step = (hi - lo) / n
        out = []
        for i in range(n):
            a, b = q4(lo + i * step), q4(lo + (i + 1) * step) if i + 1 < n else hi
            out.append((a, band[1], b, band[3]) if along_x else (band[0], a, band[2], b))
        return out

    @staticmethod
    def _minus_edge_rect(R, core, side):
        """R minus a rectangle on its `side` edge, as a polygon (U / L shape)."""
        x0, z0, x1, z1 = R
        a0, b0, a1, b1 = core
        if side == "+z":
            pts = [(x0, z0), (x1, z0), (x1, z1), (a1, z1), (a1, b0), (a0, b0), (a0, z1), (x0, z1)]
        elif side == "-z":
            pts = [(x0, z0), (a0, z0), (a0, b1), (a1, b1), (a1, z0), (x1, z0), (x1, z1), (x0, z1)]
        elif side == "+x":
            pts = [(x0, z0), (x1, z0), (x1, b0), (a0, b0), (a0, b1), (x1, b1), (x1, z1), (x0, z1)]
        else:
            pts = [(x0, z0), (x1, z0), (x1, z1), (x0, z1), (x0, b1), (a1, b1), (a1, b0), (x0, b0)]
        dedup = []
        for p in pts:
            if not dedup or abs(p[0] - dedup[-1][0]) > 1e-6 or abs(p[1] - dedup[-1][1]) > 1e-6:
                dedup.append(p)
        return [list(p) for p in dedup]

    def _stair_house(self, door, kind, target):
        """Two storeys: straight stair along the back wall, hall + rooms below, landing + rooms above."""
        R, f0 = self.R, self.f0
        side = door["side"]
        n = F.SIDE_N[side]
        along_x = side in ("+z", "-z")
        W = (R[2] - R[0]) if along_x else (R[3] - R[1])
        D = (R[3] - R[1]) if along_x else (R[2] - R[0])
        L, sw, leg = 6.4, 2.6, 2.4
        if W < leg + L + 3.0 or D < 9.0:
            return False
        # local (u along the front, v from the back wall) -> world
        def W2(u, v):
            if side == "+z":
                return (R[0] + u, R[1] + v)
            if side == "-z":
                return (R[0] + u, R[3] - v)
            if side == "+x":
                return (R[0] + v, R[1] + u)
            return (R[2] - v, R[1] + u)

        def box(u0, v0, u1, v1):
            a, b = W2(u0, v0), W2(u1, v1)
            return (min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1]))
        u_door = door["u"] - (R[0] if along_x else R[1])
        x0 = leg if u_door > W / 2 else W - leg - L       # stair away from the entrance
        x1 = x0 + L
        f1 = f0 + F.STOREY
        stair = self.add_room(box(x0, 0, x1, sw), f0, F.ROOM_H, "stair", slope_local=(x0, x1))
        # ground: front zone partitioned, back strip beside the stair
        front = box(0, sw, W, D)
        names, entry = self.partition(front, target, kind, self._edge_pt(door), f0, F.ROOM_H)
        bottom_end = W2(x0, sw / 2)
        top_end = W2(x1, sw / 2)
        low_side = (0, x0) if x0 > 0.1 else None
        high_side = (x1, W) if x1 < W - 0.1 else None
        # ground room at the stair's bottom end (opens to the front zone), upper landing at its top end
        if low_side and low_side[1] - low_side[0] >= 2.2:
            g = self.add_room(box(low_side[0], 0, low_side[1], sw), f0, F.ROOM_H, "hall")
        else:
            return False
        self.link(g, stair, style="open", width=1.6, near=list(bottom_end))
        self._link_to_zone(g, names)
        if high_side and high_side[1] - high_side[0] >= 2.2:
            k = self.add_room(box(high_side[0], 0, high_side[1], sw), f0, F.ROOM_H, "kitchen")
            self._link_to_zone(k, names)
        else:
            return False
        landing = self.add_room(box(high_side[0], 0, high_side[1], sw), f1, F.ROOM_H, "corridor")
        self.link(landing, stair, style="open", width=1.6, near=list(top_end))
        up_names, _ = self.partition(box(0, sw, W, D), 20.0, "home", W2(high_side[0] + 0.5, sw + 0.5), f1, F.ROOM_H)
        self._link_to_zone(landing, up_names)
        if low_side[1] - low_side[0] >= 2.2:
            bath = self.add_room(box(low_side[0], 0, low_side[1], sw), f1, F.ROOM_H, "bath")
            self._link_to_zone(bath, up_names, private=True)
        self.rooms[stair]["slope"] = {"from": bottom_end, "to": top_end, "y0": f0, "y1": f1,
                                      "ceiling": f1 + F.ROOM_H}
        self.storeys = 2
        self._hall_features()
        return True

    def _link_to_zone(self, room, names, private=False):
        r = self.rooms[room]["rect"]
        best = None
        for nm in names:
            v = self.rooms[nm]
            if abs(v["floor_y"] - self.rooms[room]["floor_y"]) > 0.05:
                continue
            s = shared(r, v["rect"])
            if s and (best is None or s[3] - s[2] > best[1][3] - best[1][2]):
                best = (nm, s)
        if best and best[1][3] - best[1][2] >= PASS:
            self.link(room, best[0], style="door" if private else "arch", width=1.5)

    def _hall_features(self):
        """Feature for the biggest ground room: basin (water themes), stage (cantina), dome (tall shell)."""
        ground = [(n, v) for n, v in self.rooms.items() if abs(v["floor_y"] - self.f0) < 0.05 and not v.get("poly")]
        for n, v in ground:
            if v["role"] == "cantina":
                v["feature"] = "stage"
        halls = [(n, v) for n, v in ground if v["role"] in ("hall", "parlor", "lobby", "shop") and area(v["rect"]) >= 40]
        if not halls:
            return
        n, v = max(halls, key=lambda nv: area(nv[1]["rect"]))
        if self.theme == "tato" and self.H - (v["floor_y"] + v["height"]) > 2.6 and v["role"] != "shop":
            v["feature"] = "dome"
        elif self.deco["basin"] and v["role"] != "shop" and min(v["rect"][2] - v["rect"][0], v["rect"][3] - v["rect"][1]) >= 5:
            v["feature"] = "basin"

    def finish_roles(self):
        pass

    # -- spec ----------------------------------------------------------------------------------------------
    def spec_rooms(self):
        out = []
        th, deco = self.th, self.deco
        for name, v in self.rooms.items():
            role = v["role"]
            poly = v["poly"] or rect_poly(v["rect"])
            mats = F.SHAFT if role == "lift" else self._materials(v)
            room = {"name": name, "polygon": poly, "floor_y": v["floor_y"], "height": v["height"], "materials": mats,
                    "light": dict(ROLE_LIGHT.get(role, ROLE_LIGHT["hall"]))}
            if v.get("windows"):
                room["windows"] = {"list": v["windows"], "auto": False}
            if v.get("levels"):
                room["levels"] = v["levels"]
            if v.get("elevator"):
                room["elevator"] = True
            if v.get("slope"):
                s = v["slope"]
                ax = "x" if abs(s["to"][0] - s["from"][0]) > abs(s["to"][1] - s["from"][1]) else "z"
                k = 0 if ax == "x" else 1
                rising = s["to"][k] > s["from"][k]
                room["slope"] = {"axis": ax, "y_min": s["y0"] if rising else s["y1"], "y_max": s["y1"] if rising else s["y0"],
                                 "steps": True, "ceiling_y": s["ceiling"]}
            feat = v.get("feature")
            r = v["rect"]
            if feat == "dome":
                room["dome"] = {"height": min(2.2, self.H - (v["floor_y"] + v["height"]) - 0.4), "rings": 5}
            if feat == "stage":
                w, d = r[2] - r[0], r[3] - r[1]
                # stage across the wall farthest from the room's entrance, ramp toward the room centre
                ent = self._entry_side(name)
                sd = {"+x": "-x", "-x": "+x", "+z": "-z", "-z": "+z"}.get(ent, "-z")
                depth = 2.4
                if sd in ("+z", "-z") and d >= 8 and w >= 6:
                    z_lo = r[3] - depth - 0.3 if sd == "+z" else r[1] + 0.3
                    st = {"min": [r[0] + 1.0, z_lo], "max": [r[2] - 1.0, z_lo + depth], "height": 0.6,
                          "ramp": {"side": "-z" if sd == "+z" else "+z", "width": 1.4, "length": 1.8}}
                    room["stages"] = [st]
                    v["stage"] = st
                elif sd in ("+x", "-x") and w >= 8 and d >= 6:
                    x_lo = r[2] - depth - 0.3 if sd == "+x" else r[0] + 0.3
                    st = {"min": [x_lo, r[1] + 1.0], "max": [x_lo + depth, r[3] - 1.0], "height": 0.6,
                          "ramp": {"side": "-x" if sd == "+x" else "+x", "width": 1.4, "length": 1.8}}
                    room["stages"] = [st]
                    v["stage"] = st
            out.append(room)
        return out

    def place_windows(self, wins, entrances, cap=48):
        """Real windows where a painted stock window stands in front of a room wall: same side, within 2.5 m,
        overlapping the wall and the room's height; clipped to both, clear of doorways."""
        marks = self._door_marks(entrances)
        self.window_marks = []
        made = 0
        for name, v in self.rooms.items():
            if v.get("poly") or v.get("slope") or v.get("elevator") or v["role"] in ("lift",):
                continue
            r, fy, h = v["rect"], v["floor_y"], v["height"]
            walls = {"+z": (1, r[3], r[0], r[2]), "-z": (1, r[1], r[0], r[2]),
                     "+x": (0, r[2], r[1], r[3]), "-x": (0, r[0], r[1], r[3])}
            per_wall = {}
            for w in wins:
                ax, coord, lo, hi = walls[w["side"]]
                sign = 1 if w["side"] in ("+x", "+z") else -1
                depth = sign * (w["plane"] - coord)
                if not (0.05 <= depth <= 2.5):
                    continue
                u0, u1 = max(w["u0"], lo + 0.4), min(w["u1"], hi - 0.4)
                y0, y1 = max(w["y0"], fy + 0.6), min(w["y1"], fy + h - 0.35)
                if u1 - u0 < 0.6 or y1 - y0 < 0.8:
                    continue
                if u1 - u0 > 3.0:                     # wide glazing: a centred 3 m window
                    uc = (u0 + u1) / 2
                    u0, u1 = uc - 1.5, uc + 1.5
                if any(rm == name and m_ax == ax and (c is None or abs(c - coord) < 0.05) and a - 0.3 < u1 and b + 0.3 > u0
                       for rm, m_ax, c, a, b in marks):
                    continue
                taken = per_wall.setdefault(w["side"], [])
                if len(taken) >= 3 or any(a - 0.4 < u1 and b + 0.4 > u0 for a, b in taken):
                    continue
                taken.append((u0, u1))
                uc = (u0 + u1) / 2
                at = (uc, coord) if ax == 1 else (coord, uc)
                v.setdefault("windows", []).append({"side": w["side"], "at": [at[0], at[1]], "width": round(u1 - u0, 3),
                                                    "height": round(y1 - y0, 3), "sill": round(y0 - fy, 3),
                                                    "reveal": round(depth + 0.03, 3)})
                self.window_marks.append((name, ax, coord, u0, u1))
                made += 1
                if made >= cap:
                    return made
        return made

    def _materials(self, v):
        """Wall / floor / ceiling / trim shaders for a room: its unit's palette (one stock interior family for the
        whole unit, hallways included); baths and kitchens only swap the floor for that family's tile."""
        pals = PALETTES[self.theme]
        kind = v.get("kind") or ("commerce" if v["role"] in ("lobby", "shop") else "home")
        P = pals.get(KIND_PALETTE.get(kind, "home")) or pals["home"]
        floor = P["wet"] if v["role"] in ("bath", "kitchen") else P["floor"]
        return {"wall": {"shader": P["wall"]}, "floor": {"shader": floor},
                "ceiling": {"shader": P["ceiling"]}, "trim": {"shader": P["trim"]}}

    def _entry_side(self, name):
        for room, side, _ in self.entrance_marks:
            if room == name:
                return side
        return None

    def spec_doors(self):
        out = []
        for a, b, o in self.links:
            d = {"rooms": [a, b], "width": o["width"] or 1.5, "height": 2.6}
            style = o["style"] or "open"
            if style == "door":
                d.update({"style": "door", "door_style": self.th["private"], "height": 2.8})
            elif style == "arch":
                d["style"] = "arch"
            if o["y"] is not None:
                d["y"] = o["y"]
            if o["near"] is not None:
                d["near"] = list(o["near"])
            out.append(d)
        return out

    # -- decor ---------------------------------------------------------------------------------------------
    def decor_plan(self, entrances):
        """Decor items per room (built after the rooms by build_decor)."""
        items = []
        deco = self.deco
        rng = self.rng
        door_marks = self._door_marks(entrances)
        for name, v in self.rooms.items():
            role, r, y = v["role"], v["rect"], v["floor_y"]
            if v.get("poly") and role != "lobby":
                continue
            w, d = r[2] - r[0], r[3] - r[1]
            cx, cz = (r[0] + r[2]) / 2, (r[1] + r[3]) / 2
            if v.get("core"):           # lobby around an edge core: centre the piece away from it
                cs, cr = v["core"]
                n = F.SIDE_N[cs]
                depth = (cr[3] - cr[1]) if cs in ("+z", "-z") else (cr[2] - cr[0])
                cx, cz = cx - n[0] * depth / 2, cz - n[1] * depth / 2
                w, d = (w, d - depth) if cs in ("+z", "-z") else (w - depth, d)
            feat = v.get("feature")
            if feat == "basin":
                s = min(3.2, min(w, d) * 0.4)
                items.append({"room": name, "type": "basin", "rect": (cx - s / 2, cz - s / 2, cx + s / 2, cz + s / 2),
                              "y": y, "water": deco["basin"], "rim": deco["rim"]})
            elif role in ("hall", "parlor", "lobby", "bedroom", "study", "cantina") and min(w, d) >= 3.2 and feat != "stage":
                rw, rd = min(4.0, w * 0.55), min(3.0, d * 0.5)
                if rd > rw and w > d:
                    rw, rd = rd, rw
                items.append({"room": name, "type": "rug", "rect": (cx - rw / 2, cz - rd / 2, cx + rw / 2, cz + rd / 2),
                              "y": y + 0.012, "shader": deco["rug"] if self.theme != "tato" or role != "bedroom" else SLUM_CLOTH})
            if v.get("stage"):
                st = v["stage"]
                items.append({"room": name, "type": "backdrop", "stage": st, "y": y, "rect": r,
                              "shader": deco["stage_cloth"]})
            walls = self._free_walls(name, door_marks)
            if role in ("hall", "parlor", "lobby", "cantina", "study", "shop") and walls:
                seg = max(walls, key=lambda s: s["len"])
                if seg["len"] >= 2.2:
                    items.append({"room": name, "type": "hanging", "wall": seg, "y": y + 0.9,
                                  "w": min(1.6, seg["len"] - 0.6), "h": min(2.4, v["height"] - 1.3),
                                  "shader": deco["hanging"]})
            if role == "bedroom" and walls:
                seg = max(walls, key=lambda s: s["len"])
                if seg["len"] >= 2.6:
                    items.append({"room": name, "type": "hanging", "wall": seg, "y": y + 0.15,
                                  "w": min(2.6, seg["len"] - 0.6), "h": min(2.8, v["height"] - 0.6),
                                  "shader": deco["curtain"]})
            if role == "shop" and walls:
                seg = max(walls, key=lambda s: s["len"])
                if seg["len"] >= 3.0 and min(w, d) >= 4.0:
                    ln = min(3.6, seg["len"] - 0.8)
                    p, q, n = seg["p"], seg["q"], seg["n_in"]
                    mx, mz = (p[0] + q[0]) / 2 + n[0] * 1.1, (p[1] + q[1]) / 2 + n[1] * 1.1
                    tx, tz = (q[0] - p[0]) / seg["len"], (q[1] - p[1]) / seg["len"]
                    xs = [mx - tx * ln / 2 - n[0] * 0.3, mx + tx * ln / 2 + n[0] * 0.3]
                    zs = [mz - tz * ln / 2 - n[1] * 0.3, mz + tz * ln / 2 + n[1] * 0.3]
                    items.append({"room": name, "type": "counter", "rect": (min(xs), min(zs), max(xs), max(zs)),
                                  "y": y, "shader": deco["counter"]})
        return items

    def _door_marks(self, entrances):
        """Doorway intervals on each room's walls: (room, axis, coord, lo, hi)."""
        marks = []
        for a, b, o in self.links:
            ra, rb = self.rooms[a], self.rooms[b]
            if abs(ra["floor_y"] - rb["floor_y"]) > 0.05 and not (ra.get("levels") or rb.get("levels") or ra.get("slope") or rb.get("slope")):
                continue
            s = shared(ra["rect"], rb["rect"])
            if s:
                for rm in (a, b):
                    marks.append((rm, s[0], s[1], s[2], s[3]))       # whole shared wall: keep decor off it
        for name, v in self.rooms.items():
            if v.get("core"):           # the core occupies that stretch of the lobby's outer wall
                cs, cr = v["core"]
                if cs in ("+z", "-z"):
                    marks.append((name, 1, cr[3] if cs == "+z" else cr[1], cr[0], cr[2]))
                else:
                    marks.append((name, 0, cr[2] if cs == "+x" else cr[0], cr[1], cr[3]))
        marks += getattr(self, "window_marks", [])
        for e in entrances:
            ax = 1 if e["side"] in ("+z", "-z") else 0
            u = e["at"][0] if ax == 1 else e["at"][1]
            coord = e["at"][1] if ax == 1 else e["at"][0]
            marks.append((e["room"], ax, None, u - 1.6, u + 1.6))
        return marks

    def _free_walls(self, name, marks):
        """Wall stretches of a rectangular room clear of doorways: [{p, q, n_in, len}]."""
        v = self.rooms[name]
        r = v["rect"]
        out = []
        walls = [(1, r[1], (r[0], r[2]), (0, 1)), (1, r[3], (r[0], r[2]), (0, -1)),
                 (0, r[0], (r[1], r[3]), (1, 0)), (0, r[2], (r[1], r[3]), (-1, 0))]
        for ax, coord, (lo, hi), n_in in walls:
            cuts = []
            for rm, max_, c, a, b in marks:
                if rm != name or max_ != ax:
                    continue
                if c is not None and abs(c - coord) > 0.05:
                    continue
                cuts.append((a - 0.3, b + 0.3))
            segs = pob_builder._subtract_intervals((lo, hi), cuts)
            # partition walls are drawn WALL / 2 inside the room: hang decor on that face, not inside the wall
            part = any(o is not v and abs(o["floor_y"] - v["floor_y"]) < 0.05 and (sh := shared(r, o["rect"])) and
                       sh[0] == ax and abs(sh[1] - coord) < 0.05 for o in self.rooms.values())
            off = WALL / 2 if part else WALL     # outside walls are inset the whole thickness
            c2 = coord + (n_in[0] if ax == 0 else n_in[1]) * off
            for a, b in segs:
                if b - a < 1.0:
                    continue
                p = (a, c2) if ax == 1 else (c2, a)
                q = (b, c2) if ax == 1 else (c2, b)
                out.append({"p": p, "q": q, "n_in": n_in, "len": b - a})
        return out


# ============================================================================
# decor geometry
# ============================================================================

def build_decor(root, items, rooms_summary, prefix):
    """Decor meshes under each room's cell (rN|mesh) with stock shaders; basins and counters also go into the
    cell collision (rN|collision|extent)."""
    cell_of = {r["name"]: r["cell"] for r in rooms_summary}
    made = 0
    for k, it in enumerate(items):
        cell = cell_of.get(it["room"])
        if not cell:
            continue
        mesh_grp = f"{root}|{cell}|mesh"
        col_grp = f"{root}|{cell}|collision"
        t = it["type"]
        if t == "rug":
            r, y = it["rect"], it["y"]
            acc = pob_builder.MeshAccumulator(fit=True)
            acc.facing([(r[0], y, r[1]), (r[2], y, r[1]), (r[2], y, r[3]), (r[0], y, r[3])], (0, 1, 0))
            _put(acc, f"{it['room']}_rug", mesh_grp, it["shader"], prefix + "_rug" + str(k))
        elif t == "hanging":
            seg, y, w, h = it["wall"], it["y"], it["w"], it["h"]
            p, q, n = seg["p"], seg["q"], seg["n_in"]
            mx, mz = (p[0] + q[0]) / 2 + n[0] * 0.03, (p[1] + q[1]) / 2 + n[1] * 0.03
            tx, tz = (q[0] - p[0]) / seg["len"], (q[1] - p[1]) / seg["len"]
            a = (mx - tx * w / 2, mz - tz * w / 2)
            b = (mx + tx * w / 2, mz + tz * w / 2)
            acc = pob_builder.MeshAccumulator(fit=True)
            acc.facing([(a[0], y, a[1]), (b[0], y, b[1]), (b[0], y + h, b[1]), (a[0], y + h, a[1])], (n[0], 0, n[1]))
            _put(acc, f"{it['room']}_hanging", mesh_grp, it["shader"], prefix + "_hang" + str(k))
        elif t == "basin":
            r, y = it["rect"], it["y"]
            rim_h, rim_w = 0.5, 0.3
            box = pob_builder.MeshAccumulator(2.0)
            _box(box, r, y, y + rim_h)
            inner = (r[0] + rim_w, r[1] + rim_w, r[2] - rim_w, r[3] - rim_w)
            _box(box, inner, y + 0.05, y + rim_h, inward=True)
            _put(box, f"{it['room']}_basin", mesh_grp, it["rim"], prefix + "_rim" + str(k))
            water = pob_builder.MeshAccumulator(1.5)
            wy = y + rim_h - 0.08
            water.facing([(inner[0], wy, inner[1]), (inner[2], wy, inner[1]), (inner[2], wy, inner[3]),
                          (inner[0], wy, inner[3])], (0, 1, 0))
            _put(water, f"{it['room']}_water", mesh_grp, it["water"], prefix + "_water" + str(k))
            col = pob_builder.MeshAccumulator()
            _box(col, r, y, y + rim_h)
            _collision(col, f"{it['room']}_basin_collision", col_grp)
        elif t == "counter":
            r, y = it["rect"], it["y"]
            body = pob_builder.MeshAccumulator(1.0)
            _box(body, r, y, y + 0.9)
            _put(body, f"{it['room']}_counter", mesh_grp, it["shader"], prefix + "_counter" + str(k))
            glass = pob_builder.MeshAccumulator(fit=True)
            gr = (r[0] - 0.05, r[1] - 0.05, r[2] + 0.05, r[3] + 0.05)
            _box(glass, gr, y + 0.9, y + 0.95)
            _put(glass, f"{it['room']}_counter_glass", mesh_grp, GLASS, prefix + "_glass" + str(k))
            col = pob_builder.MeshAccumulator()
            _box(col, r, y, y + 0.95)
            _collision(col, f"{it['room']}_counter_collision", col_grp)
        elif t == "backdrop":
            st, y, r = it["stage"], it["y"], it["rect"]
            (x0, z0), (x1, z1) = st["min"], st["max"]
            ramp = st["ramp"]["side"]
            back = {"-z": ("+z", r[3]), "+z": ("-z", r[1]), "-x": ("+x", r[2]), "+x": ("-x", r[0])}[ramp]
            h = 3.0
            acc = pob_builder.MeshAccumulator(fit=True)
            yy = y + st["height"]
            if back[0] in ("+z", "-z"):
                zc = back[1] - 0.05 if back[0] == "+z" else back[1] + 0.05
                acc.facing([(x0, yy, zc), (x1, yy, zc), (x1, yy + h, zc), (x0, yy + h, zc)],
                           (0, 0, -1 if back[0] == "+z" else 1))
            else:
                xc = back[1] - 0.05 if back[0] == "+x" else back[1] + 0.05
                acc.facing([(xc, yy, z0), (xc, yy, z1), (xc, yy + h, z1), (xc, yy + h, z0)],
                           (-1 if back[0] == "+x" else 1, 0, 0))
            _put(acc, f"{it['room']}_backdrop", mesh_grp, it["shader"], prefix + "_backdrop" + str(k))
        made += 1
    return made


def _box(acc, r, y0, y1, inward=False):
    x0, z0, x1, z1 = r
    s = -1 if inward else 1
    acc.facing([(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)], (0, 0, -s))
    acc.facing([(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)], (0, 0, s))
    acc.facing([(x0, y0, z0), (x0, y0, z1), (x0, y1, z1), (x0, y1, z0)], (-s, 0, 0))
    acc.facing([(x1, y0, z0), (x1, y0, z1), (x1, y1, z1), (x1, y1, z0)], (s, 0, 0))
    if not inward:
        acc.facing([(x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)], (0, 1, 0))


def _put(acc, mesh_name, parent, shader, mat_name):
    if not acc.counts:
        return None
    m = acc.build(mesh_name, parent)
    sg = pob_builder._material(mat_name, (0.7, 0.7, 0.7), None, shader)
    cmds.sets(m, edit=True, forceElement=sg)
    return m


def _collision(acc, name, collision_grp):
    if not cmds.objExists(collision_grp):
        return None
    return pob_builder._collision_mesh(acc, name, collision_grp)
