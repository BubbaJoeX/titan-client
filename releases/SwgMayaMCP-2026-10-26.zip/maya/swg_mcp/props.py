"""POI props for every adventurer planet - runs inside Maya with SwgMayaEditor loaded.

Four placeable static props per planet, each themed on the factions of that planet's points of interest
(dsrc/sku.0/sys.server/compiled/game/datatables/poi): Tatooine's Jawas, Tuskens, moisture farmers and spice
fiends, Corellia's CorSec, smugglers, Selonians and swoop gangs, and so on. Built from kit.Piece primitives
(box / prism / log / rail) in stock exterior "a_" shaders: crates, banners and flags carry their texture once
per face (fit UVs), everything else is world-scaled like the kit.

Exported like kit.build: appearance/thm_<prefix>_poi_<prop>_s01.apt (exportStaticMesh -collision none) and the
collision boxes + radar footprint the host turns into a .lod. Maya space: x right, y up, z; the prop sits on its
origin, ground at y = 0 (feet sunk 0.2-0.5 m so it sits on sloped terrain)."""

from __future__ import annotations

import math

import maya.cmds as cmds
import maya.mel as mel

from . import kit
from . import pob_builder as pb

SP = kit.SP

# material key -> (stock shader, metres per tile or None = one texture per face)
MATS = {
    "crate": ("cargo_crate_1_asbd21", None), "crate2": ("cargo_crate_2_asbd21", None),
    "rust": ("metal_rusty_a_as9", 2.0), "spice": ("spice_a_as8", 1.0),
    "log": ("camp_trando_log_s01_asc13", 1.5), "logtop": ("camp_trando_log_top_s01_asc13", None),
    "hide": ("camp_trando_hide_tile_asc14", 1.5), "totemhide": ("camp_trando_totem_s01_hide_s01_asc13", None),
    "totem": ("camp_trando_totem_s01_wood_s01_asc13", 1.5), "totembase": ("dant_totempole_base_adb13", 2.0),
    "canvas": ("fbrc_canvas_stitched_as8", 1.0), "nsbanner": ("dath_nightsister_banners_as8", None),
    "impbanner": ("all_imp_banner_assoc_a_asb13", None), "flagblue": ("all_flag_blue_a_ad8", None),
    "flagyellow": ("all_flag_yellow_a_ad8", None), "flagalien": ("all_flag_alien_a_ad8", None),
    "rope": ("endr_lakehut_rope_as8", 0.5), "ewokpost": ("endr_ewok_post_adb13", 1.5),
    "mud": ("endr_ewok_hut_mud_adb13", 2.0), "drum": ("eqp_music_drum_a_asb13", None),
    "dish": ("all_radar_dish_as8", None), "antenna": ("corl_antenna_as8", 1.0), "statue": ("all_statue_a_asb13", 1.5),
    "coals": ("dant_hotcoals_ae9", 1.0), "nscoals": ("dath_nightsister_hotcoals_ae9", 1.0),
    "bone": ("eqp_bones_must_monster_jaw_large_asc13", 0.6), "impconc": ("all_imp_concrete_a_fallback_a2d13", 2.0),
    "cords": ("dath_nightsister_leather_cords_aa7", 1.0), "nymwall": ("thm_nym_metalwall_a2_adb13", 2.0),
    "nymlight": ("thm_nym_lights_ae9", 1.0), "nymtrim": ("thm_nym_metaltrim_asb14", 1.0),
    "orb": ("frn_all_otoh_gunga_house_lamp_asceb28", None), "fish": ("blackfish_side_as8", None),
    "rock": ("base_rock_as8", 2.0), "lightstrip": ("corl_wall_lightstrip_ae9", 1.0),
    "temple": ("temple_stone_b_as8", 2.0), "carving": ("temple_carvingsa_as8", None), "vines": ("temple_vines_aa7", 2.0),
    "boundwood": ("dath_nightsister_boundwood_asb13", 1.5), "nsrock": ("dath_nightsister_rock_asb13", 2.0),
    "dantwood": ("dant_wood_s01_asb13", 1.5), "thedstone": ("thed_stone_deco_asb13", 2.0),
    "adobe": ("stco_tato_dtlbase_a1_adb13", 2.0), "skymetal": ("corellia_sky_trim_metal_a_ads16", 1.5),
    "concrete": ("all_concrete_b_a_adb13", 2.0), "ashlog": ("eqp_camping_log_ashed_as8", 1.0),
    "trim": ("tato_starport_trim_horz_asb13", 1.0), "water": ("corl_fountain_water_ripple_ae9", 2.0),
}

# planet -> folder, prefix, props (name: builder)
PLANETS = {
    "tatooine": ("tatooine", "tato"), "corellia": ("corellia", "corl"), "naboo": ("naboo", "nboo"),
    "lok": ("lok", "lok"), "endor": ("endor", "endr"), "yavin4": ("yavin", "yavn"), "rori": ("rori", "rori"),
    "dathomir": ("dathomir", "dath"), "dantooine": ("dantooine", "dant"), "talus": ("talus", "talus"),
}


def _poly_facing(A, pts, uvs, want):
    """Polygon with explicit UVs, wound so its normal points along `want`."""
    n = pb._normal3(pts)
    if sum(n[i] * want[i] for i in range(3)) < 0:
        pts, uvs = pts[::-1], uvs[::-1]
    A.poly(pts, uvs)


class Prop(kit.Piece):
    """kit.Piece whose slots are MATS keys: fit accumulators (one texture per face) where MATS says None."""

    def a(self, slot):
        if slot not in self.acc:
            scale = MATS[slot][1]
            self.acc[slot] = pb.MeshAccumulator(scale or 1.0, fit=scale is None)
        return self.acc[slot]

    # -- oriented box: centre (x, y0..y1, z), half sizes, yaw (degrees) ------------------------------------------
    def obox(self, slot, x, z, hx, hz, y0, y1, yaw=0.0, collide=True, bottom=None, top=True):
        a = math.radians(yaw)
        c, s = math.cos(a), math.sin(a)
        corner = lambda u, v: (x + c * u - s * v, z + s * u + c * v)
        q = [corner(-hx, -hz), corner(hx, -hz), corner(hx, hz), corner(-hx, hz)]
        A = self.a(slot)
        for i in range(4):
            (ax, az), (bx, bz) = q[i - 1], q[i]
            mx, mz = (ax + bx) / 2 - x, (az + bz) / 2 - z
            A.facing([(ax, y0, az), (bx, y0, bz), (bx, y1, bz), (ax, y1, az)], (mx, 0, mz))
        if top:
            A.facing([(px, y1, pz) for px, pz in q], (0, 1, 0))
        if bottom or (bottom is None and y0 > 0.05):
            A.facing([(px, y0, pz) for px, pz in q], (0, -1, 0))
        if collide:
            xs, zs = [p[0] for p in q], [p[1] for p in q]
            self.boxes.append(((min(xs), y0, min(zs)), (max(xs), y1, max(zs))))
            self.footprint += [(q[0], q[1], q[2]), (q[0], q[2], q[3])]

    def crate(self, slot, x, z, size, y0=0.0, yaw=0.0, h=None):
        h = h or size
        self.obox(slot, x, z, size / 2, size / 2, y0, y0 + h, yaw)

    def cyl(self, slot, x, z, r, y0, y1, n=12, tip=None, collide=True, cap=None):
        self.log(slot, x, z, r, y0, y1, n=n, tip=tip)
        if cap:                                             # a separately textured lid (drum skin, log end)
            ring = [(x + r * math.cos(2 * math.pi * (k + 0.5) / n), z + r * math.sin(2 * math.pi * (k + 0.5) / n))
                    for k in range(n)]
            self.a(cap).facing([(px, y1 + 0.005, pz) for px, pz in ring], (0, 1, 0))
        if collide:
            self.boxes.append(((x - r, y0, z - r), (x + r, tip or y1, z + r)))
            self.footprint += kit._square(r, x, z)

    def cone(self, slot, x, z, r, y0, y1, n=8):
        """Spike / cone: a ring at y0 narrowing to a point at y1 (no collision)."""
        A = self.a(slot)
        ring = [(x + r * math.cos(2 * math.pi * k / n), z + r * math.sin(2 * math.pi * k / n)) for k in range(n)]
        for i in range(n):
            (ax, az), (bx, bz) = ring[i - 1], ring[i]
            A.facing([(ax, y0, az), (bx, y0, bz), (x, y1, z)], ((ax + bx) / 2 - x, 0.3, (az + bz) / 2 - z))

    def orb(self, slot, x, y, z, r, n=10):
        """A faceted ball: two latitude rings between the poles."""
        A = self.a(slot)
        rings = [(y - r, 0.0), (y - r * 0.5, r * 0.87), (y + r * 0.5, r * 0.87), (y + r, 0.0)]
        pts = [[(x + rr * math.cos(2 * math.pi * k / n), yy, z + rr * math.sin(2 * math.pi * k / n)) for k in range(n)]
               for yy, rr in rings]
        for j in range(3):
            for k in range(n):
                a0, a1, b0, b1 = pts[j][k - 1], pts[j][k], pts[j + 1][k - 1], pts[j + 1][k]
                want = (((a0[0] + a1[0] + b0[0] + b1[0]) / 4) - x, ((a0[1] + b1[1]) / 2) - y, ((a0[2] + a1[2] + b0[2] + b1[2]) / 4) - z)
                A.facing([a0, a1, b1, b0], want)

    def cloth(self, slot, p0, p1, y0, y1, sag=0.0):
        """A double-sided hanging sheet (banner, flag, hide) between plan points p0 and p1 from y0 up to y1;
        `sag` bows its middle out by that much."""
        (x0, z0), (x1, z1) = p0, p1
        nx, nz = -(z1 - z0), (x1 - x0)
        ln = math.hypot(nx, nz) or 1.0
        nx, nz = nx / ln, nz / ln
        A = self.a(slot)
        if sag:
            xm, zm = (x0 + x1) / 2 + nx * sag, (z0 + z1) / 2 + nz * sag
            halves = [((x0, z0), (xm, zm)), ((xm, zm), (x1, z1))]
        else:
            halves = [((x0, z0), (x1, z1))]
        fit = MATS[slot][1] is None
        L = math.hypot(x1 - x0, z1 - z0) or 1.0
        for (ax, az), (bx, bz) in halves:
            quad = [(ax, y0, az), (bx, y0, bz), (bx, y1, bz), (ax, y1, az)]
            if not fit:
                A.facing(quad, (nx, 0, nz))
                A.facing(quad, (-nx, 0, -nz))
                continue
            ua, ub = math.hypot(ax - x0, az - z0) / L, math.hypot(bx - x0, bz - z0) / L
            uvs = [(ua, 0.0), (ub, 0.0), (ub, 1.0), (ua, 1.0)]      # one texture across the whole sheet
            for want in ((nx, nz), (-nx, -nz)):
                _poly_facing(A, quad, uvs, (want[0], 0.0, want[1]))

    def pole(self, slot, x, z, r, h, y0=-0.4, tip=None):
        self.cyl(slot, x, z, r, y0, h, n=8, tip=tip)


# ---------------------------------------------------------------------------------------------------------------
# props
# ---------------------------------------------------------------------------------------------------------------

def _scatter(P, slot, pts, collide=False):
    for x, z, s, yaw in pts:
        P.obox(slot, x, z, s / 2, s * 0.35, -0.1, s * 0.5, yaw, collide=collide)


def tato_jawa_scrap_pile(P):
    """Jawa traders' salvage heap: rusty plates, a gutted crate, droid scrap, a canvas sheet over the top."""
    P.crate("crate", -0.6, 0.2, 1.1, yaw=12)
    P.crate("crate2", 0.7, -0.3, 0.8, yaw=-20)
    P.obox("rust", 0.1, 0.5, 1.4, 0.9, -0.3, 0.45, yaw=25)                    # base heap
    _scatter(P, "rust", [(1.2, 0.6, 0.9, 40), (-1.3, -0.5, 0.7, -15), (0.2, -0.9, 0.8, 70), (0.6, 0.9, 0.6, 5)])
    P.cyl("rust", -0.1, -0.2, 0.35, 0.45, 1.35, n=10, cap="trim")             # a droid's torso drum
    P.obox("rust", 0.9, 0.3, 0.6, 0.12, 0.8, 1.0, yaw=-35, collide=False)     # bent plate leaning on the crate
    P.cloth("canvas", (-1.2, 0.75), (0.2, 1.0), 0.45, 1.25, sag=0.15)


def tato_tusken_bone_totem(P):
    """Tusken raider camp marker: a bound pole hung with bantha bones, hide strips and a horned skull."""
    P.pole("totem", 0.0, 0.0, 0.16, 3.2, tip=3.6)
    P.cyl("totembase", 0.0, 0.0, 0.6, -0.3, 0.35, n=8)                        # stone ring at its foot
    for y, yaw in ((2.4, 0), (1.7, 60), (1.0, 120)):
        a = math.radians(yaw)
        for s in (-1, 1):
            P.obox("bone", s * 0.45 * math.cos(a), s * 0.45 * math.sin(a), 0.32, 0.05, y - 0.06, y + 0.06, yaw, collide=False)
    P.orb("bone", 0.0, 3.0, 0.0, 0.26)                                        # the skull
    for s in (-1, 1):                                                         # horns
        P.cone("bone", s * 0.24, 0.0, 0.07, 3.1, 3.55)
    P.cloth("totemhide", (-0.35, 0.18), (0.35, 0.18), 1.3, 2.2)


def tato_moisture_vaporator(P):
    """A moisture farmer's vaporator: a tall ribbed column on a tripod pad, condenser fins and a collar light."""
    P.cyl("adobe", 0.0, 0.0, 0.9, -0.4, 0.3, n=10)                            # sand pad
    for k in range(3):
        a = 2 * math.pi * k / 3
        P.obox("rust", 0.55 * math.cos(a), 0.55 * math.sin(a), 0.12, 0.12, 0.3, 1.1, math.degrees(a), collide=False)
    P.cyl("skymetal", 0.0, 0.0, 0.32, 0.3, 4.2, n=12)
    for y in (1.4, 2.3, 3.2):                                                 # condenser rings
        P.cyl("rust", 0.0, 0.0, 0.42, y, y + 0.12, n=12, collide=False)
    for k in range(4):                                                        # fins
        a = math.pi / 2 * k
        P.obox("rust", 0.48 * math.cos(a), 0.48 * math.sin(a), 0.2, 0.03, 1.4, 3.4, math.degrees(a), collide=False)
    P.cyl("rust", 0.0, 0.0, 0.22, 4.2, 4.5, n=12, tip=4.75, collide=False)


def tato_spice_crate_stack(P):
    """Spice fiends' stash: cargo crates, an open crate heaped with spice, sacks of it beside."""
    P.crate("crate", -0.7, 0.0, 1.2, yaw=4)
    P.crate("crate2", 0.6, -0.2, 1.0, yaw=-8)
    P.crate("crate", -0.6, 0.1, 0.9, y0=1.2, yaw=18)
    P.obox("crate2", 0.7, 0.9, 0.5, 0.5, 0.0, 0.6, yaw=30)                    # open crate...
    P.obox("spice", 0.7, 0.9, 0.42, 0.42, 0.6, 0.72, yaw=30, collide=False)   # ...heaped with spice
    for x, z in ((1.4, -0.6), (1.5, 0.2)):
        P.orb("canvas", x, 0.3, z, 0.32, n=8)


def corl_corsec_barrier(P):
    """CorSec checkpoint barrier: a concrete jersey block with a sky-metal crown and a blue light strip."""
    P.obox("concrete", 0.0, 0.0, 1.6, 0.45, -0.3, 0.35)
    P.obox("concrete", 0.0, 0.0, 1.6, 0.25, 0.35, 1.0, collide=False)
    P.obox("skymetal", 0.0, 0.0, 1.62, 0.28, 1.0, 1.12, collide=False)
    for s in (-1, 1):
        P.cloth("lightstrip", (-1.5, s * 0.26), (1.5, s * 0.26), 0.7, 0.82)
    for x in (-1.75, 1.75):                                                   # end posts
        P.obox("skymetal", x, 0.0, 0.14, 0.14, -0.3, 1.35)


def corl_smuggler_cargo_stack(P):
    """Smugglers' cache: crates stacked three high under a tied-down tarp."""
    P.crate("crate", -0.65, -0.3, 1.2, yaw=0)
    P.crate("crate2", 0.65, -0.3, 1.2, yaw=3)
    P.crate("crate2", -0.6, 0.85, 1.0, yaw=-6)
    P.crate("crate", 0.0, -0.3, 1.1, y0=1.2, yaw=10)
    P.cloth("canvas", (-1.3, -0.95), (1.3, -0.95), 0.4, 1.9, sag=0.1)
    for x in (-1.3, 1.3):
        P.obox("rope", x, -0.95, 0.03, 0.03, 0.0, 2.3, collide=False)


def corl_selonian_marker(P):
    """Selonian separatists' den marker: a rough standing stone ringed with smaller stones, a cord-bound charm."""
    P.prism("rock", [(-0.5, -0.4), (0.45, -0.5), (0.6, 0.3), (-0.1, 0.6), (-0.6, 0.2)], -0.4, 2.4, tip=2.9)
    P.boxes.append(((-0.6, -0.4, -0.5), (0.6, 2.9, 0.6)))
    P.footprint += kit._square(0.6)
    for k in range(6):
        a = 2 * math.pi * k / 6 + 0.3
        P.obox("rock", 1.3 * math.cos(a), 1.3 * math.sin(a), 0.22, 0.18, -0.2, 0.35, math.degrees(a), collide=False)
    P.obox("cords", 0.0, 0.0, 0.58, 0.6, 1.5, 1.65, collide=False, bottom=True)


def corl_swoop_barricade(P):
    """Swoop gang barricade: scrap plates welded across tyre-like drums, gang colours sprayed on a flag."""
    for x in (-1.5, 0.0, 1.5):
        P.cyl("rust", x, 0.0, 0.45, -0.2, 0.7, n=12, cap="trim")
    P.obox("rust", 0.0, 0.0, 2.1, 0.08, 0.5, 1.5, yaw=4)
    P.obox("rust", 0.6, 0.15, 0.8, 0.06, 0.9, 1.8, yaw=-10, collide=False)
    P.pole("antenna", -1.9, 0.0, 0.05, 2.6)
    P.cloth("flagyellow", (-1.9, 0.0), (-0.9, 0.0), 1.8, 2.5, sag=0.08)


def nboo_gungan_totem(P):
    """Gungan warriors' totem: a carved stone shaft crowned by a glowing gunga orb, flanked by two small orbs."""
    P.cyl("thedstone", 0.0, 0.0, 0.7, -0.3, 0.3, n=10)
    P.cyl("thedstone", 0.0, 0.0, 0.28, 0.3, 2.8, n=10)
    P.cyl("thedstone", 0.0, 0.0, 0.42, 2.8, 3.0, n=10, collide=False)
    P.orb("orb", 0.0, 3.4, 0.0, 0.42, n=12)
    for s in (-1, 1):
        P.cyl("thedstone", s * 0.95, 0.0, 0.12, -0.2, 1.2, n=8)
        P.orb("orb", s * 0.95, 1.4, 0.0, 0.2, n=10)


def nboo_tradefed_crates(P):
    """Trade Federation loyalists' supply drop: grey containers on a pallet with a lamp post."""
    P.obox("impconc", 0.0, 0.0, 1.4, 1.0, -0.2, 0.18)                         # pallet slab
    P.crate("crate2", -0.65, -0.4, 1.1, y0=0.18)
    P.crate("crate2", 0.65, -0.4, 1.1, y0=0.18, yaw=2)
    P.crate("crate", 0.0, 0.55, 0.9, y0=0.18, yaw=-12)
    P.crate("crate2", -0.6, -0.4, 0.9, y0=1.28, yaw=8)
    P.pole("skymetal", 1.25, 0.8, 0.06, 2.4)
    P.orb("lightstrip", 1.25, 2.5, 0.8, 0.14, n=8)


def nboo_swamp_drying_rack(P):
    """Swamp hunters' drying rack: a log A-frame hung with fish and stretched hides."""
    for x in (-1.6, 1.6):
        for z in (-0.4, 0.4):
            P.obox("log", x, z * 0.3, 0.07, 0.07, -0.3, 2.2, yaw=0, collide=x > 0 and z > 0)
    P.rail("log", -1.8, 1.8, 2.1, 0.0, 0.09)
    P.boxes.append(((-1.75, -0.3, -0.2), (1.75, 2.2, 0.2)))
    P.footprint += [((-1.75, -0.2), (1.75, -0.2), (1.75, 0.2)), ((-1.75, -0.2), (1.75, 0.2), (-1.75, 0.2))]
    for k, x in enumerate((-1.1, -0.5, 0.1, 0.7)):
        P.obox("rope", x, 0.0, 0.015, 0.015, 1.7, 2.1, collide=False)
        P.cloth("fish", (x - 0.3, 0.0), (x + 0.3, 0.0), 1.45, 1.75)
    P.cloth("hide", (1.0, 0.05), (1.55, 0.05), 0.6, 1.9)


def nboo_market_stall(P):
    """Naboo villagers' market stall: a stone counter under a striped canvas awning on four posts."""
    P.obox("thedstone", 0.0, 0.3, 1.4, 0.45, -0.2, 0.95)
    for x in (-1.5, 1.5):
        for z in (-0.6, 0.9):
            P.pole("dantwood", x, z, 0.07, 2.4)
    A = P.a("canvas")                                                         # sloped awning, both sides
    q = [(-1.7, 2.6, -0.8), (1.7, 2.6, -0.8), (1.7, 2.2, 1.1), (-1.7, 2.2, 1.1)]
    A.facing(q, (0, 1, 0.2))
    A.facing(q, (0, -1, -0.2))
    P.crate("crate", -0.8, 0.3, 0.4, y0=0.95, yaw=10)
    P.orb("orb", 0.6, 1.15, 0.3, 0.18)                                        # fruit / goods
    P.orb("spice", 0.2, 1.1, 0.35, 0.15)


def lok_nym_fuel_drums(P):
    """Nym's fuel dump: Nym-plated drums, two stacked, banded in trim, a warning lamp on the tallest."""
    for x, z, y0 in ((-0.6, -0.3, 0.0), (0.4, -0.4, 0.0), (-0.1, 0.5, 0.0), (0.9, 0.5, 0.0), (-0.1, -0.35, 1.25)):
        P.cyl("nymwall", x, z, 0.38, y0 - (0.2 if y0 == 0 else 0), y0 + 1.2, n=12, cap="nymtrim")
        for y in (y0 + 0.25, y0 + 0.9):
            P.cyl("nymtrim", x, z, 0.4, y, y + 0.06, n=12, collide=False)
    P.cyl("nymlight", -0.1, -0.35, 0.1, 2.45, 2.65, n=8, collide=False)


def lok_pirate_loot_pile(P):
    """Pirate raiders' loot: crates, an ammo case, a bent Nym hull plate and a flag on a broken antenna."""
    P.crate("crate", -0.5, 0.0, 1.0, yaw=-15)
    P.crate("crate2", 0.6, 0.3, 0.8, yaw=25)
    P.obox("nymwall", 0.2, -0.7, 1.1, 0.06, -0.2, 1.1, yaw=-8)
    P.obox("rust", 0.9, -0.2, 0.35, 0.2, 0.0, 0.3, yaw=60)
    P.pole("antenna", -1.2, 0.6, 0.04, 2.8)
    P.cloth("flagalien", (-1.2, 0.6), (-0.3, 0.6), 2.0, 2.7, sag=0.1)


def lok_warning_beacon(P):
    """Imperial patrol warning beacon: a Nym-metal pylon, lamp cage and banded light."""
    P.obox("nymwall", 0.0, 0.0, 0.5, 0.5, -0.4, 0.4)
    P.obox("nymwall", 0.0, 0.0, 0.22, 0.22, 0.4, 3.0)
    for y in (1.0, 2.0):
        P.obox("nymtrim", 0.0, 0.0, 0.26, 0.26, y, y + 0.1, collide=False)
    P.obox("nymlight", 0.0, 0.0, 0.3, 0.3, 3.0, 3.4, collide=False)
    P.obox("nymtrim", 0.0, 0.0, 0.34, 0.34, 3.4, 3.5, collide=False)
    P.cone("nymtrim", 0.0, 0.0, 0.2, 3.5, 3.9)


def lok_imperial_barrier(P):
    """Imperial roadblock: an imperial concrete block with an Imperial banner hung on two posts."""
    P.obox("impconc", 0.0, 0.0, 2.0, 0.5, -0.3, 1.1)
    for x in (-1.8, 1.8):
        P.obox("impconc", x, 0.0, 0.12, 0.12, 1.1, 3.0, collide=False)
    P.obox("impconc", 0.0, 0.0, 1.95, 0.08, 2.85, 3.05, collide=False, bottom=True)
    P.cloth("impbanner", (-0.7, -0.52), (0.7, -0.52), 1.15, 2.85)
    P.cloth("impbanner", (0.7, 0.52), (-0.7, 0.52), 1.15, 2.85)


def endr_ewok_totem(P):
    """Ewok village totem: a lashed post with a carved face block, feathers of bone and a hide pennant."""
    P.pole("ewokpost", 0.0, 0.0, 0.25, 3.0, tip=3.5)
    P.cyl("ewokpost", 0.0, 0.0, 0.34, 1.6, 2.3, n=8, collide=False)
    for y in (0.6, 1.2, 2.5):
        P.cyl("rope", 0.0, 0.0, 0.28, y, y + 0.15, n=8, collide=False)
    for k in range(4):
        a = math.pi / 2 * k + 0.4
        P.obox("bone", 0.4 * math.cos(a), 0.4 * math.sin(a), 0.2, 0.03, 2.75, 2.85, math.degrees(a), collide=False)
    P.cloth("hide", (0.25, 0.0), (0.9, 0.0), 1.5, 2.2)


def endr_ewok_drum(P):
    """Ewok signal drum: a big hide-skinned drum on a log stand with two beaters."""
    P.cyl("ewokpost", 0.0, 0.0, 0.65, 0.4, 1.25, n=14, cap="drum")
    P.cyl("rope", 0.0, 0.0, 0.67, 0.75, 0.85, n=14, collide=False)
    for k in range(3):
        a = 2 * math.pi * k / 3
        P.obox("ewokpost", 0.5 * math.cos(a), 0.5 * math.sin(a), 0.08, 0.08, -0.2, 0.45, collide=False)
    for s in (-1, 1):
        P.obox("ewokpost", 0.3 * s, 0.75, 0.03, 0.3, 0.6, 0.66, yaw=20 * s, collide=False, bottom=True)


def endr_dulok_fetish(P):
    """Dulok tribe fetish: crossed swamp poles strung with bones over a mud mound."""
    P.cyl("mud", 0.0, 0.0, 0.9, -0.4, 0.25, n=10)
    for s in (-1, 1):
        P.cyl("ewokpost", s * 0.6, 0.0, 0.08, 0.2, 2.4, n=6, collide=False)
    P.rail("ewokpost", -0.7, 0.7, 2.1, 0.0, 0.07)
    for x in (-0.4, 0.0, 0.4):
        P.obox("rope", x, 0.0, 0.01, 0.01, 1.6, 2.1, collide=False)
        P.obox("bone", x, 0.0, 0.05, 0.05, 1.3, 1.6, yaw=30, collide=False)
    P.orb("bone", 0.0, 2.45, 0.0, 0.18)
    P.boxes.append(((-0.7, 0.2, -0.15), (0.7, 2.4, 0.15)))


def endr_marauder_barricade(P):
    """Marauder barricade: sharpened logs lashed at an angle over a scrap-metal skirt."""
    for k in range(7):
        x = -1.8 + 0.6 * k
        P.cone("log", x, 0.0, 0.18, 1.6, 2.6)
        P.cyl("log", x, 0.0, 0.18, -0.4, 1.6, n=8, collide=False)
    P.rail("rope", -2.0, 2.0, 1.1, 0.0, 0.2)
    P.obox("rust", 0.0, 0.25, 2.0, 0.05, -0.2, 0.9, yaw=2, collide=False)
    P.boxes.append(((-2.0, -0.4, -0.3), (2.0, 2.6, 0.3)))
    P.footprint += [((-2, -0.3), (2, -0.3), (2, 0.3)), ((-2, -0.3), (2, 0.3), (-2, 0.3))]


def yavn_rebel_supply_cache(P):
    """Abandoned rebel camp's supply cache: crates under a canvas lean-to, a fallen flag."""
    P.crate("crate2", -0.5, 0.0, 1.0)
    P.crate("crate", 0.6, 0.1, 0.9, yaw=8)
    P.crate("crate2", 0.0, 0.0, 0.8, y0=1.0, yaw=-10)
    for x in (-1.4, 1.4):
        P.pole("dantwood", x, -0.9, 0.06, 2.2)
    A = P.a("canvas")
    q = [(-1.6, 2.2, -0.9), (1.6, 2.2, -0.9), (1.6, 0.6, 1.0), (-1.6, 0.6, 1.0)]
    A.facing(q, (0, 1, 0.5))
    A.facing(q, (0, -1, -0.5))
    P.cloth("flagblue", (1.0, 1.2), (1.9, 1.5), 0.02, 0.06)


def yavn_comm_mast(P):
    """Abandoned rebel comm mast: a guyed lattice pole with a radar dish, overgrown with jungle vines."""
    P.obox("concrete", 0.0, 0.0, 0.6, 0.6, -0.3, 0.3)
    P.obox("skymetal", 0.0, 0.0, 0.12, 0.12, 0.3, 5.0)
    for y in (1.5, 3.0, 4.5):
        P.obox("antenna", 0.0, 0.0, 0.35, 0.03, y, y + 0.05, collide=False)
    A = P.a("dish")                                                           # dish: a shallow cone, both sides
    n, r = 12, 0.9
    ring = [(r * math.cos(2 * math.pi * k / n), 4.6 + r * math.sin(2 * math.pi * k / n)) for k in range(n)]
    for k in range(n):
        (ax, ay), (bx, by) = ring[k - 1], ring[k]
        A.facing([(ax, ay, 0.5), (bx, by, 0.5), (0.0, 4.6, 0.2)], (0, 0, 1))
        A.facing([(ax, ay, 0.5), (bx, by, 0.5), (0.0, 4.6, 0.2)], (0, 0, -1))
    P.cloth("vines", (-0.15, 0.13), (0.15, 0.13), 0.3, 2.6)
    for k in range(3):                                                        # guy ropes
        a = 2 * math.pi * k / 3
        P.obox("rope", 1.2 * math.cos(a), 1.2 * math.sin(a), 0.01, 0.01, -0.2, 0.25, collide=False)


def yavn_hutt_scavenger_crates(P):
    """Hutt scavenger camp: crates of dug-up relics, temple stones loaded on a skid."""
    P.obox("rust", 0.0, 0.0, 1.5, 0.8, -0.2, 0.2)                             # skid
    P.crate("crate", -0.75, -0.1, 1.0, y0=0.2, yaw=5)
    P.crate("crate2", 0.6, 0.2, 0.9, y0=0.2, yaw=-12)
    P.obox("temple", 0.6, -0.5, 0.35, 0.25, 0.2, 0.6, yaw=20)
    P.obox("carving", 0.6, 0.2, 0.4, 0.06, 1.1, 1.7, yaw=-12, collide=False)   # a carved slab leaning on the crate


def yavn_temple_idol(P):
    """Massassi temple idol: a stepped plinth with a carved stele, vine-grown."""
    P.obox("temple", 0.0, 0.0, 1.1, 1.1, -0.4, 0.4)
    P.obox("temple", 0.0, 0.0, 0.8, 0.8, 0.4, 0.8)
    P.obox("temple", 0.0, 0.0, 0.4, 0.25, 0.8, 3.0)
    for s in (-1, 1):
        P.cloth("carving", (-0.4, s * 0.26), (0.4, s * 0.26), 1.2, 2.8)
    P.obox("temple", 0.0, 0.0, 0.55, 0.35, 3.0, 3.25, collide=False)
    P.cloth("vines", (0.41, -0.25), (0.41, 0.25), 0.8, 2.6)


def rori_gungan_fishing_rack(P):
    """Rori Gungan fishing camp: a frame of poles with nets of fish, a basket of the catch."""
    for x in (-1.5, 0.0, 1.5):
        P.pole("dantwood", x, 0.0, 0.07, 2.2)
    P.rail("dantwood", -1.6, 1.6, 2.05, 0.0, 0.06)
    for x in (-1.0, -0.4, 0.4, 1.0):
        P.cloth("fish", (x - 0.25, 0.02), (x + 0.25, 0.02), 1.35, 1.65)
        P.obox("rope", x, 0.02, 0.01, 0.01, 1.65, 2.05, collide=False)
    P.cyl("rope", 0.9, 0.8, 0.4, -0.1, 0.5, n=10)


def rori_gungan_shield_post(P):
    """Gungan shield generator post: a stone column with banded orbs, the shield emitter on top."""
    P.cyl("thedstone", 0.0, 0.0, 0.6, -0.3, 0.4, n=8)
    P.cyl("thedstone", 0.0, 0.0, 0.25, 0.4, 2.6, n=8)
    for y in (1.0, 1.8):
        P.cyl("skymetal", 0.0, 0.0, 0.3, y, y + 0.1, n=8, collide=False)
    P.cone("skymetal", 0.0, 0.0, 0.45, 2.6, 2.9)
    P.orb("orb", 0.0, 3.2, 0.0, 0.35)


def rori_gungan_dock_post(P):
    """Gungan bongo dock post: a thick mooring post with rope coils and a lantern orb."""
    P.pole("log", 0.0, 0.0, 0.3, 2.0, y0=-0.6)
    P.cyl("logtop", 0.0, 0.0, 0.31, 2.0, 2.05, n=8, collide=False)
    for y in (0.6, 0.8, 1.0):
        P.cyl("rope", 0.0, 0.0, 0.34, y, y + 0.12, n=10, collide=False)
    P.rail("log", 0.0, 0.7, 1.7, 0.0, 0.05)
    P.orb("orb", 0.7, 1.45, 0.0, 0.18)


def rori_kaadu_trough(P):
    """Kaadu water trough: a log trough on stone feet with a stone basin end."""
    P.obox("dantwood", 0.0, 0.0, 1.4, 0.4, 0.3, 0.45, collide=False)            # trough floor
    for z in (-0.33, 0.33):                                                   # long sides
        P.obox("dantwood", 0.0, z, 1.4, 0.07, 0.45, 0.85, collide=False)
    for x in (-1.33, 1.33):                                                   # ends
        P.obox("dantwood", x, 0.0, 0.07, 0.26, 0.45, 0.85, collide=False)
    P.a("water").facing([(-1.26, 0.72, -0.26), (1.26, 0.72, -0.26), (1.26, 0.72, 0.26), (-1.26, 0.72, 0.26)], (0, 1, 0))
    P.boxes.append(((-1.4, 0.3, -0.4), (1.4, 0.85, 0.4)))
    for x in (-1.1, 1.1):
        P.obox("thedstone", x, 0.0, 0.25, 0.45, -0.3, 0.3)


def dath_nightsister_banner(P):
    """Nightsister banner: a bound-wood frame flying a nightsister banner over a hot-coal brazier."""
    for x in (-0.8, 0.8):
        P.pole("boundwood", x, 0.0, 0.1, 3.4, tip=3.8)
    P.rail("boundwood", -1.0, 1.0, 3.1, 0.0, 0.08)
    P.cloth("nsbanner", (-0.7, 0.0), (0.7, 0.0), 1.0, 3.05)
    P.cyl("nsrock", 0.0, 0.9, 0.4, -0.2, 0.5, n=8)
    P.a("nscoals").facing([(0.35 * math.cos(a), 0.52, 0.9 + 0.35 * math.sin(a))
                           for a in (2 * math.pi * k / 8 for k in range(8))], (0, 1, 0))


def dath_ward_stones(P):
    """Singing Mountain clan ward stones: a ring of rune stones bound with leather cords."""
    for k in range(5):
        a = 2 * math.pi * k / 5
        x, z = 1.3 * math.cos(a), 1.3 * math.sin(a)
        h = 1.4 + 0.3 * (k % 2)
        P.obox("nsrock", x, z, 0.28, 0.2, -0.4, h, yaw=math.degrees(a) + 90)
        P.cone("nsrock", x, z, 0.24, h, h + 0.35)
        P.obox("cords", x, z, 0.3, 0.22, h * 0.55, h * 0.55 + 0.1, yaw=math.degrees(a) + 90, collide=False, bottom=True)
    P.obox("nsrock", 0.0, 0.0, 0.5, 0.5, -0.3, 0.3)


def dath_prison_pylon(P):
    """Imperial prison fence pylon: an imperial concrete post with a lit emitter and a cut fence stub."""
    P.obox("impconc", 0.0, 0.0, 0.45, 0.45, -0.4, 0.5)
    P.obox("impconc", 0.0, 0.0, 0.25, 0.25, 0.5, 3.2)
    P.obox("lightstrip", 0.0, 0.0, 0.27, 0.27, 2.6, 2.75, collide=False)
    P.obox("skymetal", 0.0, 0.0, 0.32, 0.32, 3.2, 3.35, collide=False)
    for y in (0.9, 1.7, 2.5):                                                 # torn fence wire stubs
        P.obox("antenna", 0.6, 0.0, 0.35, 0.02, y, y + 0.03, collide=False)


def dath_bone_altar(P):
    """Nightsister bone altar: a rough rock slab on two stones, a skull and bones, coals in a bowl."""
    for x in (-0.8, 0.8):
        P.obox("nsrock", x, 0.0, 0.3, 0.45, -0.3, 0.75)
    P.obox("nsrock", 0.0, 0.0, 1.3, 0.6, 0.75, 1.0)
    P.orb("bone", -0.4, 1.2, 0.0, 0.2)
    for k in range(3):
        P.obox("bone", 0.3 + 0.15 * k, 0.1 * k - 0.1, 0.25, 0.04, 1.0, 1.06, yaw=30 * k, collide=False)
    P.cyl("nsrock", 0.75, 0.25, 0.22, 1.0, 1.15, n=8, collide=False)
    P.a("nscoals").facing([(0.75 + 0.2 * math.cos(a), 1.16, 0.25 + 0.2 * math.sin(a))
                           for a in (2 * math.pi * k / 8 for k in range(8))], (0, 1, 0))


def dant_janta_hide_rack(P):
    """Janta tribe hide rack: two posts and a crossbar with hides stretched on rope frames."""
    for x in (-1.4, 1.4):
        P.pole("dantwood", x, 0.0, 0.1, 2.4)
    P.rail("dantwood", -1.5, 1.5, 2.2, 0.0, 0.08)
    P.cloth("hide", (-1.2, 0.0), (-0.1, 0.0), 0.7, 2.1, sag=0.1)
    P.cloth("totemhide", (0.1, 0.0), (1.2, 0.0), 0.8, 2.1)


def dant_kunga_totem_pole(P):
    """Kunga tribe totem pole: a stacked carved pole on Dantooine's totem base, hide streamers."""
    P.cyl("totembase", 0.0, 0.0, 0.7, -0.3, 0.4, n=8)
    P.cyl("totem", 0.0, 0.0, 0.3, 0.4, 4.0, n=8)
    for y in (1.3, 2.3, 3.3):
        P.cyl("totem", 0.0, 0.0, 0.42, y, y + 0.35, n=8, collide=False)
    for s in (-1, 1):
        P.obox("totem", s * 0.6, 0.0, 0.35, 0.08, 3.4, 3.55, collide=False, bottom=True)
    P.cone("totem", 0.0, 0.0, 0.32, 4.0, 4.6)
    P.cloth("totemhide", (0.3, 0.0), (0.8, 0.0), 2.0, 3.3)


def dant_mokk_bone_fence(P):
    """Mokk tribe bone fence: a 4 m run of posts topped with skulls, horns lashed between."""
    for x in (-2.0, -1.0, 0.0, 1.0, 2.0):
        P.cyl("dantwood", x, 0.0, 0.1, -0.4, 1.6, n=6, collide=False)
        P.orb("bone", x, 1.75, 0.0, 0.16)
    for y in (0.6, 1.2):
        P.rail("dantwood", -2.05, 2.05, y, 0.0, 0.05)
    for x in (-1.5, -0.5, 0.5, 1.5):
        P.obox("bone", x, 0.05, 0.4, 0.03, 0.85, 0.95, yaw=20, collide=False, bottom=True)
    P.boxes.append(((-2.1, -0.4, -0.15), (2.1, 1.9, 0.15)))
    P.footprint += [((-2.1, -0.15), (2.1, -0.15), (2.1, 0.15)), ((-2.1, -0.15), (2.1, 0.15), (-2.1, 0.15))]


def dant_tribal_firepit(P):
    """Tribal firepit: a ring of stones, burnt logs over hot coals, a spit on forked sticks."""
    for k in range(9):
        a = 2 * math.pi * k / 9
        P.obox("rock", 0.9 * math.cos(a), 0.9 * math.sin(a), 0.2, 0.15, -0.2, 0.25, math.degrees(a), collide=False)
    P.a("coals").facing([(0.7 * math.cos(a), 0.06, 0.7 * math.sin(a)) for a in (2 * math.pi * k / 10 for k in range(10))], (0, 1, 0))
    for k in range(4):
        a = math.pi / 4 * k
        P.obox("log", 0.0, 0.0, 0.55, 0.07, 0.08, 0.22, math.degrees(a), collide=False)
    for x in (-1.0, 1.0):
        P.obox("dantwood", x, 0.0, 0.04, 0.04, -0.2, 1.1, collide=False)
    P.rail("dantwood", -1.05, 1.05, 1.0, 0.0, 0.03)
    P.boxes.append(((-1.1, -0.2, -1.1), (1.1, 0.3, 1.1)))
    P.footprint += kit._square(1.1)


def talus_sandbag_wall(P):
    """Talus militia sandbag wall: three courses of canvas sandbags in a shallow arc."""
    for row in range(3):
        n = 6 - row
        for k in range(n):
            x = (k - (n - 1) / 2) * 0.62
            z = 0.04 * x * x
            P.obox("canvas", x, z, 0.3, 0.22, row * 0.28 - 0.05, row * 0.28 + 0.24, yaw=-6 * x, collide=False)
    P.boxes.append(((-1.9, -0.05, -0.3), (1.9, 0.85, 0.45)))
    P.footprint += [((-1.9, -0.3), (1.9, -0.3), (1.9, 0.45)), ((-1.9, -0.3), (1.9, 0.45), (-1.9, 0.45))]


def talus_bandit_loot_crates(P):
    """Talus bandits' stolen goods: crates under a canvas, a rust drum, a lamp."""
    P.crate("crate", -0.4, 0.0, 1.1, yaw=-5)
    P.crate("crate2", 0.7, 0.2, 0.8, yaw=15)
    P.crate("crate2", 0.6, 0.15, 0.6, y0=0.8, yaw=40)
    P.cloth("canvas", (-1.0, -0.6), (0.2, -0.6), 0.2, 1.2, sag=0.08)
    P.cyl("rust", -1.2, 0.6, 0.35, -0.1, 0.95, n=12, cap="trim")


def talus_watch_post(P):
    """Militia watch post: a raised timber platform with a railing, ladder and a lamp."""
    for x in (-1.0, 1.0):
        for z in (-1.0, 1.0):
            P.pole("dantwood", x, z, 0.1, 2.5)
    P.box("dantwood", -1.2, 2.5, -1.2, 1.2, 2.7, 1.2, collide=True)
    for z in (-1.15, 1.15):
        P.rail("dantwood", -1.2, 1.2, 3.6, z, 0.05)
    for x in (-1.15, 1.15):
        P.box("dantwood", x - 0.04, 3.55, -1.2, x + 0.04, 3.65, 1.2)
    for x in (-1.15, 1.15):
        for z in (-1.15, 1.15):
            P.cyl("dantwood", x, z, 0.06, 2.7, 3.7, n=6, collide=False)
    for y in (0.4, 0.9, 1.4, 1.9, 2.4):                                       # ladder rungs on the -z side
        P.rail("dantwood", -0.35, 0.35, y, -1.3, 0.03)
    for x in (-0.38, 0.38):
        P.obox("dantwood", x, -1.3, 0.04, 0.04, -0.2, 2.7, collide=False)
    P.orb("lightstrip", 1.15, 3.85, 1.15, 0.12)


def talus_signal_flag(P):
    """Militia signal flag: a tall pole on a concrete foot flying the yellow flag, guy ropes."""
    P.obox("concrete", 0.0, 0.0, 0.4, 0.4, -0.3, 0.3)
    P.pole("skymetal", 0.0, 0.0, 0.06, 5.5)
    P.orb("skymetal", 0.0, 5.6, 0.0, 0.1)
    P.cloth("flagyellow", (0.05, 0.0), (1.6, 0.0), 4.4, 5.4, sag=0.12)
    for k in range(3):
        a = 2 * math.pi * k / 3
        P.obox("rope", 0.8 * math.cos(a), 0.8 * math.sin(a), 0.02, 0.02, -0.1, 0.2, collide=False)


PROPS = {
    "tatooine": {"jawa_scrap_pile": tato_jawa_scrap_pile, "tusken_bone_totem": tato_tusken_bone_totem,
                 "moisture_vaporator": tato_moisture_vaporator, "spice_crate_stack": tato_spice_crate_stack},
    "corellia": {"corsec_barrier": corl_corsec_barrier, "smuggler_cargo_stack": corl_smuggler_cargo_stack,
                 "selonian_marker": corl_selonian_marker, "swoop_barricade": corl_swoop_barricade},
    "naboo": {"gungan_totem": nboo_gungan_totem, "tradefed_crates": nboo_tradefed_crates,
              "swamp_drying_rack": nboo_swamp_drying_rack, "market_stall": nboo_market_stall},
    "lok": {"nym_fuel_drums": lok_nym_fuel_drums, "pirate_loot_pile": lok_pirate_loot_pile,
            "warning_beacon": lok_warning_beacon, "imperial_barrier": lok_imperial_barrier},
    "endor": {"ewok_totem": endr_ewok_totem, "ewok_drum": endr_ewok_drum, "dulok_fetish": endr_dulok_fetish,
              "marauder_barricade": endr_marauder_barricade},
    "yavin4": {"rebel_supply_cache": yavn_rebel_supply_cache, "comm_mast": yavn_comm_mast,
               "hutt_scavenger_crates": yavn_hutt_scavenger_crates, "temple_idol": yavn_temple_idol},
    "rori": {"gungan_fishing_rack": rori_gungan_fishing_rack, "gungan_shield_post": rori_gungan_shield_post,
             "gungan_dock_post": rori_gungan_dock_post, "kaadu_trough": rori_kaadu_trough},
    "dathomir": {"nightsister_banner": dath_nightsister_banner, "ward_stones": dath_ward_stones,
                 "prison_pylon": dath_prison_pylon, "bone_altar": dath_bone_altar},
    "dantooine": {"janta_hide_rack": dant_janta_hide_rack, "kunga_totem_pole": dant_kunga_totem_pole,
                  "mokk_bone_fence": dant_mokk_bone_fence, "tribal_firepit": dant_tribal_firepit},
    "talus": {"sandbag_wall": talus_sandbag_wall, "bandit_loot_crates": talus_bandit_loot_crates,
              "watch_post": talus_watch_post, "signal_flag": talus_signal_flag},
}


def build_prop(planet, prop):
    P = Prop()
    PROPS[planet][prop](P)
    if not P.boxes:
        raise ValueError(f"{planet} {prop}: no collision")
    return P


def prop_name(planet, prop, suffix=1):
    return f"{PLANETS[planet][1]}_poi_{prop}_s{suffix:02d}"


def _scene_meshes(P, root, tag):
    for slot, acc in P.acc.items():
        if not acc.counts:
            continue
        sg = f"poi_{slot}SG"                                # one material per slot per scene
        if not cmds.objExists(sg):
            sg = pb._material(f"poi_{slot}", (0.6, 0.6, 0.6), None, SP(MATS[slot][0]))
        cmds.sets(acc.build(f"{tag}_{slot}", "|" + root), edit=True, forceElement=sg)


def build(planet, prop, export_root, suffix=1):
    """Build one prop in a fresh scene and export appearance/thm_<name>.apt + its mesh."""
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    name = prop_name(planet, prop, suffix)
    P = build_prop(planet, prop)
    root = cmds.createNode("transform", name="thm_" + name)
    _scene_meshes(P, root, name)
    apt = f"{export_root}/appearance/thm_{name}.apt".replace("\\", "/")
    cmds.select("|" + root, replace=True)
    mel.eval(f'exportStaticMesh -path "{apt}" -collision none')
    bb = cmds.exactWorldBoundingBox("|" + root)
    return {"name": name, "planet": planet, "prop": prop, "dir": PLANETS[planet][0], "apt": f"appearance/thm_{name}.apt",
            "bounds": [round(v, 3) for v in bb], "boxes": [[list(map(float, a)), list(map(float, b))] for a, b in P.boxes],
            "composite": len(P.boxes) > 1, "footprint": [[list(p) for p in tri] for tri in P.footprint],
            "shaders": sorted({MATS[s][0] for s, acc in P.acc.items() if acc.counts})}


def preview(planet, gap=2.0):
    """The planet's four props side by side (review renders; nothing exported)."""
    cmds.file(new=True, force=True)
    x = 0.0
    for prop in PROPS[planet]:
        P = build_prop(planet, prop)
        grp = cmds.createNode("transform", name=f"{planet}_{prop}")
        _scene_meshes(P, grp, prop)
        bb = cmds.exactWorldBoundingBox("|" + grp)
        cmds.setAttr(f"|{grp}.translateX", x - bb[0])
        x += (bb[3] - bb[0]) + gap
    return {"planet": planet, "width": x}
