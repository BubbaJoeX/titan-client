"""Junction pieces for the stock Corellia bridges (thm_corl_imprv_bridge_sm/lg/insert_s01/s02) - runs inside Maya
with SwgMayaEditor loaded; examples/make_corl_bridges.py exports them and writes lods and templates.

Measured from the stock bridges (Maya space, bridge along z): 7.5 m wide over the parapets (x +-3.75), walk floor
x +-2.75 at y 0 where a bridge ends (0.25 along its span), parapet beams x 2.75..3.75 up to y 1.0 with a bulging
outer face down to -0.25, a pipe rail on posts at x +-3.12 / y 1.0..1.33, structure down to -2.5. A bridge's floor
ends are crossable, so a junction whose floor arms end exactly where a bridge's floor begins hands the player over.

Pieces (each in style s01 = marble with dark lit strips, s02 = concrete with metal strips, like the stock pair):
  4way        a plus-shaped deck open on all four sides, rounded corner pylons, the rail wrapping each corner
  3way        T junction: the -z side closed by a parapet
  corner      L: the -z and -x sides closed
  4way_lit    4way with a lamp post on each pylon (glow + light from a client data file)
Bridges attach with their ends on the junction's open edges (x or z = +-3.75)."""

from __future__ import annotations

import math
import os

import maya.cmds as cmds
import maya.mel as mel

from . import pob_builder as pb
from .kit import Piece

PIECES = ["4way", "3way", "corner", "4way_lit"]
STYLES = {
    "s01": {"body": "shader/corellia_marble_deta_adb13_phong.sht", "deck": "shader/corellia_concrete_b_adb13.sht",
            "rail": "shader/corellia_roof_metal_a_ads16.sht", "strip": "shader/corl_window_black_lt_aes17.sht"},
    "s02": {"body": "shader/all_concrete_b_a_adb13.sht", "deck": "shader/corellia_concrete_b_adb13.sht",
            "rail": "shader/corellia_roof_metal_a_ads16.sht", "strip": "shader/corellia_roof_metal_a_ads16.sht"},
}
UV = {"body": 3.0, "deck": 3.0, "rail": 1.0, "strip": 2.0}
HW, OW = 2.75, 3.75          # walk floor half width, outer half width
TOP, BASE, RAIL_X, RAIL_Y = 1.0, -0.25, 3.12, 1.33
# parapet cross-section (outward offset from the inner face at HW, y) sampled from the stock beam, bottom to top
PROFILE = [(0.75, BASE), (1.0, 0.0), (0.98, 0.26), (0.93, 0.5), (0.85, 0.71), (0.75, 0.87), (0.63, 0.97), (0.5, TOP)]


def _a(P, slot):
    return P.acc.setdefault(slot, pb.MeshAccumulator(UV.get(slot, 2.0)))


def _beam(P, u0, u1, side, axis="x"):
    """Straight parapet running along `axis` from u0 to u1 on the side (axis x: z = side * (HW..OW); axis z:
    x = side * (HW..OW)): the stock bulging profile, a flat top, the inner face down to the deck, a dark strip on
    the outer face, a pipe rail on posts; its inner face is a wall foot for the walk floor."""
    M = (lambda u, y, v: (u, y, v)) if axis == "x" else (lambda u, y, v: (v, y, u))
    N = (lambda du, dy, dv: (du, dy, dv)) if axis == "x" else (lambda du, dy, dv: (dv, dy, du))
    A = _a(P, "body")
    s = side
    prof = [(HW + d, y) for d, y in PROFILE]
    for (va, ya), (vb, yb) in zip(prof, prof[1:]):
        A.facing([M(u0, ya, s * va), M(u1, ya, s * va), M(u1, yb, s * vb), M(u0, yb, s * vb)], N(0, 0.2, s))
    A.facing([M(u0, TOP, s * (HW + 0.5)), M(u1, TOP, s * (HW + 0.5)), M(u1, TOP, s * HW), M(u0, TOP, s * HW)], (0, 1, 0))
    A.facing([M(u0, 0.0, s * HW), M(u1, 0.0, s * HW), M(u1, TOP, s * HW), M(u0, TOP, s * HW)], N(0, 0, -s))
    for u, du in ((u0, -1), (u1, 1)):                         # end caps (hidden against a pylon / bridge end)
        A.facing([M(u, BASE, s * HW)] + [M(u, y, s * v) for v, y in prof] + [M(u, TOP, s * HW)], N(du, 0, 0))
    _a(P, "strip").facing([M(u0, 0.56, s * (OW - 0.02)), M(u1, 0.56, s * (OW - 0.02)), M(u1, 0.7, s * (OW - 0.03)),
                           M(u0, 0.7, s * (OW - 0.03))], N(0, 0, s))
    n = max(1, int(round((u1 - u0) / 2.0)))
    for k in range(n + 1):
        u = u0 + (u1 - u0) * k / n
        a, b = M(u - 0.03, TOP, s * RAIL_X - 0.03), M(u + 0.03, RAIL_Y, s * RAIL_X + 0.03)
        P.box("rail", min(a[0], b[0]), TOP, min(a[2], b[2]), max(a[0], b[0]), RAIL_Y, max(a[2], b[2]))
    _pipe(P, [M(u0, RAIL_Y, s * RAIL_X), M(u1, RAIL_Y, s * RAIL_X)])
    a, b = M(u0, BASE, s * HW), M(u1, TOP, s * OW)
    P.boxes.append(((min(a[0], b[0]), BASE, min(a[2], b[2])), (max(a[0], b[0]), TOP, max(a[2], b[2]))))
    P.walls.facing([M(u0, -0.05, s * HW), M(u1, -0.05, s * HW), M(u1, TOP, s * HW), M(u0, TOP, s * HW)], N(0, 0, -s))


def _pipe(P, path, r=0.045, n=6):
    A = _a(P, "rail")
    for (ax, ay, az), (bx, by, bz) in zip(path, path[1:]):
        dx, dz = bx - ax, bz - az
        ln = math.hypot(dx, dz) or 1.0
        px, pz = -dz / ln, dx / ln                             # horizontal normal of the run
        ring = lambda cx, cy, cz: [(cx + px * r * math.cos(2 * math.pi * k / n), cy + r * math.sin(2 * math.pi * k / n),
                                    cz + pz * r * math.cos(2 * math.pi * k / n)) for k in range(n)]
        ra, rb = ring(ax, ay, az), ring(bx, by, bz)
        for k in range(n):
            mid = ((ra[k][0] + rb[k - 1][0]) / 2 - (ax + bx) / 2, (ra[k][1] + rb[k - 1][1]) / 2 - (ay + by) / 2,
                   (ra[k][2] + rb[k - 1][2]) / 2 - (az + bz) / 2)
            A.facing([ra[k - 1], ra[k], rb[k], rb[k - 1]], mid)


def _pylon(P, sx, sz, lamp=False):
    """Corner pylon on the quarter (sx, sz): plan square HW..OW on both axes with its outer corner rounded, the
    beam profile turned round the corner; the rail sweeps round it from one bridge's rail to the other's."""
    A = _a(P, "body")
    c = (sx * HW, sz * HW)
    seg = 8
    prof = [(d, y) for d, y in PROFILE]
    for k in range(seg):
        a0, a1 = math.pi / 2 * k / seg, math.pi / 2 * (k + 1) / seg
        d0 = (sx * math.cos(a0), sz * math.sin(a0))
        d1 = (sx * math.cos(a1), sz * math.sin(a1))
        for (ra, ya), (rb, yb) in zip(prof, prof[1:]):
            q = [(c[0] + d0[0] * ra, ya, c[1] + d0[1] * ra), (c[0] + d1[0] * ra, ya, c[1] + d1[1] * ra),
                 (c[0] + d1[0] * rb, yb, c[1] + d1[1] * rb), (c[0] + d0[0] * rb, yb, c[1] + d0[1] * rb)]
            A.facing(q, ((d0[0] + d1[0]) / 2, 0.2, (d0[1] + d1[1]) / 2))
        A.facing([(c[0], TOP, c[1]), (c[0] + d0[0] * 0.5, TOP, c[1] + d0[1] * 0.5),
                  (c[0] + d1[0] * 0.5, TOP, c[1] + d1[1] * 0.5)], (0, 1, 0))
        _a(P, "strip").facing([(c[0] + d0[0] * 0.99, 0.56, c[1] + d0[1] * 0.99), (c[0] + d1[0] * 0.99, 0.56, c[1] + d1[1] * 0.99),
                               (c[0] + d1[0] * 0.97, 0.7, c[1] + d1[1] * 0.97), (c[0] + d0[0] * 0.97, 0.7, c[1] + d0[1] * 0.97)],
                              ((d0[0] + d1[0]) / 2, 0, (d0[1] + d1[1]) / 2))
    # inner faces down to the deck (the pylon's two sides along the floor arms) + the walk floor's wall feet there
    # the two straight sides (facing the floor arms): the beam profile, closed back to the inner corner line
    A.facing([(sx * HW, BASE, sz * HW)] + [(sx * HW, y, sz * (HW + d)) for d, y in PROFILE] + [(sx * HW, TOP, sz * HW)], (-sx, 0, 0))
    A.facing([(sx * HW, BASE, sz * HW)] + [(sx * (HW + d), y, sz * HW) for d, y in PROFILE] + [(sx * HW, TOP, sz * HW)], (0, 0, -sz))
    P.walls.facing([(sx * HW, -0.05, sz * HW), (sx * HW, -0.05, sz * OW), (sx * HW, TOP, sz * OW), (sx * HW, TOP, sz * HW)], (-sx, 0, 0))
    P.walls.facing([(sx * HW, -0.05, sz * HW), (sx * OW, -0.05, sz * HW), (sx * OW, TOP, sz * HW), (sx * HW, TOP, sz * HW)], (0, 0, -sz))
    # rail: from one bridge's rail end (RAIL_X, OW) round the outer corner to the other's (OW, RAIL_X)
    rr = OW - RAIL_X
    arc = [(sx * (OW - rr * math.cos(math.pi / 2 * k / seg)), RAIL_Y, sz * (OW - rr * math.sin(math.pi / 2 * k / seg)))
           for k in range(seg + 1)]
    _pipe(P, arc)
    for x, y_, z in (arc[0], arc[seg // 2], arc[-1]):
        P.box("rail", x - 0.03, TOP, z - 0.03, x + 0.03, RAIL_Y, z + 0.03)
    P.boxes.append(((min(sx * HW, sx * OW), BASE, min(sz * HW, sz * OW)), (max(sx * HW, sx * OW), TOP, max(sz * HW, sz * OW))))
    if lamp:                                                 # lamp post: a slim metal pole with a glowing head
        lx, lz = sx * (HW + 0.45), sz * (HW + 0.45)
        P.box("rail", lx - 0.07, TOP, lz - 0.07, lx + 0.07, 4.2, lz + 0.07)
        P.box("rail", lx - 0.22, 4.2, lz - 0.22, lx + 0.22, 4.3, lz + 0.22)
        P.box("strip", lx - 0.16, 4.3, lz - 0.16, lx + 0.16, 4.75, lz + 0.16)
        P.box("rail", lx - 0.25, 4.75, lz - 0.25, lx + 0.25, 4.85, lz + 0.25)
        P.hardpoints.append((f"lamp_{'p' if sx > 0 else 'n'}x{'p' if sz > 0 else 'n'}z", (lx, 4.5, lz)))
        P.boxes.append(((lx - 0.15, TOP, lz - 0.15), (lx + 0.15, 4.85, lz + 0.15)))


def build_piece(piece, style):
    P = Piece()
    P.hardpoints = []
    closed_z = piece in ("3way", "corner")                    # -z side closed
    closed_x = piece == "corner"                              # -x side closed
    lamp = piece == "4way_lit"
    # deck slab: the square under everything (concrete top, body-coloured edge band), top at y 0
    D = _a(P, "deck")
    D.facing([(-OW, 0.0, -OW), (OW, 0.0, -OW), (OW, 0.0, OW), (-OW, 0.0, OW)], (0, 1, 0))
    B = _a(P, "body")
    for (ax, az), (bx, bz), n in ((((-OW, -OW), (OW, -OW), (0, -1))), (((OW, -OW), (OW, OW), (1, 0))),
                                  (((OW, OW), (-OW, OW), (0, 1))), (((-OW, OW), (-OW, -OW), (-1, 0)))):
        B.facing([(ax, BASE, az), (bx, BASE, bz), (bx, 0.0, bz), (ax, 0.0, az)], (n[0], 0, n[1]))
    B.facing([(-OW, BASE, -OW), (OW, BASE, -OW), (OW, BASE, OW), (-OW, BASE, OW)], (0, -1, 0))
    # central pier with flared feet under the deck (the stock bridges stand on curved feet down to -2.5)
    for y0, y1, h0, h1 in ((-2.5, -2.2, 1.6, 1.6), (-2.2, -0.9, 0.9, 0.9), (-0.9, BASE, 0.9, 1.7)):
        ring0 = [(-h0, -h0), (h0, -h0), (h0, h0), (-h0, h0)]
        ring1 = [(-h1, -h1), (h1, -h1), (h1, h1), (-h1, h1)]
        for k in range(4):
            (ax, az), (bx, bz) = ring0[k - 1], ring0[k]
            (cx, cz), (dx, dz) = ring1[k], ring1[k - 1]
            B.facing([(ax, y0, az), (bx, y0, bz), (cx, y1, cz), (dx, y1, dz)], ((ax + bx) / 2, 0, (az + bz) / 2))
    # pylons on the corners between open arms; parapets along closed sides
    for sx in (-1, 1):
        for sz in (-1, 1):
            if (closed_z and sz < 0) or (closed_x and sx < 0):
                continue
            _pylon(P, sx, sz, lamp)
    if closed_z:                                             # parapet across the closed side(s), corner to corner
        _beam(P, -OW, OW, -1, "x")
    if closed_x:
        _beam(P, -HW if closed_z else -OW, OW, -1, "z")
    # walk floor: plus shape, minus the closed arms
    fz0 = -HW if closed_z else -OW
    fx0 = -HW if closed_x else -OW
    ring = [(-HW, fz0), (HW, fz0), (HW, -HW), (OW, -HW), (OW, HW), (HW, HW), (HW, OW), (-HW, OW), (-HW, HW), (fx0, HW),
            (fx0, -HW), (-HW, -HW)]
    clean = []
    for p in ring:
        if not clean or (abs(clean[-1][0] - p[0]) > 1e-6 or abs(clean[-1][1] - p[1]) > 1e-6):
            clean.append(p)
    P.walk = [([(x, 0.0, z) for x, z in clean], [])]
    P.footprint = [((-OW, -OW), (OW, -OW), (OW, OW)), ((-OW, -OW), (OW, OW), (-OW, OW))]
    P.composite = True
    return P


def piece_name(piece, style):
    return f"corl_imprv_bridge_{piece}_{style}"


def build(piece, style, export_root):
    """One junction in a fresh scene: appearance/thm_<name>.apt + mesh + its walk floor (.flr)."""
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    name = piece_name(piece, style)
    P = build_piece(piece, style)
    root = cmds.createNode("transform", name="thm_" + name)
    for slot, acc in P.acc.items():
        if acc.counts:
            sg = pb._material(f"corl_bridge_{style}_{slot}", (0.7, 0.7, 0.68), None, STYLES[style][slot])
            cmds.sets(acc.build(f"{name}_{slot}", "|" + root), edit=True, forceElement=sg)
    for hp, pos in P.hardpoints:
        t = cmds.createNode("transform", name=hp, parent="|" + root)
        cmds.setAttr(t + ".translate", *pos, type="double3")
    coll = cmds.createNode("transform", name="collision", parent="|" + root)
    ext = cmds.createNode("transform", name="extent", parent=coll)
    if P.walls.counts:
        P.walls.build("walls", ext)
    fl = pb._facet_mesh(P.walk, "floor", "|" + root + "|collision", up=True)
    cmds.addAttr(fl, longName="swgFloorOpenEdgesCrossable", attributeType="bool")
    cmds.setAttr(fl + ".swgFloorOpenEdgesCrossable", True)
    flr_rel = f"appearance/collision/thm_{name}_collision_floor0.flr"
    os.makedirs(os.path.dirname(f"{export_root}/{flr_rel}"), exist_ok=True)
    cmds.select(fl, replace=True)
    cmds.file(f"{export_root}/{flr_rel}", force=True, exportSelected=True, type="SwgFlr")
    cmds.delete(coll)
    apt = f"{export_root}/appearance/thm_{name}.apt"
    cmds.select("|" + root, replace=True)
    mel.eval(f'exportStaticMesh -path "{apt}" -collision none')
    bb = cmds.exactWorldBoundingBox("|" + root)
    return {"name": name, "piece": piece, "style": style, "apt": f"appearance/thm_{name}.apt",
            "bounds": [round(v, 3) for v in bb], "boxes": [[list(map(float, a)), list(map(float, b))] for a, b in P.boxes],
            "composite": True, "footprint": [[list(p) for p in tri] for tri in P.footprint], "floor": flr_rel,
            "hardpoints": [h for h, _ in P.hardpoints]}


def preview(stock=True):
    """All junctions (both styles) in a row, optionally with stock small bridges attached to the first 4way."""
    cmds.file(new=True, force=True)
    x = 0.0
    for style in STYLES:
        for piece in PIECES:
            P = build_piece(piece, style)
            grp = cmds.createNode("transform", name=f"{piece}_{style}")
            for slot, acc in P.acc.items():
                if acc.counts:
                    sg = pb._material(f"corl_bridge_{style}_{slot}", (0.7, 0.7, 0.68), None, STYLES[style][slot]) \
                        if not cmds.objExists(f"corl_bridge_{style}_{slot}SG") else f"corl_bridge_{style}_{slot}SG"
                    cmds.sets(acc.build(f"{piece}_{style}_{slot}", "|" + grp), edit=True, forceElement=sg)
            cmds.setAttr(f"|{grp}.translateX", x)
            x += 11.0
    return {"count": len(STYLES) * len(PIECES)}
