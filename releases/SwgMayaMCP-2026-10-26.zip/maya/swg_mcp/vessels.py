"""Boardable vessels (Titan): stock ship hulls rebuilt as POB ships that players walk into up a ramp.

A vessel is a POB ShipObject. Its exterior cell r0 is the stock hull (with windows and the boarding doorway cut in);
the moving parts (boarding ramp, landing legs) are separate stock or new appearances hung on r0 hardpoints and
animated by the client from the vessel's hp_dyn "part" objvars (see TangibleObject::applyDynamicHardpointsState).

A ship has no walkable exterior floor (it is a mobile object), so the ramp is a cell of its own: an open-air cell
whose floor is the lowered ramp surface and whose foot portal stands on the ground, so players step from the
terrain into it and walk up into the cabin. Its floor rides with the ship like every cell floor.

Everything is built in Maya space with the vessel landed: the ground is y = 0. The POB itself is written in the
hull's own frame (the stock appearance frame, so the stock distance LODs still fit); `landed` in the result is the
hull frame relative to the ground point under the vessel, which is where scripts park it.
"""

from __future__ import annotations

import json
import math
import os
import struct

import maya.cmds as cmds
import maya.mel as mel
import maya.api.OpenMaya as om

from . import pob_builder as pb

DATA = os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game").replace("\\", "/")

GLASS = "shader/all_glass_a_aa7.sht"

# Blacksun transport passenger fittings: the stock transport-class interior set
TRANSPORT_MATERIALS = {
    "floor": ("shader/blacksun_transport_player_floor_cs9.sht", (0.45, 0.45, 0.47), 2.0),
    "aisle": ("shader/blacksun_transport_player_grate_cs9.sht", (0.40, 0.40, 0.42), 1.2),
    "wall": ("shader/blacksun_transport_player_wall1_cs9.sht", (0.62, 0.62, 0.64), 2.4),
    "lower": ("shader/blacksun_transport_player_wall2_cs9.sht", (0.55, 0.55, 0.57), 2.4),
    "upper": ("shader/blacksun_transport_player_wall3_cs9.sht", (0.60, 0.60, 0.62), 2.4),
    "ceiling": ("shader/blacksun_transport_player_ceiling_cs8.sht", (0.58, 0.58, 0.60), 2.0),
    "light": ("shader/blacksun_transport_player_light_ceb15.sht", (1.0, 0.97, 0.9), 1.0),
    "frame": ("shader/blacksun_transport_player_frame_cs9.sht", (0.35, 0.35, 0.37), 1.0),
    "trim": ("shader/blacksun_transport_player_trim_cs9.sht", (0.30, 0.30, 0.32), 1.0),
    "hall": ("shader/blacksun_transport_player_hall_cs9.sht", (0.50, 0.50, 0.52), 2.0),
    "glass": (GLASS, (0.55, 0.68, 0.78), 1.0),
}


# ============================================================================
# small geometry helpers (Maya space)
# ============================================================================

def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _unit(a):
    n = math.sqrt(_dot(a, a)) or 1.0
    return (a[0] / n, a[1] / n, a[2] / n)


class Faces:
    """Polygons grouped by material key; build() makes one mesh per material under a parent."""

    def __init__(self, materials):
        self.materials = materials
        self.acc = {}

    def add(self, key, corners, facing, fit=False):
        if key not in self.acc:
            self.acc[key] = pb.MeshAccumulator(uv_scale=self.materials[key][2], fit=fit or key in ("glass", "light"))
        self.acc[key].facing([tuple(c) for c in corners], facing)

    def add_uv(self, key, corners, uvs, facing):
        """A polygon with its own texture coordinates (atlas tiles), wound to face `facing`."""
        if key not in self.acc:
            self.acc[key] = pb.MeshAccumulator(uv_scale=self.materials[key][2])
        corners, uvs = [tuple(c) for c in corners], list(uvs)
        n = pb._normal3(corners)
        if sum(n[i] * facing[i] for i in range(3)) < 0:
            corners, uvs = corners[::-1], uvs[::-1]
        self.acc[key].poly(corners, uvs)

    def quad_strip(self, key, profile, z0, z1, inward):
        """Faces between consecutive profile points [(x, y)] swept from z0 to z1; `inward(p, q)` = facing."""
        for (x0, y0), (x1, y1) in zip(profile, profile[1:]):
            self.add(key, [(x0, y0, z0), (x1, y1, z0), (x1, y1, z1), (x0, y0, z1)], inward((x0, y0), (x1, y1)))

    def build(self, parent, prefix, sgs):
        made = []
        for key, acc in self.acc.items():
            m = acc.build(f"{prefix}_{key}", parent)
            if m:
                cmds.sets(m, edit=True, forceElement=sgs[key])
                made.append(m)
        return made


def _materials(prefix, table):
    return {k: pb._material(f"{prefix}_{k}", color, shader=sht) for k, (sht, color, _) in table.items()}


def _set_portal(xf, corners):
    """Reshape a connectPobCells quad to `corners` (Maya space, identity transform). The engine treats the side
    opposite the Maya polygon normal as the portal front (the exporter mirrors X), so order the corners with the
    Maya normal pointing away from the cell the portal should face into (the "to" cell)."""
    cmds.setAttr(xf + ".translate", 0.0, 0.0, 0.0, type="double3")
    cmds.setAttr(xf + ".rotate", 0.0, 0.0, 0.0, type="double3")
    shape = cmds.listRelatives(xf, shapes=True, fullPath=True)[0]
    sel = om.MSelectionList()
    sel.add(shape)
    fn = om.MFnMesh(sel.getDagPath(0))
    if fn.numVertices != len(corners):
        raise ValueError(f"{xf}: portal quad has {fn.numVertices} vertices, got {len(corners)} corners")
    fn.setPoints(om.MPointArray([om.MPoint(*c) for c in corners]), om.MSpace.kObject)
    for attr in ("primaryVisibility", "castsShadows"):
        cmds.setAttr(f"{shape}.{attr}", 0)


def portal(root, a, b, corners, inside_b, passable=True, door_style=None):
    """Portal between cells ra and rb whose front faces into rb: `corners` is a planar convex polygon in either
    winding; `inside_b` a point inside rb that the front must face. `door_style` (a vertical doorway only) hangs
    that stock door leaf on both sides, hardpoint at the doorway's bottom centre like stock portals."""
    mel.eval(f'connectPobCells -root "{root}" -from r{a} -to r{b} -w 1 -h 1'
             + (f' -doorStyle "{door_style}"' if door_style else ""))
    pair = cmds.ls(selection=True, long=True)
    poly = [tuple(c) for c in corners]
    n = _cross(_sub(poly[1], poly[0]), _sub(poly[2], poly[0]))
    c = _mul([sum(q[i] for q in poly) for i in range(3)], 1.0 / len(poly))
    if _dot(n, _sub(inside_b, c)) > 0:               # the Maya normal must point away from rb
        poly.reverse()
    for xf in pair:
        _set_portal(xf, poly)
        if door_style:
            nh = math.hypot(n[0], n[2]) or 1.0
            bottom = (c[0], min(q[1] for q in poly) - 0.1, c[2])      # stock leaves hang 0.1 under the floor
            pb._door_hardpoint(xf, bottom, (n[0] / nh, n[2] / nh))
        if not passable:
            if not cmds.attributeQuery("portalPassable", node=xf, exists=True):
                cmds.addAttr(xf, longName="portalPassable", attributeType="bool")
            cmds.setAttr(xf + ".portalPassable", False)
    return {"between": [f"r{a}", f"r{b}"], "passable": passable, "door": door_style or "",
            "index": cmds.getAttr(pair[0] + ".buildingPortalIndex")}


def _floor(cell, corners):
    """Walk floor (collision floor0) for a cell: one convex polygon facing up, or a list of them."""
    polys = corners if isinstance(corners[0][0], (list, tuple)) else [corners]
    acc = pb.MeshAccumulator()
    for poly in polys:
        acc.facing(poly, (0.0, 1.0, 0.0))
    grp = cell + "|collision"
    if not cmds.objExists(grp):
        cmds.createNode("transform", name="collision", parent=cell)
    if not cmds.objExists(grp + "|floor0"):
        cmds.createNode("transform", name="floor0", parent=grp)
    m = acc.build("floor0_mesh", grp + "|floor0")
    cmds.sets(m, edit=True, forceElement="initialShadingGroup")
    pb._hide_helper(m)
    return m


def _lights(cell, ambient, points, parallels):
    """Stock cell lighting: ambient + point lights (linear falloff, HDR colours) + parallel lights."""
    grp = cmds.createNode("transform", name="lights", parent=cell)
    amb = cmds.ambientLight(**pb._light_args(*ambient))
    cmds.parent(cmds.listRelatives(amb, parent=True, fullPath=True)[0], grp)
    for pos, rgb, intensity in points:
        pt = cmds.pointLight(**pb._light_args(rgb, intensity * pb.LINEAR_GAIN))
        xf = cmds.parent(cmds.listRelatives(pt, parent=True, fullPath=True)[0], grp)[0]
        cmds.setAttr(xf + ".translate", *pos, type="double3")
        shape = cmds.listRelatives(xf, shapes=True, fullPath=True)[0]
        for attr, value in (("constantAttenuation", 0.0), ("linearAttenuation", 1.0), ("quadraticAttenuation", 0.0)):
            if not cmds.attributeQuery(attr, node=shape, exists=True):
                cmds.addAttr(shape, longName=attr, attributeType="float")
            cmds.setAttr(f"{shape}.{attr}", value)
    for direction, rgb, intensity in parallels:
        dl = cmds.directionalLight(**pb._light_args(rgb, intensity))
        xf = cmds.parent(cmds.listRelatives(dl, parent=True, fullPath=True)[0], grp)[0]
        dx, dy, dz = _unit(direction)
        cmds.setAttr(xf + ".rotate", math.degrees(math.asin(max(-1.0, min(1.0, dy)))),
                     math.degrees(math.atan2(-dx, -dz)), 0.0, type="double3")
    return grp


def mark_uv_direct(shapes):
    """Stock meshes come in with their UVs as stored (the SwgPob / SwgMsh importers don't flip V); the exporter's
    default writes 1 - v, so a re-exported stock surface samples its texture atlas upside down - the wrong art
    altogether. swgExportUvDirect on the shading groups of imported stock faces exports their UVs as they are; the
    geometry this module builds (vs.Faces) is authored for the default and keeps it."""
    sgs = set()
    for shape in shapes:
        sgs.update(cmds.listConnections(shape, type="shadingEngine") or [])
    for sg in sgs:
        if not cmds.attributeQuery("swgExportUvDirect", node=sg, exists=True):
            cmds.addAttr(sg, longName="swgExportUvDirect", attributeType="bool")
        cmds.setAttr(sg + ".swgExportUvDirect", True)
    return len(sgs)


def _import_mesh(path, parent, name):
    before = set(cmds.ls(assemblies=True, long=True))
    cmds.file(path, i=True, type="SwgMsh")
    new = [n for n in cmds.ls(assemblies=True, long=True) if n not in before]
    # the .msh importer mirrors X without reversing the triangles: every imported shape comes in inside out, and
    # polyNormal on the transform would reverse only its first shape (one shape per shader)
    shapes = cmds.listRelatives(new, allDescendents=True, type="mesh", fullPath=True) or []
    for shape in shapes:
        cmds.polyNormal(shape, normalMode=0, userNormalMode=0, constructionHistory=False)
    mark_uv_direct(shapes)
    grp = cmds.group(new, name=name)
    return cmds.parent(grp, parent)[0] if parent else cmds.ls(grp, long=True)[0]


def _tris_world(nodes):
    out = []
    for node in nodes:
        for s in cmds.listRelatives(node, allDescendents=True, type="mesh", fullPath=True) or []:
            sel = om.MSelectionList()
            sel.add(s)
            fn = om.MFnMesh(sel.getDagPath(0))
            pts = fn.getPoints(om.MSpace.kWorld)
            _, idx = fn.getTriangles()
            P = [(p.x, p.y, p.z) for p in pts]
            out += [(P[idx[t]], P[idx[t + 1]], P[idx[t + 2]]) for t in range(0, len(idx), 3)]
    return out


def delete_faces_inside(meshes, lo, hi, all_corners=True):
    """Delete faces with all (or any) corners inside the box lo..hi (world space). Returns the count."""
    dead_total = 0
    for m in meshes:
        for shape in cmds.listRelatives(m, allDescendents=True, type="mesh", fullPath=True) or []:
            if not cmds.objExists(shape) or cmds.getAttr(shape + ".intermediateObject"):
                continue
            sel = om.MSelectionList()
            sel.add(shape)
            fn = om.MFnMesh(sel.getDagPath(0))
            pts = fn.getPoints(om.MSpace.kWorld)
            inside = [lo[0] <= p.x <= hi[0] and lo[1] <= p.y <= hi[1] and lo[2] <= p.z <= hi[2] for p in pts]
            dead = []
            for f in range(fn.numPolygons):
                vids = fn.getPolygonVertices(f)
                ok = all(inside[v] for v in vids) if all_corners else any(inside[v] for v in vids)
                if ok:
                    dead.append(f)
            if dead and len(dead) < fn.numPolygons:
                cmds.delete([f"{shape}.f[{f}]" for f in dead])
                dead_total += len(dead)
            elif dead:
                cmds.delete(shape)          # Maya keeps a mesh's last face: drop the shape (not its transform,
                dead_total += len(dead)     # which holds the other shaders' shapes of an imported stock mesh)
    return dead_total


def cut_region(meshes, planes, bounds):
    """Cut the convex region {p: k.p < val for every (k, val)} (world space, k = (kx, ky, kz)) out of meshes:
    faces crossing it are split in place along its planes (pob_builder._shell_cut), the faces inside deleted."""
    lo, hi = bounds
    # _shell_cut works on the shapes directly under each transform: hand it the transforms that hold them
    holders = []
    for m in meshes:
        for shape in cmds.listRelatives(m, allDescendents=True, type="mesh", fullPath=True) or []:
            xf = cmds.listRelatives(shape, parent=True, fullPath=True)[0]
            if xf not in holders:
                holders.append(xf)
    meshes = holders
    # _shell_cut's local frame with o=(0,0), t=(1,0), n=(0,1) is (u, v, y) = (x, z, y)
    sc_planes = [((k[0], k[2], k[1]), val, 1) for k, val in planes]
    return pb._shell_cut(meshes, (0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (lo[0], hi[0]), (lo[2], hi[2]), (lo[1], hi[1]),
                         planes=sc_planes)


def box_planes(lo, hi):
    return [((-1, 0, 0), -lo[0]), ((1, 0, 0), hi[0]), ((0, -1, 0), -lo[1]), ((0, 1, 0), hi[1]),
            ((0, 0, -1), -lo[2]), ((0, 0, 1), hi[2])]


# ============================================================================
# matrices: Maya world (landed) -> hull frame, Maya -> engine
# ============================================================================

def _m4(flat):
    return om.MMatrix(flat)


def to_frame(nodes, frame_inv):
    """Move nodes (meshes, lights, portals: anything whose geometry is in Maya world space with an identity parent)
    into the hull frame: apply frame_inv to each transform and freeze meshes."""
    for n in nodes:
        m = om.MMatrix(cmds.xform(n, q=True, ws=True, matrix=True)) * frame_inv
        cmds.xform(n, ws=True, matrix=list(m))


def engine_matrix_rows(m):
    """Maya 4x4 (row-vector convention, translation in row 3) -> engine 3x4 rows with X mirrored."""
    R = [[m.getElement(c, r) for c in range(3)] for r in range(3)]       # column-vector rotation rows
    t = [m.getElement(3, i) for i in range(3)]
    S = (-1.0, 1.0, 1.0)
    rows = []
    for r in range(3):
        rows.append([S[r] * R[r][c] * S[c] for c in range(3)] + [S[r] * t[r]])
    return rows


# ============================================================================
# transport shuttle
# ============================================================================

def _transport_joints():
    """Stock transport skeleton in its bind (landed) pose: world matrices of the hull and the part joints, the door
    at its closed angle and the legs stowed. Returns {name: MMatrix} and deletes the skeleton."""
    cmds.file(os.path.join(DATA, "appearance/skeleton/transport.skt"), i=True, type="SwgSkt")
    out = {}
    cmds.setAttr("hold_transport_door.rotateZ", 0.0)                 # closed: flush with the hull
    out["hull"] = om.MMatrix(cmds.xform("hold_transport", q=True, ws=True, matrix=True))
    out["door"] = om.MMatrix(cmds.xform("hold_transport_door", q=True, ws=True, matrix=True))
    out["strut_a"] = om.MMatrix(cmds.xform("hold_transport_strut_a", q=True, ws=True, matrix=True))   # bind = stowed
    cmds.setAttr("hold_transport_strut_b.translateY", 0.0)            # bind = deployed; 0 = stowed
    cmds.setAttr("hold_transport_strut_c.translateY", 0.0)
    out["strut_b"] = om.MMatrix(cmds.xform("hold_transport_strut_b", q=True, ws=True, matrix=True))
    out["strut_c"] = om.MMatrix(cmds.xform("hold_transport_strut_c", q=True, ws=True, matrix=True))
    for top in cmds.ls("|master", long=True):
        cmds.delete(top)
    return out


# Measured on the stock rig (transport_landing / transport_takeoff): the ramp turns -39 deg about its hinge (local Z)
# in 2.3 s, strut a drops 1.0 m and b / c 1.249 m along their local -Y in 2.8 s.
TRANSPORT_PARTS = [
    {"slot": "ramp", "hp": "ramp", "path": "appearance/transport_door.apt", "mode": "rot", "axis": (0.0, 0.0, 1.0),
     "amount": -39.0, "seconds": 2.3},
    {"slot": "strut_a", "hp": "strut_a", "path": "appearance/transport_strut_a.apt", "mode": "move",
     "axis": (0.0, -1.0, 0.0), "amount": 1.0, "seconds": 2.8},
    {"slot": "strut_b", "hp": "strut_b", "path": "appearance/transport_strut_b.apt", "mode": "move",
     "axis": (0.0, -1.0, 0.0), "amount": 1.249, "seconds": 2.8},
    {"slot": "strut_c", "hp": "strut_c", "path": "appearance/transport_strut_c.apt", "mode": "move",
     "axis": (0.0, -1.0, 0.0), "amount": 1.249, "seconds": 2.8},
]

T_FLOOR = 1.5            # cabin / vestibule / ramp-hinge floor height above the ground
T_CEIL = 4.45
T_Z0, T_Z1 = -8.3, 5.6   # cabin rear / front wall (strut wells aft, nose leg bay forward)
# cabin cross-section (half, x >= 0) inside the lens-shaped hull: floor, lower slope, side band, upper slope, ceiling
T_PROFILE = [(0.0, T_FLOOR), (4.0, T_FLOOR), (6.9, 2.55), (6.9, 3.9), (4.5, T_CEIL), (0.0, T_CEIL)]
T_SIDE_X, T_HULL_X = 6.9, 7.5                # cabin side wall, hull side band
T_WIN_Y = (2.97, 3.57)                       # side window band (inside the hull's recessed side strip)
T_WIN_Z = [-7.0, -5.4, -3.8, -2.2, -0.6, 1.0, 2.6, 4.2]
T_WIN_HALF = 0.5
T_LOW_Z = [-6.6, -3.3, 0.0, 3.3]             # floor-level windows in the lower slope, looking down
T_LOW_HALF = 0.6
T_LOW_T = (0.42, 0.86)                       # along the lower cabin wall (0 = floor edge, 1 = side band)
T_HULL_LOW = ((4.72, 1.67), (7.5, 2.5))      # the hull's lower slope (same section all along the cabin)
# vestibule (the stock boarding alcove) and the ramp
T_VEST = (1.5, 3.75, 5.6, 8.05, 3.85)        # x0, x1, z0, z1, ceiling
T_DOOR_Z = (5.96, 8.02)                      # ramp width
T_RAMP_FOOT_X = 7.3
T_OVERHANG = ((3.75, 3.82), (7.3, 1.97))     # just under the hull underside over the ramp


def _to_hull(p, n_out, side):
    """Distance from cabin-wall point p (x, y) along n_out to the hull's lower slope (mirrored for side < 0)."""
    (ax, ay), (bx, by) = T_HULL_LOW
    ax, bx = side * ax, side * bx
    dx, dy = bx - ax, by - ay
    det = n_out[0] * (-dy) - n_out[1] * (-dx)
    if abs(det) < 1e-9:
        return 0.2
    rx, ry = ax - p[0], ay - p[1]
    return (rx * (-dy) - ry * (-dx)) / det


def _cabin_geometry(F):
    """Passenger cabin + vestibule surfaces (Maya world, landed)."""
    z0, z1 = T_Z0, T_Z1
    vx0, vx1, vz0, vz1, vy = T_VEST
    prof = T_PROFILE

    def inward(side):
        def f(p, q):
            # normal of the profile edge p->q pointing toward the cabin axis / middle
            dx, dy = q[0] - p[0], q[1] - p[1]
            n = (-dy, dx) if side > 0 else (dy, -dx)
            cx, cy = (p[0] + q[0]) / 2, (p[1] + q[1]) / 2
            if n[0] * (0.0 - cx) + n[1] * (3.0 - cy) < 0:
                n = (-n[0], -n[1])
            return (n[0], n[1], 0.0)
        return f

    for side in (1, -1):
        P = [(side * x, y) for x, y in prof]
        # lower slope (with floor-level window holes), side band (with the window strip), upper slope
        lower = (P[1], P[2])
        band = (P[2], P[3])
        upper = (P[3], P[4])
        F.quad_strip("upper", [upper[0], upper[1]], z0, z1, inward(side))
        # side band: solid below and above the window strip, panes between mullions
        (bx, by0), (_, by1) = band
        wy0, wy1 = T_WIN_Y
        n_in = (-side, 0.0, 0.0)
        F.add("wall", [(bx, by0, z0), (bx, wy0, z0), (bx, wy0, z1), (bx, by0, z1)], n_in)
        F.add("wall", [(bx, wy1, z0), (bx, by1, z0), (bx, by1, z1), (bx, wy1, z1)], n_in)
        edges = [z0] + [v for c in T_WIN_Z for v in (c - T_WIN_HALF, c + T_WIN_HALF)] + [z1]
        hull_x = side * (T_HULL_X - 0.04)
        for k in range(0, len(edges), 2):
            a, b = edges[k], edges[k + 1]
            F.add("wall", [(bx, wy0, a), (bx, wy1, a), (bx, wy1, b), (bx, wy0, b)], n_in)
        for c in T_WIN_Z:
            a, b = c - T_WIN_HALF, c + T_WIN_HALF
            # reveal: sill, head, jambs from the cabin wall out to the hull, and the pane (seen from inside)
            F.add("frame", [(bx, wy0, a), (hull_x, wy0, a), (hull_x, wy0, b), (bx, wy0, b)], (0, 1, 0))
            F.add("frame", [(bx, wy1, a), (hull_x, wy1, a), (hull_x, wy1, b), (bx, wy1, b)], (0, -1, 0))
            F.add("frame", [(bx, wy0, a), (hull_x, wy0, a), (hull_x, wy1, a), (bx, wy1, a)], (0, 0, 1))
            F.add("frame", [(bx, wy0, b), (hull_x, wy0, b), (hull_x, wy1, b), (bx, wy1, b)], (0, 0, -1))
            gx = side * (T_HULL_X - 0.06)
            F.add("glass", [(gx, wy0, a), (gx, wy0, b), (gx, wy1, b), (gx, wy1, a)], n_in)
        # lower slope with downward windows
        (lx0, ly0), (lx1, ly1) = lower
        t0, t1 = T_LOW_T
        pa = (lx0 + (lx1 - lx0) * t0, ly0 + (ly1 - ly0) * t0)
        pb_ = (lx0 + (lx1 - lx0) * t1, ly0 + (ly1 - ly0) * t1)
        n_low = inward(side)((lx0, ly0), (lx1, ly1))
        F.quad_strip("lower", [(lx0, ly0), pa], z0, z1, inward(side))
        F.quad_strip("lower", [pb_, (lx1, ly1)], z0, z1, inward(side))
        ledges = [z0] + [v for c in T_LOW_Z for v in (c - T_LOW_HALF, c + T_LOW_HALF)] + [z1]
        for k in range(0, len(ledges), 2):
            F.quad_strip("lower", [pa, pb_], ledges[k], ledges[k + 1], inward(side))
        out_n = _unit((-n_low[0], -n_low[1], 0.0))         # toward the hull
        da, db = _to_hull(pa, out_n, side) - 0.02, _to_hull(pb_, out_n, side) - 0.02
        qa = (pa[0] + out_n[0] * da, pa[1] + out_n[1] * da)
        qb = (pb_[0] + out_n[0] * db, pb_[1] + out_n[1] * db)
        for c in T_LOW_Z:
            a, b = c - T_LOW_HALF, c + T_LOW_HALF
            F.add("frame", [(pa[0], pa[1], a), (qa[0], qa[1], a), (qa[0], qa[1], b), (pa[0], pa[1], b)],
                  (pb_[0] - pa[0], pb_[1] - pa[1], 0.0))
            F.add("frame", [(pb_[0], pb_[1], a), (qb[0], qb[1], a), (qb[0], qb[1], b), (pb_[0], pb_[1], b)],
                  (pa[0] - pb_[0], pa[1] - pb_[1], 0.0))
            F.add("frame", [(pa[0], pa[1], a), (qa[0], qa[1], a), (qb[0], qb[1], a), (pb_[0], pb_[1], a)], (0, 0, 1))
            F.add("frame", [(pa[0], pa[1], b), (qa[0], qa[1], b), (qb[0], qb[1], b), (pb_[0], pb_[1], b)], (0, 0, -1))
            ga = (pa[0] + out_n[0] * (da - 0.02), pa[1] + out_n[1] * (da - 0.02))
            gb = (pb_[0] + out_n[0] * (db - 0.02), pb_[1] + out_n[1] * (db - 0.02))
            F.add("glass", [(ga[0], ga[1], a), (gb[0], gb[1], a), (gb[0], gb[1], b), (ga[0], ga[1], b)],
                  (n_low[0], n_low[1], 0.0))

    # floor: main deck with a grated centre aisle, plus the vestibule
    aisle = 0.55
    F.add("floor", [(-4.0, T_FLOOR, z0), (-aisle, T_FLOOR, z0), (-aisle, T_FLOOR, z1), (-4.0, T_FLOOR, z1)], (0, 1, 0))
    F.add("floor", [(aisle, T_FLOOR, z0), (4.0, T_FLOOR, z0), (4.0, T_FLOOR, z1), (aisle, T_FLOOR, z1)], (0, 1, 0))
    F.add("aisle", [(-aisle, T_FLOOR, z0), (aisle, T_FLOOR, z0), (aisle, T_FLOOR, z1), (-aisle, T_FLOOR, z1)], (0, 1, 0))
    F.add("hall", [(vx0, T_FLOOR, vz0), (vx1, T_FLOOR, vz0), (vx1, T_FLOOR, vz1), (vx0, T_FLOOR, vz1)], (0, 1, 0))

    # ceiling with two light strips
    strips = [(-2.2, -1.6), (1.6, 2.2)]
    xs = [-4.5] + [v for s in strips for v in s] + [4.5]
    for k in range(0, len(xs), 2):
        F.add("ceiling", [(xs[k], T_CEIL, z0), (xs[k + 1], T_CEIL, z0), (xs[k + 1], T_CEIL, z1), (xs[k], T_CEIL, z1)],
              (0, -1, 0))
    for a, b in strips:
        F.add("ceiling", [(a, T_CEIL, z0), (b, T_CEIL, z0), (b, T_CEIL, z0 + 0.4), (a, T_CEIL, z0 + 0.4)], (0, -1, 0))
        F.add("ceiling", [(a, T_CEIL, z1 - 0.4), (b, T_CEIL, z1 - 0.4), (b, T_CEIL, z1), (a, T_CEIL, z1)], (0, -1, 0))
        F.add("light", [(a, T_CEIL - 0.02, z0 + 0.4), (b, T_CEIL - 0.02, z0 + 0.4), (b, T_CEIL - 0.02, z1 - 0.4),
                        (a, T_CEIL - 0.02, z1 - 0.4)], (0, -1, 0))

    # rear wall (full lens), front wall (lens minus the vestibule mouth)
    ring = [(-4.0, T_FLOOR), (4.0, T_FLOOR), (6.9, 2.55), (6.9, 3.9), (4.5, T_CEIL), (-4.5, T_CEIL), (-6.9, 3.9),
            (-6.9, 2.55)]
    F.add("wall", [(x, y, z0) for x, y in ring], (0, 0, 1))
    F.add("wall", [(x, y, z1) for x, y in [(-4.0, T_FLOOR), (vx0, T_FLOOR), (vx0, T_CEIL), (-4.5, T_CEIL),
                                           (-6.9, 3.9), (-6.9, 2.55)]], (0, 0, -1))
    F.add("wall", [(vx0, vy, z1), (vx1, vy, z1), (vx1, T_CEIL, z1), (vx0, T_CEIL, z1)], (0, 0, -1))
    F.add("wall", [(x, y, z1) for x, y in [(vx1, T_FLOOR), (4.0, T_FLOOR), (6.9, 2.55), (6.9, 3.9), (4.5, T_CEIL),
                                           (vx1, T_CEIL)]], (0, 0, -1))
    # trims where the walls meet the floor and ceiling
    for side in (1, -1):
        F.add("trim", [(side * 4.0, T_FLOOR, z0), (side * 4.0, T_FLOOR + 0.12, z0), (side * 4.0, T_FLOOR + 0.12, z1),
                       (side * 4.0, T_FLOOR, z1)], (-side, 0, 0))

    # vestibule: inner wall, end wall, ceiling, the stub beside the doorway
    dz0, dz1 = T_DOOR_Z
    F.add("hall", [(vx0, T_FLOOR, z1), (vx0, T_FLOOR, vz1), (vx0, vy, vz1), (vx0, vy, z1)], (1, 0, 0))
    F.add("hall", [(vx0, T_FLOOR, vz1), (vx1, T_FLOOR, vz1), (vx1, vy, vz1), (vx0, vy, vz1)], (0, 0, -1))
    F.add("ceiling", [(vx0, vy, z1), (vx1, vy, z1), (vx1, vy, vz1), (vx0, vy, vz1)], (0, -1, 0))
    F.add("hall", [(vx1, T_FLOOR, z1), (vx1, T_FLOOR, dz0), (vx1, vy, dz0), (vx1, vy, z1)], (-1, 0, 0))
    F.add("hall", [(vx1, T_FLOOR, dz1), (vx1, T_FLOOR, vz1), (vx1, vy, vz1), (vx1, vy, dz1)], (-1, 0, 0))
    # door frame round the mouth (seen from the vestibule)
    fw = 0.08
    F.add("trim", [(vx1 - 0.01, T_FLOOR, dz0), (vx1 - 0.01, vy, dz0), (vx1 - 0.01, vy, dz0 + fw),
                   (vx1 - 0.01, T_FLOOR, dz0 + fw)], (-1, 0, 0))
    F.add("trim", [(vx1 - 0.01, T_FLOOR, dz1 - fw), (vx1 - 0.01, vy, dz1 - fw), (vx1 - 0.01, vy, dz1),
                   (vx1 - 0.01, T_FLOOR, dz1)], (-1, 0, 0))
    F.add("trim", [(vx1 - 0.01, vy - fw, dz0), (vx1 - 0.01, vy, dz0), (vx1 - 0.01, vy, dz1),
                   (vx1 - 0.01, vy - fw, dz1)], (-1, 0, 0))


def _cabin_floor():
    vx0, vx1, vz0, vz1, _ = T_VEST
    dz0, dz1 = T_DOOR_Z
    y = T_FLOOR
    return [
        # main deck, split where the vestibule joins so the seam is welded (shared vertices = crossable)
        [(-4.0, y, T_Z0), (vx0, y, T_Z0), (vx0, y, T_Z1), (-4.0, y, T_Z1)],
        [(vx0, y, T_Z0), (vx1, y, T_Z0), (vx1, y, T_Z1), (vx0, y, T_Z1)],
        [(vx1, y, T_Z0), (4.0, y, T_Z0), (4.0, y, T_Z1), (vx1, y, T_Z1)],
        # vestibule, split at the doorway jambs so the portal edge has its own vertices
        [(vx0, y, vz0), (vx1, y, vz0), (vx1, y, dz0), (vx0, y, dz0)],
        [(vx0, y, dz0), (vx1, y, dz0), (vx1, y, dz1), (vx0, y, dz1)],
        [(vx0, y, dz1), (vx1, y, dz1), (vx1, y, vz1), (vx0, y, vz1)],
    ]


def _cabin_collision():
    """Cell collision (CMSH): the cabin's walls as seen from inside, so the camera stays in the cabin."""
    acc = pb.MeshAccumulator()
    ring = [(-4.0, T_FLOOR), (4.0, T_FLOOR), (6.9, 2.55), (6.9, 3.9), (4.5, T_CEIL), (-4.5, T_CEIL), (-6.9, 3.9),
            (-6.9, 2.55)]
    for (x0, y0), (x1, y1) in zip(ring, ring[1:] + ring[:1]):
        if y0 == y1 == T_FLOOR:
            continue
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        n = (-(y1 - y0), x1 - x0)
        if n[0] * -cx + n[1] * (3.0 - cy) < 0:
            n = (-n[0], -n[1])
        acc.facing([(x0, y0, T_Z0), (x1, y1, T_Z0), (x1, y1, T_Z1), (x0, y0, T_Z1)], (n[0], n[1], 0.0))
    acc.facing([(x, y, T_Z0) for x, y in ring], (0, 0, 1))
    return acc


def build_transport(name="titan_transport_shuttle", export_root="D:/exported", export=True):
    """The starport transport as a boardable POB ship (see module doc)."""
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    J = _transport_joints()
    hull_m = J["hull"]
    mel.eval(f'createPobTemplate -n "{name}" -cells 3 -layoutSpacing 0')
    root = cmds.ls("|" + name, long=True)[0]
    for i, cname in enumerate(("r0", "ramp", "cabin")):
        cell = f"{root}|r{i}"
        if not cmds.attributeQuery("pobCellName", node=cell, exists=True):
            cmds.addAttr(cell, longName="pobCellName", dataType="string")
        cmds.setAttr(cell + ".pobCellName", cname, type="string")
        if not cmds.objExists(cell + "|mesh"):
            cmds.createNode("transform", name="mesh", parent=cell)

    sgs = _materials(f"swg_{name}", TRANSPORT_MATERIALS)

    # --- r0: the stock hull at its landed pose, doorway and windows cut in -------------------------------------
    hull = _import_mesh(os.path.join(DATA, "appearance/mesh/transport_l0.msh"), f"{root}|r0|mesh", "hull")
    cmds.xform(hull, ws=True, matrix=list(hull_m))
    cmds.makeIdentity(hull, apply=True, translate=True, rotate=True, scale=True)
    vx0, vx1, vz0, vz1, vy = T_VEST
    # the stock boarding alcove and the passage behind it become the vestibule (cell geometry)
    removed = delete_faces_inside([hull], (vx0 - 0.08, 1.3, 1.9), (vx1 + 0.05, 4.0, vz1 + 0.06))
    hull_glass = Faces(TRANSPORT_MATERIALS)
    for side in (1, -1):
        hx = side * T_HULL_X
        for c in T_WIN_Z:
            lo = (min(hx - 0.25 * side, hx + 0.25 * side), T_WIN_Y[0], c - T_WIN_HALF)
            hi = (max(hx - 0.25 * side, hx + 0.25 * side), T_WIN_Y[1], c + T_WIN_HALF)
            cut_region([hull], box_planes(lo, hi), (lo, hi))
            gx = side * (T_HULL_X - 0.02)
            hull_glass.add("glass", [(gx, T_WIN_Y[0], lo[2]), (gx, T_WIN_Y[0], hi[2]), (gx, T_WIN_Y[1], hi[2]),
                                     (gx, T_WIN_Y[1], lo[2])], (side, 0, 0))
        # lower-slope windows: the cut follows the cabin's window reveal out through the hull
        (lx0, ly0), (lx1, ly1) = (T_PROFILE[1], T_PROFILE[2])
        t0, t1 = T_LOW_T
        pa = (side * (lx0 + (lx1 - lx0) * t0), ly0 + (ly1 - ly0) * t0)
        pb_ = (side * (lx0 + (lx1 - lx0) * t1), ly0 + (ly1 - ly0) * t1)
        d = _unit((pb_[0] - pa[0], pb_[1] - pa[1], 0.0))
        n_out = _unit((side * abs(d[1]), -abs(d[0]), 0.0))           # out of the cabin, down through the hull
        for c in T_LOW_Z:
            planes = [((0, 0, -1), -(c - T_LOW_HALF)), ((0, 0, 1), c + T_LOW_HALF)]
            # along-slope bounds through pa / pb (perpendicular to the slope), depth from the cabin wall outward
            along = (d[0], d[1], 0.0)
            planes.append(((-along[0], -along[1], 0), -(along[0] * pa[0] + along[1] * pa[1])))
            planes.append(((along[0], along[1], 0), along[0] * pb_[0] + along[1] * pb_[1]))
            planes.append(((-n_out[0], -n_out[1], 0), -(n_out[0] * pa[0] + n_out[1] * pa[1])))
            planes.append(((n_out[0], n_out[1], 0), n_out[0] * pa[0] + n_out[1] * pa[1] + 0.6))
            xs = [pa[0], pb_[0], pa[0] + n_out[0] * 0.6, pb_[0] + n_out[0] * 0.6]
            ys = [pa[1], pb_[1], pa[1] + n_out[1] * 0.6, pb_[1] + n_out[1] * 0.6]
            lo, hi = (min(xs), min(ys), c - T_LOW_HALF), (max(xs), max(ys), c + T_LOW_HALF)
            cut_region([hull], planes, (lo, hi))
            # exterior pane where the reveal meets the hull
            da, db = _to_hull(pa, n_out, side), _to_hull(pb_, n_out, side)
            ga = (pa[0] + n_out[0] * da, pa[1] + n_out[1] * da)
            gb = (pb_[0] + n_out[0] * db, pb_[1] + n_out[1] * db)
            hull_glass.add("glass", [(ga[0], ga[1], c - T_LOW_HALF), (gb[0], gb[1], c - T_LOW_HALF),
                                     (gb[0], gb[1], c + T_LOW_HALF), (ga[0], ga[1], c + T_LOW_HALF)], n_out)
    # a plate under the vestibule (the alcove floor was the hull bottom there)
    hull_glass.add("hall", [(vx0, T_FLOOR - 0.02, vz0), (vx1, T_FLOOR - 0.02, vz0), (vx1, T_FLOOR - 0.02, vz1),
                            (vx0, T_FLOOR - 0.02, vz1)], (0, -1, 0))
    hull_glass.build(f"{root}|r0|mesh", "hull", sgs)

    # --- r1: the ramp (open air; floor = the lowered ramp surface, foot on the ground) ------------------------
    ramp = f"{root}|r1"
    dz0, dz1 = T_DOOR_Z
    foot, hinge = T_RAMP_FOOT_X, vx1
    _floor(ramp, [(hinge, T_FLOOR, dz0), (foot, 0.0, dz0), (foot, 0.0, dz1), (hinge, T_FLOOR, dz1)])
    rf = Faces(TRANSPORT_MATERIALS)
    # hinge sill strip (the cell's only visible geometry: the ramp itself is the animated part)
    rf.add("trim", [(hinge, T_FLOOR + 0.005, dz0), (hinge + 0.12, T_FLOOR - 0.045, dz0),
                    (hinge + 0.12, T_FLOOR - 0.045, dz1), (hinge, T_FLOOR + 0.005, dz1)], (0.4, 1, 0))
    rf.build(ramp + "|mesh", "ramp", sgs)
    (ox0, oy0), (ox1, oy1) = T_OVERHANG
    portals = []
    # foot (walk on / off), seen from inside the ramp: x = foot plane, facing -x
    ramp_in = ((hinge + foot) / 2, 1.0, (dz0 + dz1) / 2)
    cabin_in = (0.0, 3.0, -1.0)
    portals.append(portal(root, 0, 1, [(foot, -0.3, dz1), (foot, -0.3, dz0), (foot, oy1, dz0), (foot, oy1, dz1)],
                          ramp_in))
    # sides, top (under the hull) and bottom (under the ramp: the ramp part and the ground show through)
    portals.append(portal(root, 0, 1, [(hinge, -0.3, dz0), (foot, -0.3, dz0), (foot, oy1, dz0), (hinge, oy0, dz0)],
                          ramp_in, passable=False))
    portals.append(portal(root, 0, 1, [(foot, -0.3, dz1), (hinge, -0.3, dz1), (hinge, oy0, dz1), (foot, oy1, dz1)],
                          ramp_in, passable=False))
    portals.append(portal(root, 0, 1, [(hinge, oy0, dz0), (foot, oy1, dz0), (foot, oy1, dz1), (hinge, oy0, dz1)],
                          ramp_in, passable=False))
    portals.append(portal(root, 0, 1, [(hinge, -0.3, dz1), (foot, -0.3, dz1), (foot, -0.3, dz0), (hinge, -0.3, dz0)],
                          ramp_in, passable=False))
    # ramp <-> vestibule doorway, facing into the cabin (-x)
    portals.append(portal(root, 1, 2, [(hinge, T_FLOOR - 0.05, dz1), (hinge, T_FLOOR - 0.05, dz0), (hinge, vy, dz0),
                                       (hinge, vy, dz1)], (2.6, 2.5, (dz0 + dz1) / 2)))
    _lights(ramp, ((0.75, 0.72, 0.68), 0.55), [], [((0.3, -1.0, 0.2), (0.8, 0.75, 0.66), 1.0),
                                                    ((-0.2, 1.0, -0.1), (0.25, 0.25, 0.28), 1.0)])

    # --- r2: the cabin ------------------------------------------------------------------------------------------
    cabin = f"{root}|r2"
    F = Faces(TRANSPORT_MATERIALS)
    _cabin_geometry(F)
    F.build(cabin + "|mesh", "cabin", sgs)
    _floor(cabin, _cabin_floor())
    col = _cabin_collision()
    pb._collision_mesh(col, "cabin_collision", cabin + "|collision")
    # window strips: one portal per side per row, facing into the cabin
    for side in (1, -1):
        hx = side * (T_HULL_X - 0.01)
        a, b = T_WIN_Z[0] - T_WIN_HALF, T_WIN_Z[-1] + T_WIN_HALF
        y0, y1 = T_WIN_Y
        portals.append(portal(root, 0, 2, [(hx, y0, a), (hx, y0, b), (hx, y1, b), (hx, y1, a)], cabin_in,
                              passable=False))
        (lx0, ly0), (lx1, ly1) = (T_PROFILE[1], T_PROFILE[2])
        t0, t1 = T_LOW_T
        pa = (side * (lx0 + (lx1 - lx0) * t0), ly0 + (ly1 - ly0) * t0)
        pb_ = (side * (lx0 + (lx1 - lx0) * t1), ly0 + (ly1 - ly0) * t1)
        d = _unit((pb_[0] - pa[0], pb_[1] - pa[1], 0.0))
        n_out = _unit((side * abs(d[1]), -abs(d[0]), 0.0))
        da, db = _to_hull(pa, n_out, side) - 0.01, _to_hull(pb_, n_out, side) - 0.01
        ga = (pa[0] + n_out[0] * da, pa[1] + n_out[1] * da)
        gb = (pb_[0] + n_out[0] * db, pb_[1] + n_out[1] * db)
        za, zb = T_LOW_Z[0] - T_LOW_HALF, T_LOW_Z[-1] + T_LOW_HALF
        portals.append(portal(root, 0, 2, [(ga[0], ga[1], za), (gb[0], gb[1], za), (gb[0], gb[1], zb),
                                           (ga[0], ga[1], zb)], cabin_in, passable=False))
    _lights(cabin, ((0.62, 0.62, 0.68), 0.45),
            [((0.0, T_CEIL - 0.5, 3.0), (1.0, 0.96, 0.88), 0.9), ((0.0, T_CEIL - 0.5, -2.0), (1.0, 0.96, 0.88), 0.9),
             ((0.0, T_CEIL - 0.5, -6.5), (1.0, 0.96, 0.88), 0.7)],
            [((0.4, -1.0, 0.2), (0.55, 0.52, 0.48), 1.0), ((-0.3, 1.0, -0.1), (0.22, 0.22, 0.26), 1.0)])
    for cell in (f"{root}|r1", f"{root}|r2"):
        if not cmds.attributeQuery("canSeeWorld", node=cell, exists=True):
            cmds.addAttr(cell, longName="canSeeWorld", attributeType="bool")
        cmds.setAttr(cell + ".canSeeWorld", True)

    # --- into the hull frame ----------------------------------------------------------------------------------
    inv = hull_m.inverse()
    groups = [g for cell in cmds.listRelatives(root, children=True, fullPath=True) or []
              for g in cmds.listRelatives(cell, children=True, fullPath=True) or []]
    for grp in groups:
        short = grp.split("|")[-1]
        kids = cmds.listRelatives(grp, children=True, fullPath=True, type="transform") or []
        if short == "portals":
            for xf in kids:
                for shape in cmds.listRelatives(xf, shapes=True, fullPath=True, noIntermediate=True) or []:
                    _apply_points(shape, inv)
        elif short == "lights":
            for xf in kids:
                m = om.MMatrix(cmds.xform(xf, q=True, ws=True, matrix=True)) * inv
                cmds.xform(xf, ws=True, matrix=list(m))
        else:
            for shape in cmds.listRelatives(grp, allDescendents=True, type="mesh", fullPath=True) or []:
                if not cmds.getAttr(shape + ".intermediateObject"):
                    _apply_points(shape, inv)

    hardpoints = {}
    for part in TRANSPORT_PARTS:
        key = part["hp"] if part["hp"] != "ramp" else "door"
        hardpoints[part["hp"]] = J[key] * inv
    info = {
        "root": root, "removed_alcove_faces": removed, "portals": portals,
        "landed": [list(row) for row in engine_matrix_rows(hull_m)],
        "hardpoints": {k: engine_matrix_rows(m) for k, m in hardpoints.items()},
        "parts": TRANSPORT_PARTS,
    }
    if export:
        info["export"] = pb.export(root, export_root, name)
    return info


def _apply_points(shape, matrix):
    """Move a mesh shape's points by `matrix` in world space (transforms untouched; one transform may hold
    several shapes, as imported stock meshes do: one per shader)."""
    sel = om.MSelectionList()
    sel.add(shape)
    dag = sel.getDagPath(0)
    fn = om.MFnMesh(dag)
    pts = fn.getPoints(om.MSpace.kWorld)
    to_local = dag.inclusiveMatrix().inverse()
    fn.setPoints(om.MPointArray([p * matrix * to_local for p in pts]), om.MSpace.kObject)


# ----------------------------------------------------------------------------
# hyperspace tunnel (hp_dyn app round a vessel in transit; script.library.vessel.setHyperspaceVisual)
# ----------------------------------------------------------------------------

HYPERSPACE_SHADER = "shader/titan_hyperspace_tunnel.sht"


def build_hyperspace_tunnel(name="titan_hyperspace_tunnel", export_root="D:/exported", radius=30.0, length=600.0,
                            sides=32, rings=12, u_repeat=4.0, v_repeat=6.0):
    """An open cylinder along +z round the vessel origin, faces inward, so the windows look out on the tunnel and
    the vessel shows plainly from outside (back faces). UVs: u round, v growing toward +z in Maya (the exporter writes
    1 - v; the shader's scroll sign accounts for it). Every normal points up: the vertex lighting is the same all round."""
    for old in cmds.ls(name, long=True) or []:
        cmds.delete(old)
    root = cmds.createNode("transform", name=name)
    xf = cmds.createNode("transform", name=name + "_mesh", parent=root)
    pts, us, vs = om.MPointArray(), om.MFloatArray(), om.MFloatArray()
    for j in range(rings + 1):
        z = -length / 2 + length * j / rings
        for i in range(sides + 1):                       # the seam column twice, for its own u
            a = 2 * math.pi * i / sides
            pts.append(om.MPoint(radius * math.cos(a), radius * math.sin(a), z))
            us.append(u_repeat * i / sides)
            vs.append(v_repeat * j / rings)
    counts, connects = om.MIntArray(), om.MIntArray()
    for j in range(rings):
        for i in range(sides):
            a, b = j * (sides + 1) + i, j * (sides + 1) + i + 1
            # (i, j) (i, j+1) (i+1, j+1) (i+1, j): the right-hand normal points at the axis
            for k in (a, a + sides + 1, b + sides + 1, b):
                connects.append(k)
            counts.append(4)
    fn = om.MFnMesh()
    sel = om.MSelectionList()
    sel.add(xf)
    fn.create(pts, counts, connects, us, vs, parent=sel.getDependNode(0))
    fn.assignUVs(counts, connects)
    shape = cmds.listRelatives(xf, shapes=True, fullPath=True)[0]
    cmds.polyNormalPerVertex(shape + ".vtx[*]", xyz=(0.0, 1.0, 0.0))
    sgs = _materials(name, {"tunnel": (HYPERSPACE_SHADER, (0.25, 0.35, 0.9), 1.0)})
    cmds.sets(shape, edit=True, forceElement=sgs["tunnel"])
    apt = f"{export_root}/appearance/{name}.apt".replace("\\", "/")
    os.makedirs(os.path.dirname(apt), exist_ok=True)
    cmds.select(root, replace=True)
    mel.eval(f'exportStaticMesh -path "{apt}" -collision none')
    return {"root": root, "apt": f"appearance/{name}.apt", "faces": len(counts), "shader": HYPERSPACE_SHADER}


# ============================================================================
# Sorosuub yacht variant: the stock yacht POB with see-in windows, stateroom portholes, a boarding door in the
# lobby's port side with a slide-out ramp, and three landing legs. Maya space of the imported POB (X mirrored).
# ============================================================================

YACHT_POB = "appearance/sorosuub_space_yacht.pob"
Y_GROUND = -8.85                     # ground under the landed yacht (1.4 m under the lowest belly point)
Y_FLOOR = -5.67                      # lobby / stateroom deck
Y_DOOR_Z = (21.35, 22.85)            # boarding door in the lobby's outboard wall (1.5 m)
Y_DOOR_TOP = -3.15                   # clears the saucer rim lip
Y_HINGE_X = -7.55                    # ramp hinge: the sill's outer edge, where the deck leaves the belly
Y_HINGE_Y = -5.70                    # plank top at the hinge (3 cm under the deck: no z-fight when stowed)
Y_RAMP_DEG = 30.0
Y_RAMP_LEN = (Y_HINGE_Y - Y_GROUND) / math.sin(math.radians(Y_RAMP_DEG))
Y_FOOT_X = Y_HINGE_X - Y_RAMP_LEN * math.cos(math.radians(Y_RAMP_DEG))
Y_CELL_BOTTOM = Y_GROUND - 1.2           # deep enough that uneven ground under the foot still meets the portal
# lobby floor edge under the door: (-6.6, z 20.2) to (-6.4, z 23.9)
Y_LOBBY_EDGE = ((-6.6, 20.2), (-6.4, 23.9))
Y_PORTHOLES = (27.0, 30.5, 34.0)     # stateroom portholes each side: centre z, at eye height
Y_PORT_Y, Y_PORT_HW, Y_PORT_HH = -4.1, 0.45, 0.3
Y_GEAR = {"gear_nose": (0.0, 34.0, 0.45), "gear_left": (-4.5, -8.0, 0.55), "gear_right": (4.5, -8.0, 0.55)}

YACHT_MATERIALS = {
    "wall": ("shader/ss3000_smwall_cs8.sht", (0.62, 0.62, 0.64), 1.0),
    "floor": ("shader/yt1300_hallfloor_ce9.sht", (0.5, 0.5, 0.52), 1.0),
    "ceiling": ("shader/ss3000_hallceiling_ceb15.sht", (0.7, 0.7, 0.72), 1.0),
    "glass": (GLASS, (0.55, 0.68, 0.78), 1.0),     # clear: the stock canopy glass is a dark tint you cannot see in through
    "metal": ("shader/all_metal_streaked_ads16.sht", (0.6, 0.6, 0.6), 1.0),
    "grate": ("shader/asteroid_grate01_as8.sht", (0.45, 0.45, 0.45), 1.0),
}


def _lobby_edge_x(z):
    (x0, z0), (x1, z1) = Y_LOBBY_EDGE
    return x0 + (x1 - x0) * (z - z0) / (z1 - z0)


def tri_list(nodes):
    """World-space triangles of every mesh under nodes, as plain tuples (MPoint references go stale)."""
    out = []
    for node in nodes:
        for s in cmds.listRelatives(node, allDescendents=True, type="mesh", fullPath=True) or []:
            if cmds.getAttr(s + ".intermediateObject"):
                continue
            sel = om.MSelectionList()
            sel.add(s)
            fn = om.MFnMesh(sel.getDagPath(0))
            P = [(p.x, p.y, p.z) for p in fn.getPoints(om.MSpace.kWorld)]
            _, idx = fn.getTriangles()
            out += [(P[idx[t]], P[idx[t + 1]], P[idx[t + 2]]) for t in range(0, len(idx), 3)]
    return out


def ray_hits(tris, origin, direction):
    """Distances along a ray (Moller-Trumbore) to every triangle it crosses, sorted."""
    hits = []
    for a, b, c in tris:
        e1, e2 = _sub(b, a), _sub(c, a)
        p = _cross(direction, e2)
        det = _dot(e1, p)
        if abs(det) < 1e-12:
            continue
        inv = 1.0 / det
        s = _sub(origin, a)
        u = _dot(s, p) * inv
        if u < -1e-6 or u > 1 + 1e-6:
            continue
        q = _cross(s, e1)
        v = _dot(direction, q) * inv
        if v < -1e-6 or u + v > 1 + 1e-6:
            continue
        t = _dot(e2, q) * inv
        if t > 1e-6:
            hits.append(t)
    return sorted(hits)


def _hull_x_at(hull_tris, y, z, side):
    """Outermost hull surface along x on `side` (-1 port / +1 starboard in Maya) at height y, station z."""
    h = ray_hits(hull_tris, (0.0, y, z), (float(side), 0.0, 0.0))
    return side * h[-1] if h else None


def yacht_import(name="titan_sorosuub_yacht"):
    """Stage 1: the stock yacht POB, renamed; every cell mesh turned right side out; cells this variant leaves alone
    keep their stock appearance and floor files (excluded from export, floor shapes dropped)."""
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    before = set(cmds.ls(assemblies=True, long=True))
    cmds.file(os.path.join(DATA, YACHT_POB), i=True, type="SwgPob", ignoreVersion=True)
    new = [n for n in cmds.ls(assemblies=True, long=True) if n not in before and cmds.objExists(n + "|r0")]
    root = cmds.ls(cmds.rename(new[0], name), long=True)[0]
    kept = []
    for cell in cmds.listRelatives(root, children=True, fullPath=True) or []:
        short = cell.split("|")[-1]
        shapes = cmds.listRelatives(cell + "|mesh", allDescendents=True, type="mesh", fullPath=True) or []
        for shape in shapes:
            cmds.polyNormal(shape, normalMode=0, userNormalMode=0, constructionHistory=False)
        mark_uv_direct(shapes)
        if short in ("r0", "r2", "r4"):
            continue
        # unchanged cell: the .pob references the stock mesh and floor
        for shape in cmds.listRelatives(cell + "|mesh", allDescendents=True, type="mesh", fullPath=True) or []:
            if not cmds.attributeQuery("swgExcludeFromStaticMeshExport", node=shape, exists=True):
                cmds.addAttr(shape, longName="swgExcludeFromStaticMeshExport", attributeType="bool")
            cmds.setAttr(shape + ".swgExcludeFromStaticMeshExport", True)
        kept.append(short)
    for short in kept + ["r4"]:
        floor = f"{root}|{short}|collision|floor0"
        for shape in cmds.listRelatives(floor, allDescendents=True, type="mesh", fullPath=True) or []:
            xf = cmds.listRelatives(shape, parent=True, fullPath=True)[0]
            cmds.delete(xf if xf != floor else shape)
    # windows: the stock r0 side of the canopy portals is disabled (no seeing in); enable it
    for p in cmds.listRelatives(root + "|r0|portals", children=True, fullPath=True) or []:
        if cmds.attributeQuery("portalDisabled", node=p, exists=True):
            cmds.setAttr(p + ".portalDisabled", False)
    for short in ("r2", "r4"):
        cell = f"{root}|{short}"
        if not cmds.attributeQuery("pobCellCanSeeWorld", node=cell, exists=True):
            cmds.addAttr(cell, longName="pobCellCanSeeWorld", attributeType="bool")
        cmds.setAttr(cell + ".pobCellCanSeeWorld", True)
    return {"root": root, "kept_stock": kept}


def _prism_planes(origin, u, v, n, hu, hv, n0, n1):
    """Convex prism around a window axis: |u.(p-o)| < hu, |v.(p-o)| < hv, n0 < n.(p-o) < n1 (cut_region planes)."""
    planes = []
    for axis, lo, hi in ((u, -hu, hu), (v, -hv, hv), (n, n0, n1)):
        d = _dot(axis, origin)
        planes.append((tuple(axis), d + hi))
        planes.append((tuple(-a for a in axis), -(d + lo)))
    return planes


def _bounds_of(points, pad=0.05):
    lo = tuple(min(p[i] for p in points) - pad for i in range(3))
    hi = tuple(max(p[i] for p in points) + pad for i in range(3))
    return lo, hi


def yacht_openings(root):
    """Stage 2: the boarding door notch (lobby wall + saucer rim) and the stateroom portholes (wall + hull, lined,
    glazed both sides, portalled to r0). Returns the door / porthole data the ramp stage and the report use."""
    sgs = _materials("swg_titan_yacht", YACHT_MATERIALS)
    # the canopy windows (bridge, observation deck, private room) take the clear glass too: see in as well as out
    for shape in cmds.listRelatives(root + "|r0|mesh", allDescendents=True, type="mesh", fullPath=True) or []:
        if shape.split("|")[-1].startswith("sorosub3000_window"):
            cmds.sets(shape, edit=True, forceElement=sgs["glass"])
    hull_xf = [x for x in cmds.listRelatives(root + "|r0|mesh", children=True, fullPath=True) or []]
    hull_tris = tri_list([root + "|r0|mesh"])
    state_tris = tri_list([root + "|r4|mesh"])
    z0, z1 = Y_DOOR_Z
    # --- door notch: through the lobby's outboard wall (beyond the floor edge line) and the rim ------------------
    xa, xb = _lobby_edge_x(z0), _lobby_edge_x(z1)
    d = _unit((xb - xa, 0.0, z1 - z0))
    k_out = (-d[2], 0.0, d[0])                           # horizontal, pointing outboard (-x)
    if k_out[0] > 0:
        k_out = tuple(-c for c in k_out)
    line_val = _dot(k_out, (xa, 0.0, z0))
    door_planes = [(tuple(-c for c in k_out), -line_val), ((0, -1, 0), -(Y_FLOOR - 0.06)), ((0, 1, 0), Y_DOOR_TOP),
                   ((0, 0, -1), -z0), ((0, 0, 1), z1), ((-1, 0, 0), 7.9)]
    lobby_cut = cut_region([root + "|r2|mesh"], door_planes, ((-7.9, Y_FLOOR - 0.06, z0), (-6.3, Y_DOOR_TOP, z1)))
    hull_planes = box_planes((-10.2, -5.88, z0), (-6.9, Y_DOOR_TOP, z1))
    hull_cut = cut_region(hull_xf, hull_planes, ((-10.2, -5.88, z0), (-6.9, Y_DOOR_TOP, z1)))
    # the hull's section at each jamb, floor to lintel
    ys = [Y_FLOOR, -5.4, -5.1, -4.8, -4.5, -4.2, -3.9, -3.6, -3.35, Y_DOOR_TOP]
    skin = {z: [(_hull_x_at(hull_tris, y, z, -1), y) for y in ys] for z in (z0, z1)}
    door = {"z": (z0, z1), "line_x": (xa, xb), "skin": skin, "lobby_cut": lobby_cut, "hull_cut": hull_cut}

    # --- portholes ---------------------------------------------------------------------------------------------
    hull_glass, ports = Faces(YACHT_MATERIALS), []
    reveals = Faces(YACHT_MATERIALS)
    for side in (-1, 1):
        for zc in Y_PORTHOLES:
            ha, hb = _hull_x_at(hull_tris, Y_PORT_Y, zc - 0.5, side), _hull_x_at(hull_tris, Y_PORT_Y, zc + 0.5, side)
            t = _unit((hb - ha, 0.0, 1.0))
            n = _unit((t[2], 0.0, -t[0]))
            if n[0] * side < 0:
                n = tuple(-c for c in n)
            u, v = t, (0.0, 1.0, 0.0)
            o = (0.0, Y_PORT_Y, zc)
            corners = [(a, b) for a, b in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
            wall_d, hull_d = [], []
            for a, b in corners:
                p0 = _add(o, _add(_mul(u, a * Y_PORT_HW), _mul(v, b * Y_PORT_HH)))
                wh = ray_hits(state_tris, p0, n)
                hh_ = ray_hits(hull_tris, p0, n)
                wall_d.append(wh[-1] if wh else None)
                hull_d.append(hh_[-1] if hh_ else None)
            if None in wall_d or None in hull_d:
                ports.append({"side": side, "z": zc, "skipped": True, "wall": wall_d, "hull": hull_d})
                continue
            n0, n1 = min(wall_d) - 0.12, max(hull_d) + 0.3
            planes = _prism_planes(o, u, v, n, Y_PORT_HW, Y_PORT_HH, n0, n1)
            pts = [_add(o, _add(_mul(u, a * Y_PORT_HW), _add(_mul(v, b * Y_PORT_HH), _mul(n, dd))))
                   for a, b in corners for dd in (n0, n1)]
            bounds = _bounds_of(pts)
            cut_w = cut_region([root + "|r4|mesh"], planes, bounds)
            cut_h = cut_region(hull_xf, planes, bounds)
            inner = [_add(o, _add(_mul(u, a * Y_PORT_HW), _add(_mul(v, b * Y_PORT_HH), _mul(n, wall_d[i] - 0.02))))
                     for i, (a, b) in enumerate(corners)]
            outer = [_add(o, _add(_mul(u, a * Y_PORT_HW), _add(_mul(v, b * Y_PORT_HH), _mul(n, hull_d[i]))))
                     for i, (a, b) in enumerate(corners)]
            centre = _mul(_add(_add(inner[0], inner[2]), _add(outer[0], outer[2])), 0.25)
            # reveal: the four sides of the hole, facing the window axis
            for i in range(4):
                j = (i + 1) % 4
                quad = [inner[i], inner[j], outer[j], outer[i]]
                mid = _mul(_add(_add(quad[0], quad[1]), _add(quad[2], quad[3])), 0.25)
                facing = _sub(centre, mid)
                facing = _sub(facing, _mul(n, _dot(facing, n)))
                reveals.add("wall", quad, _unit(facing))
            glass_in = [_sub(p, _mul(n, 0.03)) for p in outer]
            reveals.add("glass", glass_in, tuple(-c for c in n))
            hull_glass.add("glass", outer, n)
            # portal at the outermost wall point: the room stays whole, the reveal and the glass lie beyond it
            dp = max(wall_d) + 0.01
            prt = [_add(o, _add(_mul(u, a * Y_PORT_HW), _add(_mul(v, b * Y_PORT_HH), _mul(n, dp)))) for a, b in corners]
            ports.append({"side": side, "z": zc, "portal": prt, "cuts": [cut_w, cut_h],
                          "depth": [min(wall_d), max(hull_d)]})
    reveals.build(root + "|r4|mesh", "portholes", sgs)
    hull_glass.build(root + "|r0|mesh", "portholes_glass", sgs)
    for p in ports:
        if not p.get("skipped"):
            # front into the stateroom (the cell inside), as the transport's window portals
            p["portal_index"] = portal(root, 0, 4, p["portal"], (0.0, Y_PORT_Y, p["z"]), passable=False)["index"]
    return {"door": door, "portholes": ports}


def _new_cell(root, index, name):
    cell = cmds.createNode("transform", name=f"r{index}", parent=root)
    cell = cmds.ls(cell, long=True)[0]
    cmds.addAttr(cell, longName="pobCellName", dataType="string")
    cmds.setAttr(cell + ".pobCellName", name, type="string")
    cmds.addAttr(cell, longName="pobCellCanSeeWorld", attributeType="bool")
    cmds.setAttr(cell + ".pobCellCanSeeWorld", True)
    for grp in ("mesh", "portals", "collision"):
        cmds.createNode("transform", name=grp, parent=cell)
    cmds.createNode("transform", name="floor0", parent=cell + "|collision")
    for node in (cell + "|mesh", cell + "|collision|floor0"):          # as createPobTemplate makes them
        cmds.addAttr(node, longName="external_reference", shortName="extref", dataType="string")
    return cell


def _split_lobby_floor(root, za, zb):
    """Insert the door's ends into the lobby floor's outboard edge, so the floor edge under the door portal is its
    own edge (crossable) and the rest of the wall foot stays uncrossable."""
    floor = root + "|r2|collision|floor0"
    shape = (cmds.listRelatives(floor, allDescendents=True, type="mesh", fullPath=True) or [None])[0]
    sel = om.MSelectionList()
    sel.add(shape)
    dag = sel.getDagPath(0)
    fn = om.MFnMesh(dag)
    P = [(p.x, p.y, p.z) for p in fn.getPoints(om.MSpace.kWorld)]
    counts, ids = fn.getTriangles()
    T = [tuple(ids[i:i + 3]) for i in range(0, len(ids), 3)]
    (ex0, ez0), (ex1, ez1) = Y_LOBBY_EDGE
    e0 = min(range(len(P)), key=lambda i: (P[i][0] - ex0) ** 2 + (P[i][2] - ez0) ** 2)
    e1 = min(range(len(P)), key=lambda i: (P[i][0] - ex1) ** 2 + (P[i][2] - ez1) ** 2)
    ia, ib = len(P), len(P) + 1
    P += [(_lobby_edge_x(za), P[e0][1], za), (_lobby_edge_x(zb), P[e0][1], zb)]
    out = []
    for t in T:
        if e0 in t and e1 in t:
            # the triangle on the edge: fan it from its third corner through the two new points, same winding
            k = t.index(e0)
            a_, b_, c_ = t[k], t[(k + 1) % 3], t[(k + 2) % 3]      # a_ = e0
            if b_ == e1:            # winding e0 -> e1 -> other
                other = c_
                out += [(e0, ia, other), (ia, ib, other), (ib, e1, other)]
            else:                   # winding e0 -> other -> e1
                other = b_
                out += [(e0, other, ia), (ia, other, ib), (ib, other, e1)]
        else:
            out.append(t)
    parent = cmds.listRelatives(shape, parent=True, fullPath=True)[0]
    cmds.delete(shape)
    new = om.MFnMesh()
    psel = om.MSelectionList()
    psel.add(parent)
    new.create(om.MPointArray([om.MPoint(*p) for p in P]), om.MIntArray([3] * len(out)),
               om.MIntArray([i for t in out for i in t]), parent=psel.getDependNode(0))
    shape = cmds.listRelatives(parent, shapes=True, fullPath=True)[0]
    cmds.sets(shape, edit=True, forceElement="initialShadingGroup")
    # the exporter expects floors facing up
    a, b, c = (P[i] for i in out[0])
    up = _cross(_sub(b, a), _sub(c, a))[1]
    if up < 0:
        cmds.polyNormal(shape, normalMode=0, userNormalMode=0, constructionHistory=False)
    return {"edge": [e0, e1], "points": [P[ia], P[ib]], "flipped": up < 0, "tris": len(out)}


def yacht_ramp_cell(root):
    """Stage 3: r12 'ramp': the door notch (sill, jambs, lintel) and the open-air box over the lowered plank, its
    portals (door, foot, top, sides, bottom, under the hinge), floor and lights; the lobby floor split at the door."""
    sgs = _materials("swg_titan_yacht_ramp", YACHT_MATERIALS)    # one material set per stage (no re-create)
    hull_tris = tri_list([root + "|r0|mesh"])
    z0, z1 = Y_DOOR_Z
    cells = [c for c in cmds.listRelatives(root, children=True) or [] if c.startswith("r") and c[1:].isdigit()]
    index = max(int(c[1:]) for c in cells) + 1
    cell = _new_cell(root, index, "ramp")
    xa, xb = _lobby_edge_x(z0), _lobby_edge_x(z1)
    F = Faces(YACHT_MATERIALS)
    # sill (deck level) from the lobby floor edge to the hinge, and its lip down to the plank
    F.add("floor", [(xa, Y_FLOOR, z0), (xb, Y_FLOOR, z1), (Y_HINGE_X, Y_FLOOR, z1), (Y_HINGE_X, Y_FLOOR, z0)],
          (0, 1, 0))
    F.add("metal", [(Y_HINGE_X, Y_FLOOR, z0), (Y_HINGE_X, Y_FLOOR, z1), (Y_HINGE_X, Y_HINGE_Y - 0.15, z1),
                    (Y_HINGE_X, Y_HINGE_Y - 0.15, z0)], (-1, 0, 0))
    # jambs: lobby wall line to the hull skin, floor to lintel
    for z, facing, zs in ((z0, (0, 0, 1), z0 - 0.02), (z1, (0, 0, -1), z1 + 0.02)):
        lx = _lobby_edge_x(z)
        sk = []
        for y in (Y_FLOOR, -5.4, -5.1, -4.8, -4.5, -4.2, -3.9, -3.6, -3.35, Y_DOOR_TOP):
            x = _hull_x_at(hull_tris, y, zs, -1)       # sampled just beside the hole: the hull outside the cut
            sk.append((x if x is not None else Y_HINGE_X, y))
        poly = [(lx, Y_FLOOR, z)] + [(min(x, Y_HINGE_X) if y == Y_FLOOR else x, y, z) for x, y in sk] + \
               [(lx, Y_DOOR_TOP, z)]
        F.add("wall", poly, facing)
    # lintel: lobby wall line to where the hull top meets the door top
    xt0 = _hull_x_at(hull_tris, Y_DOOR_TOP, z0 - 0.02, -1) or -8.9
    xt1 = _hull_x_at(hull_tris, Y_DOOR_TOP, z1 + 0.02, -1) or -8.9
    F.add("ceiling", [(xa, Y_DOOR_TOP, z0), (xt0, Y_DOOR_TOP, z0), (xt1, Y_DOOR_TOP, z1), (xb, Y_DOOR_TOP, z1)],
          (0, -1, 0))
    F.build(cell + "|mesh", "ramp", sgs)
    # floors: sill + the lowered plank down to the ground
    _floor(cell, [[(xa, Y_FLOOR, z0), (xb, Y_FLOOR, z1), (Y_HINGE_X, Y_FLOOR, z1), (Y_HINGE_X, Y_FLOOR, z0)],
                  [(Y_HINGE_X, Y_FLOOR, z0), (Y_HINGE_X, Y_FLOOR, z1), (Y_FOOT_X, Y_GROUND + 0.03, z1),
                   (Y_FOOT_X, Y_GROUND + 0.03, z0)]])
    split = _split_lobby_floor(root, z0, z1)
    # portals
    xtop = min(xt0, xt1)
    ramp_in = (Y_HINGE_X - 1.5, (Y_FLOOR + Y_DOOR_TOP) / 2 - 0.6, (z0 + z1) / 2)
    lobby_in = (-4.0, -4.5, 22.0)
    yb, yt = Y_CELL_BOTTOM, Y_DOOR_TOP
    r0, rr, r2 = 0, index, 2
    made = [
        portal(root, rr, r2, [(xa, Y_FLOOR, z0), (xb, Y_FLOOR, z1), (xb, yt, z1), (xa, yt, z0)], lobby_in),
        portal(root, r0, rr, [(Y_FOOT_X, yb, z1), (Y_FOOT_X, yb, z0), (Y_FOOT_X, yt, z0), (Y_FOOT_X, yt, z1)], ramp_in),
        portal(root, r0, rr, [(xtop, yt, z0), (Y_FOOT_X, yt, z0), (Y_FOOT_X, yt, z1), (xtop, yt, z1)], ramp_in,
               passable=False),
        # sides: hinge to foot, bottom to door top (where they cross the rim they lie on the jambs, behind the hull)
        portal(root, r0, rr, [(Y_HINGE_X, yb, z0), (Y_FOOT_X, yb, z0), (Y_FOOT_X, yt, z0), (Y_HINGE_X, yt, z0)],
               ramp_in, passable=False),
        portal(root, r0, rr, [(Y_HINGE_X, yt, z1), (Y_FOOT_X, yt, z1), (Y_FOOT_X, yb, z1), (Y_HINGE_X, yb, z1)],
               ramp_in, passable=False),
        portal(root, r0, rr, [(Y_HINGE_X, yb, z1), (Y_FOOT_X, yb, z1), (Y_FOOT_X, yb, z0), (Y_HINGE_X, yb, z0)],
               ramp_in, passable=False),
        portal(root, r0, rr, [(Y_HINGE_X, yb, z0), (Y_HINGE_X, Y_FLOOR, z0), (Y_HINGE_X, Y_FLOOR, z1),
                              (Y_HINGE_X, yb, z1)], ramp_in, passable=False),
    ]
    _lights(cell, ((0.75, 0.72, 0.68), 0.55), [((-7.0, -3.6, (z0 + z1) / 2), (1.0, 0.95, 0.85), 0.6)],
            [((0.3, -1.0, 0.2), (0.8, 0.75, 0.66), 1.0), ((-0.2, 1.0, -0.1), (0.25, 0.25, 0.28), 1.0)])
    return {"cell": cell, "index": index, "portals": made, "lobby_floor": split,
            "ramp": {"hinge": (Y_HINGE_X, Y_HINGE_Y), "foot_x": Y_FOOT_X, "length": Y_RAMP_LEN}}


def _prism(F, key, base, axis_dir, length, radius, sides=8, caps=True):
    """A closed n-sided prism from `base` along unit `axis_dir`, faces out."""
    a = _unit(axis_dir)
    ref = (1.0, 0.0, 0.0) if abs(a[0]) < 0.9 else (0.0, 1.0, 0.0)
    e1 = _unit(_cross(a, ref))
    e2 = _cross(a, e1)
    ring = []
    for i in range(sides):
        t = 2 * math.pi * (i + 0.5) / sides
        ring.append(_add(_mul(e1, radius * math.cos(t)), _mul(e2, radius * math.sin(t))))
    top = _mul(a, length)
    for i in range(sides):
        j = (i + 1) % sides
        q = [_add(base, ring[i]), _add(base, ring[j]), _add(_add(base, top), ring[j]), _add(_add(base, top), ring[i])]
        F.add(key, q, _unit(_add(ring[i], ring[j])))
    if caps:
        F.add(key, [_add(base, r) for r in ring], tuple(-c for c in a))
        F.add(key, [_add(_add(base, top), r) for r in ring], a)


def _export_part(name, F, sgs, export_root):
    for old in cmds.ls(name, long=True) or []:
        cmds.delete(old)
    root = cmds.createNode("transform", name=name)
    F.build("|" + name, name, sgs)
    apt = f"{export_root}/appearance/{name}.apt".replace("\\", "/")
    cmds.select("|" + name, replace=True)
    mel.eval(f'exportStaticMesh -path "{apt}" -collision none')
    cmds.delete("|" + name)
    return f"appearance/{name}.apt"


def yacht_parts(root, export_root="D:/exported", name="titan_sorosuub_yacht"):
    """Stage 4: the boarding plank and the three landing legs as their own meshes on hardpoints (hp_dyn parts).
    Plank: modelled lowered-flat (out from the hinge, -x); stowed it sits slid into the belly, deploying slides it
    out, then tilts it down Y_RAMP_DEG. Legs: modelled folded forward under the belly; deploying swings them down."""
    sgs = _materials("swg_titan_yacht_parts", YACHT_MATERIALS)
    hull_tris = tri_list([root + "|r0|mesh"])
    parts, hps = [], {}
    # --- plank ------------------------------------------------------------------------------------------------
    z0, z1 = Y_DOOR_Z
    hw, L, th = (z1 - z0) / 2 - 0.02, Y_RAMP_LEN + 0.05, 0.12
    F = Faces(YACHT_MATERIALS)
    F.add("grate", [(0, 0, -hw), (0, 0, hw), (-L, 0, hw), (-L, 0, -hw)], (0, 1, 0))
    F.add("metal", [(0, -th, -hw), (-L, -th, -hw), (-L, -th, hw), (0, -th, hw)], (0, -1, 0))
    for zz, f in ((-hw, (0, 0, -1)), (hw, (0, 0, 1))):
        F.add("metal", [(0, 0.06, zz), (-L, 0.06, zz), (-L, -th, zz), (0, -th, zz)], f)
        inner = zz - 0.06 if zz > 0 else zz + 0.06
        F.add("metal", [(0, 0.06, inner), (-L, 0.06, inner), (-L, 0, inner), (0, 0, inner)], (0, 0, -f[2]))
        F.add("metal", [(0, 0.06, zz), (0, 0.06, inner), (-L, 0.06, inner), (-L, 0.06, zz)], (0, 1, 0))
    F.add("metal", [(-L, 0, -hw), (-L, 0, hw), (-L, -th, hw), (-L, -th, -hw)], (-1, 0, 0))
    F.add("metal", [(0, 0, hw), (0, 0, -hw), (0, -th, -hw), (0, -th, hw)], (1, 0, 0))
    ramp_apt = _export_part(f"{name}_ramp", F, sgs, export_root)
    hps["ramp"] = (Y_HINGE_X, Y_HINGE_Y, (z0 + z1) / 2)
    parts.append({"slot": "ramp", "hp": "ramp", "path": ramp_apt, "mode": "rot", "axis": [0.0, 0.0, 1.0],
                  "amount": Y_RAMP_DEG, "seconds": 4.0, "slide": [L - 0.05, 0.0, 0.0]})
    # --- legs ---------------------------------------------------------------------------------------------------
    legs = {}
    for slot, (x, z, pad) in Y_GEAR.items():
        hits = ray_hits(hull_tris, (x, -30.0, z), (0.0, 1.0, 0.0))
        belly = -30.0 + hits[0]
        hp_y = belly - 0.22
        length = hp_y - Y_GROUND
        F = Faces(YACHT_MATERIALS)
        fwd = (0.0, 0.0, 1.0)
        _prism(F, "metal", (0.0, 0.0, -0.25), fwd, 0.5, 0.2, sides=8)                       # hinge knuckle (x axis)
        _prism(F, "metal", (0.0, 0.0, 0.0), fwd, length * 0.55, 0.17)                      # upper sleeve
        _prism(F, "metal", (0.0, 0.0, length * 0.5), fwd, length * 0.5 - 0.12, 0.11)        # oleo
        _prism(F, "grate", (0.0, 0.0, length - 0.12), fwd, 0.12, pad, sides=10)             # foot pad
        apt = _export_part(f"{name}_{slot}", F, sgs, export_root)
        hps[slot] = (x, hp_y, z)
        parts.append({"slot": slot, "hp": slot, "path": apt, "mode": "rot", "axis": [1.0, 0.0, 0.0],
                      "amount": 90.0, "seconds": 3.0})
        legs[slot] = {"belly": belly, "length": length}
    hardpoints = {k: [[1.0, 0.0, 0.0, -p[0]], [0.0, 1.0, 0.0, p[1]], [0.0, 0.0, 1.0, p[2]]] for k, p in hps.items()}
    return {"parts": parts, "hardpoints": hardpoints, "legs": legs}


def build_yacht(name="titan_sorosuub_yacht", export_root="D:/exported", export=True):
    """The Sorosuub yacht variant (see the section comment): all stages, then the POB export."""
    info = yacht_import(name)
    root = info.pop("root")
    info.update(yacht_openings(root))
    info.update(yacht_ramp_cell(root))
    info.update(yacht_parts(root, export_root, name))
    info["landed"] = [[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, -Y_GROUND], [0.0, 0.0, 1.0, 0.0]]
    info["root"] = root
    if export:
        info["export"] = pb.export(root, export_root, name)
    return info
