"""Otoh Gunga structure set (the Gungan bubble city of Naboo) - runs inside Maya with SwgMayaEditor loaded;
examples/make_otoh_gunga.py drives it step by step and writes the lods, client data files and templates.

The look follows the films: clusters of glowing translucent bubbles in different sizes, warm amber light inside,
organic bronze ribs arching over each bubble in a pointed-arch lattice, small bubbles on stalks, hanging pods
and blue-lit lower spheres. Underwater rendering is not supported, so the set stands on land: each bubble is
cut off at the ground (or sits on its stalk) and glows on its own through emissive shaders.

Layers of a bubble, outside in:
  skin    see-through pale amber glass (alpha + full emissive), the sphere itself
  ribs    bronze tubes on the skin: meridians, pointed arches between them, a crown ring and a spire
  nodes   small hot-gold lights where ribs cross (emissive)
  shell   a denser amber glow layer just inside (the hub: pob_build's exterior domes) - seen through the skin it
          gives the "lit from inside" depth of the reference
The hub (a POB) is pob_build's cells + portals + floors + lights, dressed here: glow domes inside, interior
ribs, a lantern column and hanging glow pods; the skins, ribs, collars round the tube openings and the
effect hardpoints go on r0.

Static pieces (object/static/structure/naboo/shared_nboo_otoh_<piece>_s01.iff): see PIECES."""

from __future__ import annotations

import math
import os

import maya.cmds as cmds
import maya.mel as mel

from . import pob_builder as pb
from .kit import Piece

PIECES = ["pod_sm", "pod_md", "pod_hanging", "sphere_blue", "tube", "stalk", "rib_arch", "rib_lattice", "dome_lg",
          "bubble_cluster"]
# material slot -> shader (absolute .sht paths filled in by configure(); stock ones are tree paths)
SHADERS = {
    "skin": "shader/nboo_otoh_glass_skin.sht", "shell": "shader/nboo_otoh_glow_shell.sht",
    "veil": "shader/nboo_otoh_glow_veil.sht", "wall_in": "shader/nboo_otoh_wall_in.sht",
    "mosaic": "shader/nboo_otoh_floor_mosaic.sht",
    "core": "shader/nboo_otoh_glow_core.sht", "blue": "shader/nboo_otoh_glow_blue.sht",
    "rib": "shader/nboo_otoh_rib.sht", "stone": "shader/gungan_brick01_asb13.sht",
}
COLORS = {"skin": (1.0, 0.7, 0.3), "shell": (0.95, 0.5, 0.15), "veil": (0.95, 0.55, 0.2), "wall_in": (0.85, 0.48, 0.18),
          "mosaic": (0.55, 0.42, 0.28), "core": (1.0, 0.85, 0.5), "blue": (0.15, 0.35, 0.8),
          "rib": (0.42, 0.3, 0.18), "stone": (0.5, 0.5, 0.42)}
UVS = {"stone": 3.0}
DETAIL = 1.0                  # tessellation factor for the primitives; the far LODs rebuild a piece at 0.5 / 0.25


def _d(n, lo=3):
    return max(lo, int(round(n * DETAIL)))


def configure(shaders):
    SHADERS.update(shaders or {})


def _sg(slot):
    if cmds.objExists(f"otoh_{slot}SG"):        # re-making it would fight its connected preview texture
        return f"otoh_{slot}SG"
    return pb._material(f"otoh_{slot}", COLORS[slot], None, SHADERS[slot])


# ---------------------------------------------------------------------------------------------------------------
# primitives (Maya space, y up)
# ---------------------------------------------------------------------------------------------------------------

def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _unit(a):
    ln = math.sqrt(_dot(a, a)) or 1.0
    return (a[0] / ln, a[1] / ln, a[2] / ln)


def _put(A, corners, uvs, want):
    """Polygon with explicit UVs, wound so its normal points along `want`."""
    n = pb._normal3(corners)
    if _dot(n, want) < 0:
        corners, uvs = corners[::-1], uvs[::-1]
    A.poly(corners, uvs)


def sphere(A, c, r, lat0=-90.0, lat1=90.0, nu=40, nv=20, inward=False, keep=None, tiles=(4.0, 2.0), sy=1.0):
    """Latitude band lat0..lat1 (degrees) of a sphere (y radius r * sy); keep(face centre) drops faces (openings)."""
    nu, nv = _d(nu, 6), _d(nv, 3)
    rows = max(1, int(round(nv * (lat1 - lat0) / 180.0)))

    def P(i, j):
        lon = 2 * math.pi * i / nu
        lat = math.radians(lat0 + (lat1 - lat0) * j / rows)
        return (c[0] + r * math.cos(lat) * math.cos(lon), c[1] + r * sy * math.sin(lat), c[2] + r * math.cos(lat) * math.sin(lon))
    for j in range(rows):
        for i in range(nu):
            q = [P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1)]
            mid = tuple(sum(p[k] for p in q) / 4 for k in range(3))
            if keep and not keep(mid):
                continue
            v0, v1 = tiles[1] * j / rows, tiles[1] * (j + 1) / rows
            u0, u1 = tiles[0] * i / nu, tiles[0] * (i + 1) / nu
            out = _sub(mid, c)
            _put(A, q, [(u0, v0), (u1, v0), (u1, v1), (u0, v1)], tuple(-x for x in out) if inward else out)


def lathe(A, c, profile, n=16, inward=False, tiles=1.0):
    """Surface of revolution round the vertical axis through c: profile [(radius, y)] bottom to top."""
    n = _d(n, 6)
    length = sum(math.hypot(profile[k + 1][0] - profile[k][0], profile[k + 1][1] - profile[k][1]) for k in range(len(profile) - 1))
    acc_v = [0.0]
    for k in range(len(profile) - 1):
        acc_v.append(acc_v[-1] + math.hypot(profile[k + 1][0] - profile[k][0], profile[k + 1][1] - profile[k][1]))
    for k in range(len(profile) - 1):
        (r0, y0), (r1, y1) = profile[k], profile[k + 1]
        for i in range(n):
            a0, a1 = 2 * math.pi * i / n, 2 * math.pi * (i + 1) / n
            q = [(c[0] + r0 * math.cos(a0), c[1] + y0, c[2] + r0 * math.sin(a0)),
                 (c[0] + r0 * math.cos(a1), c[1] + y0, c[2] + r0 * math.sin(a1)),
                 (c[0] + r1 * math.cos(a1), c[1] + y1, c[2] + r1 * math.sin(a1)),
                 (c[0] + r1 * math.cos(a0), c[1] + y1, c[2] + r1 * math.sin(a0))]
            am = (a0 + a1) / 2
            dr, dy = r1 - r0, y1 - y0
            out = (math.cos(am) * dy, -dr, math.sin(am) * dy)       # profile normal, rotated round the axis
            if abs(dy) < 1e-6 and abs(dr) < 1e-6:
                continue
            uvs = [(tiles * i / n, acc_v[k] / length * tiles * 4), (tiles * (i + 1) / n, acc_v[k] / length * tiles * 4),
                   (tiles * (i + 1) / n, acc_v[k + 1] / length * tiles * 4), (tiles * i / n, acc_v[k + 1] / length * tiles * 4)]
            _put(A, q, uvs, tuple(-x for x in out) if inward else out)


def disc(A, c, r0, r1, y, n=24, tile=3.0, down=False):
    """Flat ring r0..r1 (r0 = 0: a full disc) at height y round c, planar UVs (x / tile, z / tile) so a stone or
    mosaic texture lies flat instead of streaking round the centre like lathe() UVs do."""
    n = _d(n, 8)
    want = (0, -1, 0) if down else (0, 1, 0)
    for i in range(n):
        a0, a1 = 2 * math.pi * i / n, 2 * math.pi * (i + 1) / n
        pts = [(c[0] + r1 * math.cos(a0), c[1] + y, c[2] + r1 * math.sin(a0)),
               (c[0] + r1 * math.cos(a1), c[1] + y, c[2] + r1 * math.sin(a1))]
        if r0 > 1e-6:
            pts += [(c[0] + r0 * math.cos(a1), c[1] + y, c[2] + r0 * math.sin(a1)),
                    (c[0] + r0 * math.cos(a0), c[1] + y, c[2] + r0 * math.sin(a0))]
        else:
            pts.append((c[0], c[1] + y, c[2]))
        _put(A, pts, [(q[0] / tile, q[2] / tile) for q in pts], want)


def tube(A, path, radius, n=6, caps=True, closed=False):
    """Tube along a polyline (parallel-transport frames). radius: float or f(t in 0..1). closed: a loop."""
    n = _d(n, 3)
    pts = list(path)
    if len(pts) < 2:
        return
    rad = radius if callable(radius) else (lambda t, r=radius: r)
    m = len(pts)
    tang = []
    for k in range(m):
        if closed:
            a, b = pts[k - 1], pts[(k + 1) % m]
        else:
            a, b = pts[max(0, k - 1)], pts[min(m - 1, k + 1)]
        tang.append(_unit(_sub(b, a)))
    ref = (0.0, 1.0, 0.0) if abs(tang[0][1]) < 0.9 else (1.0, 0.0, 0.0)
    nrm = _unit(_cross(tang[0], ref))
    frames = []
    for k in range(m):
        t = tang[k]
        nrm = _unit(_sub(nrm, tuple(t[i] * _dot(nrm, t) for i in range(3))))
        frames.append((nrm, _cross(t, nrm)))
    lens = [0.0]
    for k in range(1, m):
        lens.append(lens[-1] + math.sqrt(_dot(_sub(pts[k], pts[k - 1]), _sub(pts[k], pts[k - 1]))))
    total = lens[-1] or 1.0
    rings = []
    for k in range(m):
        N, B = frames[k]
        r = rad(lens[k] / total)
        rings.append([tuple(pts[k][i] + r * (math.cos(2 * math.pi * j / n) * N[i] + math.sin(2 * math.pi * j / n) * B[i])
                            for i in range(3)) for j in range(n)])
    peri = 2 * math.pi * max(rad(0.5), 0.02)
    segs = range(m) if closed else range(m - 1)
    for k in segs:
        k2 = (k + 1) % m
        for j in range(n):
            q = [rings[k][j], rings[k][(j + 1) % n], rings[k2][(j + 1) % n], rings[k2][j]]
            mid = tuple(sum(p[i] for p in q) / 4 for i in range(3))
            axis = tuple((pts[k][i] + pts[k2][i]) / 2 for i in range(3))
            v0, v1 = lens[k] / peri, (lens[k2] if k2 else total) / peri
            _put(A, q, [(j / n, v0), ((j + 1) / n, v0), ((j + 1) / n, v1), (j / n, v1)], _sub(mid, axis))
    if caps and not closed:
        for k, sgn in ((0, -1), (m - 1, 1)):
            ring = rings[k]
            _put(A, ring, [(0.5 + 0.5 * math.cos(2 * math.pi * j / n), 0.5 + 0.5 * math.sin(2 * math.pi * j / n)) for j in range(n)],
                 tuple(sgn * x for x in tang[k]))


def on_sphere(c, r, lon_deg, lat_deg):
    lon, lat = math.radians(lon_deg), math.radians(lat_deg)
    return (c[0] + r * math.cos(lat) * math.cos(lon), c[1] + r * math.sin(lat), c[2] + r * math.cos(lat) * math.sin(lon))


def _lerp(a, b, t):
    return a + (b - a) * t


def bubble_ribs(R, c, r, lat0, lat_crown=76.0, meridians=12, lon_offset=None, holes=(), arches=True, ring_lat=None,
                rib_r=None, spire=1.4, nodes=None, offset=None):
    """The lattice over a bubble: meridian ribs (thick at the foot, tapering), pointed arches between neighbours
    in the lower band, a crown ring with spokes and a spire, an optional latitude ring. holes = [lon] of
    openings to keep clear (arches spanning one are left out). Returns the spire tip (for a glow / hardpoint)."""
    rr = rib_r or max(0.07, r * 0.016)
    off = offset if offset is not None else rr * 1.2
    ro = r + off
    step = 360.0 / meridians
    lo = (step / 2) if lon_offset is None else lon_offset
    lons = [lo + step * k for k in range(meridians)]
    seg = 18

    def arc(lon_a, lat_a, lon_b, lat_b, bulge=0.0):
        out = []
        for k in range(seg + 1):
            t = k / seg
            lat = _lerp(lat_a, lat_b, t) + bulge * math.sin(math.pi * t)
            out.append(on_sphere(c, ro, _lerp(lon_a, lon_b, t), lat))
        return out
    for lon in lons:
        sway = 3.0
        path = [on_sphere(c, ro, lon + sway * math.sin(math.pi * k / seg * 2), _lerp(lat0, lat_crown, k / seg)) for k in range(seg + 1)]
        tube(R, path, lambda t: rr * (1.6 - 0.7 * t), n=7)
    if arches:
        apex = lat0 + (lat_crown - lat0) * 0.42
        for k, lon in enumerate(lons):
            lon2 = lon + step
            if any((((h - lon) % 360) < step) for h in holes):
                continue
            mid = lon + step / 2
            left = [on_sphere(c, ro, _lerp(lon, mid, (t / seg) ** 0.7), _lerp(lat0, apex, math.sin(math.pi / 2 * t / seg)))
                    for t in range(seg + 1)]
            right = [on_sphere(c, ro, _lerp(lon2, mid, (t / seg) ** 0.7), _lerp(lat0, apex, math.sin(math.pi / 2 * t / seg)))
                     for t in range(seg + 1)]
            tube(R, left + right[::-1][1:], rr * 0.75, n=6)
            if nodes is not None:
                nodes.append((on_sphere(c, ro + rr, mid, apex), rr * 1.9))
    crown = [on_sphere(c, ro, 360.0 * k / 36, lat_crown) for k in range(36)]
    tube(R, crown, rr * 1.1, n=7, closed=True)
    if ring_lat is not None:
        ring = [on_sphere(c, ro, 360.0 * k / 48, ring_lat) for k in range(48)]
        tube(R, ring, rr * 0.8, n=6, closed=True)
        if nodes is not None:
            for lon in lons:
                nodes.append((on_sphere(c, ro + rr * 0.8, lon, ring_lat), rr * 2.1))
    top = (c[0], c[1] + ro, c[2])
    for lon in lons[::2]:                          # spokes from the crown to the cap
        tube(R, [on_sphere(c, ro, lon, lat_crown), on_sphere(c, ro + rr, lon, (lat_crown + 90) / 2), top], rr * 0.8, n=6)
    tip = (top[0], top[1] + spire, top[2])
    if spire > 0:
        tube(R, [top, (top[0], top[1] + spire * 0.5, top[2]), tip], lambda t: rr * (1.5 - 0.9 * t), n=7)
    return tip


def _fan(cx, cz, r, n=12):
    pts = [(cx + r * math.cos(2 * math.pi * k / n), cz + r * math.sin(2 * math.pi * k / n)) for k in range(n)]
    return [((cx, cz), pts[k], pts[(k + 1) % n]) for k in range(n)]


def _box(cx, cz, hx, hz, y0, y1):
    return ((cx - hx, y0, cz - hz), (cx + hx, y1, cz + hz))


def _roots(R, c, r_base, n=5, reach=1.6, rr=0.14, y=0.0, seed=0):
    """Organic roots flaring from a stalk foot into the ground."""
    for k in range(n):
        a = 2 * math.pi * (k + 0.37 * seed) / n
        path = []
        for t in range(9):
            s = t / 8
            rad = r_base * 0.8 + reach * s
            path.append((c[0] + rad * math.cos(a + 0.25 * s), y + 1.0 * (1 - s) ** 1.6 - 0.15 * s, c[2] + rad * math.sin(a + 0.25 * s)))
        tube(R, path, lambda t: rr * (1.3 - 0.8 * t), n=6)


# ---------------------------------------------------------------------------------------------------------------
# static pieces
# ---------------------------------------------------------------------------------------------------------------

def _pod(P, c, r, lat0=-90.0, glow=True, ribs=10, spire=None, holes=()):
    """A free bubble: skin, inner glow core, ribs, rib-cross nodes. Returns the glow centre and spire tip."""
    sphere(P.a("skin"), c, r, lat0, 90.0, nu=36, nv=18, tiles=(3.0, 1.5))
    sphere(P.a("veil"), c, r * 0.93, lat0, 90.0, nu=28, nv=14, inward=True, tiles=(2.0, 1.0))
    if glow:
        sphere(P.a("core"), (c[0], c[1] - r * 0.15, c[2]), r * 0.28, nu=14, nv=8, tiles=(1.0, 1.0))
    nodes = []
    tip = bubble_ribs(P.a("rib"), c, r, max(lat0, -60.0), meridians=ribs, holes=holes, nodes=nodes,
                      ring_lat=-5.0 if lat0 < -20 else None, spire=r * 0.35 if spire is None else spire)
    for p, nr in nodes:
        sphere(P.a("core"), p, nr, nu=8, nv=4, tiles=(1.0, 1.0))
    return (c[0], c[1] - r * 0.15, c[2]), tip


def build_piece(piece):
    P = Piece()
    P.hardpoints = []          # (name, (x, y, z))
    if piece == "pod_sm":
        # small bubble on a stalk: stalk 5 m with roots, a cup, the bubble (r 2) above it
        lathe(P.a("rib"), (0, 0, 0), [(0.55, -0.4), (0.42, 0.4), (0.26, 1.6), (0.2, 3.4), (0.26, 4.2), (0.7, 4.7),
                                      (1.05, 4.95)], n=12)
        _roots(P.a("rib"), (0, 0, 0), 0.45, n=5, reach=1.5)
        core, tip = _pod(P, (0, 6.55, 0), 2.0, lat0=-70.0)
        P.boxes = [_box(0, 0, 0.5, 0.5, 0, 4.6), _box(0, 0, 1.6, 1.6, 4.6, 8.6)]
        P.footprint = _fan(0, 0, 2.0)
        P.hardpoints = [("glow_core", core), ("glow_top", tip)]
    elif piece == "pod_md":
        # medium bubble sitting on a root ring at ground level (cut at the ground like the hub)
        c, r = (0.0, 1.4, 0.0), 3.6
        lat0 = -math.degrees(math.asin(1.5 / r))
        core, tip = _pod(P, c, r, lat0=lat0, ribs=12, spire=1.0)
        ring_r = math.sqrt(r * r - 1.4 * 1.4)
        lathe(P.a("rib"), (0, 0, 0), [(ring_r + 0.45, -0.3), (ring_r + 0.35, 0.25), (ring_r - 0.05, 0.45), (ring_r - 0.3, 0.3)], n=36)
        disc(P.a("stone"), (0, 0, 0), 0.0, ring_r - 0.3, 0.3, n=36)
        P.boxes = [_box(0, 0, 2.6, 2.6, 0, 4.8)]
        P.footprint = _fan(0, 0, ring_r + 0.4)
        P.hardpoints = [("glow_core", core), ("glow_top", tip)]
    elif piece == "pod_hanging":
        # gooseneck stalk bending over, a pod hanging from it on a short stem
        path = [(0, -0.3, 0), (0, 2.0, 0), (0.1, 4.5, 0), (0.6, 6.4, 0), (1.6, 7.5, 0), (2.8, 7.7, 0), (3.6, 7.2, 0)]
        tube(P.a("rib"), path, lambda t: 0.3 * (1.0 - 0.55 * t), n=10)
        _roots(P.a("rib"), (0, 0, 0), 0.3, n=4, reach=1.2, rr=0.12, seed=1)
        tube(P.a("rib"), [(3.6, 7.2, 0), (3.62, 6.6, 0), (3.6, 6.15, 0)], 0.06, n=6)
        core, tip = _pod(P, (3.6, 4.9, 0), 1.3, ribs=8, spire=0.0)
        P.boxes = [_box(0, 0, 0.35, 0.35, 0, 7.8)]
        P.composite = False
        P.footprint = _fan(0, 0, 0.6) + _fan(3.6, 0, 1.3)
        P.hardpoints = [("glow_core", core), ("glow_stem", (3.6, 6.4, 0))]
    elif piece == "sphere_blue":
        # cluster of blue-lit lower spheres on a low root plinth
        balls = [((0.0, 1.55, 0.0), 1.45), ((1.95, 1.05, 0.9), 1.0), ((-1.5, 0.85, 1.35), 0.8)]
        for (bc, br) in balls:
            sphere(P.a("blue"), bc, br, -40.0, 90.0, nu=28, nv=14, tiles=(2.0, 1.0))
            tube(P.a("rib"), [on_sphere(bc, br + 0.03, a, 0.0) for a in range(0, 360, 10)], 0.06, n=6, closed=True)
            lathe(P.a("rib"), bc, [(br * 0.85, -br * 0.65), (br * 0.55, -br * 1.05), (br * 0.3, -bc[1] - 0.2)], n=14)
        lathe(P.a("stone"), (0, 0, 0), [(3.3, -0.2), (3.2, 0.15), (2.9, 0.25)], n=24)
        disc(P.a("stone"), (0, 0, 0), 0.0, 2.9, 0.25, n=24)
        P.boxes = [_box(0, 0, 1.2, 1.2, 0, 3.0), _box(1.95, 0.9, 0.8, 0.8, 0, 2.0), _box(-1.5, 1.35, 0.65, 0.65, 0, 1.6)]
        P.footprint = _fan(0, 0, 3.2)
        P.hardpoints = [("glow_blue", (0.0, 3.4, 0.0))]
    elif piece == "tube":
        # walkable connector tube, 8 m along x: glass vault on a bronze sill, rib rings every 2 m
        L, hw, cy = 4.0, 1.6, 1.25
        prof = [(hw, 0.0), (hw, cy)] + [(hw * math.cos(math.pi * k / 12), cy + 1.45 * math.sin(math.pi * k / 12)) for k in range(1, 12)] + \
            [(-hw, cy), (-hw, 0.0)]
        for k in range(len(prof) - 1):
            (z0, y0), (z1, y1) = prof[k], prof[k + 1]
            q = [(-L, y0, z0), (L, y0, z0), (L, y1, z1), (-L, y1, z1)]
            mz, my = (z0 + z1) / 2, (y0 + y1) / 2 - cy * 0.5
            uv = [(0, k / 4), (4, k / 4), (4, (k + 1) / 4), (0, (k + 1) / 4)]
            _put(P.a("skin"), q, uv, (0, my, mz))                       # seen from outside
            _put(P.a("shell"), q, uv, (0, -my, -mz))                    # and from inside
        for x in (-L, -L / 2, 0.0, L / 2, L):                         # rib rings just outside the glass
            ring = [(x, y * (1 + 0.07 / 2.7) if y > 0.01 else -0.1, z * (1 + 0.07 / hw)) for z, y in prof]
            tube(P.a("rib"), ring, 0.11 if abs(x) == L else 0.08, n=6)
        for z in (-hw, hw):                                              # sills
            z0, z1 = (z - 0.12, z + 0.05) if z < 0 else (z - 0.05, z + 0.12)
            P.box("rib", -L, -0.2, z0, L, 0.35, z1)
        deck = P.a("stone")
        _put(deck, [(-L, 0.12, -hw), (L, 0.12, -hw), (L, 0.12, hw), (-L, 0.12, hw)], [(-L / 3, -hw / 3), (L / 3, -hw / 3), (L / 3, hw / 3), (-L / 3, hw / 3)], (0, 1, 0))
        for k in range(5):                                              # glow strips along the floor edges
            x0 = -L + 0.3 + k * 1.6
            for z in (-hw + 0.15, hw - 0.3):
                P.box("core", x0, 0.12, z, x0 + 1.0, 0.16, z + 0.15)
        P.walk = [([(-L, 0.12, -hw + 0.05), (L, 0.12, -hw + 0.05), (L, 0.12, hw - 0.05), (-L, 0.12, hw - 0.05)], [])]
        P.walls.facing([(-L, 0.0, -hw + 0.05), (L, 0.0, -hw + 0.05), (L, 1.0, -hw + 0.05), (-L, 1.0, -hw + 0.05)], (0, 0, 1))
        P.walls.facing([(-L, 0.0, hw - 0.05), (L, 0.0, hw - 0.05), (L, 1.0, hw - 0.05), (-L, 1.0, hw - 0.05)], (0, 0, -1))
        P.boxes = []
        P.footprint = [((-L, -hw), (L, -hw), (L, hw)), ((-L, -hw), (L, hw), (-L, hw))]
        P.hardpoints = [("glow_mid", (0.0, cy + 1.2, 0.0))]
    elif piece == "stalk":
        # tall support stalk: roots, a ribbed shaft, a flared cup holding a glow bulb
        prof = [(0.95, -0.4), (0.7, 0.5), (0.45, 2.0), (0.36, 5.0), (0.4, 8.0), (0.55, 9.6), (1.1, 10.6), (1.6, 11.0),
                (1.45, 11.15), (0.9, 10.85)]
        lathe(P.a("rib"), (0, 0, 0), prof, n=14)
        _roots(P.a("rib"), (0, 0, 0), 0.75, n=6, reach=2.2, rr=0.2, seed=2)
        for k in range(6):                                              # twisted fins up the shaft
            a = 2 * math.pi * k / 6
            path = [((0.42 + 0.12 * math.sin(math.pi * s / 10)) * math.cos(a + 0.6 * s / 10), 0.6 + 9.4 * s / 10,
                     (0.42 + 0.12 * math.sin(math.pi * s / 10)) * math.sin(a + 0.6 * s / 10)) for s in range(11)]
            tube(P.a("rib"), path, 0.07, n=5)
        sphere(P.a("core"), (0, 11.55, 0), 0.75, nu=18, nv=10)
        sphere(P.a("skin"), (0, 11.55, 0), 1.15, -40.0, 90.0, nu=24, nv=12)
        P.boxes = [_box(0, 0, 0.6, 0.6, 0, 11.2)]
        P.footprint = _fan(0, 0, 1.2)
        P.hardpoints = [("glow_top", (0, 11.6, 0))]
    elif piece == "rib_arch":
        # free-standing pointed rib arch, 8 m span, 7.5 m tall, with an inner tracery rib and glow nodes
        def arch(span, height, z):
            pts = []
            for k in range(25):
                t = k / 24
                x = -span / 2 + span * t
                y = height * (1 - abs(2 * t - 1) ** 1.6)
                pts.append((x, y, z))
            return pts
        for z in (-0.35, 0.35):
            tube(P.a("rib"), arch(8.0, 7.5, z), lambda t: 0.26 * (1.3 - 0.6 * math.sin(math.pi * t)), n=8)
        tube(P.a("rib"), [(x, y - 0.2, 0.0) for x, y, _ in arch(6.2, 6.6, 0)], 0.11, n=6)
        for k in range(1, 8):                                            # struts tying the two ribs together
            t = k / 8
            x = -4.0 + 8.0 * t
            y = 7.5 * (1 - abs(2 * t - 1) ** 1.6)
            tube(P.a("rib"), [(x, y, -0.35), (x, y, 0.35)], 0.08, n=5)
            sphere(P.a("core"), (x * 0.97, y - 0.05, 0.0), 0.17, nu=8, nv=4)
        sphere(P.a("core"), (0, 6.9, 0), 0.4, nu=12, nv=6)
        sphere(P.a("skin"), (0, 6.9, 0), 0.62, nu=16, nv=8)
        for x in (-4.0, 4.0):
            _roots(P.a("rib"), (x, 0, 0), 0.25, n=4, reach=1.1, rr=0.13, seed=3)
        P.boxes = [_box(-3.85, 0, 0.45, 0.6, 0, 2.5), _box(3.85, 0, 0.45, 0.6, 0, 2.5)]
        P.composite = True
        P.footprint = _fan(-3.9, 0, 0.6) + _fan(3.9, 0, 0.6)
        P.hardpoints = [("glow_top", (0, 6.9, 0))]
    elif piece == "rib_lattice":
        # the frame of a bubble on its own (a "bare" dome, 4.5 m radius) over a glow pool
        c, r = (0.0, 0.0, 0.0), 4.5
        nodes = []
        tip = bubble_ribs(P.a("rib"), c, r, 0.0, meridians=10, lon_offset=0.0, nodes=nodes, ring_lat=40.0,
                          rib_r=0.12, offset=0.0, spire=1.2)
        for p, nr in nodes:
            sphere(P.a("core"), p, nr, nu=8, nv=4)
        sphere(P.a("core"), (tip[0], tip[1] + 0.25, tip[2]), 0.3, nu=10, nv=6)
        lathe(P.a("stone"), (0, 0, 0), [(4.9, -0.2), (4.8, 0.15), (4.5, 0.2)], n=40)
        disc(P.a("stone"), (0, 0, 0), 1.4, 4.5, 0.2, n=40)
        lathe(P.a("stone"), (0, 0, 0), [(1.4, 0.2), (1.3, 0.12)], n=40)
        lathe(P.a("core"), (0, 0, 0), [(1.3, 0.12), (0.0, 0.12)], n=20)
        tube(P.a("rib"), [(1.35 * math.cos(math.radians(a)), 0.2, 1.35 * math.sin(math.radians(a))) for a in range(0, 360, 12)],
             0.09, n=6, closed=True)
        P.boxes = [_box(r * math.cos(math.radians(a)), r * math.sin(math.radians(a)), 0.3, 0.3, 0, 1.6) for a in range(0, 360, 36)]
        P.composite = True
        P.footprint = [tri for a in range(0, 360, 36) for tri in _fan(r * math.cos(math.radians(a)), r * math.sin(math.radians(a)), 0.3, 6)]
        P.hardpoints = [("glow_top", (tip[0], tip[1] + 0.25, tip[2])), ("glow_pool", (0, 0.6, 0))]
    elif piece == "dome_lg":
        # big ground dome (r 7.5): clear skin over a lit mosaic gallery floor on a bronze column, with bubbles
        # floating inside at different heights - the "city seen through the glass" look of the reference
        c, r = (0.0, 2.2, 0.0), 7.5
        lat0 = -math.degrees(math.asin(2.3 / r))
        sphere(P.a("skin"), c, r, lat0, 90.0, nu=44, nv=22, tiles=(4.0, 2.0))
        sphere(P.a("veil"), c, r * 0.95, lat0, 90.0, nu=34, nv=17, inward=True, tiles=(3.0, 1.5))
        nodes = []
        tip = bubble_ribs(P.a("rib"), c, r, lat0 + 2.0, meridians=16, nodes=nodes, ring_lat=-2.0, spire=1.8)
        for p_, nr in nodes:
            sphere(P.a("core"), p_, nr, nu=8, nv=4, tiles=(1.0, 1.0))
        ring_r = math.sqrt(r * r - (c[1] + 0.1) ** 2)
        lathe(P.a("rib"), (0, 0, 0), [(ring_r + 0.5, -0.3), (ring_r + 0.4, 0.3), (ring_r - 0.05, 0.5), (ring_r - 0.35, 0.35)], n=48)
        disc(P.a("mosaic"), (0, 0, 0), 0.0, ring_r - 0.35, 0.35, n=48, tile=2 * ring_r)
        gy = 4.4                                                          # the gallery: a lit floor half way up
        gr = math.sqrt(r * r - (gy - c[1]) ** 2) * 0.72
        disc(P.a("mosaic"), (0, 0, 0), 0.0, gr, gy, n=40, tile=2 * gr)
        disc(P.a("stone"), (0, 0, 0), 0.0, gr, gy - 0.3, n=40, down=True)
        lathe(P.a("rib"), (0, 0, 0), [(gr, gy - 0.3), (gr + 0.12, gy - 0.15), (gr, gy)], n=40)
        lathe(P.a("rib"), (0, 0, 0), [(1.1, 0.35), (0.7, 0.9), (0.55, 2.5), (0.75, 3.6), (1.6, gy - 0.3)], n=16)
        for k in range(6):                                                # lamps round the gallery edge
            a = 2 * math.pi * k / 6 + 0.3
            sphere(P.a("core"), (gr * 0.9 * math.cos(a), gy + 0.35, gr * 0.9 * math.sin(a)), 0.22, nu=10, nv=5)
        for (bx, by, bz, br) in ((3.2, 2.0, 2.4, 0.9), (-3.6, 2.6, 1.0, 1.1), (0.8, 1.6, -3.9, 0.75),
                                 (-1.6, 6.6, -1.8, 1.0), (2.2, 6.9, 1.2, 0.8), (-2.6, 1.5, -2.4, 0.6)):
            sphere(P.a("skin"), (bx, by, bz), br, nu=18, nv=9, tiles=(1.5, 1.0))
            sphere(P.a("core"), (bx, by - br * 0.1, bz), br * 0.45, nu=12, nv=6, tiles=(1.0, 1.0))
        P.boxes = [_box(ring_r * 0.92 * math.cos(math.radians(a)), ring_r * 0.92 * math.sin(math.radians(a)), 1.0, 1.0, 0, 3.0)
                   for a in range(0, 360, 30)]
        P.composite = True
        P.footprint = _fan(0, 0, ring_r + 0.4, 16)
        P.hardpoints = [("glow_core", (0.0, gy + 1.0, 0.0)), ("glow_top", tip), ("glow_low", (0.0, 1.5, 0.0))]
    elif piece == "bubble_cluster":
        # a root mound sending up six curved stalks of different heights, each with a small lit bubble
        _roots(P.a("rib"), (0, 0, 0), 0.6, n=7, reach=1.8, rr=0.16, seed=4)
        lathe(P.a("rib"), (0, 0, 0), [(0.9, -0.3), (0.75, 0.3), (0.45, 0.9), (0.3, 1.3)], n=14)
        tops = []
        for k, (ang, lean, h, br) in enumerate(((0, 1.6, 6.2, 1.15), (70, 2.4, 4.4, 0.85), (140, 1.9, 5.4, 1.0),
                                                 (205, 2.7, 3.3, 0.7), (265, 1.3, 7.2, 0.9), (320, 2.6, 4.8, 0.8))):
            a = math.radians(ang)
            dx, dz = math.cos(a), math.sin(a)
            path = [(0.25 * dx * t + lean * dx * t ** 2.2, 1.0 + (h - 1.0) * t, 0.25 * dz * t + lean * dz * t ** 2.2)
                    for t in [i / 8 for i in range(9)]]
            tube(P.a("rib"), path, lambda t: 0.13 * (1.0 - 0.5 * t), n=7)
            top = path[-1]
            cc = (top[0], top[1] + br * 0.85, top[2])
            core, _ = _pod(P, cc, br, lat0=-62.0, ribs=6 if br < 0.9 else 8, spire=0.0)
            tops.append(core)
        P.boxes = [_box(0, 0, 0.7, 0.7, 0, 3.0)]
        P.composite = False
        P.footprint = _fan(0, 0, 2.6, 12)
        P.hardpoints = [("glow_top", tops[4]), ("glow_core", tops[0])]
    else:
        raise ValueError(f"unknown piece {piece}; pieces: {PIECES}")
    return P


def piece_name(piece, suffix=1):
    return f"nboo_otoh_{piece}_s{suffix:02d}"


LOD_DETAIL = (0.5, 0.25)     # tessellation of the far LODs (l1, l2) relative to the full mesh


def _export_lods(root, name, export_root, piece):
    """Far LODs: rebuild the piece with the primitives' tessellation scaled by LOD_DETAIL (same shapes, UVs and
    hardpoints, far fewer faces), swap the meshes under the root and export thm_<name>_l<k>.apt; write_static_lod
    puts them in the .lod as the far children."""
    global DETAIL
    out = []
    for k, det in enumerate(LOD_DETAIL, start=1):
        DETAIL = det
        try:
            P = build_piece(piece)
        finally:
            DETAIL = 1.0
        for m in cmds.listRelatives("|" + root, children=True, type="transform", fullPath=True) or []:
            if cmds.listRelatives(m, shapes=True, type="mesh"):
                cmds.delete(m)
        for slot, acc in P.acc.items():
            if acc.counts:
                cmds.sets(acc.build(f"{name}_{slot}", "|" + root), edit=True, forceElement=_sg(slot))
        rel = f"appearance/thm_{name}_l{k}.apt"
        cmds.select("|" + root, replace=True)
        mel.eval(f'exportStaticMesh -path "{export_root}/{rel}" -collision none')
        out.append(rel)
    return out


def build(piece, export_root, suffix=1):
    """Build one piece in a fresh scene and export appearance/thm_<name>.apt (+ mesh, its floor for the tube)."""
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    name = piece_name(piece, suffix)
    P = build_piece(piece)
    root = cmds.createNode("transform", name="thm_" + name)
    for slot, acc in P.acc.items():
        if acc.counts:
            cmds.sets(acc.build(f"{name}_{slot}", "|" + root), edit=True, forceElement=_sg(slot))
    for hp, pos in P.hardpoints:
        t = cmds.createNode("transform", name=hp, parent="|" + root)
        cmds.setAttr(t + ".translate", *pos, type="double3")
    flr_rel = None
    if P.walk:
        coll = cmds.createNode("transform", name="collision", parent="|" + root)
        ext = cmds.createNode("transform", name="extent", parent=coll)
        if P.walls.counts:
            P.walls.build("walls", ext)
        fl = pb._facet_mesh(P.walk, "floor", "|" + root + "|collision", up=True)
        cmds.addAttr(fl, longName="swgFloorOpenEdgesCrossable", attributeType="bool")
        cmds.setAttr(fl + ".swgFloorOpenEdgesCrossable", True)
        flr_rel = f"appearance/collision/thm_{name}_collision_floor0.flr"
        os.makedirs(os.path.dirname(f"{export_root}/{flr_rel}"), exist_ok=True)
        cmds.select(fl, replace=True)
        cmds.file(f"{export_root}/{flr_rel}", force=True, exportSelected=True, type="SwgFlr")
        cmds.delete(coll)
    apt = f"{export_root}/appearance/thm_{name}.apt".replace("\\", "/")
    os.makedirs(os.path.dirname(apt), exist_ok=True)
    cmds.select("|" + root, replace=True)
    mel.eval(f'exportStaticMesh -path "{apt}" -collision none')
    bb = cmds.exactWorldBoundingBox("|" + root)
    lods = _export_lods(root, name, export_root, piece)
    return {"name": name, "piece": piece, "apt": f"appearance/thm_{name}.apt", "bounds": [round(v, 3) for v in bb],
            "lods": lods,
            "boxes": [[list(map(float, a)), list(map(float, b))] for a, b in P.boxes],
            "composite": bool(getattr(P, "composite", len(P.boxes) > 1)),
            "footprint": [[list(p) for p in tri] for tri in P.footprint], "floor": flr_rel,
            "hardpoints": [h for h, _ in P.hardpoints], "root": root}


def look():
    """Review renders only (Maya Software ignores the .sht): see-through skins, glowing cores."""
    for n, tr, inc in (("otoh_skin", 0.7, 0.5), ("otoh_shell", 0.45, 0.6), ("otoh_core", 0.0, 1.0), ("otoh_blue", 0.0, 0.6)):
        if cmds.objExists(n):
            cmds.setAttr(n + ".transparency", tr, tr, tr, type="double3")
            c = (1.0, 0.7, 0.3) if cmds.listConnections(n + ".color") else cmds.getAttr(n + ".color")[0]
            cmds.setAttr(n + ".incandescence", *[x * inc for x in c], type="double3")


def preview(gap=3.0):
    """Every piece side by side for a review render (nothing exported)."""
    cmds.file(new=True, force=True)
    x = 0.0
    for piece in PIECES:
        P = build_piece(piece)
        grp = cmds.createNode("transform", name=f"otoh_{piece}")
        for slot, acc in P.acc.items():
            if acc.counts:
                cmds.sets(acc.build(f"{piece}_{slot}", "|" + grp), edit=True, forceElement=_sg(slot))
        bb = cmds.exactWorldBoundingBox("|" + grp)
        cmds.setAttr(f"|{grp}.translateX", x - bb[0])
        x += (bb[3] - bb[0]) + gap
    return {"width": x}


# ---------------------------------------------------------------------------------------------------------------
# the hub (POB)
# ---------------------------------------------------------------------------------------------------------------

HUB_R, HUB_WALL, HUB_DOME = 9.0, 3.2, 7.0
POD_R, POD_WALL, POD_DOME = 4.5, 2.8, 4.2
FLOOR_Y = 0.4
FLAT_HW = 1.8                                    # half-width of the flat wall a doorway sits on
CHORD = math.sqrt(HUB_R ** 2 - FLAT_HW ** 2)     # hub centre -> its flat walls
POD_IN = 12.6                                    # x of the pods' flat walls (tube ends)
POD_CX = POD_IN + math.sqrt(POD_R ** 2 - FLAT_HW ** 2)
FOYER_Z = 12.8
# bubble skins: sphere centre height above the floor, radius from the ground circle
HUB_SKIN = (FLOOR_Y + 2.6, math.sqrt(10.0 ** 2 + (FLOOR_Y + 2.6) ** 2))
POD_SKIN = (FLOOR_Y + 2.2, math.sqrt(5.2 ** 2 + (FLOOR_Y + 2.2) ** 2))
# openings in the skins over the tubes/foyer: an elliptic arch as wide as the pad strip that runs out beside
# them, so walking along the pad never crosses glass (the pad's rim is sealed: make_otoh_gunga.seal_pad)
OPEN_HW, OPEN_LEG, OPEN_RISE = 2.5, 3.6 + FLOOR_Y, 1.8
PAD_MARGIN = 0.6                                 # terrain base margin: the pad stays inside the skins
COLLISION_TOP = 4.2                              # skins are collision from the ground up to here


def circle_with_flats(cx, cz, r, n, flats):
    """Plan polygon of a round room with flat walls for doorways: flats = [angle degrees] (direction from the
    centre), each a chord of half-width FLAT_HW."""
    pts = []
    half = math.degrees(math.asin(FLAT_HW / r))
    fl = [math.radians(a) for a in flats]
    for k in range(n):
        a = 2 * math.pi * (k + 0.5) / n
        if any(abs(math.atan2(math.sin(a - f), math.cos(a - f))) < math.radians(half) + 1e-6 for f in fl):
            continue
        pts.append((cx + r * math.cos(a), cz + r * math.sin(a)))
    for f in fl:
        for s in (-1, 1):
            a = f + s * math.radians(half)
            pts.append((cx + r * math.cos(a), cz + r * math.sin(a)))
    pts.sort(key=lambda p: math.atan2(p[1] - cz, p[0] - cx))
    return [[round(x, 4), round(z, 4)] for x, z in pts]


def hub_spec():
    """pob_build spec: round hall (r 9, glow dome) with a foyer to the south (+z, the entrance) and a tube east
    and west to two domed pods."""
    stone = {"shader": SHADERS["stone"], "uv_scale": 3.0}
    glow = {"shader": SHADERS["veil"]}
    wall_in = {"shader": SHADERS["wall_in"], "uv_scale": 3.0}
    # the mosaic rosette sits on the texture's tile corner: a tile that divides each room centre's x puts it there
    hall_floor = {"shader": SHADERS["mosaic"], "uv_scale": 2 * HUB_R}
    pod_floor = {"shader": SHADERS["mosaic"], "uv_scale": POD_CX / max(1, round(POD_CX / (2 * POD_R)))}
    rib = {"shader": SHADERS["rib"], "uv_scale": 2.0}
    warm = lambda k=1.0: {"ambient": 1.0, "ambient_rgb": [0.55 * k, 0.36 * k, 0.2 * k], "rgb": [1.0, 0.62, 0.3],
                          "intensity": 1.5 * k, "fixtures": False,
                          "parallel": [{"rgb": [0.5, 0.36, 0.22], "dir": [0.2, -1.0, -0.3]},
                                       {"rgb": [0.3, 0.2, 0.12], "dir": [0.0, 1.0, 0.1]}]}
    mats = {"wall": wall_in, "floor": stone, "fixture": {"shader": SHADERS["core"]}}
    hall_mats = dict(mats, floor=hall_floor)
    pod_mats = dict(mats, floor=pod_floor)
    hall = circle_with_flats(0, 0, HUB_R, 32, [0, 90, 180])
    pod = lambda cx, face: circle_with_flats(cx, 0, POD_R, 24, [face])
    rooms = [
        {"name": "hall", "polygon": hall, "floor_y": FLOOR_Y, "height": HUB_WALL, "dome": {"height": HUB_DOME, "rings": 9},
         "materials": hall_mats, "light": warm(1.1), "obstacles": [[-1.0, -1.0, 1.0, 1.0]]},
        {"name": "foyer", "min": [-FLAT_HW, CHORD], "max": [FLAT_HW, FOYER_Z], "floor_y": FLOOR_Y, "height": 3.3,
         "dome": {"height": 1.0, "rings": 4}, "materials": mats, "light": warm(0.9)},
        {"name": "tube_east", "min": [CHORD, -FLAT_HW], "max": [POD_IN, FLAT_HW], "floor_y": FLOOR_Y, "height": 2.9,
         "dome": {"height": 1.0, "rings": 4}, "materials": mats, "light": warm(0.8)},
        {"name": "tube_west", "min": [-POD_IN, -FLAT_HW], "max": [-CHORD, FLAT_HW], "floor_y": FLOOR_Y, "height": 2.9,
         "dome": {"height": 1.0, "rings": 4}, "materials": mats, "light": warm(0.8)},
        {"name": "pod_east", "polygon": pod(POD_CX, 180), "floor_y": FLOOR_Y, "height": POD_WALL,
         "dome": {"height": POD_DOME, "rings": 7}, "materials": pod_mats, "light": warm(1.0)},
        {"name": "pod_west", "polygon": pod(-POD_CX, 0), "floor_y": FLOOR_Y, "height": POD_WALL,
         "dome": {"height": POD_DOME, "rings": 7}, "materials": pod_mats, "light": warm(1.0)},
    ]
    arch = lambda a, b: {"rooms": [a, b], "width": 2.4, "height": 2.7, "style": "arch"}
    return {
        "name": "nboo_otoh_hub",
        "ground_y": 0.0,
        "wall_thickness": 0.35,
        "collision_meshes": True,
        "shell_color": [0.42, 0.3, 0.18],
        "shell_materials": rib,
        "exterior": {"porch": stone, "trim": rib, "dome": glow, "roof": rib},
        "base": {"shader": SHADERS["stone"], "margin": PAD_MARGIN, "flare": 0.6, "depth": 1.2, "ramp_slope": 0.3},
        "trim_materials": rib,
        "rooms": rooms,
        "doors": [arch("hall", "foyer"), arch("hall", "tube_east"), arch("hall", "tube_west"),
                  arch("tube_east", "pod_east"), arch("tube_west", "pod_west")],
        "entrances": [{"room": "foyer", "side": "+z", "width": 2.92, "height": 2.9, "door_style": "door_nboo_filler_s04",
                       "ramp_width": 4.2}],
        "lights": True,
    }


def _faces_above(mesh, y):
    """Face ids of a mesh whose centroid is above y (MFnMesh only: MItMeshPolygon is unsafe on fresh meshes)."""
    import maya.api.OpenMaya as om
    sel = om.MSelectionList()
    sel.add(mesh)
    fn = om.MFnMesh(sel.getDagPath(0))
    pts = fn.getPoints(om.MSpace.kWorld)
    counts, ids = fn.getVertices()
    out, off = [], 0
    for f, n in enumerate(counts):
        if sum(pts[ids[off + k]].y for k in range(n)) / n > y:
            out.append(f)
        off += n
    return out


def _dome_point(cx, cz, rad, base, h, lon, a, inset=0.0):
    f = math.cos(a)
    return (cx + (rad - inset) * f * math.cos(lon), base + (h - inset) * math.sin(a), cz + (rad - inset) * f * math.sin(lon))


def _interior_dome_ribs(A, nodes, cx, cz, rad, base, h, lons, rr):
    for lon in lons:
        L = math.radians(lon)
        path = [_dome_point(cx, cz, rad, base, h, L, math.pi / 2 * k / 16 * 0.97, inset=rr * 1.5) for k in range(17)]
        tube(A, [(path[0][0], base - 0.5, path[0][2])] + path, lambda t: rr * (1.4 - 0.6 * t), n=6)
    for frac in (0.45, 0.8):
        a = math.pi / 2 * frac
        ring = [_dome_point(cx, cz, rad, base, h, math.radians(d), a, inset=rr * 1.5) for d in range(0, 360, 10)]
        tube(A, ring, rr * 0.8, n=6, closed=True)
        for lon in lons:
            nodes.append((_dome_point(cx, cz, rad, base, h, math.radians(lon), a, inset=rr * 2.6), rr * 1.8))


def _hang(A_rib, A_core, A_skin, top, bottom_y, r):
    """A glow pod hanging on a stem from `top` down to bottom_y."""
    c = (top[0], bottom_y + r, top[2])
    tube(A_rib, [top, (top[0], (top[1] + c[1] + r) / 2, top[2]), (c[0], c[1] + r * 0.9, c[2])], 0.035, n=5, caps=False)
    sphere(A_core, c, r * 0.62, nu=12, nv=6)
    sphere(A_skin, c, r, nu=16, nv=8)
    tube(A_rib, [on_sphere(c, r + 0.02, a, 10.0) for a in range(0, 360, 20)], 0.03, n=5, closed=True)


def hub_build():
    spec = hub_spec()
    out = pb.build(spec, new_scene=True)
    return {"root": out["root"], "cells": out["cells"], "portals": len(out["portals"]),
            "rooms": [r["name"] for r in out["rooms"]]}


def hub_interior(root):
    """Inside: the dome faces of each domed room (part of its walls mesh) get the glow shader; interior ribs,
    nodes, the hall's lantern column and hanging glow pods are added to each cell mesh."""
    glow_sg, rib_sg, core_sg, skin_sg, stone_sg = _sg("shell"), _sg("rib"), _sg("core"), _sg("skin"), _sg("stone")
    rooms = {r["name"]: r for r in hub_spec()["rooms"]}
    done = {}
    for i, name in enumerate(["hall", "foyer", "tube_east", "tube_west", "pod_east", "pod_west"], start=1):
        cell = f"{root}|r{i}"
        room = rooms[name]
        top = room["floor_y"] + room["height"]
        walls = f"{cell}|mesh|{name}_walls"
        faces = _faces_above(walls, top + 0.02)
        if faces:
            cmds.sets([f"{walls}.f[{f}]" for f in faces], edit=True, forceElement=glow_sg)
        R, C, S, ST = pb.MeshAccumulator(), pb.MeshAccumulator(), pb.MeshAccumulator(), pb.MeshAccumulator(3.0)
        nodes = []
        if name == "hall":
            _interior_dome_ribs(R, nodes, 0, 0, HUB_R, top, HUB_DOME, [22.5 + 45 * k for k in range(8)], 0.1)
            # lantern column on the floor hole in the middle: plinth, bronze stalk with fingers, glow orb
            lathe(ST, (0, FLOOR_Y, 0), [(0.98, 0.0), (0.98, 0.55), (0.8, 0.7), (0.3, 0.7)], n=20)
            lathe(R, (0, FLOOR_Y, 0), [(0.3, 0.7), (0.2, 1.4), (0.16, 2.3), (0.3, 2.55)], n=10)
            orb = (0.0, FLOOR_Y + 3.1, 0.0)
            sphere(C, orb, 0.5, nu=16, nv=8)
            sphere(S, orb, 0.72, nu=20, nv=10)
            for k in range(5):
                a = 2 * math.pi * k / 5
                tube(R, [(0.22 * math.cos(a), FLOOR_Y + 2.45, 0.22 * math.sin(a)),
                         (0.7 * math.cos(a), FLOOR_Y + 2.9, 0.7 * math.sin(a)),
                         (0.62 * math.cos(a), FLOOR_Y + 3.55, 0.62 * math.sin(a))], lambda t: 0.06 * (1 - 0.6 * t), n=5)
            apex = (0.0, top + HUB_DOME - 0.05, 0.0)
            _hang(R, C, S, apex, FLOOR_Y + 6.0, 0.75)
            for k in range(6):
                a = math.radians(60 * k + 30)
                frac = math.acos(4.6 / HUB_R)
                p = (4.6 * math.cos(a), top + HUB_DOME * math.sin(frac) - 0.1, 4.6 * math.sin(a))
                _hang(R, C, S, p, FLOOR_Y + 3.6 + 0.4 * (k % 2), 0.32)
        elif name.startswith("pod"):
            cx = POD_CX if name == "pod_east" else -POD_CX
            _interior_dome_ribs(R, nodes, cx, 0, POD_R, top, POD_DOME, [45.0 + 90 * k for k in range(4)], 0.08)
            _hang(R, C, S, (cx, top + POD_DOME - 0.05, 0.0), FLOOR_Y + 2.7, 0.5)
        for p, nr in nodes:
            sphere(C, p, nr, nu=8, nv=4)
        grp = f"{cell}|mesh"
        for acc, sg, tag in ((R, rib_sg, "ribs"), (C, core_sg, "glow"), (S, skin_sg, "glass"), (ST, stone_sg, "plinth")):
            if acc.counts:
                cmds.sets(acc.build(f"{name}_{tag}", grp), edit=True, forceElement=sg)
        done[name] = len(faces)
    return {"glow_faces": done}


def _opening(dirn, c_y, R):
    """Arched opening through a bubble skin along plan direction dirn (unit x/z): keep(mid) test + collar path."""
    dx, dz = dirn

    def inside(p):
        along = p[0] * dx + p[2] * dz
        side = -p[0] * dz + p[2] * dx
        if along <= 0:
            return False
        y = p[1]
        return abs(side) < OPEN_HW and (y < OPEN_LEG or ((y - OPEN_LEG) / OPEN_RISE) ** 2 + (side / OPEN_HW) ** 2 < 1.0)
    return inside


def _collar(A, center, R, dirn, hw, leg, rr, rise=OPEN_RISE):
    """Rib frame where an arched opening meets the sphere (center = sphere centre, plan direction dirn)."""
    dx, dz = dirn
    pts = []
    loop = [(-hw, y) for y in [0.0, leg * 0.5, leg]] + \
        [(-hw * math.cos(math.pi * k / 12), leg + rise * math.sin(math.pi * k / 12)) for k in range(1, 12)] + \
        [(hw, y) for y in [leg, leg * 0.5, 0.0]]
    for side, y in loop:
        rel_y = y - center[1]
        along = math.sqrt(max(0.0, R * R - rel_y * rel_y - side * side))
        px, pz = center[0] + dx * along - dz * side, center[2] + dz * along + dx * side
        pts.append((px, y - (0.2 if y == 0.0 else 0.0), pz))
    tube(A, pts, rr, n=7)


def hub_exterior(root):
    """r0: bubble skins (hub, pods) with arched openings over the foyer/tubes, rib lattices, collars, glow nodes,
    a ceremonial rib arch over the entrance and the effect hardpoints."""
    grp = f"{root}|r0|mesh"
    SK, R, C = pb.MeshAccumulator(), pb.MeshAccumulator(), pb.MeshAccumulator()
    hub_c = (0.0, HUB_SKIN[0], 0.0)
    hub_r = HUB_SKIN[1]
    lat0 = -math.degrees(math.asin(hub_c[1] / hub_r)) - 1.5
    opens = [((0.0, 1.0), 90.0), ((1.0, 0.0), 0.0), ((-1.0, 0.0), 180.0)]
    tests = [_opening(d, hub_c[1], hub_r) for d, _ in opens]
    sphere(SK, hub_c, hub_r, lat0, 90.0, nu=64, nv=32, keep=lambda m: not any(t(m) for t in tests), tiles=(6.0, 3.0))
    nodes = []
    tip = bubble_ribs(R, hub_c, hub_r, lat0 + 1.5, meridians=12, lon_offset=15.0, holes=[a for _, a in opens], nodes=nodes,
                      ring_lat=38.0, rib_r=0.14, spire=2.2)
    for d, _ in opens:
        _collar(R, hub_c, hub_r + 0.05, d, OPEN_HW, OPEN_LEG, 0.2)
    pod_tops = []
    for name, cx, d, lon in (("east", POD_CX, (-1.0, 0.0), 180.0), ("west", -POD_CX, (1.0, 0.0), 0.0)):
        c = (cx, POD_SKIN[0], 0.0)
        pr = POD_SKIN[1]
        t = _opening(d, c[1], pr)
        local = lambda m, t=t, cx=cx: t((m[0] - cx, m[1], m[2]))
        plat0 = -math.degrees(math.asin(c[1] / pr)) - 2.0
        sphere(SK, c, pr, plat0, 90.0, nu=40, nv=20, keep=lambda m, local=local: not local(m), tiles=(4.0, 2.0))
        ptip = bubble_ribs(R, c, pr, plat0 + 2.0, meridians=8, lon_offset=22.5, holes=[lon], nodes=nodes, ring_lat=30.0,
                           rib_r=0.1, spire=1.2)
        _collar(R, c, pr + 0.04, d, OPEN_HW, OPEN_LEG, 0.16)
        pod_tops.append((f"glow_pod_{name}", (ptip[0], ptip[1] + 0.3, ptip[2])))
        sphere(C, (ptip[0], ptip[1] + 0.3, ptip[2]), 0.32, nu=12, nv=6)
    for p, nr in nodes:
        sphere(C, p, nr, nu=8, nv=4)
    sphere(C, (tip[0], tip[1] + 0.45, tip[2]), 0.55, nu=16, nv=8)
    sphere(SK, (tip[0], tip[1] + 0.45, tip[2]), 0.85, nu=20, nv=10)
    # entrance: a pointed rib arch over the foyer mouth, glow bulbs on its shoulders
    z = FOYER_Z + 0.25
    for dz in (-0.12, 0.12):
        path = []
        for k in range(25):
            t = k / 24
            x = -2.6 + 5.2 * t
            path.append((x, 5.2 * (1 - abs(2 * t - 1) ** 1.7), z + dz))
        tube(R, path, lambda t: 0.18 * (1.3 - 0.5 * math.sin(math.pi * t)), n=8)
    for x in (-1.6, 1.6):
        sphere(C, (x, 4.15, z + 0.25), 0.22, nu=10, nv=5)
    sphere(C, (0, 5.05, z + 0.25), 0.3, nu=12, nv=6)
    # the glass is solid from outside: a coarse band of each skin (ground to head height, same openings) in r0's
    # collision extent stops anyone on the terrain; the pad's sealed rim stops anyone inside (seal_pad)
    band = pb.MeshAccumulator()
    sphere(band, hub_c, hub_r, lat0, math.degrees(math.asin((COLLISION_TOP - hub_c[1]) / hub_r)), nu=32, nv=16,
           keep=lambda m: not any(t(m) for t in tests))
    for cx, d in ((POD_CX, (-1.0, 0.0)), (-POD_CX, (1.0, 0.0))):
        c, pr = (cx, POD_SKIN[0], 0.0), POD_SKIN[1]
        t = _opening(d, c[1], pr)
        sphere(band, c, pr, -math.degrees(math.asin(c[1] / pr)) - 2.0, math.degrees(math.asin((COLLISION_TOP - c[1]) / pr)),
               nu=24, nv=16, keep=lambda m, t=t, cx=cx: not t((m[0] - cx, m[1], m[2])))
    pb._collision_mesh(band, "bubble_skin_collision", f"{root}|r0|collision")
    for acc, sg, tag in ((SK, _sg("skin"), "bubble_skins"), (R, _sg("rib"), "bubble_ribs"), (C, _sg("core"), "glow_nodes")):
        if acc.counts:
            cmds.sets(acc.build(f"exterior_{tag}", grp), edit=True, forceElement=sg)
    hps = [("glow_top", (tip[0], tip[1] + 0.45, tip[2])), ("bubbles_top", (tip[0], tip[1] + 1.4, tip[2])),
           ("glow_door", (0.0, 5.05, z + 0.6)), ("swarm", (0.0, 9.0, 0.0))] + pod_tops
    for hp, pos in hps:
        t = cmds.createNode("transform", name=hp, parent=grp)
        cmds.setAttr(t + ".translate", *pos, type="double3")
    return {"hardpoints": [h for h, _ in hps], "spire": [round(v, 2) for v in tip]}


def hub_export(root, export_root):
    return pb.export(root, export_root)
