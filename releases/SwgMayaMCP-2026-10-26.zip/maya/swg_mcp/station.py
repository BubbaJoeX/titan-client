"""Orbital station modelled on Nova Orion (thm_spc_nebula_orion_station) — runs inside Maya with SwgMayaEditor.

Nova Orion is a hub-and-spoke station: a round central room on each deck, four halls radiating from it in a cross,
big themed rooms at the ends of the halls (hangars, docking bays, the cantina, medical, cloning, an armory), a
basement deck mirroring the main one, an upper deck reached by a tall elevator shaft. This station keeps that
plan and stacks five decks 8 m apart, each with its own purpose and unique rooms:

  +16  Command      bridge (hub), domed observatory, comms array, captain's quarters, holo-conference, ops offices
   +8  Habitat      atrium (hub), hydroponics bay, mess hall, crew quarters, gym, cabins
    0  Concourse    rotunda (hub), bank & bazaar, docking bay (the entrance), medical + cloning, cantina, shops
   -8  Hangars      cargo hub, two hangar bays, cargo hold, vehicle workshop, storage
  -16  Engineering  reactor (hub), power distribution, life support, droid workshop, armory + brig

Getting around: a lift beside the north hall serves every deck, and straight stairs with landings climb between
each pair of decks along the south hall (alternating sides), so no deck relies on the lift. Functional rooms for
the game: cloning + medical (respawn / healing), bank + bazaar + mission office (terminals), cantina with a stage
(entertainers), docking bay (shuttle / travel), hangars, crafting workshops. Decks below 0 are underground; the
concourse is ground level (y 0) with the docking bay door, ringed by an exterior skirt floor for collision.
All coordinates are Maya space (x, z plan)."""

from __future__ import annotations

import math

import maya.cmds as cmds

from . import pob_builder as pb
from . import filler_plan as FP

DECKS = [-16.0, -8.0, 0.0, 8.0, 16.0]
DECK_H = 6.0                     # rooms per deck (8 m deck spacing leaves the slab + services)
HUB_R = 12.0
HALL_W, HALL_END = 6.0, 32.0     # halls from the hub's flat edge out to u = 32
SKIRT = 6.0

SP = lambda n: "shader/" + n + ".sht"


def _mat(wall, floor, ceiling, trim):
    return {"wall": {"shader": SP(wall)}, "floor": {"shader": SP(floor)}, "ceiling": {"shader": SP(ceiling)},
            "trim": {"shader": SP(trim)}, "fixture": {"shader": SP("spaceport_luma_lightstrip2_cs8")}}


# coherent families (one stock interior family each, never mixed within a room)
PAL = {
    "tech": _mat("spaceport_metl_panel3_cs8", "intr_tech_floor_c_cs8", "intr_tech_ceilingb_cs8", "spaceport_metl_trim_cs8"),
    "tech_b": _mat("spaceport_metl_panel5_cs8", "intr_tech_floor_c_cs8", "intr_tech_ceilingb_cs8", "spaceport_metl_base_cs8"),
    "med": _mat("intr_medicalwall_tech_b_cd8", "hospital_floor_grey_cd8_phong", "hospital_ceiling_a_cd8", "intr_tech_trimb_cs8"),
    "industrial": _mat("despot_tech_wall_cs9", "despot_metl_floor_panel3_cs9", "despot_intr_ceiling_a1_cs9", "despot_metl_trim_cs9"),
    "lounge": _mat("z_intr_assoc_wall_gloss_ces17", "intr_cptl_floor_cs8", "intr_hotel_ceiling_a1_cs8", "intr_hoteltrim_cs8"),
    "cantina": _mat("corl_stco_cantina_wall_fallback_c2d13", "corl_metl_cantina_floor_cds16", "z_intr_tech_ceilinga_cs8",
                    "corl_stco_cantina_trim_cs8"),
    "hangar": _mat("spaceport_metl_panel5_cs8", "floor_garage_floor_02", "intr_tech_ceilinga_cs8", "spaceport_metl_base_cs8"),
}
LIGHT = dict(FP.ROLE_LIGHT)
LIGHT.update({"bridge": {"ambient": 1.0, "ambient_rgb": (0.30, 0.34, 0.42), "rgb": (0.75, 0.9, 1.0), "intensity": 1.1},
              "reactor": {"ambient": 1.0, "ambient_rgb": (0.25, 0.30, 0.38), "rgb": (0.6, 0.85, 1.0), "intensity": 1.3},
              "hangar": {"ambient": 1.0, "ambient_rgb": (0.34, 0.36, 0.40), "rgb": (0.95, 0.97, 1.0), "intensity": 1.3},
              "hydroponics": {"ambient": 1.0, "ambient_rgb": (0.32, 0.40, 0.30), "rgb": (0.85, 1.0, 0.8), "intensity": 1.2}})

# deck programme: hub, the four hall-end rooms (N, E, S, W) and the side rooms along the halls
# end room: (name, role, palette, (half width, depth), extras)
DECK_PLAN = {
    16.0: {"name": "command", "hub": ("bridge", "bridge", "tech", {"windows": True}),
           "ends": {"N": ("observatory", "lounge", "lounge", (8, 14), {"dome": True, "windows": True}),
                    "E": ("comms", "office", "tech", (8, 12), {"windows": True}),
                    "S": ("captain", "bedroom", "lounge", (8, 12), {"windows": True}),
                    "W": ("holo_conference", "office", "tech_b", (8, 12), {"windows": True})},
           "side": ("ops_office", "office", "tech")},
    8.0: {"name": "habitat", "hub": ("atrium", "lobby", "lounge", {"windows": True}),
          "ends": {"N": ("hydroponics", "hydroponics", "tech_b", (14, 20), {"windows": True}),
                   "E": ("mess_hall", "kitchen", "lounge", (10, 16), {"windows": True}),
                   "S": ("crew_quarters", "bedroom", "lounge", (10, 14), {"windows": True}),
                   "W": ("gym", "workshop", "tech", (10, 14), {"windows": True})},
          "side": ("cabin", "bedroom", "lounge")},
    0.0: {"name": "concourse", "hub": ("rotunda", "lobby", "tech", {}),
          "ends": {"N": ("bank_bazaar", "shop", "lounge", (12, 16), {}),
                   "E": ("docking_bay", "hangar", "hangar", (14, 22), {"entrance": True}),
                   "S": ("medical_cloning", "bath", "med", (12, 16), {}),
                   "W": ("cantina", "cantina", "cantina", (12, 18), {"stage": True})},
          "side": ("shop", "shop", "tech")},
    -8.0: {"name": "hangars", "hub": ("cargo_hub", "storage", "industrial", {}),
           "ends": {"N": ("cargo_hold", "storage", "industrial", (12, 18), {}),
                    "E": ("hangar_bay_a", "hangar", "hangar", (16, 24), {}),
                    "S": ("vehicle_workshop", "workshop", "industrial", (10, 14), {}),
                    "W": ("hangar_bay_b", "hangar", "hangar", (16, 24), {})},
           "side": ("storage", "storage", "industrial")},
    -16.0: {"name": "engineering", "hub": ("reactor", "reactor", "industrial", {}),
            "ends": {"N": ("power_distribution", "workshop", "industrial", (10, 14), {}),
                     "E": ("life_support", "workshop", "tech_b", (10, 14), {}),
                     "S": ("droid_workshop", "workshop", "industrial", (10, 14), {}),
                     "W": ("armory_brig", "office", "tech", (10, 14), {})},
            "side": ("maintenance", "storage", "industrial")},
}

# hall direction -> local (u outward, v across) to world plan
DIRS = {"N": lambda u, v: (v, u), "E": lambda u, v: (u, -v), "S": lambda u, v: (-v, -u), "W": lambda u, v: (-u, v)}


def lrect(d, u0, u1, v0, v1):
    """World plan rectangle polygon (CCW) of the local box u0..u1 x v0..v1 along hall direction d."""
    pts = [DIRS[d](u, v) for u, v in ((u0, v0), (u1, v0), (u1, v1), (u0, v1))]
    xs, zs = [p[0] for p in pts], [p[1] for p in pts]
    x0, x1, z0, z1 = min(xs), max(xs), min(zs), max(zs)
    return [[x0, z0], [x1, z0], [x1, z1], [x0, z1]]


class Plan:
    def __init__(self):
        self.rooms, self.doors, self.entrances = [], [], []

    def room(self, name, poly, role, pal, fy, h=DECK_H, **extra):
        r = {"name": name, "polygon": poly, "floor_y": fy, "height": h, "materials": PAL[pal],
             "light": dict(LIGHT.get(role, LIGHT["hall"]))}
        r.update(extra)
        self.rooms.append(r)
        return name

    def link(self, a, b, y, width=2.4, style="open", near=None):
        d = {"rooms": [a, b], "width": width, "height": 3.2, "style": style, "y": y}
        if style == "door":
            d["door_style"] = "door_corl_metal_s01"
        if near is not None:
            d["near"] = list(near)
        self.doors.append(d)


def plan():
    P = Plan()
    flat = HUB_R * math.cos(math.pi / 16)            # the hub's flat edges (16 sides) face +-x / +-z
    lift_levels = DECKS[1:]
    lift = P.room("lift", lrect("N", 14.0, 20.0, -9.0, -3.0), "lift", "tech_b", DECKS[0],
                  h=DECKS[-1] - DECKS[0] + DECK_H, levels=lift_levels, elevator=True)
    for y in DECKS:
        prog = DECK_PLAN[y]
        tag = prog["name"]
        hname, hrole, hpal, hextra = prog["hub"]
        hub = P.room(f"{tag}_{hname}", None, hrole, hpal, y, round={"center": [0.0, 0.0], "radius": HUB_R, "segments": 16},
                     **({"windows": {"auto": True, "width": 2.2, "height": 2.0, "sill": 1.0, "spacing": 3.0}}
                        if hextra.get("windows") and y > 0 else {}))
        P.rooms[-1].pop("polygon")
        for d in "NESW":
            hall = P.room(f"{tag}_hall_{d.lower()}", lrect(d, flat, HALL_END, -HALL_W / 2, HALL_W / 2), "corridor", "tech", y)
            P.link(hub, hall, y, width=3.0, near=DIRS[d](flat, 0.0))
            ename, erole, epal, (hw, depth), ex = prog["ends"][d]
            extra = {}
            if ex.get("windows") and y > 0:
                extra["windows"] = {"auto": True, "width": 2.2, "height": 2.2, "sill": 0.9, "spacing": 3.2}
            if ex.get("dome"):
                extra["dome"] = {"height": 1.8, "rings": 5}
            end = P.room(f"{tag}_{ename}", lrect(d, HALL_END, HALL_END + depth, -hw, hw), erole, epal, y,
                         h=7.0 if erole == "hangar" and y < 0 else DECK_H, **extra)
            P.link(hall, end, y, width=4.0 if erole == "hangar" else 3.0, style="open" if erole != "bedroom" else "door",
                   near=DIRS[d](HALL_END, 0.0))
            if ex.get("stage"):                     # cantina: stage across the far wall, ramp toward the hall
                fx, fz = DIRS[d](HALL_END + depth - 2.0, 0.0)
                sx, sz = DIRS[d](0.0, hw - 2.0)
                (ax, az), (bx, bz) = DIRS[d](HALL_END + depth - 3.4, -(hw - 2.5)), DIRS[d](HALL_END + depth - 0.6, hw - 2.5)
                ramp_side = {"N": "-z", "S": "+z", "E": "-x", "W": "+x"}[d]
                P.rooms[-1]["stages"] = [{"min": [min(ax, bx), min(az, bz)], "max": [max(ax, bx), max(az, bz)], "height": 0.6,
                                          "ramp": {"side": ramp_side, "width": 1.6, "length": 1.8}}]
            if ex.get("entrance"):                  # the docking bay doors open onto the landing apron outside
                P.entrances.append({"room": end, "side": {"N": "+z", "E": "+x", "S": "-z", "W": "-x"}[d],
                                    "width": 4.2, "height": 4.0, "door_style": "door_corl_metal_s04", "door_hardpoint": True})
            # side rooms along the hall (not where the lift / stairs stand)
            sname, srole, spal = prog["side"]
            slots = []
            if d == "N":
                slots = [(14.0, 23.0, 3.0, 11.0), (23.0, HALL_END, 3.0, 11.0), (20.0, HALL_END, -11.0, -3.0)]
            elif d in ("E", "W"):
                slots = [(14.0, 23.0, 3.0, 11.0), (23.0, HALL_END, 3.0, 11.0), (14.0, 23.0, -11.0, -3.0),
                         (23.0, HALL_END, -11.0, -3.0)]
            for k, (u0, u1, v0, v1) in enumerate(slots):
                sr = P.room(f"{tag}_{sname}_{d.lower()}{k + 1}", lrect(d, u0, u1, v0, v1), srole, spal, y)
                P.link(hall, sr, y, width=1.8, style="door" if srole in ("bedroom", "office") else "open",
                       near=DIRS[d]((u0 + u1) / 2, 3.0 if v0 > 0 else -3.0))
        P.link(lift, f"{tag}_hall_n", y, width=2.4, near=DIRS["N"](17.0, -3.0))
    # stairs between every pair of decks along the south hall, alternating sides so the flights never stack
    for k in range(len(DECKS) - 1):
        y0, y1 = DECKS[k], DECKS[k + 1]
        side = 1.0 if k % 2 == 0 else -1.0
        v0, v1 = (3.0, 9.0) if side > 0 else (-9.0, -3.0)
        t0, t1 = DECK_PLAN[y0]["name"], DECK_PLAN[y1]["name"]
        low = P.room(f"stair{k + 1}_bottom", lrect("S", 14.0, 17.0, v0, v1), "corridor", "tech", y0, h=4.0)
        dx, dz = DIRS["S"](1.0, 0.0)
        flight = P.room(f"stair{k + 1}", lrect("S", 17.0, 29.0, v0, v1), "corridor", "tech", y0, h=y1 + 3.5 - y0,
                        slope={"dir": [dx, dz], "y_min": y0, "y_max": y1, "steps": True, "ceiling_y": y1 + 3.5})
        high = P.room(f"stair{k + 1}_top", lrect("S", 29.0, 32.0, v0, v1), "corridor", "tech", y1, h=4.0)
        vh = 3.0 if side > 0 else -3.0
        P.link(f"{t0}_hall_s", low, y0, width=2.2, near=DIRS["S"](15.5, vh))
        P.link(low, flight, y0, width=2.4, near=DIRS["S"](17.0, (v0 + v1) / 2))
        P.link(flight, high, y1, width=2.4, near=DIRS["S"](29.0, (v0 + v1) / 2))
        P.link(high, f"{t1}_hall_s", y1, width=2.2, near=DIRS["S"](30.5, vh))
    return P


def spec_from(P, name):
    return {
        "name": name, "rooms": P.rooms, "doors": P.doors, "entrances": P.entrances, "lights": True, "trim": True,
        "flat_terrain": True, "ground_y": 0.0, "collision_meshes": True, "window_portals": True, "wall_thickness": 0.35,
        "shell_materials": {"shader": SP("all_metal_streaked_ads16")},
        "trim_materials": {"shader": SP("spaceport_metl_trim_cs8")},
        "exterior": {"roof": {"shader": SP("all_roof_a_ads16")}, "trim": {"shader": SP("all_trim_c_asb13")},
                     "window": {"color": (0.5, 0.6, 0.75)}},
        "shell_color": (0.6, 0.62, 0.66),
    }


def skirt(root, spec, entrances):
    """r0 floor ring round the ground-level outline (SKIRT m wide, y 0): its inner edge on the wall foot stops the
    player at the hull (floors, not meshes, collide), the docking bay doorway edge carries the entrance portal,
    the outer rim is crossable onto the terrain."""
    ground = [r for r in spec["rooms"] if abs(r["floor_y"]) < 0.05 and not r["slope"]]     # spec: normalized
    loops = pb._building_outline(ground)
    outer_loop = max(loops, key=lambda l: abs(pb._area(l)))
    jambs = []
    for e in entrances:
        edge, uc, w = e["edge"], e["uc"], e["w"]
        jambs += [edge.at(uc - w / 2), edge.at(uc + w / 2)]
    inner = pb._insert_points(outer_loop, jambs)
    outer = pb._offset_clean(outer_loop, SKIRT)
    ring3 = lambda ring: [(p[0], 0.0, p[1]) for p in ring]
    m = pb._facet_mesh([(ring3(outer), [ring3(inner)])], "station_skirt", f"{root}|r0|collision|floor0", up=True)
    cmds.sets(m, edit=True, forceElement="initialShadingGroup")
    pb._hide_helper(m)
    return m


def build(name="titan_orbital_station", export_root="D:/exported"):
    cmds.file(new=True, force=True)
    P = plan()
    spec = spec_from(P, name)
    out = pb.build(spec, new_scene=False)
    root = out["root"]
    # the entrance info the builder used (edge, centre, width) for the skirt's door jambs
    norm = pb._normalize(spec)
    ents = []
    for e in norm["entrances"]:
        room = pb._room(norm["rooms"], e["room"])
        want = pb.SIDES[e.get("side", "+z")]
        ei = max(range(len(room["poly"])), key=lambda i: pb._dot2(pb.Edge(room, i).n_out, want) + pb.Edge(room, i).length * 1e-3)
        edge = pb.Edge(room, ei)
        ents.append({"edge": edge, "uc": edge.length / 2, "w": float(e.get("width", pb.DEFAULT_DOOR[0]))})
    skirt(root, norm, ents)
    exp = pb.export(root, export_root, name)
    return {"root": root, "cells": out["cells"], "rooms": len(P.rooms), "portals": len(out["portals"]), "export": exp,
            "decks": [DECK_PLAN[y]["name"] for y in DECKS]}
