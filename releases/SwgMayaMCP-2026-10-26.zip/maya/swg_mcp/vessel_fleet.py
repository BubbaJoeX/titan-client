"""More boardable POB vessels (Titan), built on the stock ship POBs the way vessels.py builds the transport and the
yacht: the Lambda shuttle, the player Corellian corvette (extended) and the Nebulon-B frigate.

Each one is a POB ShipObject parked on the ground: r0 is the stock hull (its paint shaders swapped for the
two-zone hue shaders of examples/vessel_paint.py, so owners can repaint it), the boarding ramp is an open-air cell
whose floor is the lowered ramp surface, and the ramp, landing legs and (on the Lambda) the wings are hp_dyn parts
on r0 hardpoints that the client animates (TangibleObject::applyDynamicHardpointsState). Everything is built in the
stock POB frame (Maya space, X mirrored against the engine); `landed` in the result places that frame above the
ground point under the vessel.

Scale: the stock SWG hulls are kept. Their interiors are cut to the player (2.6-3.5 m decks), and the hulls keep
the films' proportions among themselves (Lambda 26 m, corvette 263 m, Nebulon-B 472 m: the SWG space scale).

Build stages are separate maya_python calls (long single calls have crashed Maya); build_<ship> chains them.
"""

from __future__ import annotations

import contextlib
import json
import math
import os
import sys

import maya.cmds as cmds
import maya.mel as mel
import maya.api.OpenMaya as om

from . import pob_builder as pb
from . import vessels as vs

DATA = vs.DATA
EXPORT = os.environ.get("TITAN_EXPORT_ROOT", "D:/exported").replace("\\", "/")
QUIET_LOG = os.path.join(os.environ.get("TEMP", "C:/Temp"), "swg_vessel_fleet_import.log")

# open-air ramp wells and landing legs (a_ shaders: lit by the cell / world lights)
FLEET_MATERIALS = {
    "well": ("shader/all_metl_impl_gate_solid_ads16.sht", (0.35, 0.35, 0.37), 2.0),     # lit: c_ shaders need vertex colours
    "trim": ("shader/all_metl_impl_trim_ads16.sht", (0.30, 0.30, 0.32), 1.2),
    "metal": ("shader/all_metal_streaked_ads16.sht", (0.6, 0.6, 0.6), 1.0),
    "grate": ("shader/asteroid_grate01_as8.sht", (0.45, 0.45, 0.45), 1.0),
    "glass": (vs.GLASS, (0.55, 0.68, 0.78), 1.0),
}


@contextlib.contextmanager
def quiet():
    """Send the plug-in's console chatter (it writes straight to the process stdout / stderr) to QUIET_LOG."""
    for s in (sys.stdout, sys.stderr):
        try:
            s.flush()
        except Exception:
            pass
    fd = os.open(QUIET_LOG, os.O_WRONLY | os.O_CREAT | os.O_APPEND)
    saved = os.dup(1), os.dup(2)
    os.dup2(fd, 1)
    os.dup2(fd, 2)
    try:
        yield
    finally:
        for s in (sys.stdout, sys.stderr):
            try:
                s.flush()
            except Exception:
                pass
        os.dup2(saved[0], 1)
        os.dup2(saved[1], 2)
        for f in (fd, *saved):
            os.close(f)


def _paint(ship):
    path = f"{EXPORT}/build/titan_{ship}_paint.json"
    if not os.path.isfile(path):
        raise RuntimeError(f"{path} missing: run examples/vessel_paint.py {ship} first (the hue .sht must exist)")
    with open(path) as f:
        return json.load(f)


def import_stock_pob(pob, name):
    """The stock POB renamed `name`, every cell mesh right side out (the importer mirrors X without reversing
    triangles). Returns the root."""
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    before = set(cmds.ls(assemblies=True, long=True))
    with quiet():
        cmds.file(os.path.join(DATA, pob), i=True, type="SwgPob", ignoreVersion=True)
    new = [n for n in cmds.ls(assemblies=True, long=True) if n not in before and cmds.objExists(n + "|r0")]
    root = cmds.ls(cmds.rename(new[0], name), long=True)[0]
    for cell in cmds.listRelatives(root, children=True, fullPath=True) or []:
        shapes = cmds.listRelatives(cell + "|mesh", allDescendents=True, type="mesh", fullPath=True) or []
        for shape in shapes:
            cmds.polyNormal(shape, normalMode=0, userNormalMode=0, constructionHistory=False)
        mark_uv_direct(shapes)
    return root


mark_uv_direct = vs.mark_uv_direct


def _shape_stock_shader(shape):
    """The stock shader name (no path / extension) an imported shape carries: the importer names SGs
    <shader>__m__m<n>SG."""
    for sg in cmds.listConnections(shape, type="shadingEngine") or []:
        if cmds.attributeQuery("swgShaderPath", node=sg, exists=True):
            p = cmds.getAttr(sg + ".swgShaderPath") or ""
            if p:
                return os.path.splitext(os.path.basename(p.replace("\\", "/")))[0]
        short = sg.split(":")[-1]
        if "__m__m" in short:
            return short.split("__m__m")[0]
    return ""


def swap_shaders(nodes, swap, prefix):
    """Reassign every mesh under nodes whose stock shader is a key of `swap` ({stock .sht: new .sht}) to a material
    exporting the new shader. Returns {new shader: shape count}."""
    by_name = {os.path.splitext(os.path.basename(k))[0]: v for k, v in swap.items()}
    sgs, done = {}, {}
    for node in nodes:
        for shape in cmds.listRelatives(node, allDescendents=True, type="mesh", fullPath=True) or []:
            if cmds.getAttr(shape + ".intermediateObject"):
                continue
            new = by_name.get(_shape_stock_shader(shape))
            if not new:
                continue
            if new not in sgs:
                stem = os.path.splitext(os.path.basename(new))[0]
                sgs[new] = pb._material(f"{prefix}_{stem}", (0.8, 0.8, 0.8), shader=new)
            cmds.sets(shape, edit=True, forceElement=sgs[new])
            done[new] = done.get(new, 0) + 1
    for shape_sg in sgs.values():                      # they hold stock faces only: export their UVs as stored
        if not cmds.attributeQuery("swgExportUvDirect", node=shape_sg, exists=True):
            cmds.addAttr(shape_sg, longName="swgExportUvDirect", attributeType="bool")
        cmds.setAttr(shape_sg + ".swgExportUvDirect", True)
    return done


def enable_r0_portals(root):
    """Stock ship POBs disable the r0 side of their window portals (no seeing in): enable them."""
    n = 0
    for p in cmds.listRelatives(root + "|r0|portals", children=True, fullPath=True) or []:
        if cmds.attributeQuery("portalDisabled", node=p, exists=True) and cmds.getAttr(p + ".portalDisabled"):
            cmds.setAttr(p + ".portalDisabled", False)
            n += 1
    return n


def _floor_up(cell):
    """The exporter expects floor triangles facing up: flip any floor shape whose first face points down."""
    flipped = 0
    for shape in cmds.listRelatives(cell + "|collision|floor0", allDescendents=True, type="mesh", fullPath=True) or []:
        sel = om.MSelectionList()
        sel.add(shape)
        fn = om.MFnMesh(sel.getDagPath(0))
        if fn.numPolygons and fn.getPolygonNormal(0, om.MSpace.kWorld).y < 0:
            cmds.polyNormal(shape, normalMode=0, userNormalMode=0, constructionHistory=False)
            flipped += 1
    return flipped


def belly_y(hull_tris, x, z, y0=-40.0):
    """Lowest hull surface above (x, y0, z)."""
    h = vs.ray_hits(hull_tris, (x, y0, z), (0.0, 1.0, 0.0))
    return y0 + h[0] if h else None


def _hp_rows(p):
    """Identity hardpoint at Maya point p, as engine rows (X mirrored)."""
    return [[1.0, 0.0, 0.0, -p[0]], [0.0, 1.0, 0.0, p[1]], [0.0, 0.0, 1.0, p[2]]]


def export_mesh_part(name, msh_rel, swap=None, export_root=EXPORT):
    """A stock mesh re-exported as appearance/<name>.apt with its shaders swapped (hue variants of ship parts)."""
    for old in cmds.ls("|" + name, long=True) or []:
        cmds.delete(old)
    before = set(cmds.ls(assemblies=True, long=True))
    with quiet():
        cmds.file(os.path.join(DATA, msh_rel), i=True, type="SwgMsh")
    new = [n for n in cmds.ls(assemblies=True, long=True) if n not in before]
    shapes = cmds.listRelatives(new, allDescendents=True, type="mesh", fullPath=True) or []
    for shape in shapes:
        cmds.polyNormal(shape, normalMode=0, userNormalMode=0, constructionHistory=False)
    mark_uv_direct(shapes)
    grp = cmds.group(new, name=name)
    swapped = swap_shaders([grp], swap or {}, name)
    apt = f"{export_root}/appearance/{name}.apt"
    cmds.select("|" + name, replace=True)
    with quiet():
        mel.eval(f'exportStaticMesh -path "{apt}" -collision none')
    cmds.delete("|" + name)
    return {"apt": f"appearance/{name}.apt", "swapped": swapped}


def paint_lods(name, stock_lod_rel, swap, export_root=EXPORT):
    """The stock distance LODs of a hull, re-exported with the paint shaders (a repainted ship keeps its colours out
    to the horizon). Returns {stock child path in the .lod: our child path} for make_titan_vessels' .lod writer."""
    import re
    with open(os.path.join(DATA, stock_lod_rel), "rb") as f:
        kids = sorted(set(m.decode() for m in re.findall(rb"mesh/[a-z0-9_]+\.msh", f.read())))
    out = {}
    for k, rel in enumerate(kids):
        stem = f"{name}_lod{k}"
        export_mesh_part(stem, "appearance/" + rel, swap, export_root)
        out[rel] = f"mesh/{stem}.msh"
    return out


def hull_collision_boxes(root, dz, dy, merge_tol=1.0, pad=0.05):
    """Solid collision boxes for a hull (Maya space), so players on the terrain can't walk through it: hull surface
    points are binned into z slices and height layers, each bin's x span becomes a box (the hull's inside fills it),
    then boxes merge up the layers and along the slices where their spans agree within merge_tol."""
    tris = vs.tri_list([root + "|r0|mesh"])
    step = min(dz, dy) / 2.0
    bins = {}
    for a, b, c in tris:
        longest = max(math.dist(a, b), math.dist(b, c), math.dist(c, a))
        n = max(1, int(math.ceil(longest / step)))
        for i in range(n + 1):
            for j in range(n + 1 - i):
                u, v = i / n, j / n
                w = 1.0 - u - v
                p = tuple(a[k] * w + b[k] * u + c[k] * v for k in range(3))
                key = (int(math.floor(p[2] / dz)), int(math.floor(p[1] / dy)))
                e = bins.get(key)
                if e is None:
                    bins[key] = [p[0], p[0], p[1], p[1], p[2], p[2]]
                else:
                    e[0], e[1] = min(e[0], p[0]), max(e[1], p[0])
                    e[2], e[3] = min(e[2], p[1]), max(e[3], p[1])
                    e[4], e[5] = min(e[4], p[2]), max(e[5], p[2])
    close = lambda p, q, i: abs(p[i] - q[i]) <= merge_tol and abs(p[i + 1] - q[i + 1]) <= merge_tol
    # up the layers within each slice
    columns = {}
    for (iz, iy), e in sorted(bins.items()):
        col = columns.setdefault(iz, [])
        if col and col[-1][1] == iy - 1 and close(col[-1][0], e, 0):
            p = col[-1][0]
            col[-1] = ([min(p[0], e[0]), max(p[1], e[1]), min(p[2], e[2]), max(p[3], e[3]), min(p[4], e[4]),
                        max(p[5], e[5])], iy)
        else:
            col.append((list(e), iy))
    # along the slices: a box continues into the next slice when its x and y spans agree
    boxes = []
    open_boxes = []
    for iz in sorted(columns):
        nxt = []
        for e, _ in columns[iz]:
            m = next((o for o in open_boxes if o[1] == iz - 1 and close(o[0], e, 0) and close(o[0], e, 2)), None)
            if m:
                open_boxes.remove(m)
                p = m[0]
                nxt.append(([min(p[0], e[0]), max(p[1], e[1]), min(p[2], e[2]), max(p[3], e[3]), min(p[4], e[4]),
                             max(p[5], e[5])], iz))
            else:
                nxt.append((list(e), iz))
        boxes += [o[0] for o in open_boxes]
        open_boxes = nxt
    boxes += [o[0] for o in open_boxes]
    return [((e[0] - pad, e[2] - pad, e[4] - pad), (e[1] + pad, e[3] + pad, e[5] + pad)) for e in boxes
            if e[1] - e[0] > 0.05 or e[3] - e[2] > 0.05]


HEADROOM = 2.0          # hull boxes starting higher than this over the ground are walked under, not into


def box_extent(boxes):
    """[x min, x max, z min, z max] over boxes (Maya space): the hull's plan, for the deed's landing-pad check."""
    return [min(b[0][0] for b in boxes), max(b[1][0] for b in boxes), min(b[0][2] for b in boxes), max(b[1][2] for b in boxes)]


def landed_collision(boxes, ground_y, legs, headroom=HEADROOM):
    """The landed hull's walker collision: hull boxes that reach down within `headroom` of the ground (a walker
    passes under the rest, e.g. to the ramp foot), plus a post per deployed leg from the ground to its hinge.
    legs: the parts' "legs" info ({slot: {"hp": (x, y, z), "pad": footpad radius, ...}})."""
    kept = [b for b in boxes if b[0][1] <= ground_y + headroom]
    posts = []
    for leg in legs.values():
        (x, y, z), r = leg["hp"], leg["pad"]
        posts.append(((x - r, ground_y, z - r), (x + r, y, z + r)))
    return kept + posts


# Landing gear materials: lit (a_) shaders only - the c_ blacksun transport frame / trim are prelit and render black
# without vertex colours. (shader, Maya swatch colour, metres per texture tile)
GEAR_MATERIALS = {
    "gear_frame": ("shader/all_metl_impl_trim_ads16.sht", (0.55, 0.56, 0.58), 1.2),       # bolted blocks, bands
    "gear_strut": ("shader/all_metl_impl_gate_solid_ads16.sht", (0.62, 0.62, 0.62), 2.0),  # painted cylinders, braces
    "gear_chrome": ("shader/all_statue_grey_ads16.sht", (0.8, 0.8, 0.82), 0.8),            # polished oleo piston
    "gear_dark": ("shader/black_melee_as9.sht", (0.15, 0.16, 0.2), 1.0),                    # pads, links, lines
}


def _rod(F, key, a, b, radius, sides=8):
    """A closed prism from point a to point b."""
    d = tuple(b[i] - a[i] for i in range(3))
    n = math.sqrt(sum(c * c for c in d))
    if n > 1e-6:
        vs._prism(F, key, a, tuple(c / n for c in d), n, radius, sides=sides)


def _gear_faces(length, scale, pad):
    """An oleo landing leg in the style of the stock JTL / YT-1300 gear, modelled stowed along +z from its hinge
    (origin); deploying turns it 90 deg about x (stowed +z -> down, stowed +y -> forward along the belly):
      trunnion and yoke at the hinge, painted upper cylinder with two bands and a gland nut, two hydraulic lines,
      polished piston, scissor torque links, a twin drag brace from mid-leg up to a belly mount ahead of the leg
      (stowed it folds up into the hull), and an articulated foot: ankle clevis, ribbed upper plate, dark sole.
    The sole's underside is at `length` (the ground when deployed)."""
    F = vs.Faces(GEAR_MATERIALS)
    s = scale
    fwd = (0.0, 0.0, 1.0)
    sole = length - 0.12 * s                                     # sole plate from here to `length`
    ankle = sole - 0.3 * s
    # hinge: trunnion across x and the yoke cheeks holding the cylinder
    vs._prism(F, "gear_frame", (-0.42 * s, 0.0, 0.0), (1.0, 0.0, 0.0), 0.84 * s, 0.17 * s, sides=12)
    for sx in (-1.0, 1.0):
        _rod(F, "gear_frame", (sx * 0.27 * s, 0.0, -0.05 * s), (sx * 0.27 * s, 0.0, 0.42 * s), 0.08 * s, sides=4)
    # upper cylinder, bands, gland nut
    upper = length * 0.55
    vs._prism(F, "gear_strut", (0.0, 0.0, 0.0), fwd, upper, 0.19 * s, sides=14)
    for z in (0.12 * length, upper - 0.14 * s):
        vs._prism(F, "gear_frame", (0.0, 0.0, z), fwd, 0.12 * s, 0.215 * s, sides=14)
    vs._prism(F, "gear_dark", (0.0, 0.0, upper), fwd, 0.07 * s, 0.205 * s, sides=14)
    # hydraulic lines down the cylinder's sides, into the gland nut
    for sx in (-1.0, 1.0):
        _rod(F, "gear_dark", (sx * 0.23 * s, 0.03 * s, 0.05 * s), (sx * 0.23 * s, 0.03 * s, upper - 0.02 * s),
             0.028 * s, sides=6)
    # polished piston down to the ankle
    vs._prism(F, "gear_chrome", (0.0, 0.0, upper + 0.07 * s), fwd, ankle - upper - 0.07 * s, 0.12 * s, sides=14)
    # scissor torque links on the back (-y stowed = aft deployed)
    knee = (0.0, -0.36 * s, (upper + ankle) / 2.0)
    _rod(F, "gear_dark", (0.0, -0.17 * s, upper - 0.1 * s), knee, 0.045 * s, sides=6)
    _rod(F, "gear_dark", knee, (0.0, -0.1 * s, ankle - 0.05 * s), 0.045 * s, sides=6)
    vs._prism(F, "gear_frame", (-0.07 * s, knee[1], knee[2]), (1.0, 0.0, 0.0), 0.14 * s, 0.06 * s, sides=8)
    # twin drag brace: mid-leg collar to a belly mount 0.45 x length ahead (stowed: up into the hull)
    brace_at, mount = length * 0.42, length * 0.45
    vs._prism(F, "gear_frame", (0.0, 0.0, brace_at - 0.06 * s), fwd, 0.12 * s, 0.24 * s, sides=12)
    for sx in (-1.0, 1.0):
        _rod(F, "gear_strut", (sx * 0.16 * s, 0.1 * s, brace_at), (sx * 0.16 * s, mount, 0.0), 0.055 * s, sides=8)
    vs._prism(F, "gear_frame", (-0.26 * s, mount - 0.08 * s, -0.08 * s), (1.0, 0.0, 0.0), 0.52 * s, 0.1 * s, sides=8)
    # foot: ankle clevis, ribbed upper plate, dark sole
    vs._prism(F, "gear_frame", (-0.18 * s, 0.0, ankle), (1.0, 0.0, 0.0), 0.36 * s, 0.11 * s, sides=10)
    vs._prism(F, "gear_frame", (0.0, 0.0, ankle), fwd, sole - ankle - 0.06 * s, 0.16 * s, sides=10)
    vs._prism(F, "gear_frame", (0.0, 0.0, sole - 0.06 * s), fwd, 0.06 * s, pad * 0.82, sides=16)
    for k in range(8):                                           # ribs from the ankle out over the plate
        ang = 2 * math.pi * (k + 0.5) / 8
        tip = (math.cos(ang) * pad * 0.74, math.sin(ang) * pad * 0.74, sole - 0.06 * s)
        _rod(F, "gear_strut", (math.cos(ang) * 0.12 * s, math.sin(ang) * 0.12 * s, ankle + 0.08 * s), tip,
             0.035 * s, sides=4)
    vs._prism(F, "gear_dark", (0.0, 0.0, sole), fwd, length - sole, pad, sides=16)
    return F


def _truss_faces(length, scale, pad):
    """A long engine-block strut as a triangulated truss tower (the Nebulon-B's 89 m supports): three longerons on
    a triangle round the axis, a ring every bay, a zig-zag diagonal up each face, a mounting collar at the hinge and
    a broad footing with a dark sole. Stowed along +z from the hinge like _gear_faces."""
    F = vs.Faces(GEAR_MATERIALS)
    s = scale
    R = 0.55 * s                                                 # longerons' distance from the axis
    foot_top = length - 0.5 * s
    corners = [(R * math.cos(a), R * math.sin(a))
               for a in (math.pi / 2, math.pi / 2 + 2 * math.pi / 3, math.pi / 2 + 4 * math.pi / 3)]
    vs._prism(F, "gear_frame", (0.0, 0.0, 0.0), (0.0, 0.0, 1.0), 0.6 * s, R * 1.35, sides=12)       # collar
    vs._prism(F, "gear_frame", (-R * 1.2, 0.0, 0.0), (1.0, 0.0, 0.0), R * 2.4, 0.18 * s, sides=12)  # trunnion
    z0, z1 = 0.6 * s, foot_top
    bays = max(3, int(round((z1 - z0) / (1.4 * s))))
    zs = [z0 + (z1 - z0) * i / bays for i in range(bays + 1)]
    for x, y in corners:
        _rod(F, "gear_strut", (x, y, z0), (x, y, z1), 0.085 * s, sides=8)
    for i, z in enumerate(zs):
        for j in range(3):
            a, b = corners[j], corners[(j + 1) % 3]
            _rod(F, "gear_frame", (a[0], a[1], z), (b[0], b[1], z), 0.05 * s, sides=6)
            if i < bays:                                          # alternate diagonals: a zig-zag up each face
                lo, hi = (a, b) if i % 2 == 0 else (b, a)
                _rod(F, "gear_strut", (lo[0], lo[1], z), (hi[0], hi[1], zs[i + 1]), 0.04 * s, sides=6)
    _rod(F, "gear_dark", (0.0, 0.0, z0), (0.0, 0.0, z1), 0.06 * s, sides=8)                         # hydraulic spine
    # footing: block, ribs out to a plate, dark sole
    vs._prism(F, "gear_frame", (0.0, 0.0, foot_top), (0.0, 0.0, 1.0), 0.32 * s, R * 1.25, sides=12)
    for k in range(6):
        ang = 2 * math.pi * (k + 0.5) / 6
        _rod(F, "gear_strut", (math.cos(ang) * R, math.sin(ang) * R, foot_top),
             (math.cos(ang) * pad * 0.85, math.sin(ang) * pad * 0.85, length - 0.18 * s), 0.07 * s, sides=4)
    vs._prism(F, "gear_frame", (0.0, 0.0, length - 0.18 * s), (0.0, 0.0, 1.0), 0.08 * s, pad * 0.92, sides=16)
    vs._prism(F, "gear_dark", (0.0, 0.0, length - 0.1 * s), (0.0, 0.0, 1.0), 0.1 * s, pad, sides=16)
    return F


def landing_leg(name, hp, ground_y, pad=0.5, export_root=EXPORT):
    """A folding landing leg modelled stowed (lying forward along +z from its hinge); deploying turns it 90 deg about
    x down to the ground. Returns (apt, length)."""
    length = hp[1] - ground_y
    F = _gear_faces(length, 1.0, pad)
    sgs = vs._materials(f"swg_{name}", GEAR_MATERIALS)
    return vs._export_part(name, F, sgs, export_root), length


# ============================================================================
# Lambda-class T-4a shuttle
# ============================================================================
# Stock lambda_player.pob: r0 the hull (lambda_shuttle_body_player.lod), r1 the cabin (passenger bay aft, a corridor,
# the cockpit forward; deck y -0.61). The stock skeleton (lambda.skt) sits 3.75 m higher and 1.83 m further forward
# than the POB frame; in the POB frame the boarding ramp hinges at (0, -0.59, 1.82) and lies forward along +z,
# flush with the belly panel under the corridor (the belly is at -0.62 there, 1 cm under the deck). Lowered, it drops
# forward under the cockpit: the corridor deck gets a hatch where a walker on the ramp needs the headroom.
# The corridor is the only way between the bay and the cockpit, so the walk floor stays whole over the hatch and the
# ramp cell is a "hatch" cell: the engine crosses a portal into a hatch cell only while that cell admits the walker
# (Portal::isPassable), and the vessel scripts open it with the ramp. Ramp up: people walk over the closed hatch.
# Ramp down: walking into the hatch (at the hinge, or over its front edge) puts you on the ramp.

L_POB = "appearance/lambda_player.pob"
L_DECK = -0.61
L_HINGE = (0.0, -0.59, 1.82)
L_RAMP_LEN, L_RAMP_HW = 6.12, 0.93          # stock lambda_ramp mesh: 6.12 long, 1.82 wide, 0.12 thick
L_GROUND = -3.40                             # 1.46 m under the lowest belly point
L_RAMP_TOP = L_HINGE[1] + 0.06
L_RAMP_DEG = math.degrees(math.asin((L_RAMP_TOP - L_GROUND) / L_RAMP_LEN))
L_FOOT_Z = L_HINGE[2] + L_RAMP_LEN * math.cos(math.radians(L_RAMP_DEG))
L_HOLE_Z = 5.8                               # deck hatch: hinge to where the lowered ramp leaves 2 m of headroom
L_CUT_Z = (1.80, 7.96)                       # belly opening (the stowed ramp's footprint)
L_CELL_Z = 8.02                              # foot portal: just past the belly opening
L_PORTAL_TOP = -0.45                         # the ramp cell's top portal over the hatch (above the deck)
L_RAMP_CELL = "hatch_ramp"
# legs (x, z): the nose is a narrow V under the corridor, so the front pair stands just outside the ramp
L_LEGS = {"leg_fl": (1.3, 4.0), "leg_fr": (-1.3, 4.0), "leg_rl": (3.0, -6.2), "leg_rr": (-3.0, -6.2)}
L_WINGS = {"wing_l": ((6.0, 0.0, 0.0), "appearance/mesh/lambda_wing_left_l0.msh", 135.0),
           "wing_r": ((-6.0, 0.0, 0.0), "appearance/mesh/lambda_wing_right_l0.msh", -135.0)}


def lambda_import(name="titan_lambda_shuttle"):
    """Stage 1: the stock POB, hull paint swapped to the hue shaders, canopy glass made clear, canopy portal
    enabled (see into the cockpit)."""
    paint = _paint("lambda")
    root = import_stock_pob(L_POB, name)
    swapped = swap_shaders([root + "|r0|mesh"], paint["swap"], "swg_titan_lambda")
    glass = swap_shaders([root + "|r0|mesh"], {"shader/lambda_glass_ae9.sht": vs.GLASS}, "swg_titan_lambda")
    return {"root": root, "swapped": swapped, "glass": glass, "portals_enabled": enable_r0_portals(root)}


def lambda_hatch(root):
    """Stage 2: the belly opening in r0 and the deck hatch in r1 (the visual deck only: the walk floor stays)."""
    x = L_RAMP_HW
    z0, z1 = L_CUT_Z
    hull_lo, hull_hi = (-x, -1.12, z0), (x, -0.50, z1)
    hull_cut = vs.cut_region([root + "|r0|mesh"], vs.box_planes(hull_lo, hull_hi), (hull_lo, hull_hi))
    deck_lo, deck_hi = (-x, L_DECK - 0.08, L_HINGE[2]), (x, L_DECK + 0.08, L_HOLE_Z)
    vs.cut_region([root + "|r1|mesh"], vs.box_planes(deck_lo, deck_hi), (deck_lo, deck_hi))
    return {"deck_hatch": [deck_lo, deck_hi], "belly_opening": [hull_lo, hull_hi]}


def lambda_ramp_cell(root):
    """Stage 3: r2 'hatch_ramp': the open-air box under the hatch (floor = the lowered ramp, then a ground apron to
    the foot portal), the well linings, its portals and lights."""
    hull_tris = vs.tri_list([root + "|r0|mesh"])
    cell = vs._new_cell(root, 2, L_RAMP_CELL)
    sgs = vs._materials("swg_titan_lambda_ramp", FLEET_MATERIALS)
    x, zh, zo, zc = L_RAMP_HW, L_HINGE[2], L_HOLE_Z, L_CELL_Z
    yb, yt = L_GROUND - 1.2, L_PORTAL_TOP
    # where the belly steps from the low hull aft of the hinge (-1.04) up to the ramp panel (-0.62)
    step_z = next((z / 100.0 for z in range(int(zh * 100), int(zo * 100), 5)
                   if (belly_y(hull_tris, x + 0.05, z / 100.0) or -9) > -0.8), zh)
    low = min(belly_y(hull_tris, x + 0.05, zh + 0.02) or -1.04, -0.66) - 0.02
    plate = -0.63
    F = vs.Faces(FLEET_MATERIALS)
    # rear wall under the hinge strip, the side linings up to the hatch coaming, the wall under the hatch's front edge
    F.add("well", [(-x, low, zh), (x, low, zh), (x, -0.66, zh), (-x, -0.66, zh)], (0, 0, 1))
    for s in (1, -1):
        F.add("well", [(s * x, low, zh), (s * x, low, step_z), (s * x, yt, step_z), (s * x, yt, zh)], (-s, 0, 0))
        F.add("well", [(s * x, plate, step_z), (s * x, plate, zo), (s * x, yt, zo), (s * x, yt, step_z)], (-s, 0, 0))
        F.add("trim", [(s * x, yt, zh), (s * (x + 0.08), yt, zh), (s * (x + 0.08), yt, zo), (s * x, yt, zo)], (0, 1, 0))
    F.add("well", [(-x, plate, zo), (x, plate, zo), (x, -0.66, zo), (-x, -0.66, zo)], (0, 0, -1))
    # the belly opening forward of the hatch is roofed by the ramp-well ceiling (seen from below with the ramp down)
    F.add("well", [(-x, plate, zo), (-x, plate, L_CUT_Z[1]), (x, plate, L_CUT_Z[1]), (x, plate, zo)], (0, -1, 0))
    F.add("well", [(-x, low, zh), (-x, low, step_z), (x, low, step_z), (x, low, zh)], (0, -1, 0))
    F.build(cell + "|mesh", "ramp", sgs)
    # floor: the lowered ramp from the hinge (deck height) to the foot, then flat ground to the foot portal
    gy = L_GROUND + 0.03
    vs._floor(cell, [[(-x, L_DECK, zh), (x, L_DECK, zh), (x, gy, L_FOOT_Z), (-x, gy, L_FOOT_Z)],
                     [(-x, gy, L_FOOT_Z), (x, gy, L_FOOT_Z), (x, gy, zc), (-x, gy, zc)]])
    inside = (0.0, L_GROUND + 1.0, (zh + zc) / 2)
    portals = [
        # hinge strip and the hatch's front edge (the walk crosses these at deck height) and the hatch top
        vs.portal(root, 2, 1, [(-x, -0.66, zh), (x, -0.66, zh), (x, yt, zh), (-x, yt, zh)], (0.0, 0.5, zh - 1.0)),
        vs.portal(root, 2, 1, [(-x, -0.66, zo), (x, -0.66, zo), (x, yt, zo), (-x, yt, zo)], (0.0, 0.5, zo + 1.0)),
        vs.portal(root, 2, 1, [(-x, yt, zh), (x, yt, zh), (x, yt, zo), (-x, yt, zo)], (0.0, 1.5, (zh + zo) / 2)),
        # foot (walk on / off) and the open sides, rear and bottom to the world
        vs.portal(root, 0, 2, [(-x, yb, zc), (x, yb, zc), (x, plate, zc), (-x, plate, zc)], inside),
        vs.portal(root, 0, 2, [(-x, yb, zh), (x, yb, zh), (x, low, zh), (-x, low, zh)], inside, passable=False),
        vs.portal(root, 0, 2, [(-x, yb, zh), (x, yb, zh), (x, yb, zc), (-x, yb, zc)], inside, passable=False),
    ]
    for s in (1, -1):
        portals.append(vs.portal(root, 0, 2, [(s * x, yb, zh), (s * x, yb, step_z), (s * x, low, step_z),
                                              (s * x, low, zh)], inside, passable=False))
        portals.append(vs.portal(root, 0, 2, [(s * x, yb, step_z), (s * x, yb, zc), (s * x, plate, zc),
                                              (s * x, plate, step_z)], inside, passable=False))
    vs._lights(cell, ((0.75, 0.72, 0.68), 0.55), [((0.0, -1.0, (zh + zo) / 2), (1.0, 0.95, 0.85), 0.6)],
               [((0.3, -1.0, 0.2), (0.8, 0.75, 0.66), 1.0), ((-0.2, 1.0, -0.1), (0.25, 0.25, 0.28), 1.0)])
    return {"cell": cell, "portals": portals, "step_z": step_z, "low": low,
            "ramp": {"deg": L_RAMP_DEG, "foot_z": L_FOOT_Z, "ground": L_GROUND}}


def lambda_parts(root, export_root=EXPORT, name="titan_lambda_shuttle"):
    """Stage 4: the stock ramp, the wings (hue variants; flight pose = stock, landed = folded up 135 deg) and four
    folding landing legs, as hp_dyn parts on their own hardpoints."""
    paint = _paint("lambda")
    hull_tris = vs.tri_list([root + "|r0|mesh"])
    parts, hps, legs = [], {}, {}
    hps["ramp"] = L_HINGE
    parts.append({"slot": "ramp", "hp": "ramp", "path": "appearance/lambda_ramp.apt", "mode": "rot",
                  "axis": [1.0, 0.0, 0.0], "amount": L_RAMP_DEG, "seconds": 3.0})
    for slot, (p, msh, amount) in L_WINGS.items():
        part = export_mesh_part(f"{name}_{slot}", msh, paint["swap"], export_root)
        hps[slot] = p
        parts.append({"slot": slot, "hp": slot, "path": part["apt"], "mode": "rot", "axis": [0.0, 0.0, 1.0],
                      "amount": amount, "seconds": 4.0})
    for slot, (x, z) in L_LEGS.items():
        belly = belly_y(hull_tris, x, z)
        hp = (x, belly - 0.22, z)
        apt, length = landing_leg(f"{name}_{slot}", hp, L_GROUND, pad=0.35, export_root=export_root)
        hps[slot] = hp
        parts.append({"slot": slot, "hp": slot, "path": apt, "mode": "rot", "axis": [1.0, 0.0, 0.0],
                      "amount": 90.0, "seconds": 3.0})
        legs[slot] = {"belly": belly, "length": length, "hp": hp, "pad": 0.35}
    return {"parts": parts, "hardpoints": {k: _hp_rows(p) for k, p in hps.items()}, "legs": legs}


def build_lambda(name="titan_lambda_shuttle", export_root=EXPORT, export=True):
    info = lambda_import(name)
    root = info.pop("root")
    info.update(lambda_hatch(root))
    info.update(lambda_ramp_cell(root))
    info.update(lambda_parts(root, export_root, name))
    info["landed"] = [[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, -L_GROUND], [0.0, 0.0, 1.0, 0.0]]
    info["paint"] = _paint("lambda")["defaults"]
    hull = hull_collision_boxes(root, 2.0, 1.0)
    info["hull_extent"] = box_extent(hull)
    info["collision_boxes"] = landed_collision(hull, L_GROUND, info["legs"])
    info["lod_paint"] = paint_lods(name, "appearance/lod/lambda_shuttle_body_player.lod", _paint("lambda")["swap"], export_root)
    info["root"] = root
    if export:
        with quiet():
            info["export"] = pb.export(root, export_root, name)
    return info


# ============================================================================
# room kit: box rooms on a deck, walls with openings, split floors, ceiling light strips, portals
# ============================================================================

def _wall_point(side, box, u, y):
    """A point on one wall of box (x0, x1, z0, z1): `u` runs along the wall (x on z walls, z on x walls)."""
    x0, x1, z0, z1 = box
    return {"z1": (u, y, z1), "z0": (u, y, z0), "x1": (x1, y, u), "x0": (x0, y, u)}[side]


WALL_IN = {"z1": (0, 0, -1), "z0": (0, 0, 1), "x1": (-1, 0, 0), "x0": (1, 0, 0)}


# Interior doorways: the stock corvette door (door_blockade_runner_s01, a 1.8 x 2.9 m leaf) in a 2 x 3 m opening,
# framed by a bulkhead collar FRAME_DEPTH deep on each side (the walls read as thick as a ship's bulkheads).
DOOR_STYLE = "door_blockade_runner_s01"
RAMP_CELL = "hatch_ramp"              # the big hulls' ramp cells (engine floor-hatch rules, see ramp_cell)
DOOR_W, DOOR_H = 2.0, 3.0
FRAME_W, FRAME_DEPTH = 0.22, 0.25
# Wall panels: the stock corvette panel atlas (corv_whitewall_panels) holds four 0.68 x 1.1 m raised panels - two
# white (plain, intercom), two dark with red status lights. Stock halls set them in two rows on plain whitewall.
PANEL_W, PANEL_H, PANEL_PITCH = 0.68, 1.1, 0.76
PANEL_ROWS = ((0.5, 1.6), (1.7, 2.8))
PANEL_BEVEL_U, PANEL_BEVEL_V, PANEL_PROUD = 0.14, 0.1, 0.035
PANEL_TILES = ((0.0, 0.0, 0.55), (0.5, 0.0, 0.25), (0.0, 0.5, 0.1), (0.5, 0.5, 0.1))   # atlas origin, share


def door(a=None):
    """The (a, b, top) opening of a standard doorway centred on `a` (default 0)."""
    c = 0.0 if a is None else a
    return (c - DOOR_W / 2, c + DOOR_W / 2, DOOR_H)


def _pick_tile(key):
    """Deterministic atlas tile for a panel: mostly white, some intercoms, the odd dark status panel."""
    h = 2166136261
    for ch in key:
        h = ((h ^ ord(ch)) * 16777619) & 0xFFFFFFFF
    t, acc = (h % 1000) / 1000.0, 0.0
    for u0, v0, share in PANEL_TILES:
        acc += share
        if t < acc:
            return u0, v0
    return PANEL_TILES[0][:2]


def wall_panel(F, P, n, right_sign, ua, ub, ya, yb, tile, mat="panels"):
    """One raised atlas panel between wall coordinates ua..ub (along), ya..yb (height). `P(u, y, d)` is the wall
    point d metres in front of the wall; right_sign +1 when u grows to the right seen from the front."""
    u0, v0 = tile
    bu, bv, d = PANEL_BEVEL_U, PANEL_BEVEL_V, PANEL_PROUD
    w, h = ub - ua, yb - ya

    def uv(u, y):
        s = (u - ua) / w if right_sign > 0 else (ub - u) / w
        t = (y - ya) / h
        return (u0 + 0.5 * s, 1.0 - (v0 + 0.5 * (1.0 - t)))     # stock v runs top-down; the exporter writes 1 - v

    outer = [(ua, ya), (ub, ya), (ub, yb), (ua, yb)]
    inner = [(ua + bu, ya + bv), (ub - bu, ya + bv), (ub - bu, yb - bv), (ua + bu, yb - bv)]
    F.add_uv(mat, [P(u, y, d) for u, y in inner], [uv(u, y) for u, y in inner], n)
    for k in range(4):
        q = [outer[k], outer[(k + 1) % 4], inner[(k + 1) % 4], inner[k]]
        F.add_uv(mat, [P(u, y, 0.0 if j < 2 else d) for j, (u, y) in enumerate(q)], [uv(u, y) for u, y in q], n)


def _pillar_positions(lo, hi, cuts, spacing, width):
    count = int((hi - lo) // spacing) if spacing else 0
    if count < 1:
        return []
    start = lo + ((hi - lo) - (count - 1) * spacing) / 2.0 if count > 1 else (lo + hi) / 2.0
    out = []
    for k in range(count):
        a, b = start + k * spacing - width / 2, start + k * spacing + width / 2
        if a < lo + 0.3 or b > hi - 0.3 or any(a < ob + FRAME_W + 0.3 and b > oa - FRAME_W - 0.3 for oa, ob, _ in cuts):
            continue
        out.append((a, b))
    return out


def door_collar(F, P, n, along, oa, ob, y0, yt, y1, mat):
    """A doorway's bulkhead collar on one side of its wall: face ring, reveal through the opening (oa..ob, y0..yt),
    outer cheeks and the head's top. `P(u, y, d)`: the wall point d metres in front of the wall."""
    fw, d = FRAME_W, FRAME_DEPTH
    back = tuple(-c for c in along)
    yh = min(yt + fw, y1)
    F.add(mat, [P(oa - fw, y0, d), P(oa, y0, d), P(oa, yt, d), P(oa - fw, yt, d)], n)
    F.add(mat, [P(ob, y0, d), P(ob + fw, y0, d), P(ob + fw, yt, d), P(ob, yt, d)], n)
    if yh > yt + 1e-3:
        F.add(mat, [P(oa - fw, yt, d), P(ob + fw, yt, d), P(ob + fw, yh, d), P(oa - fw, yh, d)], n)
        if yh < y1 - 1e-3:
            F.add(mat, [P(oa - fw, yh, 0.0), P(ob + fw, yh, 0.0), P(ob + fw, yh, d), P(oa - fw, yh, d)], (0, 1, 0))
    F.add(mat, [P(oa, y0, 0.0), P(oa, y0, d), P(oa, yt, d), P(oa, yt, 0.0)], along)
    F.add(mat, [P(ob, y0, 0.0), P(ob, y0, d), P(ob, yt, d), P(ob, yt, 0.0)], back)
    if yt < y1 - 1e-3:
        F.add(mat, [P(oa, yt, 0.0), P(ob, yt, 0.0), P(ob, yt, d), P(oa, yt, d)], (0, -1, 0))
    F.add(mat, [P(oa - fw, y0, 0.0), P(oa - fw, y0, d), P(oa - fw, yh, d), P(oa - fw, yh, 0.0)], back)
    F.add(mat, [P(ob + fw, y0, 0.0), P(ob + fw, y0, d), P(ob + fw, yh, d), P(ob + fw, yh, 0.0)], along)


def wall(F, col, side, box, y0, y1, openings=(), base=0.35, mats=("base", "panels", "metal"), pillars=0.0,
         panels=True, tag=""):
    """One room wall from y0 to y1 with openings [(a, b, top)] (heights above y0); faces into the room. Plain
    whitewall with two rows of raised atlas panels between the ribs (`pillars`: rib spacing) and the doorways; each
    doorway gets a bulkhead collar FRAME_DEPTH deep (its neighbour's wall carries the other half)."""
    x0, x1, z0, z1 = box
    lo, hi = (x0, x1) if side in ("z0", "z1") else (z0, z1)
    n = WALL_IN[side]
    along = (1.0, 0.0, 0.0) if side in ("z0", "z1") else (0.0, 0.0, 1.0)
    back = tuple(-c for c in along)
    right_sign = 1 if (n[2] * along[0] - n[0] * along[2]) > 0 else -1     # u along the wall vs. right seen from front
    cuts = sorted(openings)
    P = lambda u, y, d=0.0: tuple(p + c * d for p, c in zip(_wall_point(side, box, u, y), n))
    edges, a = [], lo
    for oa, ob, _ in cuts:
        edges.append((a, oa))
        a = ob
    edges.append((a, hi))
    for ua, ub in edges:
        if ub - ua < 1e-3:
            continue
        F.add(mats[0], [P(ua, y0), P(ub, y0), P(ub, y1), P(ua, y1)], n)
        if col is not None:
            col.facing([P(ua, y0), P(ub, y0), P(ub, y1), P(ua, y1)], n)
    for oa, ob, top in cuts:
        yt = min(y0 + top, y1)
        if yt < y1 - 1e-3:
            F.add(mats[0], [P(oa, yt), P(ob, yt), P(ob, y1), P(oa, y1)], n)
            if col is not None:
                col.facing([P(oa, yt), P(ob, yt), P(ob, y1), P(oa, y1)], n)
        door_collar(F, P, n, along, oa, ob, y0, yt, y1, mats[2])
    ribs = _pillar_positions(lo, hi, cuts, pillars, 0.36)
    for a, b in ribs:
        proud = 0.12
        F.add(mats[0], [P(a, y0, proud), P(b, y0, proud), P(b, y1, proud), P(a, y1, proud)], n)
        F.add(mats[0], [P(a, y0), P(a, y0, proud), P(a, y1, proud), P(a, y1)], back)
        F.add(mats[0], [P(b, y0), P(b, y0, proud), P(b, y1, proud), P(b, y1)], along)
    if not panels:
        return
    # panel bays: wall runs between doorway collars and ribs, filled with whole panels centred in each bay
    blocks = [(oa - FRAME_W - 0.08, ob + FRAME_W + 0.08) for oa, ob, _ in cuts] + [(a - 0.06, b + 0.06) for a, b in ribs]
    blocks.sort()
    bays, a = [], lo + 0.12
    for ba, bb in blocks:
        if ba > a:
            bays.append((a, ba))
        a = max(a, bb)
    if hi - 0.12 > a:
        bays.append((a, hi - 0.12))
    for r, (ra, rb) in enumerate(PANEL_ROWS):
        ya, yb = y0 + ra, y0 + rb
        if yb > y1 - 0.15:
            continue
        for ba, bb in bays:
            count = int((bb - ba + PANEL_PITCH - PANEL_W) // PANEL_PITCH)
            if count < 1:
                continue
            start = (ba + bb) / 2.0 - (count * PANEL_PITCH - (PANEL_PITCH - PANEL_W)) / 2.0
            for k in range(count):
                ua = start + k * PANEL_PITCH
                tile = _pick_tile(f"{tag}{side}{r}{round(ua, 2)}")
                wall_panel(F, P, n, right_sign, ua, ua + PANEL_W, ya, yb, tile, mats[1])


def ceiling_beams(F, box, y, spacing=4.0, depth=0.22, width=0.3, mat="base"):
    """Beams across the room's short span under the ceiling every `spacing` metres."""
    x0, x1, z0, z1 = box
    along_z = (z1 - z0) >= (x1 - x0)
    lo, hi = (z0, z1) if along_z else (x0, x1)
    count = int((hi - lo) // spacing)
    for k in range(1, count + 1):
        u = lo + (hi - lo) * k / (count + 1)
        a, b, yb = u - width / 2, u + width / 2, y - depth
        if along_z:
            F.add(mat, [(x0, yb, a), (x1, yb, a), (x1, yb, b), (x0, yb, b)], (0, -1, 0))
            F.add(mat, [(x0, yb, a), (x1, yb, a), (x1, y, a), (x0, y, a)], (0, 0, -1))
            F.add(mat, [(x0, yb, b), (x1, yb, b), (x1, y, b), (x0, y, b)], (0, 0, 1))
        else:
            F.add(mat, [(a, yb, z0), (a, yb, z1), (b, yb, z1), (b, yb, z0)], (0, -1, 0))
            F.add(mat, [(a, yb, z0), (a, yb, z1), (a, y, z1), (a, y, z0)], (-1, 0, 0))
            F.add(mat, [(b, yb, z0), (b, yb, z1), (b, y, z1), (b, y, z0)], (1, 0, 0))


def split_floor(box, y, openings):
    """Floor quads for box split at every opening edge, so each doorway's floor edge has its own vertices (welded
    seams are crossable)."""
    x0, x1, z0, z1 = box
    xs, zs = {x0, x1}, {z0, z1}
    for side, cuts in openings.items():
        for a, b, _ in cuts:
            (xs if side in ("z0", "z1") else zs).update((a, b))
    xs, zs = sorted(xs), sorted(zs)
    return [[(xa, y, za), (xb, y, za), (xb, y, zb), (xa, y, zb)]
            for xa, xb in zip(xs, xs[1:]) for za, zb in zip(zs, zs[1:])]


def ceiling(F, col, box, y, strip=0.6, inset=0.8, beams=True):
    """Ceiling facing down with a light strip down the room's long axis."""
    x0, x1, z0, z1 = box
    if (z1 - z0) >= (x1 - x0):
        c = (x0 + x1) / 2
        a, b, s0, s1 = c - strip / 2, c + strip / 2, z0 + inset, z1 - inset
        F.add("ceiling", [(x0, y, z0), (a, y, z0), (a, y, z1), (x0, y, z1)], (0, -1, 0))
        F.add("ceiling", [(b, y, z0), (x1, y, z0), (x1, y, z1), (b, y, z1)], (0, -1, 0))
        F.add("ceiling", [(a, y, z0), (b, y, z0), (b, y, s0), (a, y, s0)], (0, -1, 0))
        F.add("ceiling", [(a, y, s1), (b, y, s1), (b, y, z1), (a, y, z1)], (0, -1, 0))
        F.add("light", [(a, y - 0.02, s0), (b, y - 0.02, s0), (b, y - 0.02, s1), (a, y - 0.02, s1)], (0, -1, 0))
    else:
        c = (z0 + z1) / 2
        a, b, s0, s1 = c - strip / 2, c + strip / 2, x0 + inset, x1 - inset
        F.add("ceiling", [(x0, y, z0), (x1, y, z0), (x1, y, a), (x0, y, a)], (0, -1, 0))
        F.add("ceiling", [(x0, y, b), (x1, y, b), (x1, y, z1), (x0, y, z1)], (0, -1, 0))
        F.add("ceiling", [(x0, y, a), (s0, y, a), (s0, y, b), (x0, y, b)], (0, -1, 0))
        F.add("ceiling", [(s1, y, a), (x1, y, a), (x1, y, b), (s1, y, b)], (0, -1, 0))
        F.add("light", [(s0, y - 0.02, a), (s1, y - 0.02, a), (s1, y - 0.02, b), (s0, y - 0.02, b)], (0, -1, 0))
    if beams and max(x1 - x0, z1 - z0) > 8.0:
        ceiling_beams(F, box, y)
    if col is not None:
        col.facing([(x0, y, z0), (x1, y, z0), (x1, y, z1), (x0, y, z1)], (0, -1, 0))


def room_lights(cell, box, y0, h, warm=(1.0, 0.96, 0.9), points=3, intensity=0.8, ambient=0.42):
    """Stock layout: ambient + 2 parallels + point lights spread along the long axis under the ceiling."""
    x0, x1, z0, z1 = box
    along_z = (z1 - z0) >= (x1 - x0)
    n = max(1, min(points, int(max(z1 - z0, x1 - x0) // 6) or 1))
    pts = []
    for k in range(n):
        t = (k + 0.5) / n
        p = ((x0 + x1) / 2, y0 + h - 0.5, z0 + (z1 - z0) * t) if along_z else \
            (x0 + (x1 - x0) * t, y0 + h - 0.5, (z0 + z1) / 2)
        pts.append((p, warm, intensity))
    return vs._lights(cell, ((0.62, 0.63, 0.68), ambient), pts,
                      [((0.4, -1.0, 0.2), (0.5, 0.5, 0.48), 1.0), ((-0.3, 1.0, -0.1), (0.2, 0.2, 0.24), 1.0)])


def new_cell(root, index, name, see_world=False):
    cell = vs._new_cell(root, index, name)
    cmds.setAttr(cell + ".pobCellCanSeeWorld", bool(see_world))
    return cell


def finish_cell(cell, F, col, sgs, floors, tag, floor_mat="floor"):
    """Deck plating over the walk floor (floor_mat None: the cell lays its own), mesh, walk floor, collision."""
    for poly in floors if floor_mat else ():
        F.add(floor_mat, poly, (0, 1, 0))
    F.build(cell + "|mesh", tag, sgs)
    vs._floor(cell, floors)
    if col is not None and col.counts:
        pb._collision_mesh(col, f"{tag}_collision", cell + "|collision")


def keep_stock_cells(root, keep):
    """Cells this variant leaves alone keep their stock appearance and floor files (the .pob references them)."""
    for short in keep:
        cell = f"{root}|{short}"
        for shape in cmds.listRelatives(cell + "|mesh", allDescendents=True, type="mesh", fullPath=True) or []:
            if not cmds.attributeQuery("swgExcludeFromStaticMeshExport", node=shape, exists=True):
                cmds.addAttr(shape, longName="swgExcludeFromStaticMeshExport", attributeType="bool")
            cmds.setAttr(shape + ".swgExcludeFromStaticMeshExport", True)
        floor = cell + "|collision|floor0"
        for shape in cmds.listRelatives(floor, allDescendents=True, type="mesh", fullPath=True) or []:
            xf = cmds.listRelatives(shape, parent=True, fullPath=True)[0]
            cmds.delete(xf if xf != floor else shape)


def import_meshes(paths, parent, swap=None, prefix="hull"):
    """Stock .msh files into `parent`, right side out, shaders swapped."""
    made = []
    for rel in paths:
        before = set(cmds.ls(assemblies=True, long=True))
        with quiet():
            cmds.file(os.path.join(DATA, rel), i=True, type="SwgMsh")
        new = [n for n in cmds.ls(assemblies=True, long=True) if n not in before]
        shapes = cmds.listRelatives(new, allDescendents=True, type="mesh", fullPath=True) or []
        for shape in shapes:
            cmds.polyNormal(shape, normalMode=0, userNormalMode=0, constructionHistory=False)
        mark_uv_direct(shapes)
        made += cmds.parent(new, parent)
    swapped = swap_shaders([parent], swap or {}, prefix)
    return made, swapped


def landing_leg_scaled(name, hp, ground_y, scale=1.0, export_root=EXPORT):
    """landing_leg for big hulls: radii and pad scaled. Returns (apt, length)."""
    length = hp[1] - ground_y
    # past about 40 of its own cylinder radii (0.19 x scale) an oleo leg reads as a pole: those (the Nebulon's 89 m
    # engine struts) are truss towers
    F = (_truss_faces if length > 8.0 * scale else _gear_faces)(length, scale, 0.45 * scale)
    sgs = vs._materials(f"swg_{name}", GEAR_MATERIALS)
    return vs._export_part(name, F, sgs, export_root), length


def ramp_plank(name, length, half_width, export_root=EXPORT, along=-1.0, thickness=0.18):
    """A boarding plank modelled lowered-flat from its hinge (origin) along `along` z, grate on top, kerbs."""
    F = vs.Faces(FLEET_MATERIALS)
    hw, L, th, s = half_width, length, thickness, along
    F.add("grate", [(-hw, 0, 0), (hw, 0, 0), (hw, 0, s * L), (-hw, 0, s * L)], (0, 1, 0))
    F.add("metal", [(-hw, -th, 0), (hw, -th, 0), (hw, -th, s * L), (-hw, -th, s * L)], (0, -1, 0))
    for xx, f in ((-hw, -1), (hw, 1)):
        inner = xx - f * 0.08
        F.add("metal", [(xx, 0.10, 0), (xx, -th, 0), (xx, -th, s * L), (xx, 0.10, s * L)], (f, 0, 0))
        F.add("metal", [(inner, 0.10, 0), (inner, 0, 0), (inner, 0, s * L), (inner, 0.10, s * L)], (-f, 0, 0))
        F.add("metal", [(xx, 0.10, 0), (inner, 0.10, 0), (inner, 0.10, s * L), (xx, 0.10, s * L)], (0, 1, 0))
    F.add("metal", [(-hw, 0, s * L), (hw, 0, s * L), (hw, -th, s * L), (-hw, -th, s * L)], (0, 0, s))
    F.add("metal", [(-hw, 0, 0), (hw, 0, 0), (hw, -th, 0), (-hw, -th, 0)], (0, 0, -s))
    sgs = vs._materials(f"swg_{name}", FLEET_MATERIALS)
    return vs._export_part(name, F, sgs, export_root)


# ============================================================================
# Corellian corvette (CR90), extended
# ============================================================================
# The stock player corvette (corellian_corvette_2005e3.pob, the 2005 E3 demo cut) is the forward section only: bridge,
# officers' quarters, the halls behind it and two lift alcoves. The extension carries the deck aft through the neck
# into the wide mid-section (inside the hull: the neck is 12 m wide, the mid-section 44 m): a spine hall, a cross hall,
# a starboard lounge and port crew quarters with windows through the hull sides, and a companionway down into the
# keel to an embarkation room on a lower deck, whose aft door opens onto a 29 m ventral ramp. Landed, the corvette
# rests on its engine block (y -27.3) and four forward legs. Main deck y 0.

CV_POB = "appearance/corellian_corvette_2005e3.pob"
CV_HULL = [f"appearance/mesh/corellian_corvette_2005e3_r0_mesh_l0_c{i}_l0.msh" for i in range(4)]
CV_KEEP = ("r1", "r3", "r4", "r5", "r6", "r7")          # r2 (hall61) gets the aft doorway
CV_GROUND = -27.4
CV_H = 3.4
CV_DOOR = door()
CV_HALL61_Z = 84.57                           # hall61 walk floor starts here (its aft wall face is at 84.1)
CV_SPINE = (-2.0, 2.0, 62.0, CV_HALL61_Z + 0.05)
CV_CROSS = (-16.0, 16.0, 58.0, 62.0)
CV_LOUNGE_X = (2.5, 19.6)                     # inner wall, outer wall (hull side at deck height: 21-22.4)
CV_LOUNGE_Z = (30.0, 58.0)
CV_LOUNGE_H = 3.2
CV_OUTER_TOP = (17.6, 3.2)                    # the outer wall leans in above y 1.9 (the hull narrows to 19 at y 3)
CV_WIN_Y = (0.85, 1.85)
CV_WIN_Z = (33.0, 37.6, 42.2, 46.8, 51.4)
CV_WIN_HALF = 1.6
CV_COMP_X = 1.6
CV_COMP_Z = (34.0, 58.0)                      # bottom (y -12), top (deck)
CV_LOWER = -12.0
CV_EMBARK = (-4.5, 4.5, 20.0, 34.0)
CV_RAMP_HW = 1.8
CV_RAMP_DEG = 32.0
CV_RAMP_LEN = (CV_LOWER - CV_GROUND) / math.sin(math.radians(CV_RAMP_DEG))
CV_RAMP_FOOT_Z = CV_EMBARK[2] - CV_RAMP_LEN * math.cos(math.radians(CV_RAMP_DEG))
CV_GEAR_SCALE = 6.5                            # gear radii x this (the 266 m hull wants stout legs)
CV_LEGS = {"leg_fl": (5.0, 54.0), "leg_fr": (-5.0, 54.0), "leg_nl": (5.5, 112.0), "leg_nr": (-5.5, 112.0)}

CV_MATERIALS = {
    "panels": ("shader/corv_whitewall_panels_2005e3_cesde32.sht", (0.85, 0.85, 0.86), 3.4),
    "base": ("shader/corv_whitewall_base_2005e3_cesd24.sht", (0.8, 0.8, 0.8), 2.0),
    "pillar": ("shader/corv_whitewall_pillars_2005e3_cesd24.sht", (0.8, 0.8, 0.82), 1.0),
    "floor": ("shader/corv_floor_gray_2005e3_cesd24.sht", (0.55, 0.55, 0.57), 2.0),
    "ceiling": ("shader/corv_whitewall_base_2005e3_cesd24.sht", (0.8, 0.8, 0.8), 3.0),
    "light": ("shader/corv_ceiling_light_aefb17.sht", (1.0, 1.0, 0.95), 1.0),
    "grate": ("shader/corv_gray_metal_grate_2005e3_cd8.sht", (0.45, 0.45, 0.47), 2.0),
    "metal": ("shader/corv_gray_metal_square_2005e3_cds16.sht", (0.5, 0.5, 0.52), 2.0),
    "glass": (vs.GLASS, (0.55, 0.68, 0.78), 1.0),
}


def corvette_import(name="titan_corellian_corvette"):
    """Stage 1: the stock POB, its hull (four component meshes) into r0 with the paint shaders, the untouched cells
    referencing their stock files, the r0 window portals enabled."""
    paint = _paint("corvette")
    root = import_stock_pob(CV_POB, name)
    for old in cmds.listRelatives(root + "|r0|mesh", children=True, fullPath=True) or []:
        cmds.delete(old)
    made, swapped = import_meshes(CV_HULL, root + "|r0|mesh", paint["swap"], "swg_titan_corvette")
    keep_stock_cells(root, CV_KEEP)
    return {"root": root, "hull_parts": len(made), "swapped": swapped, "portals_enabled": enable_r0_portals(root)}


def corvette_aft_door(root):
    """Stage 2: a doorway through hall61's aft wall (mesh and walk floor: a 5 cm sliver of floor goes, so the
    doorway's floor edge gets its own vertices)."""
    a, b, top = CV_DOOR
    z = CV_HALL61_Z
    lo, hi = (a, -0.2, z - 1.2), (b, top, z + 0.05)
    vs.cut_region([root + "|r2|mesh"], vs.box_planes(lo, hi), (lo, hi))
    flo, fhi = (a, -0.2, z - 1.2), (b, 0.2, z + 0.05)
    vs.cut_region([root + "|r2|collision|floor0"], vs.box_planes(flo, fhi), (flo, fhi))
    return {"hall61_door": [lo, hi], "floor_flipped": _floor_up(root + "|r2")}


def _hull_x(hull_tris, y, z, side):
    h = vs.ray_hits(hull_tris, (0.0, y, z), (float(side), 0.0, 0.0))
    return side * h[-1] if h else None


def corvette_rooms(root):
    """Stage 3: spine (r8), cross hall (r9), lounge (r10), crew quarters (r11), companionway (r12), embarkation
    room (r13), with their doorways, portals, floors, collision and lights."""
    sgs = vs._materials("swg_titan_corvette_int", CV_MATERIALS)
    hull_xf = cmds.listRelatives(root + "|r0|mesh", children=True, fullPath=True)
    hull_tris = vs.tri_list([root + "|r0|mesh"])
    a, b, top = CV_DOOR
    out = {"portals": []}
    P = out["portals"]

    # --- r8 spine -----------------------------------------------------------------------------------------------
    box = CV_SPINE
    cell = new_cell(root, 8, "hall_aft")
    F, col = vs.Faces(CV_MATERIALS), pb.MeshAccumulator()
    ops = {"z1": [(a, b, top)], "z0": [(a, b, top)]}
    for side in ("x0", "x1", "z0", "z1"):
        wall(F, col, side, box, 0.0, CV_H, ops.get(side, ()), pillars=4.0, tag=cell)
    ceiling(F, col, box, CV_H)
    finish_cell(cell, F, col, sgs, split_floor(box, 0.0, ops), "hall_aft")
    room_lights(cell, box, 0.0, CV_H)
    P.append(vs.portal(root, 8, 2, [(a, 0.0, box[3]), (b, 0.0, box[3]), (b, top, box[3]), (a, top, box[3])],
                       (0.0, 1.5, CV_HALL61_Z + 3.0), door_style=DOOR_STYLE))

    # --- r9 cross hall ------------------------------------------------------------------------------------------
    box = CV_CROSS
    cell = new_cell(root, 9, "crosshall")
    F, col = vs.Faces(CV_MATERIALS), pb.MeshAccumulator()
    lounge_door, quarters_door = door(8.5), door(-8.5)
    ops = {"z1": [(a, b, top)], "z0": [quarters_door, (-CV_COMP_X, CV_COMP_X, CV_LOUNGE_H), lounge_door]}
    for side in ("x0", "x1", "z0", "z1"):
        wall(F, col, side, box, 0.0, CV_H, ops.get(side, ()), pillars=4.0, tag=cell)
    ceiling(F, col, box, CV_H)
    finish_cell(cell, F, col, sgs, split_floor(box, 0.0, ops), "crosshall")
    room_lights(cell, box, 0.0, CV_H)
    P.append(vs.portal(root, 9, 8, [(a, 0.0, 62.0), (b, 0.0, 62.0), (b, top, 62.0), (a, top, 62.0)], (0.0, 1.5, 70.0),
                       door_style=DOOR_STYLE))

    # --- r10 lounge (starboard), r11 crew quarters (port): outer wall with windows through the hull --------------
    windows = {}
    for idx, side, cname in ((10, 1, "lounge"), (11, -1, "quarters")):
        cell = new_cell(root, idx, cname, see_world=True)
        F, col = vs.Faces(CV_MATERIALS), pb.MeshAccumulator()
        xi, xo = side * CV_LOUNGE_X[0], side * CV_LOUNGE_X[1]
        xt, yt = side * CV_OUTER_TOP[0], CV_OUTER_TOP[1]
        z0, z1 = CV_LOUNGE_Z
        lo_x, hi_x = min(xi, xo), max(xi, xo)
        ldoor = lounge_door if side > 0 else quarters_door
        da, db = (ldoor[0], ldoor[1]) if side > 0 else (ldoor[1], ldoor[0])        # inner jamb first
        # inner wall (beside the companionway), end walls (the door in the fore one), ceiling
        wall(F, col, "x0" if side > 0 else "x1", (lo_x, hi_x, z0, z1), 0.0, CV_LOUNGE_H, pillars=4.0)
        for zz, n in ((z0, (0, 0, 1)), (z1, (0, 0, -1))):
            if zz == z1:
                pieces = [[(xi, 0.0), (da, 0.0), (da, yt), (xi, yt)],
                          [(db, 0.0), (xo, 0.0), (xo, 1.9), (xt, yt), (db, yt)],
                          [(da, ldoor[2]), (db, ldoor[2]), (db, yt), (da, yt)]]
            else:
                pieces = [[(xi, 0.0), (xo, 0.0), (xo, 1.9), (xt, yt), (xi, yt)]]
            for poly in pieces:
                F.add("base", [(x, y, zz) for x, y in poly], n)
                col.facing([(x, y, zz) for x, y in poly], n)
            if zz == z1:
                door_collar(F, lambda u, y, d=0.0: (u, y, z1 - d), n, (1.0, 0.0, 0.0), min(da, db), max(da, db),
                            0.0, ldoor[2], yt, "metal")
        F.add("ceiling", [(xi, yt, z0), (xt, yt, z0), (xt, yt, z1), (xi, yt, z1)], (0, -1, 0))
        col.facing([(xi, yt, z0), (xt, yt, z0), (xt, yt, z1), (xi, yt, z1)], (0, -1, 0))
        strip = side * (CV_LOUNGE_X[0] + CV_OUTER_TOP[0]) / 2
        F.add("light", [(strip - 0.3, yt - 0.02, z0 + 1.0), (strip + 0.3, yt - 0.02, z0 + 1.0),
                        (strip + 0.3, yt - 0.02, z1 - 1.0), (strip - 0.3, yt - 0.02, z1 - 1.0)], (0, -1, 0))
        n_in = (-side, 0, 0)
        F.add("base", [(xo, 1.9, z0), (xt, yt, z0), (xt, yt, z1), (xo, 1.9, z1)], (-side, -1.0, 0))
        col.facing([(xo, 1.9, z0), (xt, yt, z0), (xt, yt, z1), (xo, 1.9, z1)], (-side, -1.0, 0))
        col.facing([(xo, 0.0, z0), (xo, 1.9, z0), (xo, 1.9, z1), (xo, 0.0, z1)], n_in)
        # outer wall: solid below / above the window band, mullions between, reveals out to the hull, glass
        wy0, wy1 = CV_WIN_Y
        F.add("base", [(xo, 0.0, z0), (xo, 0.35, z0), (xo, 0.35, z1), (xo, 0.0, z1)], n_in)
        F.add("base", [(xo, 0.35, z0), (xo, wy0, z0), (xo, wy0, z1), (xo, 0.35, z1)], n_in)
        F.add("base", [(xo, wy1, z0), (xo, 1.9, z0), (xo, 1.9, z1), (xo, wy1, z1)], n_in)
        edges = [z0] + [v for c in CV_WIN_Z for v in (c - CV_WIN_HALF, c + CV_WIN_HALF)] + [z1]
        for k in range(0, len(edges), 2):
            F.add("base", [(xo, wy0, edges[k]), (xo, wy1, edges[k]), (xo, wy1, edges[k + 1]),
                             (xo, wy0, edges[k + 1])], n_in)
        hull_glass, made = vs.Faces(CV_MATERIALS), []
        for c in CV_WIN_Z:
            za, zb = c - CV_WIN_HALF, c + CV_WIN_HALF
            hx = [abs(_hull_x(hull_tris, y, z, side) or abs(xo) + 2.8) for y in (wy0, wy1) for z in (za, zb)]
            outer = side * (max(hx) + 0.15)
            lo, hi = (min(xo, outer), wy0, za), (max(xo, outer), wy1, zb)
            vs.cut_region(hull_xf, vs.box_planes(lo, hi), (lo, hi))
            gx = side * (min(hx) - 0.04)
            F.add("metal", [(xo, wy0, za), (gx, wy0, za), (gx, wy0, zb), (xo, wy0, zb)], (0, 1, 0))
            F.add("metal", [(xo, wy1, za), (gx, wy1, za), (gx, wy1, zb), (xo, wy1, zb)], (0, -1, 0))
            F.add("metal", [(xo, wy0, za), (gx, wy0, za), (gx, wy1, za), (xo, wy1, za)], (0, 0, 1))
            F.add("metal", [(xo, wy0, zb), (gx, wy0, zb), (gx, wy1, zb), (xo, wy1, zb)], (0, 0, -1))
            F.add("glass", [(gx, wy0, za), (gx, wy0, zb), (gx, wy1, zb), (gx, wy1, za)], n_in)
            # the hull side of the pane, and the hull's own reveal from the pane out to the skin
            gxo = gx + side * 0.02
            ox = side * (max(hx) + 0.1)
            hull_glass.add("glass", [(gxo, wy0, za), (gxo, wy0, zb), (gxo, wy1, zb), (gxo, wy1, za)], (side, 0, 0))
            hull_glass.add("metal", [(gx, wy0, za), (ox, wy0, za), (ox, wy0, zb), (gx, wy0, zb)], (0, 1, 0))
            hull_glass.add("metal", [(gx, wy1, za), (ox, wy1, za), (ox, wy1, zb), (gx, wy1, zb)], (0, -1, 0))
            hull_glass.add("metal", [(gx, wy0, za), (ox, wy0, za), (ox, wy1, za), (gx, wy1, za)], (0, 0, 1))
            hull_glass.add("metal", [(gx, wy0, zb), (ox, wy0, zb), (ox, wy1, zb), (gx, wy1, zb)], (0, 0, -1))
            made.append({"z": c, "hull_x": [round(min(hx), 2), round(max(hx), 2)]})
        hull_glass.build(root + "|r0|mesh", f"{cname}_windows", sgs)
        windows[cname] = made
        ops = {"z1": [(min(da, db), max(da, db), ldoor[2])]}
        finish_cell(cell, F, col, sgs, split_floor((lo_x, hi_x, z0, z1), 0.0, ops), cname)
        room_lights(cell, (lo_x, hi_x, z0, z1), 0.0, CV_LOUNGE_H, points=3, intensity=0.75)
        pa, pb_ = min(da, db), max(da, db)
        P.append(vs.portal(root, 9, idx, [(pa, 0.0, z1), (pb_, 0.0, z1), (pb_, ldoor[2], z1), (pa, ldoor[2], z1)],
                           (side * 9.0, 1.5, 50.0), door_style=DOOR_STYLE))
        px = xo + side * 0.01
        P.append(vs.portal(root, 0, idx, [(px, wy0, z0 + 0.5), (px, wy0, z1 - 0.5), (px, wy1, z1 - 0.5),
                                          (px, wy1, z0 + 0.5)], (side * 9.0, 1.5, 44.0), passable=False))
    out["windows"] = windows

    # --- r12 companionway: from the cross hall down aft into the keel --------------------------------------------
    cell = new_cell(root, 12, "companionway")
    F, col = vs.Faces(CV_MATERIALS), pb.MeshAccumulator()
    cx, (zb_, zt) = CV_COMP_X, CV_COMP_Z
    hgt = CV_LOUNGE_H
    for s in (1, -1):
        poly = [(s * cx, 0.0, zt), (s * cx, CV_LOWER, zb_), (s * cx, CV_LOWER + hgt, zb_), (s * cx, hgt, zt)]
        F.add("base", poly, (-s, 0, 0))
        col.facing(poly, (-s, 0, 0))
        # handrail along the wall
        F.add("metal", [(s * (cx - 0.06), 0.9, zt), (s * (cx - 0.06), CV_LOWER + 0.9, zb_),
                         (s * (cx - 0.06), CV_LOWER + 1.0, zb_), (s * (cx - 0.06), 1.0, zt)], (-s, 0, 0))
    up = (0.0, 1.0, CV_LOWER / (zt - zb_))
    F.add("grate", [(-cx, 0.0, zt), (cx, 0.0, zt), (cx, CV_LOWER, zb_), (-cx, CV_LOWER, zb_)], up)
    down = (0.0, -1.0, -up[2])
    F.add("ceiling", [(-cx, hgt, zt), (cx, hgt, zt), (cx, CV_LOWER + hgt, zb_), (-cx, CV_LOWER + hgt, zb_)], down)
    F.add("light", [(-0.25, hgt - 0.03, zt - 1.0), (0.25, hgt - 0.03, zt - 1.0),
                    (0.25, CV_LOWER + hgt - 0.03, zb_ + 1.0), (-0.25, CV_LOWER + hgt - 0.03, zb_ + 1.0)], down)
    col.facing([(-cx, hgt, zt), (cx, hgt, zt), (cx, CV_LOWER + hgt, zb_), (-cx, CV_LOWER + hgt, zb_)], down)
    finish_cell(cell, F, col, sgs, [[(-cx, 0.0, zt), (cx, 0.0, zt), (cx, CV_LOWER, zb_), (-cx, CV_LOWER, zb_)]],
                "companionway", floor_mat=None)
    warm = (1.0, 0.96, 0.9)
    vs._lights(cell, ((0.62, 0.63, 0.68), 0.42),
               [((0.0, hgt - 0.6, zt - 4.0), warm, 0.7),
                ((0.0, CV_LOWER / 2 + hgt - 0.6, (zt + zb_) / 2), warm, 0.7),
                ((0.0, CV_LOWER + hgt - 0.6, zb_ + 4.0), warm, 0.7)],
               [((0.4, -1.0, 0.2), (0.5, 0.5, 0.48), 1.0), ((-0.3, 1.0, -0.1), (0.2, 0.2, 0.24), 1.0)])
    P.append(vs.portal(root, 9, 12, [(-cx, 0.0, zt), (cx, 0.0, zt), (cx, hgt, zt), (-cx, hgt, zt)],
                       (0.0, -2.0, zt - 5.0)))

    # --- r13 embarkation room on the lower deck ------------------------------------------------------------------
    box = CV_EMBARK
    cell = new_cell(root, 13, "embark")
    F, col = vs.Faces(CV_MATERIALS), pb.MeshAccumulator()
    ops = {"z1": [(-cx, cx, hgt)], "z0": [door()]}
    for side in ("x0", "x1", "z0", "z1"):
        wall(F, col, side, box, CV_LOWER, CV_LOWER + hgt, ops.get(side, ()), pillars=4.0, tag=cell)
    ceiling(F, col, box, CV_LOWER + hgt)
    finish_cell(cell, F, col, sgs, split_floor(box, CV_LOWER, ops), "embark")
    room_lights(cell, box, CV_LOWER, hgt, points=2)
    P.append(vs.portal(root, 12, 13, [(-cx, CV_LOWER, zb_), (cx, CV_LOWER, zb_), (cx, CV_LOWER + hgt, zb_),
                                      (-cx, CV_LOWER + hgt, zb_)], (0.0, CV_LOWER + 1.5, 27.0)))
    out["keel_halfwidth"] = [(z, y, round(_hull_x(hull_tris, y, z, 1) or -1, 2))
                             for z in (20, 27, 34) for y in (CV_LOWER, CV_LOWER + hgt)]
    return out


def ramp_cell(root, index, room_index, hinge_z, deck_y, ceil_y, ground_y, half_w, deg, direction, mats, tag):
    """An open-air ramp cell at a room's door in the hull's underside: the lowered ramp runs from the room's floor
    edge at hinge_z out along `direction` (+1 forward, -1 aft) down to the ground. Where a walker on the ramp would
    put their head into the hull, a well (lined, roofed at the room's ceiling height) is cut up through the hull; past
    it the cell is a box under the hull, roofed by a non-passable portal. Returns the measurements and portals."""
    sgs = vs._materials(f"swg_{tag}", mats)
    hull_xf = cmds.listRelatives(root + "|r0|mesh", children=True, fullPath=True)
    hull_tris = vs.tri_list([root + "|r0|mesh"])
    x, s = half_w, direction
    tan = math.tan(math.radians(deg))
    length = (deck_y - ground_y) / math.sin(math.radians(deg))
    d_foot = length * math.cos(math.radians(deg))
    Z = lambda d: hinge_z + s * d                       # d: distance out from the hinge
    d_end = d_foot + 0.6
    yb = ground_y - 1.2

    def belly_min(da, db):
        ys = [belly_y(hull_tris, xx, Z(d / 10.0), ground_y - 20.0) for xx in (-x - 0.1, 0.0, x + 0.1)
              for d in range(int(math.floor(da * 10)), int(math.ceil(db * 10)) + 1, 5)]
        ys = [y for y in ys if y is not None and y > ground_y]
        return min(ys) if ys else deck_y

    # the well: where a 2 m walker on the ramp would put their head into the hull
    dw = 0.0
    for _ in range(3):
        top_out = belly_min(dw, d_end) - 0.05
        dw = next((d / 10.0 for d in range(int(d_end * 10), -1, -1)
                   if deck_y - (d / 10.0) * tan + 2.0 > top_out), 0.0)
        dw = min(d_end - 1.0, dw + 0.5)
    top_out = belly_min(dw, d_end) - 0.05
    wb = belly_min(0.0, dw) - 0.05
    # a floor-hatch cell (Portal::isPassable): with the ramp up it admits no one, so its door stays shut
    cell = new_cell(root, index, RAMP_CELL, see_world=True)
    zlo, zhi = sorted((Z(0.0), Z(dw)))
    lo, hi = (-x, wb - 0.5, zlo), (x, ceil_y, zhi)
    vs.cut_region(hull_xf, vs.box_planes(lo, hi), (lo, hi))
    F = vs.Faces(mats)
    for sx in (1, -1):
        F.add("metal", [(sx * x, wb, Z(0)), (sx * x, wb, Z(dw)), (sx * x, ceil_y, Z(dw)), (sx * x, ceil_y, Z(0))],
              (-sx, 0, 0))
    F.add("metal", [(-x, top_out, Z(dw)), (x, top_out, Z(dw)), (x, ceil_y, Z(dw)), (-x, ceil_y, Z(dw))], (0, 0, -s))
    F.add("ceiling", [(-x, ceil_y, Z(0)), (x, ceil_y, Z(0)), (x, ceil_y, Z(dw)), (-x, ceil_y, Z(dw))], (0, -1, 0))
    F.add("light", [(-0.3, ceil_y - 0.02, Z(0.5)), (0.3, ceil_y - 0.02, Z(0.5)), (0.3, ceil_y - 0.02, Z(dw - 0.5)),
                    (-0.3, ceil_y - 0.02, Z(dw - 0.5))], (0, -1, 0))
    # under the room's deck at the hinge: the plank's slot, the rest plated
    F.add("metal", [(-x, wb, Z(0)), (x, wb, Z(0)), (x, deck_y - 0.25, Z(0)), (-x, deck_y - 0.25, Z(0))], (0, 0, s))
    # the room's bulkhead round its ramp door, seen from the well: cheeks beside the door, the head over it, and the
    # door's collar on this side
    da, db, dtop = door()
    dt = min(deck_y + dtop, ceil_y)
    Pw = lambda u, y, d=0.0: (u, y, Z(d))
    for ua, ub in ((-x, da), (db, x)):
        F.add("base", [Pw(ua, deck_y), Pw(ub, deck_y), Pw(ub, ceil_y), Pw(ua, ceil_y)], (0, 0, s))
    if dt < ceil_y - 1e-3:
        F.add("base", [Pw(da, dt), Pw(db, dt), Pw(db, ceil_y), Pw(da, ceil_y)], (0, 0, s))
    door_collar(F, Pw, (0, 0, s), (1.0, 0.0, 0.0), da, db, deck_y, dt, ceil_y, "metal")
    F.build(cell + "|mesh", tag, sgs)
    gy = ground_y + 0.03
    # the plank's walk floor in three strips, so the door's width of its top edge lies on the doorway portal
    strips = [(-x, da), (da, db), (db, x)]
    vs._floor(cell, [[(xa, deck_y, Z(0)), (xb, deck_y, Z(0)), (xb, gy, Z(d_foot)), (xa, gy, Z(d_foot))]
                     for xa, xb in strips]
              + [[(xa, gy, Z(d_foot)), (xb, gy, Z(d_foot)), (xb, gy, Z(d_end)), (xa, gy, Z(d_end))]
                 for xa, xb in strips])
    inside = (0.0, ground_y + 1.0, Z(d_end / 2))
    P = [
        vs.portal(root, index, room_index, [(da, deck_y, Z(0)), (db, deck_y, Z(0)), (db, dt, Z(0)), (da, dt, Z(0))],
                  (0.0, deck_y + 1.5, Z(-3.0)), door_style=DOOR_STYLE),
        vs.portal(root, 0, index, [(-x, yb, Z(d_end)), (x, yb, Z(d_end)), (x, top_out, Z(d_end)),
                                   (-x, top_out, Z(d_end))], inside),
        vs.portal(root, 0, index, [(-x, top_out, Z(d_end)), (x, top_out, Z(d_end)), (x, top_out, Z(dw)),
                                   (-x, top_out, Z(dw))], inside, passable=False),
        vs.portal(root, 0, index, [(-x, yb, Z(d_end)), (x, yb, Z(d_end)), (x, yb, Z(0)), (-x, yb, Z(0))], inside,
                  passable=False),
        vs.portal(root, 0, index, [(-x, yb, Z(0)), (x, yb, Z(0)), (x, wb, Z(0)), (-x, wb, Z(0))], inside,
                  passable=False),
    ]
    for sx in (1, -1):
        P.append(vs.portal(root, 0, index, [(sx * x, yb, Z(d_end)), (sx * x, yb, Z(dw)), (sx * x, top_out, Z(dw)),
                                            (sx * x, top_out, Z(d_end))], inside, passable=False))
        P.append(vs.portal(root, 0, index, [(sx * x, yb, Z(dw)), (sx * x, yb, Z(0)), (sx * x, wb, Z(0)),
                                            (sx * x, wb, Z(dw))], inside, passable=False))
    vs._lights(cell, ((0.75, 0.72, 0.68), 0.55), [((0.0, ceil_y - 0.6, Z(dw / 2)), (1.0, 0.95, 0.85), 0.7)],
               [((0.3, -1.0, 0.2), (0.8, 0.75, 0.66), 1.0), ((-0.2, 1.0, -0.1), (0.25, 0.25, 0.28), 1.0)])
    return {"portals": P, "well": sorted((Z(0.0), Z(dw))), "top_out": top_out, "well_bottom": wb,
            "ramp": {"deg": deg, "length": length, "foot_z": Z(d_foot)}}


def corvette_ramp_cell(root):
    """Stage 4: r14 'ramp' at the embarkation room's aft door: the well up through the keel and the open-air box
    round the lowered ramp under the hull."""
    return ramp_cell(root, 14, 13, CV_EMBARK[2], CV_LOWER, CV_LOWER + CV_LOUNGE_H, CV_GROUND, CV_RAMP_HW,
                     CV_RAMP_DEG, -1, CV_MATERIALS, "titan_corvette_ramp")


def corvette_parts(root, export_root=EXPORT, name="titan_corellian_corvette"):
    """Stage 5: the ventral ramp (stowed slid forward into the keel under the embarkation deck: it slides out aft,
    then tilts down) and four forward landing legs."""
    hull_tris = vs.tri_list([root + "|r0|mesh"])
    parts, hps, legs = [], {}, {}
    L = CV_RAMP_LEN + 0.05
    apt = ramp_plank(f"{name}_ramp", L, CV_RAMP_HW - 0.03, export_root, along=-1.0)
    hps["ramp"] = (0.0, CV_LOWER - 0.03, CV_EMBARK[2])
    parts.append({"slot": "ramp", "hp": "ramp", "path": apt, "mode": "rot", "axis": [1.0, 0.0, 0.0],
                  "amount": -CV_RAMP_DEG, "seconds": 8.0, "slide": [0.0, 0.0, L - 0.05]})
    for slot, (x, z) in CV_LEGS.items():
        belly = belly_y(hull_tris, x, z, -60.0)
        hp = (x, belly - 0.15 * CV_GEAR_SCALE, z)
        apt, length = landing_leg_scaled(f"{name}_{slot}", hp, CV_GROUND, scale=CV_GEAR_SCALE, export_root=export_root)
        hps[slot] = hp
        parts.append({"slot": slot, "hp": slot, "path": apt, "mode": "rot", "axis": [1.0, 0.0, 0.0],
                      "amount": 90.0, "seconds": 6.0})
        legs[slot] = {"belly": belly, "length": length, "hp": hp, "pad": 0.45 * CV_GEAR_SCALE}
    return {"parts": parts, "hardpoints": {k: _hp_rows(p) for k, p in hps.items()}, "legs": legs}


def build_corvette(name="titan_corellian_corvette", export_root=EXPORT, export=True):
    info = corvette_import(name)
    root = info.pop("root")
    info.update(corvette_aft_door(root))
    info.update(corvette_rooms(root))
    info["ramp_cell"] = corvette_ramp_cell(root)
    info.update(corvette_parts(root, export_root, name))
    info["landed"] = [[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, -CV_GROUND], [0.0, 0.0, 1.0, 0.0]]
    info["paint"] = _paint("corvette")["defaults"]
    hull = hull_collision_boxes(root, 8.0, 3.0, merge_tol=2.5)
    info["hull_extent"] = box_extent(hull)
    info["collision_boxes"] = landed_collision(hull, CV_GROUND, info["legs"])
    info["lod_paint"] = paint_lods(name, "appearance/lod/corellian_corvette_2005e3_r0_mesh.lod", _paint("corvette")["swap"], export_root)
    info["root"] = root
    if export:
        with quiet():
            info["export"] = pb.export(root, export_root, name)
    return info


def wall_windows(F, hull_glass, hull_xf, hull_tris, axis, sign, plane, band, centres, half, mats_key="metal",
                 lining="base"):
    """Windows through a room wall out to the hull: `axis` "x" (a side wall at x = plane, looking along sign*x) or
    "z" (an end wall at z = plane, looking along sign*z); `band` (y0, y1); `centres` along the wall (z for side walls,
    x for end walls). The hull is cut round each window out to its skin, the reveal is lined (room side in the
    wall finish `lining`, hull side in `mats_key`), both faces glazed.
    Returns a portal polygon per window (just outside the wall plane: one portal over the whole band would let hull
    structure behind the wall show over the wall between the windows) and what was measured."""
    y0, y1 = band
    out_dir = (sign, 0.0, 0.0) if axis == "x" else (0.0, 0.0, sign)

    def P(along, y, depth):
        return (depth, y, along) if axis == "x" else (along, y, depth)

    made = []
    for c in centres:
        a, b = c - half, c + half
        skins = []
        for y in (y0, y1):
            for u in (a, b):
                o = P(u, y, 0.0)
                h = vs.ray_hits(hull_tris, o, out_dir)
                skins.append(h[-1] if h else abs(plane) + 2.0)
        far, near = sign * (max(skins) + 0.15), sign * (min(skins) - 0.04)
        lo = [min(P(a, y0, plane)[i], P(b, y1, far)[i]) for i in range(3)]
        hi = [max(P(a, y0, plane)[i], P(b, y1, far)[i]) for i in range(3)]
        vs.cut_region(hull_xf, vs.box_planes(lo, hi), (lo, hi))
        n_in = tuple(-c_ for c_ in out_dir)
        up, down = (0, 1, 0), (0, -1, 0)
        along_pos = (1, 0, 0) if axis == "z" else (0, 0, 1)
        along_neg = tuple(-v for v in along_pos)
        F.add(lining, [P(a, y0, plane), P(a, y0, near), P(b, y0, near), P(b, y0, plane)], up)
        F.add(lining, [P(a, y1, plane), P(a, y1, near), P(b, y1, near), P(b, y1, plane)], down)
        F.add(lining, [P(a, y0, plane), P(a, y0, near), P(a, y1, near), P(a, y1, plane)], along_pos)
        F.add(lining, [P(b, y0, plane), P(b, y0, near), P(b, y1, near), P(b, y1, plane)], along_neg)
        F.add("glass", [P(a, y0, near), P(b, y0, near), P(b, y1, near), P(a, y1, near)], n_in)
        outer = sign * (max(skins) + 0.1)
        gxo = near + sign * 0.02
        hull_glass.add("glass", [P(a, y0, gxo), P(b, y0, gxo), P(b, y1, gxo), P(a, y1, gxo)], out_dir)
        hull_glass.add(mats_key, [P(a, y0, near), P(a, y0, outer), P(b, y0, outer), P(b, y0, near)], up)
        hull_glass.add(mats_key, [P(a, y1, near), P(a, y1, outer), P(b, y1, outer), P(b, y1, near)], down)
        hull_glass.add(mats_key, [P(a, y0, near), P(a, y0, outer), P(a, y1, outer), P(a, y1, near)], along_pos)
        hull_glass.add(mats_key, [P(b, y0, near), P(b, y0, outer), P(b, y1, outer), P(b, y1, near)], along_neg)
        made.append({"at": c, "skin": [round(min(skins), 2), round(max(skins), 2)]})
    pw = plane + sign * 0.01
    portals = [[P(c - half, y0, pw), P(c + half, y0, pw), P(c + half, y1, pw), P(c - half, y1, pw)] for c in centres]
    return portals, made


def wall_with_band(F, col, side, box, y0, y1, openings, band, centres, half):
    """A room wall whose window band (heights above y0) is left open at `centres` (wall_windows lines them)."""
    x0, x1, z0, z1 = box
    lo, hi = (x0, x1) if side in ("z0", "z1") else (z0, z1)
    b0, b1 = band
    P = lambda u, y: _wall_point(side, box, u, y)
    n = WALL_IN[side]
    wall(F, col, side, box, y0, y0 + b0, openings)
    wall(F, None, side, box, y0 + b1, y1, (), base=0.0)
    edges = [lo] + [v for c in centres for v in (c - half, c + half)] + [hi]
    for k in range(0, len(edges), 2):
        F.add("base", [P(edges[k], y0 + b0), P(edges[k + 1], y0 + b0), P(edges[k + 1], y0 + b1),
                         P(edges[k], y0 + b1)], n)
    if col is not None:
        col.facing([P(lo, y0 + b0), P(hi, y0 + b0), P(hi, y1), P(lo, y1)], n)


# ============================================================================
# Nebulon-B escort frigate (the Empire Strikes Back medical frigate)
# ============================================================================
# The stock Nebulon-B (nebulon_frigate.apt, 472 m) is an exterior only: the forward hull, the deep lower section
# under it (a hull volume from y -97 up, with three disc plates stacked beneath it down to y -147), the spar and the
# engine block. The interior is new and sits in the lower section's core: a lift shaft (one cell; its four landings
# are floors stacked in it, so the stock elevator terminals - elevatorMove - carry players between them) serving the
# embarkation room in the bottom plate, the medical bay, the crew deck and the bridge in the forward pod with its
# window band. The boarding ramp runs forward and down out of the bottom plate. Landed, the frigate stands on two
# short legs under the plates and two long struts under the engine block. Rebel-styled: the corvette's interior set.

NB_HULL = ["appearance/mesh/nebulon_frigate_l0.msh"]
NB_STOCK_LOD = "appearance/lod/nebulon_frigate.lod"
NB_GROUND = -148.6
NB_H = 3.4
NB_LIFT = (-1.6, 1.6, 90.0, 93.2)
NB_ROOMS = [                                    # (cell, floor y, box, height, openings / features)
    ("embark", -133.0, (-3.2, 3.2, 93.2, 110.0), 3.0, {"lift": True, "z1": [door()]}),  # rounded plate
    ("medbay", -94.5, (-7.0, 7.0, 93.2, 118.0), 3.4, {"lift": True, "side_windows": True}),
    ("crewdeck", -77.0, (-7.0, 7.0, 93.2, 118.0), 3.4, {"lift": True, "side_windows": True}),
    ("bridgehall", -55.5, (-2.0, 2.0, 93.2, 130.0), 3.4, {"lift": True, "z1": [door()]}),
    ("bridge", -55.5, (-5.0, 5.0, 130.0, 150.5), 3.4, {"z0": [door()], "front_windows": True}),
]
NB_ROOM = {r[0]: r for r in NB_ROOMS}
NB_WIN_Z = (98.0, 103.0, 108.0, 113.0)
NB_WIN_HALF = 1.6
NB_WIN_BAND = (0.95, 2.05)
NB_BRIDGE_WIN_X = (-2.2, 0.0, 2.2)            # the bridge's forward viewport: three tall panes, slim mullions
NB_BRIDGE_WIN_HALF = 0.95
# the bridge: a rear section (door from the bridge hall, side walls) tapering forward to the viewport; console banks
# line the angled prow walls under tactical displays; a soffit rings a raised, cove-lit ceiling coffer
NB_BRIDGE = {"rear": 130.0, "waist": 141.0, "front": 150.5, "half": 5.0, "prow": 3.4, "soffit": 3.0,
             "coffer_inset": 0.9, "console": 0.75}
NB_BRIDGE_BAND = (0.75, 2.75)
NB_RAMP_HW, NB_RAMP_DEG = 1.8, 30.0
NB_LEGS = {"leg_pl": (4.5, 96.0), "leg_pr": (-4.5, 96.0)}     # under the bottom plate, clear of each other at 5x
NB_STRUTS = {"strut_l": (10.0, -228.0), "strut_r": (-10.0, -228.0)}
NB_MATERIALS = dict(CV_MATERIALS,
                    console=("shader/corv_bridge_console1_2005e3_cesde32.sht", (0.45, 0.47, 0.5), 1.0),
                    screen=("shader/corv_screen_maps_aefb17.sht", (0.9, 0.4, 0.2), 1.0))


def nebulon_shell(name="titan_nebulon_frigate"):
    """Stage 1: a new POB (r0, the lift and the deck rooms; the ramp cell comes with its stage) with the stock hull
    in r0, paint shaders swapped."""
    paint = _paint("nebulon")
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    names = ["r0", "lift"] + [r[0] for r in NB_ROOMS]
    mel.eval(f'createPobTemplate -n "{name}" -cells {len(names)} -layoutSpacing 0')
    root = cmds.ls("|" + name, long=True)[0]
    for i, cname in enumerate(names):
        cell = f"{root}|r{i}"
        if not cmds.attributeQuery("pobCellName", node=cell, exists=True):
            cmds.addAttr(cell, longName="pobCellName", dataType="string")
        cmds.setAttr(cell + ".pobCellName", cname, type="string")
        if not cmds.objExists(cell + "|mesh"):
            cmds.createNode("transform", name="mesh", parent=cell)
        if i and not cmds.attributeQuery("pobCellCanSeeWorld", node=cell, exists=True):
            cmds.addAttr(cell, longName="pobCellCanSeeWorld", attributeType="bool")
        if i:
            feat = NB_ROOM[cname][4] if cname in NB_ROOM else {}
            cmds.setAttr(cell + ".pobCellCanSeeWorld", bool(feat.get("side_windows") or feat.get("front_windows")))
    made, swapped = import_meshes(NB_HULL, root + "|r0|mesh", paint["swap"], "swg_titan_nebulon")
    return {"root": root, "swapped": swapped}


def nebulon_rooms(root):
    """Stage 2: the lift (r1) with a landing per deck and the deck rooms (r2-r6): doors, windows, lights."""
    sgs = vs._materials("swg_titan_nebulon_int", NB_MATERIALS)
    hull_xf = cmds.listRelatives(root + "|r0|mesh", children=True, fullPath=True)
    hull_tris = vs.tri_list([root + "|r0|mesh"])
    x0, x1, z0, z1 = NB_LIFT
    door_ = door()
    out = {"portals": [], "windows": {}}
    P = out["portals"]
    index = {r[0]: i for i, r in enumerate(NB_ROOMS, start=2)}

    def cell_groups(cell):
        for g in ("portals", "collision"):
            if not cmds.objExists(f"{cell}|{g}"):
                cmds.createNode("transform", name=g, parent=cell)
        if not cmds.objExists(cell + "|collision|floor0"):
            cmds.createNode("transform", name="floor0", parent=cell + "|collision")

    # --- r1 lift: one shaft from the embarkation deck to the bridge deck; a closed car per deck (floor, walls,
    # ceiling) stacked in it - elevatorMove carries the rider from car to car, so the shaft between them is never seen
    stops = [(y, h) for _, y, _, h, f in NB_ROOMS if f.get("lift")]
    lift = f"{root}|r1"
    cell_groups(lift)
    F, col = vs.Faces(NB_MATERIALS), pb.MeshAccumulator()
    ytop = stops[-1][0] + stops[-1][1]
    box = (x0, x1, z0, z1)
    landings = []
    for y, h in stops:
        for side in ("x0", "x1", "z0"):
            wall(F, col, side, box, y, y + h, (), tag=f"lift{y}")
        wall(F, col, "z1", box, y, y + h, [door_], tag=f"lift{y}")
        # walk floor split at the door jambs, so the doorway edge lies on the landing portal
        landings += split_floor(box, y, {"z1": [door_]})
        F.add("grate", [(x0, y, z0), (x1, y, z0), (x1, y, z1), (x0, y, z1)], (0, 1, 0))
        ceiling(F, col, box, y + h, beams=False)
    finish_cell(lift, F, col, sgs, landings, "lift", floor_mat=None)
    vs._lights(lift, ((0.62, 0.63, 0.68), 0.45),
               [(((x0 + x1) / 2, y + h - 0.6, (z0 + z1) / 2), (1.0, 0.96, 0.9), 0.6) for y, h in stops],
               [((0.4, -1.0, 0.2), (0.5, 0.5, 0.48), 1.0), ((-0.3, 1.0, -0.1), (0.2, 0.2, 0.24), 1.0)])
    out["lift"] = {"landings": [y for y, _ in stops], "top": ytop}

    # --- deck rooms ---------------------------------------------------------------------------------------------
    for cname, y, box, h, feat in NB_ROOMS:
        idx = index[cname]
        cell = f"{root}|r{idx}"
        cell_groups(cell)
        if cname == "bridge":
            out["windows"][cname] = nebulon_bridge(root, cell, idx, y, h, sgs, hull_xf, hull_tris, P)
            continue
        bx0, bx1, bz0, bz1 = box
        F, col, hull_glass = vs.Faces(NB_MATERIALS), pb.MeshAccumulator(), vs.Faces(NB_MATERIALS)
        ops = {k: v for k, v in feat.items() if k in ("x0", "x1", "z0", "z1")}
        if feat.get("lift"):
            ops["z0"] = [door_]
        windows = []
        for side in ("x0", "x1"):
            if feat.get("side_windows"):
                sign = 1 if side == "x1" else -1
                wall_with_band(F, col, side, box, y, y + h, (), NB_WIN_BAND, NB_WIN_Z, NB_WIN_HALF)
                polys, made = wall_windows(F, hull_glass, hull_xf, hull_tris, "x", sign, bx1 if sign > 0 else bx0,
                                           (y + NB_WIN_BAND[0], y + NB_WIN_BAND[1]), NB_WIN_Z, NB_WIN_HALF)
                windows.append((polys, made, (sign * 3.0, y + 1.5, (bz0 + bz1) / 2)))
            else:
                wall(F, col, side, box, y, y + h, ops.get(side, ()), pillars=4.0, tag=cname)
        wall(F, col, "z0", box, y, y + h, ops.get("z0", ()), tag=cname)
        if feat.get("front_windows"):
            wall_with_band(F, col, "z1", box, y, y + h, (), NB_BRIDGE_BAND, NB_BRIDGE_WIN_X, NB_BRIDGE_WIN_HALF)
            polys, made = wall_windows(F, hull_glass, hull_xf, hull_tris, "z", 1, bz1,
                                       (y + NB_BRIDGE_BAND[0], y + NB_BRIDGE_BAND[1]), NB_BRIDGE_WIN_X, NB_BRIDGE_WIN_HALF)
            windows.append((polys, made, (0.0, y + 1.5, bz1 - 5.0)))
        else:
            wall(F, col, "z1", box, y, y + h, ops.get("z1", ()), tag=cname)
        ceiling(F, col, box, y + h)
        finish_cell(cell, F, col, sgs, split_floor(box, y, ops), cname)
        if hull_glass.acc:
            hull_glass.build(root + "|r0|mesh", f"{cname}_windows", sgs)
        room_lights(cell, box, y, h, points=3 if max(bz1 - bz0, bx1 - bx0) > 20 else 2)
        if feat.get("lift"):
            P.append(vs.portal(root, 1, idx, [(door_[0], y, bz0), (door_[1], y, bz0), (door_[1], y + door_[2], bz0),
                                              (door_[0], y + door_[2], bz0)], (0.0, y + 1.5, bz0 + 3.0),
                               door_style=DOOR_STYLE))
        for polys, made, inside in windows:
            for poly in polys:
                P.append(vs.portal(root, 0, idx, poly, inside, passable=False))
        out["windows"][cname] = [m for _, made, _ in windows for m in made]
    # the bridge hall's fore door into the bridge
    hy, hb = NB_ROOM["bridgehall"][1], NB_ROOM["bridgehall"][2]
    a, b, top = NB_ROOM["bridgehall"][4]["z1"][0]
    P.append(vs.portal(root, index["bridgehall"], index["bridge"],
                       [(a, hy, hb[3]), (b, hy, hb[3]), (b, hy + top, hb[3]), (a, hy + top, hb[3])],
                       (0.0, hy + 1.5, hb[3] + 4.0), door_style=DOOR_STYLE))
    return out


def _offset_poly(poly, d):
    """A convex polygon [(x, z)], counter-clockwise seen from above (x right, z up the page), every edge moved d
    metres inward."""
    n = len(poly)
    lines = []
    for k in range(n):
        (ax, az), (bx, bz) = poly[k], poly[(k + 1) % n]
        L = math.hypot(bx - ax, bz - az)
        nx, nz = -(bz - az) / L, (bx - ax) / L
        lines.append(((ax + nx * d, az + nz * d), (bx - ax, bz - az)))
    out = []
    for k in range(n):
        (p, u), (q, v) = lines[k - 1], lines[k]
        det = u[0] * v[1] - u[1] * v[0]
        t = ((q[0] - p[0]) * v[1] - (q[1] - p[1]) * v[0]) / det
        out.append((p[0] + u[0] * t, p[1] + u[1] * t))
    return out


def _quad_uv(F, key, corners, region, facing):
    """corners [bottom-left, bottom-right, top-right, top-left] seen from the front onto the texture region
    (u0, v0, u1, v1) in image coordinates (v down the image; the exporter writes 1 - v)."""
    u0, v0, u1, v1 = region
    F.add_uv(key, corners, [(u0, 1.0 - v1), (u1, 1.0 - v1), (u1, 1.0 - v0), (u0, 1.0 - v0)], facing)


def nebulon_bridge(root, cell, idx, y, h, sgs, hull_xf, hull_tris, P):
    """The Nebulon's bridge: a rear section with the door from the bridge hall, a prow tapering to a three-pane
    viewport, console banks under tactical displays along the angled prow walls, a soffit and a cove-lit coffer.
    Appends its window portals to P; returns what wall_windows measured."""
    B = NB_BRIDGE
    hw, pw, zr, zw, zf = B["half"], B["prow"], B["rear"], B["waist"], B["front"]
    ys, yc, cd = y + B["soffit"], y + h, B["console"]
    F, col, hull_glass = vs.Faces(NB_MATERIALS), pb.MeshAccumulator(), vs.Faces(NB_MATERIALS)
    dr = door()
    rear_box = (-hw, hw, zr, zw)
    wall(F, col, "z0", rear_box, y, ys, [dr], tag="bridge")
    for side in ("x0", "x1"):
        wall(F, col, side, rear_box, y, ys, (), pillars=3.6, tag="bridge")
    wall_with_band(F, col, "z1", (-pw, pw, zw, zf), y, ys, (), NB_BRIDGE_BAND, NB_BRIDGE_WIN_X, NB_BRIDGE_WIN_HALF)
    polys, made = wall_windows(F, hull_glass, hull_xf, hull_tris, "z", 1, zf,
                               (y + NB_BRIDGE_BAND[0], y + NB_BRIDGE_BAND[1]), NB_BRIDGE_WIN_X, NB_BRIDGE_WIN_HALF)

    # prow walls, each with a console bank along it and two tactical displays over the bank
    L = math.hypot(hw - pw, zf - zw)
    profile = [(cd, 0.0), (cd, 0.8), (0.32, 1.05), (0.0, 1.05)]
    for sx in (1, -1):
        A = (sx * hw, zw)
        al = ((sx * pw - A[0]) / L, 0.0, (zf - zw) / L)
        n = (-sx * (zf - zw) / L, 0.0, -(hw - pw) / L)

        def W(u, yy, d=0.0, A=A, al=al, n=n):
            return (A[0] + al[0] * u + n[0] * d, yy, A[1] + al[2] * u + n[2] * d)

        right = 1 if (n[2] * al[0] - n[0] * al[2]) > 0 else -1
        poly = [W(0.0, y), W(L, y), W(L, ys), W(0.0, ys)]
        F.add("base", poly, n)
        col.facing(poly, n)
        segs = max(1, int(round(L / 1.2)))
        up_fwd = (n[0] * 0.25, 0.68, n[2] * 0.25)
        for k in range(segs):
            ua, ub = L * k / segs, L * (k + 1) / segs
            ul, ur = (ua, ub) if right > 0 else (ub, ua)          # left / right seen from the room
            _quad_uv(F, "console", [W(ul, y, cd), W(ur, y, cd), W(ur, y + 0.8, cd), W(ul, y + 0.8, cd)],
                     (0.0, 0.5, 1.0, 1.0), n)
            _quad_uv(F, "console", [W(ul, y + 0.8, cd), W(ur, y + 0.8, cd), W(ur, y + 1.05, 0.32),
                                    W(ul, y + 1.05, 0.32)], (0.0, 0.0, 0.62, 0.45), up_fwd)
        F.add("metal", [W(0.0, y + 1.05, 0.32), W(L, y + 1.05, 0.32), W(L, y + 1.05, 0.0), W(0.0, y + 1.05, 0.0)],
              (0, 1, 0))
        for u, face in ((0.0, tuple(-c for c in al)), (L, al)):
            F.add("metal", [W(u, y + yy, d) for d, yy in [(0.0, 0.0)] + profile], face)
        for k, region in enumerate(((0.0, 0.0, 1.0, 0.5), (0.0, 0.5, 1.0, 1.0))):
            ua, ub = L * (0.08 + 0.46 * k), L * (0.46 + 0.46 * k)
            ul, ur = (ua, ub) if right > 0 else (ub, ua)
            ya, yb, e = y + 1.45, y + 2.65, right * 0.06
            F.add("metal", [W(ul - e, ya - 0.06, 0.02), W(ur + e, ya - 0.06, 0.02),
                            W(ur + e, yb + 0.06, 0.02), W(ul - e, yb + 0.06, 0.02)], n)
            _quad_uv(F, "screen", [W(ul, ya, 0.04), W(ur, ya, 0.04), W(ur, yb, 0.04), W(ul, yb, 0.04)], region, n)

    # soffit round the room, a raised coffer inside it with a cove light along its step
    outline = [(-hw, zr), (hw, zr), (hw, zw), (pw, zf), (-pw, zf), (-hw, zw)]
    coffer = _offset_poly(outline, B["coffer_inset"])
    down = (0, -1, 0)
    for k in range(len(outline)):
        (ax, az), (bx, bz) = outline[k], outline[(k + 1) % len(outline)]
        (cx, cz), (ex, ez) = coffer[k], coffer[(k + 1) % len(coffer)]
        ring = [(ax, ys, az), (bx, ys, bz), (ex, ys, ez), (cx, ys, cz)]
        F.add("ceiling", ring, down)
        col.facing(ring, down)
        inward = (-(ez - cz), 0.0, ex - cx)
        step = [(cx, ys, cz), (ex, ys, ez), (ex, yc, ez), (cx, yc, cz)]
        F.add("base", step, inward)
        col.facing(step, inward)
        F.add("light", [(cx, ys + 0.03, cz), (ex, ys + 0.03, ez), (ex, ys + 0.11, ez), (cx, ys + 0.11, cz)], inward)
    F.add("ceiling", [(x, yc, z) for x, z in coffer], down)
    col.facing([(x, yc, z) for x, z in coffer], down)
    F.add("light", [(-0.3, yc - 0.02, zr + 2.0), (0.3, yc - 0.02, zr + 2.0), (0.3, yc - 0.02, zf - 3.0),
                    (-0.3, yc - 0.02, zf - 3.0)], down)

    # walk floor: the rear section split at the door jambs and the console ends, the prow between the banks
    # (console fronts: the prow walls moved cd inward)
    a0 = (hw - cd * (zf - zw) / L, zw - cd * (hw - pw) / L)
    xin = lambda z: a0[0] - (hw - pw) / (zf - zw) * (z - a0[1])
    xo, xf = xin(zw), xin(zf)
    xs = [-hw, -xo, dr[0], dr[1], xo, hw]
    floors = [[(xa, y, zr), (xb, y, zr), (xb, y, zw), (xa, y, zw)] for xa, xb in zip(xs, xs[1:])]
    floors += [[(-xo, y, zw), (dr[0], y, zw), (dr[0], y, zf), (-xf, y, zf)],
               [(dr[0], y, zw), (dr[1], y, zw), (dr[1], y, zf), (dr[0], y, zf)],
               [(dr[1], y, zw), (xo, y, zw), (xf, y, zf), (dr[1], y, zf)]]
    for poly in floors:
        F.add("floor", poly, (0, 1, 0))
    F.add("grate", [(-0.6, y + 0.005, zr + 1.0), (0.6, y + 0.005, zr + 1.0), (0.6, y + 0.005, zf - 1.5),
                    (-0.6, y + 0.005, zf - 1.5)], (0, 1, 0))
    finish_cell(cell, F, col, sgs, floors, "bridge", floor_mat=None)
    hull_glass.build(root + "|r0|mesh", "bridge_windows", sgs)
    room_lights(cell, (-hw, hw, zr, zf), y, h, points=3)
    for poly in polys:
        P.append(vs.portal(root, 0, idx, poly, (0.0, y + 1.5, zf - 5.0), passable=False))
    return made


def nebulon_ramp(root):
    """Stage 3: r7 'ramp' forward out of the bottom plate from the embarkation room's front door."""
    _, y, box, h, _ = NB_ROOM["embark"]
    return ramp_cell(root, 2 + len(NB_ROOMS), 2, box[3], y, y + h, NB_GROUND, NB_RAMP_HW, NB_RAMP_DEG, 1, NB_MATERIALS,
                     "titan_nebulon_ramp")


def nebulon_parts(root, export_root=EXPORT, name="titan_nebulon_frigate"):
    """Stage 4: the ramp (stowed slid aft under the embarkation deck, slides out, tilts down), two legs under the
    plates and two long struts under the engine block."""
    hull_tris = vs.tri_list([root + "|r0|mesh"])
    _, y, box, _, _ = NB_ROOM["embark"]
    L = (y - NB_GROUND) / math.sin(math.radians(NB_RAMP_DEG)) + 0.05
    parts, hps, legs = [], {}, {}
    apt = ramp_plank(f"{name}_ramp", L, NB_RAMP_HW - 0.03, export_root, along=1.0)
    hps["ramp"] = (0.0, y - 0.03, box[3])
    parts.append({"slot": "ramp", "hp": "ramp", "path": apt, "mode": "rot", "axis": [1.0, 0.0, 0.0],
                  "amount": NB_RAMP_DEG, "seconds": 7.0, "slide": [0.0, 0.0, -(L - 0.05)]})
    for group, scale in ((NB_LEGS, 5.0), (NB_STRUTS, 9.0)):
        for slot, (x, z) in group.items():
            belly = belly_y(hull_tris, x, z, NB_GROUND - 5.0)
            hp = (x, belly - 0.6 * scale / 3.0, z)
            apt, length = landing_leg_scaled(f"{name}_{slot}", hp, NB_GROUND, scale=scale, export_root=export_root)
            hps[slot] = hp
            parts.append({"slot": slot, "hp": slot, "path": apt, "mode": "rot", "axis": [1.0, 0.0, 0.0],
                          "amount": 90.0, "seconds": 8.0 if scale > 4 else 5.0})
            legs[slot] = {"belly": belly, "length": length, "hp": hp, "pad": 0.45 * scale}
    return {"parts": parts, "hardpoints": {k: _hp_rows(p) for k, p in hps.items()}, "legs": legs}


def build_nebulon(name="titan_nebulon_frigate", export_root=EXPORT, export=True):
    info = nebulon_shell(name)
    root = info.pop("root")
    info.update(nebulon_rooms(root))
    info["ramp_cell"] = nebulon_ramp(root)
    info.update(nebulon_parts(root, export_root, name))
    info["landed"] = [[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, -NB_GROUND], [0.0, 0.0, 1.0, 0.0]]
    info["paint"] = _paint("nebulon")["defaults"]
    hull = hull_collision_boxes(root, 12.0, 6.0, merge_tol=4.0)
    info["hull_extent"] = box_extent(hull)
    info["collision_boxes"] = landed_collision(hull, NB_GROUND, info["legs"])
    info["lod_paint"] = paint_lods(name, NB_STOCK_LOD, _paint("nebulon")["swap"], export_root)
    info["root"] = root
    if export:
        with quiet():
            info["export"] = pb.export(root, export_root, name)
    return info
