"""Atmo Flight Starport built onto the stock ring starport (mun_all_starport_s01_u01) — runs inside Maya with
SwgMayaEditor loaded.

The stock building stays as it is: its 17 cells (foyers, ticketing, arrivals and departures arms) with their own
meshes, floors, lights and prelit vertex colours, and its ring with the corner towers. The open courtyard inside
the ring becomes the landing field:

  field          the courtyard paved from the well's kerb to the ring's wall feet, flush with the well deck; two
                 landing pads on it south of the well
  side halls     one on each side, 24 m deep and curved to follow the ring, two storeys under one roof level with
                 the stock ring roof: a 6 m concourse glazed toward the field (doors out to it) and 18 m of content
                 rooms behind it on the ground floor, open observation rooms over the whole hall upstairs. One
                 welded roof per hall with a continuous coping round it, over the cut edge of the stock roof
  access ways    each hall's end room is built against the stock arm's exit (arrivals on the left, departures on the
                 right): the stock exit portal is re-pointed from the field into that room, so the existing hallways
                 lead straight on into the new halls (the old wide exits become maintenance doors)
  towers         a lift in each hall from its lobby to the upper storey, where the room over it is the control room;
                 the stock control tower keeps its outline: a door in the south gallery, a passage and a lift up
                 inside its pillar to the control room filling its head
  landing well   a round shaft in the middle of the courtyard, open to the sky, six storeys deep, with five rentable
                 hangar bays (2 large, 3 medium) opening off it on every level (exterior space, so a ship flies down
                 and straight in) and a lounge at the back of each; the bottom is a landing pad. Each bay column has a
                 lift up to an access corridor off the sub-ring, which the halls' down lifts reach. Bay 1's top
                 level is the shuttle service's reserved bay: the east hall's departures lift runs straight down
                 to it. The terrain layer cuts the shaft and the bays out (one polygon), and an apron floor
                 at ground level closes the bays' plan outside the building.
  main entry     the stock entry hall (foyer4) becomes a security checkpoint: a barrier line with screening lanes
                 (walk-through scanners, X-ray belts) between the public side and the departures side

Stock geometry inside the new footprint (landings, stairs, field floor) is cut away in place, the new halls' r0
floor (porches) is merged into the stock field floor, and the whole thing exports as one POB.
All coordinates are Maya world space: x, z plan (the importer mirrors engine x)."""

from __future__ import annotations

import math
import struct

import maya.cmds as cmds
import maya.mel as mel
import maya.api.OpenMaya as om

from . import pob_builder as pb
from . import starport as SPV1

STOCK = "mun_all_starport_s01_u01"
DATA = "D:/titan/data/sku.0/sys.client/compiled/game"
C = (-1.5, 0.0)                     # courtyard centre (measured from the stock r0 floor)
# concourse r_in..r_mid (6 m) + content r_mid..r_out (18 m) = 24 m halls; r_out reaches into the ring's inner
# wall (~49.5) so the halls are built onto the ring, no alley between them
R_IN, R_MID, R_OUT = 38.0, 44.0, 50.0       # halls stand back from the landing well's shaft (r 35) behind a walk
MAINT_DOOR = "door_impl_s02"      # the arms' old 7.3 m exits to the courtyard: door-sized maintenance doors now
STEP = 7.5                           # arc grid (degrees): every room edge on an arc is one grid step long
F0 = 0.97                            # stock arm floor height (exits) = hall floor
GROUND = 0.1                         # courtyard ground
DECK_Y = F0 + 7.5                    # upper storey
H_ROOM = DECK_Y - pb.SLAB - F0       # ground storey (concourse and content rooms): one height, under the upper floor
H_CONC = H_ROOM
ROOF_Y = 15.8                        # one roof over both halls, just under the stock ring roof (~16)
UPPER_H = ROOF_Y - DECK_Y
HEADROOM = 3.4                       # over the top step of every flight: full 3.0 m doorways at both ends
# lower sub-ring (underground): a corridor round the north of the courtyard just outside its edge, hangar bays and a
# cantina under the main entrance off its outer side; everything tops out >= 1.5 m under the ground
SUB_Y = F0 - 8.5
SUB_IN, SUB_OUT, SUB_ROOM = 50.0, 56.0, 74.0      # corridor r 50..56, hangars / cantina r 56..74
# landing well: a round shaft open to the sky, and on each of N_LEVELS levels five hangar bays opening off it, round
# the whole shaft (the bays are r0: exterior space, so a ship flies down the shaft and straight in). Sized for the
# landable POB ships (titan_vessels.tab): the shaft takes a VT-49 / YKL-37R (55 x 37 / 50 x 40 m) level; the yacht
# (90.5 m) is longer than the courtyard is wide and lands on the surface pads outside the ring instead.
SHAFT_R = 35.0
RIM_R = SHAFT_R + 0.3                                           # the parapet's outer face: the terrain hole's edge
BAY_H, LEVEL_SLAB = 24.0, 2.0                                   # bay clear height (the yacht stands ~19 m) and floor slab
PITCH, N_LEVELS = BAY_H + LEVEL_SLAB, 6
WELL_Y = [SUB_Y - 1.0 - BAY_H - PITCH * k for k in range(N_LEVELS)]   # bay floors, top level first (under the sub-ring)
RIM_SILL = 1.1                                                  # parapet round the shaft top
EXCLUDE_R = RIM_R                                               # terrain hole: the shaft's rim (and the bays)
# bays: (kind, width, depth past the shaft) - large take the YKL-37R / VT-49 / YT-2400, medium the YT-1300 / shuttle -
# centred on half-grid angles, so each one's access corridor meets a sub-ring cell's outer edge square on. Bay 1 sits
# under the east hall's departures end: its top level is the shuttle service's, reached by the departures lift (the
# hall's "gate", standing in the bay beside the shuttle's berth) - a medium bay 2 m wider, so the lift's column
# stands clear of the shuttle and inside the bay's side wall
BAY_KINDS = {"large": (46.0, 72.0), "medium": (32.0, 58.0), "shuttle": (34.0, 58.0)}
BAYS = [("shuttle", -18.75), ("large", 56.25), ("medium", 131.25), ("large", 206.25), ("medium", 281.25)]
SHUTTLE_BAY, SHUTTLE_LEVEL = 0, 0                               # BAYS index, WELL_Y index
GATE = (-7.5, 0.0)                                              # the departures lift's sector in the east hall
SHUTTLE_LEN, SHUTTLE_U = 43.0, -3.0                             # the shuttle's berth: its length, off the bay's
                                                                # centre line away from the gate lift
LOUNGE_D, LOUNGE_W, LOUNGE_H = 10.0, 14.0, 4.0                  # the private lounge against each bay's back wall
BAY_LIFT = 4.0                                                  # each bay column's lift, behind its lounges
FIELD_Y = 0.0                                                   # the stock courtyard walk floor (r0 floor0) - under GROUND
APRON_Y = FIELD_Y - 0.02                                        # the bays' apron walk floor: under the stock ground floors
PAVE_Y = FIELD_Y + 0.04                                         # field deck and paving: just over the walk floor and the
                                                                # flattened terrain, so feet don't sink into them
TOWERS = [(60.72, 34.69), (-55.38, 40.71), (40.0, -59.39), (-41.79, -59.39)]     # stock domed corner towers
MAT, LIGHT, SP = SPV1.MAT, SPV1.LIGHT, SPV1.SP
# the well's hangar finish: the stock space-station hangar set (all lit a_ shaders; r0 has no cell lights to bake)
BAY_PANELS = SP("newbie_hangar_wall_asb14")                     # panelled hangar wall (the d21 detail-map variants need a second UV set)
SHAFT_PANELS = SP("newbie_hangar_trim_asb14")                   # plain hangar panels: the shaft
BAY_RIBS = SP("landingpad_side_a_asb14")                        # the ribs (pilasters) along bay walls
BAY_CEILING = SP("newbie_hangar_trim_asb14")
BAY_LAMP = SP("newbie_hangar_light_asbe22")                     # emissive wall lamp on each rib
BAY_HAZARD = SP("newbie_hangar_tooth_asb14")                    # warning band at each bay's mouth
RIB_STEP, RIB_W, RIB_D = 8.0, 1.2, 0.6                          # rib spacing along the walls, width, depth


def P(r, a):
    t = math.radians(a)
    return (C[0] + r * math.cos(t), C[1] + r * math.sin(t))


def arc(r, a0, a1):
    """Points on radius r from angle a0 to a1 on the grid (both ends included)."""
    # every grid angle strictly between the ends, so arcs of neighbouring rooms share vertices even when one end is
    # off the grid (the hall end on the departures exit line)
    lo, hi = sorted((a0, a1))
    k0, k1 = math.floor(lo / STEP + 1e-6) + 1, math.ceil(hi / STEP - 1e-6) - 1
    mids = [k * STEP for k in range(k0, k1 + 1) if lo + 1e-6 < k * STEP < hi - 1e-6]
    angs = [a0] + (mids if a1 > a0 else mids[::-1]) + [a1]
    return [P(r, a) for a in angs]


def sector(r0, r1, a0, a1):
    """Annular sector (a0 < a1): inner arc a0->a1, outer arc back. Counter-clockwise in the builder's sense."""
    return pb._ccw(arc(r0, a0, a1) + arc(r1, a1, a0))


def _rad(a, sign=1):
    """Plan direction straight out from the courtyard centre at angle a (sign -1: straight in)."""
    return [sign * math.cos(math.radians(a)), sign * math.sin(math.radians(a))]


def landing(r0, r1, a0, a1, split_inner=False, split_outer=False):
    """Sector whose inner / outer arc also has a vertex at the half-step angle, where a switchback's two flight lanes
    (a0..mid, mid..a1) meet it - so each lane shares a straight wall with it."""
    m = (a0 + a1) / 2
    inner = arc(r0, a0, m)[:-1] + arc(r0, m, a1) if split_inner else arc(r0, a0, a1)
    outer = arc(r1, a1, m)[:-1] + arc(r1, m, a0) if split_outer else arc(r1, a1, a0)
    return pb._ccw(inner + outer)


def _line_r(A, B, r):
    """Point on line AB at distance r from C (the root on the A->B side of the closest approach)."""
    dx, dz = B[0] - A[0], B[1] - A[1]
    fx, fz = A[0] - C[0], A[1] - C[1]
    a = dx * dx + dz * dz
    b = 2 * (fx * dx + fz * dz)
    c = fx * fx + fz * fz - r * r
    disc = max(0.0, b * b - 4 * a * c)
    ts = [(-b - math.sqrt(disc)) / (2 * a), (-b + math.sqrt(disc)) / (2 * a)]
    t = min(ts, key=lambda t: abs(t))
    return (A[0] + dx * t, A[1] + dz * t)


def _ext(A, B, d):
    """Segment AB extended by d at both ends."""
    L = math.hypot(B[0] - A[0], B[1] - A[1])
    ux, uz = (B[0] - A[0]) / L, (B[1] - A[1]) / L
    return (A[0] - ux * d, A[1] - uz * d), (B[0] + ux * d, B[1] + uz * d)


def stock_exits(root):
    """{stock cell index: (A, B, y0, y1, r0 portal node, cell portal node)} for the arm exits to the field."""
    out = {}
    for ci in (15, 16):
        for p in cmds.listRelatives(f"{root}|r{ci}|portals", children=True, fullPath=True) or []:
            if cmds.getAttr(p + ".portalTargetCell") != 0:
                continue
            idx = cmds.getAttr(p + ".buildingPortalIndex")
            shp = cmds.listRelatives(p, shapes=True, fullPath=True)[0]
            v = cmds.xform(shp + ".vtx[*]", q=True, ws=True, t=True)
            pts = [(v[i], v[i + 1], v[i + 2]) for i in range(0, len(v), 3)]
            plan = []
            for x, _, z in pts:
                if not any(abs(x - q[0]) < 1e-3 and abs(z - q[1]) < 1e-3 for q in plan):
                    plan.append((x, z))
            ys = [q[1] for q in pts]
            twin = next(q for q in cmds.listRelatives(f"{root}|r0|portals", children=True, fullPath=True)
                        if cmds.getAttr(q + ".buildingPortalIndex") == idx)
            out[ci] = (plan[0], plan[1], min(ys), max(ys), twin, p)
    return out


# ---------------------------------------------------------------------------------------------------------------
# plan
# ---------------------------------------------------------------------------------------------------------------

class Wing:
    def __init__(self):
        self.rooms, self.doors, self.entrances = [], [], []
        self.cut = []           # convex plan polygons whose stock geometry goes
        self.exit_rooms = {}    # stock cell -> (room name, A, B)
        self.sub_landings = []  # (landing room, angle) where the down-stairs reach the sub-ring
        self.upper_steps = {}   # hall -> [(a, b, free outer radius on the upper storey)]
        self.upper_attach = []  # (hall, room, angle, near point, kind) to join to the upper room over that angle
        self.halls = []         # (side, a0, a1) of each side hall: roof edge and courtyard paving follow them
        self.gate = None        # the departures lift down to the shuttle bay: {"lift", "poly"}

    def room(self, name, poly, role, mat, fy=F0, h=H_ROOM, **extra):
        # one material family for every new room: the stock terminal's own spaceport panels, so the halls read as
        # part of u01 (the v1 per-role palette - cantina, VIP red, teal carpet, medical - clashed)
        mat = "spaceport_b" if mat in ("spaceport_b", "hangar", "cargo") else "spaceport"
        r = {"name": name, "polygon": [list(p) for p in pb._ccw(poly)], "floor_y": fy, "height": h,
             "materials": {k: {"shader": v} for k, v in MAT[mat].items()}, "light": dict(LIGHT.get(role, LIGHT["hall"]))}
        r["materials"]["fixture"] = {"shader": SPV1.FIXTURE}
        r.update(extra)
        self.rooms.append(r)
        return name

    def link(self, a, b, width=2.4, style="open", y=None, near=None, height=3.0):
        d = {"rooms": [a, b], "width": width, "height": height, "style": style}
        if style == "door":
            d.update({"door_style": "door_corl_metal_s01", "height": 3.1})
        if y is not None:
            d["y"] = y
        if near is not None:
            d["near"] = list(near)
        self.doors.append(d)

    def edge_of(self, name, a, b):
        """Index of the room's polygon edge whose midpoint is nearest the midpoint of plan points a, b."""
        poly = next(r for r in self.rooms if r["name"] == name)["polygon"]
        mx, mz = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
        n = len(poly)
        return min(range(n), key=lambda i: ((poly[i][0] + poly[(i + 1) % n][0]) / 2 - mx) ** 2 +
                   ((poly[i][1] + poly[(i + 1) % n][1]) / 2 - mz) ** 2)


def hall(W, side, a0, a1, content, tower, exit_cell, exit_seg, entrances):
    """One curved side hall from angle a0 to a1. content: [(kind, steps)] along the hall from a0 (kind "exit" = the
    access room on the stock exit, "tower" = the lift to the upper storey, "down" = the lift down to the sub-ring). exit_seg: (A, B) of the
    stock exit. Ground storey here; the upper storey over it is laid out by upper() from W.upper_steps."""
    pre = side
    A, B = exit_seg
    steps = W.upper_steps.setdefault(side, [])

    def free(a, b, r):          # what the upper storey may use over (a, b): R_IN .. r
        steps.append((a, b, r))
    conc = []
    a = a0
    while a < a1 - 1e-6:
        b = min(a + 2 * STEP, a1)
        conc.append((a, b))
        a = b
    names = []
    for i, (ca, cb) in enumerate(conc):
        nm = W.room(f"{pre}_boarding{i + 1}", sector(R_IN, R_MID, ca, cb), "terminal", "spaceport" if i % 2 else "spaceport_b",
                    h=H_CONC)
        names.append(nm)
        r = W.rooms[-1]
        inner = [W.edge_of(nm, p, q) for p, q in zip(arc(R_IN, ca, cb), arc(R_IN, ca, cb)[1:])]
        r["windows"] = {"auto": True, "edges": inner, "width": 2.0, "height": 3.0, "sill": 0.9, "spacing": 3.0}
    for p, q in zip(names, names[1:]):
        W.link(p, q, width=4.0, style="open")
    for i in entrances:
        ca, cb = conc[i]
        mid = (ca + cb) / 2
        pts = arc(R_IN, ca, cb)
        seg = min(zip(pts, pts[1:]), key=lambda s: abs(math.degrees(math.atan2((s[0][1] + s[1][1]) / 2 - C[1],
                                                                              (s[0][0] + s[1][0]) / 2 - C[0])) % 360 - mid % 360))
        # a shallow porch: the walk from the shaft's parapet (RIM_R) to the concourse front (R_IN) is under 3 m
        W.entrances.append({"room": names[i], "edge": W.edge_of(names[i], *seg), "width": 2.2, "height": 3.2,
                            "door_style": "door_corl_metal_s01",
                            "porch": {"depth": 0.6, "width": 3.0, "steps": 4, "run": 0.3}})
    for (ca, cb), nm in ((conc[0], names[0]), (conc[-1], names[-1])):
        a_end = conc[0][0] if nm == names[0] else conc[-1][1]
        e = W.edge_of(nm, P(R_IN, a_end), P(R_MID, a_end))
        W.entrances.append({"room": nm, "edge": e, "width": 3.0, "height": 3.2, "door_style": "door_corl_metal_s01",
                            "porch": {"depth": 2.4, "width": 3.8, "steps": max(1, int(round((F0 - GROUND) / 0.2))), "run": 0.35}})

    def conc_at(a):
        return next(names[i] for i, (ca, cb) in enumerate(conc) if ca - 1e-6 <= a <= cb + 1e-6)

    a = a0
    for kind, nsteps in content:
        b = min(a + nsteps * STEP, a1)
        mid = (a + b) / 2
        if kind == "exit":
            Ae, Be = _ext(A, B, 0.6)
            if _radial(A, B):
                outer = max((Ae, Be), key=lambda p: math.hypot(p[0] - C[0], p[1] - C[1]))
                poly = arc(R_MID, a, b) + [outer, P(R_OUT, mid), P(R_OUT, a)]
                edge_pts = (P(R_MID, b), outer)
            else:
                ang = lambda p: math.degrees(math.atan2(p[1] - C[1], p[0] - C[0])) % 360
                lo, hi = sorted((Ae, Be), key=lambda p: (ang(p) - a) % 360)
                poly = arc(R_MID, a, b) + [P(R_OUT, b), hi, lo, P(R_OUT, a)]
                edge_pts = (lo, hi)
            nm = W.room(f"{pre}_access", poly, "terminal", "spaceport", h=H_ROOM)
            W.exit_rooms[exit_cell] = (nm, A, B)
            leaf = pb.DOOR_LEAF[MAINT_DOOR]
            W.entrances.append({"room": nm, "edge": W.edge_of(nm, *edge_pts), "width": leaf[1] + pb.DOOR_FIT_W,
                                "height": leaf[2] + pb.DOOR_FIT_H, "at": [(A[0] + B[0]) / 2, (A[1] + B[1]) / 2],
                                "door_style": MAINT_DOOR, "stock_exit": exit_cell})
            W.link(conc_at(mid), nm, width=3.0, style="open", near=P(R_MID, mid))
            free(a, b, R_OUT)
        elif kind == "tower":
            # lift tower: the lift up to the upper storey straight off the concourse (the content rooms are only
            # R_MID..R_OUT deep), and the room over the concourse in front of it is the control room
            lift = W.room(f"{pre}_tower_lift", sector(R_MID, R_OUT, a, b), "lift", "lift", h=ROOF_Y - F0,
                          levels=[DECK_Y], elevator=True)
            W.link(conc_at(mid), lift, width=2.4, style="open", near=P(R_MID, mid))
            free(a, b, R_MID)
            W.upper_attach.append((side, lift, mid, P(R_MID, mid), "arc"))
            tower.append({"side": side, "lift": lift})
        elif kind in ("down", "gate"):
            # a lift down to the sub-ring (and from there the bays' access corridors), off the concourse; its outer
            # wall is the sub-ring corridor's inner one (R_OUT == SUB_IN). The gate (departures) lift goes on down
            # through the shuttle bay's ceiling to its floor, a door on its inner face opening beside the berth
            gate = kind == "gate"
            fy = WELL_Y[SHUTTLE_LEVEL] if gate else SUB_Y
            lift = W.room(f"{pre}_{'gate' if gate else 'down'}_lift", sector(R_MID, R_OUT, a, b), "lift", "lift", fy=fy,
                          h=F0 + H_ROOM - fy, levels=[SUB_Y, F0] if gate else [F0], elevator=True)
            W.link(conc_at(mid), lift, width=2.4, style="open", y=F0, near=P(R_MID, mid))
            W.sub_landings.append((lift, mid))
            if gate:
                W.entrances.append({"room": lift, "edge": W.edge_of(lift, P(R_MID, a), P(R_MID, b)), "width": 2.2,
                                    "height": 3.2, "door_style": "door_corl_metal_s01"})
                W.gate = {"lift": lift, "poly": sector(R_MID, R_OUT, a, b)}
            free(a, b, R_OUT)
        else:
            role, mat = {"shops": ("shop", "spaceport_b"), "cargo": ("hangar", "hangar"), "cantina": ("cantina", "cantina"),
                         "lounge": ("lounge", "lounge"), "customs": ("office", "office"), "med": ("bath", "med")}[kind]
            nm = W.room(f"{pre}_{kind}", sector(R_MID, R_OUT, a, b), role, mat)
            W.link(conc_at(mid), nm, width=4.0 if kind in ("cantina", "lounge", "shops", "cargo") else 2.4,
                   style="door" if kind == "med" else "arch", near=P(R_MID, mid))
            free(a, b, R_OUT)
        a = b
    # the whole hall volume is cleared of stock, not only the ground rooms' outlines: the stock arm roofs reached
    # in over the stair landings and the stair cores and stood up through the hall roof
    a = a0
    while a < a1 - 1e-6:
        b = min(a + STEP, a1)
        W.cut.append(sector(R_IN, R_OUT, a, b))
        a = b
    W.halls.append((side, a0, a1))
    return names


def upper(W, side):
    """The upper storey over a hall: open observation rooms from the concourse's glazed front (R_IN) back to what
    the ground floor leaves free (towers, stair cores and flights keep their own volume), up to the one roof level.
    Full-depth runs make rooms of up to three grid steps, partial ones their own; neighbours open wide onto each
    other, and the lift, the cab stair and the hall stair's landing join the room beside or in front of them."""
    steps = sorted(W.upper_steps[side])
    groups = []
    for a, b, r in steps:
        g = groups[-1] if groups else None
        if g and abs(g["b"] - a) < 1e-6 and g["r"] == r and len(g["steps"]) < 3:
            g["b"] = b
            g["steps"].append((a, b))
        else:
            groups.append({"a": a, "b": b, "r": r, "steps": [(a, b)]})
    rooms = []
    for i, g in enumerate(groups):
        over_lift = abs(g["r"] - R_MID) < 1e-6
        nm = W.room(f"{side}_{'control' if over_lift else 'upper'}{i + 1}", sector(R_IN, g["r"], g["a"], g["b"]),
                    "control" if over_lift else "observation", "office" if over_lift else "lounge", fy=DECK_Y, h=UPPER_H)
        r = W.rooms[-1]
        inner = [W.edge_of(nm, p, q) for p, q in zip(arc(R_IN, g["a"], g["b"]), arc(R_IN, g["a"], g["b"])[1:])]
        r["windows"] = {"auto": True, "edges": inner, "width": 2.6, "height": 3.4, "sill": 1.0, "spacing": 3.0}
        rooms.append((nm, g))
    for (na, ga), (nb, gb) in zip(rooms, rooms[1:]):
        if abs(ga["b"] - gb["a"]) > 1e-6:
            continue
        depth = min(ga["r"], gb["r"]) - R_IN
        W.link(na, nb, width=min(6.0, depth - 0.8), style="open", y=DECK_Y, near=P(R_IN + depth / 2, ga["b"]),
               height=4.0)

    def room_at(ang, r_min):
        for nm, g in rooms:
            if g["a"] - 1e-6 <= ang <= g["b"] + 1e-6 and g["r"] >= r_min - 1e-6:
                return nm
        return None
    for hall_side, nm, ang, near, how in W.upper_attach:
        if hall_side != side:
            continue
        tgt = room_at(ang, R_MID)   # in front of it: the room over the same angle
        if tgt:
            W.link(nm, tgt, width=2.0, style="open", y=DECK_Y, near=near)


def _radial(A, B):
    """Does the exit segment run outward from the courtyard centre (rather than facing it)?"""
    mx, mz = (A[0] + B[0]) / 2 - C[0], (A[1] + B[1]) / 2 - C[1]
    dx, dz = B[0] - A[0], B[1] - A[1]
    return abs(mx * dx + mz * dz) / (math.hypot(mx, mz) * math.hypot(dx, dz)) > 0.7


def _fan(poly):
    """Convex pieces of a star-shaped polygon: triangles from its vertex centroid."""
    cx = sum(p[0] for p in poly) / len(poly)
    cz = sum(p[1] for p in poly) / len(poly)
    return [[(cx, cz), tuple(poly[i - 1]), tuple(poly[i])] for i in range(len(poly))]


def plan(exits):
    """exits: stock_exits() result. Left hall around the arrivals exit (r16), right hall south of departures (r15)."""
    W = Wing()
    towers = []
    # left (west, -x): 127.5..232.5 deg; the arrivals exit faces the courtyard at ~165-173 deg
    hall(W, "west", 127.5, 232.5, [("down", 1), ("shops", 3), ("exit", 3), ("tower", 2), ("lounge", 2), ("cantina", 3)],
         towers, 16, exits[16][:2], entrances=[1, 4])
    # right (east, +x): from -52.5 deg up to the departures exit, a wall running outward at ~7.5 deg: the hall ends
    # exactly on that line (its angle where it crosses the concourse/content boundary)
    A, B = exits[15][:2]
    L = _line_r(A, B, R_MID)
    a_end = math.degrees(math.atan2(L[1] - C[1], L[0] - C[0]))
    if abs(a_end - round(a_end / STEP) * STEP) < 0.2:      # on the grid but for rounding: no sliver room past it
        a_end = round(a_end / STEP) * STEP
    # the departures gate: the lift down to the sub-ring goes on down to the shuttle bay (it stands in the bay)
    hall(W, "east", -52.5, a_end, [("cargo", 2), ("tower", 2), ("lounge", 2), ("gate", 1), ("exit", 1)], towers,
         15, (A, B), entrances=[1])
    assert abs(-52.5 + 6 * STEP - GATE[0]) < 1e-6
    for side in ("west", "east"):
        upper(W, side)
    subring(W)
    bays(W)
    towers.append(control_tower(W))
    return W, towers


def subring(W):
    """The sub-ring: a corridor (r SUB_IN..SUB_OUT) all the way round under the courtyard's edge, reached by the halls'
    down lifts; the bays' access corridors run out from it, and a cantina opens off its outer side under the main
    entrance."""
    cells = [(k * 2 * STEP, (k + 1) * 2 * STEP) for k in range(int(round(360.0 / (2 * STEP))))]
    names = [W.room(f"sub_corridor{i + 1}", sector(SUB_IN, SUB_OUT, ca, cb), "corridor", "spaceport_b", fy=SUB_Y, h=4.5)
             for i, (ca, cb) in enumerate(cells)]
    for p, q in zip(names, names[1:] + names[:1]):
        W.link(p, q, width=4.0, style="open", y=SUB_Y)

    def cell_at(ang):
        ang %= 360.0
        return next(names[i] for i, (ca, cb) in enumerate(cells) if ca - 1e-6 <= ang <= cb + 1e-6)
    W.sub_cell_at = cell_at
    for lift, ang in W.sub_landings:
        W.link(lift, cell_at(ang), width=2.4, style="open", y=SUB_Y, near=P(SUB_IN, ang))
    nm = W.room("sub_cantina", sector(SUB_OUT, SUB_ROOM, 75.0, 105.0), "cantina", "hangar", fy=SUB_Y, h=6.0)
    cx, cz = P(SUB_ROOM - 5.0, 90.0)
    W.rooms[-1]["stages"] = [{"min": [cx - 7.0, cz - 1.5], "max": [cx + 7.0, cz + 1.5], "height": 0.6,
                              "ramp": {"side": "-z", "width": 1.6, "length": 1.8}}]
    W.link(cell_at(90.0), nm, width=3.0, style="arch", y=SUB_Y, near=P(SUB_OUT, 90.0))


def bay_frame(kind, ang):
    """A bay's plan frame: its centre line runs out from the courtyard centre at `ang`; s is the distance along it,
    u across it (left positive). Returns (width, s_mouth, s_back, to_xz): the mouth is the chord where the bay's
    side walls meet the shaft circle, the back wall is the bay's depth past it."""
    w, depth = BAY_KINDS[kind]
    s_mouth = math.sqrt(SHAFT_R ** 2 - (w / 2) ** 2)
    t = (math.cos(math.radians(ang)), math.sin(math.radians(ang)))
    n = (-t[1], t[0])
    to_xz = lambda s_, u: (C[0] + t[0] * s_ + n[0] * u, C[1] + t[1] * s_ + n[1] * u)
    return w, s_mouth, s_mouth + depth, to_xz


def bays(W):
    """The bays' cells: on every level a private lounge against each bay's back wall (glazed onto the bay, a door
    out to it), and per bay one lift up the back of its column of lounges to an access corridor that runs in at the
    sub-ring's level to the sub-ring corridor. The bays themselves are r0 (bay_fixtures)."""
    for i, (kind, ang) in enumerate(BAYS):
        w, s_mouth, s_back, to_xz = bay_frame(kind, ang)
        pre = f"bay{i + 1}"
        rect = lambda s0, s1, u0, u1: [to_xz(s0, u0), to_xz(s1, u0), to_xz(s1, u1), to_xz(s0, u1)]
        hl = BAY_LIFT / 2
        lift = W.room(f"{pre}_lift", rect(s_back, s_back + BAY_LIFT, -hl, hl), "lift", "lift", fy=WELL_Y[-1],
                      h=SUB_Y + HEADROOM + 0.6 - WELL_Y[-1], levels=sorted(WELL_Y[:-1] + [SUB_Y]), elevator=True)
        s_sub = SUB_OUT * math.cos(math.radians(STEP / 2))       # the sub-ring cell's outer edge, square to the bay
        acc = W.room(f"{pre}_access", rect(s_sub, s_back, -1.5, 1.5), "corridor", "spaceport_b", fy=SUB_Y, h=4.0)
        W.link(W.sub_cell_at(ang), acc, width=2.4, style="open", y=SUB_Y, near=to_xz(s_sub, 0.0))
        W.link(acc, lift, width=2.0, style="open", y=SUB_Y, near=to_xz(s_back, 0.0))
        for k, y in enumerate(WELL_Y):
            lounge = W.room(f"{pre}_l{k + 1}_lounge", rect(s_back - LOUNGE_D, s_back, -LOUNGE_W / 2, LOUNGE_W / 2), "lounge",
                            "lounge", fy=y, h=LOUNGE_H)
            r = W.rooms[-1]
            front = W.edge_of(lounge, to_xz(s_back - LOUNGE_D, -1.0), to_xz(s_back - LOUNGE_D, 1.0))
            r["windows"] = {"auto": True, "edges": [front], "width": 2.4, "height": 2.2, "sill": 0.9, "spacing": 3.0}
            W.entrances.append({"room": lounge, "edge": front, "width": 2.2, "height": 3.2, "door_style": "door_corl_metal_s01"})
            W.link(lounge, lift, width=2.0, style="open", y=y, near=to_xz(s_back, 0.0))
    W.cut.append([P(RIM_R, k * STEP) for k in range(48)])       # the shaft's opening through the courtyard


# the stock control tower: a long metal head on a pillar over the south of the ring (measured from the r0 mesh:
# head x -17..19, z -69..-56, underside 24.8, top 32.9; pillar x -4.5..6.4, z -68..-59.6 from the outer low
# building's roof (8.1) up into the head; ring roof ~16). Its inside becomes the control room. Under the ring's
# south face the stock building is undercut: a gallery open to the field, back wall z -51.2, soffit ~7.7.
TOWER_FLOOR, TOWER_H = 26.0, 6.0
TOWER_HEAD = (-15.5, -68.0, 17.5, -57.0)              # control room plan, inside the head's shell
TOWER_X = (-0.5, 2.5)                                 # passage / lift / vestibule, on the pillar's centre line
GALLERY_BACK = -51.2                                  # the gallery's back wall: the tower's door
LIFT_Z = (-64.0, -61.0)                               # the lift shaft, inside the pillar
PASSAGE_H = 4.0


def control_tower(W):
    """Make the stock control tower usable without changing its outline: a door in the back wall of the gallery
    under the ring's south face, a passage through the ring building to a lift that rises inside the stock pillar
    into the head, and the control room filling the head round the lift's vestibule - glazed all round (window
    portals to r0, so the field and the sky show through the stock head's window band). Nothing is added outside
    the stock tower and ring (every room clears the stock only up to its own top, clear_stock)."""
    x0, x1 = TOWER_X
    lz0, lz1 = LIFT_Z
    passage = W.room("tower_passage", [(x0, lz1), (x1, lz1), (x1, GALLERY_BACK), (x0, GALLERY_BACK)], "corridor",
                     "spaceport", h=PASSAGE_H)
    lift = W.room("tower_lift", [(x0, lz0), (x1, lz0), (x1, lz1), (x0, lz1)], "lift", "lift",
                  h=TOWER_FLOOR + 3.6 - F0, levels=[TOWER_FLOOR], elevator=True)
    hx0, hz0, hx1, hz1 = TOWER_HEAD
    vest = W.room("tower_vestibule", [(x0, lz1), (x1, lz1), (x1, hz1), (x0, hz1)], "corridor", "office",
                  fy=TOWER_FLOOR, h=TOWER_H)
    # the control room wraps the lift and its vestibule (a notch in from the head's north side)
    ctrl = W.room("tower_control", [(hx0, hz0), (hx1, hz0), (hx1, hz1), (x1, hz1), (x1, lz0), (x0, lz0), (x0, hz1),
                                    (hx0, hz1)], "control", "office", fy=TOWER_FLOOR, h=TOWER_H)
    W.rooms[-1]["windows"] = {"auto": True, "width": 2.6, "height": 2.8, "sill": 1.0, "spacing": 3.2}
    W.link(passage, lift, width=2.0, style="open", y=F0)
    W.link(lift, vest, width=2.0, style="open", y=TOWER_FLOOR)
    W.link(vest, ctrl, width=2.4, style="open", y=TOWER_FLOOR, near=(x0, (lz1 + hz1) / 2))
    W.link(vest, ctrl, width=2.4, style="open", y=TOWER_FLOOR, near=(x1, (lz1 + hz1) / 2))
    W.entrances.append({"room": passage, "side": "+z", "width": 2.2, "height": 3.2, "door_style": "door_corl_metal_s01",
                        "porch": {"depth": 2.4, "width": 3.8, "steps": max(1, int(round((F0 - GROUND) / 0.2))), "run": 0.35}})
    return {"passage": passage, "lift": lift, "vestibule": vest, "control": ctrl}


def exclude_circle():
    """Engine-space (building-local) terrain hole over the landing well: the shaft's rim (parapet outer face), as
    (x, z, radius). Written as a "local" circle with a fine AffectorExclude (titan engine): the terrain ends exactly on
    the circle - tiles the edge crosses keep their outside part, their inside height poles moved onto it - so none of it
    lies over the shaft and the ground round the building stays at grade. The circle keeps its offset from
    the building origin and turns with it (the importer mirrors x, so engine x = -Maya x)."""
    return (-C[0], C[1], EXCLUDE_R)


def bay_plan(kind, ang):
    """A bay's whole plan (Maya x, z), counter-clockwise: mouth chord on the shaft circle out to the back of its lift."""
    w, s_mouth, s_back, to_xz = bay_frame(kind, ang)
    s_end = s_back + BAY_LIFT
    return [to_xz(s_mouth, -w / 2), to_xz(s_end, -w / 2), to_xz(s_end, w / 2), to_xz(s_mouth, w / 2)]


def exclude_polygon():
    """Engine-space (building-local) terrain hole: the shaft's rim with every bay's plan run out from its mouth - the
    bays reach past the ring building under open ground, and terrain over an r0 bay would hold anyone in it up at the
    surface (the footprint stands on the higher of terrain and floor). One simple polygon (the bays don't overlap: their
    mouths are apart on the circle and their sides run outward). Engine x = -Maya x."""
    bays_ = sorted(BAYS, key=lambda b: b[1] % 360.0)
    pts = []
    for i, (kind, ang) in enumerate(bays_):
        w, _, s_back, to_xz = bay_frame(kind, ang)
        half = math.degrees(math.asin((w / 2) / EXCLUDE_R))
        s_rim = math.sqrt(EXCLUDE_R ** 2 - (w / 2) ** 2)             # where the bay's sides cross the rim circle
        s_end = s_back + BAY_LIFT
        pts += [to_xz(s_rim, -w / 2), to_xz(s_end, -w / 2), to_xz(s_end, w / 2), to_xz(s_rim, w / 2)]
        a0 = ang + half                                               # open rim up to the next bay's mouth
        k2, a2 = bays_[(i + 1) % len(bays_)]
        a1 = a0 + (a2 - math.degrees(math.asin((BAY_KINDS[k2][0] / 2) / EXCLUDE_R)) - a0) % 360.0
        k = (math.floor(a0 / 3.75 + 1e-6) + 1) * 3.75
        while k < a1 - 0.5:
            pts.append(P(EXCLUDE_R, k))
            k += 3.75
    return [(-x, z) for x, z in pts]


def _clip(poly, a, b, keep_left=True):
    """Convex polygon clipped to one side of the directed line a->b (x, z plan)."""
    side = lambda p: ((b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])) * (1 if keep_left else -1)
    out = []
    for i, p in enumerate(poly):
        q = poly[(i + 1) % len(poly)]
        sp, sq = side(p), side(q)
        if sp >= 0:
            out.append(p)
        if (sp >= 0) != (sq >= 0):
            t = sp / (sp - sq)
            out.append((p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t))
    return out


def _clip_inside(piece, convex):
    """Convex `piece` clipped to the inside of convex polygon `convex` (a list of at most one polygon)."""
    if pb._area(convex) < 0:
        convex = convex[::-1]
    cur = list(piece)
    for i, a in enumerate(convex):
        cur = _clip(cur, a, convex[(i + 1) % len(convex)], keep_left=True)
        if len(cur) < 3:
            return []
    return [cur] if abs(pb._area(cur)) > 1e-3 else []


def _minus_convex(piece, convex):
    """Convex pieces of convex `piece` outside convex polygon `convex`."""
    if pb._area(convex) < 0:
        convex = convex[::-1]
    out, cur = [], list(piece)
    for i, a in enumerate(convex):
        b = convex[(i + 1) % len(convex)]
        outside = _clip(cur, a, b, keep_left=False)
        if len(outside) >= 3 and abs(pb._area(outside)) > 1e-3:
            out.append(outside)
        cur = _clip(cur, a, b, keep_left=True)
        if len(cur) < 3:
            break
    return out


def stock_outline():
    """The stock building's footprint (its .lod's overhead-map outline), Maya plan."""
    import os
    import sys
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if root not in sys.path:
        sys.path.insert(0, root)
    from swg_maya_mcp import iff
    return [(-x, z) for x, z in iff.radar_outline(f"{DATA}/appearance/lod/{STOCK}_r0_mesh.lod")]


def apron(stock_root, name):
    """Ground over the bays wherever the terrain hole leaves them open above: r0 walk floor over every bay's plan
    outside the courtyard (R_PAVE: the courtyard has its own field floor), 2 cm under the field so the stock ground
    floors it runs under (the entrance plaza, the ring's skirt) stay the ones walked on; and paving (render, flush
    with the courtyard paving) where it lies outside the stock building. The yacht pads are cut out of both (they
    bring their own deck). make_atmo_starport makes the walk floor's inner edge (on R_PAVE, under the ring wall)
    uncrossable."""
    outline = stock_outline()
    pads_ = [[(x0, z0), (x1, z0), (x1, z1), (x0, z1)] for x0, z0, x1, z1 in pad_layout()["rects"]]
    court = [P(R_PAVE, k * STEP) for k in range(int(round(360.0 / STEP)))]
    walk_pieces, paved = [], []
    for kind, ang in BAYS:
        cur = _minus_convex(bay_plan(kind, ang), court)
        for pd in pads_:
            cur = [q for c in cur for q in _minus_convex(c, pd)]
        walk_pieces += cur
        paved += [q for c in cur for q in _minus_convex(c, outline)]
    render = pb.MeshAccumulator(pb.UV_SCALE["porch"])
    walk = pb.MeshAccumulator()
    for q in paved:
        render.facing([(x, PAVE_Y, z) for x, z in q], (0, 1, 0))
    # inside the building's outline the stock ground meshes cover most of it; under them (5 cm down) the same paving
    # fills the gaps the terrain hole opened between the ring's parts (the entrance plaza, beside the arms)
    for c in walk_pieces:
        inner = [q for q in _clip_inside(c, outline)]
        for q in inner:
            render.facing([(x, FIELD_Y - 0.05, z) for x, z in q], (0, 1, 0))
    for q in walk_pieces:
        walk.facing([(x, APRON_Y, z) for x, z in q], (0, 1, 0))
    m = render.build("apron_paving", f"{stock_root}|r0|mesh")
    cmds.sets(m, edit=True, forceElement=pb._material(f"swg_{name}_apron_paving", (0.6, 0.6, 0.62), None,
                                                       SP("all_concrete_b_fallback_a2d13")))
    wm = walk.build("apron_floor", f"{stock_root}|r0|collision|floor0")
    pb._hide_helper(wm)
    cmds.sets(wm, edit=True, forceElement="initialShadingGroup")
    return {"pieces": len(walk_pieces), "paved": len(paved), "area": round(sum(abs(pb._area(q)) for q in walk_pieces), 1),
            "y": APRON_Y, "inner_r": R_PAVE, "centre": [-C[0], C[1]]}


def shuttle_berth():
    """The shuttle's parked pose in its bay (engine space, building-local): centre on the bay floor, yaw facing back
    out to the shaft (it backs in, leaves nose first), plus the shaft centre at that level for its approach path."""
    kind, ang = BAYS[SHUTTLE_BAY]
    w, s_mouth, s_back, to_xz = bay_frame(kind, ang)
    s_c = s_mouth + 4.0 + SHUTTLE_LEN / 2
    x, z = to_xz(s_c, SHUTTLE_U)
    fx, fz = -math.cos(math.radians(ang)), -math.sin(math.radians(ang))     # facing: in toward the shaft (Maya)
    yaw = math.degrees(math.atan2(-fx, fz)) % 360.0                           # engine: x mirrored, yaw from +z
    y = WELL_Y[SHUTTLE_LEVEL]
    return {"pos": [-x, y, z], "yaw": round(yaw, 2), "shaft": [-C[0], y, C[1]], "bay": SHUTTLE_BAY + 1,
            "level": SHUTTLE_LEVEL + 1, "mouth_s": s_mouth, "axis_yaw": round((yaw + 180.0) % 360.0, 2),
            "ceiling": y + BAY_H, "lounge": f"bay{SHUTTLE_BAY + 1}_l{SHUTTLE_LEVEL + 1}_lounge"}


def bay_table():
    """Every bay on every level for traffic control (space.atmo.starport_traffic, datatables/space/
    titan_starport_bays.tab), engine space (building-local): the clear floor a ship berths on - from 2 m in from the
    mouth chord (a long hull may overhang the shaft's edge at the bay's centre line) to 1.5 m short of the lounge,
    1 m in from each side wall - as its centre (x, floor y, z), the heading that faces the shaft, and its depth
    (along the bay) and width; the lounge cell; reserved = the shuttle service's."""
    rows = []
    for i, (kind, ang) in enumerate(BAYS):
        w, s_mouth, s_back, to_xz = bay_frame(kind, ang)
        s0, s1 = s_mouth + 2.0, s_back - LOUNGE_D - 1.5
        x, z = to_xz((s0 + s1) / 2, 0.0)
        yaw = math.degrees(math.atan2(math.cos(math.radians(ang)), -math.sin(math.radians(ang)))) % 360.0
        for k, y in enumerate(WELL_Y):
            rows.append({"bay": i + 1, "level": k + 1, "kind": kind, "reserved": int(i == SHUTTLE_BAY and k == SHUTTLE_LEVEL),
                         "x": round(-x, 3), "y": round(y, 3), "z": round(z, 3), "yaw": round(yaw, 2),
                         "depth": round(s1 - s0, 2), "width": round(w - 2.0, 2), "lounge": f"bay{i + 1}_l{k + 1}_lounge"})
    return rows


def spec_from(W, name):
    return {
        "name": name, "rooms": W.rooms, "doors": W.doors,
        "entrances": [{k: v for k, v in e.items() if k != "stock_exit"} for e in W.entrances],
        "lights": True, "trim": True, "flat_terrain": True, "ground_y": GROUND, "collision_meshes": True,
        "window_portals": True, "wall_thickness": 0.35,
        "shell_materials": {"shader": SP("all_concrete_a_fallback_a2d13")},
        "trim_materials": {"shader": SP("spaceport_metl_trim_cs8")},
        "exterior": {"roof": {"shader": SP("all_roof_a_ads16")}, "trim": {"shader": SP("all_trim_c_asb13")},
                     "porch": {"shader": SP("all_concrete_b_fallback_a2d13")}, "window": {"color": (0.5, 0.6, 0.75)}},
        "shell_color": (0.62, 0.62, 0.64),
    }


# ---------------------------------------------------------------------------------------------------------------
# merge into the stock building
# ---------------------------------------------------------------------------------------------------------------

def _portals(cell):
    return cmds.listRelatives(cell + "|portals", children=True, fullPath=True) or []


def _cells(root):
    out = {}
    for c in cmds.listRelatives(root, children=True, fullPath=True) or []:
        s = c.split("|")[-1]
        if s.startswith("r") and s[1:].isdigit():
            out[int(s[1:])] = c
    return out


def merge(stock_root, wing_root, W):
    """Move the wing's cells into the stock building after its 17 cells, renumber portals, re-point the stock arm
    exits into the access rooms, and merge r0 (meshes, portals, floor)."""
    S = _cells(stock_root)
    n_stock = max(S) + 1
    stock_portals = {cmds.getAttr(p + ".buildingPortalIndex") for c in S.values() for p in _portals(c)}
    off = max(stock_portals) + 1
    Wc = _cells(wing_root)
    names = {}
    for k in sorted(Wc):
        if k == 0:
            continue
        names[cmds.getAttr(Wc[k] + ".pobCellName")] = n_stock + k - 1
    # portals: indices after the stock ones, targets into the merged numbering
    for k, c in Wc.items():
        for p in _portals(c):
            cmds.setAttr(p + ".buildingPortalIndex", cmds.getAttr(p + ".buildingPortalIndex") + off)
            t = cmds.getAttr(p + ".portalTargetCell")
            cmds.setAttr(p + ".portalTargetCell", 0 if t == 0 else n_stock + t - 1)
    for k in sorted(Wc):
        if k == 0:
            continue
        # unique names first: parenting next to a same-named node would get it renamed by Maya
        tmp = cmds.rename(Wc[k], f"wingcell_{k}")
        moved = cmds.parent(f"{wing_root}|{tmp}", stock_root)[0]
        cmds.rename(moved, f"r{n_stock + k - 1}")
    # r0: meshes, portals, collision
    s0, w0 = f"{stock_root}|r0", f"{wing_root}|r0"
    for grp in ("mesh", "portals"):
        for ch in cmds.listRelatives(f"{w0}|{grp}", children=True, fullPath=True) or []:
            if grp == "portals":
                ch = f"{w0}|{grp}|" + cmds.rename(ch, f"pw{cmds.getAttr(ch + '.buildingPortalIndex')}")
            cmds.parent(ch, f"{s0}|{grp}")
    for ch in cmds.listRelatives(f"{w0}|collision|floor0", children=True, fullPath=True) or []:
        cmds.parent(ch, f"{s0}|collision|floor0")
    for ch in cmds.listRelatives(f"{w0}|collision", children=True, fullPath=True) or []:
        nm = ch.split("|")[-1]
        if nm == "floor0":
            continue
        if cmds.objExists(f"{s0}|collision|{nm}"):
            # fold into the existing group: a second "extent" would be renamed "extent1", and the exporters only
            # read rN|collision|extent (walk-floor wall feet and the CMSH) - the halls' outside walls were lost
            for g in cmds.listRelatives(ch, children=True, fullPath=True) or []:
                cmds.parent(g, f"{s0}|collision|{nm}")
        else:
            cmds.parent(ch, f"{s0}|collision")
    cmds.delete(wing_root)
    S = _cells(stock_root)
    # the arm's old full-width exit to the courtyard becomes a maintenance door into the access room: the access
    # room's door-sized entrance pair is re-pointed from r0 to the arm (the arm stands where the courtyard was),
    # the stock pair goes, and the rest of the old opening is walled up on the arm side
    rewired = []
    for ci, (nm, A, B) in W.exit_rooms.items():
        cell = names[nm]
        mx, mz = (A[0] + B[0]) / 2, (A[1] + B[1]) / 2

        def near_exit(p):
            bb = cmds.exactWorldBoundingBox(p)
            return abs((bb[0] + bb[3]) / 2 - mx) < 1.0 and abs((bb[2] + bb[5]) / 2 - mz) < 1.0
        wing_r0 = next(p for p in _portals(S[0]) if cmds.getAttr(p + ".portalTargetCell") == cell and near_exit(p))
        idx = cmds.getAttr(wing_r0 + ".buildingPortalIndex")
        wing_in = next(q for q in _portals(S[cell]) if cmds.getAttr(q + ".buildingPortalIndex") == idx)
        stock_r0 = next(p for p in _portals(S[0]) if cmds.getAttr(p + ".portalTargetCell") == ci)
        arm = next(p for p in _portals(S[ci]) if cmds.getAttr(p + ".portalTargetCell") == 0)
        old = _quad(arm)
        door = _quad(wing_in)
        cmds.delete(stock_r0, arm)
        wing_r0 = S[0] + "|portals|" + cmds.rename(wing_r0, f"pmaint{ci}")
        moved = cmds.parent(wing_r0, S[ci] + "|portals")[0]
        cmds.setAttr(moved + ".portalTargetCell", cell)
        cmds.setAttr(wing_in + ".portalTargetCell", ci)
        _close_old_exit(S[ci], old, door)
        rewired.append({"stock_cell": ci, "access_cell": cell, "portal": idx, "door": MAINT_DOOR})
    # compact portal indices (0..n-1, each used by exactly two nodes)
    allp = [p for c in S.values() for p in _portals(c)]
    used = sorted({cmds.getAttr(p + ".buildingPortalIndex") for p in allp})
    remap = {old: i for i, old in enumerate(used)}
    for p in allp:
        cmds.setAttr(p + ".buildingPortalIndex", remap[cmds.getAttr(p + ".buildingPortalIndex")])
    counts = {}
    for p in allp:
        i = cmds.getAttr(p + ".buildingPortalIndex")
        counts[i] = counts.get(i, 0) + 1
    unpaired = [i for i, n in counts.items() if n != 2]
    return {"cells": len(S), "portals": len(used), "rewired": rewired, "unpaired": unpaired, "cell_of": names}


def _quad(portal):
    """(plan end points along the opening, y bottom, y top) of a portal node's quad."""
    v = cmds.xform(cmds.listRelatives(portal, shapes=True, fullPath=True)[0] + ".vtx[*]", q=True, ws=True, t=True)
    pts = [(v[i], v[i + 1], v[i + 2]) for i in range(0, len(v), 3)]
    plan = []
    for x, _, z in pts:
        if not any(abs(x - q[0]) < 1e-3 and abs(z - q[1]) < 1e-3 for q in plan):
            plan.append((x, z))
    ys = [q[1] for q in pts]
    return plan[0], plan[1], min(ys), max(ys)


def _close_old_exit(cell, old, door):
    """Wall up the arm's old opening around the maintenance door, on the arm side, in the arm's own material, and
    split the arm's floor edge at the door jambs so only the door span stays a portal edge (the walled parts
    become wall feet)."""
    (A, B, y0, y1), (J0, J1, _, dy1) = old, door
    L = math.hypot(B[0] - A[0], B[1] - A[1])
    t = ((B[0] - A[0]) / L, (B[1] - A[1]) / L)
    u = lambda p: (p[0] - A[0]) * t[0] + (p[1] - A[1]) * t[1]
    j0, j1 = sorted((u(J0), u(J1)))
    floor = _mesh_transforms(cell + "|collision|floor0")
    fb = cmds.exactWorldBoundingBox(floor[0])
    fc = ((fb[0] + fb[3]) / 2, (fb[2] + fb[5]) / 2)
    n = (-t[1], t[0])
    if (fc[0] - A[0]) * n[0] + (fc[1] - A[1]) * n[1] < 0:      # face into the arm
        n = (-n[0], -n[1])
    P = lambda uu, y: (A[0] + t[0] * uu + n[0] * 0.01, y, A[1] + t[1] * uu + n[1] * 0.01)
    acc = pb.MeshAccumulator(pb.UV_SCALE["shell"])
    want = (n[0], 0.0, n[1])
    yb = y0 - 0.3
    for a_, b_ in ((-0.05, j0), (j1, L + 0.05)):
        if b_ - a_ > 0.02:
            acc.facing([P(a_, yb), P(b_, yb), P(b_, y1), P(a_, y1)], want)
    if y1 - dy1 > 0.02:
        acc.facing([P(j0, dy1), P(j1, dy1), P(j1, y1), P(j0, y1)], want)
    meshes = _mesh_transforms(cell + "|mesh")
    sg = pb._dominant_sg_near(meshes, A, t, n, (-1.0, L + 1.0), (0.0, 4.0), (y0, y1 + 1.0))
    m = acc.build("maintenance_wall", cell + "|mesh")
    if m:
        cmds.sets(m, edit=True, forceElement=sg or "initialShadingGroup")
        col = pb.MeshAccumulator()
        pb._append(col, acc)
        pb._collision_mesh(col, "maintenance_wall_collision", cell + "|collision")
    # floor: split along vertical planes through the jambs (across the exit line)
    rot = (0.0, math.degrees(math.atan2(t[0], t[1])), 0.0)
    for jj in (j0, j1):
        cx, cz = A[0] + t[0] * jj, A[1] + t[1] * jj
        faces = []
        sel = om.MSelectionList()
        sel.add(floor[0])
        it = om.MItMeshPolygon(sel.getDagPath(0))
        while not it.isDone():
            c = it.center(om.MSpace.kWorld)
            if math.hypot(c.x - cx, c.z - cz) < L:
                faces.append(it.index())
            it.next()
        if faces:
            cmds.polyCut([f"{floor[0]}.f[{f}]" for f in faces], cutPlaneCenter=(cx, y0, cz), cutPlaneRotate=rot,
                         extractFaces=False, deleteFaces=False, ch=False)


def _mesh_transforms(group):
    shapes = cmds.listRelatives(group, allDescendents=True, type="mesh", fullPath=True) or []
    return sorted({cmds.listRelatives(s, parent=True, fullPath=True)[0] for s in shapes
                   if not cmds.getAttr(s + ".intermediateObject")})


def clear_stock(W, wing_root, stock_meshes, stock_floor, stock_collision=()):
    """Cut the stock r0 render meshes and field floor inside the new footprint: exactly the ground rooms' outlines
    (their outer walls stand on the cut, so the floor's hole edges become wall feet) and the porches, whose own
    floor replaces the stock one there."""
    pieces = []
    for r in W.rooms:
        # each room clears the stock only up to its own top (where its roof goes): a stair flight down from the
        # field or the tower's passage running in under the ring building must not slot the ring's face and roof
        # above it. The halls' whole volume is cleared by their W.cut sectors.
        top = (r.get("slope") or {}).get("ceiling_y") or r["floor_y"] + r["height"]
        if r["floor_y"] <= F0 + 0.05 and top >= F0 + 1.0:
            pieces += [(p, top + 0.05) for p in _fan(r["polygon"])]
    pieces += [(list(map(tuple, p)), 30.0) for p in W.cut]
    for poly, y1 in pieces:
        pb.cut_plan_prism(stock_meshes, poly, -2.0, y1)
        pb.cut_plan_prism(stock_floor, poly, -2.0, 3.0)
        if stock_collision:
            pb.cut_plan_prism(list(stock_collision), poly, -2.0, y1)
    import maya.api.OpenMaya as om
    for m in _mesh_transforms(f"{wing_root}|r0|collision|floor0"):
        sel = om.MSelectionList()
        sel.add(m)
        fn = om.MFnMesh(sel.getDagPath(0))
        pts = fn.getPoints(om.MSpace.kWorld)
        for f in range(fn.numPolygons):
            tri = [(pts[v].x, pts[v].z) for v in fn.getPolygonVertices(f)]
            if abs(pb._area(tri)) > 1e-4:
                pb.cut_plan_prism(stock_floor, tri, -2.0, 3.0)
    return len(pieces)


def merge_floor(stock_root):
    """One r0 floor mesh: the cut stock field floor + the halls' porches, vertices welded."""
    grp = f"{stock_root}|r0|collision|floor0"
    ms = _mesh_transforms(grp)
    if len(ms) > 1:
        # imported stock floors face down in Maya (mirrored X), built ones face up; each exports right on its own,
        # but united they must agree or one set comes out flipped: turn the others to match the stock floor
        import maya.api.OpenMaya as om

        def facing(m):
            # area-weighted y of the triangle normals; plain MFnMesh (MItMeshPolygon crashed Maya on freshly built
            # and freshly cut floors)
            sel = om.MSelectionList()
            sel.add(m)
            fn = om.MFnMesh(sel.getDagPath(0))
            pts = fn.getPoints(om.MSpace.kWorld)
            _, ids = fn.getTriangles()
            ny = 0.0
            for t in range(0, len(ids), 3):
                a_, b_, c_ = pts[ids[t]], pts[ids[t + 1]], pts[ids[t + 2]]
                ny += (b_.z - a_.z) * (c_.x - a_.x) - (b_.x - a_.x) * (c_.z - a_.z)
            return ny
        ref = facing(max(ms, key=lambda m: cmds.polyEvaluate(m, face=True)))
        for m in ms:
            if facing(m) * ref < 0:
                cmds.polyNormal(m, normalMode=0, userNormalMode=0, ch=False)
        cmds.createNode("transform", name="keep_floor0", parent=grp)    # polyUnite deletes groups it empties
        united = cmds.polyUnite(ms, ch=False, mergeUVSets=1, name="floor0_merged")[0]
        united = cmds.parent(united, grp)[0]
        cmds.delete(f"{grp}|keep_floor0")
        cmds.polyMergeVertex(united, d=0.02, ch=False)
        for m in ms:
            if cmds.objExists(m):
                cmds.delete(m)
        pb._hide_helper(united)
        cmds.sets(united, edit=True, forceElement="initialShadingGroup")
        return united
    return ms[0] if ms else None


def _floor_height(floor_mesh, x, z):
    """Height of the floor mesh at plan point (x, z) (highest hit), or None."""
    import maya.api.OpenMaya as om
    sel = om.MSelectionList()
    sel.add(floor_mesh)
    fn = om.MFnMesh(sel.getDagPath(0))
    r = fn.closestIntersection(om.MFloatPoint(x, 50.0, z), om.MFloatVector(0, -1, 0), om.MSpace.kWorld, 100.0, False)
    return r[0].y if r and r[3] >= 0 else None


def _iff_blocks(data, pos=0, end=None):
    """(tag, payload) for every chunk in an IFF byte string, forms flattened depth first."""
    end = len(data) if end is None else end
    while pos + 8 <= end:
        tag = data[pos:pos + 4].decode("latin1")
        n = int.from_bytes(data[pos + 4:pos + 8], "big")
        if tag == "FORM":
            yield from _iff_blocks(data, pos + 12, pos + 8 + n)
        else:
            yield tag, data[pos + 8:pos + 8 + n]
        pos += 8 + n


def stock_collision_mesh(cell):
    """Turn a stock cell's verbatim collision extent (pobCellCollisionExtent, carried over by importPob) into an
    authored mesh under rN|collision|extent, so cuts and additions reach the exported CMSH (the verbatim bytes win
    over authored meshes on export). Engine space mirrors X; the triangle order is kept, which round-trips."""
    if not cmds.attributeQuery("pobCellCollisionExtent", node=cell, exists=True):
        return None
    hexs = cmds.getAttr(cell + ".pobCellCollisionExtent") or ""
    if len(hexs) < 16:
        return None
    blocks = list(_iff_blocks(bytes.fromhex(hexs)))
    pts, tris = [], []
    verts = None
    for tag, data in blocks:
        if tag == "VERT":
            verts = [struct.unpack_from("<3f", data, i) for i in range(0, len(data), 12)]
        elif tag == "INDX" and verts is not None:
            base = len(pts)
            pts += [(-x, y, z) for x, y, z in verts]
            ix = struct.unpack_from(f"<{len(data) // 4}i", data)
            tris += [(base + ix[i], base + ix[i + 1], base + ix[i + 2]) for i in range(0, len(ix) - 2, 3)]
            verts = None
    if not tris:
        return None
    grp = cell + "|collision|extent"
    if not cmds.objExists(grp):
        cmds.createNode("transform", name="extent", parent=cell + "|collision")
    xf = grp + "|" + cmds.createNode("transform", name="stock_collision", parent=grp).split("|")[-1]
    sel = om.MSelectionList()
    sel.add(xf)
    om.MFnMesh().create([om.MPoint(*q) for q in pts], [3] * len(tris), [i for t in tris for i in t],
                        parent=sel.getDependNode(0))
    cmds.sets(xf, edit=True, forceElement="initialShadingGroup")
    pb._hide_helper(xf)
    cmds.setAttr(cell + ".pobCellCollisionExtent", "", type="string")
    return xf


def _ring_pt(r, a, y):
    x, z = P(r, a)
    return (x, y, z)


def bay_fixtures(stock_root, name, W):
    """r0 geometry of the landing well: the round shaft from the courtyard down to the bottom level (a parapet round
    its rim, one mouth per bay on every level), and the bays - floor (landing-deck grating, walkable), ceiling with
    light strips, side and back walls. The bottom level's floor runs on across the shaft as the landing pad. Walkable
    floors go to r0's floor (cut round the lounges, which bring their own), every face to r0's collision (facing the
    open side). Returns the mouth chords (make_atmo_starport types those floor edges uncrossable: a 26 m drop)."""
    mg, cg = f"{stock_root}|r0|mesh", f"{stock_root}|r0|collision"
    walls = pb.MeshAccumulator(6.0)             # the shaft: hangar panels
    panels = pb.MeshAccumulator(8.0)            # bay walls: panelled hangar wall, a texture repeat every 8 m
    ribs = pb.MeshAccumulator(4.0)
    lamps = pb.MeshAccumulator(fit=True)
    hazard = pb.MeshAccumulator(1.5)
    floors = pb.MeshAccumulator(8.0)            # landing-deck grating, tiled every 8 m
    ceil = pb.MeshAccumulator(6.0)
    trim = pb.MeshAccumulator(1.0)
    walk = pb.MeshAccumulator()
    pad = pb.MeshAccumulator(fit=True)
    lights = pb.MeshAccumulator(fit=True)
    y_bot, y_top = WELL_Y[-1], GROUND + RIM_SILL
    inward = lambda a: (-math.cos(math.radians(a)), 0.0, -math.sin(math.radians(a)))
    outward = lambda a: (math.cos(math.radians(a)), 0.0, math.sin(math.radians(a)))
    frames = [(kind, ang) + bay_frame(kind, ang) for kind, ang in BAYS]
    mouths = []                                   # (a0, a1) of each bay's opening in the shaft wall
    for kind, ang, w, s_mouth, s_back, to_xz in frames:
        half = math.degrees(math.asin((w / 2) / SHAFT_R))
        mouths.append((ang - half, ang + half))
    # shaft wall: 3.75 deg facets, split at the mouths' edges; a mouth's wall has holes over every level's bay
    cuts = sorted({k * 3.75 for k in range(96)} | {m % 360.0 for pair in mouths for m in pair})
    cuts.append(cuts[0] + 360.0)
    for a, b in zip(cuts, cuts[1:]):
        m = (a + b) / 2
        in_mouth = any(((m - m0) % 360.0) < ((m1 - m0) % 360.0) for m0, m1 in mouths)
        spans = [(y_bot, y_top)]
        if in_mouth:
            for y in WELL_Y:
                spans = [piece for lo, hi in spans for piece in ((lo, min(hi, y)), (max(lo, y + BAY_H), hi)) if piece[1] - piece[0] > 1e-3]
        for lo, hi in spans:
            walls.facing([_ring_pt(SHAFT_R, a, lo), _ring_pt(SHAFT_R, b, lo), _ring_pt(SHAFT_R, b, hi), _ring_pt(SHAFT_R, a, hi)], inward(m))
        # the rim's parapet: cap and outer face, running below grade over the terrain hole's edge
        trim.facing([_ring_pt(SHAFT_R, a, y_top), _ring_pt(RIM_R, a, y_top), _ring_pt(RIM_R, b, y_top), _ring_pt(SHAFT_R, b, y_top)], (0, 1, 0))
        walls.facing([_ring_pt(RIM_R, a, GROUND - 1.0), _ring_pt(RIM_R, b, GROUND - 1.0), _ring_pt(RIM_R, b, y_top),
                      _ring_pt(RIM_R, a, y_top)], outward(m))
    # bottom: the landing pad over the whole shaft floor
    pad.facing([_ring_pt(SHAFT_R, k * 3.75, y_bot + 0.01) for k in range(96)], (0, 1, 0))
    walk.facing([_ring_pt(SHAFT_R, k * 3.75, y_bot) for k in range(96)], (0, 1, 0))
    holes, chords, doors = [], [], []
    dw = pb.DOOR_LEAF["door_corl_metal_s01"][1] + pb.DOOR_FIT_W
    for (kind, ang, w, s_mouth, s_back, to_xz), (m0, m1) in zip(frames, mouths):
        t = (math.cos(math.radians(ang)), 0.0, math.sin(math.radians(ang)))
        n = (-t[2], 0.0, t[0])
        # the bay's near edge follows the shaft circle between its corners: strips from there to the back wall
        k_arc = max(2, int(math.ceil((m1 - m0) / 3.75)))
        arc_pts = [_ring_pt(SHAFT_R, m0 + (m1 - m0) * j / k_arc, 0.0) for j in range(k_arc + 1)]
        us = [((p[0] - C[0]) * n[0] + (p[2] - C[1]) * n[2]) for p in arc_pts]
        back = [to_xz(s_back, u) for u in us]
        for y in WELL_Y:
            yc = y + BAY_H
            Y = lambda q, yy: (q[0], yy, q[2]) if len(q) == 3 else (q[0], yy, q[1])
            for j in range(k_arc):
                quad = [Y(arc_pts[j], y), Y(arc_pts[j + 1], y), Y(back[j + 1], y), Y(back[j], y)]
                floors.facing(quad, (0, 1, 0))
                walk.facing(quad, (0, 1, 0))
                ceil.facing([Y(arc_pts[j], yc), Y(arc_pts[j + 1], yc), Y(back[j + 1], yc), Y(back[j], yc)], (0, -1, 0))
            hw = w / 2
            for u, nrm in ((hw, (-n[0], 0.0, -n[2])), (-hw, n)):
                p0, p1 = to_xz(s_mouth, u), to_xz(s_back, u)
                panels.facing([(p0[0], y, p0[1]), (p1[0], y, p1[1]), (p1[0], yc, p1[1]), (p0[0], yc, p0[1])], nrm)
            bl, br = to_xz(s_back - 0.03, hw), to_xz(s_back - 0.03, -hw)      # 3 cm proud: the lifts' shells share the plane
            panels.facing([(bl[0], y, bl[1]), (br[0], y, br[1]), (br[0], yc, br[1]), (bl[0], yc, bl[1])], (-t[0], 0.0, -t[2]))
            # ribs up the side walls (from the mouth back) and the back wall (either side of the lounge), a lamp on
            # each at two heights; a warning band across the floor at the mouth
            sr = s_mouth + RIB_STEP / 2
            while sr < s_back - RIB_W:
                for sign in (1.0, -1.0):
                    u_in = sign * (hw - RIB_D)
                    _obox(ribs, to_xz, sr - RIB_W / 2, sr + RIB_W / 2, min(u_in, sign * hw), max(u_in, sign * hw), y, yc)
                    for ly in (y + 3.2, y + BAY_H - 6.0):
                        uf = sign * (hw - RIB_D - 0.02)
                        q = [to_xz(sr - 0.45, uf), to_xz(sr + 0.45, uf)]
                        lamps.facing([(q[0][0], ly, q[0][1]), (q[1][0], ly, q[1][1]), (q[1][0], ly + 0.5, q[1][1]),
                                      (q[0][0], ly + 0.5, q[0][1])], (-sign * n[0], 0.0, -sign * n[2]))
                sr += RIB_STEP
            ur = LOUNGE_W / 2 + 2.0 + RIB_W / 2
            while ur < hw - RIB_W:
                for sign in (1.0, -1.0):
                    uc = sign * ur
                    _obox(ribs, to_xz, s_back - RIB_D, s_back, uc - RIB_W / 2, uc + RIB_W / 2, y, yc)
                    for ly in (y + 3.2, y + BAY_H - 6.0):
                        sf_ = s_back - RIB_D - 0.02
                        q = [to_xz(sf_, uc - 0.45), to_xz(sf_, uc + 0.45)]
                        lamps.facing([(q[0][0], ly, q[0][1]), (q[1][0], ly, q[1][1]), (q[1][0], ly + 0.5, q[1][1]),
                                      (q[0][0], ly + 0.5, q[0][1])], (-t[0], 0.0, -t[2]))
                ur += RIB_STEP
            if y != y_bot:
                hb = [to_xz(SHAFT_R + 0.4, -hw + 0.6), to_xz(SHAFT_R + 1.9, -hw + 0.6), to_xz(SHAFT_R + 1.9, hw - 0.6),
                      to_xz(SHAFT_R + 0.4, hw - 0.6)]
                hazard.facing([(x_, y + 0.015, z_) for x_, z_ in hb], (0, 1, 0))
            for uc in (-w / 4, w / 4):          # two light strips down the bay's ceiling
                q = [to_xz(s_mouth + 2.0, uc - 0.4), to_xz(s_back - LOUNGE_D - 1.0, uc - 0.4),
                     to_xz(s_back - LOUNGE_D - 1.0, uc + 0.4), to_xz(s_mouth + 2.0, uc + 0.4)]
                lights.facing([(x, yc - 0.03, z) for x, z in q], (0, -1, 0))
            if y != y_bot:
                chords.append({"y": round(y, 3), "a0": m0, "a1": m1})
        hl, sf = LOUNGE_W / 2, s_back - LOUNGE_D
        # a vertex at each door jamb: only the doorway stays crossable (make_atmo_starport.well_edges walls the rest)
        holes.append([to_xz(sf, -hl), to_xz(s_back, -hl), to_xz(s_back, hl), to_xz(sf, hl), to_xz(sf, dw / 2),
                      to_xz(sf, -dw / 2)])
        doors += [(to_xz(sf, -dw / 2), to_xz(sf, dw / 2), y) for y in WELL_Y]
    built = {}
    for acc, nm, sh in ((walls, "well_walls", SHAFT_PANELS), (floors, "well_floors", SPV1.PAD_DECK),
                        (panels, "well_bay_walls", BAY_PANELS), (ribs, "well_bay_ribs", BAY_RIBS),
                        (lamps, "well_bay_lamps", BAY_LAMP), (hazard, "well_bay_hazard", BAY_HAZARD),
                        (ceil, "well_ceilings", BAY_CEILING), (trim, "well_trim", SP("all_trim_c_asb13")),
                        (pad, "well_pad", SPV1.PAD_DECK), (lights, "well_lights", SPV1.FIXTURE)):
        m = acc.build(nm, mg)
        cmds.sets(m, edit=True, forceElement=pb._material(f"swg_{name}_{nm}", (0.6, 0.6, 0.62), None, sh))
        built[nm] = m
        if acc is lights:           # emissive strip (c_ shader): full-white colour0, r0 has no cell lights to bake
            cmds.polyColorSet(m, create=True, colorSet="swgPrelit", representation="RGBA")
            cmds.polyColorSet(m, currentColorSet=True, colorSet="swgPrelit")
            cmds.polyColorPerVertex(m, rgb=(1.0, 1.0, 1.0), alpha=1.0, colorDisplayOption=True)
    col = pb.MeshAccumulator()
    for acc in (walls, panels, ribs, ceil, trim, floors, pad):
        pb._append(col, acc)
    wcol = pb._collision_mesh(col, "well_collision", cg)
    wm = walk.build("well_floor", f"{cg}|floor0")
    for q in holes:                 # the lounges stand on their own floors: out of the bay's walk and render floor
        for tri in _fan(q):
            pb.cut_plan_prism([wm, built["well_floors"]], tri, y_bot - 1.0, WELL_Y[0] + 1.0)
    if W.gate:                      # the departures lift stands in the shuttle bay: through its ceiling, off its floor
        ys = WELL_Y[SHUTTLE_LEVEL]
        A, B = P(R_MID, GATE[0]), P(R_MID, GATE[1])        # its door: centred on the inner chord, jamb vertices
        L = math.hypot(B[0] - A[0], B[1] - A[1])
        d = ((B[0] - A[0]) / L, (B[1] - A[1]) / L)
        J0 = (A[0] + d[0] * (L - dw) / 2, A[1] + d[1] * (L - dw) / 2)
        J1 = (A[0] + d[0] * (L + dw) / 2, A[1] + d[1] * (L + dw) / 2)
        doors.append((J0, J1, ys))
        for tri in _fan([A, J0, J1, B, P(R_OUT, GATE[1]), P(R_OUT, GATE[0])]):
            pb.cut_plan_prism([wm, built["well_floors"], wcol], tri, ys - 0.5, ys + 0.5)
            pb.cut_plan_prism([built["well_ceilings"], built["well_lights"], wcol], tri, ys + BAY_H - 0.5, ys + BAY_H + 0.5)
    pb._hide_helper(wm)
    cmds.sets(wm, edit=True, forceElement="initialShadingGroup")
    return {"levels": len(WELL_Y), "floor_y": y_bot, "shaft_r": SHAFT_R, "bays": len(frames) * len(WELL_Y), "wall_faces": len(walls.counts),
            "mouth_chords": chords, "levels": list(WELL_Y),
            "doors": [[-a[0], a[1], -b[0], b[1], y] for a, b, y in doors]}       # engine x = -Maya x


def _box(acc, x0, z0, x1, z1, y0, y1):
    """Five faces (no bottom) of an axis-aligned box."""
    acc.facing([(x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)], (0, 1, 0))
    acc.facing([(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)], (0, 0, -1))
    acc.facing([(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)], (0, 0, 1))
    acc.facing([(x0, y0, z0), (x0, y0, z1), (x0, y1, z1), (x0, y1, z0)], (-1, 0, 0))
    acc.facing([(x1, y0, z0), (x1, y0, z1), (x1, y1, z1), (x1, y1, z0)], (1, 0, 0))


def checkpoint(stock_root, name):
    """Security screening in the stock entry hall (foyer4, x -18.6..17.2, z 47.6..69.2): a barrier line splits the
    departures side (east, the exit to the ticket hall) from the public side, with three screening lanes - a
    walk-through scanner arch and an X-ray belt through the barrier at each - and an exit lane back. Queue
    stanchions on the public side, a supervisor's podium on the secure side. Everything that stands on the floor
    is cut out of the walk floor (movement stops at floor edges)."""
    cell = f"{stock_root}|r4"
    floor = _mesh_transforms(cell + "|collision|floor0")
    y = _floor_height(floor[0], 0.0, 58.0) or 0.6
    XB, Z0, Z1, XE = 8.0, 48.2, 65.5, 16.6
    lanes = [51.0, 54.6, 58.2]
    exit_gap = (62.0, 63.6)
    gaps = [(c - 0.6, c + 0.6) for c in lanes] + [exit_gap]
    panel, cap, arch, xray, glass = (pb.MeshAccumulator(1.5) for _ in range(5))
    holes = []
    t = 0.08
    z = Z0
    for g0, g1 in sorted(gaps) + [(Z1, Z1)]:
        if g0 - z > 0.05:
            _box(panel, XB - t, z, XB + t, g0, y, y + 1.15)
            _box(cap, XB - t - 0.03, z, XB + t + 0.03, g0, y + 1.15, y + 1.22)
            holes.append((XB - 0.15, z, XB + 0.15, g0))
        z = g1
    _box(panel, XB, Z1 - t, XE, Z1 + t, y, y + 1.15)
    _box(cap, XB, Z1 - t - 0.03, XE, Z1 + t + 0.03, y + 1.15, y + 1.22)
    holes.append((XB, Z1 - 0.15, XE, Z1 + 0.15))
    for c in lanes:
        for zz in (c - 0.72, c + 0.6):                                   # scanner posts either side of the lane
            _box(arch, XB - 0.25, zz, XB + 0.25, zz + 0.12, y, y + 2.45)
            holes.append((XB - 0.3, zz - 0.02, XB + 0.3, zz + 0.14))
        _box(arch, XB - 0.25, c - 0.72, XB + 0.25, c + 0.72, y + 2.45, y + 2.7)
        tz0, tz1 = c - 1.42, c - 0.78                                   # X-ray belt through the barrier, south side
        _box(xray, XB - 4.0, tz0, XB + 4.0, tz1, y, y + 0.85)
        _box(xray, XB - 1.0, tz0 - 0.05, XB + 1.0, tz1 + 0.05, y + 0.85, y + 1.9)
        holes.append((XB - 4.05, tz0 - 0.05, XB + 4.05, tz1 + 0.05))
    for zq in (52.8, 56.4, 60.0):                                         # queue stanchions on the public side
        for xq in [-6.0 + 1.5 * i for i in range(9)]:
            _box(cap, xq - 0.05, zq - 0.05, xq + 0.05, zq + 0.05, y, y + 0.95)
        _box(glass, -6.0, zq - 0.02, 6.0, zq + 0.02, y + 0.8, y + 0.9)
        holes.append((-6.08, zq - 0.08, 6.08, zq + 0.08))
    _box(panel, 10.0, 60.4, 11.8, 61.4, y, y + 1.1)                     # supervisor's podium
    _box(cap, 9.95, 60.35, 11.85, 61.45, y + 1.1, y + 1.16)
    holes.append((9.95, 60.35, 11.85, 61.45))
    mg = cell + "|mesh"
    for acc, nm, sh in ((panel, "checkpoint_barrier", SP("spaceport_metl_panel5_cs8")), (cap, "checkpoint_rails", SP("spaceport_metl_trim_cs8")),
                        (arch, "checkpoint_scanners", SP("spaceport_metl_base_cs8")), (xray, "checkpoint_xray", SP("spaceport_metl_panel3_cs8")),
                        (glass, "checkpoint_belts", SP("spaceport_metl_trim_cs8"))):
        if acc.counts:
            m = acc.build(nm, mg)
            cmds.sets(m, edit=True, forceElement=pb._material(f"swg_{name}_{nm}", (0.6, 0.6, 0.62), None, sh))
    for x0, z0, x1, z1 in holes:
        pb.cut_plan_prism(floor, [(x0, z0), (x1, z0), (x1, z1), (x0, z1)], y - 0.5, y + 0.5)
    return {"lanes": len(lanes), "floor_holes": len(holes), "floor_y": round(y, 2)}


def _obox(acc, to_xz, s0, s1, u0, u1, y0, y1, bottom=False):
    """A box in a bay's frame (s along its centre line, u across): top and four sides (and the bottom, for things
    lifted off the floor). Normals worked out from the frame, so it needn't be axis-aligned."""
    c = [to_xz(s0, u0), to_xz(s1, u0), to_xz(s1, u1), to_xz(s0, u1)]
    mx, mz = sum(p[0] for p in c) / 4, sum(p[1] for p in c) / 4
    acc.facing([(c[0][0], y1, c[0][1]), (c[1][0], y1, c[1][1]), (c[2][0], y1, c[2][1]), (c[3][0], y1, c[3][1])], (0, 1, 0))
    if bottom:
        acc.facing([(c[0][0], y0, c[0][1]), (c[1][0], y0, c[1][1]), (c[2][0], y0, c[2][1]), (c[3][0], y0, c[3][1])], (0, -1, 0))
    for p, q in zip(c, c[1:] + c[:1]):
        ex, ez = (p[0] + q[0]) / 2 - mx, (p[1] + q[1]) / 2 - mz
        acc.facing([(p[0], y0, p[1]), (q[0], y0, q[1]), (q[0], y1, q[1]), (p[0], y1, p[1])], (ex, 0.0, ez))


def _ray(shapes, origin, direction, reach):
    """Distance along `direction` from `origin` to the nearest surface of mesh `shapes`, or None."""
    best = None
    for m in shapes:
        sel = om.MSelectionList()
        sel.add(m)
        fn = om.MFnMesh(sel.getDagPath(0))
        hit = fn.closestIntersection(om.MFloatPoint(*origin), om.MFloatVector(*direction), om.MSpace.kWorld, reach, False)
        if hit and hit[3] >= 0 and (best is None or hit[1] < best):      # (point, ray param = distance, face, tri, ...)
            best = hit[1]
    return best


def _front_piers(shapes, P3, s_wall, hw, y, top, step=0.1):
    """Solid parts of a lounge front (the plane s = s_wall, |u| < hw, floor y to y + top) as rectangles (u0, u1, y0, y1)
    relative to the floor: each 10 cm column is probed from the bay at 10 cm heights, runs of equal columns merge."""
    nu, nh = int(round(2 * hw / step)), int(round(top / step))
    t = (P3(1.0, 0.0, 0.0)[0] - P3(0.0, 0.0, 0.0)[0], 0.0, P3(1.0, 0.0, 0.0)[2] - P3(0.0, 0.0, 0.0)[2])
    cols = []
    for i in range(nu):
        u = -hw + (i + 0.5) * step
        col = []
        for j in range(nh):
            o = P3(s_wall - 1.0, u, y + (j + 0.5) * step)
            d = _ray(shapes, o, t, 1.3)
            col.append(d is not None)
        cols.append(tuple(col))
    out, i = [], 0
    while i < nu:
        k = i
        while k + 1 < nu and cols[k + 1] == cols[i]:
            k += 1
        j = 0
        while j < nh:
            if cols[i][j]:
                m = j
                while m + 1 < nh and cols[i][m + 1]:
                    m += 1
                out.append((-hw + i * step, -hw + (k + 1) * step, j * step, (m + 1) * step))
                j = m + 1
            else:
                j += 1
        i = k + 1
    return out


def lounge_cladding(stock_root, name):
    """The bay lounges' outsides (the builder gives every room one plain shell): hangar cladding on the sides, the band
    over the windows and the front corners, a roof cap with a fascia, and a canopy over the door with lamps under it -
    measured off the shell itself (rays from the bay), 3 cm proud of it."""
    mg, cg = f"{stock_root}|r0|mesh", f"{stock_root}|r0|collision"
    shapes = [x for x in cmds.listRelatives(mg, allDescendents=True, type="mesh", fullPath=True) or []
              if not cmds.getAttr(x + ".intermediateObject")]
    opaque = [x for x in shapes if not any("glass" in sg for sg in cmds.listConnections(x, type="shadingEngine") or [])]
    clad = pb.MeshAccumulator(4.0)
    fascia = pb.MeshAccumulator(1.0)
    lamps = pb.MeshAccumulator(fit=True)
    off, header_y, canopy_d, canopy_w = 0.03, 3.3, 1.4, 3.6
    done = 0
    piers = None            # the front's solid runs (u0, u1, y0, y1 above the floor): the same on every lounge's shell
    for kind, ang in BAYS:
        w, s_mouth, s_back, to_xz = bay_frame(kind, ang)
        t = (math.cos(math.radians(ang)), 0.0, math.sin(math.radians(ang)))
        n = (-t[2], 0.0, t[0])
        P3 = lambda s_, u, y_: (to_xz(s_, u)[0], y_, to_xz(s_, u)[1])
        for y in WELL_Y:
            # the shell's front (from the bay, toward the back wall), sides (from beside, inward) and roof (from above)
            o = P3(s_back - LOUNGE_D - 6.0, 3.0, y + 1.5)
            d_front = _ray(shapes, o, t, 12.0)
            o_side = P3(s_back - LOUNGE_D / 2, LOUNGE_W / 2 + 4.0, y + 1.5)
            d_side = _ray(shapes, o_side, (-n[0], 0.0, -n[2]), 8.0)
            mid = P3(s_back - LOUNGE_D / 2, 0.0, y + 9.0)
            d_top = _ray(shapes, mid, (0.0, -1.0, 0.0), 9.0)
            if d_front is None or d_side is None or d_top is None:
                continue
            sf = s_back - LOUNGE_D - 6.0 + d_front - off
            us = LOUNGE_W / 2 + 4.0 - d_side + off
            top = y + 9.0 - d_top
            # sides: back wall to front, floor to roof
            for sign in (1.0, -1.0):
                u = sign * us
                clad.facing([P3(sf, u, y), P3(s_back, u, y), P3(s_back, u, top), P3(sf, u, top)], (sign * n[0], 0.0, sign * n[2]))
            fwd = (-t[0], 0.0, -t[2])
            # front: the band over the windows and the door, and below it every bit of wall round the openings (found
            # once, by rays through the shell at 10 cm steps: piers full height, sills under the windows, window heads)
            clad.facing([P3(sf, -us, y + header_y), P3(sf, us, y + header_y), P3(sf, us, top), P3(sf, -us, top)], fwd)
            if piers is None:
                piers = _front_piers(opaque, P3, sf + off, us - off, y, header_y)
            for u0, u1, y0, y1 in piers:
                clad.facing([P3(sf, u0, y + y0), P3(sf, u1, y + y0), P3(sf, u1, y + y1), P3(sf, u0, y + y1)], fwd)
            # roof cap (an overhang all round) and its fascia
            ov = 0.15
            ctop = top + off
            clad.facing([P3(sf - ov, -us - ov, ctop), P3(s_back, -us - ov, ctop), P3(s_back, us + ov, ctop),
                         P3(sf - ov, us + ov, ctop)], (0, 1, 0))
            ft = ctop + 0.35
            fascia.facing([P3(sf - ov, -us - ov, ctop - 0.25), P3(sf - ov, us + ov, ctop - 0.25), P3(sf - ov, us + ov, ft),
                           P3(sf - ov, -us - ov, ft)], fwd)
            for sign in (1.0, -1.0):
                u = sign * (us + ov)
                fascia.facing([P3(sf - ov, u, ctop - 0.25), P3(s_back, u, ctop - 0.25), P3(s_back, u, ft), P3(sf - ov, u, ft)],
                              (sign * n[0], 0.0, sign * n[2]))
            # the canopy over the door, lamps under its front edge and over the door
            c0, c1 = y + header_y + 0.05, y + header_y + 0.2
            _obox(fascia, to_xz, sf - canopy_d, sf, -canopy_w / 2, canopy_w / 2, c0, c1, bottom=True)
            lq = [P3(sf - canopy_d + 0.15, -1.2, c0 - 0.01), P3(sf - canopy_d + 0.15, 1.2, c0 - 0.01),
                  P3(sf - 0.4, 1.2, c0 - 0.01), P3(sf - 0.4, -1.2, c0 - 0.01)]
            lamps.facing(lq, (0, -1, 0))
            lamps.facing([P3(sf - off, -1.0, y + header_y + 0.35), P3(sf - off, 1.0, y + header_y + 0.35),
                          P3(sf - off, 1.0, y + header_y + 0.75), P3(sf - off, -1.0, y + header_y + 0.75)], fwd)
            done += 1
    built = {}
    for acc, nm, sh in ((clad, "lounge_cladding", SHAFT_PANELS), (fascia, "lounge_fascia", SP("all_trim_c_asb13")),
                        (lamps, "lounge_lamps", BAY_LAMP)):
        if acc.counts:
            m = acc.build(nm, mg)
            cmds.sets(m, edit=True, forceElement=pb._material(f"swg_{name}_{nm}", (0.6, 0.6, 0.62), None, sh))
            built[nm] = m
    col = pb.MeshAccumulator()
    for acc in (clad, fascia):
        pb._append(col, acc)
    pb._collision_mesh(col, "lounge_cladding_collision", cg)
    return {"lounges": done}


def gate_cladding(stock_root, name):
    """The departures lift's column where it stands in the shuttle bay (floor to ceiling): hangar panels on every face
    3 cm proud of its shell, a trimmed surround and lamps round its door, slim pilasters up the corners with the bay
    ribs' lamps on the two facing the shaft."""
    mg, cg = f"{stock_root}|r0|mesh", f"{stock_root}|r0|collision"
    ys, yt = WELL_Y[SHUTTLE_LEVEL], WELL_Y[SHUTTLE_LEVEL] + BAY_H
    clad, trim, ribs = pb.MeshAccumulator(4.0), pb.MeshAccumulator(1.0), pb.MeshAccumulator(4.0)
    lamps = pb.MeshAccumulator(fit=True)
    off, door_w, door_h, frame = 0.03, 2.2, 3.2, 0.25
    a, b = GATE
    # the outline grown by `off`: inner arc a->b, outer arc b->a (one chord each on the 7.5-degree grid)
    da_in, da_out = math.degrees(off / R_MID), math.degrees(off / R_OUT)
    ring = [P(R_MID - off, a - da_in), P(R_MID - off, b + da_in), P(R_OUT + off, b + da_out), P(R_OUT + off, a - da_out)]
    cx, cz = sum(q[0] for q in ring) / 4, sum(q[1] for q in ring) / 4

    def out_n(p0, p1):
        mx, mz = (p0[0] + p1[0]) / 2 - cx, (p0[1] + p1[1]) / 2 - cz
        return (mx, 0.0, mz)

    def quad(acc, p0, p1, y0, y1, nrm):
        acc.facing([(p0[0], y0, p0[1]), (p1[0], y0, p1[1]), (p1[0], y1, p1[1]), (p0[0], y1, p0[1])], nrm)

    def lerp(p0, p1, t):
        return (p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t)

    for i in range(4):
        p0, p1 = ring[i], ring[(i + 1) % 4]
        nrm = out_n(p0, p1)
        if i:
            quad(clad, p0, p1, ys, yt, nrm)
            continue
        # the inner face: round the door (centred on the chord), a surround of trim 5 cm proud of the panels
        L = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
        t0, t1 = (L - door_w) / 2 / L, (L + door_w) / 2 / L
        j0, j1 = lerp(p0, p1, t0), lerp(p0, p1, t1)
        quad(clad, p0, j0, ys, yt, nrm)
        quad(clad, j1, p1, ys, yt, nrm)
        quad(clad, j0, j1, ys + door_h, yt, nrm)
        nl = math.hypot(nrm[0], nrm[2])
        o = (nrm[0] / nl * 0.05, nrm[2] / nl * 0.05)
        sh = lambda q: (q[0] + o[0], q[1] + o[1])
        f0, f1 = lerp(p0, p1, t0 - frame / L), lerp(p0, p1, t1 + frame / L)
        for e0, e1, y0, y1 in ((f0, j0, ys, ys + door_h), (j1, f1, ys, ys + door_h), (f0, f1, ys + door_h, ys + door_h + frame)):
            quad(trim, sh(e0), sh(e1), y0, y1, nrm)
        # the surround's returns: into the doorway on both jambs, and the lintel's top
        quad(trim, j0, sh(j0), ys, ys + door_h, (p1[0] - p0[0], 0.0, p1[1] - p0[1]))
        quad(trim, sh(j1), j1, ys, ys + door_h, (p0[0] - p1[0], 0.0, p0[1] - p1[1]))
        yl = ys + door_h + frame
        trim.facing([(f0[0], yl, f0[1]), (f1[0], yl, f1[1]), (sh(f1)[0], yl, sh(f1)[1]), (sh(f0)[0], yl, sh(f0)[1])], (0, 1, 0))
        o2 = (nrm[0] / nl * 0.07, nrm[2] / nl * 0.07)
        l0, l1 = lerp(p0, p1, 0.5 - 0.9 / L), lerp(p0, p1, 0.5 + 0.9 / L)
        quad(lamps, (l0[0] + o2[0], l0[1] + o2[1]), (l1[0] + o2[0], l1[1] + o2[1]), ys + door_h + frame + 0.2,
             ys + door_h + frame + 0.6, nrm)
    # corner pilasters (0.5 m square, 0.12 m proud of both faces), lamps on the inner two facing the shaft
    for i, c in enumerate(ring):
        pv, nx = ring[i - 1], ring[(i + 1) % 4]
        d1 = (nx[0] - c[0], nx[1] - c[1]); l1 = math.hypot(*d1); d1 = (d1[0] / l1, d1[1] / l1)
        d2 = (pv[0] - c[0], pv[1] - c[1]); l2 = math.hypot(*d2); d2 = (d2[0] / l2, d2[1] / l2)
        g, w_ = -0.12, 0.38                       # out past each face by 0.12, along each face by 0.38
        pts = [(c[0] + d1[0] * w_ + d2[0] * g, c[1] + d1[1] * w_ + d2[1] * g),
               (c[0] + d1[0] * g + d2[0] * g, c[1] + d1[1] * g + d2[1] * g),
               (c[0] + d1[0] * g + d2[0] * w_, c[1] + d1[1] * g + d2[1] * w_)]
        for q0, q1 in zip(pts, pts[1:]):
            quad(ribs, q0, q1, ys, yt, out_n(q0, q1))
        quad(ribs, (c[0] + d1[0] * w_, c[1] + d1[1] * w_), pts[0], ys, yt, out_n(c, nx))
        quad(ribs, pts[2], (c[0] + d2[0] * w_, c[1] + d2[1] * w_), ys, yt, out_n(pv, c))
        if i in (0, 1):                           # the shaft-side corners: lamps on their inner-face side
            nrm = out_n(ring[0], ring[1])
            nl = math.hypot(nrm[0], nrm[2])
            q0 = pts[2] if i == 0 else pts[0]
            q1 = pts[1]
            sh2 = (nrm[0] / nl * 0.02, nrm[2] / nl * 0.02)
            for ly in (ys + 3.2 + 2.0, ys + BAY_H - 6.0):
                quad(lamps, (q0[0] + sh2[0], q0[1] + sh2[1]), (q1[0] + sh2[0], q1[1] + sh2[1]), ly, ly + 0.5, nrm)
    for acc, nm, shd in ((clad, "gate_cladding", SHAFT_PANELS), (trim, "gate_trim", SP("all_trim_c_asb13")),
                         (ribs, "gate_ribs", BAY_RIBS), (lamps, "gate_lamps", BAY_LAMP)):
        if acc.counts:
            m = acc.build(nm, mg)
            cmds.sets(m, edit=True, forceElement=pb._material(f"swg_{name}_{nm}", (0.6, 0.6, 0.62), None, shd))
    col = pb.MeshAccumulator()
    for acc in (clad, ribs):
        pb._append(col, acc)
    pb._collision_mesh(col, "gate_cladding_collision", cg)
    return len(clad.counts) + len(trim.counts) + len(ribs.counts)


def lounge_fittings(stock_root, name, cell_of):
    """Each dock's lounge is a refreshment lounge: a bar down one side (counter with a marble top and foot rail,
    stools, a back-bar of lit shelves against the wall) and a seating corner down the other (an L sofa round a low
    table). Counter, back-bar, sofa and table stand in holes in the walk floor (movement stops at floor edges); the
    stools are open. Meshes go into each lounge cell, prelit with the cell's lights on export."""
    looks = (("lounge_bar", SP("spaceport_metl_panel5_cs8")), ("lounge_marble", SP("z_intr_assoc_marble_white_gloss_ces17")),
             ("lounge_metal", SP("spaceport_metl_trim_cs8")), ("lounge_glow", SPV1.FIXTURE),
             ("lounge_sofa", SP("intr_hoteltrim_cs8")), ("lounge_cushion", SP("floor_carpet_teal")))
    sgs = {nm: pb._material(f"swg_{name}_{nm}", (0.6, 0.6, 0.6), None, sh) for nm, sh in looks}   # once, shared by all lounges
    done = 0
    for i, (kind, ang) in enumerate(BAYS):
        w, s_mouth, s_back, to_xz = bay_frame(kind, ang)
        s0 = s_back - LOUNGE_D                       # the lounge's front (door) line; hw: half its width
        hw = LOUNGE_W / 2
        for k, y in enumerate(WELL_Y):
            ci = cell_of.get(f"bay{i + 1}_l{k + 1}_lounge")
            if ci is None:
                continue
            cell = f"{stock_root}|r{ci}"
            body, top, shelf, glow, sofa, cushion = (pb.MeshAccumulator(1.0) for _ in range(6))
            holes = []
            # bar: counter along the +u wall, 1.5 m off it, from 2 m behind the door to 2.5 m short of the back
            b0, b1 = s0 + 2.0, s_back - 2.5
            _obox(body, to_xz, b0, b1, hw - 2.3, hw - 1.5, y, y + 1.02)
            _obox(top, to_xz, b0 - 0.05, b1 + 0.05, hw - 2.4, hw - 1.45, y + 1.02, y + 1.08, bottom=True)
            _obox(shelf, to_xz, b0, b1, hw - 2.42, hw - 2.38, y + 0.18, y + 0.24)          # foot rail
            holes.append((b0 - 0.05, b1 + 0.05, hw - 2.45, hw - 1.45))
            for j in range(4):                                                              # stools
                sc = b0 + (b1 - b0) * (j + 0.5) / 4
                _obox(shelf, to_xz, sc - 0.05, sc + 0.05, hw - 3.0, hw - 2.9, y, y + 0.72)
                _obox(cushion, to_xz, sc - 0.22, sc + 0.22, hw - 3.17, hw - 2.73, y + 0.72, y + 0.8, bottom=True)
            # back-bar against the wall: cabinet, two lit shelves, a cabinet head
            _obox(body, to_xz, b0, b1, hw - 0.45, hw - 0.02, y, y + 0.95)
            for ys in (y + 1.35, y + 1.8):
                _obox(shelf, to_xz, b0, b1, hw - 0.35, hw - 0.02, ys, ys + 0.04, bottom=True)
                _obox(glow, to_xz, b0 + 0.1, b1 - 0.1, hw - 0.06, hw - 0.03, ys + 0.04, ys + 0.3)
            _obox(body, to_xz, b0, b1, hw - 0.45, hw - 0.02, y + 2.2, y + 2.45, bottom=True)
            holes.append((b0, b1, hw - 0.5, hw))
            # seating corner on the -u side: an L sofa (long run against the wall, return toward the door)
            f0, f1 = s0 + 2.5, s_back - 1.5
            _obox(sofa, to_xz, f0, f1, -hw + 0.02, -hw + 0.95, y, y + 0.42)                 # long seat base
            _obox(cushion, to_xz, f0, f1, -hw + 0.1, -hw + 0.9, y + 0.42, y + 0.55)
            _obox(sofa, to_xz, f0, f1, -hw + 0.02, -hw + 0.25, y + 0.42, y + 0.95)          # back
            _obox(sofa, to_xz, f0, f0 + 0.9, -hw + 0.95, -hw + 3.2, y, y + 0.42)            # return
            _obox(cushion, to_xz, f0 + 0.05, f0 + 0.85, -hw + 0.95, -hw + 3.1, y + 0.42, y + 0.55)
            _obox(sofa, to_xz, f0, f0 + 0.25, -hw + 0.95, -hw + 3.2, y + 0.42, y + 0.95)
            holes += [(f0, f1, -hw, -hw + 0.95), (f0, f0 + 0.9, -hw + 0.95, -hw + 3.2)]
            t0, t1 = f0 + 2.0, f0 + 4.4                                                     # low table
            _obox(top, to_xz, t0, t1, -hw + 1.8, -hw + 2.9, y + 0.36, y + 0.42, bottom=True)
            _obox(body, to_xz, t0 + 0.3, t1 - 0.3, -hw + 2.0, -hw + 2.7, y, y + 0.36)
            holes.append((t0, t1, -hw + 1.8, -hw + 2.9))
            mg = cell + "|mesh"
            for acc, (nm, _) in zip((body, top, shelf, glow, sofa, cushion), looks):
                if acc.counts:
                    cmds.sets(acc.build(nm, mg), edit=True, forceElement=sgs[nm])
            floor = _mesh_transforms(cell + "|collision|floor0")
            for a0, a1, u0, u1 in holes:
                pb.cut_plan_prism(floor, [to_xz(a0, u0), to_xz(a1, u0), to_xz(a1, u1), to_xz(a0, u1)], y - 0.5, y + 0.5)
            done += 1
    return done


def round_towers(stock_root, step=7.5, coarse=12.0, widest=40.0, reach=17.5):
    """Round off the stock corner towers' domes: every horizontal edge on a tower ring that spans more than
    `coarse` degrees (domes 12-sided, drums and trims 20-sided) is split into `step`-degree pieces and the new points pushed out onto
    the ring's circle. Shared edges are split for both faces (no cracks); UVs and colours interpolate."""
    done = {}
    for s in cmds.listRelatives(f"{stock_root}|r0|mesh", allDescendents=True, type="mesh", fullPath=True) or []:
        if cmds.getAttr(s + ".intermediateObject"):
            continue
        sel = om.MSelectionList()
        sel.add(s)
        dag = sel.getDagPath(0)
        fn = om.MFnMesh(dag)
        pts = fn.getPoints(om.MSpace.kWorld)
        picks, rings = [], []
        for e in range(fn.numEdges):
            i, j = fn.getEdgeVertices(e)
            a, b = pts[i], pts[j]
            if abs(a.y - b.y) > 0.02:
                continue
            for cx, cz in TOWERS:
                da, db = math.hypot(a.x - cx, a.z - cz), math.hypot(b.x - cx, b.z - cz)
                if da > reach or db > reach or da < 1.0 or abs(da - db) > 0.05:
                    continue
                span = abs((math.degrees(math.atan2(a.z - cz, a.x - cx) - math.atan2(b.z - cz, b.x - cx)) + 180) % 360 - 180)
                if coarse < span <= widest:          # a ring segment (wider: a cap edge across the dome)
                    picks.append(e)
                    rings.append((cx, cz, a.y, (da + db) / 2, span))
                break
        if not picks:
            continue
        n_div = max(1, int(round(max(r[4] for r in rings) / step)) - 1)
        n0 = fn.numVertices
        cmds.polySubdivideEdge([f"{s}.e[{e}]" for e in picks], divisions=n_div, ch=False)
        fn = om.MFnMesh(dag)
        pts = fn.getPoints(om.MSpace.kWorld)
        moved = 0
        for v in range(n0, fn.numVertices):
            q = pts[v]
            best = None
            for cx, cz, ry, rr, span in rings:
                if abs(q.y - ry) > 0.02:
                    continue
                d = math.hypot(q.x - cx, q.z - cz)
                if rr * math.cos(math.radians(span / 2)) - 0.05 <= d <= rr + 0.01 and (best is None or abs(rr - d) < abs(best[2] - d)):
                    best = (cx, cz, rr, d)
            if best:
                cx, cz, rr, d = best
                k = rr / d
                pts[v] = om.MPoint(cx + (q.x - cx) * k, q.y, cz + (q.z - cz) * k)
                moved += 1
        fn.setPoints(pts, om.MSpace.kWorld)
        done[s.split("|")[-1]] = {"edges": len(picks), "divisions": n_div, "moved": moved}
    return done


# the yacht's landing pads: it is longer (90.5 m) than the courtyard is wide, so two raised pads stand on the
# flattened ground outside the ring, west and east, mirror images about the courtyard's axis, clear of the corner
# towers (the flatten layer and the terrain collision boxes cover them, make_atmo_starport)
PAD_W, PAD_L, PAD_X_IN, PAD_Z = 46.0, 100.0, 77.0, (-50.0, 50.0)
PAD_Y = PAVE_Y + 0.23                   # a step up from the ground round it
PAD_STAIR_W, PAD_STAIR_RUN = 3.0, 0.35
RAIL_H, RAIL_POST, RAIL_BAR, RAIL_SPAN = 1.0, 0.07, 0.05, 1.8


def pad_layout():
    """The two yacht pads (x0, z0, x1, z1) outside the ring, west and east of it, mirror images about the courtyard's
    north-south axis, and each one's stair (x0, x1, z_top, z_foot) centred on its north edge, down to the ground."""
    east = (PAD_X_IN, PAD_Z[0], PAD_X_IN + PAD_W, PAD_Z[1])
    west = (2 * C[0] - east[2], PAD_Z[0], 2 * C[0] - east[0], PAD_Z[1])
    rects = [west, east]
    nsteps = max(1, int(round((PAD_Y - FIELD_Y) / 0.15)))
    stairs = [((r[0] + r[2] - PAD_STAIR_W) / 2, (r[0] + r[2] + PAD_STAIR_W) / 2, r[3], r[3] + nsteps * PAD_STAIR_RUN)
              for r in rects]
    return {"rects": rects, "stairs": stairs, "y": PAD_Y, "field_y": FIELD_Y, "steps": nsteps}


def pads(stock_root, name):
    """The yacht's two landing pads outside the ring, raised a step: a deck on side walls down below the ground, a guard rail round each (posts and two bars) open only at its stair, and a stair centred on each
    pad's north edge down to the field - the two the same, mirrored. Walk floor: the decks and the stairs' ramps go
    into r0's floor and the field floor is cut out under them (make_atmo_starport types the rail edges uncrossable
    and the pads' feet wall bases after export)."""
    L = pad_layout()
    deck = pb.MeshAccumulator(fit=True)
    side = pb.MeshAccumulator(2.0)
    rail = pb.MeshAccumulator(1.0)
    steps = pb.MeshAccumulator(pb.UV_SCALE["porch"])
    walk = pb.MeshAccumulator()
    y, g, n = L["y"], FIELD_Y, L["steps"]
    foot = g - 0.2
    floor_grp = f"{stock_root}|r0|collision|floor0"
    for (x0, z0, x1, z1), (sx0, sx1, sz_top, sz_foot) in zip(L["rects"], L["stairs"]):
        # the field floor under the pad and its stair goes (they bring their own walk floor)
        for m in _mesh_transforms(floor_grp):
            for q in ([(x0, z0), (x1, z0), (x1, z1), (x0, z1)], [(sx0, z1), (sx1, z1), (sx1, sz_foot), (sx0, sz_foot)]):
                pb.cut_plan_prism([m], q, g - 1.0, g + 1.0)
        deck.facing([(x0, y, z0), (x1, y, z0), (x1, y, z1), (x0, y, z1)], (0, 1, 0))
        # walk floor: the deck as three strips meeting at the stair mouth's corners (one polygon with them as mid-edge
        # points lost them in triangulation: the ramp's top then lay along an open deck edge), then the stair's ramp
        for a, b in ((x0, sx0), (sx0, sx1), (sx1, x1)):
            walk.facing([(a, y, z0), (b, y, z0), (b, y, z1), (a, y, z1)], (0, 1, 0))
        walk.facing([(sx0, y, z1), (sx1, y, z1), (sx1, g, sz_foot), (sx0, g, sz_foot)], (0, 1, 0))
        # side walls, the north one open over the stair
        for a, b, nrm in (((x1, z0), (x1, z1), (1, 0, 0)), ((x0, z0), (x1, z0), (0, 0, -1)), ((x0, z1), (x0, z0), (-1, 0, 0)),
                          ((x0, z1), (sx0, z1), (0, 0, 1)), ((sx1, z1), (x1, z1), (0, 0, 1))):
            side.facing([(a[0], foot, a[1]), (b[0], foot, b[1]), (b[0], y, b[1]), (a[0], y, a[1])], nrm)
        # stair: treads and risers down to the field, closed sides
        rise, run = (y - g) / n, (sz_foot - sz_top) / n
        for i in range(n):
            top, prev = y - (i + 1) * rise, y - i * rise
            za, zb = sz_top + i * run, sz_top + (i + 1) * run
            steps.facing([(sx0, top, za), (sx1, top, za), (sx1, prev, za), (sx0, prev, za)], (0, 0, 1))
            steps.facing([(sx0, top, za), (sx1, top, za), (sx1, top, zb), (sx0, top, zb)], (0, 1, 0))
            for sx, nx in ((sx0, -1.0), (sx1, 1.0)):
                steps.facing([(sx, foot, za), (sx, foot, zb), (sx, top, zb), (sx, top, za)], (nx, 0, 0))
        # guard rail: posts along every edge and two bars, open across the stair mouth
        runs = [((x0, z0), (x1, z0)), ((x0, z0), (x0, z1)), ((x1, z0), (x1, z1)), ((x0, z1), (sx0, z1)), ((sx1, z1), (x1, z1))]
        h = RAIL_POST / 2
        for (ax, az), (bx, bz) in runs:
            length = math.hypot(bx - ax, bz - az)
            k = max(1, int(math.ceil(length / RAIL_SPAN)))
            for i in range(k + 1):
                px, pz = ax + (bx - ax) * i / k, az + (bz - az) * i / k
                _box(rail, px - h, pz - h, px + h, pz + h, y, y + RAIL_H)
            for yb in (y + RAIL_H - RAIL_BAR, y + RAIL_H * 0.5):
                b2 = RAIL_BAR / 2
                _box(rail, min(ax, bx) - b2, min(az, bz) - b2, max(ax, bx) + b2, max(az, bz) + b2, yb, yb + RAIL_BAR)
    mg = f"{stock_root}|r0|mesh"
    for acc, nm, sh in ((deck, "landing_pads", SPV1.PAD_DECK), (side, "landing_pad_sides", SPV1.PAD_SIDE),
                        (rail, "landing_pad_rails", SP("all_trim_c_asb13")),
                        (steps, "landing_pad_stairs", SP("all_concrete_b_fallback_a2d13"))):
        m = acc.build(nm, mg)
        cmds.sets(m, edit=True, forceElement=pb._material(f"swg_{name}_{nm}", (0.5, 0.5, 0.52), None, sh))
    wm = walk.build("landing_pad_floor", floor_grp)
    pb._hide_helper(wm)
    cmds.sets(wm, edit=True, forceElement="initialShadingGroup")
    return L


EDGE_IN, EDGE_OUT = 0.35, 0.45          # roof edge: over the hall roof / out over the facade or the stock roof
EDGE_FOOT = ROOF_Y - 0.8                # its outer face's foot: under the stock roof's cut edge everywhere
R_PAVE = 54.0                           # courtyard paving runs in under the ring building (wall feet r 41..52.7)


def _top_y(meshes, x, z):
    """Highest surface of `meshes` (transforms; the stock importer hangs one shape per shader under each) over plan
    point (x, z), or None."""
    best = None
    shapes = [s for m in meshes for s in cmds.listRelatives(m, allDescendents=True, type="mesh", fullPath=True) or []
              if not cmds.getAttr(s + ".intermediateObject")]
    for m in shapes:
        sel = om.MSelectionList()
        sel.add(m)
        fn = om.MFnMesh(sel.getDagPath(0))
        hit = fn.closestIntersection(om.MFloatPoint(x, 80.0, z), om.MFloatVector(0, -1, 0), om.MSpace.kWorld, 200.0, False)
        if hit and hit[3] >= 0 and (best is None or hit[0].y > best):
            best = hit[0].y
    return best


def hall_roofs(stock_root, name, W):
    """One welded roof per hall instead of the builder's per-room roof patches (their seams and T-junctions showed
    as lines across the roof): the room patches at ROOF_Y inside the hall sector go, and the whole sector is roofed
    with one strip of quads on the arc grid, world-mapped so the texture runs on across it."""
    gone = 0
    for m in _mesh_transforms(f"{stock_root}|r0|mesh"):
        if not m.split("|")[-1].startswith("exterior_roof"):
            continue
        for s in cmds.listRelatives(m, allDescendents=True, type="mesh", fullPath=True) or []:
            if cmds.getAttr(s + ".intermediateObject"):
                continue
            sel = om.MSelectionList()
            sel.add(s)
            fn = om.MFnMesh(sel.getDagPath(0))
            pts = fn.getPoints(om.MSpace.kWorld)
            drop = []
            for f in range(fn.numPolygons):
                vs = [pts[v] for v in fn.getPolygonVertices(f)]
                if any(abs(p.y - ROOF_Y) > 0.02 for p in vs):
                    continue
                cx, cz = sum(p.x for p in vs) / len(vs), sum(p.z for p in vs) / len(vs)
                r = math.hypot(cx - C[0], cz - C[1])
                ang = math.degrees(math.atan2(cz - C[1], cx - C[0]))
                if R_IN - 0.5 < r < R_OUT + 0.5 and any(a0 - 0.1 <= ang + k * 360.0 <= a1 + 0.1 for _, a0, a1 in W.halls
                                                         for k in (-1, 0, 1)):
                    drop.append(f)
            if drop and len(drop) < fn.numPolygons:
                cmds.delete([f"{s}.f[{f}]" for f in drop])
                gone += len(drop)
            elif drop:
                cmds.delete(m)
                gone += len(drop)
                break
    acc = pb.MeshAccumulator(pb.UV_SCALE["roof"])
    for _, a0, a1 in W.halls:
        pin, pout = arc(R_IN, a0, a1), arc(R_OUT, a0, a1)
        for k in range(len(pin) - 1):
            acc.facing([(pin[k][0], ROOF_Y, pin[k][1]), (pout[k][0], ROOF_Y, pout[k][1]),
                        (pout[k + 1][0], ROOF_Y, pout[k + 1][1]), (pin[k + 1][0], ROOF_Y, pin[k + 1][1])], (0, 1, 0))
    m = acc.build("exterior_roof_halls", f"{stock_root}|r0|mesh")
    cmds.sets(m, edit=True, forceElement=pb._material(f"swg_{name}_hall_roofs", (0.62, 0.62, 0.64), None, SP("all_roof_a_ads16")))
    return {"mesh": m, "patches_replaced": gone}


def roof_edges(stock_root, name, W, stock_meshes):
    """One continuous coping round each hall roof - over the glazed front, along both ends and against the ring.
    The halls cut the stock ring roof along their outline and it stands 0..0.6 m over the hall roof there; the
    coping's top is a hair over the highest stock roof along it and its outer face runs down under the stock roof's
    cut edge, so hall roof, coping and stock roof meet with no gap, step or loose edge. One welded mesh per hall:
    top, inner face (on the hall roof), outer face and soffit (seen from the field under the overhang)."""
    acc = pb.MeshAccumulator(pb.UV_SCALE["trim"])
    tops = {}
    for side, a0, a1 in W.halls:
        poly = sector(R_IN, R_OUT, a0, a1)
        n = len(poly)
        inner = pb._inset_poly(poly, [EDGE_IN] * n)
        outer = pb._inset_poly(poly, [-EDGE_OUT] * n)
        probe = pb._inset_poly(poly, [-EDGE_OUT - 0.1] * n)
        hs = [h for i in range(n) for h in (_top_y(stock_meshes, *probe[i]),
              _top_y(stock_meshes, (probe[i][0] + probe[(i + 1) % n][0]) / 2, (probe[i][1] + probe[(i + 1) % n][1]) / 2))
              if h is not None and h < ROOF_Y + 2.0]
        y = min(max([ROOF_Y + 0.6] + [h + 0.15 for h in hs]), ROOF_Y + 1.6)
        tops[side] = round(y, 2)
        for i in range(n):
            j = (i + 1) % n
            t = (poly[j][0] - poly[i][0], poly[j][1] - poly[i][1])
            L = math.hypot(*t) or 1.0
            nin = (-t[1] / L, 0.0, t[0] / L)
            nout = (-nin[0], 0.0, -nin[2])
            acc.facing([(outer[i][0], y, outer[i][1]), (outer[j][0], y, outer[j][1]), (inner[j][0], y, inner[j][1]),
                        (inner[i][0], y, inner[i][1])], (0, 1, 0))
            acc.facing([(inner[i][0], ROOF_Y, inner[i][1]), (inner[j][0], ROOF_Y, inner[j][1]),
                        (inner[j][0], y, inner[j][1]), (inner[i][0], y, inner[i][1])], nin)
            acc.facing([(outer[i][0], EDGE_FOOT, outer[i][1]), (outer[j][0], EDGE_FOOT, outer[j][1]),
                        (outer[j][0], y, outer[j][1]), (outer[i][0], y, outer[i][1])], nout)
            acc.facing([(poly[i][0], EDGE_FOOT, poly[i][1]), (poly[j][0], EDGE_FOOT, poly[j][1]),
                        (outer[j][0], EDGE_FOOT, outer[j][1]), (outer[i][0], EDGE_FOOT, outer[i][1])], (0, -1, 0))
    m = acc.build("hall_roof_edges", f"{stock_root}|r0|mesh")
    cmds.sets(m, edit=True, forceElement=pb._material(f"swg_{name}_roof_edges", (0.55, 0.53, 0.5), None, SP("all_trim_c_asb13")))
    return {"mesh": m, "top_y": tops}


def courtyard_paving(stock_root, name, W):
    """Pave the courtyard between the well's kerb and the ring (and on into the south gallery), flush with the well
    deck, so the field reads as one surface with or without terrain under it: the halls' sectors are left out (their
    ends stand on the paving's edge) and every ground room's footprint is cut out of it."""
    acc = pb.MeshAccumulator(pb.UV_SCALE["porch"])
    y = PAVE_Y
    free = [(0.0, 360.0)]
    for _, a0, a1 in W.halls:
        for lo, hi in ((a0 % 360.0, a0 % 360.0 + (a1 - a0)),):
            spans = [(lo, min(hi, 360.0))] + ([(0.0, hi - 360.0)] if hi > 360.0 else [])
            for s0, s1 in spans:
                free = [piece for f0, f1 in free for piece in ((f0, min(f1, s0)), (max(f0, s1), f1)) if piece[1] - piece[0] > 1e-6]
    for f0, f1 in free:
        pin, pout = arc(RIM_R, f0, f1), arc(R_PAVE, f0, f1)
        for k in range(len(pin) - 1):
            acc.facing([(pin[k][0], y, pin[k][1]), (pout[k][0], y, pout[k][1]), (pout[k + 1][0], y, pout[k + 1][1]),
                        (pin[k + 1][0], y, pin[k + 1][1])], (0, 1, 0))
    # in front of the halls too (rim to the concourse glazing): the terrain there is cut away with the bays under it
    for _, a0, a1 in W.halls:
        pin, pout = arc(RIM_R, a0, a1), arc(R_IN, a0, a1)
        for k in range(len(pin) - 1):
            acc.facing([(pin[k][0], y, pin[k][1]), (pout[k][0], y, pout[k][1]), (pout[k + 1][0], y, pout[k + 1][1]),
                        (pin[k + 1][0], y, pin[k + 1][1])], (0, 1, 0))
    m = acc.build("courtyard_paving", f"{stock_root}|r0|mesh")
    for r in W.rooms:
        # only rooms standing in the paving's plane (the kiosk, a flight rising out of the ground); the tunnel and
        # the stair flights running under the field keep the paving over them
        top = (r.get("slope") or {}).get("ceiling_y") or r["floor_y"] + r["height"]
        if r["floor_y"] < y + 1.0 and top > y:
            for tri in _fan(r["polygon"]):
                pb.cut_plan_prism([m], tri, y - 1.0, y + 1.0)
    cmds.sets(m, edit=True, forceElement=pb._material(f"swg_{name}_courtyard_paving", (0.6, 0.6, 0.62), None,
                                                       SP("all_concrete_b_fallback_a2d13")))
    return {"mesh": m, "spans": [(round(a, 1), round(b, 1)) for a, b in free]}


def top_collision(stock_root, meshes):
    """r0 collision (the camera's CMSH) for the surfaces seen from above that the shell's own collision leaves out:
    hall roofs and their coping, the courtyard paving and the landing pads - faces as rendered (facing the open
    side)."""
    col = pb.MeshAccumulator()
    shapes = [s for m in meshes if m and cmds.objExists(m)
              for s in cmds.listRelatives(m, allDescendents=True, type="mesh", fullPath=True) or []
              if not cmds.getAttr(s + ".intermediateObject")]
    for m in shapes:
        sel = om.MSelectionList()
        sel.add(m)
        fn = om.MFnMesh(sel.getDagPath(0))
        pts = fn.getPoints(om.MSpace.kWorld)
        for f in range(fn.numPolygons):
            col.poly([tuple(pts[v])[:3] for v in fn.getPolygonVertices(f)], [(0.0, 0.0)] * len(fn.getPolygonVertices(f)))
    pb._collision_mesh(col, "top_collision", f"{stock_root}|r0|collision")
    return len(col.counts)


def build(name="titan_atmo_starport", export_root="D:/exported"):
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    mel.eval(f'importPob -i "{DATA}/appearance/{STOCK}.pob"')
    stock = cmds.ls("|" + STOCK, long=True)[0]
    # the msh importer mirrors X without reversing triangle order, so every stock mesh - exterior and cells - comes
    # in inside out (same fix as filler.import_shell). Reverse each SHAPE: the importer puts one shape per shader
    # under one transform, and polyNormal on the transform only flips its first shape (measured: 36 of 220 foyer
    # triangles), which left the rooms inside out.
    for cell in _cells(stock).values():
        for s in cmds.listRelatives(cell + "|mesh", allDescendents=True, type="mesh", fullPath=True) or []:
            if not cmds.getAttr(s + ".intermediateObject"):
                cmds.polyNormal(s, normalMode=0, userNormalMode=0, ch=False)
    exits = stock_exits(stock)
    W, towers = plan(exits)
    spec = spec_from(W, name + "_wings")
    out = pb.build(spec, new_scene=False)
    wing_root = out["root"]
    S = _cells(stock)
    # stock collision becomes authored where the building changes (r0 is cut and extended, the arms are walled up)
    stock_col = {ci: stock_collision_mesh(S[ci]) for ci in (0, 15, 16)}
    stock_meshes = _mesh_transforms(f"{stock}|r0|mesh")
    stock_floor = [m for m in _mesh_transforms(f"{stock}|r0|collision|floor0")]
    n_cut = clear_stock(W, wing_root, stock_meshes, stock_floor, [stock_col[0]] if stock_col[0] else [])
    # the control room fills the stock tower head: the pillar's top runs up into that volume, so it goes
    hx0, hz0, hx1, hz1 = TOWER_HEAD
    head = [(hx0, hz0), (hx1, hz0), (hx1, hz1), (hx0, hz1)]
    pb.cut_plan_prism(stock_meshes, head, TOWER_FLOOR - 0.3, TOWER_FLOOR + TOWER_H)
    if stock_col[0]:
        pb.cut_plan_prism([stock_col[0]], head, TOWER_FLOOR - 0.3, TOWER_FLOOR + TOWER_H)
    info = merge(stock, wing_root, W)
    fix = bay_fixtures(stock, name, W)
    clad = lounge_cladding(stock, name)
    gate_clad = gate_cladding(stock, name)
    tsa = checkpoint(stock, name)
    lounges = lounge_fittings(stock, name, info["cell_of"])
    domes = round_towers(stock)
    pad = pads(stock, name)                 # before the merge: its walk floor joins r0's
    ground = apron(stock, name)             # likewise
    floor = merge_floor(stock)
    n_pads = len(pad["rects"])
    roofs = hall_roofs(stock, name, W)
    edges = roof_edges(stock, name, W, stock_meshes)
    paving = courtyard_paving(stock, name, W)
    tops = [m for m in _mesh_transforms(f"{stock}|r0|mesh")
            if m.split("|")[-1].startswith(("exterior_roof", "landing_pad", "hall_roof_edges", "courtyard_paving", "apron_paving"))]
    n_top = top_collision(stock, tops)
    root = cmds.rename(stock, name)
    root = cmds.ls(root, long=True)[0]
    # bottom faces under everything modelled from above, and reveals for doorways with see-through slots
    undersides = pb.close_undersides(root, ground=GROUND + 0.05)
    reveals = pb.line_doorways(root)
    exp = pb.export(root, export_root, name)
    return {"root": root, "cells": info["cells"], "portals": info["portals"], "rewired": info["rewired"],
            "unpaired": info["unpaired"], "rooms": len(W.rooms), "towers": towers, "pads": n_pads,
            "entrances": len(W.entrances), "export": exp, "well": fix, "checkpoint": tsa, "domes": domes,
            "exclude": {"polygon": exclude_polygon()}, "apron": ground, "shuttle": shuttle_berth(), "bay_table": bay_table(), "undersides": sum(undersides.values()), "reveals": len(reveals),
            "pads_layout": pad, "lounges_fitted": lounges, "lounges_clad": clad,
            "roof_edge_top": edges["top_y"], "roof_patches_replaced": roofs["patches_replaced"], "paving": paving["spans"],
            "top_collision_faces": n_top}
