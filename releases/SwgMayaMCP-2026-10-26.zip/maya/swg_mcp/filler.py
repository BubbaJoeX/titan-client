"""Interiors for stock exterior-only buildings (city "filler" buildings) — runs inside Maya with SwgMayaEditor.

The stock mesh is imported with its SWG shaders and kept as the exterior cell r0 (pob_builder shell mode). Its free
interior is measured by slicing the mesh at several heights per storey (cross-section -> occupancy grid -> flood
fill from outside); rooms are laid out in the largest rectangle that stays inside the shell on every storey used,
and the entrance is cut through the facade where the stock door is painted (door shaders) or where the facade is
closest to the rooms.

Categories (plan_for picks one from the name and the measured size):
  tower    lobby + elevator shaft on the ground floor; apartments off a corridor on each upper floor
  house    living hall + back rooms; a straight stair to an upper floor of bedrooms when it fits
  slum     small dwelling: a main room and one or two back rooms, single storey
  block    a house-style plan scaled to a wide block (more back rooms / bedrooms)
"""

from __future__ import annotations

import math
import os

import maya.cmds as cmds
import maya.api.OpenMaya as om

from . import pob_builder

RES = 0.5            # occupancy grid cell (m)
STOREY = 4.0         # floor-to-floor height
ROOM_H = 3.6         # room height on stacked storeys (SLAB 0.4 between)
CORRIDOR = 2.4

THEMES = {
    "tato": {"wall": "shader/tatt_stco_player_wall_fallback_c2d13.sht", "floor": "shader/tatt_stco_player_floor_cs8.sht",
             "trim": "shader/metl_jnkshp_trim_cs8.sht", "porch": "shader/tato_concreteb_asb13.sht",
             "entrance": ["door_tato_filler_s01", "door_tato_filler_s02", "door_tato_filler_s03"],
             "private": "door_tato_interior_s01", "color": (0.78, 0.68, 0.52)},
    "corl": {"wall": "shader/ply_corl_stucco_fallback_c2d13.sht", "floor": "shader/ply_corl_floor_a_cs9.sht",
             "trim": "shader/ply_corl_accent_c_cs8.sht", "porch": "shader/corellia_concrete_a_unlined_asb13.sht",
             "entrance": ["door_corl_metal_s01", "door_corl_metal_s02"], "historic": "door_corl_metal_s01",      # door_corl_hist_s01 renders magenta here
             "slum": "door_corl_slum_s01", "private": "door_corl_metal_s01", "color": (0.7, 0.7, 0.72)},
    "nboo": {"wall": "shader/ply_nboo_marblewhite_ces17.sht", "floor": "shader/ply_nboo_marblefloordec_ces17.sht",
             "bedroom_floor": "shader/ply_nboo_carpetblue_cd8.sht", "trim": "shader/thed_trim_c_asb13.sht",
             "porch": "shader/thed_concreteb_adb13.sht",
             "entrance": ["door_nboo_filler_s01", "door_nboo_filler_s02", "door_nboo_filler_s03"],
             "private": "ply_nboo_house_door_s01", "color": (0.82, 0.8, 0.74)},
}
SHAFT = {"wall": {"shader": "shader/intr_medicalwall_tech_b_cd8.sht"}, "floor": {"shader": "shader/floor_garage_floor_02.sht"}}


# ============================================================================
# shell import + measurement
# ============================================================================

def import_shell(msh_path, name):
    """Import a stock .msh; returns (group, [mesh transforms]). The stock collision group is dropped (the POB
    gets a cell collision mesh instead)."""
    before = set(cmds.ls(assemblies=True, long=True))
    cmds.file(msh_path, i=True)
    new = [n for n in cmds.ls(assemblies=True, long=True) if n not in before]
    grp = cmds.group(new, name=name + "_stock_shell") if len(new) != 1 else new[0]
    grp = cmds.ls(grp, long=True)[0]
    for c in cmds.ls(grp, dag=True, long=True):
        if c.split("|")[-1] == "collision" and cmds.objExists(c):
            cmds.delete(c)
    shapes = cmds.ls(grp, dag=True, type="mesh", long=True, noIntermediate=True)
    # the .msh importer mirrors X without reversing the triangle order, so stock faces arrive inside-out
    # (measured: ~85% of wall faces point inward); turn them back before anything is built or exported
    for s in shapes:
        cmds.polyNormal(s, normalMode=0, userNormalMode=0, ch=False)
    meshes = sorted({cmds.listRelatives(s, parent=True, fullPath=True)[0] for s in shapes})
    return grp, meshes


def triangles(meshes):
    """World triangles [(p0, p1, p2, shader_path)]."""
    out = []
    for m in meshes:
        for shape in cmds.listRelatives(m, shapes=True, fullPath=True, noIntermediate=True) or []:
            sel = om.MSelectionList()
            sel.add(shape)
            dag = sel.getDagPath(0)
            fn = om.MFnMesh(dag)
            pts = fn.getPoints(om.MSpace.kWorld)
            sgs, face_sg = fn.getConnectedShaders(dag.instanceNumber())
            names = []
            for sg in sgs:
                n = sg.name() if hasattr(sg, "name") else om.MFnDependencyNode(sg).name()
                path = cmds.getAttr(n + ".swgShaderPath") if cmds.attributeQuery("swgShaderPath", node=n, exists=True) else n
                names.append(path or n)
            counts, ids = fn.getTriangles()
            k = 0
            for f, c in enumerate(counts):
                sh = names[face_sg[f]] if 0 <= face_sg[f] < len(names) else ""
                for _ in range(c):
                    out.append((tuple(pts[ids[k]])[:3], tuple(pts[ids[k + 1]])[:3], tuple(pts[ids[k + 2]])[:3], sh))
                    k += 3
    return out


class Grid:
    def __init__(self, bbox):
        self.x0, self.z0 = bbox[0] - 2 * RES, bbox[2] - 2 * RES
        self.nx = int(math.ceil((bbox[3] - bbox[0]) / RES)) + 5
        self.nz = int(math.ceil((bbox[5] - bbox[2]) / RES)) + 5

    def cell(self, x, z):
        return int((x - self.x0) / RES), int((z - self.z0) / RES)

    def x(self, i):
        return self.x0 + i * RES

    def z(self, j):
        return self.z0 + j * RES


def interior_mask(tris, grid, y, dilate=1, erode=None):
    """Cells strictly inside the shell's cross-section at height y (walls dilated by `dilate` cells)."""
    solid = [[False] * grid.nz for _ in range(grid.nx)]
    for a, b, c, _ in tris:
        ys = (a[1], b[1], c[1])
        if min(ys) > y or max(ys) < y:
            continue
        pts = []
        for p, q in ((a, b), (b, c), (c, a)):
            if (p[1] - y) * (q[1] - y) < 0 or (p[1] == y and q[1] != y):
                f = (y - p[1]) / (q[1] - p[1])
                pts.append((p[0] + (q[0] - p[0]) * f, p[2] + (q[2] - p[2]) * f))
        if len(pts) < 2:
            continue
        (x0, z0), (x1, z1) = pts[0], pts[1]
        n = max(1, int(math.hypot(x1 - x0, z1 - z0) / (RES * 0.3)))
        for k in range(n + 1):
            i, j = grid.cell(x0 + (x1 - x0) * k / n, z0 + (z1 - z0) * k / n)
            if 0 <= i < grid.nx and 0 <= j < grid.nz:
                solid[i][j] = True
    if dilate:
        grown = [row[:] for row in solid]
        for i in range(grid.nx):
            for j in range(grid.nz):
                if solid[i][j]:
                    for di in range(-dilate, dilate + 1):
                        for dj in range(-dilate, dilate + 1):
                            if 0 <= i + di < grid.nx and 0 <= j + dj < grid.nz:
                                grown[i + di][j + dj] = True
        solid = grown
    outside = [[False] * grid.nz for _ in range(grid.nx)]
    stack = [(i, j) for i in range(grid.nx) for j in (0, grid.nz - 1)] + [(i, j) for j in range(grid.nz) for i in (0, grid.nx - 1)]
    while stack:
        i, j = stack.pop()
        if not (0 <= i < grid.nx and 0 <= j < grid.nz) or outside[i][j] or solid[i][j]:
            continue
        outside[i][j] = True
        stack += [(i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)]
    # inside = not reachable from outside. Internal partitions (stock shells are often overlapping boxes) do not
    # split it: the stock geometry inside the rooms' volume is carved away (carve_rooms). Erode away from the
    # outside so room walls keep clear of the facade.
    inside = [[not outside[i][j] for j in range(grid.nz)] for i in range(grid.nx)]
    for _ in range(dilate + 2 if erode is None else erode):
        nxt = [row[:] for row in inside]
        for i in range(grid.nx):
            for j in range(grid.nz):
                if inside[i][j] and any(not (0 <= a < grid.nx and 0 <= b < grid.nz) or not inside[a][b]
                                        for a, b in ((i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1))):
                    nxt[i][j] = False
        inside = nxt
    return inside


def mask_and(masks):
    return [[all(m[i][j] for m in masks) for j in range(len(masks[0][0]))] for i in range(len(masks[0]))]


def largest_rect(mask):
    """Largest all-True axis-aligned rectangle (cells): (i0, j0, i1, j1) inclusive-exclusive, or None."""
    nx, nz = len(mask), len(mask[0])
    best, area = None, 0
    h = [0] * nz
    for i in range(nx):
        for j in range(nz):
            h[j] = h[j] + 1 if mask[i][j] else 0
        stack = []
        for j in range(nz + 1):
            cur = h[j] if j < nz else 0
            start = j
            while stack and stack[-1][1] >= cur:
                s, hh = stack.pop()
                if hh * (j - s) > area:
                    area, best = hh * (j - s), (i - hh + 1, s, i + 1, j)
                start = s
            stack.append((start, cur))
    return best


def rect_inside(mask, r):
    i0, j0, i1, j1 = r
    return all(mask[i][j] for i in range(i0, i1) for j in range(j0, j1))


def ray_hits(tris, o, d, max_t=40.0):
    """Distances along ray o + t d to every triangle it crosses (Moller-Trumbore)."""
    out = []
    for a, b, c, _ in tris:
        e1 = [b[k] - a[k] for k in range(3)]
        e2 = [c[k] - a[k] for k in range(3)]
        p = [d[1] * e2[2] - d[2] * e2[1], d[2] * e2[0] - d[0] * e2[2], d[0] * e2[1] - d[1] * e2[0]]
        det = sum(e1[k] * p[k] for k in range(3))
        if abs(det) < 1e-9:
            continue
        inv = 1.0 / det
        s = [o[k] - a[k] for k in range(3)]
        u = sum(s[k] * p[k] for k in range(3)) * inv
        if u < 0 or u > 1:
            continue
        q = [s[1] * e1[2] - s[2] * e1[1], s[2] * e1[0] - s[0] * e1[2], s[0] * e1[1] - s[1] * e1[0]]
        v = sum(d[k] * q[k] for k in range(3)) * inv
        if v < 0 or u + v > 1:
            continue
        t = sum(e2[k] * q[k] for k in range(3)) * inv
        if 0 < t < max_t:
            out.append(t)
    return out


# ============================================================================
# planning
# ============================================================================

SIDE_N = {"+x": (1.0, 0.0), "-x": (-1.0, 0.0), "+z": (0.0, 1.0), "-z": (0.0, -1.0)}


def measure(tris, bbox):
    """Door location (from door shaders), per-storey interior masks."""
    grid = Grid(bbox)
    doors = [t for t in tris if "door" in t[3].lower() and "window" not in t[3].lower()]
    door = None
    if doors:
        area_sum, c, n, ymin = 0.0, [0.0, 0.0, 0.0], [0.0, 0.0, 0.0], 1e9
        for a, b, cc, _ in doors:
            e1 = [b[k] - a[k] for k in range(3)]
            e2 = [cc[k] - a[k] for k in range(3)]
            cr = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]]
            ar = 0.5 * math.sqrt(sum(x * x for x in cr))
            area_sum += ar
            for k in range(3):
                c[k] += ar * (a[k] + b[k] + cc[k]) / 3
                n[k] += cr[k] * 0.5
            ymin = min(ymin, a[1], b[1], cc[1])
        if area_sum > 0.5:
            c = [x / area_sum for x in c]
            # the facade the door is painted on: the nearest side of the building's box (imported winding is
            # mirrored, so the polygon normals are not reliable)
            gaps = {"-x": c[0] - bbox[0], "+x": bbox[3] - c[0], "-z": c[2] - bbox[2], "+z": bbox[5] - c[2]}
            side = min(gaps, key=gaps.get)
            door = {"center": c, "side": side, "bottom": ymin}
    return grid, door


def plan_for(name, tris, bbox, theme, category=None, seed=1, _force=None):
    """Returns (spec_without_shell, info)."""
    grid, door = measure(tris, bbox)
    H = bbox[4]
    cat = category or ("slum" if "slum" in name else "block" if "block" in name or "bldg_64" in name else
                       "historic" if "historic" in name else "house")
    f0 = 0.15
    if door and 0.0 < door["bottom"] < 2.0:
        f0 = round(max(f0, door["bottom"] + 0.02), 2)

    def storey_mask(k):
        y = f0 + k * STOREY
        return mask_and([interior_mask(tris, grid, y + dy) for dy in (0.3, 1.8, ROOM_H - 0.1)])

    m0 = storey_mask(0)
    r = largest_rect(m0)
    if r is None or (r[2] - r[0]) * RES < 4.0 or (r[3] - r[1]) * RES < 4.0:
        m0 = mask_and([interior_mask(tris, grid, f0 + dy, dilate=2) for dy in (0.3, 1.8, ROOM_H - 0.1)])
        r = largest_rect(m0)
    if r is None or (r[2] - r[0]) * RES < 3.5 or (r[3] - r[1]) * RES < 3.5:
        raise ValueError(f"{name}: no usable interior found in the shell")
    rx0, rz0, rx1, rz1 = grid.x(r[0]) + 0.05, grid.z(r[1]) + 0.05, grid.x(r[2]) - 0.05, grid.z(r[3]) - 0.05
    rx0, rz0, rx1, rz1 = (round(v * 4) / 4 for v in (rx0, rz0, rx1, rz1))

    # front: the door's side, else the side whose facade is nearest the free rectangle
    def facade(side, at, y):
        n = SIDE_N[side]
        hits = ray_hits(tris, (at[0], y, at[1]), (n[0], 0.0, n[1]))
        return max(hits) if hits else 0.0

    def beyond(side, pt, d):
        """How far stock geometry (terrace, balustrade, columns) reaches out in front of the facade at a doorway:
        the passage is cut and the porch run out that far."""
        n = SIDE_N[side]
        t = (abs(n[1]), abs(n[0]))
        far = 0.0
        for hy in (0.4, 1.4, 2.4):
            for du in (-0.8, 0.0, 0.8):
                o = (pt[0] + n[0] * (d + 0.05) + t[0] * du, f0 + hy, pt[1] + n[1] * (d + 0.05) + t[1] * du)
                hits = ray_hits(tris, o, (n[0], 0.0, n[1]), 8.0)
                if hits:
                    far = max(far, max(hits))
        return far

    def side_mid(side):
        return {"+x": (rx1, (rz0 + rz1) / 2), "-x": (rx0, (rz0 + rz1) / 2),
                "+z": ((rx0 + rx1) / 2, rz1), "-z": ((rx0 + rx1) / 2, rz0)}[side]

    pick = None
    if door:
        front = door["side"]
    elif _force:
        front, pick = _force
    else:
        # no painted door: the facade spot nearest the rooms with nothing (balcony, railing, column) in front
        cands = []
        for sd, n in SIDE_N.items():
            mid = side_mid(sd)
            t = (abs(n[1]), abs(n[0]))
            span = (rx1 - rx0) if sd in ("+z", "-z") else (rz1 - rz0)
            for k in (0.0, -0.25, 0.25):
                pt = (mid[0] + t[0] * span * k, mid[1] + t[1] * span * k)
                d = facade(sd, pt, f0 + 1.2)
                score = d + 3.0 * beyond(sd, pt, d) + 0.3 * abs(k) - 0.01 * span
                cands.append((score, sd, pt))
        # among entrance spots about as good as the best, take the one whose plan holds the most rooms (the
        # facade side decides which part of the shell the rooms fill, e.g. whether a tower's floors stack)
        cands.sort(key=lambda c: c[0])
        tried = []
        for score, sd, pt in cands[:6]:
            try:
                sp, inf = plan_for(name, tris, bbox, theme, category, seed, _force=(sd, pt))
            except ValueError:
                continue
            # a room is worth half a metre of facade depth (a deeper doorway gets a vestibule)
            tried.append((len(sp["rooms"]) - 2.0 * (score - cands[0][0]), sp, inf))
        if tried:
            tried.sort(key=lambda c: c[0])
            return tried[-1][1], tried[-1][2]
        _, front, pick = cands[0]
    # local frame: W along the front, D front-to-back
    along_x = front in ("+z", "-z")
    W, D = (rx1 - rx0, rz1 - rz0) if along_x else (rz1 - rz0, rx1 - rx0)
    caps = {"slum": (12.0, 10.0), "house": (16.0, 13.0), "historic": (18.0, 13.0), "block": (24.0, 14.0),
            "tower": (20.0, 14.0)}
    # door u (world) along the front edge, to centre the used part of the rectangle on it
    door_u = None
    if door:
        door_u = door["center"][0] if along_x else door["center"][2]
    elif pick:
        door_u = pick[0] if along_x else pick[1]
    lo, hi = (rx0, rx1) if along_x else (rz0, rz1)
    cu = door_u if door_u is not None else (lo + hi) / 2

    def used_rect(cat_):
        """Part of the free rectangle a category uses: capped, flush with the front, centred on the door."""
        capw, capd = caps[cat_]
        Wu, Du = min(W, capw), min(D, capd)
        a = min(max(cu - Wu / 2, lo), hi - Wu)
        if front == "+z":
            box = (a, rz1 - Du, a + Wu, rz1)
        elif front == "-z":
            box = (a, rz0, a + Wu, rz0 + Du)
        elif front == "+x":
            box = (rx1 - Du, a, rx1, a + Wu)
        else:
            box = (rx0, a, rx0 + Du, a + Wu)
        return Wu, Du, box

    def cells(box):
        i0, j0 = grid.cell(box[0] + 0.01, box[1] + 0.01)
        i1, j1 = grid.cell(box[2] - 0.01, box[3] - 0.01)
        return (i0, j0, i1 + 1, j1 + 1)

    def count_storeys(box, limit):
        n = 1
        while n < limit and H > f0 + (n + 1) * STOREY:
            if not rect_inside(storey_mask(n), cells(box)):
                break
            n += 1
        return n

    Wu, Du, box = used_rect(cat)
    storeys = 1 if cat == "slum" else count_storeys(box, 2 if cat != "block" else 6)
    if cat in ("house", "historic", "block") and H > 24 and count_storeys(used_rect("tower")[2], 4) >= 4:
        cat = "tower"
    if cat == "tower":
        Wu, Du, box = used_rect("tower")
        storeys = count_storeys(box, 6)
    storeys = min(storeys, 6 if cat == "tower" else 2)
    ux0, uz0, ux1, uz1 = box

    def to_world(x, z):            # local (x along front, z from back(0) to front(D))
        if front == "+z":
            return (ux0 + x, uz0 + z)
        if front == "-z":
            return (ux0 + x, uz1 - z)
        if front == "+x":
            return (ux0 + z, uz0 + x)
        return (ux1 - z, uz0 + x)

    rng = _Rand(seed)
    layout = {"tower": _tower, "slum": _slum}.get(cat, _house)(Wu, Du, storeys, f0, H, cat)
    th = THEMES[theme]
    rooms = []
    for rm in layout["rooms"]:
        poly = [to_world(x, z) for x, z in rm.pop("local")]
        room = {"polygon": [list(p) for p in poly], **rm}
        kind = room.pop("kind", "room")
        mats = SHAFT if kind == "shaft" else {
            "wall": {"shader": th["wall"]},
            "floor": {"shader": th.get("bedroom_floor", th["floor"]) if kind == "bedroom" else th["floor"]}}
        room.setdefault("materials", mats)
        rooms.append(room)
    _fix_slopes(rooms, layout["rooms_meta"], to_world, along_x, front)
    doors = []
    for d in layout["doors"]:
        dd = {"rooms": d["rooms"], "width": d.get("width", 1.4), "height": d.get("height", 2.5)}
        if d.get("private"):
            dd.update({"style": "door", "door_style": th["private"], "width": 1.6, "height": 2.8})
        elif d.get("arch"):
            dd["style"] = "arch"
        if "y" in d:
            dd["y"] = d["y"]
        if "near" in d:
            dd["near"] = list(to_world(*d["near"]))
        doors.append(dd)
    ent_style = th.get(cat, None) if cat in ("historic", "slum") else None
    ent_style = ent_style or th["entrance"][rng.next(len(th["entrance"]))]
    if door:
        at = (door["center"][0], door["center"][2])
    elif pick:
        at = pick
    else:
        at = to_world(Wu / 2, Du)
    reveal = facade(front, _onto_front(at, front, ux0, ux1, uz0, uz1), f0 + 1.2)
    reveal = max(0.3, reveal + 0.03)
    w, h = 2.0, 3.0
    entry = layout["entry"]
    p_front = _onto_front(at, front, ux0, ux1, uz0, uz1)
    nf = SIDE_N[front]
    behind = (p_front[0] - nf[0] * 0.2, p_front[1] - nf[1] * 0.2)
    for rm in rooms:      # the ground-floor room right behind the doorway takes the entrance
        if not rm.get("slope") and abs(rm["floor_y"] - f0) < 0.05 and pob_builder._inside(behind, rm["polygon"]):
            entry = rm["name"]
            break
    if reveal > 1.6:
        # deep facade (arcade, recess, thick plinth): a vestibule room reaches out to within 0.5 m of it, so
        # the doorway is not a long tunnel through the stock mesh
        p0 = _onto_front(at, front, ux0, ux1, uz0, uz1)
        n = SIDE_N[front]
        t = (abs(n[1]), abs(n[0]))
        depth = round((reveal - 0.5) * 4) / 4
        vw = 3.2
        q0 = (p0[0] - t[0] * vw / 2, p0[1] - t[1] * vw / 2)
        q1 = (p0[0] + t[0] * vw / 2 + n[0] * depth, p0[1] + t[1] * vw / 2 + n[1] * depth)
        vbox = (min(q0[0], q1[0]), min(q0[1], q1[1]), max(q0[0], q1[0]), max(q0[1], q1[1]))
        loose = mask_and([interior_mask(tris, grid, f0 + dy, dilate=1, erode=0) for dy in (0.3, 1.8, 3.3)])
        if depth >= 0.75 and rect_inside(loose, cells(vbox)):
            rooms.append({"polygon": [[vbox[0], vbox[1]], [vbox[2], vbox[1]], [vbox[2], vbox[3]], [vbox[0], vbox[3]]],
                          "name": "vestibule", "floor_y": round(f0, 3), "height": 3.4,
                          "materials": {"wall": {"shader": th["wall"]}, "floor": {"shader": th["floor"]}}})
            doors.append({"rooms": [entry, "vestibule"], "width": 2.0, "height": 2.8, "style": "arch"})
            entry = "vestibule"
            at = (p0[0] + n[0] * depth, p0[1] + n[1] * depth)
            reveal = max(0.3, facade(front, at, f0 + 1.2) + 0.03)
    p_ent = _onto_front(at, front, ux0, ux1, uz0, uz1) if entry != "vestibule" else at
    clear = beyond(front, p_ent, reveal - 0.03)
    ent = {"room": entry, "cut_beyond": round(clear + 0.4, 2), "side": front, "at": list(at), "width": w, "height": h, "door_style": ent_style,
           "reveal": reveal, "porch": {"depth": reveal + clear + 1.0, "width": w, "steps": max(1, int(round(f0 / 0.2))),
                                        "run": 0.35}}
    spec = {
        "name": name, "rooms": rooms, "doors": doors, "entrances": [ent], "lights": True, "trim": True,
        "flat_terrain": True, "ground_y": 0.0, "collision_meshes": True, "window_portals": False,
        "trim_materials": {"shader": th["trim"]},
        "exterior": {"porch": {"shader": th["porch"]}},
        "shell_color": th["color"],
    }
    info = {"category": cat, "front": front, "door": [round(v, 2) for v in door["center"]] if door else None, "entrance_at": [round(v, 2) for v in at], "storeys": storeys, "used": [ux0, uz0, ux1, uz1],
            "free": [rx0, rz0, rx1, rz1], "reveal": round(reveal, 2), "floor_y": f0, "height": H}
    return spec, info


def _onto_front(at, front, x0, x1, z0, z1):
    if front in ("+z", "-z"):
        return (min(max(at[0], x0 + 1.2), x1 - 1.2), z1 if front == "+z" else z0)
    return (x1 if front == "+x" else x0, min(max(at[1], z0 + 1.2), z1 - 1.2))


def _fix_slopes(rooms, meta, to_world, along_x, front):
    """Local stair slopes run along local x (rising toward +x); map y_min/y_max onto the world axis."""
    for room, m in zip(rooms, meta):
        if not room.get("slope"):
            continue
        lo_y, hi_y = m["y_lo"], m["y_hi"]          # floor height at local x0 / x1
        wa, wb = to_world(m["x0"], 0.0), to_world(m["x1"], 0.0)
        k = 0 if along_x else 1
        rising = wb[k] > wa[k]
        room["slope"] = {"axis": "x" if along_x else "z", "y_min": lo_y if rising else hi_y,
                         "y_max": hi_y if rising else lo_y, "steps": True, "ceiling_y": m["ceiling"]}


class _Rand:
    def __init__(self, seed):
        self.s = seed * 2654435761 % 2 ** 32 or 1

    def next(self, n):
        self.s = (1103515245 * self.s + 12345) % 2 ** 31
        return self.s % n


def _rect(x0, z0, x1, z1):
    return [(x0, z0), (x1, z0), (x1, z1), (x0, z1)]


def _room(name, local, f, h, kind="room", **kw):
    return {"name": name, "local": local, "floor_y": round(f, 3), "height": round(h, 3), "kind": kind, **kw}


def _split(a, b, n):
    step = (b - a) / n
    return [(a + i * step, a + (i + 1) * step) for i in range(n)]


def _slum(W, D, storeys, f0, H, cat):
    h = min(3.4, H - f0 - 0.4)
    rooms, doors, meta = [], [], []
    if D >= 7.0 and W >= 5.0:
        db = min(3.5, D * 0.4)
        rooms.append(_room("main", _rect(0, db, W, D), f0, h))
        backs = _split(0, W, 2 if W >= 8 else 1)
        for i, (a, b) in enumerate(backs):
            nm = ["bedroom", "kitchen"][i]
            rooms.append(_room(nm, _rect(a, 0, b, db), f0, h, "bedroom" if nm == "bedroom" else "room"))
            doors.append({"rooms": ["main", nm], "private": nm == "bedroom"})
    elif W >= 7.0:
        wa = W * 0.6
        rooms += [_room("main", _rect(0, 0, wa, D), f0, h), _room("bedroom", _rect(wa, 0, W, D), f0, h, "bedroom")]
        doors.append({"rooms": ["main", "bedroom"], "private": True})
    else:
        rooms.append(_room("main", _rect(0, 0, W, D), f0, h))
    meta = [{} for _ in rooms]
    return {"rooms": rooms, "doors": doors, "entry": "main", "rooms_meta": meta}


def _house(W, D, storeys, f0, H, cat):
    rooms, doors = [], []
    two = storeys >= 2 and W >= 11.2 and D >= 9.0
    h1 = ROOM_H if two else min(4.2, H - f0 - 0.4)
    db = min(max(D * 0.38, 3.0), 3.4 if two else 4.5)          # back strip depth
    if D < 7.0:
        # shallow: side-by-side rooms
        parts = _split(0, W, max(1, min(3, int(W // 5))))
        names = ["hall", "bedroom", "study"]
        for i, (a, b) in enumerate(parts):
            rooms.append(_room(names[i], _rect(a, 0, b, D), f0, h1, "bedroom" if names[i] == "bedroom" else "room"))
            if i:
                doors.append({"rooms": [names[i - 1], names[i]], "private": names[i] == "bedroom",
                              "arch": names[i] != "bedroom"})
        return {"rooms": rooms, "doors": doors, "entry": "hall", "rooms_meta": [{} for _ in rooms]}
    meta = []
    if two:
        L = 6.4                                  # stair run for a 4 m rise (~32 degrees)
        x0 = 2.4
        x1 = x0 + L
        sw = db                                  # the stair fills the back strip between hall leg and kitchen
        # ground hall: front strip + the leg left of the stair (the stair's bottom end opens onto it)
        rooms.append(_room("hall", [(0, 0), (x0, 0), (x0, db), (W, db), (W, D), (0, D)], f0, h1))
        rooms.append(_room("stair", _rect(x0, 0, x1, sw), f0, h1, slope=True))
        meta += [{}, {"x0": x0, "x1": x1, "y_lo": f0, "y_hi": f0 + STOREY, "ceiling": f0 + STOREY + ROOM_H}]
        doors.append({"rooms": ["hall", "stair"], "width": 1.6, "near": (x0, sw / 2)})
        back = _split(x1, W, max(1, int((W - x1) // 5.5)))
        for i, (a, b) in enumerate(back):
            nm = ["kitchen", "dining", "pantry"][i % 3] + ("" if i < 3 else str(i))
            rooms.append(_room(nm, _rect(a, 0, b, db), f0, h1))
            meta.append({})
            doors.append({"rooms": ["hall", nm], "arch": True})
        # upper floor: corridor (front of the stair + the leg right of it, where the stair arrives)
        f1 = f0 + STOREY
        cz = db + CORRIDOR
        rooms.append(_room("landing", [(0, db), (x1, db), (x1, 0), (W, 0), (W, cz), (0, cz)] if x1 < W - 2.0
                           else _rect(0, db, W, cz), f1, ROOM_H))
        meta.append({})
        doors.append({"rooms": ["landing", "stair"], "width": 1.6, "near": (x1, sw / 2)})
        rooms.append(_room("bath", _rect(0, 0, x0, db), f1, ROOM_H))
        meta.append({})
        doors.append({"rooms": ["landing", "bath"], "private": True} if x0 >= 2.2 else {"rooms": ["landing", "bath"]})
        front = _split(0, W, max(1, int(W // 6.0)))
        for i, (a, b) in enumerate(front):
            nm = f"bedroom{i + 1}"
            rooms.append(_room(nm, _rect(a, cz, b, D), f1, ROOM_H, "bedroom"))
            meta.append({})
            doors.append({"rooms": ["landing", nm], "private": True})
        return {"rooms": rooms, "doors": doors, "entry": "hall", "rooms_meta": meta}
    # single storey: living hall in front, rooms along the back
    rooms.append(_room("hall", _rect(0, db, W, D), f0, h1))
    meta.append({})
    back = _split(0, W, max(1, min(4, int(W // 5.0))))
    names = ["bedroom", "kitchen", "study", "bedroom2"]
    for i, (a, b) in enumerate(back):
        nm = names[i]
        rooms.append(_room(nm, _rect(a, 0, b, db), f0, h1, "bedroom" if nm.startswith("bedroom") else "room"))
        meta.append({})
        doors.append({"rooms": ["hall", nm], "private": nm.startswith("bedroom"), "arch": not nm.startswith("bedroom")})
    return {"rooms": rooms, "doors": doors, "entry": "hall", "rooms_meta": meta}


def _tower(W, D, storeys, f0, H, cat):
    rooms, doors, meta = [], [], []
    sw, sd = 3.2, 3.2
    cx = W / 2
    s0, s1 = cx - sw / 2, cx + sw / 2
    levels = [f0 + k * STOREY for k in range(1, storeys)]
    shaft_h = (storeys - 1) * STOREY + ROOM_H
    rooms.append(_room("lift", _rect(s0, 0, s1, sd), f0, shaft_h, "shaft", levels=levels, elevator=True))
    meta.append({})
    roomy = D >= sd + CORRIDOR + 3.5 and W >= sw + 5.0
    if roomy:
        rooms.append(_room("lobby", _rect(0, sd, W, D), f0, ROOM_H))
        meta.append({})
        doors.append({"rooms": ["lobby", "lift"], "width": 2.0, "height": 2.8})
        for nm, (a, b) in (("office", (0, s0)), ("mailroom", (s1, W))):
            if b - a >= 2.5:
                rooms.append(_room(nm, _rect(a, 0, b, sd), f0, ROOM_H))
                meta.append({})
                doors.append({"rooms": ["lobby", nm], "arch": True})
    else:
        rooms.append(_room("lobby", [(0, 0), (s0, 0), (s0, sd), (s1, sd), (s1, 0), (W, 0), (W, D), (0, D)], f0, ROOM_H))
        meta.append({})
        doors.append({"rooms": ["lobby", "lift"], "width": 2.0, "height": 2.8})
    for k in range(1, storeys):
        f = f0 + k * STOREY
        p = f"f{k + 1}_"
        if roomy:
            cz = sd + CORRIDOR
            rooms.append(_room(p + "corridor", _rect(0, sd, W, cz), f, ROOM_H))
            meta.append({})
            doors.append({"rooms": [p + "corridor", "lift"], "width": 2.0, "height": 2.8, "y": f})
            units = []
            for side, (a, b) in (("a", (0, s0)), ("b", (s1, W))):
                if b - a >= 2.5:
                    units.append((p + "apt_" + side, _rect(a, 0, b, sd)))
            for i, (a, b) in enumerate(_split(0, W, max(1, int(W // 7.0)))):
                depth = D - cz
                if depth >= 7.0:
                    mid = cz + depth * 0.55
                    liv, bed = p + f"apt{i + 1}", p + f"apt{i + 1}_bed"
                    rooms.append(_room(liv, _rect(a, cz, b, mid), f, ROOM_H))
                    rooms.append(_room(bed, _rect(a, mid, b, D), f, ROOM_H, "bedroom"))
                    meta += [{}, {}]
                    doors.append({"rooms": [p + "corridor", liv], "private": True})
                    doors.append({"rooms": [liv, bed], "arch": True})
                else:
                    units.append((p + f"apt{i + 1}", _rect(a, cz, b, D)))
            for nm, poly in units:
                rooms.append(_room(nm, poly, f, ROOM_H, "bedroom"))
                meta.append({})
                doors.append({"rooms": [p + "corridor", nm], "private": True})
        else:
            nm = p + "apartment"
            rooms.append(_room(nm, [(0, 0), (s0, 0), (s0, sd), (s1, sd), (s1, 0), (W, 0), (W, D), (0, D)], f, ROOM_H))
            meta.append({})
            doors.append({"rooms": [nm, "lift"], "width": 2.0, "height": 2.8, "y": f})
    return {"rooms": rooms, "doors": doors, "entry": "lobby", "rooms_meta": meta}


# ============================================================================
# build
# ============================================================================

def carve_rooms(meshes, spec):
    """Cut the stock geometry inside the rooms' volume (internal partitions, mezzanines) out of the shell, so
    nothing of r0 shows inside a room through the entrance portal. Room polygons all lie in the used rectangle."""
    for r in spec["rooms"]:
        xs = [p[0] for p in r["polygon"]]
        zs = [p[1] for p in r["polygon"]]
        y0 = r["floor_y"] - 0.05
        y1 = (r["slope"]["ceiling_y"] if r.get("slope") else r["floor_y"] + r["height"]) + 0.05
        o = (min(xs), min(zs))
        pob_builder._shell_cut(meshes, o, (1.0, 0.0), (0.0, 1.0), (-0.05, max(xs) - o[0] + 0.05),
                               (-0.05, max(zs) - o[1] + 0.05), (y0, y1))


def hide_redundant_porch(root, tris, entrances):
    """The porch slab only renders where the stock model has nothing of its own to stand on: if stock steps or
    ground sit at about the landing height under the porch, the porch stays walkable (floor) but invisible."""
    if not entrances:
        return 0
    covered = 0
    total = 0
    for e in entrances:
        n = SIDE_N[e["side"]]
        t = (abs(n[1]), abs(n[0]))
        a, b = e["at"]
        depth = float((e.get("porch") or {}).get("depth", 2.0))
        ytop = None
        for du in (-0.6, 0.0, 0.6):
            for dv in (depth * 0.3, depth * 0.6, depth * 0.9):
                x, z = a + t[0] * du + n[0] * dv, b + t[1] * du + n[1] * dv
                hits = ray_hits(tris, (x, 6.0, z), (0.0, -1.0, 0.0), 8.0)
                total += 1
                if hits:
                    y = 6.0 - min(hits)
                    if ytop is None:
                        ytop = y
                    if y > -0.1:
                        covered += 1
    if total and covered >= total * 0.7:
        for nm in ("porch_top", "porch_steps"):
            for m in cmds.ls(f"{root}|r0|mesh|{nm}*", long=True) or []:
                cmds.delete(m)
        return 1
    return 0


def _porch_rect(e):
    """Plan rectangle a porch occupies (landing + steps), from the room wall outward."""
    n = SIDE_N[e["side"]]
    t = (abs(n[1]), abs(n[0]))
    pc = e.get("porch") or {}
    depth = float(pc.get("depth", 2.0)) + float(pc.get("run", 0.35)) * int(pc.get("steps", 1)) + 0.3
    w = float(pc.get("width", e.get("width", 2.0))) / 2 + 0.6
    a, b = e["at"]
    xs = [a - t[0] * w, a + t[0] * w + n[0] * depth, a + t[0] * w, a - t[0] * w + n[0] * depth]
    zs = [b - t[1] * w, b + t[1] * w + n[1] * depth, b + t[1] * w, b - t[1] * w + n[1] * depth]
    return (min(xs), min(zs), max(xs), max(zs))


def add_skirt(root, tris, bbox, entrances, width=2.5, y_floor=0.0, y_cut=0.4):
    """Exterior skirt floor for the stock shell (r0|collision|floor0), like the stock buildings' own: a ring of
    ground around the shell whose inner edge sits on the wall foot. SWG blocks movement with floor edges (mesh
    extents never collide), so this ring is what stops the player at the shell; the exporter tags the edges on
    the wall foot as WallBase, the outer rim stays crossable onto the terrain. Gaps are left where the porches
    are (the porch floor carries the player to the doorway)."""
    grid = Grid(bbox)
    inside = interior_mask(tris, grid, y_cut, dilate=1, erode=0)
    k = int(round(width / RES))
    dist = [[None] * grid.nz for _ in range(grid.nx)]
    front = [(i, j) for i in range(grid.nx) for j in range(grid.nz) if inside[i][j]]
    for i, j in front:
        dist[i][j] = 0
    while front:
        nxt = []
        for i, j in front:
            for a, b in ((i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)):
                if 0 <= a < grid.nx and 0 <= b < grid.nz and dist[a][b] is None and dist[i][j] < k:
                    dist[a][b] = dist[i][j] + 1
                    nxt.append((a, b))
        front = nxt
    porches = [_porch_rect(e) for e in entrances]

    def in_porch(x0, z0, x1, z1):
        return any(x0 < r[2] and x1 > r[0] and z0 < r[3] and z1 > r[1] for r in porches)

    # wall line at foot height
    segs = []
    for a, b, c, _ in tris:
        ys = (a[1], b[1], c[1])
        if min(ys) > y_cut or max(ys) < y_cut:
            continue
        pts = []
        for p, q in ((a, b), (b, c), (c, a)):
            if (p[1] - y_cut) * (q[1] - y_cut) < 0:
                f = (y_cut - p[1]) / (q[1] - p[1])
                pts.append((p[0] + (q[0] - p[0]) * f, p[2] + (q[2] - p[2]) * f))
        if len(pts) == 2:
            segs.append(pts)

    def snap(x, z):
        best = None
        for (ax, az), (bx, bz) in segs:
            dx, dz = bx - ax, bz - az
            ll = dx * dx + dz * dz
            t = 0.0 if ll < 1e-9 else max(0.0, min(1.0, ((x - ax) * dx + (z - az) * dz) / ll))
            px, pz = ax + dx * t, az + dz * t
            d = (px - x) ** 2 + (pz - z) ** 2
            if best is None or d < best[0]:
                best = (d, px, pz)
        if best is None or best[0] > 1.2 ** 2:
            return x, z
        _, px, pz = best
        d = math.sqrt(best[0]) or 1.0
        return px + (x - px) / d * 0.04, pz + (z - pz) / d * 0.04

    inner = set()
    cells = []
    for i in range(grid.nx):
        for j in range(grid.nz):
            if dist[i][j] is None or dist[i][j] == 0:
                continue
            x0, z0, x1, z1 = grid.x(i), grid.z(j), grid.x(i) + RES, grid.z(j) + RES
            if in_porch(x0, z0, x1, z1):
                continue
            cells.append((i, j))
            for a, b in ((i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)):
                if 0 <= a < grid.nx and 0 <= b < grid.nz and dist[a][b] == 0:
                    # the corners this cell shares with an inside cell lie on the inner boundary
                    if a == i + 1:
                        inner.update({(i + 1, j), (i + 1, j + 1)})
                    elif a == i - 1:
                        inner.update({(i, j), (i, j + 1)})
                    elif b == j + 1:
                        inner.update({(i, j + 1), (i + 1, j + 1)})
                    else:
                        inner.update({(i, j), (i + 1, j)})
    if not cells:
        return 0
    corner = {}

    def vtx(ci, cj):
        if (ci, cj) not in corner:
            x, z = grid.x(ci), grid.z(cj)
            if (ci, cj) in inner:
                x, z = snap(x, z)
            corner[(ci, cj)] = (x, y_floor, z)
        return corner[(ci, cj)]
    acc = pob_builder.MeshAccumulator()
    for i, j in cells:
        q = [vtx(i, j), vtx(i + 1, j), vtx(i + 1, j + 1), vtx(i, j + 1)]
        acc.facing(q, (0, 1, 0))
    floor_grp = f"{root}|r0|collision|floor0"
    if not cmds.objExists(floor_grp):
        return 0
    m = acc.build("exterior_skirt", floor_grp)
    cmds.polyTriangulate(m, ch=False)
    cmds.sets(m, edit=True, forceElement="initialShadingGroup")
    pob_builder._hide_helper(m)
    return 2 * len(cells)


def build(msh_path, name, theme, category=None, seed=1):
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    grp, meshes = import_shell(msh_path, name)
    tris = triangles(meshes)
    bbox = cmds.exactWorldBoundingBox(grp)
    from . import filler_plan
    import importlib
    importlib.reload(filler_plan)
    decor = []
    try:
        spec, info, decor = filler_plan.plan(name, tris, bbox, theme, category, seed)
    except ValueError as exc:            # door-driven plan impossible: the single-entrance planner
        spec, info = plan_for(name, tris, bbox, theme, category, seed)
        info["fallback"] = str(exc)
    carve_rooms(meshes, spec)
    spec["shell"] = {"meshes": meshes}
    out = pob_builder.build(spec, new_scene=False)
    info["decor"] = filler_plan.build_decor(out["root"], decor, out["rooms"], name)
    info["skirt_tris"] = add_skirt(out["root"], tris, bbox, spec.get("entrances", []))
    info["porch_hidden"] = hide_redundant_porch(out["root"], tris, spec.get("entrances", []))
    if cmds.objExists(grp) and not cmds.listRelatives(grp, allDescendents=True, type="mesh"):
        cmds.delete(grp)
    spec.pop("shell")
    return {"build": {k: out[k] for k in ("root", "cells")}, "info": info, "spec": spec, "bbox": bbox}
