"""SwgMayaMCP Maya-side package (bridge + POB builder)."""
