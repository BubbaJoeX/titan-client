"""Procedural SWG building (POB) generator — runs inside Maya with SwgMayaEditor loaded.

A building is a set of rooms (one cell each) plus an exterior shell cell r0. Rooms are polygons in plan
(rectangles, regular "round" polygons, or any simple polygon incl. concave), can sit at any height, can be
ramps (floor rising along x or z), can hold elevated stages reached by a ramp, and can be multi-level
elevator shafts. Doors go on wall segments two rooms share; entrances cut the shell. The scene is built
through the plug-in's own authoring commands (createPobTemplate / connectPobCells) and exported with
swg_pob_exportStructure (msh + flr + pob).

Spec (metres, Maya Y-up; x/z are building-space plan coordinates):
{
  "name": "titan_complex",
  "rooms": [
    {"name": "lobby", "min": [0, 0], "max": [10, 10], "height": 5.6},                       # rectangle
    {"name": "rotunda", "round": {"center": [5, -5.9], "radius": 6, "segments": 16},       # flat edges face
     "height": 5, "stages": [{"min": [3.5, -9.5], "max": [6.5, -7.5], "height": 0.8,       #   +-x / +-z
                               "ramp": {"side": "+z", "width": 1.6, "length": 2.4}}]},
    {"name": "hangar", "polygon": [[28, 0], [36, 0], [36, 12], [32, 12], [32, 8], [28, 8]]},
    {"name": "ramp", "min": [10, 2], "max": [28, 6], "height": 4,
     "slope": {"axis": "x", "y_min": 6.0, "y_max": 0.0}},                                  # floor y at min/max x
                                    # slope extras: "steps": true (stair look), "ceiling_y": flat ceiling
    {"name": "lift", "min": [-4, 3], "max": [0, 7], "height": 10, "levels": [6.0],         # extra floors
     "elevator": true},
    {"name": "gallery", "min": [0, 0], "max": [10, 10], "floor_y": 6.0, "height": 4}       # upper storey
  ],
  "doors":     [{"rooms": ["lobby", "lift"]}, {"rooms": ["gallery", "lift"]}, ...],     # y picked from floors
  "entrances": [{"room": "lobby", "side": "+z", "width": 2.4, "height": 3.2}],
  "lights": true
}
"""

from __future__ import annotations

import math
import os
import random
import struct
import zlib

import maya.cmds as cmds
import maya.mel as mel
import maya.api.OpenMaya as om

EPS = 1e-4
DEFAULT_HEIGHT = 4.0
DEFAULT_DOOR = (2.0, 3.0)
# Door leaf models, measured from the stock meshes: style -> (thickness, width, height) in metres. A doorway with a
# door leaf is sized to the leaf (+DOOR_FIT_W / +DOOR_FIT_H) and its wall is at least the leaf's thickness plus
# DOOR_CLEAR on each side, so the leaf (closed or sliding open) stays inside the wall instead of clipping through.
DOOR_LEAF = {
    "door_corl_metal_s01": (0.076, 2.02, 3.00), "door_corl_metal_s02": (0.076, 2.02, 3.00),
    "door_corl_metal_s03": (0.076, 3.01, 3.00), "door_corl_metal_s04": (0.076, 3.01, 3.75),
    "door_corl_hist_s01": (0.215, 1.59, 3.28), "door_corl_slum_s01": (0.189, 1.60, 3.32),
    "door_tato_filler_s01": (0.200, 2.20, 3.10), "door_tato_filler_s02": (0.200, 2.20, 3.10),
    "door_tato_filler_s03": (0.200, 2.20, 3.10), "door_tato_interior_s01": (0.200, 1.80, 3.20),
    "door_tato_despot_s01": (0.200, 3.10, 3.10), "door_tato_shuttleport": (0.200, 2.76, 3.89),
    "door_nboo_filler_s01": (0.150, 1.48, 3.23), "door_nboo_filler_s02": (0.117, 2.11, 3.23),
    "door_nboo_filler_s03": (0.117, 2.11, 3.23), "door_nboo_filler_s04": (0.141, 2.82, 2.85),
    "door_nboo_filler_s05": (0.116, 1.53, 2.75), "door_impl_s02": (0.150, 2.19, 3.03),
    "door_bunker_rebel": (0.150, 2.20, 2.97), "poi_all_impl_bunker_door": (0.200, 1.10, 3.00),
    "ply_nboo_house_door_s01": (0.200, 2.00, 3.00),
}
DOOR_FIT_W, DOOR_FIT_H, DOOR_CLEAR = 0.1, 0.05, 0.06


def door_fits(style, width, height):
    """Can a doorway of width x height take this door style's leaf? (Unknown styles: assume yes.)"""
    leaf = DOOR_LEAF.get(style or "")
    return leaf is None or (leaf[1] + DOOR_FIT_W <= width + EPS and leaf[2] + DOOR_FIT_H <= height + EPS)


def wall_for_doors(styles):
    """Thinnest wall that hides every one of these door leaves."""
    return max([DOOR_LEAF[st][0] + 2 * DOOR_CLEAR for st in styles if st in DOOR_LEAF] or [0.0])
SLAB = 0.4            # floor/ceiling slab between stacked storeys and elevator levels
RAMP_SOFFIT = 0.3     # thickness under sloped corridors
SIDES = {"+x": (1.0, 0.0), "-x": (-1.0, 0.0), "+z": (0.0, 1.0), "-z": (0.0, -1.0)}
# metres per texture tile, by surface role (a material can override with "uv_scale")
UV_SCALE = {"wall": 3.0, "floor": 2.5, "ceiling": 3.0, "trim": 1.0, "shell": 4.0, "roof": 4.0, "base": 3.0,
            "porch": 2.5, "stair": 1.5, "dome": 3.0}
GLASS_SHADER = "shader/all_glass_a_aa7.sht"            # stock alpha-blended glass (effect a_alpha)
FIXTURE_SHADER = "shader/intr_tech_light_ceilinga_ce9.sht"   # stock emissive ceiling light panel


# ============================================================================
# 2D helpers (plan coordinates (x, z))
# ============================================================================

def _area(poly):
    return 0.5 * sum(poly[i][0] * poly[(i + 1) % len(poly)][1] - poly[(i + 1) % len(poly)][0] * poly[i][1]
                     for i in range(len(poly)))


def _ccw(poly):
    poly = [(float(x), float(z)) for x, z in poly]
    return poly if _area(poly) > 0 else poly[::-1]


def _inside(p, poly):
    x, z = p
    inside = False
    for i in range(len(poly)):
        (x1, z1), (x2, z2) = poly[i], poly[(i + 1) % len(poly)]
        if (z1 > z) != (z2 > z) and x < x1 + (z - z1) * (x2 - x1) / (z2 - z1):
            inside = not inside
    return inside


def _interior_point(poly):
    """Area centroid, or (for concave shapes whose centroid falls outside) the first ear's centroid."""
    a = _area(poly)
    cx = sum((poly[i][0] + poly[(i + 1) % len(poly)][0]) * (poly[i][0] * poly[(i + 1) % len(poly)][1] -
             poly[(i + 1) % len(poly)][0] * poly[i][1]) for i in range(len(poly))) / (6 * a)
    cz = sum((poly[i][1] + poly[(i + 1) % len(poly)][1]) * (poly[i][0] * poly[(i + 1) % len(poly)][1] -
             poly[(i + 1) % len(poly)][0] * poly[i][1]) for i in range(len(poly))) / (6 * a)
    if _inside((cx, cz), poly):
        return cx, cz
    for i in range(len(poly)):
        p = [poly[i - 1], poly[i], poly[(i + 1) % len(poly)]]
        c = (sum(q[0] for q in p) / 3, sum(q[1] for q in p) / 3)
        if _inside(c, poly):
            return c
    return poly[0]


class Edge:
    def __init__(self, room, index):
        self.room, self.index = room, index
        poly = room["poly"]
        self.p = poly[index]
        self.q = poly[(index + 1) % len(poly)]
        dx, dz = self.q[0] - self.p[0], self.q[1] - self.p[1]
        self.length = math.hypot(dx, dz)
        self.t = (dx / self.length, dz / self.length)
        self.n_in = (-self.t[1], self.t[0])          # CCW polygon: interior on the left
        self.n_out = (-self.n_in[0], -self.n_in[1])

    def at(self, u):
        return (self.p[0] + self.t[0] * u, self.p[1] + self.t[1] * u)

    def u_of(self, pt):
        return (pt[0] - self.p[0]) * self.t[0] + (pt[1] - self.p[1]) * self.t[1]

    def overlap_with(self, other):
        """(lo, hi) in this edge's parameter where `other` is collinear, opposite and overlapping, else None."""
        if self.t[0] * other.t[0] + self.t[1] * other.t[1] > -0.999:
            return None
        for pt in (other.p, other.q):
            d = (pt[0] - self.p[0]) * self.n_in[0] + (pt[1] - self.p[1]) * self.n_in[1]
            if abs(d) > 1e-3:
                return None
        a, b = sorted((self.u_of(other.p), self.u_of(other.q)))
        lo, hi = max(0.0, a), min(self.length, b)
        return (lo, hi) if hi - lo > EPS else None


# ============================================================================
# room model
# ============================================================================

def _normalize_room(r, i, spec):
    if "round" in r:
        rd = r["round"]
        n = int(rd.get("segments", 16))
        if n % 4:
            raise ValueError(f"room {r.get('name')}: round segments must be a multiple of 4 (flat edges face +-x/+-z)")
        cx, cz = rd["center"]
        rad = float(rd["radius"])
        poly = [(cx + rad * math.cos((k + 0.5) * 2 * math.pi / n), cz + rad * math.sin((k + 0.5) * 2 * math.pi / n))
                for k in range(n)]
    elif "polygon" in r:
        poly = r["polygon"]
    else:
        (x0, z0), (x1, z1) = r["min"], r["max"]
        poly = [(min(x0, x1), min(z0, z1)), (max(x0, x1), min(z0, z1)), (max(x0, x1), max(z0, z1)), (min(x0, x1), max(z0, z1))]
    poly = _ccw(poly)
    if abs(_area(poly)) < 1.0:
        raise ValueError(f"room {r.get('name', i)}: footprint is smaller than 1 m^2")
    room = {
        "name": str(r.get("name") or f"room{i + 1}"),
        "cell": i + 1,
        "poly": poly,
        "floor_y": float(r.get("floor_y", 0.0)),
        "height": float(r.get("height", spec.get("height", DEFAULT_HEIGHT))),
        "levels": sorted(float(y) for y in r.get("levels", [])),
        "slope": r.get("slope"),
        "stages": list(r.get("stages", [])),
        "elevator": bool(r.get("elevator", False)),
        "hardpoints": list(r.get("hardpoints", [])),
        "color": tuple(r.get("color") or _palette(i)),
        "materials": r.get("materials") or {},
        "light": r.get("light"),
        "dome": r.get("dome"),
        "trim": r.get("trim", spec.get("trim", False)),
        "ground_y": spec.get("ground_y"),
        "collision": r.get("collision", spec.get("collision_meshes", False)),
        "windows": r.get("windows"),
        "spiral": r.get("spiral"),
        "round": r.get("round"),
        # floor holes for fixtures (counters, basins): SWG blocks movement with floor edges, not meshes
        "obstacles": [list(map(float, o)) for o in r.get("obstacles", [])],
    }
    if room["spiral"]:
        if not room["round"] or room["levels"] or room["stages"] or room["slope"]:
            raise ValueError(f"room {room['name']}: a spiral stair needs a round room without levels/stages/slope")
        if float(room["spiral"]["y_to"]) - room["floor_y"] < 2.6:
            raise ValueError(f"room {room['name']}: spiral rise must be at least 2.6 m (headroom over the bottom landing)")
    if room["dome"] and (room["slope"] or room["levels"]):
        raise ValueError(f"room {room['name']}: domes need a flat, single-level room")
    if room["slope"]:
        s = room["slope"]
        if s.get("dir") is not None:                 # any plan direction (curved halls): rises along dir
            dx, dz = (float(v) for v in s["dir"])
            ln = math.hypot(dx, dz)
            room["slope_dir"] = (dx / ln, dz / ln)
        elif s.get("axis") in ("x", "z"):
            room["slope_dir"] = (1.0, 0.0) if s["axis"] == "x" else (0.0, 1.0)
        else:
            raise ValueError(f"room {room['name']}: slope needs axis 'x' / 'z' or a plan dir [dx, dz]")
        proj = [_dot2(p, room["slope_dir"]) for p in poly]
        room["slope_range"] = (min(proj), max(proj))
        if room["levels"] or room["stages"]:
            raise ValueError(f"room {room['name']}: sloped rooms cannot have levels or stages")
    for y in room["levels"]:
        if not room["floor_y"] + 2.5 < y < room["floor_y"] + room["height"] - 2.5:
            raise ValueError(f"room {room['name']}: level {y} needs 2.5 m of headroom above and below")
    return room


def floor_y(room, pt):
    """Lowest walkable height at a plan point (sloped rooms interpolate)."""
    s = room["slope"]
    if not s:
        return room["floor_y"]
    lo, hi = room["slope_range"]
    f = min(1.0, max(0.0, (_dot2(pt, room["slope_dir"]) - lo) / (hi - lo)))
    return float(s["y_min"]) + (float(s["y_max"]) - float(s["y_min"])) * f


def floors_at(room, pt):
    if room.get("spiral"):
        return [room["floor_y"], float(room["spiral"]["y_to"])]
    if room["slope"]:
        return [floor_y(room, pt)]
    ys = [room["floor_y"]] + room["levels"]
    for st in room["stages"]:            # a doorway can open onto a stage that reaches the wall (stair landing)
        (x0, z0), (x1, z1) = st["min"], st["max"]
        if min(x0, x1) - 0.06 <= pt[0] <= max(x0, x1) + 0.06 and min(z0, z1) - 0.06 <= pt[1] <= max(z0, z1) + 0.06:
            ys.append(room["floor_y"] + float(st.get("height", 1.0)))
    return ys


def top_y(room, pt):
    if room["slope"] and room["slope"].get("ceiling_y") is not None:     # stairwell with a flat ceiling
        return float(room["slope"]["ceiling_y"])
    return floor_y(room, pt) + room["height"]


def _palette(i):
    colors = [(0.62, 0.56, 0.48), (0.50, 0.58, 0.62), (0.58, 0.50, 0.58), (0.52, 0.60, 0.50), (0.64, 0.60, 0.44),
              (0.55, 0.50, 0.44), (0.48, 0.55, 0.60)]
    return colors[i % len(colors)]


# ============================================================================
# geometry accumulation
# ============================================================================

class MeshAccumulator:
    """Collects polygons (CCW as seen from the side they should face) and builds one Maya mesh."""

    def __init__(self, uv_scale=2.0, fit=False):
        self.points, self.index = [], {}
        self.counts, self.connects = [], []
        self.uvs, self.uv_ids = [], []
        self.uv_scale = float(uv_scale)     # metres per texture tile
        self.fit = fit                      # True: each face spans the texture once (glass, fixtures)

    def _vid(self, p):
        key = tuple(int(round(c / EPS)) for c in p)
        if key not in self.index:
            self.index[key] = len(self.points)
            self.points.append(tuple(p))
        return self.index[key]

    def poly(self, corners, uvs):
        ids = [self._vid(p) for p in corners]
        # drop repeated corners (a quad that collapses to a triangle): Maya would merge them and the UV list
        # would no longer line up with the face's vertices
        keep = [k for k in range(len(ids)) if ids[k] != ids[k - 1]] if len(ids) > 1 else list(range(len(ids)))
        ids = [ids[k] for k in keep]
        uvs = [uvs[k] for k in keep]
        if len(set(ids)) < 3 or len(set(ids)) != len(ids):
            return
        self.counts.append(len(ids))
        self.connects.extend(ids)
        for uv in uvs:
            self.uv_ids.append(len(self.uvs))
            self.uvs.append(uv)

    def facing(self, corners, want):
        """Add polygon `corners`, flipping the winding so its normal points along `want` (3-vector)."""
        n = _normal3(corners)
        if sum(n[i] * want[i] for i in range(3)) < 0:
            corners = corners[::-1]
        uvs = [_uv_for(p, want, self.uv_scale) for p in corners]
        if self.fit:
            us, vs = [u for u, _ in uvs], [v for _, v in uvs]
            du, dv = (max(us) - min(us)) or 1.0, (max(vs) - min(vs)) or 1.0
            uvs = [((u - min(us)) / du, (v - min(vs)) / dv) for u, v in uvs]
        self.poly(corners, uvs)

    def build(self, name, parent):
        if not self.counts:
            return None
        fn = om.MFnMesh()
        obj = fn.create(om.MFloatPointArray([om.MFloatPoint(*p) for p in self.points]), self.counts, self.connects)
        fn.setUVs([u for u, _ in self.uvs], [v for _, v in self.uvs])
        fn.assignUVs(self.counts, self.uv_ids)
        return _finish_mesh(om.MFnDagNode(obj).fullPathName(), name, parent)


def _normal3(p):
    a = [p[1][i] - p[0][i] for i in range(3)]
    b = [p[2][i] - p[0][i] for i in range(3)]
    n = (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
    if math.sqrt(sum(c * c for c in n)) < 1e-9 and len(p) > 3:   # degenerate first corner: use a later one
        return _normal3(p[1:])
    return n


def _uv_for(p, n, scale=2.0):
    """World-scaled planar UVs, `scale` metres per tile. Floors/ceilings map x/z; walls map along their own
    horizontal tangent (u) and height (v), so angled and curved walls keep square texels instead of the
    stretch a dominant-axis projection gives them."""
    nl = math.sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]) or 1.0
    if abs(n[1]) / nl > 0.7:
        return (p[0] / scale, p[2] / scale)
    h = math.hypot(n[0], n[2]) or 1.0
    tx, tz = n[2] / h, -n[0] / h                       # right-hand direction seen from the front
    return ((p[0] * tx + p[2] * tz) / scale, p[1] / scale)


def _uvs(material, role):
    """Tile size for a surface: the material's "uv_scale" or the role default."""
    return float((material or {}).get("uv_scale", UV_SCALE[role]))


def _finish_mesh(xform, name, parent):
    xform = cmds.parent(xform, parent)[0]
    xform = cmds.ls(cmds.rename(xform, name), long=True)[0]
    shape = cmds.listRelatives(xform, shapes=True, fullPath=True)[0]
    cmds.setAttr(shape + ".doubleSided", 0)   # the client back-face culls
    return xform


def _facet_mesh(pieces, name, parent, up, uv_scale=2.0):
    """Polygons (optionally with holes) -> one triangulated, vertex-merged mesh facing up (+Y) or down.
    pieces: [(outer_points3d, [hole_points3d, ...]), ...]"""
    parts = []
    for outer, holes in pieces:
        pts = list(outer)
        for h in holes:
            pts += [()] + list(h)
        f = cmds.polyCreateFacet(p=pts, ch=False)[0]
        cmds.polyTriangulate(f, ch=False)
        # area-weighted normal: a collinear run of points (doorway jambs on an edge) can make the first
        # triangle a zero-area sliver whose normal points either way
        sel_ = om.MSelectionList()
        sel_.add(f)
        it = om.MItMeshPolygon(sel_.getDagPath(0))
        ny = 0.0
        while not it.isDone():
            ny += it.getNormal().y * it.getArea()
            it.next()
        if (ny < 0) == up:
            cmds.polyNormal(f, normalMode=0, userNormalMode=0, ch=False)
        parts.append(f)
    if not parts:
        return None
    mesh = parts[0] if len(parts) == 1 else cmds.polyUnite(parts, ch=False, mergeUVSets=True)[0]
    cmds.polyMergeVertex(mesh, d=0.001, ch=False)
    sel = om.MSelectionList()
    sel.add(mesh)
    fn = om.MFnMesh(sel.getDagPath(0))
    pts = fn.getPoints()
    fn.clearUVs()
    fn.setUVs([p.x / uv_scale for p in pts], [p.z / uv_scale for p in pts])
    counts, ids = fn.getVertices()
    fn.assignUVs(counts, ids)
    return _finish_mesh(cmds.ls(mesh, long=True)[0], name, parent)


def _grid_rects(piece, holes):
    """Rectangle (u0,u1,v0,v1) minus `holes`, split on a shared grid (no T-junctions)."""
    u0, u1, v0, v1 = piece
    us = sorted({u0, u1, *[max(u0, min(u1, x)) for h in holes for x in h[:2]]})
    vs = sorted({v0, v1, *[max(v0, min(v1, y)) for h in holes for y in h[2:]]})
    out = []
    for a, b in zip(us, us[1:]):
        for c, d in zip(vs, vs[1:]):
            if b - a < EPS or d - c < EPS:
                continue
            mu, mv = (a + b) / 2, (c + d) / 2
            if any(h[0] < mu < h[1] and h[2] < mv < h[3] for h in holes):
                continue
            out.append((a, b, c, d))
    return out


def _subtract_intervals(span, cuts):
    pieces = [span]
    for c0, c1 in cuts:
        nxt = []
        for a, b in pieces:
            if c1 <= a + EPS or c0 >= b - EPS:
                nxt.append((a, b))
                continue
            if c0 > a + EPS:
                nxt.append((a, c0))
            if c1 < b - EPS:
                nxt.append((c1, b))
        pieces = nxt
    return pieces


def _insert_on_edges(poly3, jambs):
    """poly3: [(x,y,z)] ring; jambs: {edge_index: [u, ...]} -> ring with extra vertices along those edges."""
    out = []
    n = len(poly3)
    for i in range(n):
        p, q = poly3[i], poly3[(i + 1) % n]
        out.append(p)
        length = math.dist((p[0], p[2]), (q[0], q[2]))
        for u in sorted(set(jambs.get(i, []))):
            if EPS < u < length - EPS:
                f = u / length
                out.append(tuple(p[k] + (q[k] - p[k]) * f for k in range(3)))
    return out


# ============================================================================
# stages (raised platforms with an access ramp)
# ============================================================================

def _stage_geometry(room, st, base_y):
    """Returns dict with the floor hole outline, stage top ring, ramp quad and side faces (all 3D)."""
    (x0, z0), (x1, z1) = st["min"], st["max"]
    x0, x1, z0, z1 = min(x0, x1), max(x0, x1), min(z0, z1), max(z0, z1)
    h = float(st.get("height", 1.0))
    top = base_y + h
    rect = [(x0, z0), (x1, z0), (x1, z1), (x0, z1)]                       # CCW
    if not all(_inside(c, room["poly"]) for c in rect):
        raise ValueError(f"room {room['name']}: stage {st} must lie inside the room")
    rp = st.get("ramp")
    if not rp:
        raise ValueError(f"room {room['name']}: every stage needs a ramp so it is reachable")
    d = SIDES[rp.get("side", "+z")]
    w, length = float(rp.get("width", 1.5)), float(rp.get("length", h * 3))
    k = next(i for i in range(4) if abs(Edge({"poly": rect}, i).n_out[0] - d[0]) < 1e-6
             and abs(Edge({"poly": rect}, i).n_out[1] - d[1]) < 1e-6)
    e = Edge({"poly": rect}, k)
    mid = e.length / 2 + float(rp.get("offset", 0.0))
    if mid - w / 2 < -EPS or mid + w / 2 > e.length + EPS:
        raise ValueError(f"room {room['name']}: stage ramp is wider than the stage edge")
    a = e.at(mid - w / 2)
    b = e.at(mid + w / 2)
    a_out = (a[0] + d[0] * length, a[1] + d[1] * length)
    b_out = (b[0] + d[0] * length, b[1] + d[1] * length)
    if not (_inside(a_out, room["poly"]) and _inside(b_out, room["poly"])):
        raise ValueError(f"room {room['name']}: stage ramp runs outside the room")
    outline2 = rect[:k + 1] + [a, a_out, b_out, b] + rect[k + 1:]
    top2 = rect[:k + 1] + [a, b] + rect[k + 1:]
    P = lambda pt, y: (pt[0], y, pt[1])
    sides = []
    # stage walls (vertical, facing away from the stage), skipping the ramp mouth on edge k
    for i in range(4):
        ei = Edge({"poly": rect}, i)
        spans = _subtract_intervals((0.0, ei.length), [(mid - w / 2, mid + w / 2)] if i == k else [])
        for u0, u1 in spans:
            p0, p1 = ei.at(u0), ei.at(u1)
            sides.append(([P(p0, base_y), P(p1, base_y), P(p1, top), P(p0, top)], (ei.n_out[0], 0, ei.n_out[1])))
    # ramp side triangles (or a stepped stringer), facing away from the ramp's centre line
    centre = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    steps = []
    if rp.get("steps"):
        # a staircase: treads + risers to look at; the walkable floor stays the ramp under them (stock style)
        n = max(2, round(h / float(rp.get("step_height", 0.2))))
        rise = h / n
        off = lambda pt, s: (pt[0] + d[0] * s, pt[1] + d[1] * s)
        for j in range(n):                                     # j = 0 is the bottom step
            s0, s1 = length * (1 - (j + 1) / n), length * (1 - j / n)
            yt = base_y + (j + 1) * rise
            a0, b0, a1, b1 = off(a, s0), off(b, s0), off(a, s1), off(b, s1)
            steps.append(([P(a0, yt), P(b0, yt), P(b1, yt), P(a1, yt)], (0, 1, 0)))
            steps.append(([P(a1, yt - rise), P(b1, yt - rise), P(b1, yt), P(a1, yt)], (d[0], 0, d[1])))
            for p0, p1 in ((a0, a1), (b0, b1)):
                away = (p0[0] - centre[0] - d[0] * s0, p0[1] - centre[1] - d[1] * s0)
                sides.append(([P(p0, base_y), P(p1, base_y), P(p1, yt), P(p0, yt)], (away[0], 0, away[1])))
    else:
        for edge_pt, out_pt in ((a, a_out), (b, b_out)):
            away = (edge_pt[0] - centre[0], edge_pt[1] - centre[1])
            sides.append(([P(out_pt, base_y), P(edge_pt, base_y), P(edge_pt, top)], (away[0], 0, away[1])))
    return {
        "hole": [P(pt, base_y) for pt in outline2],
        "top": [P(pt, top) for pt in top2],
        "ramp": [P(a, top), P(b, top), P(b_out, base_y), P(a_out, base_y)],
        "sides": sides,
        "steps": steps,
    }


def _slope_steps(room, acc):
    """Treads + risers over a sloped room's ramp (slope {"steps": true}). Tread j sits at the ramp height at its
    upper edge, so the ramp runs just under the step nosings and the walls' sloped bottoms stay hidden."""
    sl = room["slope"]
    d = room["slope_dir"]
    e = (-d[1], d[0])                                  # across the stair
    lo, hi = room["slope_range"]
    c0 = min(_dot2(p, e) for p in room["poly"])
    c1 = max(_dot2(p, e) for p in room["poly"])
    y0, y1 = float(sl["y_min"]), float(sl["y_max"])
    n = max(2, round(abs(y1 - y0) / float(sl.get("step_height", 0.2))))
    up = 1.0 if y1 > y0 else -1.0                      # +dir rises
    P = lambda u, c, y: (d[0] * u + e[0] * c, y, d[1] * u + e[1] * c)
    run = (hi - lo) / n
    for j in range(n):
        # j-th step from the bottom
        ua, ub = (lo + j * run, lo + (j + 1) * run) if up > 0 else (hi - (j + 1) * run, hi - j * run)
        yt = min(y0, y1) + (j + 1) * abs(y1 - y0) / n
        yb = yt - abs(y1 - y0) / n
        front = ua if up > 0 else ub
        acc.facing([P(ua, c0, yt), P(ub, c0, yt), P(ub, c1, yt), P(ua, c1, yt)], (0, 1, 0))
        nf = (-up * d[0], 0, -up * d[1])
        acc.facing([P(front, c0, yb), P(front, c1, yb), P(front, c1, yt), P(front, c0, yt)], nf)


def _dot2(a, b):
    return a[0] * b[0] + a[1] * b[1]


# ============================================================================
# spec handling
# ============================================================================

def _normalize(spec):
    rooms = [_normalize_room(r, i, spec) for i, r in enumerate(spec.get("rooms") or [])]
    if not rooms:
        raise ValueError("spec needs at least one room")
    names = [r["name"] for r in rooms]
    if len(set(names)) != len(names):
        raise ValueError("room names must be unique")
    return {
        "name": spec.get("name") or "swg_building",
        "rooms": rooms,
        "doors": list(spec.get("doors") or []),
        "entrances": list(spec.get("entrances") or []),
        "lights": spec.get("lights", True),
        # partition walls (edges shared with another room) are drawn this thick: each side inset by half, openings
        # lined, the walk floor tongued through doorways to the portal. 0 = back-to-back zero-width walls.
        "wall_thickness": float(spec.get("wall_thickness", 0.0)),
        "shell_color": tuple(spec.get("shell_color") or (0.42, 0.42, 0.45)),
        "shell": spec.get("shell"),                       # {"meshes": [stock exterior transforms]}: see _apply_shell
        "shell_materials": spec.get("shell_materials") or {},
        "exterior": spec.get("exterior") or {},          # {"porch": {...material}, "trim": {...material}}
        "ground_y": spec.get("ground_y"),
        "collision": bool(spec.get("collision_meshes", False)),
        "flat_terrain": bool(spec.get("flat_terrain", False)),
        "base": dict(spec.get("base") or {}),
        "trim_materials": spec.get("trim_materials") or {},
        "texture_dir": spec.get("texture_dir", os.path.join(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"),
                                                            "source", spec.get("name") or "swg_building")),
    }


def _partition_offsets(room, rooms, thickness):
    """Per edge inset (metres) for wall thickness: half the thickness on edges mostly shared with another room
    (the neighbour insets the other half), the whole thickness on outside walls (the shell face stays on the
    edge), so every wall - and every door leaf in it - is `thickness` deep."""
    n = len(room["poly"])
    if thickness <= 0 or room["slope"] or room["spiral"]:
        return [0.0] * n
    out = []
    for i in range(n):
        e = Edge(room, i)
        shared = 0.0
        for other in rooms:
            if other is not room:
                for j in range(len(other["poly"])):
                    ov = e.overlap_with(Edge(other, j))
                    if ov:
                        shared += ov[1] - ov[0]
        out.append(thickness / 2 if shared >= 0.5 * e.length else thickness)
    return out


def _inset_poly(poly, offsets):
    """CCW polygon with edge i moved inward by offsets[i] (corners re-intersected)."""
    n = len(poly)
    lines = []
    for i in range(n):
        p, q = poly[i], poly[(i + 1) % n]
        L = math.hypot(q[0] - p[0], q[1] - p[1]) or 1.0
        t = ((q[0] - p[0]) / L, (q[1] - p[1]) / L)
        nin = (-t[1], t[0])
        lines.append(((p[0] + nin[0] * offsets[i], p[1] + nin[1] * offsets[i]), t))
    out = []
    for i in range(n):
        (a, ta), (b, tb) = lines[i - 1], lines[i]
        den = ta[0] * tb[1] - ta[1] * tb[0]
        if abs(den) < 1e-6:
            out.append(b)
            continue
        k = ((b[0] - a[0]) * tb[1] - (b[1] - a[1]) * tb[0]) / den
        out.append((a[0] + ta[0] * k, a[1] + ta[1] * k))
    return out


def _floor_ring(room, vroom, offsets, holes, lvl, sills=None):
    """Walk-floor outline at level lvl: the (inset) room outline with the doorway jambs on it; on inset edges a
    tongue runs out through each doorway to the portal on the shared edge (not through sills: the floor stops at the
    wall's inner face there, off the portal, so that edge blocks)."""
    ring = []
    for ei in range(len(room["poly"])):
        e, ve = Edge(room, ei), Edge(vroom, ei)
        ring.append((ve.p[0], lvl, ve.p[1]))
        ops = sorted((h for h in holes.get((room["name"], ei), []) if abs(h[2] - lvl) < 0.05
                      and (room["name"], ei, round(h[0], 3)) not in (sills or {})), key=lambda h: h[0])
        for (u0, u1, _, _) in ops:
            o0, o1 = e.at(u0), e.at(u1)
            if offsets[ei] > 0:
                v0, v1 = ve.at(ve.u_of(o0)), ve.at(ve.u_of(o1))
                ring += [(v0[0], lvl, v0[1]), (o0[0], lvl, o0[1]), (o1[0], lvl, o1[1]), (v1[0], lvl, v1[1])]
            else:
                ring += [(o0[0], lvl, o0[1]), (o1[0], lvl, o1[1])]
    return ring


def _room(rooms, key):
    for r in rooms:
        if r["name"] == key or str(r["cell"]) == str(key):
            return r
    raise ValueError(f"unknown room {key!r}")


def _shared_edges(a, b):
    out = []
    for i in range(len(a["poly"])):
        ea = Edge(a, i)
        for j in range(len(b["poly"])):
            ov = ea.overlap_with(Edge(b, j))
            if ov:
                out.append((i, j, ov))
    return out


def _wall_span(room, edge, u0, u1):
    """Vertical extent of a room's wall over [u0,u1] of its edge, including the slab band below raised floors."""
    lo = min(floor_y(room, edge.at(u0)), floor_y(room, edge.at(u1)))
    hi = max(top_y(room, edge.at(u0)), top_y(room, edge.at(u1)))
    if room.get("base_top") is not None and not room["slope"] and abs(room["floor_y"] - room["base_top"]) < 0.05:
        return room["base_top"], hi        # sits on the terrain base; the base skirt covers below
    g = room.get("ground_y")
    if g is not None and not room["slope"] and 0.0 <= room["floor_y"] - g < 2.0:     # (not rooms below ground)
        return float(g) - 0.3, hi          # raised ground floor: plinth down into the terrain
    # upper storeys and underground ones (a landing well's stacked levels) reach down through the slab to the room
    # below, so a facade of stacked rooms has no gaps
    ext = RAMP_SOFFIT if room["slope"] else (SLAB if lo > SLAB - EPS or lo < -SLAB else 0.0)
    return lo - ext, hi


def _rotation_facing(d):
    """rotateY so a connectPobCells quad's front faces direction d (plan vector). Its front is local -Z because
    the quad is built through MayaSceneBuilder::createMesh, which mirrors X."""
    return math.degrees(math.atan2(-d[0], -d[1]))


# ============================================================================
# build
# ============================================================================

def build(spec: dict, new_scene: bool = False) -> dict:
    s = _normalize(spec)
    if new_scene:
        cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    name, rooms = s["name"], s["rooms"]
    if cmds.objExists("|" + name):
        cmds.delete("|" + name)
    mel.eval(f'createPobTemplate -n "{name}" -cells {len(rooms) + 1} -layoutSpacing 0')
    root = cmds.ls("|" + name, long=True)[0]
    for i in range(len(rooms) + 1):
        cell = f"{root}|r{i}"
        cmds.setAttr(cell + ".translate", 0.0, 0.0, 0.0, type="double3")
        cmds.setAttr(cell + ".rotate", 0.0, 0.0, 0.0, type="double3")
        if not cmds.attributeQuery("pobCellName", node=cell, exists=True):
            cmds.addAttr(cell, longName="pobCellName", dataType="string")
        cmds.setAttr(cell + ".pobCellName", "r0" if i == 0 else rooms[i - 1]["name"], type="string")

    holes = {}      # (room name, edge index) -> [(u0,u1,y0,y1)]
    arches = {}     # (room name, edge index) -> [(u0,u1,y0,y1)] doorways that get an arched head
    jambs = {}      # (room name, level y rounded) -> {edge index: [u, ...]}
    portals = []
    porches = []
    entrance_info = []
    sills = {}      # (room name, edge index, u0 rounded) -> parapet height: openings the walk floor stops short of
    base = None
    if not s["flat_terrain"]:
        # the pad sits at the entrance storey (a basement stays below it); no entrances: the lowest storey
        ent_rooms = [_room(rooms, e["room"]) for e in s["entrances"]]
        level = min(r["floor_y"] for r in (ent_rooms or rooms))
        ground_rooms = [r for r in rooms if not r["slope"] and abs(r["floor_y"] - level) < 0.05]
        base_top = ground_rooms[0]["floor_y"]
        g = s["ground_y"] if s["ground_y"] is not None else base_top - 0.8
        if base_top - g < 0.3:
            raise ValueError(f"terrain base needs the ground floor at least 0.3 m above ground_y ({g}); raise floor_y, "
                             "lower ground_y, or set flat_terrain")
        for r in ground_rooms:
            r["base_top"] = base_top
        base = {"rooms": ground_rooms, "top": base_top, "ground": float(g)}

    door_holes = set()      # (room name, edge, u0 rounded) of openings that take a door leaf: overlapping casings

    def add_opening(room, ei, u0, u1, y0, y1):
        holes.setdefault((room["name"], ei), []).append((u0, u1, y0, y1))
        jambs.setdefault((room["name"], round(y0, 3)), {}).setdefault(ei, []).extend([u0, u1])

    # --- doors between rooms -------------------------------------------------------------------
    for d in s["doors"]:
        a, b = (_room(rooms, k) for k in d["rooms"])
        shared = _shared_edges(a, b)
        if "edge" in d:
            shared = [x for x in shared if x[0] == int(d["edge"])]
        if not shared:
            raise ValueError(f"door {d['rooms']}: rooms do not share a wall")
        if "near" in d:    # several shared walls (e.g. a stair's end wall and its long side): the one nearest
            nx_, nz_ = d["near"]
            mid = lambda x: Edge(a, x[0]).at((x[2][0] + x[2][1]) / 2)
            ia, ib, (lo, hi) = min(shared, key=lambda x: (mid(x)[0] - nx_) ** 2 + (mid(x)[1] - nz_) ** 2)
        else:
            ia, ib, (lo, hi) = max(shared, key=lambda x: x[2][1] - x[2][0])
        ea, eb = Edge(a, ia), Edge(b, ib)
        w = float(d.get("width", DEFAULT_DOOR[0]))
        style = d.get("style") or ("door" if d.get("door_style") else "open")
        leaf = DOOR_LEAF.get(d.get("door_style", "")) if style == "door" else None
        if leaf:
            if leaf[1] + DOOR_FIT_W <= (hi - lo) - 0.3:       # opening cut to the leaf, jambs either side
                w = leaf[1] + DOOR_FIT_W                     # (a closed door closes its portal: a wider cut shows void)
            else:                                            # the leaf would clip the wall: open doorway
                d = dict(d, style="open", door_style="")
                style, leaf = "open", None
                w = min(w, hi - lo - 0.3)
        uc = (lo + hi) / 2 + float(d.get("offset", 0.0))
        if uc - w / 2 < lo - EPS or uc + w / 2 > hi + EPS:
            raise ValueError(f"door {d['rooms']}: a {w} m door does not fit the {hi - lo:.2f} m shared wall")
        pt = ea.at(uc)
        common = [y for y in floors_at(a, pt) if any(abs(y - yb) < 0.05 for yb in floors_at(b, pt))]
        if "y" in d:
            common = [y for y in common if abs(y - float(d["y"])) < 0.05]
        if not common:
            raise ValueError(f"door {d['rooms']}: no floor height shared by both rooms at the doorway "
                             f"({floors_at(a, pt)} vs {floors_at(b, pt)})")
        y = common[0]
        h = float(d.get("height", DEFAULT_DOOR[1]))
        if leaf:
            h = leaf[2] + DOOR_FIT_H
        for r in (a, b):   # stay under the next slab / ceiling
            ceilings = [l - SLAB for l in floors_at(r, pt) if l > y + 0.05] + [top_y(r, pt)]   # same tolerance as `common`
            h = min(h, min(ceilings) - y - 0.05)
        if leaf and h < leaf[2] + DOOR_FIT_H - EPS:          # no headroom for the leaf: open doorway
            d = dict(d, style="open", door_style="")
            style, leaf = "open", None
        if h < 2.0:
            raise ValueError(f"door {d['rooms']}: only {h:.2f} m of headroom")
        add_opening(a, ia, uc - w / 2, uc + w / 2, y, y + h)
        ub = eb.u_of(pt)
        add_opening(b, ib, ub - w / 2, ub + w / 2, y, y + h)
        if leaf:
            door_holes.update({(a["name"], ia, round(uc - w / 2, 3)), (b["name"], ib, round(ub - w / 2, 3))})
        # doorway style: "door" (spawned door model, needs door_style), "open" (plain opening) or "arch" (open,
        # with an arched head). Default: a door when a door_style is named, otherwise an open doorway.
        if style not in ("door", "open", "arch"):
            raise ValueError(f"door {d['rooms']}: style must be door, open or arch")
        if style == "door" and not d.get("door_style"):
            raise ValueError(f"door {d['rooms']}: style door needs a door_style (e.g. door_tato_interior_s01)")
        if style == "arch":
            arches.setdefault((a["name"], ia), []).append((uc - w / 2, uc + w / 2, y, y + h))
            arches.setdefault((b["name"], ib), []).append((ub - w / 2, ub + w / 2, y, y + h))
        portals.append({"from": a["cell"], "to": b["cell"], "pos": (pt[0], y, pt[1]), "width": w, "height": h,
                        "facing": ea.n_out, "door_style": d.get("door_style", "") if style == "door" else "",
                        "door_hardpoint": style == "door" and bool(d.get("door_hardpoint", True))})

    # --- entrances ---------------------------------------------------------------------------
    for e in s["entrances"]:
        room = _room(rooms, e["room"])
        if "edge" in e:
            ei = int(e["edge"])
        else:
            want = SIDES[e.get("side", "+z")]
            ei = max(range(len(room["poly"])), key=lambda i: _dot2(Edge(room, i).n_out, want) + Edge(room, i).length * 1e-3)
        edge = Edge(room, ei)
        w = float(e.get("width", DEFAULT_DOOR[0]))
        leaf = DOOR_LEAF.get(e.get("door_style") or "")
        if leaf and leaf[1] + DOOR_FIT_W <= w + EPS and leaf[2] + DOOR_FIT_H <= float(e.get("height", DEFAULT_DOOR[1])) + EPS:
            # cut to the leaf: a closed door closes its portal, so any opening round the leaf shows void
            e = dict(e, width=leaf[1] + DOOR_FIT_W, height=leaf[2] + DOOR_FIT_H)
            w = leaf[1] + DOOR_FIT_W
        uc = edge.length / 2 + float(e.get("offset", 0.0))
        if "at" in e:      # plan point the doorway should centre on (clamped onto the wall)
            uc = min(max(edge.u_of(tuple(e["at"])), w / 2 + 0.15), edge.length - w / 2 - 0.15)
        if uc - w / 2 < -EPS or uc + w / 2 > edge.length + EPS:
            raise ValueError(f"entrance on {room['name']} edge {ei}: {w} m does not fit the {edge.length:.2f} m wall")
        pt = edge.at(uc)
        y = float(e.get("y", floors_at(room, pt)[0]))
        h = min(float(e.get("height", DEFAULT_DOOR[1])), top_y(room, pt) - y - 0.05)
        if e.get("door_style") and not door_fits(e["door_style"], w, h):
            e = dict(e, door_style="")       # the leaf would clip the opening: leave the entrance open
        for other in rooms:
            if other is room:
                continue
            for j in range(len(other["poly"])):
                ov = edge.overlap_with(Edge(other, j))
                if ov and ov[0] < uc + w / 2 and ov[1] > uc - w / 2:
                    lo_o, hi_o = _wall_span(other, Edge(other, j), 0, Edge(other, j).length)
                    if lo_o < y + h and hi_o > y:
                        raise ValueError(f"entrance on {room['name']} opens into {other['name']}; use a door")
        add_opening(room, ei, uc - w / 2, uc + w / 2, y, y + h)
        if e.get("door_style") and DOOR_LEAF.get(e["door_style"]):
            door_holes.add((room["name"], ei, round(uc - w / 2, 3)))
        if e.get("sill"):       # open to the exterior above a parapet (a hangar mouth over a drop): no way out on foot
            sills[(room["name"], ei, round(uc - w / 2, 3))] = float(e["sill"])
        portals.append({"from": 0, "to": room["cell"], "pos": (pt[0], y, pt[1]), "width": w, "height": h,
                        "facing": edge.n_in, "door_style": e.get("door_style", ""),
                        "door_hardpoint": bool(e.get("door_hardpoint", bool(e.get("door_style"))))})
        entrance_info.append({"room": room, "edge": edge, "uc": uc, "w": w, "y": y, "h": h, "spec": e})
        if e.get("porch") and s["flat_terrain"]:
            porches.append(_porch_geometry(edge, uc, w, y, e["porch"], s["ground_y"]))

    # --- windows: wall holes + a non-passable portal to the exterior (so the world shows through the glass)
    windows = []          # (room, edge index, u0, u1, y0, y1)
    for room in rooms:
        if room["windows"]:
            for wdw in _place_windows(room, rooms, holes, room["windows"]):
                holes.setdefault((room["name"], wdw[1]), []).append(wdw[2:])
                windows.append(wdw)
                if s.get("window_portals", True):
                    e = Edge(room, wdw[1])
                    uc = (wdw[2] + wdw[3]) / 2.0
                    pt = e.at(uc)
                    portals.append({"from": 0, "to": room["cell"], "pos": (pt[0], wdw[4], pt[1]),
                                    "width": wdw[3] - wdw[2], "height": wdw[5] - wdw[4], "facing": e.n_in,
                                    "door_style": "", "door_hardpoint": False, "passable": False})

    # walls at least as deep as the thickest door leaf they hold (+ clearance); 0 = legacy zero-width walls
    wall_t = s["wall_thickness"]
    if wall_t > 0:
        wall_t = max(wall_t, wall_for_doors([p_["door_style"] for p_ in portals if p_["door_style"]]))

    # --- geometry ------------------------------------------------------------------------------
    ext_cfg = s["exterior"]
    shell = MeshAccumulator(_uvs(s["shell_materials"], "shell"))
    glass_out = MeshAccumulator(fit=True)
    dome_out = MeshAccumulator(_uvs(ext_cfg.get("dome"), "dome"))
    shell_trim = MeshAccumulator(_uvs(ext_cfg.get("trim"), "trim"))     # exterior cornice
    if not s["shell"]:     # the outside face of every entrance that takes a door leaf: the same overlapping casing
        for ent in entrance_info:
            u0 = ent["uc"] - ent["w"] / 2
            if (ent["room"]["name"], ent["edge"].index, round(u0, 3)) in door_holes:
                _door_casing(shell_trim, ent["edge"], u0, u0 + ent["w"], ent["y"], ent["y"] + ent["h"],
                             top_y(ent["room"], ent["edge"].at(ent["uc"])), ent["edge"].n_out)
    shell_flat = []        # roofs (up) handled as facets
    shell_soffits = []     # undersides of sloped rooms (down)
    tex = s["texture_dir"]
    summary_rooms = []
    for room in rooms:
        cell = f"{root}|r{room['cell']}"
        walls = MeshAccumulator(_uvs(room["materials"].get("wall"), "wall"))
        trim = MeshAccumulator(_uvs({**s["trim_materials"], **room["materials"].get("trim", {})}, "trim"))
        poly = room["poly"]
        offsets = _partition_offsets(room, rooms, wall_t)
        vroom = dict(room, poly=_inset_poly(poly, offsets)) if any(offsets) else room   # visible (inset) outline
        vpoly = vroom["poly"]
        for ei in range(len(poly)):
            edge, vedge = Edge(room, ei), Edge(vroom, ei)
            yb0, yb1 = floor_y(room, edge.p), floor_y(room, edge.q)
            yt0, yt1 = top_y(room, edge.p), top_y(room, edge.q)
            constant = abs(yb0 - yb1) < EPS
            wall_holes = holes.get((room["name"], ei), [])
            remap = lambda hs: [(vedge.u_of(edge.at(h[0])), vedge.u_of(edge.at(h[1])), *h[2:]) for h in hs]
            v_holes = remap(wall_holes)
            n_in3, n_out3 = (edge.n_in[0], 0, edge.n_in[1]), (edge.n_out[0], 0, edge.n_out[1])
            W = lambda u, y: (edge.at(u)[0], y, edge.at(u)[1])
            Wv = lambda u, y: (vedge.at(u)[0], y, vedge.at(u)[1])
            if constant:
                for a, b, c, d_ in _grid_rects((0.0, vedge.length, yb0, yt0), v_holes):
                    walls.facing([Wv(a, c), Wv(b, c), Wv(b, d_), Wv(a, d_)], n_in3)
                if room["trim"]:
                    _wall_trim(trim, vedge, yb0, yt0, v_holes, room["levels"],
                               [(room["name"], ei, round(h[0], 3)) in door_holes for h in wall_holes])
                for (au0, au1, ay0, ay1) in remap(arches.get((room["name"], ei), [])):
                    _arch_head(walls, vedge, au0, au1, ay1, n_in3)
                if offsets[ei] > 0:     # line each opening through the wall's thickness, up to the shared edge
                    tt = (edge.t[0], 0, edge.t[1])
                    for (u0, u1, y0, y1), (v0, v1, _, _) in zip(wall_holes, v_holes):
                        hs = sills.get((room["name"], ei, round(u0, 3)))
                        if hs:          # parapet through the wall's depth: inner face, top, outer face
                            walls.facing([Wv(v0, y0), Wv(v1, y0), Wv(v1, y0 + hs), Wv(v0, y0 + hs)], n_in3)
                            walls.facing([Wv(v0, y0 + hs), Wv(v1, y0 + hs), W(u1, y0 + hs), W(u0, y0 + hs)], (0, 1, 0))
                            walls.facing([W(u0, y0 - 0.3), W(u1, y0 - 0.3), W(u1, y0 + hs), W(u0, y0 + hs)], n_out3)
                        walls.facing([Wv(v0, y0), W(u0, y0), W(u0, y1), Wv(v0, y1)], tt)
                        walls.facing([Wv(v1, y0), W(u1, y0), W(u1, y1), Wv(v1, y1)], (-tt[0], 0, -tt[2]))
                        walls.facing([Wv(v0, y1), Wv(v1, y1), W(u1, y1), W(u0, y1)], (0, -1, 0))
                        if y0 > yb0 + 0.05:
                            walls.facing([Wv(v0, y0), Wv(v1, y0), W(u1, y0), W(u0, y0)], (0, 1, 0))
            else:
                if wall_holes:
                    raise ValueError(f"room {room['name']}: doors are only supported on level walls of sloped rooms")
                walls.facing([W(0, yb0), W(edge.length, yb1), W(edge.length, yt1), W(0, yt0)], n_in3)
            # exterior shell: what no neighbouring wall covers
            covered = []
            for other in rooms:
                if other is room:
                    continue
                for j in range(len(other["poly"])):
                    oe = Edge(other, j)
                    ov = edge.overlap_with(oe)
                    if ov:
                        ou0, ou1 = sorted((oe.u_of(edge.at(ov[0])), oe.u_of(edge.at(ov[1]))))
                        lo_o, hi_o = _wall_span(other, oe, ou0, ou1)
                        covered.append((ov[0], ov[1], lo_o, hi_o))
            lo_s, _ = _wall_span(room, edge, 0, edge.length)
            if constant:
                for a, b, c, d_ in _grid_rects((0.0, edge.length, lo_s, yt0), covered + wall_holes):
                    shell.facing([W(a, c), W(b, c), W(b, d_), W(a, d_)], n_out3)
                if room["trim"]:   # cornice band where the wall top is exterior
                    for a, b in _subtract_intervals((0.0, edge.length), [(c[0], c[1]) for c in covered if c[3] > yt0 - 0.4]):
                        _cornice(shell_trim, edge, a, b, yt0)
            else:   # sloped wall: split along the slope only, down to the soffit
                for a, b in _subtract_intervals((0.0, edge.length), [(c[0], c[1]) for c in covered]):
                    ya, yb_ = floor_y(room, edge.at(a)), floor_y(room, edge.at(b))
                    shell.facing([W(a, ya - RAMP_SOFFIT), W(b, yb_ - RAMP_SOFFIT), W(b, top_y(room, edge.at(b))),
                                  W(a, top_y(room, edge.at(a)))], n_out3)

        # floors (walkable) per level, stages, ceilings, roof
        levels = floors_at(room, _interior_point(poly)) if not room["slope"] else [None]
        spiral = _spiral_stair(room, jambs) if room["spiral"] else None
        if spiral:
            levels = [room["floor_y"]]          # one walkable part: landing + helix + landing
        floor_pieces, hidden_ramps = [], []
        render_pieces = []           # (walk piece, its render version)
        stage_sides = MeshAccumulator(_uvs(room["materials"].get("wall"), "wall"))
        stage_steps = MeshAccumulator(_uvs(room["materials"].get("stair"), "stair"))
        ceiling_pieces = []
        for li, lvl in enumerate(levels):
            if room["slope"]:
                ring = [(p[0], floor_y(room, p), p[1]) for p in poly]
                jam = {}
                for (rn, ly), ed in jambs.items():
                    if rn == room["name"]:
                        for ei, us in ed.items():
                            jam.setdefault(ei, []).extend(us)
            else:
                ring = [(p[0], lvl, p[1]) for p in poly]
                jam = jambs.get((room["name"], round(lvl, 3)), {})
            outer = _floor_ring(room, vroom, offsets, holes, lvl, sills) if vroom is not room else _insert_on_edges(ring, jam)
            hole_rings = []
            obstacle_rings = []      # walk floor only: the render floor stays whole under counters and basins
            if li == 0 and not room["slope"]:
                for x0, z0, x1, z1 in room["obstacles"]:
                    obstacle_rings.append([(x0, lvl, z0), (x1, lvl, z0), (x1, lvl, z1), (x0, lvl, z1)])
                for st in room["stages"]:
                    g = _stage_geometry(room, st, lvl)
                    hole_rings.append(g["hole"])
                    floor_pieces.append((g["top"], []))
                    floor_pieces.append((g["ramp"], []))
                    if g["steps"]:
                        hidden_ramps.append(id(floor_pieces[-1]))
                    for corners, want in g["sides"]:
                        stage_sides.facing(corners, want)
                    for corners, want in g["steps"]:
                        stage_steps.facing(corners, want)
            if spiral:
                hole_rings.append(spiral["column_ring"])
            floor_pieces.insert(0, (outer, hole_rings + obstacle_rings))
            render_pieces.append((floor_pieces[0], (outer, hole_rings)))
            if room["slope"] and room["slope"].get("steps"):
                hidden_ramps.append(id(floor_pieces[0]))      # walk on the ramp, look at the steps
                _slope_steps(room, stage_steps)
            if li + 1 < len(levels):   # slab under the next level
                ceiling_pieces.append(([(p[0], levels[li + 1] - SLAB, p[1]) for p in vpoly], []))
        if room["slope"]:
            ceiling_pieces.append(([(p[0], top_y(room, p), p[1]) for p in poly], []))
            shell_soffits.append(([(p[0], floor_y(room, p) - RAMP_SOFFIT, p[1]) for p in poly], []))
        elif room["dome"]:
            _dome(walls, vpoly, room["floor_y"] + room["height"], room["dome"], inward=True)
            _dome(dome_out, poly, room["floor_y"] + room["height"], room["dome"], inward=False)
        else:
            ceiling_pieces.append(([(p[0], room["floor_y"] + room["height"], p[1]) for p in vpoly], []))
        if not room["dome"]:
            shell_flat.append(([(p[0], top_y(room, p), p[1]) for p in poly], []))

        mats = room["materials"]
        wall_tex = mats.get("wall", {}).get("texture") or (None if mats.get("wall", {}).get("shader") else panel_texture(os.path.join(tex, f"{name}_{room['name']}_wall.png"),
                                                                          room["color"], "wall", seed=room["cell"]) if tex else None)
        floor_tex = mats.get("floor", {}).get("texture") or (None if mats.get("floor", {}).get("shader") else panel_texture(os.path.join(tex, f"{name}_{room['name']}_floor.png"),
                                                                            room["color"], "floor", seed=room["cell"] + 100) if tex else None)
        wall_sg = _material(f"swg_{name}_{room['name']}_wall", room["color"], wall_tex, mats.get("wall", {}).get("shader"))
        floor_sg = _material(f"swg_{name}_{room['name']}_floor", [c * 0.62 for c in room["color"]], floor_tex,
                             mats.get("floor", {}).get("shader"))
        mesh_grp = cell + "|mesh"
        glass_in = MeshAccumulator(fit=True)
        for (wr, wei, u0, u1, y0, y1) in windows:
            if wr is not room:
                continue
            e = Edge(room, wei)
            W2 = lambda u, y, e=e: (e.at(u)[0], y, e.at(u)[1])
            glass_in.facing([W2(u0, y0), W2(u1, y0), W2(u1, y1), W2(u0, y1)], (e.n_in[0], 0, e.n_in[1]))
            glass_out.facing([W2(u0, y0), W2(u1, y0), W2(u1, y1), W2(u0, y1)], (e.n_out[0], 0, e.n_out[1]))
            _window_exterior(shell_trim, e, u0, u1, y0, y1)
        if glass_in.counts:
            wm = mats.get("window", {})
            win_sg = _material(f"swg_{name}_{room['name']}_window", tuple(wm.get("color", (0.55, 0.65, 0.8))),
                               wm.get("texture"), _glass_shader(wm, s))
            cmds.sets(glass_in.build(f"{room['name']}_windows", mesh_grp), edit=True, forceElement=win_sg)
        ceiling = _facet_mesh(ceiling_pieces, f"{room['name']}_ceiling", mesh_grp, up=False,
                              uv_scale=_uvs(mats.get("ceiling") or mats.get("wall"), "ceiling")) if ceiling_pieces else None
        parts = [walls.build(f"{room['name']}_walls", mesh_grp), stage_sides.build(f"{room['name']}_stage_sides", mesh_grp)]
        for p in parts:
            if p:
                cmds.sets(p, edit=True, forceElement=wall_sg)
        if ceiling:
            cm = mats.get("ceiling") or {}
            ceil_sg = _material(f"swg_{name}_{room['name']}_ceiling", tuple(cm.get("color", room["color"])),
                                cm.get("texture"), cm.get("shader")) if cm.get("shader") or cm.get("texture") else wall_sg
            cmds.sets(ceiling, edit=True, forceElement=ceil_sg)
        if trim.counts:
            tm = {**s["trim_materials"], **mats.get("trim", {})}
            trim_sg = _material(f"swg_{name}_{room['name']}_trim", tuple(tm.get("color", (0.35, 0.3, 0.26))),
                                tm.get("texture"), tm.get("shader"))
            cmds.sets(trim.build(f"{room['name']}_trim", mesh_grp), edit=True, forceElement=trim_sg)
        if room["collision"]:
            col = MeshAccumulator()
            _append(col, walls)
            _append(col, stage_sides)
            _append(col, glass_in)          # window holes stay closed to collision (portals there are not passable)
            if spiral:
                _append(col, spiral["column"])
            _collision_mesh(col, f"{room['name']}_collision", cell + "|collision")
        swap = {id(w): r for w, r in render_pieces}
        shown = [swap.get(id(fp), fp) for fp in floor_pieces if id(fp) not in hidden_ramps]   # stepped ramps: walk-only
        render_floor = _facet_mesh(shown, f"{room['name']}_floor_render", mesh_grp, up=True,
                                   uv_scale=_uvs(mats.get("floor"), "floor"))
        cmds.sets(render_floor, edit=True, forceElement=floor_sg)
        if stage_steps.counts:
            sm = mats.get("stair", {})
            step_sg = _material(f"swg_{name}_{room['name']}_stair", tuple(sm.get("color", (0.7, 0.68, 0.64))),
                                sm.get("texture"), sm.get("shader")) if sm else floor_sg
            cmds.sets(stage_steps.build(f"{room['name']}_steps", mesh_grp), edit=True, forceElement=step_sg)
        if spiral:
            sm = mats.get("stair", {})
            stair_sg = _material(f"swg_{name}_{room['name']}_stair", tuple(sm.get("color", (0.7, 0.68, 0.64))),
                                 sm.get("texture"), sm.get("shader"))
            cmds.sets(spiral["render"].build(f"{room['name']}_stairs", mesh_grp), edit=True, forceElement=stair_sg)
            cmds.sets(spiral["column"].build(f"{room['name']}_column", mesh_grp), edit=True, forceElement=wall_sg)
            walk = spiral["walk"].build(f"{room['name']}_floor", cell + "|collision|floor0")
        else:
            walk = _facet_mesh(floor_pieces, f"{room['name']}_floor", cell + "|collision|floor0", up=True)
        cmds.sets(walk, edit=True, forceElement="initialShadingGroup")
        wshape = cmds.listRelatives(walk, shapes=True, fullPath=True)[0]
        for attr, value in (("primaryVisibility", 0), ("castsShadows", 0), ("receiveShadows", 0),
                            ("overrideEnabled", 1), ("overrideDisplayType", 1)):
            cmds.setAttr(f"{wshape}.{attr}", value)

        hps = _hardpoints(room, levels, mesh_grp)
        if s["lights"]:
            light_levels = floors_at(room, (0, 0)) if spiral else ([l for l in levels if l is not None] or [None])
            room_windows = [Edge(room, w[1]) for w in windows if w[0] is room]
            _add_lights(cell, room, light_levels, room_windows, f"swg_{name}_{room['name']}")
        summary_rooms.append({"cell": f"r{room['cell']}", "name": room["name"], "levels": [l for l in levels if l is not None],
                              "stages": len(room["stages"]), "sloped": bool(room["slope"]), "hardpoints": hps,
                              "expected_floor_parts": len(levels)})

    ext = s["exterior"]
    r0_floor_pieces, porch_acc = [], MeshAccumulator(_uvs(ext.get("porch"), "porch"))
    r0_render_pieces = []   # what of the walk floor is drawn (not the ramps under porch steps)
    base_acc, skirt_acc = MeshAccumulator(_uvs(s["base"], "base")), MeshAccumulator(_uvs(s["base"], "base"))
    if base:
        tb = _terrain_base(base, entrance_info, s["base"])
        r0_floor_pieces += tb["floor"]
        r0_render_pieces += tb["floor"]
        for corners, want in tb["skirt"]:
            skirt_acc.facing(corners, want)
        for corners, want in tb["footing"]:
            shell_trim.facing(corners, want)
        for corners, want in tb["ramp_faces"]:
            porch_acc.facing(corners, want)
    for pg in porches:
        r0_floor_pieces += pg["floor"]
        r0_render_pieces += pg.get("render", pg["floor"])
        for corners, want in pg["faces"]:
            porch_acc.facing(corners, want)
    if r0_floor_pieces:
        walk = _facet_mesh(r0_floor_pieces, "exterior_floor", f"{root}|r0|collision|floor0", up=True)
        cmds.sets(walk, edit=True, forceElement="initialShadingGroup")
        _hide_helper(walk)
        top = _facet_mesh(r0_render_pieces, "porch_top", f"{root}|r0|mesh", up=True, uv_scale=_uvs(ext.get("porch"), "porch"))
        pm = ext.get("porch", {})
        porch_sg = _material(f"swg_{name}_porch", tuple(pm.get("color", (0.55, 0.5, 0.42))), pm.get("texture"), pm.get("shader"))
        cmds.sets(top, edit=True, forceElement=porch_sg)
        if porch_acc.counts:
            cmds.sets(porch_acc.build("porch_steps", f"{root}|r0|mesh"), edit=True, forceElement=porch_sg)
    if s["shell"]:      # stock exterior mesh as r0: cut the entrances through it, add reveals + collision
        _apply_shell(s, root, entrance_info, porch_acc, windows)
    else:
        if shell_trim.counts:
            tm = ext.get("trim", {})
            ctrim_sg = _material(f"swg_{name}_cornice", tuple(tm.get("color", (0.5, 0.45, 0.38))), tm.get("texture"), tm.get("shader"))
            cmds.sets(shell_trim.build("exterior_cornice", f"{root}|r0|mesh"), edit=True, forceElement=ctrim_sg)
        if skirt_acc.counts:
            bm = s["base"]
            skirt_sg = _material(f"swg_{name}_base", tuple(bm.get("color", s["shell_color"])), bm.get("texture"),
                                 bm.get("shader") or s["shell_materials"].get("shader"))
            cmds.sets(skirt_acc.build("base_skirt", f"{root}|r0|mesh"), edit=True, forceElement=skirt_sg)
        if s["collision"]:
            col = MeshAccumulator()
            _append(col, shell)
            _append(col, glass_out)
            _append(col, porch_acc)
            _append(col, skirt_acc)
            _append(col, dome_out)
            _collision_mesh(col, "exterior_collision", f"{root}|r0|collision")

        shell_tex = s["shell_materials"].get("texture") or (None if s["shell_materials"].get("shader") else panel_texture(os.path.join(tex, f"{name}_shell.png"), s["shell_color"],
                                                                          "wall", seed=99) if tex else None)
        shell_sg = _material(f"swg_{name}_shell", s["shell_color"], shell_tex, s["shell_materials"].get("shader"))
        if glass_out.counts:
            wm = ext.get("window", {})
            wsg = _material(f"swg_{name}_window_ext", tuple(wm.get("color", (0.5, 0.6, 0.75))), wm.get("texture"),
                            _glass_shader(wm, s))
            cmds.sets(glass_out.build("exterior_windows", f"{root}|r0|mesh"), edit=True, forceElement=wsg)
        if dome_out.counts:
            dm = ext.get("dome", {})
            dsg = _material(f"swg_{name}_dome", tuple(dm.get("color", s["shell_color"])), dm.get("texture"),
                            dm.get("shader") or s["shell_materials"].get("shader"))
            cmds.sets(dome_out.build("exterior_domes", f"{root}|r0|mesh"), edit=True, forceElement=dsg)
        if shell_flat and ext.get("roof"):
            rm = ext["roof"]
            rsg = _material(f"swg_{name}_roof", tuple(rm.get("color", s["shell_color"])), rm.get("texture"), rm.get("shader"))
            cmds.sets(_facet_mesh(shell_flat, "exterior_roof", f"{root}|r0|mesh", up=True, uv_scale=_uvs(rm, "roof")),
                      edit=True, forceElement=rsg)
            shell_flat = []
        for p in (shell.build("exterior_walls", f"{root}|r0|mesh"),
                  _facet_mesh(shell_flat, "exterior_roof", f"{root}|r0|mesh", up=True) if shell_flat else None,
                  _facet_mesh(shell_soffits, "exterior_soffit", f"{root}|r0|mesh", up=False) if shell_soffits else None):
            if p:
                cmds.sets(p, edit=True, forceElement=shell_sg)

    # --- portals -------------------------------------------------------------------------------
    made = []
    for p in portals:
        mel.eval(f'connectPobCells -root "{root}" -from r{p["from"]} -to r{p["to"]} -w {p["width"]} -h {p["height"]}'
                 + (f' -doorStyle "{p["door_style"]}"' if p["door_style"] else ""))
        pair = cmds.ls(selection=True, long=True)
        rot = _rotation_facing(p["facing"])
        for xf in pair:
            cmds.setAttr(xf + ".translate", *p["pos"], type="double3")
            cmds.setAttr(xf + ".rotate", 0.0, rot, 0.0, type="double3")
            if p.get("door_hardpoint"):
                _door_hardpoint(xf, p["pos"], p["facing"])
            for shp in cmds.listRelatives(xf, shapes=True, fullPath=True) or []:   # helper quads: not rendered
                cmds.setAttr(shp + ".primaryVisibility", 0)
                cmds.setAttr(shp + ".castsShadows", 0)
            if not p.get("passable", True):
                if not cmds.attributeQuery("portalPassable", node=xf, exists=True):
                    cmds.addAttr(xf, longName="portalPassable", attributeType="bool")
                cmds.setAttr(xf + ".portalPassable", False)
        made.append({"index": cmds.getAttr(pair[0] + ".buildingPortalIndex"), "between": [f"r{p['from']}", f"r{p['to']}"],
                     "passable": p.get("passable", True),
                     "center": [round(c, 3) for c in p["pos"]], "rotate_y": round(rot, 1), "nodes": pair})

    cmds.select(root)
    return {"root": root, "cells": len(rooms) + 1, "rooms": summary_rooms, "portals": made}


def _apply_shell(s, root, entrance_info, porch_acc, windows=()):
    """Shell mode (spec "shell": {"meshes": [...]}, needs flat_terrain): an existing exterior mesh (e.g. a stock
    filler building imported with its SWG shaders) becomes r0. Each entrance is cut through it as a box from the
    room's wall out past the facade (entrance "reveal" = metres from the room wall to the facade's outer face),
    lined with jambs + lintel in the material the cut removed most of. r0 collision = the cut shell + reveals +
    porches."""
    if not s["flat_terrain"]:
        raise ValueError("shell mode needs flat_terrain (the stock exterior already meets the ground)")
    meshes = [cmds.ls(m, long=True)[0] for m in s["shell"]["meshes"]]
    mesh_grp = f"{root}|r0|mesh"
    reveals = {}
    for ent in entrance_info:
        edge, uc, w, y, h = ent["edge"], ent["uc"], ent["w"], ent["y"], ent["h"]
        depth = float(ent["spec"].get("reveal", 1.0))
        o, t, n = edge.at(uc), edge.t, edge.n_out
        outline = ent["spec"].get("outline")
        if outline:
            _shaped_entrance(s, meshes, reveals, ent, outline, mesh_grp)
            continue
        sg = _shell_cut(meshes, o, t, n, (-w / 2, w / 2), (-0.05, depth + float(ent["spec"].get("cut_beyond", 2.0))),
                        (y, y + h))      # on out past the facade: trims, railings, terraces in the way
        acc = reveals.setdefault(sg or "", MeshAccumulator(UV_SCALE["shell"]))
        P = lambda u, v, yy, o=o, t=t, n=n: (o[0] + t[0] * u + n[0] * v, yy, o[1] + t[1] * u + n[1] * v)
        a, b = -w / 2, w / 2
        L = depth + max(0.0, float(ent["spec"].get("cut_beyond", 0.4)) - 0.4)   # line the whole passage
        yb = y - 0.35       # down past the floor/porch edge: no terrain showing at the lining's foot
        acc.facing([P(a, 0, yb), P(a, L, yb), P(a, L, y + h), P(a, 0, y + h)], (t[0], 0, t[1]))
        acc.facing([P(b, 0, yb), P(b, L, yb), P(b, L, y + h), P(b, 0, y + h)], (-t[0], 0, -t[1]))
        acc.facing([P(a, 0, y + h), P(b, 0, y + h), P(b, L, y + h), P(a, L, y + h)], (0, -1, 0))
    # windows: the painted stock window is cut out, the opening through the shell lined, glass at the facade
    glass = MeshAccumulator(fit=True)
    for (room, ei, u0, u1, y0, y1) in windows:
        e = Edge(room, ei)
        uc = (u0 + u1) / 2
        depth = (room.get("window_reveal") or {}).get((ei, round(uc, 3)))
        if depth is None:
            continue
        o, t, n = e.at(uc), e.t, e.n_out
        hw = (u1 - u0) / 2
        sg = _shell_cut(meshes, o, t, n, (-hw, hw), (-0.05, depth + 0.3), (y0, y1))
        acc = reveals.setdefault(sg or "", MeshAccumulator(UV_SCALE["shell"]))
        P = lambda u, v, yy, o=o, t=t, n=n: (o[0] + t[0] * u + n[0] * v, yy, o[1] + t[1] * u + n[1] * v)
        a, b = -hw, hw
        acc.facing([P(a, 0, y0), P(a, depth, y0), P(a, depth, y1), P(a, 0, y1)], (t[0], 0, t[1]))
        acc.facing([P(b, 0, y0), P(b, depth, y0), P(b, depth, y1), P(b, 0, y1)], (-t[0], 0, -t[1]))
        acc.facing([P(a, 0, y1), P(b, 0, y1), P(b, depth, y1), P(a, depth, y1)], (0, -1, 0))
        acc.facing([P(a, 0, y0), P(b, 0, y0), P(b, depth, y0), P(a, depth, y0)], (0, 1, 0))
        g = depth - 0.03
        pane = [P(a, g, y0), P(b, g, y0), P(b, g, y1), P(a, g, y1)]
        glass.facing(pane, (n[0], 0, n[1]))
        glass.facing(pane, (-n[0], 0, -n[1]))
    if glass.counts:
        gm = s["exterior"].get("window", {})
        gsg = _material(f"swg_{s['name']}_shell_glass", tuple(gm.get("color", (0.5, 0.6, 0.75))), gm.get("texture"),
                        _glass_shader(gm, s))
        cmds.sets(glass.build("exterior_windows", mesh_grp), edit=True, forceElement=gsg)
    col = MeshAccumulator()
    for m in meshes:
        for shape in cmds.listRelatives(m, shapes=True, fullPath=True, noIntermediate=True) or []:
            sel = om.MSelectionList()
            sel.add(shape)
            fn = om.MFnMesh(sel.getDagPath(0))
            pts = fn.getPoints(om.MSpace.kWorld)
            _, ids = fn.getTriangles()
            for k in range(0, len(ids), 3):
                col.poly([tuple(pts[ids[k + j]])[:3] for j in range(3)], [(0.0, 0.0)] * 3)
    for m in meshes:
        if cmds.objExists(m) and not m.startswith(mesh_grp + "|"):
            cmds.parent(m, mesh_grp, absolute=True)
    for sg, acc in reveals.items():
        r = acc.build("entrance_reveal", mesh_grp)
        if r:
            cmds.sets(r, edit=True, forceElement=sg or _material(f"swg_{s['name']}_shell", s["shell_color"]))
        _append(col, acc)
    _append(col, porch_acc)
    _collision_mesh(col, "exterior_collision", f"{root}|r0|collision")


def _shaped_entrance(s, meshes, reveals, ent, outline, mesh_grp):
    """Doorway through a painted stock door that follows the door's own outline (arch, pointed top...): the
    painted door faces go, the stock between the room wall and the door plane is cut inside the outline's box,
    the passage is lined by extruding the outline back to the room wall, and a cap at the room wall closes the
    outline around the (rectangular) doorway of the room."""
    edge, uc, w, y, h = ent["edge"], ent["uc"], ent["w"], ent["y"], ent["h"]
    # through the painted door and on out to the facade (frames and panels stand proud of recessed doors)
    depth = max(float(ent["spec"].get("door_depth") or 0.0), float(ent["spec"].get("reveal", 0.3)))
    o, t, n = edge.at(uc), edge.t, edge.n_out
    # outline u is along the world axis (x or z); this edge's tangent may run the other way
    flip = (t[0] + t[1]) < 0
    # the opening reaches the floor: outline points near the bottom drop to the doorway's floor
    bottom = min(q[1] for q in outline)
    pts = [((-q[0] if flip else q[0]), (y if q[1] < max(bottom, y) + 0.45 else q[1])) for q in outline]
    u_lo, u_hi = min(p[0] for p in pts), max(p[0] for p in pts)
    y_lo, y_hi = min(p[1] for p in pts), max(p[1] for p in pts)
    # the painted door itself, then whatever stands inside the outline box between the room and the door
    # the decal and the wall it is painted on, in the outline's own shape, from the room wall to just past it
    cut_poly = [(p[0], max(p[1], y - 0.3)) for p in pts]
    _shell_cut(meshes, o, t, n, None, (-0.05, depth + 0.12), None, uy_poly=cut_poly)
    sg = _dominant_sg_near(meshes, o, t, n, (u_lo - 1.0, u_hi + 1.0), (depth - 0.4, depth + 0.4), (y_lo, y_hi + 1.0))
    acc = reveals.setdefault(sg or "", MeshAccumulator(UV_SCALE["shell"]))
    P = lambda u, v, yy: (o[0] + t[0] * u + n[0] * v, yy, o[1] + t[1] * u + n[1] * v)
    cu = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    for i in range(len(pts)):
        (u0, y0), (u1, y1) = pts[i - 1], pts[i]
        if max(y0, y1) < y + 0.05:          # the sill: the porch floor covers it
            continue
        mu, my = (u0 + u1) / 2, (y0 + y1) / 2
        # outline points on the doorway floor run on down past it (no terrain showing at the lining's foot)
        y0d, y1d = (y0 - 0.35 if y0 < y + 0.05 else y0), (y1 - 0.35 if y1 < y + 0.05 else y1)
        quad = [P(u0, 0.0, y0d), P(u1, 0.0, y1d), P(u1, depth, y1d), P(u0, depth, y0d)]
        acc.facing(quad, (t[0] * (cu - mu), cy - my, t[1] * (cu - mu)))
    # cap at the room wall: outline minus the room's doorway
    hole = [(-w / 2, y), (w / 2, y), (w / 2, y + h), (-w / 2, y + h)]
    flat = [(p[0], max(p[1], y)) for p in pts]
    poly2 = None
    for i in range(len(flat)):           # the sill edge the doorway sits on: notch the doorway up from it
        (ua, ya), (ub, yb) = flat[i - 1], flat[i]
        if abs(ya - y) < 0.06 and abs(yb - y) < 0.06 and min(ua, ub) < -w / 2 and max(ua, ub) > w / 2:
            notch = [(-w / 2, y), (-w / 2, y + h), (w / 2, y + h), (w / 2, y)]
            if ua > ub:
                notch = notch[::-1]
            poly2 = flat[:i] + notch + flat[i:]
            break
    if poly2:
        cap = cmds.polyCreateFacet(p=[P(a, 0.01, b) for a, b in poly2], ch=False)[0]
    else:
        ring = [P(p[0], 0.01, p[1]) for p in flat]
        cap = cmds.polyCreateFacet(p=ring + [()] + [P(a, 0.01, b) for a, b in hole], ch=False)[0]
    cmds.polyTriangulate(cap, ch=False)
    nrm = [float(v) for v in cmds.polyInfo(cap + ".f[0]", faceNormals=True)[0].split()[2:5]]
    if nrm[0] * n[0] + nrm[2] * n[1] < 0:
        cmds.polyNormal(cap, normalMode=0, userNormalMode=0, ch=False)
    sel = om.MSelectionList()
    sel.add(cap)
    fnc = om.MFnMesh(sel.getDagPath(0))
    cpts = fnc.getPoints(om.MSpace.kWorld)
    counts, ids = fnc.getTriangles()
    for k in range(0, len(ids), 3):
        tri = [tuple(cpts[ids[k + j]])[:3] for j in range(3)]
        acc.poly(tri, [_uv_for(p_, (n[0], 0, n[1]), UV_SCALE["shell"]) for p_ in tri])
    cmds.delete(cap)


_LAST_CUT_AREAS = {}


def _hull2(pts):
    """Convex hull (counter-clockwise) of 2D points."""
    P = sorted(set((round(a, 4), round(b, 4)) for a, b in pts))
    if len(P) < 3:
        return P
    cross = lambda o, a, b: (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in P:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(P):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def _dominant_sg_near(meshes, o, t, n, us, vs, ys):
    """Shading group covering the most area of (non-door, non-window) stock faces whose centre lies in the box."""
    area = {}
    for m in meshes:
        for shape in cmds.listRelatives(m, shapes=True, fullPath=True, noIntermediate=True) or []:
            sel = om.MSelectionList()
            sel.add(shape)
            dag = sel.getDagPath(0)
            fn = om.MFnMesh(dag)
            sgs, face_sg = fn.getConnectedShaders(dag.instanceNumber())
            it = om.MItMeshPolygon(dag)
            while not it.isDone():
                c = it.center(om.MSpace.kWorld)
                dx, dz = c.x - o[0], c.z - o[1]
                u, v = dx * t[0] + dz * t[1], dx * n[0] + dz * n[1]
                if us[0] <= u <= us[1] and vs[0] <= v <= vs[1] and ys[0] <= c.y <= ys[1]:
                    f = it.index()
                    sgi = face_sg[f] if f < len(face_sg) else -1
                    if 0 <= sgi < len(sgs):
                        nm = om.MFnDependencyNode(sgs[sgi]).name()
                        path = cmds.getAttr(nm + ".swgShaderPath") if cmds.attributeQuery("swgShaderPath", node=nm, exists=True) else nm
                        if not any(k in (path or "").lower() for k in ("door", "window", "glass")):
                            area[nm] = area.get(nm, 0.0) + it.getArea(om.MSpace.kWorld)
                it.next()
    return max(area, key=area.get) if area else None


def _shell_cut(meshes, o, t, n, us, vs, ys, only_shader=None, uy_poly=None, planes=None):
    """Remove the box u in us (along plan tangent t), v in vs (along plan normal n), y in ys, around plan point o,
    from the meshes - or, with uy_poly, the prism of that convex (u, y) outline over v in vs. The faces crossing
    the region are split in place along its planes with polyCut (shared edges are split for both neighbours, so
    no T-junction cracks; UVs and shading groups stay), then the faces inside are deleted. Returns the shading
    group most of the removed area used. `planes` = [((ku, kv, ky), value, sign)] replaces the box / prism planes
    (convex region: inside where sign * (k . (u, v, y) - value) < 0 for every plane; us/vs/ys still bound it)."""
    E = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))
    if planes is not None:
        planes = list(planes)
    elif uy_poly:
        planes = [(E[1], vs[0], -1), (E[1], vs[1], 1)]
        hull = _hull2(uy_poly)
        us = (min(p[0] for p in hull), max(p[0] for p in hull))
        ys = (min(p[1] for p in hull), max(p[1] for p in hull))
        for i in range(len(hull)):
            (au, ay), (bu, by) = hull[i - 1], hull[i]
            nu, ny = (by - ay), -(bu - au)          # outward for a counter-clockwise hull
            planes.append(((nu, 0.0, ny), nu * au + ny * ay, 1))
    else:
        planes = [(E[1], vs[0], -1), (E[1], vs[1], 1), (E[0], us[0], -1), (E[0], us[1], 1), (E[2], ys[0], -1),
                  (E[2], ys[1], 1)]
    EPS = 1e-4

    def local(p):
        dx, dz = p[0] - o[0], p[2] - o[1]
        return (dx * t[0] + dz * t[1], dx * n[0] + dz * n[1], p[1])

    def side(q, k, val):                    # > 0: outside the region across this plane
        return (k[0] * q[0] + k[1] * q[1] + k[2] * q[2] - val)

    def world_plane(k, val, sign):
        """polyCut centre + rotation of plane k.x = val (local u, v, y); polyCut's plane normal is its local +Z."""
        kk = k[0] * k[0] + k[1] * k[1] + k[2] * k[2]
        lu, lv, ly = (k[0] * val / kk, k[1] * val / kk, k[2] * val / kk)
        c = (o[0] + t[0] * lu + n[0] * lv, ly, o[1] + t[1] * lu + n[1] * lv)
        N = (k[0] * t[0] + k[1] * n[0], k[2], k[0] * t[1] + k[1] * n[1])
        ln = math.sqrt(sum(x * x for x in N)) or 1.0
        N = [x / ln for x in N]
        return c, (math.degrees(math.asin(max(-1.0, min(1.0, -N[1])))), math.degrees(math.atan2(N[0], N[2])), 0.0)

    def overlaps(lo, hi):
        return not (hi[0] <= us[0] or lo[0] >= us[1] or hi[1] <= vs[0] or lo[1] >= vs[1] or hi[2] <= ys[0]
                    or lo[2] >= ys[1])

    def faces_of(shape, sg_ok):
        """[(face, local points, world points)] of faces whose bbox overlaps the region."""
        sel = om.MSelectionList()
        sel.add(shape)
        dag = sel.getDagPath(0)
        fn = om.MFnMesh(dag)
        pts = fn.getPoints(om.MSpace.kWorld)
        loc = [local(p) for p in pts]
        _, face_sg = fn.getConnectedShaders(dag.instanceNumber())
        out = []
        for f in range(fn.numPolygons):
            if sg_ok is not None and not sg_ok(face_sg[f] if f < len(face_sg) else -1):
                continue
            vids = fn.getPolygonVertices(f)
            L = [loc[v] for v in vids]
            lo = [min(q[k] for q in L) for k in range(3)]
            hi = [max(q[k] for q in L) for k in range(3)]
            if overlaps(lo, hi):
                out.append((f, L, [pts[v] for v in vids]))
        return fn, dag, out

    removed = {}
    for m in list(meshes):
        for shape in cmds.listRelatives(m, shapes=True, fullPath=True, noIntermediate=True) or []:
            bb = cmds.exactWorldBoundingBox(shape)
            corners = [local((x, y, z)) for x in (bb[0], bb[3]) for y in (bb[1], bb[4]) for z in (bb[2], bb[5])]
            if not overlaps([min(c[k] for c in corners) for k in range(3)], [max(c[k] for c in corners) for k in range(3)]):
                continue
            sel = om.MSelectionList()
            sel.add(shape)
            dag0 = sel.getDagPath(0)
            sgs = om.MFnMesh(dag0).getConnectedShaders(dag0.instanceNumber())[0]
            sg_names = [om.MFnDependencyNode(x).name() for x in sgs]
            sg_ok = None
            if only_shader:
                paths = [(cmds.getAttr(nm + ".swgShaderPath") if cmds.attributeQuery("swgShaderPath", node=nm, exists=True) else nm) or ""
                         for nm in sg_names]
                sg_ok = lambda i: 0 <= i < len(paths) and only_shader in paths[i].lower()
            if not faces_of(shape, sg_ok)[2]:
                continue
            for k, val, sign in planes:
                _, _, faces = faces_of(shape, sg_ok)
                cross = [f for f, L, _ in faces
                         if min(side(q, k, val) for q in L) < -EPS and max(side(q, k, val) for q in L) > EPS]
                if not cross:
                    continue
                c, rot = world_plane(k, val, sign)
                cmds.polyCut([f"{shape}.f[{f}]" for f in cross], cutPlaneCenter=c, cutPlaneRotate=rot,
                             extractFaces=False, deleteFaces=False, ch=False)
            fn, dag, faces = faces_of(shape, sg_ok)
            _, face_sg = fn.getConnectedShaders(dag.instanceNumber())
            dead = []
            for f, L, W in faces:
                cen = [sum(q[j] for q in L) / len(L) for j in range(3)]
                if all(sign * side(cen, k, val) < 0 for k, val, sign in planes):
                    dead.append(f)
                    sgi = face_sg[f] if f < len(face_sg) else -1
                    sg = sg_names[sgi] if 0 <= sgi < len(sg_names) else ""
                    a3 = [0.0, 0.0, 0.0]
                    for i in range(1, len(W) - 1):
                        e1, e2 = W[i] - W[0], W[i + 1] - W[0]
                        cr = e1 ^ e2
                        a3 = [a3[0] + cr.x, a3[1] + cr.y, a3[2] + cr.z]
                    removed[sg] = removed.get(sg, 0.0) + 0.5 * math.sqrt(sum(x * x for x in a3))
            if not dead:
                continue
            if len(dead) >= fn.numPolygons:      # Maya will not delete a mesh's last face: drop the shape
                cmds.delete(shape)
            else:
                cmds.delete([f"{shape}.f[{f}]" for f in dead])
    # the reveal is lined with the wall the opening went through, not the painted door it replaced
    def is_door(sg):
        path = cmds.getAttr(sg + ".swgShaderPath") if sg and cmds.attributeQuery("swgShaderPath", node=sg, exists=True) else sg
        return any(k in (path or "").lower() for k in ("door", "window", "glass", "emis"))
    walls = {k: v for k, v in removed.items() if not is_door(k)} or removed
    _LAST_CUT_AREAS.clear()
    _LAST_CUT_AREAS.update({k: v for k, v in removed.items() if not is_door(k)})
    return max(walls, key=walls.get) if walls else None


def cut_plan_prism(meshes, poly, y0, y1):
    """Delete what the meshes have inside the vertical prism over the convex plan polygon `poly` [(x, z)] between
    y0 and y1 (split in place along its faces, see _shell_cut): clears stock geometry where new rooms go."""
    ring = _ccw([tuple(p) for p in poly])
    planes = [((0.0, 0.0, 1.0), y0, -1), ((0.0, 0.0, 1.0), y1, 1)]
    for i in range(len(ring)):
        (ax, az), (bx, bz) = ring[i - 1], ring[i]
        nx, nz = (bz - az), -(bx - ax)          # outward for a counter-clockwise ring (interior on the left)
        planes.append(((nx, nz, 0.0), nx * ax + nz * az, 1))
    xs, zs = [p[0] for p in ring], [p[1] for p in ring]
    return _shell_cut(meshes, (0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (min(xs), max(xs)), (min(zs), max(zs)), (y0, y1),
                      planes=planes)


def _append(dst, src):
    """Copy all polygons of accumulator `src` into `dst`."""
    off = 0
    for n in src.counts:
        corners = [src.points[i] for i in src.connects[off:off + n]]
        dst.poly(corners, [(0.0, 0.0)] * n)
        off += n


def _hide_helper(xform):
    shape = cmds.listRelatives(xform, shapes=True, fullPath=True)[0]
    for attr, value in (("primaryVisibility", 0), ("castsShadows", 0), ("receiveShadows", 0),
                        ("overrideEnabled", 1), ("overrideDisplayType", 1)):
        cmds.setAttr(f"{shape}.{attr}", value)


def _collision_mesh(acc, name, collision_grp):
    """Collision mesh for the cell (exportPob writes it as the cell's CMSH extent). Faces point at the side the
    player stands on, like stock data: room walls inward, the exterior shell outward."""
    if not acc.counts:
        return None
    grp = collision_grp + "|extent"
    if not cmds.objExists(grp):
        cmds.createNode("transform", name="extent", parent=collision_grp)
    m = acc.build(name, grp)
    cmds.sets(m, edit=True, forceElement="initialShadingGroup")
    _hide_helper(m)
    return m


DOOR_CASING_W, DOOR_CASING_OVERLAP, DOOR_CASING_PROUD = 0.12, 0.06, 0.04


def _door_casing(acc, edge, u0, u1, y0, y1, yt, normal):
    """Frame round a door opening on one wall face (the line of `edge`), standing DOOR_CASING_PROUD off it toward
    `normal` (n_in: room side, n_out: outside). It runs DOOR_CASING_OVERLAP in over the cut on both jambs and the
    head, past the leaf's fit gap, so no slit shows round a closed door (a closed door closes its portal: the cell
    behind is not drawn through the gap). Boxes: front plus the four returns to the wall."""
    c, ov, p = DOOR_CASING_W, DOOR_CASING_OVERLAP, DOOR_CASING_PROUD
    n3 = (normal[0], 0.0, normal[1])
    t3 = (edge.t[0], 0.0, edge.t[1])
    P = lambda u, y, d: (edge.at(u)[0] + normal[0] * d, y, edge.at(u)[1] + normal[1] * d)
    top = min(yt, y1 + c)
    for a, b, lo, hi in ((max(0.0, u0 - c), u0 + ov, y0, top), (u1 - ov, min(edge.length, u1 + c), y0, top),
                         (u0 + ov, u1 - ov, y1 - ov, top)):
        if b - a <= EPS or hi - lo <= EPS:
            continue
        acc.facing([P(a, lo, p), P(b, lo, p), P(b, hi, p), P(a, hi, p)], n3)
        acc.facing([P(a, lo, 0), P(a, hi, 0), P(a, hi, p), P(a, lo, p)], (-t3[0], 0.0, -t3[2]))
        acc.facing([P(b, lo, 0), P(b, hi, 0), P(b, hi, p), P(b, lo, p)], t3)
        acc.facing([P(a, hi, 0), P(b, hi, 0), P(b, hi, p), P(a, hi, p)], (0, 1, 0))
        if lo > y0 + EPS:                                   # the head's underside over the opening
            acc.facing([P(a, lo, 0), P(b, lo, 0), P(b, lo, p), P(a, lo, p)], (0, -1, 0))


def _wall_trim(acc, edge, yb, yt, holes, levels, doors=()):
    """Baseboards (skipping doorways) and door casings, 2-3 cm proud of the wall on the room side. `doors`: one flag
    per hole - openings taking a door leaf get a framed casing that overlaps the cut (_door_casing)."""
    off = (edge.n_in[0] * 0.025, edge.n_in[1] * 0.025)
    W = lambda u, y, o=off: (edge.at(u)[0] + o[0], y, edge.at(u)[1] + o[1])
    want = (edge.n_in[0], 0, edge.n_in[1])
    for base in [yb] + list(levels):
        cuts = [(h[0], h[1]) for h in holes if abs(h[2] - base) < 0.05]
        for a, b in _subtract_intervals((0.0, edge.length), cuts):
            acc.facing([W(a, base), W(b, base), W(b, base + 0.18), W(a, base + 0.18)], want)
            top = W(a, base + 0.18), W(b, base + 0.18)
            acc.facing([(edge.at(a)[0], base + 0.18, edge.at(a)[1]), (edge.at(b)[0], base + 0.18, edge.at(b)[1]),
                        top[1], top[0]], (0, 1, 0))
    c = 0.12
    for k, (u0, u1, y0, y1) in enumerate(holes):
        if k < len(doors) and doors[k]:
            _door_casing(acc, edge, u0, u1, y0, y1, yt, edge.n_in)
            continue
        o = (edge.n_in[0] * 0.035, edge.n_in[1] * 0.035)
        for a, b, lo, hi in ((max(0.0, u0 - c), u0, y0, y1 + c), (u1, min(edge.length, u1 + c), y0, y1 + c),
                             (u0, u1, y1, min(yt, y1 + c))):
            if b - a > EPS and hi - lo > EPS:
                acc.facing([W(a, lo, o), W(b, lo, o), W(b, hi, o), W(a, hi, o)], want)


def _cornice(acc, edge, a, b, yt):
    """Exterior cornice band along the wall top: front, underside and top cap."""
    o = 0.08
    out = (edge.n_out[0] * o, edge.n_out[1] * o)
    P = lambda u, y, d=1.0: (edge.at(u)[0] + out[0] * d, y, edge.at(u)[1] + out[1] * d)
    lo, hi = yt - 0.35, yt + 0.06
    acc.facing([P(a, lo), P(b, lo), P(b, hi), P(a, hi)], (edge.n_out[0], 0, edge.n_out[1]))
    acc.facing([P(a, lo, 0), P(b, lo, 0), P(b, lo), P(a, lo)], (0, -1, 0))
    acc.facing([P(a, hi, 0), P(b, hi, 0), P(b, hi), P(a, hi)], (0, 1, 0))


def _dome(acc, poly, base_y, dome, inward):
    """Dome over a convex footprint: rings shrinking toward the centre on a quarter-circle profile."""
    h = float(dome.get("height", 2.0))
    k = int(dome.get("rings", 5))
    cx, cz = _interior_point(poly)
    c3 = (cx, base_y, cz)
    rings = []
    for j in range(k + 1):
        a = (j / k) * math.pi / 2
        f, y = math.cos(a), base_y + h * math.sin(a)
        rings.append([(cx + (p[0] - cx) * f, y, cz + (p[1] - cz) * f) for p in poly])
    n = len(poly)
    for j in range(k):
        for i in range(n):
            q = [rings[j][i], rings[j][(i + 1) % n], rings[j + 1][(i + 1) % n], rings[j + 1][i]]
            if j + 1 == k:
                q = q[:3]          # apex ring collapses to the centre
            mid = [sum(v[t] for v in q) / len(q) for t in range(3)]
            out = (mid[0] - c3[0], (mid[1] - c3[1]) * 0.6 + 0.1, mid[2] - c3[2])
            acc.facing(q, tuple(-x for x in out) if inward else out)


def _porch_geometry(edge, uc, w, y, porch, ground):
    """Entrance porch on r0: a landing at the door's floor height plus steps down to the ground.
    The walkable floor is landing + a ramp under the steps (how stock houses do stairs)."""
    g = float(ground if ground is not None else 0.0)
    depth = float(porch.get("depth", 2.0))
    width = max(float(porch.get("width", w + 1.0)), w)
    nsteps = int(porch.get("steps", max(1, round((y - g) / 0.2))))
    run = float(porch.get("run", 0.35)) * nsteps
    t, n = edge.t, edge.n_out
    pc = edge.at(uc)
    A = (pc[0] - t[0] * width / 2, pc[1] - t[1] * width / 2)
    B = (pc[0] + t[0] * width / 2, pc[1] + t[1] * width / 2)
    J0 = (pc[0] - t[0] * w / 2, pc[1] - t[1] * w / 2)
    J1 = (pc[0] + t[0] * w / 2, pc[1] + t[1] * w / 2)
    off = lambda p, d: (p[0] + n[0] * d, p[1] + n[1] * d)
    C, D = off(B, depth), off(A, depth)
    C2, D2 = off(B, depth + run), off(A, depth + run)
    P3 = lambda p, yy: (p[0], yy, p[1])
    landing = [P3(A, y), P3(J0, y), P3(J1, y), P3(B, y), P3(C, y), P3(D, y)]
    ramp = [P3(D, y), P3(C, y), P3(C2, g), P3(D2, g)]
    faces = []
    side_a, side_b = (-t[0], 0, -t[1]), (t[0], 0, t[1])
    faces.append(([P3(A, g - 0.3), P3(D, g - 0.3), P3(D, y), P3(A, y)], side_a))
    faces.append(([P3(B, g - 0.3), P3(C, g - 0.3), P3(C, y), P3(B, y)], side_b))
    rise = (y - g) / nsteps
    for i in range(nsteps):
        d0, d1 = depth + i * run / nsteps, depth + (i + 1) * run / nsteps
        top, prev = y - (i + 1) * rise, y - i * rise
        a0, b0, a1, b1 = off(A, d0), off(B, d0), off(A, d1), off(B, d1)
        faces.append(([P3(a0, top), P3(b0, top), P3(b0, prev), P3(a0, prev)], (n[0], 0, n[1])))   # riser
        faces.append(([P3(a0, top), P3(b0, top), P3(b1, top), P3(a1, top)], (0, 1, 0)))           # tread
        faces.append(([P3(a0, g - 0.3), P3(a1, g - 0.3), P3(a1, top), P3(a0, top)], side_a))
        faces.append(([P3(b0, g - 0.3), P3(b1, g - 0.3), P3(b1, top), P3(b0, top)], side_b))
    # the ramp is walk floor only: rendered, it lay over the steps and their nosings poked through it
    return {"floor": [(landing, []), (ramp, [])], "render": [(landing, [])], "faces": faces}


def _covered_rects(room, edge, rooms):
    """(u0, u1, y0, y1) parts of `edge` that a neighbouring room's wall covers."""
    out = []
    for other in rooms:
        if other is room:
            continue
        for j in range(len(other["poly"])):
            oe = Edge(other, j)
            ov = edge.overlap_with(oe)
            if ov:
                ou0, ou1 = sorted((oe.u_of(edge.at(ov[0])), oe.u_of(edge.at(ov[1]))))
                lo, hi = _wall_span(other, oe, ou0, ou1)
                out.append((ov[0], ov[1], lo, hi))
    return out


def _place_windows(room, rooms, holes, cfg):
    """Windows on exterior wall runs. cfg: {"width","height","sill","spacing","edge_step","edges"} and/or
    {"list": [{"edge"|"side","offset","width","height","sill"}]}. Returns (room, edge, u0, u1, y0, y1)."""
    out = []
    base_y = room["floor_y"]
    explicit = cfg.get("list", [])
    for w in explicit:
        if "edge" in w:
            ei = int(w["edge"])
        elif "at" in w:      # the wall facing `side` that passes through the plan point `at`
            want = SIDES[w.get("side", "+z")]
            at = tuple(w["at"])
            cands = [i for i in range(len(room["poly"])) if _dot2(Edge(room, i).n_out, want) > 0.99]
            if not cands:
                continue
            def off(i):
                e_ = Edge(room, i)
                u = e_.u_of(at)
                d = abs((at[0] - e_.p[0]) * e_.n_in[0] + (at[1] - e_.p[1]) * e_.n_in[1])
                return d + (0 if 0 <= u <= e_.length else 100)
            ei = min(cands, key=off)
        else:
            want = SIDES[w.get("side", "+z")]
            ei = max(range(len(room["poly"])), key=lambda i: _dot2(Edge(room, i).n_out, want))
        e = Edge(room, ei)
        ww, hh = float(w.get("width", 1.4)), float(w.get("height", 1.8))
        y0 = base_y + float(w.get("sill", 1.0))
        uc = e.u_of(tuple(w["at"])) if "at" in w else e.length / 2 + float(w.get("offset", 0.0))
        uc = min(max(uc, ww / 2 + 0.1), e.length - ww / 2 - 0.1)
        if "reveal" in w:    # shell mode: metres from the room wall out to the facade's window
            room.setdefault("window_reveal", {})[(ei, round(uc, 3))] = float(w["reveal"])
        out.append((room, ei, uc - ww / 2, uc + ww / 2, y0, y0 + hh))
    if cfg.get("auto", True) and not explicit or cfg.get("auto_too"):
        ww, hh = float(cfg.get("width", 1.4)), float(cfg.get("height", 1.8))
        sill = float(cfg.get("sill", 1.0))
        spacing = float(cfg.get("spacing", 3.5))
        step = int(cfg.get("edge_step", 1))
        only = cfg.get("edges")
        for ei in range(len(room["poly"])):
            if only is not None and ei not in only or only is None and ei % step:
                continue
            e = Edge(room, ei)
            if room["slope"] or abs(floor_y(room, e.p) - floor_y(room, e.q)) > EPS:
                continue
            y0, y1 = base_y + sill, base_y + sill + hh
            cuts = [(c[0], c[1]) for c in _covered_rects(room, e, rooms) if c[2] < y1 and c[3] > y0]
            cuts += [(h[0] - 0.4, h[1] + 0.4) for h in holes.get((room["name"], ei), [])]
            for a, b in _subtract_intervals((0.0, e.length), cuts):
                L = b - a
                if L < ww + 0.5:
                    continue
                n = max(1, int((L - 0.5) // spacing))
                for k in range(n):
                    uc = a + L * (k + 0.5) / n
                    out.append((room, ei, uc - ww / 2, uc + ww / 2, y0, y1))
    for (_, ei, u0, u1, y0, y1) in out:
        if y1 > top_y(room, Edge(room, ei).p) - 0.15:
            raise ValueError(f"room {room['name']}: window on edge {ei} reaches the ceiling")
    return out


def _window_exterior(acc, e, u0, u1, y0, y1):
    """Exterior casing around a window plus a projecting sill."""
    o = (e.n_out[0] * 0.05, e.n_out[1] * 0.05)
    out3 = (e.n_out[0], 0, e.n_out[1])
    W = lambda u, y, d=1.0: (e.at(u)[0] + o[0] * d, y, e.at(u)[1] + o[1] * d)
    c = 0.14
    for a, b, lo, hi in ((u0 - c, u0, y0, y1 + c), (u1, u1 + c, y0, y1 + c), (u0, u1, y1, y1 + c)):
        acc.facing([W(a, lo), W(b, lo), W(b, hi), W(a, hi)], out3)
    # sill: 0.12 m thick, sticking out 0.18 m
    s_out = 3.6
    acc.facing([W(u0 - c - 0.05, y0 - 0.12, s_out), W(u1 + c + 0.05, y0 - 0.12, s_out),
                W(u1 + c + 0.05, y0, s_out), W(u0 - c - 0.05, y0, s_out)], out3)
    acc.facing([W(u0 - c - 0.05, y0, 0), W(u1 + c + 0.05, y0, 0), W(u1 + c + 0.05, y0, s_out), W(u0 - c - 0.05, y0, s_out)], (0, 1, 0))
    acc.facing([W(u0 - c - 0.05, y0 - 0.12, 0), W(u1 + c + 0.05, y0 - 0.12, 0), W(u1 + c + 0.05, y0 - 0.12, s_out),
                W(u0 - c - 0.05, y0 - 0.12, s_out)], (0, -1, 0))


def _spiral_stair(room, jambs):
    """Winding stair in a round room: a helix around a central column from the bottom door's landing to the
    top door's landing. Walkable = smooth helical ramp (stock practice); render = treads + risers + soffit."""
    cfg = room["spiral"]
    rd = room["round"]
    n_seg = int(rd.get("segments", 16))
    cx, cz = rd["center"]
    R = float(rd["radius"])
    apo = R * math.cos(math.pi / n_seg)
    dphi = 2 * math.pi / n_seg
    y0, y1 = room["floor_y"], float(cfg["y_to"])
    rc = float(cfg.get("column_radius", 0.6))
    ri = rc + 0.08
    step_h = float(cfg.get("step_height", 0.2))

    def ang(pt):
        return math.atan2(pt[1] - cz, pt[0] - cx)

    def r_outer(th):
        j = math.floor((th - 0.5 * dphi) / dphi)
        centre = (j + 1) * dphi
        return apo / math.cos(th - centre)

    # door angles from the jamb data at the two levels
    def door_angles(y):
        out = []
        for ei, us in jambs.get((room["name"], round(y, 3)), {}).items():
            e = Edge(room, ei)
            out.append([ang(e.at(u)) for u in us])
        return out
    bottom, top = door_angles(y0), door_angles(y1)
    if not bottom or not top:
        raise ValueError(f"room {room['name']}: a spiral stair needs a door at the bottom ({y0}) and at the top ({y1})")
    b_j = bottom[0]
    t_j = top[0]
    th0 = math.atan2(sum(math.sin(a) for a in b_j), sum(math.cos(a) for a in b_j))
    tht = math.atan2(sum(math.sin(a) for a in t_j), sum(math.cos(a) for a in t_j))
    half = lambda js, c: max(abs(math.atan2(math.sin(a - c), math.cos(a - c))) for a in js) + 0.18
    w0, w1 = half(b_j, th0), half(t_j, tht)
    min_sweep = float(cfg.get("min_sweep", 3.5))
    th1 = tht
    while th1 - th0 < w0 + w1 + min_sweep:
        th1 += 2 * math.pi
    a_start, a_rise0, a_rise1, a_end = th0 - w0, th0 + w0, th1 - w1, th1 + w1

    def y_at(th):
        if th <= a_rise0:
            return y0
        if th >= a_rise1:
            return y1
        return y0 + (y1 - y0) * (th - a_rise0) / (a_rise1 - a_rise0)

    nsteps = max(4, round((y1 - y0) / step_h))
    step_angles = [a_rise0 + (a_rise1 - a_rise0) * k / nsteps for k in range(nsteps + 1)]
    samples = {round(a_start, 9), round(a_end, 9)}
    k = math.ceil((a_start - 0.5 * dphi) / dphi)
    while (k + 0.5) * dphi < a_end:
        samples.add(round((k + 0.5) * dphi, 9))     # polygon corners
        k += 1
    fine = (a_end - a_start) / max(1, int((a_end - a_start) / (dphi / 2)))
    t = a_start
    while t < a_end:
        samples.add(round(t, 9))
        t += fine
    for js, base in ((b_j, th0), (t_j, th1)):
        for a in js:
            samples.add(round(base + math.atan2(math.sin(a - base), math.cos(a - base)), 9))
    for a in step_angles:
        samples.add(round(a, 9))
    samples = sorted(x for x in samples if a_start - 1e-9 <= x <= a_end + 1e-9)

    O = lambda th, y: (cx + r_outer(th) * math.cos(th), y, cz + r_outer(th) * math.sin(th))
    I = lambda th, y: (cx + ri * math.cos(th), y, cz + ri * math.sin(th))
    walk, render, column = MeshAccumulator(), MeshAccumulator(), MeshAccumulator()
    up, down = (0, 1, 0), (0, -1, 0)
    for a, b in zip(samples, samples[1:]):
        walk.facing([O(a, y_at(a)), O(b, y_at(b)), I(b, y_at(b)), I(a, y_at(a))], up)
    # treads (each step's top at its upper edge height), risers, soffit, inner stringer
    def tread(lo, hi, y):
        pts = [x for x in samples if lo - 1e-9 <= x <= hi + 1e-9]
        for a, b in zip(pts, pts[1:]):
            render.facing([O(a, y), O(b, y), I(b, y), I(a, y)], up)
    for kk in range(nsteps):
        lo, hi = step_angles[kk], step_angles[kk + 1]
        y_top = y0 + (kk + 1) * (y1 - y0) / nsteps
        tread(lo, hi, y_top)
        tangent = (-math.sin(lo), 0, math.cos(lo))
        render.facing([O(lo, y_top - (y1 - y0) / nsteps), I(lo, y_top - (y1 - y0) / nsteps), I(lo, y_top), O(lo, y_top)],
                      (-tangent[0], 0, -tangent[2]))
    tread(a_rise1, a_end, y1)
    under = [x for x in samples if x >= a_rise0]
    for a, b in zip(under, under[1:]):
        ya, yb = y_at(a) - 0.25, y_at(b) - 0.25
        render.facing([O(a, ya), O(b, yb), I(b, yb), I(a, ya)], down)
        ra = (math.cos(a), 0, math.sin(a))
        render.facing([I(a, ya), I(b, yb), I(b, y_at(b) + 0.2), I(a, y_at(a) + 0.2)], (-ra[0], 0, -ra[2]))
    # central column
    nc = 24
    top_y_ = room["floor_y"] + room["height"]
    ring = [(cx + rc * math.cos(2 * math.pi * k / nc), cz + rc * math.sin(2 * math.pi * k / nc)) for k in range(nc)]
    for k in range(nc):
        p0, p1 = ring[k], ring[(k + 1) % nc]
        mid = ((p0[0] + p1[0]) / 2 - cx, 0, (p0[1] + p1[1]) / 2 - cz)
        column.facing([(p0[0], y0, p0[1]), (p1[0], y0, p1[1]), (p1[0], top_y_, p1[1]), (p0[0], top_y_, p0[1])], mid)
    return {"walk": walk, "render": render, "column": column,
            "column_ring": [(p[0], y0, p[1]) for p in ring], "sweep_deg": math.degrees(a_end - a_start), "steps": nsteps}


def _building_outline(rooms):
    """Outer boundary loops of the union of room footprints that tile without overlapping: every room edge minus
    the parts another room's wall covers, chained head to tail. Loops come out CCW (interior on the left)."""
    segs = []
    for r in rooms:
        for i in range(len(r["poly"])):
            e = Edge(r, i)
            cuts = []
            for o in rooms:
                if o is r:
                    continue
                for j in range(len(o["poly"])):
                    ov = e.overlap_with(Edge(o, j))
                    if ov:
                        cuts.append(ov)
            for a, b in _subtract_intervals((0.0, e.length), cuts):
                segs.append((e.at(a), e.at(b)))
    key = lambda p: (round(p[0], 3), round(p[1], 3))
    by_start = {}
    for sgm in segs:
        by_start.setdefault(key(sgm[0]), []).append(sgm)
    loops, used = [], set()
    for sgm in segs:
        if id(sgm) in used:
            continue
        loop, cur = [], sgm
        while cur is not None and id(cur) not in used:
            used.add(id(cur))
            loop.append(cur[0])
            nxt = [x for x in by_start.get(key(cur[1]), []) if id(x) not in used]
            cur = nxt[0] if nxt else None
        # drop collinear points
        clean = []
        for i, pt in enumerate(loop):
            a, b = loop[i - 1], loop[(i + 1) % len(loop)]
            cross = (pt[0] - a[0]) * (b[1] - pt[1]) - (pt[1] - a[1]) * (b[0] - pt[0])
            if abs(cross) > 1e-6:
                clean.append(pt)
        if len(clean) >= 3:
            loops.append(clean)
    loops.sort(key=lambda l: -abs(_area(l)))
    return loops


def _self_intersection(ring):
    """First crossing between non-adjacent edges of a closed ring (plan point), or None."""
    hit = _first_crossing(ring)
    return (round(hit[2][0], 2), round(hit[2][1], 2)) if hit else None


def _first_crossing(ring):
    """(i, j, point) for the first proper crossing of edges i and j (j > i + 1) of a closed ring, or None."""
    n = len(ring)
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    for i in range(n):
        p1, p2 = ring[i], ring[(i + 1) % n]
        for j in range(i + 2, n):
            if i == 0 and j == n - 1:
                continue
            q1, q2 = ring[j], ring[(j + 1) % n]
            d1, d2 = cross(q1, q2, p1), cross(q1, q2, p2)
            d3, d4 = cross(p1, p2, q1), cross(p1, p2, q2)
            if ((d1 > 1e-9 and d2 < -1e-9) or (d1 < -1e-9 and d2 > 1e-9)) and                ((d3 > 1e-9 and d4 < -1e-9) or (d3 < -1e-9 and d4 > 1e-9)):
                t = d1 / (d1 - d2)
                return (i, j, (p1[0] + (p2[0] - p1[0]) * t, p1[1] + (p2[1] - p1[1]) * t))
    return None


def _offset_ring(ring, d, limit=2.5):
    """Offset a CCW ring outward by d (mitred; sharp convex corners clamped at `limit` x d)."""
    out = []
    n = len(ring)
    for i in range(n):
        a, p, b = ring[i - 1], ring[i], ring[(i + 1) % n]
        def nrm(u, v):
            dx, dz = v[0] - u[0], v[1] - u[1]
            ln = math.hypot(dx, dz) or 1.0
            return (dz / ln, -dx / ln)          # outward for CCW
        n1, n2 = nrm(a, p), nrm(p, b)
        k = 1.0 + n1[0] * n2[0] + n1[1] * n2[1]
        m = ((n1[0] + n2[0]) / k, (n1[1] + n2[1]) / k) if k > 1e-6 else n1
        ml = math.hypot(*m)
        convex = (p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0]) > 0
        if ml > limit and convex:          # clamp spikes only; concave mitres are pinched by _offset_clean
            m = (m[0] / ml * limit, m[1] / ml * limit)
        out.append((p[0] + m[0] * d, p[1] + m[1] * d))
    return out


def _offset_clean(ring, d):
    """_offset_ring, then pinch out the inverted loops a mitred offset makes at concave junctions (a round
    room against a flat wall, two rooms close together). Loop vertices collapse onto the crossing point, so
    the result keeps one vertex per input vertex (offset rings built this way stay in correspondence)."""
    out = _offset_ring(ring, d)
    n = len(out)

    def line(i):                                  # offset line of source edge i: (point, direction)
        a, b = ring[i], ring[(i + 1) % n]
        L = math.dist(a, b) or 1.0
        t = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
        return (a[0] + t[1] * d, a[1] - t[0] * d), t

    def live(i):
        return math.dist(out[i], out[(i + 1) % n]) > 1e-6
    # 1) edges a sharp concave corner flipped (offset edge runs against its source edge): drop each one by
    #    meeting its neighbours' offset lines
    for _ in range(2 * n):
        flipped = None
        for i in range(n):
            if live(i):
                a, b = ring[i], ring[(i + 1) % n]
                if (out[(i + 1) % n][0] - out[i][0]) * (b[0] - a[0]) + (out[(i + 1) % n][1] - out[i][1]) * (b[1] - a[1]) < 0:
                    flipped = i
                    break
        if flipped is None:
            break
        pi = (flipped - 1) % n
        while not live(pi) and pi != flipped:
            pi = (pi - 1) % n
        qi = (flipped + 1) % n
        while not live(qi) and qi != flipped:
            qi = (qi + 1) % n
        (p0, t0), (q0, t1) = line(pi), line(qi)
        den = t0[0] * t1[1] - t0[1] * t1[0]
        if abs(den) < 1e-9:
            x = ((out[flipped][0] + out[(flipped + 1) % n][0]) / 2, (out[flipped][1] + out[(flipped + 1) % n][1]) / 2)
        else:
            u = ((q0[0] - p0[0]) * t1[1] - (q0[1] - p0[1]) * t1[0]) / den
            x = (p0[0] + t0[0] * u, p0[1] + t0[1] * u)
        k = (pi + 1) % n
        while True:                               # vertices from pi's end to qi's start
            out[k] = x
            if k == qi:
                break
            k = (k + 1) % n
    # 2) overlaps between distant parts of the ring (a pocket between two rooms): pinch the loop
    for _ in range(4 * n):
        hit = _first_crossing(out)
        if not hit:
            break
        i, j, x = hit
        inner = list(range(i + 1, j + 1))                     # vertices between the two crossing edges
        outer = [k % n for k in range(j + 1, i + n + 1)]
        def area(ids):
            return _area([x] + [out[k] for k in ids])
        # the inverted (clockwise) loop is the one to pinch; otherwise the smaller one (a gap pocket)
        pick = inner if area(inner) < 0 or (area(outer) >= 0 and len(inner) <= len(outer)) else outer
        for k in pick:
            out[k] = x
    return out


def _dedupe_ring(ring, eps=1e-4):
    out = []
    for p in ring:
        if not out or math.dist(out[-1], p) > eps:
            out.append(p)
    while len(out) > 1 and math.dist(out[0], out[-1]) <= eps:
        out.pop()
    return out


def _insert_points_parallel(rings, pts):
    """Insert plan points that lie on rings[0]'s edges; the other rings (same vertex count, offset copies)
    get the matching point at the same edge parameter."""
    rings = [list(r) for r in rings]
    for q in pts:
        ring = rings[0]
        best = None
        for i in range(len(ring)):
            a, b = ring[i], ring[(i + 1) % len(ring)]
            ab = (b[0] - a[0], b[1] - a[1])
            L2 = ab[0] ** 2 + ab[1] ** 2
            if L2 < 1e-12:
                continue
            t = ((q[0] - a[0]) * ab[0] + (q[1] - a[1]) * ab[1]) / L2
            if -1e-6 <= t <= 1 + 1e-6:
                dist = math.hypot(a[0] + ab[0] * t - q[0], a[1] + ab[1] * t - q[1])
                if dist < 1e-3 and (best is None or dist < best[0]):
                    best = (dist, i, t)
        if best is None:
            raise ValueError(f"point {q} is not on the base outline (keep doors away from corners)")
        _, i, t = best
        if 1e-6 < t < 1 - 1e-6:
            for r in rings:
                a, b = r[i], r[(i + 1) % len(r)]
                r.insert(i + 1, q if r is ring else (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
    return rings


def _insert_points(ring, pts):
    """Insert plan points lying on the ring's edges (door jambs, ramp mouths) as extra vertices."""
    ring = list(ring)
    for q in pts:
        best = None
        for i in range(len(ring)):
            a, b = ring[i], ring[(i + 1) % len(ring)]
            ab = (b[0] - a[0], b[1] - a[1])
            L2 = ab[0] ** 2 + ab[1] ** 2
            if L2 < 1e-12:
                continue
            t = ((q[0] - a[0]) * ab[0] + (q[1] - a[1]) * ab[1]) / L2
            if -1e-6 <= t <= 1 + 1e-6:
                dist = math.hypot(a[0] + ab[0] * t - q[0], a[1] + ab[1] * t - q[1])
                if dist < 1e-3 and (best is None or dist < best[0]):
                    best = (dist, i, t)
        if best is None:
            raise ValueError(f"point {q} is not on the base outline (keep doors away from corners)")
        _, i, t = best
        if t > 1e-6 and t < 1 - 1e-6:
            ring.insert(i + 1, q)
    return ring


def _terrain_base(base, entrances, cfg):
    """Base pad under the ground floor + bevelled, flared skirt into the terrain + an approach ramp per
    entrance. Walls sit on the pad (wall_span) and get a footing band; r0's floor is pad ring + ramps."""
    top, ground = base["top"], base["ground"]
    margin = float(cfg.get("margin", 1.2))
    bevel = float(cfg.get("bevel", 0.15))
    flare = float(cfg.get("flare", 0.6))
    depth = float(cfg.get("depth", 1.5))
    slope = float(cfg.get("ramp_slope", 0.3))
    loops = _building_outline(base["rooms"])
    if not loops:
        raise ValueError("no building outline for the terrain base")
    outline = loops[0]
    jambs, mouths, ramps = [], [], []
    for e in entrances:
        if abs(e["y"] - top) > 0.05:
            continue
        edge, uc, w = e["edge"], e["uc"], e["w"]
        jambs += [edge.at(uc - w / 2), edge.at(uc + w / 2)]
        rw = float(e["spec"].get("ramp_width", max(w + 1.0, 2.5)))
        pc = edge.at(uc)
        n = edge.n_out
        a = (pc[0] - edge.t[0] * rw / 2 + n[0] * margin, pc[1] - edge.t[1] * rw / 2 + n[1] * margin)
        b = (pc[0] + edge.t[0] * rw / 2 + n[0] * margin, pc[1] + edge.t[1] * rw / 2 + n[1] * margin)
        mouths += [a, b]
        ramps.append((a, b, n, edge.t))
    hole = _insert_points(outline, jambs)
    # pad edge, bevel and skirt foot: offsets of the outline with concave junctions pinched (one vertex each,
    # so the three rings stay in correspondence for the skirt quads)
    outer, bev, bottom = _insert_points_parallel(
        [_offset_clean(outline, margin), _offset_clean(outline, margin + bevel),
         _offset_clean(outline, margin + bevel + flare)], mouths)
    for ring, what in ((outer, "base edge"), (bottom, "base skirt")):
        bad = _self_intersection(_dedupe_ring(ring))
        if bad:
            raise ValueError(f"terrain base: the {what} folds over itself near {bad}; reduce base margin/flare "
                             f"or move the rooms apart")
    P = lambda pt, y: (pt[0], y, pt[1])
    floor = [([P(pt, top) for pt in _dedupe_ring(outer)], [[P(pt, top) for pt in hole]])]
    skirt, footing, ramp_faces = [], [], []

    def quad(corners):
        q = []
        for c in corners:
            if not q or math.dist(q[-1], c) > 1e-4:
                q.append(c)
        if len(q) > 1 and math.dist(q[0], q[-1]) <= 1e-4:
            q.pop()
        return q if len(q) >= 3 else None
    mouth_keys = {(round(a[0], 3), round(a[1], 3), round(b[0], 3), round(b[1], 3)) for a, b, _, _ in ramps}
    mouth_keys |= {(k[2], k[3], k[0], k[1]) for k in mouth_keys}
    for i in range(len(outer)):
        j = (i + 1) % len(outer)
        if (round(outer[i][0], 3), round(outer[i][1], 3), round(outer[j][0], 3), round(outer[j][1], 3)) in mouth_keys:
            continue                       # the ramp runs off the pad here: no skirt across its mouth
        dx, dz = bottom[j][0] - bottom[i][0], bottom[j][1] - bottom[i][1]
        if math.hypot(dx, dz) < 1e-4:
            dx, dz = outer[j][0] - outer[i][0], outer[j][1] - outer[i][1]
        ln = math.hypot(dx, dz) or 1.0
        nout = (dz / ln, -dx / ln)
        for corners, want in (([P(outer[i], top), P(outer[j], top), P(bev[j], top - bevel), P(bev[i], top - bevel)],
                               (nout[0], 1.0, nout[1])),
                              ([P(bev[i], top - bevel), P(bev[j], top - bevel), P(bottom[j], ground - depth),
                                P(bottom[i], ground - depth)], (nout[0], 0.3, nout[1]))):
            q = quad(corners)
            if q:
                skirt.append((q, want))
    # footing band where the walls meet the pad (outline, skipping doorways)
    door_spans = []
    for e in entrances:
        door_spans.append((e["edge"].at(e["uc"] - e["w"] / 2), e["edge"].at(e["uc"] + e["w"] / 2)))
    for i in range(len(outline)):
        p0, p1 = outline[i], outline[(i + 1) % len(outline)]
        L = math.dist(p0, p1)
        t = ((p1[0] - p0[0]) / L, (p1[1] - p0[1]) / L)
        nout = (t[1], -t[0])
        cuts = []
        for a, b in door_spans:
            for q0, q1 in ((a, b),):
                ua = (q0[0] - p0[0]) * t[0] + (q0[1] - p0[1]) * t[1]
                ub = (q1[0] - p0[0]) * t[0] + (q1[1] - p0[1]) * t[1]
                off = abs((q0[0] - p0[0]) * nout[0] + (q0[1] - p0[1]) * nout[1])
                if off < 1e-3:
                    cuts.append((min(ua, ub), max(ua, ub)))
        for a, b in _subtract_intervals((0.0, L), cuts):
            A = (p0[0] + t[0] * a, p0[1] + t[1] * a)
            B = (p0[0] + t[0] * b, p0[1] + t[1] * b)
            Ao, Bo = (A[0] + nout[0] * 0.07, A[1] + nout[1] * 0.07), (B[0] + nout[0] * 0.07, B[1] + nout[1] * 0.07)
            footing.append(([P(Ao, top), P(Bo, top), P(Bo, top + 0.3), P(Ao, top + 0.3)], (nout[0], 0, nout[1])))
            footing.append(([P(A, top + 0.3), P(B, top + 0.3), P(Bo, top + 0.3), P(Ao, top + 0.3)], (0, 1, 0)))
    # approach ramps: pad edge -> terrain, with curbs and side walls into the ground
    for a, b, n, t in ramps:
        run = (top - ground) / slope
        a2 = (a[0] + n[0] * run, a[1] + n[1] * run)
        b2 = (b[0] + n[0] * run, b[1] + n[1] * run)
        floor.append(([P(a, top), P(b, top), P(b2, ground), P(a2, ground)], []))
        for p_in, p_out, side in ((a, a2, (-t[0], -t[1])), (b, b2, (t[0], t[1]))):
            sd = (side[0], 0, side[1])
            ramp_faces.append(([P(p_in, top), P(p_out, ground), P(p_out, ground - depth), P(p_in, ground - depth)], sd))
            # curb: 0.18 m high, 0.22 m wide, along the ramp edge
            ci = (p_in[0] - side[0] * 0.22, p_in[1] - side[1] * 0.22)
            co = (p_out[0] - side[0] * 0.22, p_out[1] - side[1] * 0.22)
            ramp_faces.append(([P(p_in, top + 0.18), P(p_out, ground + 0.18), P(co, ground + 0.18), P(ci, top + 0.18)], (0, 1, 0)))
            ramp_faces.append(([P(ci, top), P(co, ground), P(co, ground + 0.18), P(ci, top + 0.18)], (-side[0], 0, -side[1])))
            ramp_faces.append(([P(p_in, top), P(p_out, ground), P(p_out, ground + 0.18), P(p_in, top + 0.18)], sd))
    return {"floor": floor, "skirt": skirt, "footing": footing, "ramp_faces": ramp_faces, "outline": outline}


def _glass_shader(material, spec):
    """Window glass: see-through (stock alpha glass) unless the spec opts out with window_portals: false, in which
    case the material's own (opaque) shader paints a closed window like stock interiors."""
    if not spec.get("window_portals", True):
        return material.get("shader")
    return material.get("glass_shader", GLASS_SHADER)


def _arch_head(acc, edge, u0, u1, top, facing):
    """Spandrels that turn the top of a rectangular doorway into an arch (a segmental arch when the opening is
    too low for a half circle). Added on the room's own wall face, so both rooms get one."""
    w = u1 - u0
    rise = min(w / 2.0, 0.6)
    spring = top - rise
    uc = (u0 + u1) / 2.0
    rad = (rise * rise + (w / 2.0) ** 2) / (2.0 * rise)      # circle through both springs and the crown
    cy = top - rad
    n = 8
    curve = []
    for k in range(n + 1):
        u = u0 + w * k / n
        curve.append((u, cy + math.sqrt(max(0.0, rad * rad - (u - uc) ** 2))))
    P = lambda u, y: (edge.at(u)[0], y, edge.at(u)[1])
    for k in range(n):
        (ua, ya), (ub, yb) = curve[k], curve[k + 1]
        quad = [P(ua, ya), P(ub, yb), P(ub, top), P(ua, top)]
        if min(top - ya, top - yb) > 1e-3 or max(top - ya, top - yb) > 1e-3:
            acc.facing([q for q in quad], facing)


def _door_hardpoint(xf, pos, facing):
    """Door hardpoint data (doorHardpointEnabled + doorHardpointMatrix, engine 3x4 stored verbatim) at the
    doorway's bottom centre, rotated with the door plane like stock portals."""
    ex, ez = -facing[0], facing[1]                      # engine X is mirrored
    th = math.atan2(ex, ez)
    c, sn = math.cos(th), math.sin(th)
    rows = [[c, 0.0, sn, -pos[0]], [0.0, 1.0, 0.0, pos[1]], [-sn, 0.0, c, pos[2]]]
    if not cmds.attributeQuery("doorHardpointEnabled", node=xf, exists=True):
        cmds.addAttr(xf, longName="doorHardpointEnabled", shortName="dhpEn", attributeType="bool")
    if not cmds.attributeQuery("doorHardpointMatrix", node=xf, exists=True):
        cmds.addAttr(xf, longName="doorHardpointMatrix", shortName="dhm", dataType="matrix")
    cmds.setAttr(xf + ".doorHardpointEnabled", True)
    flat = rows[0] + rows[1] + rows[2] + [0.0, 0.0, 0.0, 1.0]
    cmds.setAttr(xf + ".doorHardpointMatrix", flat, type="matrix")


def _sht_preview_texture(shader):
    """First texture a stock .sht references, resolved under TITAN_DATA_ROOT (Maya can display DDS)."""
    import re
    root = os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game")
    path = os.path.join(root, shader)
    if not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        names = re.findall(rb"texture/[A-Za-z0-9_./-]+\.dds", f.read())
    # prefer the base colour map over dirt / detail / normal overlays
    names.sort(key=lambda nm: any(k in nm for k in (b"dirt", b"detl", b"_n.", b"bump", b"spec")))
    for nm in names:
        full = os.path.join(root, nm.decode("latin1"))
        if os.path.exists(full):
            return full.replace("\\", "/")
    return None


def _hardpoints(room, levels, mesh_grp):
    """Spec hardpoints plus elevator markers (terminal placement per level) as transforms under rN|mesh;
    exportStaticMesh writes them into the cell appearance (HPTS)."""
    hps = [dict(h) for h in room["hardpoints"]]
    if room["elevator"]:
        cx, cz = _interior_point(room["poly"])
        lv = [l for l in levels if l is not None]
        for i, y in enumerate(lv):
            if i + 1 < len(lv):
                hps.append({"name": f"elevator_up_{i}", "pos": [cx, y + 1.0, cz]})
            if i > 0:
                hps.append({"name": f"elevator_down_{i}", "pos": [cx, y + 1.0, cz]})
    names = []
    for h in hps:
        t = cmds.createNode("transform", name=h["name"], parent=mesh_grp)
        cmds.setAttr(t + ".translate", *h["pos"], type="double3")
        cmds.setAttr(t + ".rotateY", float(h.get("rot_y", 0.0)))
        names.append(h["name"])
    return names


# ============================================================================
# materials, textures, lights
# ============================================================================

def _write_png(path, width, height, rows):
    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    raw = b"".join(b"\0" + r for r in rows)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(png)


def panel_texture(path, color, kind="wall", size=256, seed=1):
    """Sci-fi panel texture covering 2 m (UVs are metres / 2): walls get panels with seams and rivets,
    floors a darker deck plate with tread lines. `color` is 0..1 RGB."""
    rnd = random.Random(seed)
    base = [min(255, max(0, int(c * 255))) for c in color]
    if kind == "floor":
        base = [int(c * 0.62) for c in base]
    noise = [[rnd.uniform(-7, 7) for _ in range(size)] for _ in range(size)]
    panel = size // 2
    rows = []
    for y in range(size):
        row = bytearray()
        for x in range(size):
            px, py = x % panel, y % panel
            shade = noise[y][x]
            if px < 2 or py < 2:
                shade -= 46
            elif px < 4 or py < 4:
                shade += 18
            if kind == "wall" and 10 <= px <= 13 and (10 <= py <= 13 or panel - 14 <= py <= panel - 11):
                shade -= 30
            if kind == "floor" and (px + py) % 16 < 2:
                shade -= 16
            row += bytes(min(255, max(0, int(c + shade))) for c in base)
        rows.append(bytes(row))
    _write_png(path, size, size, rows)
    return path


def _material(name, color, texture=None, shader=None):
    """Lambert (+ file texture) and its shading group. `shader` = SWG .sht tree path used as the export
    prototype (swgShaderPath on the shading group) instead of the default shader."""
    if shader and not texture:
        texture = _sht_preview_texture(shader)
    shader_node = cmds.ls(name, type="lambert")
    if not shader_node:
        shader_node = [cmds.shadingNode("lambert", asShader=True, name=name)]
        sg = cmds.sets(renderable=True, noSurfaceShader=True, empty=True, name=name + "SG")
        cmds.connectAttr(shader_node[0] + ".outColor", sg + ".surfaceShader", force=True)
    cmds.setAttr(shader_node[0] + ".color", *color, type="double3")
    if texture:
        fnode = cmds.shadingNode("file", asTexture=True, isColorManaged=True, name=name + "_tex")
        p2d = cmds.shadingNode("place2dTexture", asUtility=True, name=name + "_p2d")
        for a in ("coverage", "translateFrame", "rotateFrame", "mirrorU", "mirrorV", "stagger", "wrapU", "wrapV",
                  "repeatUV", "offset", "rotateUV", "noiseUV", "vertexUvOne", "vertexUvTwo", "vertexUvThree",
                  "vertexCameraOne"):
            cmds.connectAttr(f"{p2d}.{a}", f"{fnode}.{a}", force=True)
        cmds.connectAttr(p2d + ".outUV", fnode + ".uv", force=True)
        cmds.connectAttr(p2d + ".outUvFilterSize", fnode + ".uvFilterSize", force=True)
        cmds.setAttr(fnode + ".fileTextureName", texture.replace("\\", "/"), type="string")
        cmds.connectAttr(fnode + ".outColor", shader_node[0] + ".color", force=True)
    sg = cmds.listConnections(shader_node[0] + ".outColor", type="shadingEngine")[0]
    if shader:
        if not cmds.attributeQuery("swgShaderPath", node=sg, exists=True):
            cmds.addAttr(sg, longName="swgShaderPath", dataType="string")
        cmds.setAttr(sg + ".swgShaderPath", shader, type="string")
    return sg


LINEAR_GAIN = 2.5     # point light intensity for 1/d falloff, matched to the old 1/(1 + 0.02 d^2) at ~2.5 m


def _light_args(rgb, intensity):
    """SWG cell lights are HDR (components > 1); Maya light colours are 0..1. exportPob writes colour x
    intensity, so move the excess into the intensity and the exported value is unchanged."""
    rgb = [float(c) for c in rgb]
    m = max(rgb + [1.0])
    return {"rgb": tuple(c / m for c in rgb), "intensity": float(intensity) * m}


def _light_spots(poly, area):
    """1-3 point-light positions spread along the room's long axis (stock cells use 1-3 point lights)."""
    k = 1 if area < 40.0 else (2 if area < 120.0 else 3)
    xs, zs = [p[0] for p in poly], [p[1] for p in poly]
    cx, cz = _interior_point(poly)
    if k == 1:
        return [(cx, cz)]
    along_x = (max(xs) - min(xs)) >= (max(zs) - min(zs))
    lo, hi = (min(xs), max(xs)) if along_x else (min(zs), max(zs))
    spots = []
    for i in range(k):
        t = lo + (hi - lo) * (i + 0.5) / k
        q = (t, cz) if along_x else (cx, t)
        spots.append(q if _inside(q, poly) else (cx, cz))
    return spots


def _add_lights(cell, room, levels, window_edges=(), mat_prefix="swg_room"):
    """Stock-style cell lighting: one ambient, 1-3 point lights spread over the room under the ceiling (each with
    a visible emissive fixture), and two parallel lights - the key one aimed in through the windows when the
    room has any (daylight), otherwise down from above."""
    grp = cmds.createNode("transform", name="lights", parent=cell)
    cfg = room.get("light") or {}
    amb = cmds.ambientLight(**_light_args(cfg.get("ambient_rgb", (0.9, 0.9, 1.0)), cfg.get("ambient", 0.35)))
    cmds.parent(cmds.listRelatives(amb, parent=True, fullPath=True)[0], grp)
    poly = room["poly"]
    area = abs(_area(poly))
    spots = _light_spots(poly, area)
    fixtures = MeshAccumulator(fit=True)
    flat_ceiling = not room["slope"] and not room["dome"]
    # few, short-range point lights like stock cells: the client lights each object with only its strongest few,
    # so many long-reaching lights swap in and out as you move (the "flickering lights")
    spots = spots[:2] if len(levels) == 1 else spots[:1]
    for i, lvl in enumerate(levels):
        for (sx, sz) in spots:
            if room["slope"]:
                y = top_y(room, (sx, sz)) - 0.5
            else:
                ceiling = (levels[i + 1] - SLAB) if i + 1 < len(levels) else room["floor_y"] + room["height"]
                y = ceiling - 0.45
                if flat_ceiling and cfg.get("fixtures", True):
                    c = ceiling - 0.06       # 2 cm z-fought with the ceiling at range (lights "flicker")
                    hs = 0.35
                    fixtures.facing([(sx - hs, c, sz - hs), (sx + hs, c, sz - hs), (sx + hs, c, sz + hs), (sx - hs, c, sz + hs)],
                                    (0, -1, 0))
            scale = 1.0 if len(spots) == 1 else 0.8
            # stock falloff is linear, 1/d (attenuation 0, 1, 0) with HDR intensity ~2-3: x LINEAR_GAIN keeps the
            # old brightness at a room's typical 2.5 m light distance
            pt = cmds.pointLight(**_light_args(cfg.get("rgb", (1.0, 0.95, 0.85)),
                                               cfg.get("intensity", 1.0) * scale * LINEAR_GAIN))
            xf = cmds.parent(cmds.listRelatives(pt, parent=True, fullPath=True)[0], grp)[0]
            cmds.setAttr(xf + ".translate", sx, y, sz, type="double3")
            shape = cmds.listRelatives(xf, shapes=True, fullPath=True)[0]
            for attr, value in (("constantAttenuation", 0.0), ("linearAttenuation", 1.0), ("quadraticAttenuation", 0.0)):
                if not cmds.attributeQuery(attr, node=shape, exists=True):
                    cmds.addAttr(shape, longName=attr, attributeType="float")
                cmds.setAttr(f"{shape}.{attr}", value)
    if fixtures.counts:
        fm = (room["materials"] or {}).get("fixture", {})
        fsg = _material(f"{mat_prefix}_fixture", tuple(fm.get("color", (1.0, 0.96, 0.85))), fm.get("texture"),
                        fm.get("shader", FIXTURE_SHADER))
        cmds.sets(fixtures.build(f"{room['name']}_light_fixtures", cell + "|mesh"), edit=True, forceElement=fsg)

    parallels = [dict(p) for p in cfg.get("parallel", [{"rgb": (0.5, 0.45, 0.42), "dir": (0.2, -1.0, -0.3)},
                                                         {"rgb": (0.22, 0.22, 0.26), "dir": (0.0, 1.0, 0.1)}])]
    if window_edges and cfg.get("daylight", True):
        # key light comes in through the windows: average inward normal, angled down like sun through glass
        dx = sum(e.n_in[0] for e in window_edges)
        dz = sum(e.n_in[1] for e in window_edges)
        ln = math.hypot(dx, dz) or 1.0
        day = {"rgb": cfg.get("daylight_rgb", (0.62, 0.56, 0.46)), "dir": (dx / ln, -0.65, dz / ln)}
        parallels = [day] + parallels[1:]
    base = room["floor_y"] + room["height"]
    cx, cz = _interior_point(poly)
    for par in parallels:
        dl = cmds.directionalLight(**_light_args(par.get("rgb", (0.5, 0.45, 0.4)), par.get("intensity", 1.0)))
        xf = cmds.parent(cmds.listRelatives(dl, parent=True, fullPath=True)[0], grp)[0]
        dx, dy, dz = par.get("dir", (0.0, -1.0, 0.0))
        ln = math.sqrt(dx * dx + dy * dy + dz * dz) or 1.0
        dx, dy, dz = dx / ln, dy / ln, dz / ln
        # Maya lights shine down their local -Z
        cmds.setAttr(xf + ".rotate", math.degrees(math.asin(max(-1.0, min(1.0, dy)))),
                     math.degrees(math.atan2(-dx, -dz)), 0.0, type="double3")
        cmds.setAttr(xf + ".translate", cx, base + 1.0, cz, type="double3")


# Shaders that must not be darkened by the bake: emissive fixtures, light strips, glass (stock bakes them white).
_BAKE_WHITE = ("light", "emis", "glass", "window", "glow", "lamp")


def _bake_white(shader):
    stem = shader.lower().split("/")[-1].replace(".sht", "")
    return any(k in stem for k in _BAKE_WHITE)


def _cell_lights(cell):
    """(ambient rgb, [(pos, rgb, constant, quadratic)], [(dir_to_light, rgb)]) of a cell's light group, world space,
    HDR colour = Maya colour x intensity exactly as exportPob writes it."""
    amb, points, dirs = [0.0, 0.0, 0.0], [], []
    for shape in cmds.listRelatives(cell + "|lights", allDescendents=True, fullPath=True, type="light") or []:
        col = [c * cmds.getAttr(shape + ".intensity") for c in cmds.getAttr(shape + ".color")[0]]
        xf = cmds.listRelatives(shape, parent=True, fullPath=True)[0]
        kind = cmds.nodeType(shape)
        if kind == "ambientLight":
            amb = [a + c for a, c in zip(amb, col)]
        elif kind == "pointLight":
            att = lambda a, d: cmds.getAttr(f"{shape}.{a}") if cmds.attributeQuery(a, node=shape, exists=True) else d
            points.append((cmds.xform(xf, q=True, ws=True, t=True), col, att("constantAttenuation", 0.0),
                           att("linearAttenuation", 1.0), att("quadraticAttenuation", 0.0)))
        elif kind == "directionalLight":
            m = cmds.xform(xf, q=True, ws=True, m=True)
            dirs.append(((m[8], m[9], m[10]), col))      # light shines down local -Z: +Z points at the light
    return amb, points, dirs


def close_undersides(root, cover=0.8, clearance=0.8, ground=None, grid=1.0):
    """Bottom faces for surfaces modelled from above only (stair flights, decks, landings, ramps, rims, porches,
    overhangs): every up-facing render polygon of every cell (r0 included) with open space under it - nothing
    facing down within `cover` m below it, and either open air or a floor more than `clearance` m down - gets a
    flipped copy in the same material, so a player or camera looking up does not see through it. Polygons at or
    below `ground` (resting on the terrain) are left alone. Opposite coplanar faces do not fight: the client
    back-face culls. Returns the number of polygons added per cell."""
    import maya.api.OpenMaya as om2
    shapes_by_cell = {}
    soup = {}                                  # grid cell -> [(a, b, c, normal y)] of every render triangle
    for cell in cmds.listRelatives(root, children=True, fullPath=True) or []:
        if not cmds.objExists(cell + "|mesh"):
            continue
        shapes = [s for s in cmds.listRelatives(cell + "|mesh", allDescendents=True, type="mesh", fullPath=True) or []
                  if not cmds.getAttr(s + ".intermediateObject")]
        shapes_by_cell[cell] = shapes
        for s in shapes:
            sel = om2.MSelectionList()
            sel.add(s)
            fn = om2.MFnMesh(sel.getDagPath(0))
            pts = fn.getPoints(om2.MSpace.kWorld)
            _, ids = fn.getTriangles()
            for t in range(0, len(ids), 3):
                a, b, c = pts[ids[t]], pts[ids[t + 1]], pts[ids[t + 2]]
                ux, uy, uz = b.x - a.x, b.y - a.y, b.z - a.z
                vx, vy, vz = c.x - a.x, c.y - a.y, c.z - a.z
                nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
                ln = math.sqrt(nx * nx + ny * ny + nz * nz)
                if ln < 1e-9:
                    continue
                tri = ((a.x, a.y, a.z), (b.x, b.y, b.z), (c.x, c.y, c.z), ny / ln)
                xs, zs = (a.x, b.x, c.x), (a.z, b.z, c.z)
                for gx in range(int(math.floor(min(xs) / grid)), int(math.floor(max(xs) / grid)) + 1):
                    for gz in range(int(math.floor(min(zs) / grid)), int(math.floor(max(zs) / grid)) + 1):
                        soup.setdefault((gx, gz), []).append(tri)

    def hits_below(x, y, z):
        """(y, normal y) of every triangle under/at the vertical through (x, z) below height y."""
        out = []
        for a, b, c, ny in soup.get((int(math.floor(x / grid)), int(math.floor(z / grid))), ()):
            d = (b[2] - c[2]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[2] - c[2])
            if abs(d) < 1e-12:
                continue
            l1 = ((b[2] - c[2]) * (x - c[0]) + (c[0] - b[0]) * (z - c[2])) / d
            l2 = ((c[2] - a[2]) * (x - c[0]) + (a[0] - c[0]) * (z - c[2])) / d
            l3 = 1.0 - l1 - l2
            if min(l1, l2, l3) < -1e-6:
                continue
            hy = l1 * a[1] + l2 * b[1] + l3 * c[1]
            if hy < y - 1e-3:
                out.append((hy, ny))
        return out

    added = {}
    for cell, shapes in shapes_by_cell.items():
        n_cell = 0
        for s in shapes:
            sel = om2.MSelectionList()
            sel.add(s)
            fn = om2.MFnMesh(sel.getDagPath(0))
            pts = fn.getPoints(om2.MSpace.kWorld)
            try:
                sg_objs, face_sg = fn.getConnectedShaders(0)
                sg_names = [om2.MFnDependencyNode(o).name() for o in sg_objs]
            except RuntimeError:
                sg_names, face_sg = [], []
            accs = {}                                 # shading group -> accumulator of flipped polygons
            for f in range(fn.numPolygons):
                nrm = fn.getPolygonNormal(f, om2.MSpace.kWorld)
                if nrm.y < 0.7:
                    continue
                vids = fn.getPolygonVertices(f)
                corners = [(pts[v].x, pts[v].y, pts[v].z) for v in vids]
                cx = sum(p[0] for p in corners) / len(corners)
                cy = sum(p[1] for p in corners) / len(corners)
                cz = sum(p[2] for p in corners) / len(corners)
                if ground is not None and cy <= ground + 0.05:
                    continue
                below = sorted(hits_below(cx, cy, cz), key=lambda h: -h[0])
                if any(ny < -0.5 and cy - hy <= cover for hy, ny in below):
                    continue                      # a ceiling / soffit already closes it
                if below and cy - below[0][0] <= clearance:
                    continue                      # resting on something just below (a step on a step, a mat on a floor)
                if not below and ground is not None and cy < ground + 2.0:
                    continue                      # a ground floor with nothing under it: it lies on the terrain
                try:
                    uvs = [fn.getPolygonUV(f, k) for k in range(len(vids))]
                except RuntimeError:
                    uvs = [(p[0] / 2.0, p[2] / 2.0) for p in corners]
                k = face_sg[f] if f < len(face_sg) else -1
                sg = sg_names[k] if 0 <= k < len(sg_names) else \
                    (cmds.listConnections(s, type="shadingEngine") or ["initialShadingGroup"])[0]
                accs.setdefault(sg, MeshAccumulator()).poly(corners[::-1], [tuple(uv) for uv in uvs[::-1]])
                n_cell += 1
            xf = cmds.listRelatives(s, parent=True, fullPath=True)[0]
            for i, (sg, acc) in enumerate(accs.items()):
                if acc.counts:
                    m = acc.build(f"{xf.split('|')[-1].split(':')[-1]}_underside{i}", cell + "|mesh")
                    cmds.sets(m, edit=True, forceElement=sg)
        if n_cell:
            added[cell.split("|")[-1]] = n_cell
    return added


def line_doorways(root, reach=1.2, inset=0.03, min_gap=0.04):
    """Jambs and lintels for doorways with a gap: for every portal, on each side, find how far the cell's wall face
    stands back from the portal plane beside the opening (horizontal rays along the portal normal from just outside
    each jamb and above the lintel); where it stands back more than `min_gap` and nothing already lines the opening
    there, add the reveal - left jamb, right jamb, soffit - from the portal plane to that wall, in the cell's wall
    material nearest the door. Stops the see-through slots around doors whose walls meet at different depths
    (stock walls next to new rooms, thick walls, re-pointed exits). Returns [(cell, portal index, depth)]."""
    import maya.api.OpenMaya as om2

    def shapes_of(cell):
        return [s for s in cmds.listRelatives(cell + "|mesh", allDescendents=True, type="mesh", fullPath=True) or []
                if not cmds.getAttr(s + ".intermediateObject")]

    cache = {}

    def fns_of(cell):
        if cell not in cache:
            out = []
            for s in shapes_of(cell):
                sel = om2.MSelectionList()
                sel.add(s)
                out.append((s, om2.MFnMesh(sel.getDagPath(0))))
            cache[cell] = out
        return cache[cell]

    def cast(fns, p, d, far):
        best = None
        for s, fn in fns:
            r = fn.closestIntersection(om2.MFloatPoint(*p), om2.MFloatVector(*d), om2.MSpace.kWorld, far, False)
            if r and r[2] >= 0 and (best is None or r[1] < best[0]):     # (point, ray param, face, triangle, ...)
                best = (r[1], s, r[2])
        return best

    done = []
    for cell in cmds.listRelatives(root, children=True, fullPath=True) or []:
        if not cmds.objExists(cell + "|portals") or not cmds.objExists(cell + "|mesh"):
            continue
        fns = fns_of(cell)
        if not fns:
            continue
        accs = {}
        for portal in cmds.listRelatives(cell + "|portals", children=True, fullPath=True) or []:
            shp = cmds.listRelatives(portal, shapes=True, fullPath=True)
            if not shp:
                continue
            v = cmds.xform(shp[0] + ".vtx[*]", q=True, ws=True, t=True)
            pts = [(v[i], v[i + 1], v[i + 2]) for i in range(0, len(v), 3)]
            plan = []
            for x, _, z in pts:
                if not any(abs(x - q[0]) < 1e-3 and abs(z - q[1]) < 1e-3 for q in plan):
                    plan.append((x, z))
            if len(plan) < 2:
                continue                                       # a horizontal portal (shaft, hatch): no jambs
            (ax, az), (bx, bz) = plan[0], plan[1]
            L = math.hypot(bx - ax, bz - az)
            if L < 0.3:
                continue
            t = ((bx - ax) / L, (bz - az) / L)
            n = (-t[1], t[0])
            y0, y1 = min(p[1] for p in pts), max(p[1] for p in pts)
            ym = (y0 + y1) / 2
            other = cmds.getAttr(portal + ".portalTargetCell") if cmds.attributeQuery("portalTargetCell", node=portal, exists=True) else None
            other_cell = f"{root}|r{other}" if other is not None else None
            both = fns + (fns_of(other_cell) if other_cell and cmds.objExists(other_cell + "|mesh") else [])
            # which side of the portal plane is this cell? a room: toward its own mesh centre; r0 (the whole
            # building): away from the room on the other side
            if cell.split("|")[-1] == "r0" and other_cell and cmds.objExists(other_cell + "|mesh"):
                bb = cmds.exactWorldBoundingBox(other_cell + "|mesh")
                sign = -1
            else:
                bb = cmds.exactWorldBoundingBox(cell + "|mesh")
                sign = 1
            mc = ((bb[0] + bb[3]) / 2, (bb[2] + bb[5]) / 2)
            if sign * ((mc[0] - ax) * n[0] + (mc[1] - az) * n[1]) < 0:
                n = (-n[0], -n[1])
            # the symptom itself: aim from inside the cell at points just beside the jambs / over the lintel (in the
            # portal plane); a ray that crosses the plane without meeting any wall of either cell is a see-through slot
            look = 0.8
            beside = [((ax - t[0] * inset * 2, ym, az - t[1] * inset * 2), "a"), ((bx + t[0] * inset * 2, ym, bz + t[1] * inset * 2), "b"),
                      (((ax + bx) / 2, y1 + inset * 2, (az + bz) / 2), "top")]
            up = cast(fns, ((ax + bx) / 2 + n[0] * 0.3, y1 - 0.05, (az + bz) / 2 + n[1] * 0.3), (0.0, 1.0, 0.0), 0.2)
            if up is not None:
                beside = beside[:2]                            # the ceiling is at the door head: nothing above it
            gaps = []
            for q, tag in beside:
                start = (q[0] + n[0] * look, q[1], q[2] + n[1] * look)
                if cast(both, start, (-n[0], 0.0, -n[1]), look * 2) is None:
                    gaps.append(tag)
            if not gaps:
                continue
            # reveal depth: where this cell's wall beside the door stands (ray from deep inside, just outside the jamb)
            hits = {}
            for q, tag in beside:
                start = (q[0] + n[0] * reach, q[1], q[2] + n[1] * reach)
                h = cast(fns, start, (-n[0], 0.0, -n[1]), reach)
                if h:
                    hits[tag] = (reach - h[0], h[1])
            d = max([0.3] + [v[0] for v in hits.values() if v[0] < reach - 0.05])
            hits = {k: (v[0], v[1]) for k, v in hits.items()} or {"none": (0.0, fns[0][0])}
            src = next(iter(hits.values()))[1]
            sg = (cmds.listConnections(src, type="shadingEngine") or ["initialShadingGroup"])[0]
            acc = accs.setdefault(sg, MeshAccumulator(UV_SCALE["wall"]))
            P = lambda e, y, k: (e[0] + n[0] * k, y, e[1] + n[1] * k)
            A, B = (ax, az), (bx, bz)
            acc.facing([P(A, y0, 0), P(A, y0, d), P(A, y1, d), P(A, y1, 0)], (t[0], 0, t[1]))          # left jamb
            acc.facing([P(B, y0, 0), P(B, y0, d), P(B, y1, d), P(B, y1, 0)], (-t[0], 0, -t[1]))        # right jamb
            acc.facing([P(A, y1, 0), P(B, y1, 0), P(B, y1, d), P(A, y1, d)], (0, -1, 0))               # soffit
            done.append((cell.split("|")[-1], cmds.getAttr(portal + ".buildingPortalIndex")
                         if cmds.attributeQuery("buildingPortalIndex", node=portal, exists=True) else -1, round(d, 2)))
        for i, (sg, acc) in enumerate(accs.items()):
            if acc.counts:
                m = acc.build(f"door_reveals{i}", cell + "|mesh")
                cmds.sets(m, edit=True, forceElement=sg)
    return done


def bake_vertex_lighting(root, exposure=0.55, floor=0.1):
    """Prelit (c_) interior shaders ignore the cell's diffuse lights and multiply by the mesh's vertex colour, so
    every cell mesh gets its cell lights baked into a colour set (exported as color0): ambient + lambert point
    lights with the exported attenuation 1/(c + q d^2) + parallels. Emissive / glass shaders stay white."""
    baked = 0
    for cell in sorted(cmds.listRelatives(root, children=True, fullPath=True) or []):
        short = cell.split("|")[-1]
        if not (short.startswith("r") and short[1:].isdigit()) or short == "r0" or not cmds.objExists(cell + "|lights"):
            continue
        amb, points, dirs = _cell_lights(cell)
        for shape in cmds.listRelatives(cell + "|mesh", allDescendents=True, fullPath=True, type="mesh") or []:
            if cmds.getAttr(shape + ".intermediateObject"):
                continue
            sel = om.MSelectionList()
            sel.add(shape)
            dag = sel.getDagPath(0)
            fn = om.MFnMesh(dag)
            if any(c != "swgBake" for c in (fn.getColorSetNames() or [])):
                continue        # imported stock geometry keeps its own prelighting (swgPrelit)
            shaders, face_sg = fn.getConnectedShaders(dag.instanceNumber())
            white_sg = set()
            for i, sg in enumerate(shaders):
                path = ""
                sgn = om.MFnDependencyNode(sg).name()
                if cmds.attributeQuery("swgShaderPath", node=sgn, exists=True):
                    path = cmds.getAttr(sgn + ".swgShaderPath") or ""
                if _bake_white(path or sgn):
                    white_sg.add(i)
            pts = fn.getPoints(om.MSpace.kWorld)
            colors, faces, verts = om.MColorArray(), om.MIntArray(), om.MIntArray()
            for f in range(fn.numPolygons):
                vids = fn.getPolygonVertices(f)
                if face_sg[f] in white_sg:
                    for v in vids:
                        colors.append(om.MColor((1.0, 1.0, 1.0, 1.0)))
                        faces.append(f)
                        verts.append(v)
                    continue
                n = fn.getPolygonNormal(f, om.MSpace.kWorld)
                for v in vids:
                    p = pts[v]
                    c = list(amb)
                    for (lp, lc, kc, kl, kq) in points:
                        dx, dy, dz = lp[0] - p.x, lp[1] - p.y, lp[2] - p.z
                        d2 = dx * dx + dy * dy + dz * dz
                        d = math.sqrt(d2) or 1.0
                        lam = (n.x * dx + n.y * dy + n.z * dz) / d
                        lam = max(0.0, (lam + 0.25) / 1.25)     # slight wrap: corners and soffits are not pitch black
                        k = lam / max(0.5, kc + kl * max(d, 0.5) + kq * d2)
                        c = [a + k * b for a, b in zip(c, lc)]
                    for (ld, lc) in dirs:
                        lam = max(0.0, n.x * ld[0] + n.y * ld[1] + n.z * ld[2])
                        c = [a + lam * b for a, b in zip(c, lc)]
                    colors.append(om.MColor(tuple(min(1.0, max(floor, x * exposure)) for x in c) + (1.0,)))
                    faces.append(f)
                    verts.append(v)
            if "swgBake" not in (fn.getColorSetNames() or []):
                fn.createColorSet("swgBake", False)
            fn.setCurrentColorSetName("swgBake")
            fn.setFaceVertexColors(colors, faces, verts)
            baked += 1
    return baked


def _fold_collision_groups(root):
    """The exporters read only rN|collision|floor0 and rN|collision|extent. Groups Maya renamed on a reparent
    (extent1, floor01, ...) would be dropped silently - walls lost from the CMSH and from the walk floor's wall
    feet - so fold their contents back into the real group."""
    import re
    folded = 0
    for cell in cmds.listRelatives(root, children=True, fullPath=True) or []:
        grp = cell + "|collision"
        if not cmds.objExists(grp):
            continue
        for ch in cmds.listRelatives(grp, children=True, fullPath=True) or []:
            m = re.fullmatch(r"(extent|floor0)\d+", ch.split("|")[-1])
            if not m:
                continue
            target = f"{grp}|{m.group(1)}"
            if not cmds.objExists(target):
                cmds.rename(ch, m.group(1))
            else:
                for g in cmds.listRelatives(ch, children=True, fullPath=True) or []:
                    cmds.parent(g, target)
                cmds.delete(ch)
            folded += 1
    return folded


def export(root, export_root, base_name=""):
    """swg_pob_exportStructure wrapper: per-cell .apt/.msh, per-cell .flr and the .pob."""
    export_root = export_root.replace("\\", "/").rstrip("/")
    _fold_collision_groups(root)
    bake_vertex_lighting(root)
    base = base_name or root.split("|")[-1]
    written = mel.eval(f'swg_pob_exportStructure("{root}", "{export_root}", "{base}")')
    cells = []
    for cell in sorted(cmds.listRelatives(root, children=True, fullPath=True) or []):
        short = cell.split("|")[-1]
        if not (short.startswith("r") and short[1:].isdigit()):
            continue
        mesh_ref = cmds.getAttr(cell + "|mesh.external_reference") if cmds.objExists(cell + "|mesh") else ""
        floor_node = cell + "|collision|floor0"
        floor_ref = cmds.getAttr(floor_node + ".external_reference") if cmds.objExists(floor_node) else ""
        cells.append({"cell": short, "appearance": mesh_ref, "floor": floor_ref})
    return {"pob": written, "export_root": export_root, "cells": cells}
