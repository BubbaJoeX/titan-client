"""Modular worldbuilding kit for object/static/structure/<theme> — runs inside Maya with SwgMayaEditor loaded.

Extends the stock "improvement" kits (corl_imprv_wall_4x16_s01, nboo_imprv_pillar_..., <planet>_imprv_flagpole_s01)
with pieces that snap together on every adventurer planet, in each planet's own stock materials:

  wall_4x8, wall_4x16    straight walls, 4 m tall (sunk 1 m into the terrain like the stock walls), 1 m thick,
                         ends at x = +-length/2 so they butt end to end
  column                 a joint post, 1.2 m square, for wall ends and corners
  gate_sm                8 m wide, posts + lintel over a 4 m x 4.5 m passage (stock gate_sm footprint)
  arch_sm                8 m wide, posts + a round arch over the passage (timber planets: a crossbeam)
  wall_curve             90 degree wall, 8 m centreline radius around (0, 0): from (8, 0) to (0, 8)
  wall_low_1x8           1.1 m low wall / planter edge

Geometry families follow the stock architecture of each planet: "panel" (Corellia, Talus, Lok: plinth, body,
accent band, metal cap; Lok ribbed with vents), "stone" (Naboo, Rori, Yavin: pilasters, cornice, carved band),
"adobe" (Tatooine: rounded caps), "timber" (Dantooine posts and rails, Dathomir pointed log palisade, Endor
lashed posts). All coordinates are Maya space (x right, y up, z), the piece centred on its origin."""

from __future__ import annotations

import math
import os

import maya.cmds as cmds
import maya.mel as mel

from . import pob_builder as pb

SP = lambda n: "shader/" + n + ".sht"

# theme -> folder, prefix, family, material slots (all exterior "a_" shaders: lit by the sun, no baking)
THEMES = {
    "corellia": {"dir": "corellia", "prefix": "corl", "family": "panel", "mat": {
        "base": "all_concrete_b_a_adb13", "body": "corellia_marble_deta_adb13", "cap": "corellia_sky_trim_metal_a_ads16",
        "accent": "corl_wall_lightstrip_ae9", "post": "corellia_marble_deta_adb13"}},
    "talus": {"dir": "talus", "prefix": "talus", "family": "panel", "mat": {
        "base": "all_concrete_a_fallback_a2d13", "body": "all_concrete_b_a_adb13", "cap": "corellia_roof_metal_a_ads16",
        "accent": "corellia_verticala_trim_ads16", "post": "all_concrete_a_fallback_a2d13"}},
    "lok": {"dir": "lok", "prefix": "lok", "family": "panel", "ribbed": True, "mat": {
        "base": "thm_nym_metalwall_a2_adb13", "body": "thm_nym_metalwall_a3_adb13", "cap": "thm_nym_metaltrim_asb14",
        "accent": "thm_nym_vent_asb14", "post": "thm_nym_metaltrim_asb14", "light": "thm_nym_lights_ae9"}},
    "naboo": {"dir": "naboo", "prefix": "nboo", "family": "stone", "mat": {
        "base": "thed_concreteb_asb13", "body": "thed_stone_deco_asb13", "cap": "thed_patinaroof_trim_asb13",
        "accent": "thed_column_2tone_asb13", "post": "thed_column_2tone_asb13", "grille": "thed_metl_wrought_iron_as9"}},
    "rori": {"dir": "rori", "prefix": "rori", "family": "stone", "mat": {
        "base": "thed_concreteb_asb13", "body": "thed_brick_medb_asb13", "cap": "thed_patinaroof_trim_asb13",
        "accent": "thed_carvingb_asb13", "post": "thed_underhanga_trim_asb13"}},
    "yavin": {"dir": "yavin", "prefix": "yavn", "family": "stone", "vines": True, "mat": {
        "base": "temple_floor_a_as8", "body": "temple_stone_b_as8", "cap": "temple_stone_c_as8",
        "accent": "temple_carvingsa_as8", "post": "temple_stone_c_as8", "vines": "temple_vines_aa7"}},
    "tatooine": {"dir": "tatooine", "prefix": "tato", "family": "adobe", "mat": {
        "base": "stco_filler_a_base_adb13", "body": "stco_tato_dtlbase_a1_adb13", "cap": "stco_tato_dtlbase_a1_adb13",
        "accent": "thm_tatt_mtl_rustb_as8", "post": "stco_tato_dtlbase_a1_adb13",
        "grille": "thm_tato_imprv_wallgate_grate_ap10"}},
    "dantooine": {"dir": "dantooine", "prefix": "dant", "family": "timber", "timber": "rails", "mat": {
        "base": "dant_rock_wall_base_adb13", "body": "dant_fence_gate_s01_asb14", "cap": "dant_wood_s01_asb13",
        "accent": "dant_wood_s01_asb13", "post": "dant_wood_s01_asb13"}},
    "dathomir": {"dir": "dathomir", "prefix": "dath", "family": "timber", "timber": "palisade", "mat": {
        "base": "dath_nightsister_rock_asb13", "body": "dath_nightsister_logs_aeb14", "cap": "dath_nightsister_boundwood_cap_as8",
        "accent": "dath_nightsister_leather_cords_aa7", "post": "dath_nightsister_boundwood_asb13"}},
    "endor": {"dir": "endor", "prefix": "endr", "family": "timber", "timber": "lashed", "mat": {
        "base": "endr_lakehut_walkway_adb13", "body": "endr_lakehut_walkway_adb13", "cap": "endr_lakehut_posttop_asb13",
        "accent": "endr_lake_twine_asb13", "post": "endr_ewok_post_adb13"}},
}
# every structure type found anywhere in the stock object/static/structure folders, so each planet has its own
# variant of the others' pieces (walkable ones carry a floor; see Piece.walk)
PIECES = ["wall_4x8", "wall_4x16", "wall_4x32", "wall_curve", "wall_low_1x8", "column", "pillar_tall", "pillar_ruined",
          "gate_sm", "gate_wide", "arch_sm", "arch_lg", "fence_4m", "fence_8m", "boundary_post", "beam_overhead",
          "pergola", "gazebo", "planter_box", "fountain_round", "brazier", "platform_8x8", "stair_small", "bridge_sm",
          "walkway_elevated",
          # stairs, walkway network, caps (snap to the pieces above: walkways 3 m wide on a 3 m deck, ends at +-1.5 /
          # +-4; stair_small tops out at 2 m, stair_medium at 3 m = the walkway deck)
          "stair_medium", "stair_large", "landing_4x4", "walkway_corner", "walkway_t", "walkway_cross", "walkway_end",
          "walkway_ramp", "walkway_stair", "wall_end_cap", "wall_coping_8", "column_cap"]
WATER = {"corl": "corl_fountain_water_aaes23", "talus": "corl_fountain_water_aaes23"}     # others: ripple
COALS = "dant_hotcoals_ae9"
H, SINK, THICK = 4.0, 1.0, 1.0          # stock imprv walls: 4 m above ground, 1 m into the terrain, 1 m deep
GATE_W, OPEN_W, OPEN_H = 8.0, 4.0, 4.5  # stock gate_sm: 8 m wide; passage between the posts
CURVE_R = 8.0
UV = {"base": 2.0, "body": 3.0, "cap": 1.0, "accent": 1.0, "post": 2.0, "grille": 2.0, "light": 1.0, "vines": 3.0,
      "water": 3.0, "coals": 1.0}


# ---------------------------------------------------------------------------------------------------------------
# geometry primitives (into per-material accumulators)
# ---------------------------------------------------------------------------------------------------------------

class Piece:
    def __init__(self):
        self.acc = {}
        self.boxes = []          # collision boxes (Maya space): ((x0, y0, z0), (x1, y1, z1))
        self.footprint = []      # radar outline triangles [(x, z) * 3]
        self.walk = []           # walkable floor pieces [(ring3d, holes)] -> a .flr (stairs, bridges, platforms)
        self.walls = pb.MeshAccumulator()   # railing / side faces the floor's edges stop at (wall feet)

    def a(self, slot):
        return self.acc.setdefault(slot, pb.MeshAccumulator(UV.get(slot, 2.0)))

    def box(self, slot, x0, y0, z0, x1, y1, z1, bottom=None, collide=False):
        A = self.a(slot)
        A.facing([(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)], (0, 0, -1))
        A.facing([(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)], (0, 0, 1))
        A.facing([(x0, y0, z0), (x0, y0, z1), (x0, y1, z1), (x0, y1, z0)], (-1, 0, 0))
        A.facing([(x1, y0, z0), (x1, y0, z1), (x1, y1, z1), (x1, y1, z0)], (1, 0, 0))
        A.facing([(x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)], (0, 1, 0))
        if bottom or (bottom is None and y0 > 0.05):          # anything held up off the ground is seen from below
            A.facing([(x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1)], (0, -1, 0))
        if collide:
            self.boxes.append(((x0, y0, z0), (x1, y1, z1)))

    def prism(self, slot, ring, y0, y1, top=True, tip=None):
        """Vertical prism over a convex plan ring [(x, z)]; tip = apex height for a pointed top."""
        A = self.a(slot)
        cx = sum(p[0] for p in ring) / len(ring)
        cz = sum(p[1] for p in ring) / len(ring)
        for i in range(len(ring)):
            (ax, az), (bx, bz) = ring[i - 1], ring[i]
            mx, mz = (ax + bx) / 2 - cx, (az + bz) / 2 - cz
            A.facing([(ax, y0, az), (bx, y0, bz), (bx, y1, bz), (ax, y1, az)], (mx, 0, mz))
            if tip is not None:
                A.facing([(ax, y1, az), (bx, y1, bz), (cx, tip, cz)], (mx, 0.5, mz))
        if top and tip is None:
            A.facing([(p[0], y1, p[1]) for p in ring], (0, 1, 0))
        if y0 > 0.05:                                        # roofs, raised slabs: closed underneath
            A.facing([(p[0], y0, p[1]) for p in ring], (0, -1, 0))

    def log(self, slot, x, z, r, y0, y1, n=6, tip=None):
        ring = [(x + r * math.cos(2 * math.pi * (k + 0.5) / n), z + r * math.sin(2 * math.pi * (k + 0.5) / n)) for k in range(n)]
        self.prism(slot, ring, y0, y1, tip=tip)

    def rail(self, slot, x0, x1, y, z, r, n=6):
        """Horizontal log along x at height y."""
        A = self.a(slot)
        pts = [(y + r * math.cos(2 * math.pi * k / n), z + r * math.sin(2 * math.pi * k / n)) for k in range(n)]
        for i in range(n):
            (ay, az), (by, bz) = pts[i - 1], pts[i]
            my, mz = (ay + by) / 2 - y, (az + bz) / 2 - z
            A.facing([(x0, ay, az), (x1, ay, az), (x1, by, bz), (x0, by, bz)], (0, my, mz))
        for x, s in ((x0, -1), (x1, 1)):
            A.facing([(x, p[0], p[1]) for p in pts], (s, 0, 0))

    def rounded_cap(self, slot, x0, x1, y, half, n=6):
        """Half-cylinder along x on top of a wall of half-thickness `half` (Tatooine's soft parapets)."""
        A = self.a(slot)
        pts = [(y + half * math.sin(math.pi * k / n), -half * math.cos(math.pi * k / n)) for k in range(n + 1)]
        for i in range(n):
            (ay, az), (by, bz) = pts[i], pts[i + 1]
            A.facing([(x0, ay, az), (x1, ay, az), (x1, by, bz), (x0, by, bz)], (0, (ay + by) / 2 - y, (az + bz) / 2))
        for x, s in ((x0, -1), (x1, 1)):
            A.facing([(x, p[0], p[1]) for p in pts], (s, 0, 0))


# ---------------------------------------------------------------------------------------------------------------
# wall runs per family (a straight run from x0 to x1, centred on z = 0)
# ---------------------------------------------------------------------------------------------------------------

def _run(P, th, x0, x1, top, collide=True):
    fam = th["family"]
    t = THICK / 2
    if collide:
        P.boxes.append(((x0, -SINK, -t), (x1, top, t)))
    if fam == "panel":
        P.box("base", x0, -SINK, -t - 0.08, x1, 0.5, t + 0.08)
        P.box("body", x0, 0.5, -t, x1, top - 0.35, t)
        for s in (-1, 1):                                   # accent band, both faces
            z = s * (t + 0.01)
            P.a("accent").facing([(x0, top - 1.35, z), (x1, top - 1.35, z), (x1, top - 1.2, z), (x0, top - 1.2, z)], (0, 0, s))
        P.box("cap", x0 - 0.02, top - 0.35, -t - 0.12, x1 + 0.02, top, t + 0.12)
        if th.get("ribbed"):                                # Nym's plating: ribs every 2 m, vents between
            n = max(1, int(round((x1 - x0) / 2.0)))
            for k in range(n + 1):
                x = x0 + (x1 - x0) * k / n
                P.box("cap", x - 0.1, 0.5, -t - 0.1, x + 0.1, top - 0.35, t + 0.1)
            for k in range(n):
                xm = x0 + (x1 - x0) * (k + 0.5) / n
                for s in (-1, 1):
                    z = s * (t + 0.01)
                    P.a("accent").facing([(xm - 0.5, 1.0, z), (xm + 0.5, 1.0, z), (xm + 0.5, 1.6, z), (xm - 0.5, 1.6, z)], (0, 0, s))
    elif fam == "stone":
        P.box("base", x0, -SINK, -t - 0.12, x1, 0.6, t + 0.12)
        P.box("body", x0, 0.6, -t, x1, top - 0.45, t)
        P.box("cap", x0 - 0.05, top - 0.45, -t - 0.15, x1 + 0.05, top, t + 0.15)
        for s in (-1, 1):                                   # carved band under the cornice
            z = s * (t + 0.01)
            P.a("accent").facing([(x0, top - 1.1, z), (x1, top - 1.1, z), (x1, top - 0.6, z), (x0, top - 0.6, z)], (0, 0, s))
        n = max(1, int(round((x1 - x0) / 4.0)))              # pilasters every ~4 m
        for k in range(n + 1):
            x = x0 + (x1 - x0) * k / n
            P.box("post", x - 0.3, 0.6, -t - 0.12, x + 0.3, top - 0.45, t + 0.12)
        if th.get("vines"):
            for s in (-1, 1):
                z = s * (t + 0.03)
                P.a("vines").facing([(x0, 0.6, z), (x1, 0.6, z), (x1, top - 0.45, z), (x0, top - 0.45, z)], (0, 0, s))
    elif fam == "adobe":
        P.box("base", x0, -SINK, -t - 0.1, x1, 0.4, t + 0.1)
        P.box("body", x0, 0.4, -t, x1, top - t, t)
        P.rounded_cap("cap", x0, x1, top - t, t)
    else:                                                   # timber
        kind = th["timber"]
        n = max(1, int(round((x1 - x0) / 2.0)))
        P.box("base", x0, -SINK, -t + 0.1, x1, 0.15, t - 0.1)
        if kind == "palisade":                              # sharpened logs side by side, bound with cords
            k = max(2, int(round((x1 - x0) / 0.42)))
            for i in range(k):
                x = x0 + (x1 - x0) * (i + 0.5) / k
                P.log("body", x, 0.0, 0.21, -SINK, top - 0.4 - 0.25 * (i % 2), tip=top - 0.25 * (i % 2))
            for y in ((1.0, top - 1.2) if top > 2.5 else (top * 0.5,)):
                P.rail("accent", x0, x1, y, 0.0, 0.25)
        else:
            for i in range(n + 1):
                x = x0 + (x1 - x0) * i / n
                P.log("post", x, 0.0, 0.22, -SINK, top, tip=top + 0.25 if kind == "lashed" else None)
            k = top / H                                      # rails follow the piece's height (low walls too)
            rails = tuple(y * k for y in ((0.9, 2.2, 3.4) if kind == "rails" else (1.2, 3.0)))
            for y in rails:
                P.rail("body", x0, x1, y, 0.0, 0.12 if kind == "rails" else 0.16)
            if kind == "rails":                             # board infill between the rails
                for s in (-1, 1):
                    z = s * 0.06
                    P.a("cap").facing([(x0, 0.3 * k, z), (x1, 0.3 * k, z), (x1, rails[-1], z), (x0, rails[-1], z)], (0, 0, s))
            else:                                           # twine lashings at every post
                for i in range(n + 1):
                    x = x0 + (x1 - x0) * i / n
                    for y in rails:
                        P.log("accent", x, 0.0, 0.26, y - 0.18, y + 0.18)


def _post(P, th, x, w=1.2, top=H + 0.4):
    fam = th["family"]
    h = w / 2
    P.boxes.append(((x - h, -SINK, -h), (x + h, top, h)))
    if fam == "timber":
        P.log("post", x, 0.0, h * 0.7, -SINK, top, n=8, tip=top + 0.5 if th["timber"] != "rails" else None)
        if th["timber"] == "rails":
            P.box("cap", x - h * 0.8, top, -h * 0.8, x + h * 0.8, top + 0.15, h * 0.8)
        return
    P.box("base", x - h - 0.1, -SINK, -h - 0.1, x + h + 0.1, 0.6, h + 0.1)
    P.box("post", x - h, 0.6, -h, x + h, top - 0.4, h)
    if fam == "adobe":
        P.box("cap", x - h - 0.05, top - 0.4, -h - 0.05, x + h + 0.05, top - 0.1, h + 0.05)
        P.log("cap", x, 0.0, h * 0.75, top - 0.1, top + 0.25, n=8, tip=top + 0.45)
    else:
        P.box("cap", x - h - 0.1, top - 0.4, -h - 0.1, x + h + 0.1, top, h + 0.1)
    if th.get("mat", {}).get("light"):                       # Lok: a warning light on each post
        P.box("light", x - 0.2, top, -0.2, x + 0.2, top + 0.15, 0.2)


def _square(h, x=0.0, z=0.0):
    return [((x - h, z - h), (x + h, z - h), (x + h, z + h)), ((x - h, z - h), (x + h, z + h), (x - h, z + h))]


def _gate(P, th, hw, ow, open_h, arch=False):
    """Posts + lintel (or a round arch / a timber crossbeam) over a passage 2*ow wide and open_h tall; only the
    posts collide, so the passage stays open (stock gate/arch collision)."""
    t = THICK / 2
    top = open_h + 1.6
    for s_ in (-1, 1):
        x0, x1 = sorted((s_ * ow, s_ * hw))
        _run(P, th, x0, x1, top - 0.6)
        _post(P, th, s_ * (ow + 0.6), w=1.2, top=top)
    fam = th["family"]
    if fam == "timber":                                      # crossbeam (+ lintel log)
        P.rail("cap", -hw, hw, open_h + 0.5, 0.0, 0.3, n=8)
        if arch:
            P.rail("accent", -ow, ow, open_h + 0.15, 0.0, 0.18)
    elif not arch:
        P.box("body", -ow, open_h, -t, ow, top - 0.6, t)
        P.box("cap", -hw, top - 0.6, -t - 0.15, hw, top, t + 0.15)
        if th["mat"].get("grille"):                          # wrought iron / grate panel in the lintel
            for s_ in (-1, 1):
                z = s_ * (t + 0.01)
                P.a("grille").facing([(-ow + 0.4, open_h + 0.15, z), (ow - 0.4, open_h + 0.15, z),
                                      (ow - 0.4, top - 0.75, z), (-ow + 0.4, top - 0.75, z)], (0, 0, s_))
    else:                                                    # round arch over the passage
        spring, n = open_h - ow, 10
        A = P.a("body")
        arc = [(-ow * math.cos(math.pi * k / n), spring + ow * math.sin(math.pi * k / n)) for k in range(n + 1)]
        for (ax, ay), (bx, by) in zip(arc, arc[1:]):
            for s_ in (-1, 1):
                A.facing([(ax, ay, s_ * t), (bx, by, s_ * t), (bx, top - 0.6, s_ * t), (ax, top - 0.6, s_ * t)], (0, 0, s_))
            P.a("cap").facing([(ax, ay, -t), (bx, by, -t), (bx, by, t), (ax, ay, t)], (-(ax + bx) / 2, spring - (ay + by) / 2, 0))
        P.box("cap", -hw, top - 0.6, -t - 0.15, hw, top, t + 0.15)
    P.footprint = [((-hw, -t), (-ow, -t), (-ow, t)), ((-hw, -t), (-ow, t), (-hw, t)),
                   ((ow, -t), (hw, -t), (hw, t)), ((ow, -t), (hw, t), (ow, t))]


def _slim_post(P, th, x, z, w, top, y0=-SINK):
    """A slender post (pergola / gazebo / fountain spout / brazier stem) in the family's idiom."""
    if th["family"] == "timber":
        P.log("post", x, z, w * 0.6, y0, top, n=6)
    elif th["family"] == "adobe":
        P.log("post", x, z, w * 0.6, y0, top, n=8)
    else:
        h = w / 2
        P.box("post", x - h, y0, z - h, x + h, top, z + h)
        P.box("cap", x - h - 0.05, top - 0.15, z - h - 0.05, x + h + 0.05, top, z + h + 0.05)
    P.boxes.append(((x - w / 2, y0, z - w / 2), (x + w / 2, top, z + w / 2)))


def _beam(P, th, a0, a1, y, c, along="x", small=False):
    r = 0.09 if small else 0.16
    if th["family"] == "timber":
        if along == "x":
            P.rail("cap", a0, a1, y + r, c, r)
        else:
            P.box("cap", c - r, y, a0, c + r, y + 2 * r, a1)
    elif along == "x":
        P.box("cap", a0, y, c - r, a1, y + 2 * r, c + r)
    else:
        P.box("cap", c - r, y, a0, c + r, y + 2 * r, a1)


def _fence(P, th, x0, x1, top=1.4):
    """Low see-through fence: posts every 2 m + two rails (timber logs, masonry balusters, adobe parapet)."""
    P.boxes.append(((x0, -SINK, -0.2), (x1, top, 0.2)))
    fam = th["family"]
    if fam == "adobe":
        P.box("body", x0, -SINK, -0.15, x1, top - 0.15, 0.15)
        P.rounded_cap("cap", x0, x1, top - 0.15, 0.15)
        return
    n = max(1, int(round((x1 - x0) / 2.0)))
    for i in range(n + 1):
        x = x0 + (x1 - x0) * i / n
        if fam == "timber":
            P.log("post", x, 0.0, 0.12, -SINK, top + 0.1, tip=top + 0.3 if th["timber"] != "rails" else None)
        else:
            P.box("post", x - 0.12, -SINK, -0.12, x + 0.12, top, 0.12)
    for y in (0.45, top - 0.15):
        if fam == "timber":
            P.rail("body", x0, x1, y, 0.0, 0.07)
        else:
            P.box("cap", x0, y - 0.06, -0.06, x1, y + 0.06, 0.06)


def _railing(P, th, x0, x1, z, y, h=1.0):
    """Railing along x at plan z on a deck at height y; its face is also a wall foot for the deck's floor."""
    fam = th["family"]
    P.boxes.append(((x0, y, z - 0.12), (x1, y + h, z + 0.12)))
    P.walls.facing([(x0, y - 0.05, z), (x1, y - 0.05, z), (x1, y + h, z), (x0, y + h, z)], (0, 0, -1 if z > 0 else 1))
    if fam == "adobe":
        P.box("body", x0, y, z - 0.12, x1, y + h - 0.12, z + 0.12)
        P.rounded_cap("cap", x0, x1, y + h - 0.12, 0.12)
        return
    n = max(1, int(round((x1 - x0) / 1.5)))
    for i in range(n + 1):
        x = x0 + (x1 - x0) * i / n
        if fam == "timber":
            P.log("post", x, z, 0.08, y, y + h + 0.05)
        else:
            P.box("post", x - 0.06, y, z - 0.06, x + 0.06, y + h, z + 0.06)
    if fam == "timber":
        P.rail("body", x0, x1, y + h - 0.05, z, 0.06)
    else:
        P.box("cap", x0, y + h - 0.08, z - 0.09, x1, y + h, z + 0.09)


def _stair(P, th, w, run, rise):
    """Straight flight along +z: steps, solid sides (wall feet + collision), a sloped walk floor; the bottom and
    top edges are where you step on and off."""
    n = max(4, int(round(rise / 0.2)))
    hw = w / 2
    for k in range(n):
        z0, z1 = -run / 2 + run * k / n, -run / 2 + run * (k + 1) / n
        y = rise * (k + 1) / n
        P.box("base", -hw, -0.2, z0, hw, y, z1)
    for s_ in (-1, 1):
        x0, x1 = sorted((s_ * hw, s_ * (hw + 0.4)))
        P.box("body", x0, -0.2, -run / 2, x1, rise + 1.0, run / 2)
        P.boxes.append(((x0, -SINK, -run / 2), (x1, rise + 1.0, run / 2)))
        xi = s_ * hw
        P.walls.facing([(xi, -0.1, -run / 2), (xi, -0.1, run / 2), (xi, rise + 1.0, run / 2), (xi, rise + 1.0, -run / 2)], (-s_, 0, 0))
    P.walk.append(([(-hw, 0.0, -run / 2), (hw, 0.0, -run / 2), (hw, rise, run / 2), (-hw, rise, run / 2)], []))


def _bridge(P, th, span, width, deck, ramp):
    hw, hs = width / 2, span / 2
    P.box("base", -hs, deck - 0.4, -hw, hs, deck, hw)
    for s_ in (-1, 1):                                       # ramps down to the ground at both ends
        xa, xb = (hs, hs + ramp) if s_ > 0 else (-hs - ramp, -hs)
        A = P.a("base")
        yb = lambda x: deck * (1 - (abs(x) - hs) / ramp)
        A.facing([(xa, yb(xa), -hw), (xb, yb(xb), -hw), (xb, yb(xb), hw), (xa, yb(xa), hw)], (0, 1, 0))
        for z in (-hw, hw):
            A.facing([(xa, -0.2, z), (xb, -0.2, z), (xb, yb(xb), z), (xa, yb(xa), z)], (0, 0, z))
        P.walk.append(([(xa, yb(xa), -hw), (xb, yb(xb), -hw), (xb, yb(xb), hw), (xa, yb(xa), hw)], []))
    P.walk.append(([(-hs, deck, -hw), (hs, deck, -hw), (hs, deck, hw), (-hs, deck, hw)], []))
    for z in (-hw, hw):
        _railing(P, th, -hs, hs, z, deck)
    for x in (-hs, hs):                                      # abutments
        P.box("body", x - 0.4, -SINK, -hw - 0.2, x + 0.4, deck - 0.4, hw + 0.2)


def _walkway(P, th, length, width, deck):
    hw, hl = width / 2, length / 2
    P.box("base", -hl, deck - 0.35, -hw, hl, deck, hw)
    P.walk.append(([(-hl, deck, -hw), (hl, deck, -hw), (hl, deck, hw), (-hl, deck, hw)], []))
    for z in (-hw, hw):
        _railing(P, th, -hl, hl, z, deck)
    for x in (-hl + 0.4, hl - 0.4):
        for z in (-hw + 0.3, hw - 0.3):
            _slim_post(P, th, x, z, 0.45, deck - 0.35)


def _turned(P, build, quarter):
    """Run build(Q) into a scratch piece and merge it into P turned `quarter` x 90 degrees round y (meshes, collision
    boxes, wall feet, walk floors, footprint)."""
    Q = Piece()
    build(Q)
    a = math.pi / 2 * quarter
    c, s_ = round(math.cos(a)), round(math.sin(a))
    rot = lambda x, z: (c * x - s_ * z, s_ * x + c * z)
    for slot, acc in Q.acc.items():
        P.a(slot)
        _merge_rotated(P.acc[slot], acc, c, s_, 0.0, 0.0)
    off = 0
    for n in Q.walls.counts:
        pts = [Q.walls.points[i] for i in Q.walls.connects[off:off + n]]
        off += n
        P.walls.poly([(rot(x, z)[0], y, rot(x, z)[1]) for x, y, z in pts], [(0.0, 0.0)] * n)
    for (x0, y0, z0), (x1, y1, z1) in Q.boxes:
        xa, za = rot(x0, z0)
        xb, zb = rot(x1, z1)
        P.boxes.append(((min(xa, xb), y0, min(za, zb)), (max(xa, xb), y1, max(za, zb))))
    for ring, holes in Q.walk:
        P.walk.append(([(rot(x, z)[0], y, rot(x, z)[1]) for x, y, z in ring], holes))
    P.footprint += [tuple(rot(*q) for q in tri) for tri in Q.footprint]


def _slope_railing(P, th, x0, x1, y0, y1, z, h=1.0):
    """Railing along x from (x0, y0) to (x1, y1) at plan z (a ramp's side): posts, a sloped top rail, wall feet."""
    fam = th["family"]
    yy = lambda x: y0 + (y1 - y0) * (x - x0) / (x1 - x0)
    P.boxes.append(((x0, min(y0, y1), z - 0.12), (x1, max(y0, y1) + h, z + 0.12)))
    P.walls.facing([(x0, y0 - 0.05, z), (x1, y1 - 0.05, z), (x1, y1 + h, z), (x0, y0 + h, z)], (0, 0, -1 if z > 0 else 1))
    n = max(1, int(round((x1 - x0) / 1.5)))
    for i in range(n + 1):
        x = x0 + (x1 - x0) * i / n
        if fam == "timber":
            P.log("post", x, z, 0.08, yy(x), yy(x) + h + 0.05)
        else:
            P.box("post", x - 0.06, yy(x), z - 0.06, x + 0.06, yy(x) + h, z + 0.06)
    A = P.a("body" if fam == "timber" else "cap")
    t = 0.07 if fam == "timber" else 0.09
    for s_ in (-1, 1):
        A.facing([(x0, y0 + h - 0.08, z + s_ * t), (x1, y1 + h - 0.08, z + s_ * t), (x1, y1 + h, z + s_ * t),
                  (x0, y0 + h, z + s_ * t)], (0, 0, s_))
    A.facing([(x0, y0 + h, z - t), (x1, y1 + h, z - t), (x1, y1 + h, z + t), (x0, y0 + h, z + t)], (0, 1, 0))
    A.facing([(x0, y0 + h - 0.08, z - t), (x1, y1 + h - 0.08, z - t), (x1, y1 + h - 0.08, z + t),
              (x0, y0 + h - 0.08, z + t)], (0, -1, 0))


def _walkway_node(P, th, opens, deck=3.0, half=1.5):
    """Square walkway junction (corner / T / cross / dead end): a deck `2*half` square at `deck`, railings on the
    closed sides, a post under each corner. opens: subset of {"+x", "-x", "+z", "-z"} - the open sides, where
    walkway_elevated pieces (ends at +-4 from their centre) butt on."""
    h = half
    P.box("base", -h, deck - 0.35, -h, h, deck, h)
    P.walk.append(([(-h, deck, -h), (h, deck, -h), (h, deck, h), (-h, deck, h)], []))
    for side, quarter in (("-z", 0), ("+x", 1), ("+z", 2), ("-x", 3)):
        if side not in opens:
            _turned(P, lambda Q: _railing(Q, th, -h, h, -h, deck), quarter)
    for x in (-h + 0.3, h - 0.3):
        for z in (-h + 0.3, h - 0.3):
            _slim_post(P, th, x, z, 0.45, deck - 0.35)
    P.footprint += _square(h)


def _cap(P, th, x0, x1, z0, z1, y, rise=0.35):
    """Coping / cap block on a wall or post top in the family's idiom (cornice, metal cap, rounded adobe, log rail)."""
    fam = th["family"]
    if fam == "adobe":
        P.box("cap", x0, y, z0, x1, y + rise * 0.4, z1)
        P.rounded_cap("cap", x0, x1, y + rise * 0.4, (z1 - z0) / 2)
    elif fam == "timber":
        P.rail("cap", x0, x1, y + 0.15, (z0 + z1) / 2, max(0.12, (z1 - z0) / 2))
    else:
        P.box("cap", x0 - 0.05, y, z0 - 0.1, x1 + 0.05, y + rise * 0.6, z1 + 0.1)
        P.box("accent" if fam == "stone" else "cap", x0, y + rise * 0.6, z0 - 0.02, x1, y + rise, z1 + 0.02)


def build_piece(theme, piece):
    th = THEMES[theme]
    P = Piece()
    t = THICK / 2
    if piece in ("wall_4x8", "wall_4x16"):
        L = 8.0 if piece == "wall_4x8" else 16.0
        _run(P, th, -L / 2, L / 2, H)
        P.footprint = [((-L / 2, -t), (L / 2, -t), (L / 2, t)), ((-L / 2, -t), (L / 2, t), (-L / 2, t))]
    elif piece == "wall_low_1x8":
        _run(P, th, -4.0, 4.0, 1.1)
        P.footprint = [((-4, -t), (4, -t), (4, t)), ((-4, -t), (4, t), (-4, t))]
    elif piece == "column":
        _post(P, th, 0.0)
        P.footprint = [((-0.6, -0.6), (0.6, -0.6), (0.6, 0.6)), ((-0.6, -0.6), (0.6, 0.6), (-0.6, 0.6))]
    elif piece in ("gate_sm", "arch_sm", "gate_wide", "arch_lg"):
        hw, ow, oh = {"gate_sm": (4.0, 2.0, OPEN_H), "arch_sm": (4.0, 2.0, OPEN_H), "gate_wide": (6.0, 4.0, OPEN_H),
                      "arch_lg": (6.0, 3.0, 7.5)}[piece]
        _gate(P, th, hw, ow, oh, arch=piece.startswith("arch"))
    elif piece == "wall_curve":
        n = 12
        for k in range(n):                                   # short straight segments along the arc
            a0, a1 = math.pi / 2 * k / n, math.pi / 2 * (k + 1) / n
            seg = Piece()
            L = 2 * CURVE_R * math.sin((a1 - a0) / 2) + 0.06
            _run(seg, th, -L / 2, L / 2, H, collide=False)
            am = (a0 + a1) / 2
            cx, cz = CURVE_R * math.cos(am), CURVE_R * math.sin(am)
            rot = math.pi / 2 + am                           # segment's local x runs along the arc tangent
            c, s_ = math.cos(rot), math.sin(rot)
            for slot, acc in seg.acc.items():
                P.a(slot)
                _merge_rotated(P.acc[slot], acc, c, s_, cx, cz)
            # collision: the segment's axis-aligned bounds (small segments keep the overcover small)
            xs = [cx + c * x - s_ * z for x in (-L / 2, L / 2) for z in (-t, t)]
            zs = [cz + s_ * x + c * z for x in (-L / 2, L / 2) for z in (-t, t)]
            P.boxes.append(((min(xs), -SINK, min(zs)), (max(xs), H, max(zs))))
            q = [(CURVE_R - t) * math.cos(a0), (CURVE_R - t) * math.sin(a0)], [(CURVE_R + t) * math.cos(a0), (CURVE_R + t) * math.sin(a0)], \
                [(CURVE_R + t) * math.cos(a1), (CURVE_R + t) * math.sin(a1)], [(CURVE_R - t) * math.cos(a1), (CURVE_R - t) * math.sin(a1)]
            P.footprint += [(tuple(q[0]), tuple(q[1]), tuple(q[2])), (tuple(q[0]), tuple(q[2]), tuple(q[3]))]
    elif piece == "wall_4x32":
        _run(P, th, -16.0, 16.0, H)
        P.footprint = [((-16, -t), (16, -t), (16, t)), ((-16, -t), (16, t), (-16, t))]
    elif piece == "pillar_tall":
        _post(P, th, 0.0, w=1.6, top=8.0)
        P.footprint = _square(0.8)
    elif piece == "pillar_ruined":
        if th["family"] == "timber":
            P.log("post", 0.0, 0.0, 0.55, -SINK, 2.2, n=8, tip=2.9)
        else:
            P.box("base", -0.9, -SINK, -0.9, 0.9, 0.6, 0.9)
            P.box("post", -0.7, 0.6, -0.7, 0.7, 2.6, 0.7)
            P.box("post", -0.7, 2.6, -0.7, 0.15, 3.3, 0.35)        # the broken stump of the shaft
            P.box("cap", 0.9, -0.2, -0.4, 1.9, 0.35, 0.5)          # a fallen block at its foot
        P.boxes.append(((-0.9, -SINK, -0.9), (0.9, 3.3, 0.9)))
        P.footprint = _square(0.9)
    elif piece in ("fence_4m", "fence_8m"):
        L = 4.0 if piece == "fence_4m" else 8.0
        _fence(P, th, -L / 2, L / 2)
        P.footprint = [((-L / 2, -0.2), (L / 2, -0.2), (L / 2, 0.2)), ((-L / 2, -0.2), (L / 2, 0.2), (-L / 2, 0.2))]
    elif piece == "boundary_post":
        _post(P, th, 0.0, w=0.5, top=1.6)
        P.footprint = _square(0.25)
    elif piece == "beam_overhead":
        for x in (-4.0, 4.0):
            _post(P, th, x, w=0.8, top=5.0)
        if th["family"] == "timber":
            P.rail("cap", -4.6, 4.6, 4.7, 0.0, 0.3, n=8)
        else:
            P.box("cap", -4.6, 4.4, -0.45, 4.6, 5.0, 0.45)
        P.footprint = _square(0.4, -4.0) + _square(0.4, 4.0)
    elif piece == "pergola":
        for x in (-3.5, 3.5):
            for z in (-3.5, 3.5):
                _slim_post(P, th, x, z, 0.4, 3.2)
        for z in (-3.5, 3.5):
            _beam(P, th, -3.9, 3.9, 3.2, z, along="x")
        for k in range(7):
            x = -3.0 + k
            _beam(P, th, -3.9, 3.9, 3.45, x, along="z", small=True)
        P.footprint = [tri for x in (-3.5, 3.5) for z in (-3.5, 3.5) for tri in _square(0.2, x, z)]
    elif piece == "gazebo":
        n, rp, ry = 8, 4.2, 0.4
        ring = [(rp * math.cos(2 * math.pi * (k + 0.5) / n), rp * math.sin(2 * math.pi * (k + 0.5) / n)) for k in range(n)]
        P.prism("base", ring, -SINK, ry)
        P.walk.append(([(x, ry, z) for x, z in ring], []))
        for k in range(n):
            a = 2 * math.pi * (k + 0.5) / n
            _slim_post(P, th, 3.7 * math.cos(a), 3.7 * math.sin(a), 0.35, 3.4, y0=ry)
        roof = [(4.7 * math.cos(2 * math.pi * (k + 0.5) / n), 4.7 * math.sin(2 * math.pi * (k + 0.5) / n)) for k in range(n)]
        P.prism("cap", roof, 3.4, 3.7, tip=5.4)
        P.footprint = [((0, 0), ring[k - 1], ring[k]) for k in range(n)]
    elif piece == "planter_box":
        P.box("base", -1.0, -0.3, -1.0, 1.0, 0.8, 1.0, collide=True)
        P.box("cap", -1.1, 0.8, -1.1, 1.1, 0.9, 1.1)
        P.footprint = _square(1.0)
    elif piece == "fountain_round":
        n = 12
        outer = [(3.0 * math.cos(2 * math.pi * k / n), 3.0 * math.sin(2 * math.pi * k / n)) for k in range(n)]
        inner = [(2.6 * math.cos(2 * math.pi * k / n), 2.6 * math.sin(2 * math.pi * k / n)) for k in range(n)]
        A = P.a("body")
        for k in range(n):                                   # ring wall: outside, inside, top
            (ax, az), (bx, bz) = outer[k - 1], outer[k]
            A.facing([(ax, -0.2, az), (bx, -0.2, bz), (bx, 0.6, bz), (ax, 0.6, az)], ((ax + bx) / 2, 0, (az + bz) / 2))
            (cx, cz), (dx, dz) = inner[k - 1], inner[k]
            A.facing([(cx, 0.0, cz), (dx, 0.0, dz), (dx, 0.6, dz), (cx, 0.6, cz)], (-(cx + dx) / 2, 0, -(cz + dz) / 2))
            P.a("cap").facing([(ax, 0.6, az), (bx, 0.6, bz), (dx, 0.6, dz), (cx, 0.6, cz)], (0, 1, 0))
        P.a("base").facing([(x, 0.02, z) for x, z in inner], (0, 1, 0))
        P.a("water").facing([(x, 0.42, z) for x, z in inner], (0, 1, 0))
        _slim_post(P, th, 0.0, 0.0, 0.6, 1.8, y0=0.0)
        P.boxes.append(((-3.0, -SINK, -3.0), (3.0, 0.6, 3.0)))
        P.footprint = [((0, 0), outer[k - 1], outer[k]) for k in range(n)]
    elif piece == "brazier":
        _slim_post(P, th, 0.0, 0.0, 0.3, 1.0, y0=-0.3)
        n = 8
        lo = [(0.35 * math.cos(2 * math.pi * k / n), 0.35 * math.sin(2 * math.pi * k / n)) for k in range(n)]
        hi = [(0.65 * math.cos(2 * math.pi * k / n), 0.65 * math.sin(2 * math.pi * k / n)) for k in range(n)]
        A = P.a("cap")
        for k in range(n):
            A.facing([(lo[k - 1][0], 1.0, lo[k - 1][1]), (lo[k][0], 1.0, lo[k][1]), (hi[k][0], 1.35, hi[k][1]),
                      (hi[k - 1][0], 1.35, hi[k - 1][1])], (lo[k][0] + lo[k - 1][0], 0.3, lo[k][1] + lo[k - 1][1]))
        P.a("coals").facing([(x * 0.9, 1.28, z * 0.9) for x, z in hi], (0, 1, 0))
        P.boxes.append(((-0.65, -0.3, -0.65), (0.65, 1.35, 0.65)))
        P.footprint = _square(0.65)
    elif piece == "platform_8x8":
        P.box("base", -4.0, -SINK, -4.0, 4.0, 0.5, 4.0)
        P.box("cap", -4.1, 0.35, -4.1, 4.1, 0.5, 4.1)
        P.walk.append(([(-4.1, 0.5, -4.1), (4.1, 0.5, -4.1), (4.1, 0.5, 4.1), (-4.1, 0.5, 4.1)], []))
        P.footprint = _square(4.1)
    elif piece == "stair_small":
        _stair(P, th, w=4.0, run=4.0, rise=2.0)
        P.footprint = _square(2.0) + _square(2.0, 0.0, 0.0)
    elif piece == "bridge_sm":
        _bridge(P, th, span=8.0, width=3.0, deck=0.8, ramp=2.0)
        P.footprint = [((-6, -1.5), (6, -1.5), (6, 1.5)), ((-6, -1.5), (6, 1.5), (-6, 1.5))]
    elif piece == "walkway_elevated":
        _walkway(P, th, length=8.0, width=3.0, deck=3.0)
        P.footprint = [((-4, -1.5), (4, -1.5), (4, 1.5)), ((-4, -1.5), (4, 1.5), (-4, 1.5))]
    elif piece == "stair_medium":
        _stair(P, th, w=4.0, run=6.0, rise=3.0)
        P.footprint = [((-2.4, -3), (2.4, -3), (2.4, 3)), ((-2.4, -3), (2.4, 3), (-2.4, 3))]
    elif piece == "stair_large":
        _stair(P, th, w=6.0, run=8.0, rise=4.0)
        P.footprint = [((-3.4, -4), (3.4, -4), (3.4, 4)), ((-3.4, -4), (3.4, 4), (-3.4, 4))]
    elif piece == "landing_4x4":
        # a 4 x 4 m platform 2 m up (the top of stair_small), open on +z (stairs) and -z, railed on the sides
        P.box("base", -2.0, 1.65, -2.0, 2.0, 2.0, 2.0)
        P.walk.append(([(-2.0, 2.0, -2.0), (2.0, 2.0, -2.0), (2.0, 2.0, 2.0), (-2.0, 2.0, 2.0)], []))
        for quarter in (1, 3):
            _turned(P, lambda Q: _railing(Q, th, -2.0, 2.0, -2.0, 2.0), quarter)
        for x in (-1.7, 1.7):
            for z in (-1.7, 1.7):
                _slim_post(P, th, x, z, 0.45, 1.65)
        P.footprint = _square(2.0)
    elif piece in ("walkway_corner", "walkway_t", "walkway_cross", "walkway_end"):
        opens = {"walkway_corner": {"+x", "+z"}, "walkway_t": {"+x", "-x", "+z"}, "walkway_cross": {"+x", "-x", "+z", "-z"},
                 "walkway_end": {"+x"}}[piece]
        _walkway_node(P, th, opens)
    elif piece == "walkway_ramp":
        # from the walkway deck (3 m) at x = -4 down to the ground at x = +6: 10 m run, about 17 degrees
        x0, x1, hw = -4.0, 6.0, 1.5
        A = P.a("base")
        A.facing([(x0, 3.0, -hw), (x1, 0.0, -hw), (x1, 0.0, hw), (x0, 3.0, hw)], (0.3, 1, 0))
        for z in (-hw, hw):
            A.facing([(x0, -0.2, z), (x1, -0.2, z), (x1, 0.0, z), (x0, 3.0, z)], (0, 0, z))
        A.facing([(x0, -0.2, -hw), (x0, -0.2, hw), (x0, 3.0, hw), (x0, 3.0, -hw)], (-1, 0, 0))
        P.walk.append(([(x0, 3.0, -hw), (x1, 0.0, -hw), (x1, 0.0, hw), (x0, 3.0, hw)], []))
        for z in (-hw, hw):
            _slope_railing(P, th, x0, x1, 3.0, 0.0, z)
        P.footprint = [((x0, -hw), (x1, -hw), (x1, hw)), ((x0, -hw), (x1, hw), (x0, hw))]
    elif piece == "walkway_stair":
        # a 3 m wide flight up to the walkway deck: 6 m run, 3 m rise, along +z (top end at z = +3)
        _stair(P, th, w=3.0, run=6.0, rise=3.0)
        P.footprint = [((-1.9, -3), (1.9, -3), (1.9, 3)), ((-1.9, -3), (1.9, 3), (-1.9, 3))]
    elif piece == "wall_end_cap":
        # finishes a wall run: a block a little wider than the wall, capped in the family's idiom
        t = THICK / 2
        P.boxes.append(((-0.6, -SINK, -t - 0.15), (0.6, H + 0.6, t + 0.15)))
        if th["family"] == "timber":
            P.log("post", 0.0, 0.0, t + 0.15, -SINK, H + 0.3, n=8, tip=H + 0.8)
        else:
            P.box("base", -0.7, -SINK, -t - 0.25, 0.7, 0.6, t + 0.25)
            P.box("post", -0.6, 0.6, -t - 0.15, 0.6, H + 0.2, t + 0.15)
            _cap(P, th, -0.6, 0.6, -t - 0.15, t + 0.15, H + 0.2, rise=0.4)
        P.footprint = [((-0.7, -t - 0.25), (0.7, -t - 0.25), (0.7, t + 0.25)), ((-0.7, -t - 0.25), (0.7, t + 0.25), (-0.7, t + 0.25))]
    elif piece == "wall_coping_8":
        # a coping course that sits on top of an 8 m wall (y = H), adding a finished edge / extra height
        t = THICK / 2
        _cap(P, th, -4.0, 4.0, -t, t, H, rise=0.5)
        P.boxes.append(((-4.0, H, -t - 0.1), (4.0, H + 0.5, t + 0.1)))
        P.footprint = [((-4, -t), (4, -t), (4, t)), ((-4, -t), (4, t), (-4, t))]
    elif piece == "column_cap":
        # a finial that sits on a column / post top (column is 1.2 m square, top at H + 0.4)
        fam = th["family"]
        y = H + 0.4
        if fam == "timber":
            P.log("cap", 0.0, 0.0, 0.5, y, y + 0.3, n=8, tip=y + 0.9)
        elif fam == "adobe":
            P.log("cap", 0.0, 0.0, 0.55, y, y + 0.25, n=10, tip=y + 0.75)
        else:
            P.box("cap", -0.75, y, -0.75, 0.75, y + 0.2, 0.75)
            P.box("post", -0.45, y + 0.2, -0.45, 0.45, y + 0.6, 0.45)
            P.log("accent" if fam == "stone" else "cap", 0.0, 0.0, 0.42, y + 0.6, y + 0.75, n=8, tip=y + 1.2)
        P.boxes.append(((-0.75, y, -0.75), (0.75, y + 1.2, 0.75)))
        P.footprint = _square(0.75)
    else:
        raise ValueError(f"unknown piece {piece}")
    return P


def _merge_rotated(dst, src, c, s, tx, tz):
    off = 0
    for n in src.counts:
        corners = [src.points[i] for i in src.connects[off:off + n]]
        off += n
        pts = [(tx + c * x - s * z, y, tz + s * x + c * z) for x, y, z in corners]
        dst.poly(pts, [pb._uv_for(p, pb._normal3(pts), dst.uv_scale) for p in pts])


# ---------------------------------------------------------------------------------------------------------------
# build + export
# ---------------------------------------------------------------------------------------------------------------

def preview(theme, gap=4.0):
    """Every piece of a theme laid out in rows of five (review renders; nothing exported)."""
    cmds.file(new=True, force=True)
    th = THEMES[theme]
    x, row = 0.0, 0
    sgs = {}            # one material per slot (re-making it would fight its connected texture)
    for i, piece in enumerate(PIECES):
        if i and i % 5 == 0:
            x, row = 0.0, row + 1
        P = build_piece(theme, piece)
        grp = cmds.createNode("transform", name=f"{theme}_{piece}")
        for slot, acc in P.acc.items():
            if acc.counts:
                if slot not in sgs:
                    sgs[slot] = pb._material(f"kit_{theme}_{slot}", (0.6, 0.6, 0.6), None, SP(_slot_shader(th, slot)))
                cmds.sets(acc.build(f"{piece}_{slot}", "|" + grp), edit=True, forceElement=sgs[slot])
        bb = cmds.exactWorldBoundingBox("|" + grp)
        cmds.setAttr(f"|{grp}.translateX", x - bb[0])
        cmds.setAttr(f"|{grp}.translateZ", -row * 18.0)
        x += (bb[3] - bb[0]) + gap
    return {"theme": theme, "width": x}


def piece_name(theme, piece, suffix=1):
    return f"{THEMES[theme]['prefix']}_imprv_{piece}_s{suffix:02d}"


def build(theme, piece, export_root, suffix=1):
    """Build one kit piece in a fresh scene and export it: appearance/thm_<name>.apt + appearance/mesh/... ."""
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    th = THEMES[theme]
    name = piece_name(theme, piece, suffix)
    P = build_piece(theme, piece)
    root = cmds.createNode("transform", name="thm_" + name)
    for slot, acc in P.acc.items():
        if not acc.counts:
            continue
        shader = SP(_slot_shader(th, slot))
        sg = pb._material(f"kit_{theme}_{slot}", (0.6, 0.6, 0.6), None, shader)
        m = acc.build(f"{name}_{slot}", "|" + root)
        cmds.sets(m, edit=True, forceElement=sg)
    flr_rel = None
    if P.walk:
        # walkable piece: its floor (.flr) - ends crossable, railings/sides as wall feet (collision|extent)
        coll = cmds.createNode("transform", name="collision", parent="|" + root)
        ext = cmds.createNode("transform", name="extent", parent=coll)
        if P.walls.counts:
            P.walls.build("walls", ext)
        fl = pb._facet_mesh(P.walk, "floor", "|" + root + "|collision", up=True)
        cmds.addAttr(fl, longName="swgFloorOpenEdgesCrossable", attributeType="bool")
        cmds.setAttr(fl + ".swgFloorOpenEdgesCrossable", True)
        flr_rel = f"appearance/collision/thm_{name}_collision_floor0.flr"
        os.makedirs(os.path.dirname(f"{export_root}/{flr_rel}"), exist_ok=True)
        cmds.select(fl, replace=True)
        cmds.file(f"{export_root}/{flr_rel}", force=True, exportSelected=True, type="SwgFlr")
        cmds.delete(coll)
    apt = f"{export_root}/appearance/thm_{name}.apt".replace("\\", "/")
    os.makedirs(os.path.dirname(apt), exist_ok=True)
    cmds.select("|" + root, replace=True)
    mel.eval(f'exportStaticMesh -path "{apt}" -collision none')
    xs = [p for b in P.boxes for p in (b[0][0], b[1][0])]
    ys = [p for b in P.boxes for p in (b[0][1], b[1][1])]
    zs = [p for b in P.boxes for p in (b[0][2], b[1][2])]
    bb = cmds.exactWorldBoundingBox("|" + root)
    return {"name": name, "theme": theme, "piece": piece, "dir": th["dir"], "apt": f"appearance/thm_{name}.apt",
            "bounds": [round(v, 3) for v in bb], "boxes": [[list(map(float, a)), list(map(float, b))] for a, b in P.boxes],
            "composite": piece in ("gate_sm", "arch_sm", "wall_curve") or len(P.boxes) > 1,
            "footprint": [[list(p) for p in tri] for tri in P.footprint], "root": root, "floor": flr_rel}


def _slot_shader(th, slot):
    if slot == "water":
        return WATER.get(th["prefix"], "corl_fountain_water_ripple_ae9")
    if slot == "coals":
        return COALS
    return th["mat"].get(slot) or th["mat"]["body"]
