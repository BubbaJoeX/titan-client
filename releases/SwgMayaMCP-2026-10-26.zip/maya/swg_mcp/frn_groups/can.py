"""Mos Eisley cantina furniture (group `can`): tan adobe, worn metal, brass taps, dim amber light and neon accents.
Host half (materials, names, the sign's lights): examples/frn_sets/can.py.

  can_bar_counter    interact (wipe)  a curved bar section: adobe front, worn metal top, brass taps, a drink drum,
                                      shelves of bottles on the serving side where the bartender stands
  can_booth          seat             an alcove booth: curved padded bench in an adobe niche, a round table
  can_neon_sign      lamp             a freestanding double-sided neon sign: a cocktail glass and Aurebesh glyphs
  can_dejarik_table  table            a holochess table: checker-ring board, six holographic monsters
  can_band_stand     decor            a riser with Bith instruments on stands: ommni box, kloo horn, fanfar
  can_sabacc_table   table            a sabacc table: card slots, chip stacks, the dealer's well, a lamp-lit rim

Maya space: y up, standing on the origin, front +z. Translucent holograms (a_alpha_emis_full) are shells round
an opaque emissive core, so the far side of a shell never shows through as a culled back face."""
from __future__ import annotations

import math

from ..furniture import (v_add, v_sub, v_mul, v_norm, v_cross, rot, seat_hardpoint, station_hardpoints,
                         light_hardpoint)

# ---------------------------------------------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------------------------------------------


def _spline(ctrl, per):
    """Catmull-Rom curve through the control points, `per` samples per span."""
    pts = [ctrl[0]] + list(ctrl) + [ctrl[-1]]
    out = []
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[i + 1], pts[i + 2]
        for k in range(per):
            t = k / per
            t2, t3 = t * t, t * t * t
            out.append(tuple(0.5 * (2 * p1[j] + (p2[j] - p0[j]) * t + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * t2 +
                                    (3 * p1[j] - p0[j] - 3 * p2[j] + p3[j]) * t3) for j in range(3)))
    out.append(tuple(ctrl[-1]))
    return out


def _chaikin(pts, it, closed=False):
    """Corner-cutting: rounds polyline corners like a bent neon tube."""
    for _ in range(it):
        out = [] if closed else [pts[0]]
        m = len(pts)
        for i in range(m if closed else m - 1):
            a, b = pts[i], pts[(i + 1) % m]
            out.append(tuple(a[j] * 0.75 + b[j] * 0.25 for j in range(len(a))))
            out.append(tuple(a[j] * 0.25 + b[j] * 0.75 for j in range(len(a))))
        if not closed:
            out.append(pts[-1])
        pts = out
    return pts


def _runs(pts, closed, max_turn=100.0):
    """Split a polyline at corners sharper than max_turn degrees (a tube swept round them would fold)."""
    m = len(pts)
    if closed:
        pts = list(pts) + [pts[0]]
    sharp = []
    for i in range(1, len(pts) - 1):
        a, b, c = pts[i - 1], pts[i], pts[i + 1]
        d1 = (b[0] - a[0], b[1] - a[1])
        d2 = (c[0] - b[0], c[1] - b[1])
        l1, l2 = math.hypot(*d1), math.hypot(*d2)
        if l1 < 1e-9 or l2 < 1e-9:
            continue
        cosang = (d1[0] * d2[0] + d1[1] * d2[1]) / (l1 * l2)
        if math.degrees(math.acos(max(-1.0, min(1.0, cosang)))) > max_turn:
            sharp.append(i)
    if closed and m > 2:
        a, b, c = pts[-2], pts[0], pts[1]
        d1, d2 = (b[0] - a[0], b[1] - a[1]), (c[0] - b[0], c[1] - b[1])
        l1, l2 = math.hypot(*d1), math.hypot(*d2)
        start_sharp = l1 > 1e-9 and l2 > 1e-9 and math.degrees(math.acos(max(-1.0, min(1.0, (d1[0] * d2[0] + d1[1] * d2[1]) / (l1 * l2))))) > max_turn
        if not sharp and not start_sharp:
            return [(pts[:-1], True)]
    out, start = [], 0
    for i in sharp + [len(pts) - 1]:
        out.append((pts[start:i + 1], False))
        start = i
    return out


def _basis(ax):
    ax = v_norm(ax)
    t = v_norm(v_cross(ax, (0.0, 1.0, 0.0) if abs(ax[1]) < 0.9 else (1.0, 0.0, 0.0)))
    return t, v_cross(ax, t)


def _ring(P, slot, c, ax, R, r, n=None, sides=None):
    t, b = _basis(ax)
    n = n or P.n(16, 6)
    path = [v_add(c, v_add(v_mul(t, R * math.cos(2 * math.pi * k / n)), v_mul(b, R * math.sin(2 * math.pi * k / n))))
            for k in range(n)]
    P.sweep(slot, path, r, sides=sides or P.n(6, 3), closed=True)


def _axis_rot(d):
    """Rotation (rx, ry, 0) that turns the local +y axis onto direction d (for lathes along d)."""
    d = v_norm(d)
    return (math.degrees(math.acos(max(-1.0, min(1.0, d[1])))), math.degrees(math.atan2(d[0], d[2])), 0.0)


def _ell(P, slot, c, r, sy=1.0, n=8, rows=6, r_=(0, 0, 0), lat0=-90.0):
    """Ellipsoid (or a cap from lat0) with explicit resolution, local y scaled by sy, rotated by r_."""
    prof = [(r * math.cos(math.radians(lat0 + (90.0 - lat0) * k / rows)),
             r * sy * math.sin(math.radians(lat0 + (90.0 - lat0) * k / rows))) for k in range(rows + 1)]
    prof[-1] = (0.0, prof[-1][1])
    if lat0 <= -89.9:
        prof[0] = (0.0, prof[0][1])
    P.lathe(slot, c, prof, n=n, r=r_)


def _extrude(P, slot, pts2d, o, ex, ey, t, side_slot=None):
    """A convex plate: the 2-D outline (in the ex/ey plane through o) extruded +-t/2 along ex x ey."""
    ez = v_norm(v_cross(ex, ey))
    to3 = lambda u, v, w: v_add(o, v_add(v_mul(ex, u), v_add(v_mul(ey, v), v_mul(ez, w))))
    P.flat(slot, [to3(u, v, t / 2) for u, v in pts2d], ez)
    P.flat(slot, [to3(u, v, -t / 2) for u, v in pts2d], v_mul(ez, -1))
    cu = sum(u for u, _ in pts2d) / len(pts2d)
    cv = sum(v for _, v in pts2d) / len(pts2d)
    m = len(pts2d)
    for i in range(m):
        (ua, va), (ub, vb) = pts2d[i], pts2d[(i + 1) % m]
        q = [to3(ua, va, t / 2), to3(ub, vb, t / 2), to3(ub, vb, -t / 2), to3(ua, va, -t / 2)]
        mid = ((ua + ub) / 2 - cu, (va + vb) / 2 - cv)
        P.flat(side_slot or slot, q, v_add(v_mul(ex, mid[0]), v_mul(ey, mid[1])))


def _rrect(hw, hh, rc, n=4):
    """Rounded rectangle outline (counter-clockwise)."""
    pts = []
    for cx, cy, a0 in ((hw - rc, hh - rc, 0), (-hw + rc, hh - rc, 90), (-hw + rc, -hh + rc, 180), (hw - rc, -hh + rc, 270)):
        for k in range(n + 1):
            a = math.radians(a0 + 90.0 * k / n)
            pts.append((cx + rc * math.cos(a), cy + rc * math.sin(a)))
    return pts


def _bottle(P, c, h, r, kind, slot):
    """A bottle with a label band (the label is in the texture: v spans the profile once) and a cap."""
    if kind == 0:      # tall wine-shaped
        prof = [(0.0, 0.0), (r, 0.0), (r, 0.6 * h), (r * 0.92, 0.70 * h), (0.36 * r, 0.82 * h), (0.32 * r, 0.96 * h), (0.0, 0.965 * h)]
    elif kind == 1:    # squat flask
        prof = [(0.0, 0.0), (r * 1.1, 0.0), (r * 1.15, 0.35 * h), (r, 0.52 * h), (0.42 * r, 0.70 * h), (0.36 * r, 0.95 * h), (0.0, 0.955 * h)]
    else:              # square-shouldered spirit
        prof = [(0.0, 0.0), (r * 0.9, 0.0), (r, 0.05 * h), (r, 0.66 * h), (0.5 * r, 0.74 * h), (0.3 * r, 0.80 * h), (0.3 * r, 0.96 * h), (0.0, 0.965 * h)]
    L = sum(math.hypot(prof[k + 1][0] - prof[k][0], prof[k + 1][1] - prof[k][1]) for k in range(len(prof) - 1))
    P.lathe(slot, c, prof, n=P.n(10, 5), utiles=1, vscale=L)
    if P.lod < 2:
        P.lathe("can_brass", v_add(c, (0, 0.95 * h, 0)), [(0.0, 0.0), (0.37 * r, 0.0), (0.37 * r, 0.06 * h), (0.0, 0.065 * h)], n=P.n(8, 4))


def _mug(P, c, h=0.11, r=0.04, slot="can_metal", drink="can_drink"):
    """A metal tankard with a handle and a glowing drink."""
    n = P.n(14, 6)
    P.lathe(slot, c, [(0.0, 0.0), (r, 0.0), (r * 1.04, h * 0.1), (r * 0.98, h), (r * 0.9, h), (r * 0.86, h * 0.25), (0.0, h * 0.2)], n=n)
    P.disc(drink, v_add(c, (0, h * 0.82, 0)), 0.0, r * 0.88, n=n)
    if P.lod < 2:
        for y in (0.25, 0.75):
            _ring(P, "can_brass", v_add(c, (0, h * y, 0)), (0, 1, 0), r * 1.03, 0.003, n=n, sides=4)
        hp = [v_add(c, (r * 0.98, h * 0.78, 0)), v_add(c, (r * 1.6, h * 0.75, 0)), v_add(c, (r * 1.65, h * 0.35, 0)),
              v_add(c, (r * 1.0, h * 0.25, 0))]
        P.sweep(slot, _spline(hp, 3), 0.006, sides=5)


def _goblet(P, c, h=0.15, r=0.035, slot="can_brass", drink="can_drink2"):
    n = P.n(14, 6)
    P.lathe(slot, c, [(0.0, 0.0), (r * 0.9, 0.0), (r * 0.25, 0.012), (r * 0.18, 0.45 * h), (r * 0.9, 0.62 * h), (r * 1.05, h),
                      (r * 0.95, h), (r * 0.8, 0.66 * h), (0.0, 0.58 * h)], n=n)
    P.disc(drink, v_add(c, (0, h * 0.86, 0)), 0.0, r * 0.98, n=n)


def _tumbler(P, c, h=0.10, r=0.032, drink="can_drink"):
    """A frosted-glass tumbler (opaque glass look) with a glowing drink and a straw."""
    n = P.n(14, 6)
    P.lathe("can_frost", c, [(0.0, 0.0), (r * 0.8, 0.0), (r, h), (r * 0.92, h), (r * 0.74, 0.1 * h), (0.0, 0.08 * h)], n=n)
    P.disc(drink, v_add(c, (0, h * 0.8, 0)), 0.0, r * 0.88, n=n)
    if P.lod < 2:
        P.sweep("can_neon_m", [v_add(c, (0.005, h * 0.5, 0.004)), v_add(c, (r * 1.2, h * 1.45, r * 0.4))], 0.003, sides=4)


def _chips(P, slot, c, h, r=0.019):
    """A stack of sabacc chips (one chip = 4 mm in the texture)."""
    P.lathe(slot, c, [(0.0, 0.0), (r, 0.0), (r, h), (0.0, h)], n=P.n(12, 6), utiles=2, vscale=0.032)


# ---------------------------------------------------------------------------------------------------------------
# can_bar_counter: interact, activity "wipe"
# ---------------------------------------------------------------------------------------------------------------

BAR_SPOT = (0.0, 0.0, -0.78)            # the bartender's feet on the serving side, facing the counter (+z)


def can_bar_counter(P):
    """A curved section of the Mos Eisley bar: an adobe front with metal ribs, amber lamps and a magenta neon
    line, a brass foot rail, a worn metal top at 1.0 m with brass taps over a drip tray and a drink-mixing drum;
    on the serving side open shelves of bottles and the bartender's spot. The serving edge is 0.43 m ahead of the
    spot, the wiping zone in front of it is kept clear."""
    C = (0.0, 0.0, -1.90)
    A0, A1 = 63.0, 117.0
    R1, R2, RF, RW, RP = 1.55, 2.17, 2.08, 1.86, 1.62
    TOP0, TOP1 = 0.95, 1.00
    n = P.n(28, 10)
    pol = lambda R, a, y: (C[0] + R * math.cos(math.radians(a)), y, C[2] + R * math.sin(math.radians(a)))
    # adobe front wall (outer face, its top, the inner face toward the shelves), a moulded band, the kick plate
    P.lathe("can_adobe", C, [(RF, 0.12), (RF, TOP0), (RW, TOP0), (RW, 0.25)], a0=A0, a1=A1, n=n)
    P.lathe("can_adobe", C, [(RF, 0.125), (RF + 0.028, 0.15), (RF + 0.03, 0.19), (RF, 0.225)], a0=A0, a1=A1, n=n)
    P.lathe("can_panel", C, [(RF + 0.012, 0.0), (RF + 0.012, 0.12), (RF, 0.135)], a0=A0, a1=A1, n=n)
    # serving side: plinth with a kick plate, the mid shelf
    P.lathe("can_adobe", C, [(RW, 0.25), (RP, 0.25), (RP, 0.0)], a0=A0, a1=A1, n=n)
    P.lathe("can_panel", C, [(RP - 0.006, 0.11), (RP - 0.006, 0.0)], a0=A0, a1=A1, n=n)
    P.lathe("can_metal", C, [(RW, 0.60), (RP + 0.02, 0.60), (RP + 0.02, 0.575), (RW, 0.575)], a0=A0, a1=A1, n=n)
    # dividers between the shelf bays
    for k in (1, 2, 3):
        a = A0 + (A1 - A0) * k / 4
        c = pol((RP + RW) / 2, a, 0.60)
        P.box("can_panel", c, (0.012, 0.35, (RW - RP) / 2), r=(0, 90 - a, 0))
    # end caps of the wall / plinth / shelf sections (under the piers), then the piers themselves
    for a, sg in ((A0, -1), (A1, 1)):
        ar = math.radians(a)
        want = (sg * -math.sin(ar), 0.0, sg * math.cos(ar))
        sect = lambda pts: [pol(r, a, y) for r, y in pts]
        P.flat("can_adobe", sect([(RP, 0.0), (RW, 0.0), (RW, 0.25), (RP, 0.25)]), want)
        P.flat("can_adobe", sect([(RW, 0.0), (RF + 0.012, 0.0), (RF + 0.03, 0.15), (RF + 0.03, 0.19), (RF, 0.225), (RF, TOP0),
                                  (RW, TOP0)]), want)
        P.flat("can_metal", sect([(RP + 0.02, 0.575), (RW, 0.575), (RW, 0.60), (RP + 0.02, 0.60)]), want)
    # end piers: rounded adobe pillars closing the section
    for a, sg in ((A0, 1), (A1, -1)):
        c = pol((RP + RF) / 2 + 0.01, a + sg * 1.8, TOP0 / 2)
        P.rbox("can_adobe", c, (0.07, TOP0 / 2, (RF - RP) / 2 + 0.04), 0.06, r=(0, 90 - a - sg * 1.8, 0), puff=0.01, seg=P.n(4, 2))
    # the top: worn metal slab, bullnose on the customer edge, a brass rail along the serving edge
    m = n
    for i in range(m):
        a, b = A0 + (A1 - A0) * i / m, A0 + (A1 - A0) * (i + 1) / m
        P.flat("can_metal", [pol(R1, a, TOP1), pol(R2, a, TOP1), pol(R2, b, TOP1), pol(R1, b, TOP1)], (0, 1, 0))
        P.flat("can_metal", [pol(R1, a, TOP0), pol(R2, a, TOP0), pol(R2, b, TOP0), pol(R1, b, TOP0)], (0, -1, 0))
        mid = math.radians((a + b) / 2)
        P.flat("can_metal", [pol(R1, a, TOP0), pol(R1, b, TOP0), pol(R1, b, TOP1), pol(R1, a, TOP1)],
               (-math.cos(mid), 0, -math.sin(mid)))
        # amber light strip under the customer overhang
        P.flat("can_amber", [pol(RF + 0.015, a, TOP0 - 0.002), pol(RF + 0.06, a, TOP0 - 0.002), pol(RF + 0.06, b, TOP0 - 0.002),
                             pol(RF + 0.015, b, TOP0 - 0.002)], (0, -1, 0))
    for a, sg in ((A0, -1), (A1, 1)):
        ar = math.radians(a)
        P.flat("can_metal", [pol(R1, a, TOP0), pol(R2, a, TOP0), pol(R2, a, TOP1), pol(R1, a, TOP1)],
               (sg * -math.sin(ar), 0, sg * math.cos(ar)))
    edge = [pol(R2, A0 + (A1 - A0) * k / m, (TOP0 + TOP1) / 2) for k in range(m + 1)]
    P.sweep("can_metal", edge, 0.027, sides=P.n(8, 4))
    if P.lod < 3:
        P.sweep("can_brass", [pol(R1 + 0.015, A0 + (A1 - A0) * k / m, TOP1 + 0.012) for k in range(m + 1)], 0.008, sides=P.n(6, 4))
    # facade: metal ribs with amber lamps, a magenta neon line under the overhang
    for k in range(5):
        a = A0 + 4 + (A1 - A0 - 8) * k / 4
        c = pol(RF + 0.012, a, 0.555)
        P.box("can_panel", c, (0.03, 0.33, 0.014), r=(0, 90 - a, 0))
        if P.lod < 3:
            P.box("can_metal", pol(RF + 0.028, a, 0.555), (0.012, 0.29, 0.004), r=(0, 90 - a, 0))
            lamp = pol(RF + 0.03, a, 0.84)
            _ell(P, "can_amber", lamp, 0.026, n=P.n(10, 5), rows=P.n(5, 3), r_=(90, 90 - a, 0), lat0=0.0)
            _ring(P, "can_brass", lamp, v_sub(pol(1.0, a, 0.0), pol(0.0, a, 0.0)), 0.027, 0.005, n=P.n(10, 5), sides=4)
    neon = [pol(RF + 0.035, A0 + 2 + (A1 - A0 - 4) * k / m, 0.905) for k in range(m + 1)]
    P.sweep("can_neon_m", neon, 0.010, sides=P.n(6, 4))
    # brass foot rail on brackets
    rail = [pol(2.30, A0 + 4 + (A1 - A0 - 8) * k / m, 0.17) for k in range(m + 1)]
    P.sweep("can_brass", rail, 0.022, sides=P.n(8, 4))
    for p in (rail[0], rail[-1]):
        P.sphere("can_brass", p, 0.028, n=P.n(8, 5))
    for k in range(4 if P.lod < 3 else 2):
        a = A0 + 6 + (A1 - A0 - 12) * (k / 3 if P.lod < 3 else k)
        P.sweep("can_brass", [pol(RF + 0.01, a, 0.17), pol(2.30, a, 0.17)], 0.012, sides=P.n(6, 4))
        P.lathe("can_brass", pol(RF + 0.012, a, 0.17), [(0.0, -0.01), (0.03, -0.008), (0.03, 0.008), (0.0, 0.01)],
                r=(90, 90 - a, 0), n=P.n(10, 5))
    # brass taps over a drip tray (left of the wiping zone)
    ta0, ta1, TR = 103.0, 113.0, 1.70
    P.box("can_panel", pol(TR, (ta0 + ta1) / 2, TOP1 + 0.008), (0.065, 0.008, 0.16), r=(0, 90 - (ta0 + ta1) / 2, 0))
    pipe = [pol(TR + 0.02, ta0 + (ta1 - ta0) * k / 6, 1.20) for k in range(7)]
    P.sweep("can_brass", pipe, 0.018, sides=P.n(8, 4))
    for p in (pipe[0], pipe[-1]):
        P.sweep("can_brass", [v_add(p, (0, -0.20, 0)), p], 0.016, sides=P.n(8, 4))
        P.sphere("can_brass", v_add(p, (0, 0.01, 0)), 0.024, n=P.n(8, 5))
        P.lathe("can_brass", v_add(p, (0, -0.20, 0)), [(0.0, 0.0), (0.035, 0.0), (0.03, 0.012), (0.016, 0.02), (0.0, 0.02)], n=P.n(10, 5))
    for k in range(4 if P.lod < 3 else 0):
        a = ta0 + (ta1 - ta0) * (k + 0.5) / 4
        base = pol(TR + 0.02, a, 1.20)
        inward = v_norm(v_sub(pol(0.0, a, 0.0), pol(1.0, a, 0.0)))
        spout = v_add(base, v_add(v_mul(inward, 0.06), (0, -0.05, 0)))
        P.sweep("can_brass", [base, v_add(base, v_mul(inward, 0.05)), spout], 0.010, sides=P.n(6, 4))
        P.cone("can_brass", spout, v_add(spout, (0, -0.03, 0)), 0.012, n=P.n(6, 4))
        hdl = v_add(base, (0, 0.13, 0))
        P.sweep("can_black", [v_add(base, (0, 0.015, 0)), v_add(hdl, v_mul(inward, 0.02))], 0.010 + 0.002 * (k % 2), sides=P.n(6, 4))
        P.sphere("can_brass" if k % 2 else "can_neon_c", v_add(hdl, v_mul(inward, 0.022)), 0.016, n=P.n(8, 5))
    # drink-mixing drum at the right end: banded metal drum, a gauge, hoses into the serving side
    dc = pol(1.86, 69.0, TOP1)
    P.lathe("can_panel", dc, [(0.0, 0.0), (0.15, 0.0), (0.16, 0.03), (0.16, 0.27), (0.13, 0.31), (0.05, 0.33), (0.0, 0.33)], n=P.n(18, 8))
    for y in ((0.05, 0.25) if P.lod < 3 else ()):
        _ring(P, "can_brass", v_add(dc, (0, y, 0)), (0, 1, 0), 0.162, 0.008, n=P.n(18, 8), sides=P.n(5, 3))
    P.lathe("can_brass", v_add(dc, (0, 0.33, 0)), [(0.0, 0.0), (0.04, 0.0), (0.035, 0.05), (0.02, 0.06), (0.0, 0.06)], n=P.n(10, 5))
    to_spot = v_norm(v_sub((0.0, 0.0, -0.78), dc))
    gc = v_add(v_add(dc, (0, 0.16, 0)), v_mul((to_spot[0], 0, to_spot[2]), 0.162))
    P.lathe("can_brass", gc, [(0.0, -0.01), (0.05, -0.008), (0.052, 0.01), (0.0, 0.012)], r=_axis_rot((to_spot[0], 0, to_spot[2])), n=P.n(14, 6))
    P.disc("can_screen", v_add(gc, v_mul((to_spot[0], 0, to_spot[2]), 0.013)), 0.0, 0.042, fit=True, n=P.n(14, 6),
           r=_axis_rot((to_spot[0], 0, to_spot[2])))
    if P.lod < 3:
        for k, dy in enumerate((0.08, 0.20)):
            a = 72.0 + 6 * k
            h0 = v_add(dc, (0.0, dy, 0.0))
            h0 = v_add(h0, v_mul((to_spot[0], 0, to_spot[2]), 0.15))
            path = _spline([h0, v_add(pol(1.70, a, TOP1 + 0.06), (0, 0, 0)), pol(1.52, a + 2, TOP1 - 0.04), pol(1.60, a + 3, 0.70)], 4)
            P.sweep("can_black", path, 0.012, sides=P.n(6, 4))
    # on the top: a bar rag at the wiping zone, bottles at the drum, drinks on the customer side
    P.rbox("can_cloth", pol(1.63, 84.0, TOP1 + 0.012), (0.09, 0.010, 0.06), 0.008, r=(0, 90 - 84 + 18, 0), puff=0.004, seg=P.n(3, 2))
    for k, (a, kind, slot) in enumerate(((75.5, 0, "can_bottle_g"), (78.0, 2, "can_bottle_a"))):
        _bottle(P, pol(1.70, a, TOP1), 0.30 if kind == 0 else 0.26, 0.036, kind, slot)
    if P.lod < 3:
        _mug(P, pol(2.02, 81.0, TOP1))
        _goblet(P, pol(2.00, 95.0, TOP1))
        _tumbler(P, pol(2.03, 100.0, TOP1))
    # shelves of bottles on the serving side
    if P.lod < 3:
        kinds = (0, 1, 2, 0, 2, 1)
        slots = ("can_bottle_g", "can_bottle_a", "can_bottle_g", "can_bottle_r", "can_bottle_a", "can_bottle_r")
        step = 3.8 if P.lod < 2 else 7.6
        for y, base_r in ((0.25, 1.74), (0.60, 1.74)):
            a = A0 + 3.0
            k = 0
            while a < A1 - 2.5:
                near_div = any(abs(a - (A0 + (A1 - A0) * d / 4)) < 1.8 for d in (1, 2, 3))
                if not near_div:
                    kind = kinds[k % 6]
                    hgt = (0.27, 0.20, 0.24)[kind] * (0.95 if y > 0.5 else 1.0)
                    _bottle(P, pol(base_r + 0.04 * ((k * 7) % 3 - 1) * 0.5, a, y), hgt, 0.032, kind, slots[(k * 5) % 6])
                    k += 1
                a += step
    station_hardpoints(P, "wipe", BAR_SPOT, yaw=0.0)


# ---------------------------------------------------------------------------------------------------------------
# can_booth: seat
# ---------------------------------------------------------------------------------------------------------------

def can_booth(P):
    """A Mos Eisley alcove booth: a curved padded bench and channel-tufted back in an adobe niche under a half
    dome, a magenta neon line tracing the arch, an amber sconce, a round pedestal table with drinks.
    Seat 0.46 (cushion top), front edge z 0.01 -> foot 0.185; the back cushion face is 0.45 m behind it."""
    ZC = 0.55
    C = (0.0, 0.0, ZC)
    RS0, RS1 = 0.54, 0.98
    RI, RO, HW, DH = 1.10, 1.24, 1.55, 0.55
    A0, A1 = 196.0, 344.0
    n = P.n(32, 10)
    pol = lambda R, a, y: (C[0] + R * math.cos(math.radians(a)), y, C[2] + R * math.sin(math.radians(a)))
    # bench base, toe kick
    P.lathe("can_adobe", C, [(RI, 0.34), (RS0 + 0.05, 0.34), (RS0 + 0.05, 0.0)], a0=A0, a1=A1, n=n)
    P.lathe("can_panel", C, [(RS0 + 0.044, 0.085), (RS0 + 0.044, 0.0)], a0=A0, a1=A1, n=n)
    # seat cushion: rounded section lofted round the arc (puffed top)
    sec = []
    for k in range(12):
        t = 2 * math.pi * k / 12
        c_, s_ = math.cos(t), math.sin(t)
        r = (RS0 + RS1) / 2 + (RS1 - RS0) / 2 * math.copysign(abs(c_) ** 0.35, c_)
        y = 0.40 + 0.06 * math.copysign(abs(s_) ** 0.35, s_)
        sec.append((r, y))
    rings = []
    for i in range(n + 1):
        a = A0 + (A1 - A0) * i / n
        rings.append([pol(r, a, y) for r, y in sec])
    P.loft("can_leather", rings, closed=True)
    # back cushion: a tilted rounded slab round the arc, its face at r 0.99
    secb = []
    for k in range(12):
        t = 2 * math.pi * k / 12
        c_, s_ = math.cos(t), math.sin(t)
        u = math.copysign(abs(s_) ** 0.35, s_)                    # -1 bottom .. 1 top
        w = math.copysign(abs(c_) ** 0.35, c_)                    # -1 front .. 1 back
        y = 0.75 + 0.27 * u
        r = 1.045 + 0.05 * u + 0.05 * w
        secb.append((r, y))
    rings = [[pol(r, A0 + 1 + (A1 - A0 - 2) * i / n, y) for r, y in secb] for i in range(n + 1)]
    P.loft("can_leather", rings, closed=True)
    # piping along the cushion edges
    if P.lod < 3:
        for R, y in ((RS0 + 0.012, 0.455), (RS0 + 0.012, 0.345)):
            P.sweep("can_brass", [pol(R, A0 + (A1 - A0) * k / n, y) for k in range(n + 1)], 0.006, sides=4)
    # niche wall, half dome, the arch face
    P.lathe("can_adobe", C, [(RO, 0.0), (RO, HW), (RI, HW), (RI, 0.0)], a0=180.0, a1=360.0, n=n)
    rows = P.n(10, 4)
    outer = [(RO * math.cos(math.radians(90.0 * k / rows)), HW + DH * math.sin(math.radians(90.0 * k / rows))) for k in range(rows + 1)]
    inner = [(RI * math.cos(math.radians(90.0 * k / rows)), HW + (DH - 0.10) * math.sin(math.radians(90.0 * k / rows))) for k in range(rows + 1)]
    outer[-1], inner[-1] = (0.0, outer[-1][1]), (0.0, inner[-1][1])
    P.lathe("can_adobe", C, outer, a0=180.0, a1=360.0, n=n)
    P.lathe("can_adobe", C, inner, a0=180.0, a1=360.0, n=n, inside=True)
    for sx in (-1, 1):
        P.flat("can_adobe", [(sx * RI, 0.0, ZC), (sx * RO, 0.0, ZC), (sx * RO, HW, ZC), (sx * RI, HW, ZC)], (0, 0, 1))
        for k in range(rows):
            q = [(sx * inner[k][0], inner[k][1], ZC), (sx * outer[k][0], outer[k][1], ZC), (sx * outer[k + 1][0], outer[k + 1][1], ZC),
                 (sx * inner[k + 1][0], inner[k + 1][1], ZC)]
            P.flat("can_adobe", q, (0, 0, 1))
    # outside: a darker base band, a conduit over the dome on brackets, a vent grille
    P.lathe("can_panel", C, [(RO + 0.012, 0.0), (RO + 0.012, 0.10), (RO, 0.11)], a0=180.0, a1=360.0, n=n)
    if P.lod < 3:
        cond = [pol(RO + 0.035, 250.0, 0.10), pol(RO + 0.035, 250.0, HW)]
        for k in range(1, rows + 1):
            phi = math.radians(90.0 * k / rows)
            rr = RO * math.cos(phi) + 0.035 * math.cos(phi)
            cond.append(pol(rr, 250.0, HW + (DH + 0.035) * math.sin(phi)))
        P.sweep("can_metal", cond[:-1], 0.022, sides=P.n(8, 4))
        for k in range(0, len(cond) - 1, 3):
            _ring(P, "can_panel", cond[k], v_sub(cond[min(k + 1, len(cond) - 1)], cond[k]), 0.024, 0.008, n=P.n(10, 5), sides=4)
        vc = pol(RO + 0.004, 300.0, 0.60)
        P.box("can_panel", vc, (0.16, 0.12, 0.012), r=(0, 90 - 300.0, 0))
        P.decal("can_grille", pol(RO + 0.017, 300.0, 0.60), 0.28, 0.20, v_sub(pol(1.0, 300.0, 0.0), pol(0.0, 300.0, 0.0)))
    # bench ends: low adobe arm walls
    for a, sg in ((A0, -1), (A1, 1)):
        c = pol((RS0 + RI) / 2 + 0.02, a + sg * 2.5, 0.31)
        P.rbox("can_adobe", c, (0.05, 0.31, (RI - RS0) / 2 + 0.02), 0.04, r=(0, 90 - a - sg * 2.5, 0), seg=P.n(4, 2))
    # a metal band round the inner wall, an amber sconce at the back, the neon arch
    P.lathe("can_panel", C, [(RI - 0.006, 1.17), (RI - 0.006, 1.13)], a0=184.0, a1=356.0, n=n)
    sc = pol(RI - 0.01, 270.0, 1.36)
    _ell(P, "can_amber", sc, 0.07, sy=0.6, n=P.n(14, 6), rows=P.n(6, 3), r_=(90, 0, 0), lat0=0.0)
    _ring(P, "can_brass", sc, (0, 0, 1), 0.072, 0.008, n=P.n(14, 6), sides=P.n(5, 3))
    if P.lod < 2:
        for k in range(3):
            P.sweep("can_brass", [v_add(sc, (-0.07 + 0.07 * k, -0.05 + 0.05 * abs(k - 1), 0.0)),
                                  v_add(sc, (-0.05 + 0.05 * k, -0.02 + 0.06 * abs(k - 1) * 0, 0.045))], 0.004, sides=4)
    rm, dm = (RI + RO) / 2, DH - 0.05
    arch = [(-rm, 0.95, ZC + 0.03), (-rm, HW, ZC + 0.03)]
    for k in range(1, 2 * rows):
        phi = math.radians(180.0 - 180.0 * k / (2 * rows))
        arch.append((rm * math.cos(phi), HW + dm * math.sin(phi), ZC + 0.03))
    arch += [(rm, HW, ZC + 0.03), (rm, 0.95, ZC + 0.03)]
    arch = _chaikin(arch, 1 if P.lod < 2 else 0)
    P.sweep("can_neon_m", arch, 0.012, sides=P.n(6, 4))
    for sx in (-1, 1):
        P.lathe("can_metal", (sx * rm, 0.95, ZC + 0.03), [(0.0, -0.04), (0.016, -0.04), (0.016, 0.0), (0.0, 0.0)], n=P.n(8, 4))
    # the table: pedestal, metal top with a brass rim, drinks and a little lamp
    tc = (0.0, 0.0, ZC)
    P.lathe("can_metal", tc, [(0.0, 0.0), (0.20, 0.0), (0.20, 0.02), (0.13, 0.05), (0.05, 0.08), (0.0, 0.08)], n=P.n(18, 8))
    P.sweep("can_metal", [(0, 0.07, ZC), (0, 0.69, ZC)], 0.04, sides=P.n(10, 5))
    P.lathe("can_metal", tc, [(0.0, 0.67), (0.08, 0.675), (0.31, 0.695), (0.34, 0.70), (0.345, 0.72), (0.0, 0.722)], n=P.n(24, 8))
    P.lathe("can_brass", tc, [(0.338, 0.698), (0.35, 0.704), (0.35, 0.718), (0.338, 0.724)], n=P.n(24, 8))
    _mug(P, (0.12, 0.722, ZC - 0.08))
    _tumbler(P, (-0.13, 0.722, ZC - 0.05), drink="can_drink2")
    lc = (0.02, 0.722, ZC + 0.12)
    P.lathe("can_brass", lc, [(0.0, 0.0), (0.04, 0.0), (0.035, 0.015), (0.015, 0.025), (0.0, 0.025)], n=P.n(10, 5))
    _ell(P, "can_amber", v_add(lc, (0, 0.065, 0)), 0.03, sy=1.4, n=P.n(10, 5), rows=P.n(6, 3))
    P.lathe("can_brass", v_add(lc, (0, 0.1, 0)), [(0.0, 0.0), (0.028, 0.0), (0.012, 0.014), (0.0, 0.016)], n=P.n(10, 5))
    if P.lod < 3:
        for k, (dx, dz, h) in enumerate(((-0.05, 0.10, 0.016), (-0.02, 0.13, 0.024), (0.10, 0.08, 0.012))):
            _chips(P, "can_chip_r" if k % 2 == 0 else "can_chip_b", (dx, 0.722, ZC + dz), h)
    seat_hardpoint(P, ZC - RS0)


# ---------------------------------------------------------------------------------------------------------------
# can_neon_sign: lamp
# ---------------------------------------------------------------------------------------------------------------

def _glyphs():
    """The sign's neon design in sign space (u right, v up, metres): [(slot, points, closed)]."""
    out = []
    out.append(("can_neon_c", [(x, y) for x, y in _rrect(0.50, 0.225, 0.08, 3)], True))      # border
    # cocktail glass with an olive on a pick
    out.append(("can_neon_c", [(-0.43, 0.13), (-0.19, 0.13), (-0.31, -0.01)], True))
    out.append(("can_neon_c", [(-0.31, -0.01), (-0.31, -0.12)], False))
    out.append(("can_neon_c", [(-0.37, -0.135), (-0.25, -0.135)], False))
    out.append(("can_neon_m", [(-0.27 + 0.024 * math.cos(2 * math.pi * k / 10), 0.075 + 0.024 * math.sin(2 * math.pi * k / 10))
                               for k in range(10)], True))
    out.append(("can_neon_m", [(-0.355, 0.175), (-0.285, 0.088)], False))
    # five Aurebesh-like glyphs
    x0, w, h, yc, gap = -0.115, 0.082, 0.17, 0.035, 0.12
    G = [
        [[(0, 1), (1, 1), (1, -1), (0, -1)], [(0.5, 1), (0.5, 0.1)]],                       # cresh
        [[(0, -1), (0, 1), (1, 1)], [(0, 0), (0.8, 0)]],                                     # aurek
        [[(0, 1), (1, 1), (0, -1), (1, -1)]],                                                # isk
        [[(0.5 + 0.5 * math.cos(math.radians(a)), 0.25 + 0.6 * math.sin(math.radians(a))) for a in range(90, 450, 40)], [(0.5, -1), (0.5, 0.0)]],  # senth
        [[(0, 1), (0.5, -1), (1, 1)], [(0.2, 0.2), (0.8, 0.2)]],                             # trill
    ]
    for i, strokes in enumerate(G):
        gx = x0 + i * gap
        for st in strokes:
            out.append(("can_neon_m", [(gx + u * w, yc + v * h / 2) for u, v in st], False))
    # underline swoosh
    out.append(("can_neon_c", [(-0.12 + 0.56 * k / 8, -0.14 + 0.03 * math.sin(math.pi * k / 8) - 0.01 * k / 8) for k in range(9)], False))
    return out


def can_neon_sign(P):
    """A freestanding double-sided neon sign: a gloss-black plate in a metal rim on a yoke, a cyan cocktail glass
    with a magenta olive and five magenta Aurebesh glyphs inside a cyan border, a transformer box on the pole,
    a weighted base. Lights: magenta (light) at the glyphs, cyan (light1) at the glass."""
    SY, HW, HH, T = 1.72, 0.56, 0.285, 0.05
    # base, pole, transformer box, cable
    P.lathe("can_metal", (0, 0, 0), [(0.0, 0.0), (0.30, 0.0), (0.30, 0.035), (0.26, 0.07), (0.10, 0.09), (0.0, 0.09)], n=P.n(24, 8))
    P.lathe("can_amber", (0, 0, 0), [(0.302, 0.008), (0.302, 0.026)], n=P.n(24, 8))
    P.sweep("can_chrome", [(0, 0.08, 0), (0, 1.36, 0)], 0.026, sides=P.n(10, 5))
    for y in (0.10, 1.30):
        _ring(P, "can_metal", (0, y, 0), (0, 1, 0), 0.03, 0.01, n=P.n(12, 6), sides=P.n(5, 3))
    P.rbox("can_panel", (0, 0.42, -0.06), (0.075, 0.11, 0.045), 0.012, seg=P.n(3, 2))
    P.box("can_black", (0, 0.42, -0.0125), (0.05, 0.085, 0.004), bottom=False, top=False)
    P.sphere("can_amber", (0.04, 0.50, -0.012), 0.009, n=P.n(8, 4))
    if P.lod < 3:
        cab = _spline([(0.03, 0.47, -0.10), (0.04, 0.70, -0.04), (0.035, 1.20, -0.032), (0.05, 1.40, -0.03), (0.14, 1.44, -0.03)], 3)
        P.sweep("can_black", cab, 0.008, sides=4)
    # yoke: crossbar and two uprights to pivot hubs at the plate's sides
    YB = 1.36
    P.sweep("can_metal", [(-HW - 0.05, YB, 0.0), (HW + 0.05, YB, 0.0)], 0.022, sides=P.n(8, 4))
    P.lathe("can_metal", (0, YB - 0.04, 0), [(0.0, 0.0), (0.05, 0.0), (0.05, 0.08), (0.0, 0.08)], n=P.n(10, 5))
    for sx in (-1, 1):
        P.sweep("can_metal", [(sx * (HW + 0.05), YB, 0.0), (sx * (HW + 0.05), SY, 0.0)], 0.02, sides=P.n(8, 4))
        P.sphere("can_metal", (sx * (HW + 0.05), YB, 0.0), 0.026, n=P.n(8, 5))
        P.lathe("can_brass", (sx * (HW + 0.05), SY, 0.0), [(0.0, -0.03), (0.04, -0.03), (0.045, 0.03), (0.0, 0.032)], r=(0, 0, -90 * sx),
                n=P.n(12, 6))
    # the plate in a metal rim
    outline = _rrect(HW, HH, 0.10, P.n(5, 2))
    _extrude(P, "can_black", outline, (0, SY, 0), (1, 0, 0), (0, 1, 0), T)
    P.sweep("can_metal", [(u * 1.0, SY + v, 0.0) for u, v in outline], 0.03, sides=P.n(8, 4), closed=True)
    # neon on both faces (the back mirrored so it reads), standoffs and electrode caps
    it = 2 if P.lod < 1 else 1 if P.lod < 2 else 0
    for face in (1, -1):
        zf = face * (T / 2 + 0.035)
        for slot, pts, closed in _glyphs():
            q = _chaikin(pts, it, closed) if len(pts) > 2 else pts
            for run, cl in _runs(q, closed):
                p3 = [(face * u, SY + v, zf) for u, v in run]
                P.sweep(slot, p3, 0.012, sides=P.n(6, 4), closed=cl)
            if P.lod < 2:
                p3 = [(face * u, SY + v, zf) for u, v in q]
                if not closed:
                    for e in (p3[0], p3[-1]):
                        P.sweep("can_metal", [(e[0], e[1], face * T / 2), (e[0], e[1], zf)], 0.012, sides=P.n(6, 4))
                else:
                    e = p3[len(p3) // 3]
                    P.sweep("can_metal", [(e[0], e[1], face * T / 2), (e[0], e[1], zf)], 0.006, sides=4)
    light_hardpoint(P, (0.12, SY + 0.03, 0.0), "light")
    light_hardpoint(P, (-0.31, SY + 0.03, 0.0), "light1")


# ---------------------------------------------------------------------------------------------------------------
# can_dejarik_table: table
# ---------------------------------------------------------------------------------------------------------------

def _holo_part(P, core, shell, fn):
    """Build a hologram part twice: an opaque emissive core and a slightly larger translucent glowing shell."""
    fn(core, 0.9)
    if P.lod < 3:
        fn(shell, 1.0)


def _creature(P, kind, team):
    """A holochess monster in local space (feet on y 0, facing +z, ~0.10-0.17 m tall)."""
    core, shell = ("can_holo_core_a", "can_holo_a") if team == 0 else ("can_holo_core_b", "can_holo_b")
    lo = P.lod >= 2
    nn, rr = P.n(10, 5), P.n(6, 3)
    E = lambda c, r, sy=1.0, r_=(0, 0, 0): _holo_part(P, core, shell, lambda s, k: _ell(P, s, c, r * k, sy, nn, rr, r_))
    S = lambda pts, r: _holo_part(P, core, shell, lambda s, k: P.sweep(s, pts, r * k, sides=P.n(6, 4)))
    Cn = lambda a, b, r: _holo_part(P, core, shell, lambda s, k: P.cone(s, a, v_add(a, v_mul(v_sub(b, a), 0.8 + 0.2 * k)), r * k, n=P.n(6, 4)))
    if kind == "strider":                       # Kintan strider: tall, heavy chest, little head, clawed arms
        for sx in (-1, 1):
            S([(sx * 0.022, 0.075, 0.0), (sx * 0.03, 0.035, 0.012), (sx * 0.03, 0.006, 0.0)], 0.012)
            if not lo:
                S([(sx * 0.045, 0.14, 0.0), (sx * 0.06, 0.10, 0.025), (sx * 0.055, 0.075, 0.045)], 0.009)
                Cn((sx * 0.055, 0.075, 0.045), (sx * 0.055, 0.06, 0.07), 0.008)
        E((0.0, 0.115, 0.0), 0.048, 1.25, (12, 0, 0))
        E((0.0, 0.172, 0.025), 0.022)
    elif kind == "savrip":                      # Mantellian savrip: hunched, knuckle-walking long arms
        E((0.0, 0.085, 0.0), 0.042, 0.95, (35, 0, 0))
        E((0.0, 0.112, 0.048), 0.024, 0.8)
        for sx in (-1, 1):
            S([(sx * 0.035, 0.105, 0.02), (sx * 0.06, 0.07, 0.05), (sx * 0.05, 0.008, 0.075)], 0.010)
            S([(sx * 0.02, 0.05, -0.02), (sx * 0.026, 0.006, -0.012)], 0.010)
        if not lo:
            Cn((0.0, 0.105, 0.065), (0.0, 0.10, 0.09), 0.012)
    elif kind == "houjix":                      # Houjix: stocky quadruped with a big horned head
        E((0.0, 0.06, -0.005), 0.05, 1.4, (90, 0, 0))
        E((0.0, 0.08, 0.065), 0.034)
        for sx in (-1, 1):
            for sz in (-1, 1):
                S([(sx * 0.03, 0.05, sz * 0.035), (sx * 0.034, 0.006, sz * 0.04)], 0.011)
            if not lo:
                Cn((sx * 0.02, 0.105, 0.07), (sx * 0.05, 0.14, 0.06), 0.009)
    elif kind == "ghhhk":                       # Ghhhk: round body bristling with spines
        E((0.0, 0.055, 0.0), 0.048)
        E((0.0, 0.07, 0.045), 0.02)
        for k in range(9 if not lo else 4):
            a = math.radians(40 * k)
            b = (0.035 * math.cos(a), 0.085, 0.035 * math.sin(a) - 0.01)
            Cn(b, v_add(b, (0.04 * math.cos(a), 0.05, 0.04 * math.sin(a) - 0.01)), 0.008)
        for sx in (-1, 1):
            S([(sx * 0.03, 0.03, 0.0), (sx * 0.04, 0.005, 0.0)], 0.009)
    elif kind == "monnok":                      # Monnok: squat, wide frog-like body, huge maw
        E((0.0, 0.05, 0.0), 0.055, 0.6)
        E((0.0, 0.065, 0.045), 0.032, 0.55)
        for sx in (-1, 1):
            S([(sx * 0.045, 0.04, 0.02), (sx * 0.07, 0.025, 0.04), (sx * 0.06, 0.005, 0.055)], 0.010)
            S([(sx * 0.04, 0.035, -0.03), (sx * 0.07, 0.03, -0.04), (sx * 0.06, 0.005, -0.03)], 0.012)
            if not lo:
                E((sx * 0.02, 0.098, 0.04), 0.012)
    else:                                       # Ng'ok: long-necked strider with a beak
        E((0.0, 0.09, -0.01), 0.035, 1.3, (70, 0, 0))
        S([(0.0, 0.10, 0.02), (0.0, 0.14, 0.035), (0.0, 0.165, 0.03)], 0.009)
        E((0.0, 0.17, 0.035), 0.016)
        Cn((0.0, 0.17, 0.045), (0.0, 0.165, 0.08), 0.008)
        for sx in (-1, 1):
            S([(sx * 0.018, 0.075, -0.01), (sx * 0.025, 0.04, 0.012), (sx * 0.025, 0.006, 0.0)], 0.007)


def can_dejarik_table(P):
    """Holochess table: a flared drum on a lit plinth, the checker-ring board in a raised rim, holo emitters, a
    control panel, and six holographic monsters (two teams, orange and green) standing on the outer ring."""
    n = P.n(32, 10)
    P.lathe("can_panel", (0, 0, 0), [(0.0, 0.0), (0.40, 0.0), (0.40, 0.05), (0.36, 0.07), (0.0, 0.07)], n=n)
    P.lathe("can_amber", (0, 0, 0), [(0.402, 0.012), (0.402, 0.035)], n=n)
    P.lathe("can_panel", (0, 0, 0), [(0.22, 0.07), (0.22, 0.42)], n=n)
    P.lathe("can_metal", (0, 0, 0), [(0.22, 0.42), (0.40, 0.55), (0.52, 0.62), (0.56, 0.645), (0.56, 0.69),
                                     (0.535, 0.706), (0.47, 0.706), (0.466, 0.698)], n=n)
    P.disc("can_dejarik", (0, 0.698, 0), 0.0, 0.466, fit=True, n=n)
    P.lathe("can_neon_c", (0, 0, 0), [(0.562, 0.655), (0.562, 0.675)], n=n)
    for k in range(8):
        a = 2 * math.pi * (k + 0.5) / 8
        P.box("can_metal", (0.226 * math.cos(a), 0.25, 0.226 * math.sin(a)), (0.012, 0.17, 0.03), r=(0, -math.degrees(a) + 90, 0))
    # holo emitters on the rim
    for k in range(6):
        a = math.radians(30 + 60 * k)
        c = (0.50 * math.cos(a), 0.706, 0.50 * math.sin(a))
        _ell(P, "can_chrome", c, 0.016, n=P.n(8, 4), rows=P.n(4, 2), lat0=0.0)
        if P.lod < 2:
            P.disc("can_neon_c", v_add(c, (0, 0.0165, 0)), 0.0, 0.006, n=6)
    # control panel at the front
    pc = (0.0, 0.62, 0.575)
    P.box("can_metal", pc, (0.10, 0.03, 0.035), r=(-35, 0, 0))
    P.decal("can_screen", v_add(pc, rot((0, 0.031, 0), -35, 0, 0)), 0.14, 0.05, rot((0, 1, 0), -35, 0, 0), up=rot((0, 0, -1), -35, 0, 0))
    if P.lod < 2:
        for k in range(4):
            P.sphere("can_neon_m" if k % 2 else "can_amber", v_add(pc, rot((-0.075 + 0.05 * k, 0.03, 0.022), -35, 0, 0)), 0.006, n=5)
    # the monsters: team orange at the back, team green at the front, each on a glow disc
    kinds = [("strider", 0, 210), ("savrip", 0, 270), ("monnok", 0, 330), ("houjix", 1, 30), ("ghhhk", 1, 90), ("ngok", 1, 150)]
    for kind, team, ang in kinds:
        a = math.radians(ang)
        bx, bz = 0.37 * math.cos(a), 0.37 * math.sin(a)
        P.disc("can_holo_core_a" if team == 0 else "can_holo_core_b", (bx, 0.700, bz), 0.0, 0.06, n=P.n(12, 6))
        yaw = math.degrees(math.atan2(-bx, -bz))                     # face the centre of the board
        old = P.xform
        P.xform = lambda p, bx=bx, bz=bz, yaw=yaw: v_add(rot(v_mul(p, 1.4), 0, yaw, 0), (bx, 0.701, bz))
        _creature(P, kind, team)
        P.xform = old


# ---------------------------------------------------------------------------------------------------------------
# can_band_stand: decor
# ---------------------------------------------------------------------------------------------------------------

def _bell(P, slot_out, slot_in, c, d, r0, r1, ln, n=None):
    """A flared instrument bell from radius r0 to r1 over length ln along direction d, open at the mouth."""
    n = n or P.n(14, 6)
    prof = [(r0 + (r1 - r0) * (k / 6) ** 2.6, ln * k / 6) for k in range(7)]
    P.lathe(slot_out, c, prof, n=n, r=_axis_rot(d))
    P.lathe(slot_in, c, [(max(0.0, r - 0.003), y) for r, y in prof], n=n, r=_axis_rot(d), inside=True)
    _ring(P, slot_out, v_add(c, v_mul(v_norm(d), ln)), d, r1, 0.004, n=n, sides=4)


def can_band_stand(P):
    """A small stage riser for a Bith band: a D-shaped adobe riser with a metal deck and a cyan neon nosing;
    an ommni box on its stand with a stool behind it, a kloo horn in a tripod cradle, a three-belled fanfar on its
    stand, and two speaker cabinets at the back corners."""
    H = 0.20
    nf = P.n(24, 8)
    plan = [(0.95, -0.55)] + [(0.95 * math.cos(math.pi * k / nf), 0.55 * math.sin(math.pi * k / nf)) for k in range(nf + 1)] + [(-0.95, -0.55)]
    P.prism("can_deck", plan, 0.0, H, side_slot="can_adobe", side_vscale=0.4)
    front = [(0.955 * math.cos(math.pi * k / nf), H, 0.555 * math.sin(math.pi * k / nf)) for k in range(nf + 1)]
    P.sweep("can_metal", front, 0.014, sides=P.n(6, 4))
    P.sweep("can_neon_c", [(x * 1.012, H - 0.05, z * 1.02) for x, _, z in front[1:-1]], 0.009, sides=P.n(6, 4))
    P.box("can_adobe", (0.0, 0.05, 0.64), (0.30, 0.05, 0.10))
    P.box("can_metal", (0.0, 0.102, 0.64), (0.31, 0.004, 0.105))
    # speaker cabinets
    for sx in (-1, 1):
        c = (sx * 0.74, H + 0.30, -0.40)
        P.box("can_panel", c, (0.16, 0.30, 0.12), r=(0, -sx * 18, 0))
        P.decal("can_grille", v_add(c, rot((0, 0.02, 0.122), 0, -sx * 18, 0)), 0.26, 0.50, rot((0, 0, 1), 0, -sx * 18, 0))
        if P.lod < 3:
            P.sphere("can_amber", v_add(c, rot((0.11, 0.26, 0.122), 0, -sx * 18, 0)), 0.01, n=5)
            P.box("can_metal", v_add(c, (0, 0.305, 0)), (0.165, 0.008, 0.125), r=(0, -sx * 18, 0))
    # ommni box on an A-frame stand, a stool behind
    OX, OZ = -0.50, 0.05
    for sx in (-1, 1):
        x = OX + sx * 0.22
        P.sweep("can_chrome", [(x, H, OZ - 0.16), (x, 0.78, OZ)], 0.012, sides=P.n(6, 4))
        P.sweep("can_chrome", [(x, H, OZ + 0.16), (x, 0.78, OZ)], 0.012, sides=P.n(6, 4))
    P.sweep("can_chrome", [(OX - 0.22, 0.45, OZ), (OX + 0.22, 0.45, OZ)], 0.010, sides=P.n(6, 4))
    oc = (OX, 0.84, OZ)
    tilt = (14, 0, 0)
    P.rbox("can_black", oc, (0.29, 0.055, 0.15), 0.02, r=tilt, seg=P.n(3, 2))
    top = lambda u, w: v_add(oc, rot((u, 0.056, w), *tilt))
    up = rot((0, 1, 0), *tilt)
    P.decal("can_keys", top(0.0, -0.075), 0.52, 0.10, up, up=rot((0, 0, -1), *tilt))
    P.decal("can_screen", top(-0.15, 0.06), 0.16, 0.06, up, up=rot((0, 0, -1), *tilt))
    if P.lod < 3:
        for k in range(6):
            P.lathe("can_chrome", top(0.03 + 0.04 * k, 0.065), [(0.0, 0.0), (0.012, 0.0), (0.01, 0.014), (0.0, 0.016)], r=tilt, n=P.n(8, 4))
        P.decal("can_grille", v_add(oc, rot((0.0, 0.0, 0.152), *tilt)), 0.5, 0.09, rot((0, 0, 1), *tilt))
        P.box("can_brass", v_add(oc, rot((0.0, -0.05, 0.151), *tilt)), (0.28, 0.006, 0.003), r=tilt)
    sc = (OX, 0.0, OZ - 0.40)
    P.lathe("can_leather", (sc[0], H + 0.50, sc[2]), [(0.0, 0.0), (0.16, 0.0), (0.17, 0.03), (0.15, 0.06), (0.0, 0.065)], n=P.n(16, 6))
    P.sweep("can_chrome", [(sc[0], H, sc[2]), (sc[0], H + 0.50, sc[2])], 0.022, sides=P.n(8, 4))
    _ring(P, "can_chrome", (sc[0], H + 0.20, sc[2]), (0, 1, 0), 0.13, 0.008, n=P.n(14, 6), sides=4)
    for k in range(4):
        a = math.radians(45 + 90 * k)
        P.sweep("can_chrome", [(sc[0], H + 0.30, sc[2]), (sc[0] + 0.17 * math.cos(a), H, sc[2] + 0.17 * math.sin(a))], 0.009, sides=P.n(6, 4))
    # kloo horn: a long black body with chrome keys, a curved neck to the mouthpiece, the bell low and forward
    KX, KZ = 0.02, -0.12
    body = _spline([(KX, 1.52, KZ - 0.10), (KX, 1.44, KZ - 0.02), (KX, 1.20, KZ + 0.01), (KX, 0.80, KZ + 0.03), (KX, 0.62, KZ + 0.08)], P.n(4, 2))
    P.sweep("can_black", body, lambda t: 0.010 + 0.016 * min(1.0, t * 2.5), sides=P.n(10, 5))
    d = v_norm(v_sub(body[-1], body[-2]))
    d = v_norm(v_add(d, (0, 0.0, 0.9)))
    _bell(P, "can_black", "can_brass", body[-1], d, 0.026, 0.085, 0.16)
    P.sphere("can_chrome", body[0], 0.012, n=P.n(8, 4))
    if P.lod < 3:
        for k in range(7):
            y = 0.86 + 0.07 * k
            zc = KZ + 0.01 + 0.02 * (1.2 - y)
            _ring(P, "can_chrome", (KX, y, zc), (0, 1, -0.05), 0.027, 0.004, n=P.n(12, 5), sides=4)
            if P.lod < 2:
                P.sphere("can_chrome", (KX + 0.02, y + 0.03, zc + 0.016), 0.007, n=5)
    for k in range(3):
        a = math.radians(90 + 120 * k)
        P.sweep("can_chrome", [(KX, 0.78, KZ + 0.03), (KX + 0.26 * math.cos(a), H, KZ + 0.03 + 0.26 * math.sin(a))], 0.009, sides=P.n(6, 4))
    P.sweep("can_chrome", [(KX, H + 0.0, KZ + 0.03), (KX, 0.92, KZ + 0.03)], 0.010, sides=P.n(6, 4))
    _ring(P, "can_chrome", (KX, 0.92, KZ + 0.035), (0, 1, 0), 0.034, 0.006, n=P.n(12, 5), sides=4)
    # fanfar: a brass body with a coil, valves and three bells, on a tripod
    FX, FZ = 0.50, -0.02
    P.sweep("can_brass", [(FX, 0.70, FZ), (FX, 1.16, FZ)], 0.022, sides=P.n(10, 5))
    _ring(P, "can_brass", (FX, 0.86, FZ), (0, 1, 0), 0.085, 0.014, n=P.n(18, 8), sides=P.n(6, 4))
    _ring(P, "can_brass", (FX, 0.93, FZ), (0, 1, 0), 0.075, 0.012, n=P.n(18, 8), sides=P.n(6, 4))
    for k in range(3):
        y = 0.98 + 0.045 * k
        P.sweep("can_brass", [(FX + 0.022, y, FZ), (FX + 0.05, y, FZ)], 0.011, sides=P.n(6, 4))
        P.lathe("can_chrome", (FX + 0.05, y + 0.011, FZ), [(0.0, 0.0), (0.012, 0.0), (0.01, 0.02), (0.0, 0.022)], n=P.n(8, 4))
    for k, (ang, ln, r1, rise) in enumerate(((-35, 0.20, 0.07, 0.30), (5, 0.26, 0.09, 0.40), (40, 0.18, 0.06, 0.26))):
        a = math.radians(90 + ang)
        neck = _spline([(FX, 1.14, FZ), (FX + 0.05 * math.cos(a), 1.22 + rise * 0.3, FZ + 0.05 * math.sin(a)),
                        (FX + 0.10 * math.cos(a), 1.20 + rise * 0.55, FZ + 0.10 * math.sin(a))], P.n(4, 2))
        P.sweep("can_brass", neck, 0.016, sides=P.n(8, 4))
        dd = v_norm(v_sub(neck[-1], neck[-2]))
        _bell(P, "can_brass", "can_black", neck[-1], dd, 0.018, r1, ln * 0.6)
    P.sweep("can_brass", [(FX, 0.78, FZ), (FX - 0.06, 0.82, FZ - 0.08), (FX - 0.05, 0.98, FZ - 0.12)], 0.007, sides=P.n(5, 4))
    for k in range(3):
        a = math.radians(30 + 120 * k)
        P.sweep("can_chrome", [(FX, 0.72, FZ), (FX + 0.26 * math.cos(a), H, FZ + 0.26 * math.sin(a))], 0.009, sides=P.n(6, 4))
    P.sweep("can_chrome", [(FX, H, FZ), (FX, 0.72, FZ)], 0.010, sides=P.n(6, 4))


# ---------------------------------------------------------------------------------------------------------------
# can_sabacc_table: table
# ---------------------------------------------------------------------------------------------------------------

def can_sabacc_table(P):
    """A sabacc table: a padded rail ringed with amber lamps over a lit apron, a printed felt with six player
    stations (card slot, face-down hand, chip stacks), the dealer's shoe, and the central well holding the hand pot
    and sabacc pot round the glowing shifter."""
    n = P.n(32, 10)
    # pedestal with a brass footrest ring
    P.lathe("can_panel", (0, 0, 0), [(0.0, 0.0), (0.38, 0.0), (0.38, 0.03), (0.30, 0.06), (0.14, 0.10), (0.0, 0.10)], n=n)
    P.lathe("can_panel", (0, 0, 0), [(0.11, 0.10), (0.09, 0.18), (0.09, 0.58), (0.20, 0.66), (0.0, 0.67)], n=P.n(18, 8))
    _ring(P, "can_brass", (0, 0.22, 0), (0, 1, 0), 0.34, 0.014, n=n, sides=P.n(6, 4))
    for k in range(4):
        a = math.radians(45 + 90 * k)
        P.sweep("can_brass", [(0.09 * math.cos(a), 0.22, 0.09 * math.sin(a)), (0.34 * math.cos(a), 0.22, 0.34 * math.sin(a))], 0.01,
                sides=P.n(6, 4))
    # apron, amber light strip, felt, padded rail, lamps on the rail
    P.lathe("can_panel", (0, 0, 0), [(0.0, 0.66), (0.50, 0.68), (0.60, 0.70), (0.62, 0.73), (0.62, 0.775)], n=n)
    P.lathe("can_amber", (0, 0, 0), [(0.622, 0.712), (0.622, 0.732)], n=n)
    P.disc("can_felt", (0, 0.77, 0), 0.17, 0.545, fit=True, n=n)
    P.sweep("can_leather", [(0.585 * math.cos(2 * math.pi * k / n), 0.79, 0.585 * math.sin(2 * math.pi * k / n)) for k in range(n)],
            0.05, sides=P.n(10, 5), closed=True)
    for k in range(6):
        a = math.radians(60 * k)
        c = (0.64 * math.cos(a), 0.80, 0.64 * math.sin(a))
        P.sweep("can_brass", [(0.62 * math.cos(a), 0.80, 0.62 * math.sin(a)), c], 0.006, sides=4)
        _ell(P, "can_amber", c, 0.014, n=P.n(8, 4), rows=P.n(5, 3))
    # the dealer's well: metal bowl, brass rim, the shifter dome, the two pots
    P.lathe("can_metal", (0, 0, 0), [(0.0, 0.725), (0.14, 0.725), (0.17, 0.771)], n=n, inside=True)
    _ring(P, "can_brass", (0, 0.772, 0), (0, 1, 0), 0.172, 0.008, n=n, sides=P.n(5, 3))
    P.lathe("can_chrome", (0, 0.725, 0), [(0.0, 0.0), (0.06, 0.0), (0.055, 0.012), (0.0, 0.012)], n=P.n(14, 6))
    _ell(P, "can_neon_c", (0, 0.737, 0), 0.042, sy=0.75, n=P.n(14, 6), rows=P.n(6, 3), lat0=0.0)
    for a0, slot in ((40, "can_chip_r"), (220, "can_chip_b")):
        for k in range(3 if P.lod < 2 else 1):
            a = math.radians(a0 + 22 * (k - 1))
            _chips(P, slot if k != 1 else "can_chip_y", (0.105 * math.cos(a), 0.725, 0.105 * math.sin(a)), 0.012 + 0.008 * ((k + 1) % 3))
    # six stations: slot frame, face-down hand, chip stacks; the dealer (back) has the card shoe
    for k in range(6):
        ang = 90 + 60 * k
        a = math.radians(ang)
        ca, sa = math.cos(a), math.sin(a)
        ry = 90 - ang                                                    # local z -> radial
        sc = (0.40 * ca, 0.771, 0.40 * sa)
        P.box("can_black", sc, (0.085, 0.0015, 0.055), r=(0, ry, 0))
        if P.lod < 3:
            for (dx, dz, hx, hz) in ((0.0, 0.058, 0.09, 0.004), (0.0, -0.058, 0.09, 0.004), (0.088, 0.0, 0.004, 0.06), (-0.088, 0.0, 0.004, 0.06)):
                P.box("can_brass", v_add(sc, rot((dx, 0.002, dz), 0, ry, 0)), (hx, 0.003, hz), r=(0, ry, 0))
        if k == 3:
            sh = (0.42 * ca, 0.771, 0.42 * sa)
            P.box("can_black", v_add(sh, (0, 0.03, 0)), (0.05, 0.03, 0.07), r=(0, ry, 0))
            P.box("can_card", v_add(sh, v_add((0, 0.064, 0), rot((0, 0, -0.01), 0, ry, 0))), (0.04, 0.004, 0.058), r=(0, ry, 0), fit=True)
            P.box("can_brass", v_add(sh, v_add((0, 0.03, 0), rot((0, 0, 0.071), 0, ry, 0))), (0.045, 0.02, 0.002), r=(0, ry, 0))
            continue
        for j, off in enumerate((-0.03, 0.03)):
            cc = v_add(sc, rot((off, 0.003 + 0.0015 * j, 0.0), 0, ry, 0))
            P.box("can_card", cc, (0.027, 0.0012, 0.04), r=(0, ry + (8 if j else -8), 0), fit=True)
        if P.lod < 3:
            for j, (off, h, slot) in enumerate(((-0.10, 0.028, "can_chip_r"), (-0.055, 0.016, "can_chip_b"), (0.06, 0.020, "can_chip_y"))):
                _chips(P, slot, v_add((0.29 * ca, 0.771, 0.29 * sa), rot((off, 0.0, 0.0), 0, ry, 0)), h)


PIECES = {
    "can_bar_counter": (can_bar_counter, "interact"),
    "can_booth": (can_booth, "seat"),
    "can_neon_sign": (can_neon_sign, "lamp"),
    "can_dejarik_table": (can_dejarik_table, "table"),
    "can_band_stand": (can_band_stand, "decor"),
    "can_sabacc_table": (can_sabacc_table, "table"),
}
_NEW = ("can_adobe", "can_panel", "can_metal", "can_amber", "can_neon_m", "can_neon_c", "can_screen", "can_bottle_g",
        "can_bottle_a", "can_bottle_r", "can_drink", "can_drink2", "can_frost", "can_leather", "can_chip_r", "can_chip_b",
        "can_chip_y", "can_holo_a", "can_holo_b", "can_holo_core_a", "can_holo_core_b", "can_dejarik", "can_deck",
        "can_grille", "can_keys", "can_felt", "can_card")
SLOTS = {"can": dict({s: s for s in _NEW}, can_brass="hutt_brass", can_black="imp_black", can_chrome="imp_chrome",
                     can_cloth="reb_canvas")}
UV = {"can_adobe": 1.0, "can_panel": 0.6, "can_metal": 0.5, "can_amber": 0.5, "can_neon_m": 0.3, "can_neon_c": 0.3,
      "can_screen": 1.0, "can_bottle_g": 1.0, "can_bottle_a": 1.0, "can_bottle_r": 1.0, "can_drink": 0.15, "can_drink2": 0.15,
      "can_frost": 0.2, "can_leather": 0.5, "can_chip_r": 0.1, "can_chip_b": 0.1, "can_chip_y": 0.1, "can_holo_a": 0.12,
      "can_holo_b": 0.12, "can_holo_core_a": 0.12, "can_holo_core_b": 0.12, "can_dejarik": 1.0, "can_deck": 0.6,
      "can_grille": 1.0, "can_keys": 1.0, "can_felt": 1.0, "can_card": 1.0, "can_brass": 0.3, "can_black": 0.8,
      "can_chrome": 0.4, "can_cloth": 0.3}
SMOOTH = ("can_leather", "can_metal", "can_brass", "can_chrome", "can_bottle_g", "can_bottle_a", "can_bottle_r",
          "can_frost", "can_neon_m", "can_neon_c", "can_amber", "can_holo_a", "can_holo_b", "can_holo_core_a",
          "can_holo_core_b", "can_chip_r", "can_chip_b", "can_chip_y", "can_cloth", "can_adobe")
COLORS = {"can": (0.72, 0.6, 0.45)}
