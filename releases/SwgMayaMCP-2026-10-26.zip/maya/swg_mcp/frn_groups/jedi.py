"""Jedi Temple, Coruscant (theme jedi: warm sandstone, cream, tan, bronze, blue kyber glow):

  jedi_meditation_mat    interact  round meditation mat inside a low stone dais ring (open at the front), a kyber
                                   shrine ahead, a bronze halo frame overhead with holocrons and kyber crystals
                                   orbiting under it (station `meditate`, the mat centred on the spot)
  jedi_council_chair     seat      Jedi Council chair: curved cream shell with flared wings, tan cushions, bronze base
  jedi_temple_lantern    lamp      tall stone temple lantern: stepped plinth, column, arched chamber holding a
                                   glowing kyber core, upturned roof, bronze finial; cool blue-white light
  jedi_archive_shelf     decor     a Jedi Archives bay: rows of glowing holobook data tapes on bronze shelves, a
                                   frieze entablature, a bronze master's bust and a holocron on top
  jedi_training_remote   decor     a training remote hovering over its pedestal, a blast-shield practice helmet on a
                                   head form and a lit training lightsaber on a stand, on a stone platform
  jedi_fountain          decor     Room of a Thousand Fountains: stone basin, a bronze-bowled column, arcing jets and
                                   overflow streams, lily pads and reeds, underwater kyber lights

Maya space, metres: y up, the piece stands on the origin (lowest point y = 0), its front faces +z."""
from __future__ import annotations

import math
import random

from ..furniture import (UV as _UV, ellipse, light_hardpoint, seat_hardpoint, smoothstep, station_hardpoints, v_add,
                         v_cross, v_dot, v_len, v_mul, v_norm, v_sub, xf)

ST, FR, BR = "jedi_stone", "jedi_frieze", "jedi_bronze"


# ---------------------------------------------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------------------------------------------

def _uvs(slot):
    return _UV.get(slot.split(":")[0], 1.0)


def _frame(origin, fwd, up=(0.0, 1.0, 0.0)):
    """Point transform: local x right, y up, z = fwd, placed at origin."""
    f = v_norm(fwd)
    if abs(v_dot(f, v_norm(up))) > 0.98:
        up = (1.0, 0.0, 0.0) if abs(f[0]) < 0.9 else (0.0, 0.0, 1.0)
    r = v_norm(v_cross(up, f))
    u = v_cross(f, r)
    return lambda p: (origin[0] + p[0] * r[0] + p[1] * u[0] + p[2] * f[0],
                      origin[1] + p[0] * r[1] + p[1] * u[1] + p[2] * f[1],
                      origin[2] + p[0] * r[2] + p[1] * u[2] + p[2] * f[2])


class _Sub:
    """`with _Sub(P, fn):` everything added inside goes through fn (then through any outer transform)."""

    def __init__(self, P, fn):
        self.P, self.fn = P, fn

    def __enter__(self):
        self.old = self.P.xform
        o, fn = self.old, self.fn
        self.P.xform = (lambda p: o(fn(p))) if o else fn
        return self.P

    def __exit__(self, *exc):
        self.P.xform = self.old


def _area2(pts):
    n = len(pts)
    return sum(pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1] for i in range(n)) / 2.0


def _convex(pts):
    n = len(pts)
    s = 0
    for i in range(n):
        a, b, c = pts[i - 1], pts[i], pts[(i + 1) % n]
        cr = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
        if abs(cr) < 1e-12:
            continue
        if s == 0:
            s = 1 if cr > 0 else -1
        elif (cr > 0) != (s > 0):
            return False
    return True


def _tri2d(pts):
    """Ear-clip a simple polygon [(u, v)] -> index triangles."""
    idx = list(range(len(pts)))
    if _area2(pts) < 0:
        idx.reverse()
    cross = lambda o, a, b: (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    tris = []
    guard = 0
    while len(idx) > 3 and guard < 4 * len(pts) * len(pts):
        guard += 1
        m = len(idx)
        for k in range(m):
            i0, i1, i2 = idx[k - 1], idx[k], idx[(k + 1) % m]
            a, b, c = pts[i0], pts[i1], pts[i2]
            if cross(a, b, c) <= 1e-12:
                continue
            if any(cross(a, b, pts[j]) >= 0 and cross(b, c, pts[j]) >= 0 and cross(c, a, pts[j]) >= 0
                   for j in idx if j not in (i0, i1, i2)):
                continue
            tris.append((i0, i1, i2))
            idx.pop(k)
            break
        else:
            break
    if len(idx) == 3:
        tris.append(tuple(idx))
    return tris


def _to3(plane, u, v, w):
    if plane == "zy":
        return (w, v, u)
    if plane == "xy":
        return (u, v, w)
    return (u, w, v)


def _extrude(P, slot, pts2, w0, w1, plane="xy", side=None, caps=(True, True), side_scale=None):
    """Prism of the 2D polygon pts2 (any winding, convex or not) between w0 and w1 along the plane's normal axis."""
    n = len(pts2)
    s = 1.0 if _area2(pts2) > 0 else -1.0
    ax = _to3(plane, 0.0, 0.0, 1.0)
    acc = 0.0
    sl = side or slot
    sc = side_scale or _uvs(sl)
    for i in range(n):
        (u0, v0), (u1, v1) = pts2[i], pts2[(i + 1) % n]
        du, dv = u1 - u0, v1 - v0
        ln = math.hypot(du, dv)
        if ln < 1e-9:
            continue
        q = [_to3(plane, u0, v0, w0), _to3(plane, u1, v1, w0), _to3(plane, u1, v1, w1), _to3(plane, u0, v0, w1)]
        uv = [(acc / sc, w0 / sc), ((acc + ln) / sc, w0 / sc), ((acc + ln) / sc, w1 / sc), (acc / sc, w1 / sc)]
        P.poly(sl, q, uv, _to3(plane, dv * s, -du * s, 0.0))
        acc += ln
    tris = None if _convex(pts2) else _tri2d(pts2)
    for w, sgn, on in ((w0, -1.0, caps[0]), (w1, 1.0, caps[1])):
        if not on:
            continue
        want = v_mul(ax, sgn)
        if tris is None:
            P.flat(slot, [_to3(plane, u, v, w) for u, v in pts2], want)
        else:
            for t in tris:
                P.flat(slot, [_to3(plane, pts2[k][0], pts2[k][1], w) for k in t], want)


def _bar(P, slot, a, b, w, h=None, up=(0.0, 1.0, 0.0)):
    d = v_sub(b, a)
    if v_len(d) < 1e-6:
        return
    with _Sub(P, _frame(v_mul(v_add(a, b), 0.5), d, up)):
        P.box(slot, (0, 0, 0), (w / 2, (h or w) / 2, v_len(d) / 2))


def _arc_caps(P, slot, c, prof, a0, a1):
    """Close the two ends of a partial lathe of the closed (r, y) loop `prof` with flat caps (fan-triangulated)."""
    loop = prof[:-1] if prof[0] == prof[-1] else prof
    tris = None if _convex(loop) else _tri2d(loop)
    for a, sgn in ((a0, -1.0), (a1, 1.0)):
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        to3 = lambda r, y: (c[0] + r * ca, c[1] + y, c[2] + r * sa)
        want = (-sa * sgn, 0.0, ca * sgn)
        if tris is None:
            P.flat(slot, [to3(r, y) for r, y in loop], want)
        else:
            for t in tris:
                P.flat(slot, [to3(*loop[k]) for k in t], want)


def _square(h, c=0.0):
    """Plan square (half size h) with chamfered corners c: [(x, z)]."""
    if c <= 0:
        return [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(h, -(h - c)), (h, h - c), (h - c, h), (-(h - c), h), (-h, h - c), (-h, -(h - c)), (-(h - c), -h), (h - c, -h)]


def _kyber(P, c, h, r, tilt=(0.0, 0.0, 0.0), n=6, slot="jedi_kyber"):
    """A kyber crystal: a long hexagonal bipyramid (total height h) centred at c."""
    prof = [(0.0, -h * 0.42), (r, -h * 0.12), (r * 0.92, h * 0.18), (0.0, h * 0.58)]
    P.lathe(slot, c, prof, n=n, r=tilt, utiles=1)


def _glow(P, c, r, n=None):
    if P.lod < 2:
        P.sphere("jedi_glow", c, r, n=n or P.n(12, 6))


def _holocron(P, c, s, r=(0.0, 0.0, 0.0)):
    """Jedi holocron: a cube of glowing panels (half size s) in a bronze edge frame with corner beads."""
    with _Sub(P, lambda p: xf(p, c, r)):
        P.box("jedi_holocron", (0, 0, 0), (s * 0.94, s * 0.94, s * 0.94), fit=True)
        if P.lod < 2:
            e = s * 0.98
            for ax in range(3):
                for sa in (-1, 1):
                    for sb in (-1, 1):
                        p = [0.0, 0.0, 0.0]
                        p[(ax + 1) % 3], p[(ax + 2) % 3] = sa * e, sb * e
                        hs = [s * 0.11, s * 0.11, s * 0.11]
                        hs[ax] = s * 0.92
                        P.box(BR, tuple(p), tuple(hs))
            if P.lod < 1:
                for sx in (-1, 1):
                    for sy in (-1, 1):
                        for sz in (-1, 1):
                            P.box(BR, (sx * e, sy * e, sz * e), (s * 0.17, s * 0.17, s * 0.17))


# ---------------------------------------------------------------------------------------------------------------
# meditation mat
# ---------------------------------------------------------------------------------------------------------------

MAT_SPOT = (0.0, 0.0, 0.35)           # the meditator sits here, facing the kyber shrine (yaw 180 = toward -z)
# the whole dais is built round (0, 0, 0) and shifted by MAT_SPOT, so the piece's origin lies 0.35 m ahead of the
# meditator: a station spot on the origin itself left the player facing a random way once seated (client test)
MAT_GAP = 26.0                        # half-angle of the dais ring's opening at the front


def jedi_meditation_mat(P):
    """Meditation dais. The mat (r 0.56, top 0.024) is centred on MAT_SPOT; the ring (r 0.86-1.10, 0.14 high) opens
    at the front; the shrine stands ahead at -z; the halo frame reaches 2.15 m."""
    P.xform = lambda p: (p[0] + MAT_SPOT[0], p[1], p[2] + MAT_SPOT[2])
    n = P.n(48, 16)
    R0, R1, H = 0.86, 1.10, 0.11
    a0, a1 = 90 + MAT_GAP, 90 + 360 - MAT_GAP
    # floor mosaic inside the ring, the mat on it
    P.disc("jedi_mosaic", (0, 0.004, 0), 0.0, R0 + 0.005, n=n, fit=True)
    P.lathe(ST, (0, 0, 0), [(R0 + 0.005, 0.0), (R0 + 0.005, 0.004)], n=n)
    P.lathe("jedi_tan", (0, 0, 0), [(0.555, 0.004), (0.566, 0.012), (0.561, 0.020), (0.545, 0.024)], n=n)
    P.disc("jedi_mat", (0, 0.024, 0), 0.0, 0.546, n=n, fit=True)
    # the dais ring: carved riser, plain inner wall, an overhanging capstone with a bronze inlay band
    P.lathe(FR, (0, 0, 0), [(R1, 0.0), (R1, H)], n=n, a0=a0, a1=a1, vscale=H)
    P.lathe(ST, (0, 0, 0), [(R0, H), (R0, 0.0)], n=n, a0=a0, a1=a1)
    _arc_caps(P, ST, (0, 0, 0), [(R0, 0.0), (R1, 0.0), (R1, H), (R0, H)], a0, a1)
    cap = [(R0 - 0.02, H), (R1 + 0.025, H), (R1 + 0.025, H + 0.03), (R0 - 0.02, H + 0.03), (R0 - 0.02, H)]
    cap_a0, cap_a1 = a0 - 2.0, a1 + 2.0
    P.lathe(ST, (0, 0, 0), cap, n=n, a0=cap_a0, a1=cap_a1)
    _arc_caps(P, ST, (0, 0, 0), cap, cap_a0, cap_a1)
    m = P.n(40, 12)
    band = [((R0 + R1) / 2 * math.cos(math.radians(a0 + (a1 - a0) * k / m)), H + 0.031,
             (R0 + R1) / 2 * math.sin(math.radians(a0 + (a1 - a0) * k / m))) for k in range(m + 1)]
    P.sweep(BR, band, 0.016, profile=[(-0.3, -1.0), (0.3, -1.0), (0.3, 1.0), (-0.3, 1.0)])
    if P.lod < 2:                                                            # kyber gems set in the band
        for k in range(12):
            a = math.radians(a0 + (a1 - a0) * (k + 0.5) / 12)
            P.sphere("jedi_kyber", ((R0 + R1) / 2 * math.cos(a), H + 0.037, (R0 + R1) / 2 * math.sin(a)), 0.014, sy=0.6, n=6)
    # threshold sill across the opening
    P.lathe(ST, (0, 0, 0), [(R1, 0.0), (R1, 0.025), (R0, 0.025), (R0, 0.0)], n=P.n(8, 4), a0=a1 - 360, a1=a0)
    # guardian posts at the opening, each crowned with a kyber crystal
    for a in (a0 + 4.0, a1 - 4.0):
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        c = ((R0 + R1) / 2 * ca, 0.0, (R0 + R1) / 2 * sa)
        ry = -a + 90
        P.box(ST, (c[0], H + 0.03 + 0.26, c[2]), (0.075, 0.26, 0.075), r=(0, ry, 0))
        P.box(BR, (c[0], H + 0.03 + 0.53, c[2]), (0.088, 0.018, 0.088), r=(0, ry, 0))
        P.box(FR, (c[0], H + 0.36, c[2]), (0.077, 0.05, 0.077), r=(0, ry, 0))
        P.lathe(BR, (c[0], H + 0.03 + 0.548, c[2]), [(0.05, 0.0), (0.035, 0.03), (0.022, 0.05), (0.0, 0.05)], n=P.n(10, 5))
        _kyber(P, (c[0], H + 0.72, c[2]), 0.16, 0.034)
        _glow(P, (c[0], H + 0.72, c[2]), 0.075)
    # the kyber shrine ahead (-z): a stone altar on the ring with a bronze bowl of crystals
    sz = -(R0 + R1) / 2
    P.prism(ST, [(-0.24, sz - 0.17), (0.24, sz - 0.17), (0.24, sz + 0.17), (-0.24, sz + 0.17)], H + 0.03, H + 0.07,
            bottom=False)
    P.prism(ST, [(-0.20, sz - 0.14), (0.20, sz - 0.14), (0.20, sz + 0.14), (-0.20, sz + 0.14)], H + 0.07, 0.50,
            side_slot=FR, side_vscale=0.43 - H)
    P.prism(ST, [(-0.23, sz - 0.16), (0.23, sz - 0.16), (0.23, sz + 0.16), (-0.23, sz + 0.16)], 0.50, 0.54, bottom=True)
    P.box(BR, (0, 0.545, sz), (0.235, 0.006, 0.165))
    P.lathe(BR, (0, 0.55, sz), [(0.0, 0.0), (0.06, 0.0), (0.05, 0.03), (0.08, 0.05), (0.15, 0.10), (0.155, 0.115),
                                (0.14, 0.115), (0.07, 0.07), (0.0, 0.065)], n=P.n(20, 8))
    cl = [((0.0, 0.0), 0.26, 0.05, (0, 0, 0)), ((0.06, 0.03), 0.17, 0.032, (14, 0, -22)),
          ((-0.06, 0.02), 0.19, 0.034, (-8, 0, 24)), ((0.01, -0.06), 0.15, 0.03, (-24, 0, 6)),
          ((-0.02, 0.07), 0.13, 0.028, (26, 0, -6))]
    for (dx, dz), h, r, tl in cl:
        _kyber(P, (dx, 0.64 + h * 0.30, sz + dz), h, r, tilt=tl)
    _glow(P, (0, 0.73, sz), 0.17)
    # the overhead frame: two bronze swan-neck posts rising from the ring sides to a halo ring
    hy, hr = 2.12, 0.46
    for s in (-1, 1):
        c = (s * (R0 + R1) / 2, H + 0.03, 0.0)
        P.lathe(BR, c, [(0.075, 0.0), (0.075, 0.03), (0.05, 0.05), (0.035, 0.09), (0.0, 0.09)], n=P.n(14, 6))
        path = []
        mm = P.n(16, 6)
        for k in range(mm + 1):
            t = k / mm
            y = H + 0.10 + (hy - H - 0.10) * t
            x = hr + ((R0 + R1) / 2 - hr) * (1 - smoothstep(0.50, 1.0, t))
            path.append((s * x, y, 0.0))
        P.sweep(BR, path, lambda t: 0.034 - 0.012 * t, sides=P.n(10, 5))
        for t in (0.22, 0.42) if P.lod < 2 else ():
            y = H + 0.10 + (hy - H - 0.10) * t
            P.lathe(BR, (s * (R0 + R1) / 2, y, 0.0), [(0.020, -0.03), (0.038, -0.012), (0.038, 0.012), (0.020, 0.03)],
                    n=P.n(10, 5))
        gem = path[int(len(path) * 0.62)]
        P.sphere(BR, gem, 0.038, n=P.n(10, 5))
        P.sphere("jedi_kyber", v_add(gem, (s * 0.03, 0.0, 0.0)), 0.02, n=P.n(8, 5))
        P.sphere(BR, path[-1], 0.034, n=P.n(10, 5))
    mm = P.n(40, 12)
    P.sweep(BR, [(hr * math.cos(2 * math.pi * k / mm), hy, hr * math.sin(2 * math.pi * k / mm)) for k in range(mm)], 0.022,
            closed=True, sides=P.n(8, 4))
    P.sweep("jedi_kyber", [((hr - 0.035) * math.cos(2 * math.pi * k / mm), hy - 0.012, (hr - 0.035) * math.sin(2 * math.pi * k / mm))
                           for k in range(mm)], 0.008, closed=True, sides=P.n(6, 4))
    for k in range(4):                                                        # spokes to a central boss
        a = math.radians(45 + 90 * k)
        P.sweep(BR, [(hr * math.cos(a), hy, hr * math.sin(a)), (0.06 * math.cos(a), hy + 0.04, 0.06 * math.sin(a))], 0.009,
                sides=P.n(6, 4))
    P.sphere(BR, (0, hy + 0.04, 0), 0.05, n=P.n(12, 6))
    P.lathe(BR, (0, hy - 0.02, 0), [(0.0, 0.0), (0.03, 0.02), (0.02, 0.06), (0.0, 0.07)], n=P.n(10, 5))
    # holocrons and kyber crystals orbiting under the halo; a large holocron turning at the centre
    _holocron(P, (0, 1.80, 0), 0.06, r=(35.26, 45.0, 0.0))
    _glow(P, (0, 1.80, 0), 0.13)
    for k in range(8):
        a = math.radians(22.5 + 45 * k)
        y = 1.50 + 0.10 * math.sin(2 * a + 0.6)
        c = (0.44 * math.cos(a), y, 0.44 * math.sin(a))
        if k % 2 == 0:
            _holocron(P, c, 0.045, r=(18 + 11 * k, 37 * k, 12 - 5 * k))
        else:
            _kyber(P, c, 0.17, 0.032, tilt=(math.sin(a) * 22, 0.0, -math.cos(a) * 22))
    P.xform = None
    station_hardpoints(P, "meditate", MAT_SPOT, yaw=180.0)


# ---------------------------------------------------------------------------------------------------------------
# council chair
# ---------------------------------------------------------------------------------------------------------------

CHAIR_FRONT = 0.40                    # seat front edge (foot 0.175 m ahead)
CHAIR_CZ = 0.03                       # the shell's axis (z)
CHAIR_A0, CHAIR_SPAN = 140.0, 260.0   # shell from the front-left end round the back to the front-right end


def _chair_h(up_):
    """Shell rim height at the symmetric parameter up_ (0 = front end .. 0.5 = back centre): a level arm, then the
    wing rising, then the back."""
    return 0.68 + 0.48 * smoothstep(0.11, 0.25, up_) + 0.14 * smoothstep(0.30, 0.5, up_)


def _chair_pt(u, t, inset=0.0):
    up_ = min(u, 1.0 - u)
    a = math.radians(CHAIR_A0 + CHAIR_SPAN * u)
    rt = 0.47 + 0.10 * math.exp(-((up_ - 0.21) / 0.07) ** 2)
    rb = 0.40
    r = rb + (rt - rb) * t ** 1.6 - inset
    y = 0.33 + (_chair_h(up_) - 0.33) * t
    return (r * math.cos(a), y, CHAIR_CZ + r * math.sin(a))


def jedi_council_chair(P):
    """Jedi Council chair. Seat 0.465, front edge z 0.40 -> foot 0.575; shell wings flare to 1.14 m across."""
    cz = CHAIR_CZ
    th = 0.045
    nu, nt = P.n(40, 14), P.n(10, 4)
    # bronze lotus foot and column with a collar, cream seat drum
    P.lathe(BR, (0, 0, cz), [(0.34, 0.0), (0.34, 0.025), (0.31, 0.045), (0.20, 0.075), (0.12, 0.11), (0.085, 0.16),
                             (0.08, 0.24), (0.11, 0.27), (0.20, 0.295), (0.0, 0.30)], n=P.n(32, 10))
    P.lathe(BR, (0, 0, cz), [(0.083, 0.17), (0.10, 0.18), (0.10, 0.20), (0.082, 0.21)], n=P.n(16, 6))
    P.lathe("jedi_cream", (0, 0, cz), [(0.41, 0.295), (0.415, 0.31), (0.415, 0.395), (0.40, 0.405), (0.0, 0.405)],
            n=P.n(36, 12))
    P.lathe(BR, (0, 0, cz), [(0.41, 0.30), (0.421, 0.307), (0.421, 0.325), (0.41, 0.332)], n=P.n(36, 12))
    # the shell: outer and inner skins, rim, front ends, bottom strip
    O = [[_chair_pt(i / nu, j / nt) for j in range(nt + 1)] for i in range(nu + 1)]
    I = [[_chair_pt(i / nu, j / nt, th) for j in range(nt + 1)] for i in range(nu + 1)]
    sc = _uvs("jedi_cream")
    U = [[i / nu * 2.4 / sc] * (nt + 1) for i in range(nu + 1)]
    V = [[j / nt * 0.9 / sc for j in range(nt + 1)] for _ in range(nu + 1)]
    P.grid("jedi_cream", O, U, V, lambda q: v_sub((q[0], 0.0, q[2]), (0.0, 0.0, cz)))
    P.grid("jedi_cream", I, U, V, lambda q: v_sub((0.0, 0.0, cz), (q[0], 0.0, q[2])))
    for i in range(nu):
        P.flat("jedi_cream", [O[i][nt], O[i + 1][nt], I[i + 1][nt], I[i][nt]], (0, 1, 0))
        P.flat("jedi_cream", [O[i][0], O[i + 1][0], I[i + 1][0], I[i][0]], (0, -1, 0))
    for i, sgn in ((0, -1.0), (nu, 1.0)):
        a = math.radians(CHAIR_A0 + CHAIR_SPAN * i / nu)
        want = (-math.sin(a) * sgn, 0.0, math.cos(a) * sgn)
        for j in range(nt):
            P.flat("jedi_cream", [O[i][j], O[i][j + 1], I[i][j + 1], I[i][j]], want)
    # bronze piping along the rim and down the front ends; bronze studs along the outer foot
    rim = [v_add(v_mul(v_add(O[i][nt], I[i][nt]), 0.5), (0.0, 0.004, 0.0)) for i in range(nu + 1)]
    P.sweep(BR, rim, 0.014, sides=P.n(8, 4))
    for i in (0, nu):
        P.sweep(BR, [v_mul(v_add(O[i][j], I[i][j]), 0.5) for j in range(nt, -1, -1)], 0.012, sides=P.n(8, 4))
    if P.lod < 2:
        for k in range(15):
            u = 0.15 + 0.70 * k / 14
            P.sphere(BR, _chair_pt(u, 0.12, -0.004), 0.011, n=6)
    # seat cushion (channel-tufted top), the quilted back pad following the shell, padded arm rolls
    P.lathe("jedi_tan", (0, 0, cz), [(0.36, 0.405), (0.372, 0.425), (0.368, 0.448), (0.35, 0.462)], n=P.n(36, 12))
    P.disc("jedi_tan", (0, 0.462, cz), 0.0, 0.35, n=P.n(36, 12))
    _chair_pad(P, 0.25, 0.75, 0.10, 0.84, th, 0.07, P.n(22, 8), P.n(10, 4))
    for u0, u1 in ((0.0, 0.12), (0.88, 1.0)):
        i0, i1 = int(round(u0 * nu)), int(round(u1 * nu))
        roll = [v_add(rim[i], (0.0, 0.02, 0.0)) for i in range(i0, i1 + 1)]
        P.sweep("jedi_tan", roll, lambda t: 0.036 * (0.75 + 0.25 * math.sin(math.pi * t)), sides=P.n(10, 5))
    # the Order's medallion high on the back, inside and out
    for inset, t, out in ((th + 0.004, 0.935, (0.0, 0.22, 1.0)), (-0.004, 0.86, (0.0, -0.22, -1.0))):
        p = _chair_pt(0.5, t, inset)
        with _Sub(P, _frame(p, out)):
            P.lathe(BR, (0, 0, 0), [(0.06, -0.01), (0.06, 0.008), (0.048, 0.016), (0.0, 0.018)], r=(90, 0, 0), n=P.n(16, 6))
            if P.lod < 2:
                P.sphere("jedi_kyber", (0, 0, 0.016), 0.02, sy=0.5, r=(90, 0, 0), n=P.n(8, 5))
    seat_hardpoint(P, CHAIR_FRONT)


# ---------------------------------------------------------------------------------------------------------------
# temple lantern
# ---------------------------------------------------------------------------------------------------------------

LANTERN_CORE = (0.0, 1.35, 0.0)


def jedi_temple_lantern(P):
    """2.06 m stone lantern; the kyber core (light) at 1.35 m inside the arched chamber."""
    P.prism(ST, _square(0.28, 0.02), 0.0, 0.09, side_slot=FR, side_vscale=0.09)
    P.prism(ST, _square(0.22, 0.02), 0.09, 0.17)
    P.sweep(BR, [(x, 0.172, z) for x, z in _square(0.221, 0.02)], 0.007, closed=True, sides=4)
    P.sweep(BR, [(x, 0.092, z) for x, z in _square(0.281, 0.02)], 0.007, closed=True, sides=4)
    P.lathe(BR, (0, 0.045, 0.281), [(0.0, -0.004), (0.035, -0.004), (0.035, 0.006), (0.026, 0.012), (0.0, 0.013)],
            r=(90, 0, 0), n=P.n(14, 6))                                         # plinth medallion
    P.sphere("jedi_kyber", (0, 0.045, 0.293), 0.012, sy=0.5, r=(90, 0, 0), n=P.n(8, 5))
    n = P.n(24, 8)
    P.lathe(ST, (0, 0, 0), [(0.15, 0.17), (0.15, 0.205), (0.13, 0.23), (0.112, 0.27), (0.10, 0.60), (0.093, 0.94),
                            (0.12, 0.975), (0.12, 1.02)], n=n)
    for y in (0.45, 0.82):
        P.lathe(BR, (0, 0, 0), [(0.093, y - 0.018), (0.107, y - 0.008), (0.107, y + 0.008), (0.093, y + 0.018)], n=n)
    if P.lod < 2:                                                            # fluting ribs
        for k in range(12):
            a = 2 * math.pi * k / 12
            for y0, y1 in ((0.47, 0.80), (0.29, 0.43), (0.84, 0.93)):
                r0 = 0.10 - 0.007 * (y0 + y1) / 2
                P.box(ST, (r0 * math.cos(a), (y0 + y1) / 2, r0 * math.sin(a)), (0.007, (y1 - y0) / 2, 0.009),
                      r=(0, -math.degrees(a) + 90, 0))
    P.prism(ST, _square(0.21, 0.015), 1.02, 1.10, bottom=True, side_slot=FR, side_vscale=0.08)
    P.sweep(BR, [(x, 1.10, z) for x, z in _square(0.211, 0.015)], 0.007, closed=True, sides=4)
    # the chamber: corner posts, a slab, bronze pointed arches in the four openings
    for sx in (-1, 1):
        for sz in (-1, 1):
            P.box(ST, (sx * 0.16, 1.32, sz * 0.16), (0.032, 0.22, 0.032))
            P.box(BR, (sx * 0.16, 1.115, sz * 0.16), (0.038, 0.015, 0.038))
            P.box(BR, (sx * 0.16, 1.525, sz * 0.16), (0.038, 0.012, 0.038))
    P.prism(ST, _square(0.215, 0.015), 1.537, 1.585, bottom=True)
    for k in range(4):
        a = math.radians(90 * k)
        ca, sa = math.cos(a), math.sin(a)
        to = lambda t, y, d=0.16: (ca * d - sa * t, y, sa * d + ca * t)
        m = P.n(10, 4)
        pts = []
        for j in range(m + 1):
            t = -1 + 2 * j / m
            y = 1.41 + 0.11 * (1 - abs(t) ** 1.4)
            pts.append(to(0.128 * t, y))
        P.sweep(BR, pts, 0.009, sides=P.n(6, 4))
        if P.lod < 2:
            P.sphere("jedi_kyber", to(0.0, 1.505), 0.012, n=6)
            P.box(BR, to(0.0, 1.525), (0.008, 0.012, 0.008))
    # the kyber core: bronze cradle, crystal, glow
    P.lathe(BR, (0, 1.10, 0), [(0.07, 0.0), (0.07, 0.02), (0.035, 0.05), (0.03, 0.10), (0.05, 0.12), (0.0, 0.12)],
            n=P.n(14, 6))
    for k in range(3):
        a = math.radians(90 + 120 * k)
        P.sweep(BR, [(0.04 * math.cos(a), 1.21, 0.04 * math.sin(a)), (0.075 * math.cos(a), 1.30, 0.075 * math.sin(a)),
                     (0.05 * math.cos(a), 1.40, 0.05 * math.sin(a))], 0.007, sides=P.n(6, 4))
    _kyber(P, LANTERN_CORE, 0.30, 0.058, tilt=(0, 15, 0))
    P.sphere("jedi_glow", LANTERN_CORE, 0.125, n=P.n(14, 6))
    # upturned roof (loft through chamfered squares, the corners lifted at the eaves) and a bronze finial
    def ring(h, y, lift=0.0, cut=0.22):
        """12 points round a chamfered square: per side the two corner chamfer ends (lifted) and the middle."""
        pts = []
        for k in range(4):
            a = math.radians(-90 + 90 * k)
            nx, nz = math.cos(a), math.sin(a)
            tx, tz = -nz, nx
            for t, up in ((-(h - h * cut), lift), (0.0, 0.0), (h - h * cut, lift)):
                pts.append((nx * h + tx * t, y + up, nz * h + tz * t))
        return pts
    rings = [ring(0.31, 1.585), ring(0.315, 1.605, 0.045), ring(0.25, 1.655, 0.018), ring(0.17, 1.70),
             ring(0.11, 1.76), ring(0.075, 1.80)]
    P.loft(ST, rings, closed=True, caps=(True, True), vscale=0.5)
    P.sweep(BR, rings[1] + [rings[1][0]], 0.006, sides=4)
    P.lathe(BR, (0, 1.80, 0), [(0.06, 0.0), (0.045, 0.025), (0.055, 0.06), (0.04, 0.10), (0.016, 0.13), (0.014, 0.19),
                               (0.0, 0.195)], n=P.n(14, 6))
    _kyber(P, (0, 2.03, 0), 0.07, 0.018)
    if P.lod < 2:
        for k in range(4):                                                  # bronze bells on the eave corners
            a = math.radians(45 + 90 * k)
            c = (0.30 * math.cos(a) * 1.414 * 0.92, 1.58, 0.30 * math.sin(a) * 1.414 * 0.92)
            P.lathe(BR, v_add(c, (0, -0.07, 0)), [(0.0, 0.0), (0.025, 0.0), (0.02, 0.04), (0.008, 0.06), (0.0, 0.065)],
                    n=P.n(8, 5))
            P.sweep(BR, [v_add(c, (0, -0.005, 0)), v_add(c, (0, -0.012, 0))], 0.003, sides=4)
    light_hardpoint(P, LANTERN_CORE)


# ---------------------------------------------------------------------------------------------------------------
# archive shelf
# ---------------------------------------------------------------------------------------------------------------

def _bust(P, c):
    """Bronze bust of a hooded, bearded Jedi Master on a stone block (c = the block's foot)."""
    x0, y0, z0 = c
    P.prism(ST, [(x0 - 0.11, z0 - 0.10), (x0 + 0.11, z0 - 0.10), (x0 + 0.11, z0 + 0.10), (x0 - 0.11, z0 + 0.10)], y0, y0 + 0.13,
            side_slot=FR, side_vscale=0.13)
    yb = y0 + 0.13
    P.lathe(BR, (x0, yb, z0), [(0.085, 0.0), (0.085, 0.014), (0.062, 0.028), (0.056, 0.045), (0.0, 0.045)], n=P.n(16, 6))
    # robed shoulders and chest, the robe's crossed lapels
    P.rbox(BR, (x0, yb + 0.125, z0), (0.155, 0.08, 0.075), 0.065)
    for s in (-1, 1):
        P.sweep(BR, [(x0 + s * 0.075, yb + 0.20, z0 + 0.03), (x0 + s * 0.035, yb + 0.15, z0 + 0.072),
                     (x0 + s * 0.006, yb + 0.07, z0 + 0.078)], 0.011, sides=P.n(6, 4))
    P.sweep(BR, [(x0, yb + 0.185, z0), (x0, yb + 0.25, z0 + 0.005)], 0.034, sides=P.n(10, 5))
    hc = (x0, yb + 0.305, z0 + 0.01)
    P.sphere(BR, hc, 0.068, sy=1.15, n=P.n(14, 6))
    # hood: a closed thick shell over the back and sides of the head, open at the face
    outer = [(0.090 * math.cos(math.radians(la)), 0.090 * 1.12 * math.sin(math.radians(la))) for la in range(-56, 91, 14)]
    inner = [(0.076 * math.cos(math.radians(la)), 0.076 * 1.12 * math.sin(math.radians(la))) for la in range(90, -57, -14)]
    loop = outer + inner + [outer[0]]
    hoodc = v_add(hc, (0.0, 0.0, -0.012))
    P.lathe(BR, hoodc, loop, n=P.n(14, 6), a0=150, a1=390)
    _arc_caps(P, BR, hoodc, loop, 150, 390)
    # face: brow, nose, moustache and a full beard
    P.box(BR, (x0, hc[1] + 0.022, hc[2] + 0.062), (0.038, 0.007, 0.009))
    P.box(BR, (x0, hc[1] - 0.004, hc[2] + 0.070), (0.008, 0.02, 0.01), r=(-12, 0, 0))
    P.box(BR, (x0, hc[1] - 0.034, hc[2] + 0.062), (0.026, 0.006, 0.008))
    P.sphere(BR, (x0, hc[1] - 0.062, hc[2] + 0.038), 0.04, sy=1.45, n=P.n(10, 5))


def _tape_row(P, x0, x1, y, z, seed, hmax=0.34):
    """A row of holobook data tapes on a shelf: individual tapes (LOD0 thin, LOD1 thick), one block at LOD2+."""
    rnd = random.Random(seed)
    if P.lod >= 2:
        P.box("jedi_tapes", ((x0 + x1) / 2, y + hmax * 0.46, z), ((x1 - x0) / 2, hmax * 0.46, 0.12), bottom=False)
        return
    x = x0
    pitch = 0.019 if P.lod == 0 else 0.038
    while x + pitch < x1:
        if rnd.random() < 0.06:                                              # a gap where tapes were taken out
            x += pitch * (2 + rnd.randrange(3))
            continue
        h = hmax * (0.86 + 0.14 * rnd.random())
        dz = 0.012 * (rnd.random() - 0.5)
        lean = 0.0
        if P.lod == 0 and rnd.random() < 0.04:
            lean = rnd.choice((-1, 1)) * (8 + 8 * rnd.random())
        w = pitch * 0.72
        P.box("jedi_tape", (x + w / 2, y + h / 2, z + dz), (w / 2, h / 2, 0.12), r=(0, 0, lean), bottom=False, fit=True)
        x += pitch


def jedi_archive_shelf(P):
    """Archive bay 1.7 x 2.0 x 0.5 m: four shelves of glowing data tapes; a bust and a holocron on top (2.5 m).
    Modelled 4 % taller and pressed to height here, so it fits under 2.5 m house ceilings with the bust."""
    with _Sub(P, lambda p: (p[0], p[1] * 0.96, p[2])):
        _archive_bay(P)


def _archive_bay(P):
    W, D = 0.78, 0.23
    P.prism(ST, [(-W, -D), (W, -D), (W, D), (-W, D)], 0.0, 0.12, side_slot=FR, side_vscale=0.12)
    P.box(BR, (0, 0.06, D + 0.004), (0.18, 0.025, 0.004))                    # name plate
    P.box("jedi_shadow", (0, 1.00, -0.195), (0.70, 0.88, 0.015))
    for s in (-1, 1):                                                         # stone pilasters, bronze capitals
        x = s * 0.725
        P.box(ST, (x, 1.005, 0.0), (0.045, 0.885, 0.215))
        P.box(BR, (x, 0.135, 0.0), (0.052, 0.015, 0.222))
        P.box(BR, (x, 1.87, 0.0), (0.052, 0.015, 0.222))
        P.box("jedi_shadow", (x, 1.0, 0.216), (0.016, 0.82, 0.002), bottom=False)
        if P.lod < 2:
            P.box("jedi_kyber", (x, 1.0, 0.219), (0.004, 0.80, 0.002), bottom=False)
            P.box(ST, (x, 1.0, -0.216), (0.03, 0.80, 0.002), bottom=False)
    for k, y in enumerate((0.12, 0.56, 1.00, 1.44)):
        if k:
            P.box(BR, (0, y - 0.012, 0.0), (0.68, 0.012, 0.20))
            P.box(BR, (0, y - 0.02, 0.198), (0.68, 0.024, 0.006))
        P.box("jedi_kyber", (0, y + 0.40, 0.17), (0.66, 0.003, 0.004))       # glow strip under the next board
        _tape_row(P, -0.675, 0.675, y, 0.02, seed=31 + k)
    P.box(BR, (0, 1.876, 0.0), (0.68, 0.012, 0.20))
    # back: stone frame and a frieze band over the dark panel
    for x in (-0.36, 0.0, 0.36):
        P.box(ST, (x, 1.0, -0.213), (0.03, 0.88, 0.004), bottom=False)
    P.box(FR, (0, 1.70, -0.214), (0.70, 0.07, 0.004), bottom=False)
    # entablature with a carved frieze, a cornice with a bronze edge
    P.prism(ST, [(-0.80, -0.22), (0.80, -0.22), (0.80, 0.22), (-0.80, 0.22)], 1.89, 2.02, side_slot=FR, side_vscale=0.13,
            bottom=True)
    P.prism(ST, [(-0.84, -0.245), (0.84, -0.245), (0.84, 0.245), (-0.84, 0.245)], 2.02, 2.07, bottom=True)
    P.sweep(BR, [(-0.842, 2.07, -0.247), (0.842, 2.07, -0.247), (0.842, 2.07, 0.247), (-0.842, 2.07, 0.247)], 0.006,
            closed=True, sides=4)
    _bust(P, (-0.44, 2.07, -0.02))
    # a holocron on a bronze tripod stand
    hc = (0.44, 2.29, 0.0)
    P.lathe(BR, (0.44, 2.07, 0.0), [(0.07, 0.0), (0.07, 0.015), (0.03, 0.03), (0.02, 0.12), (0.045, 0.15), (0.05, 0.16),
                                    (0.0, 0.16)], n=P.n(14, 6))
    for k in range(3):
        a = math.radians(90 + 120 * k)
        P.sweep(BR, [(0.44 + 0.045 * math.cos(a), 2.22, 0.045 * math.sin(a)), (0.44 + 0.055 * math.cos(a), 2.26, 0.055 * math.sin(a))],
                0.006, sides=4)
    _holocron(P, hc, 0.055, r=(35.26, 45.0, 0.0))
    _glow(P, hc, 0.11)


# ---------------------------------------------------------------------------------------------------------------
# training remote
# ---------------------------------------------------------------------------------------------------------------

def _remote(P):
    """Training remote in local space: a 0.2 m metal sphere with emitter nubs, a finned waist band, antennae."""
    n = P.n(18, 8)
    P.sphere("jedi_metal", (0, 0, 0), 0.10, n=n)
    P.lathe("jedi_visor", (0, 0, 0), [(0.097, -0.012), (0.106, -0.006), (0.106, 0.006), (0.097, 0.012)], n=n)
    if P.lod < 2:
        for k in range(8):
            a = 2 * math.pi * (k + 0.5) / 8
            P.box("jedi_metal", (0.107 * math.cos(a), 0.0, 0.107 * math.sin(a)), (0.006, 0.02, 0.012), r=(0, -math.degrees(a), 0))
    for k in range(6):
        el = 35 if k % 2 == 0 else -35
        az = math.radians(60 * k + 15)
        d = (math.cos(math.radians(el)) * math.cos(az), math.sin(math.radians(el)), math.cos(math.radians(el)) * math.sin(az))
        a = v_mul(d, 0.092)
        b = v_mul(d, 0.122)
        P.sweep("jedi_metal", [a, b], 0.014, sides=P.n(8, 4))
        P.sphere("jedi_visor", b, 0.0115, n=P.n(8, 4))
    for s in (-1, 1):
        P.sweep("jedi_metal", [(s * 0.03, 0.09, -0.02), (s * 0.05, 0.17, -0.04)], 0.004, sides=4)
        P.sphere("jedi_kyber", (s * 0.05, 0.172, -0.04), 0.008, n=5)


def _training_helmet(P):
    """Blast-shield practice helmet in local space: centred on the skull, facing +z, the shield down."""
    n = P.n(18, 8)
    P.sphere("jedi_metal", (0, 0, 0), 0.125, lat0=-20, lat1=90, n=n)
    P.lathe("jedi_metal", (0, 0, 0), [(0.0, -0.075), (0.128, -0.075), (0.142, -0.062), (0.132, -0.040), (0.118, -0.043)],
            n=n)
    P.sweep("jedi_metal", [(0.0, 0.126, 0.08), (0.0, 0.137, 0.0), (0.0, 0.126, -0.08)], 0.012, sides=P.n(6, 4))
    shield = [(0.142 * math.cos(math.radians(la)), 0.142 * math.sin(math.radians(la))) for la in range(-48, 31, 8)]
    P.lathe("jedi_visor", (0, 0, 0), shield, n=P.n(12, 6), a0=35, a1=145)
    P.lathe("jedi_visor", (0, 0, 0), [(r * 0.97, y * 0.97) for r, y in shield], n=P.n(12, 6), a0=35, a1=145, inside=True)
    for s in (-1, 1):
        P.lathe("jedi_metal", (s * 0.133, 0.01, 0.0), [(0.0, 0.0), (0.03, 0.0), (0.03, 0.012), (0.0, 0.016)],
                r=(0, 0, -90 * s), n=P.n(10, 5))
    P.sweep("jedi_metal", [(0.142 * math.cos(math.radians(a)) * math.cos(math.radians(30)), 0.142 * math.sin(math.radians(30)),
                            0.142 * math.sin(math.radians(a)) * math.cos(math.radians(30))) for a in range(35, 146, 10)],
            0.007, sides=4)


def jedi_training_remote(P):
    """Training display on a 1.4 x 0.84 m stone platform: the remote hovers at 1.28 m over its pedestal, the
    practice helmet on a head form (left), a lit training saber on a stand (right)."""
    n = P.n(40, 14)
    P.prism(ST, ellipse(0.70, 0.42, n), 0.0, 0.07, side_slot=FR, side_vscale=0.07)
    P.sweep(BR, [(0.66 * math.cos(2 * math.pi * k / n), 0.071, 0.385 * math.sin(2 * math.pi * k / n)) for k in range(n)],
            0.012, closed=True, sides=P.n(6, 4), profile=[(-0.3, -1.0), (0.3, -1.0), (0.3, 1.0), (-0.3, 1.0)])
    # central pedestal with its repulsor emitter, a faint lift field and the remote
    pc = (0.0, 0.07, -0.10)
    P.lathe(ST, pc, [(0.17, 0.0), (0.17, 0.04), (0.13, 0.07), (0.085, 0.11), (0.075, 0.70), (0.10, 0.74), (0.10, 0.78)],
            n=P.n(20, 8))
    for y in (0.20, 0.62):
        P.lathe(BR, pc, [(0.077, y - 0.015), (0.09, y - 0.006), (0.09, y + 0.006), (0.077, y + 0.015)], n=P.n(20, 8))
    P.lathe(BR, pc, [(0.10, 0.78), (0.13, 0.80), (0.14, 0.84), (0.12, 0.84), (0.06, 0.81), (0.0, 0.81)], n=P.n(20, 8))
    P.disc("jedi_kyber", v_add(pc, (0, 0.812, 0)), 0.0, 0.06, n=P.n(14, 6))
    rc = (0.0, 1.30, -0.10)
    if P.lod < 2:
        for inside in (False, True):
            P.lathe("jedi_glow", pc, [(0.06, 0.815), (0.035, 1.12)], n=P.n(14, 6), inside=inside)
    with _Sub(P, lambda p: xf(p, rc, (12, -25, 8))):
        _remote(P)
    # levitation practice: three stones hanging in the air at the front of the platform
    if P.lod < 3:
        for (x, y, z, r, rr) in ((-0.10, 0.22, 0.26, 0.045, (20, 30, 10)), (0.06, 0.34, 0.22, 0.035, (-15, 70, 25)),
                                 (0.16, 0.17, 0.28, 0.028, (35, 10, -20))):
            P.sphere(ST, (x, y, z), r, sy=0.72, r=rr, n=P.n(10, 5))
    # practice helmet on a head form, on a bronze stand (left front)
    hx, hz = -0.42, 0.10
    P.lathe(BR, (hx, 0.07, hz), [(0.10, 0.0), (0.10, 0.015), (0.04, 0.03), (0.0, 0.03)], n=P.n(14, 6))
    P.sweep(BR, [(hx, 0.09, hz), (hx, 0.52, hz)], 0.016, sides=P.n(8, 4))
    P.lathe(ST, (hx, 0.52, hz), [(0.02, 0.0), (0.045, 0.02), (0.05, 0.05), (0.0, 0.06)], n=P.n(10, 5))
    P.sphere(ST, (hx, 0.66, hz), 0.10, sy=1.1, n=P.n(12, 6))
    with _Sub(P, lambda p: xf(p, (hx, 0.69, hz), (4, 20, 0))):
        _training_helmet(P)
    # training lightsaber standing in a bronze cradle (right front)
    sx_, sz_ = 0.42, 0.08
    P.lathe(BR, (sx_, 0.07, sz_), [(0.11, 0.0), (0.11, 0.015), (0.06, 0.03), (0.03, 0.05), (0.0, 0.05)], n=P.n(14, 6))
    P.sweep(BR, [(sx_, 0.10, sz_), (sx_, 0.34, sz_)], 0.014, sides=P.n(8, 4))
    for s in (-1, 1):
        P.sweep(BR, [(sx_, 0.34, sz_), (sx_ + s * 0.05, 0.40, sz_), (sx_ + s * 0.04, 0.46, sz_)], 0.008, sides=P.n(6, 4))
    d = v_norm((-0.12, 1.0, -0.04))
    base = (sx_ + 0.005, 0.36, sz_)
    hilt_frame = _frame(base, d, (0.0, 0.0, 1.0))
    with _Sub(P, lambda p: hilt_frame((p[0], p[2], p[1]))):
        # hilt along local y (mapped onto d): pommel, grip ridges, switch, emitter shroud
        P.lathe("jedi_metal", (0, 0, 0), [(0.0, 0.0), (0.02, 0.0), (0.022, 0.02), (0.017, 0.03), (0.017, 0.20),
                                          (0.022, 0.21), (0.024, 0.25), (0.02, 0.26), (0.016, 0.262), (0.0, 0.262)],
                n=P.n(12, 6))
        if P.lod < 2:
            for k in range(6):
                y = 0.05 + 0.022 * k
                P.lathe("jedi_visor", (0, y, 0), [(0.0165, -0.006), (0.0195, -0.003), (0.0195, 0.003), (0.0165, 0.006)],
                        n=P.n(12, 6))
            P.box("jedi_kyber", (0.0, 0.18, 0.018), (0.005, 0.01, 0.003))
    blade0 = v_add(base, v_mul(d, 0.262))
    blade1 = v_add(base, v_mul(d, 1.02))
    P.sweep("jedi_saber", [blade0, blade1], 0.011, sides=P.n(10, 5))
    P.sphere("jedi_saber", blade1, 0.011, n=P.n(8, 5))
    if P.lod < 3:
        P.sweep("jedi_glow", [v_add(blade0, v_mul(d, 0.01)), blade1], 0.024, sides=P.n(10, 5))
        P.sphere("jedi_glow", blade1, 0.024, n=P.n(8, 5))


# ---------------------------------------------------------------------------------------------------------------
# fountain
# ---------------------------------------------------------------------------------------------------------------

def _parabola(a, b, h, m):
    """Points on a falling arc from a to b, peaking h above the higher end."""
    pts = []
    for k in range(m + 1):
        t = k / m
        p = v_add(a, v_mul(v_sub(b, a), t))
        pts.append((p[0], p[1] + 4 * h * t * (1 - t), p[2]))
    return pts


def jedi_fountain(P):
    """Room of a Thousand Fountains basin: 1.85 m across, water at 0.36 m, a bronze-bowled column with jets to
    1.48 m, overflow streams, lily pads, reeds and kyber lights under the water."""
    n = P.n(48, 16)
    R1, R0, H, WY, FY = 0.88, 0.76, 0.44, 0.36, 0.12
    # basin: plinth step, carved outer wall, capstone rim, inner wall, floor, water
    P.lathe(ST, (0, 0, 0), [(R1 + 0.045, 0.0), (R1 + 0.045, 0.05), (R1, 0.065)], n=n)
    P.lathe(FR, (0, 0, 0), [(R1, 0.065), (R1, H - 0.035)], n=n, vscale=H - 0.10)
    P.lathe(ST, (0, 0, 0), [(R1, H - 0.035), (R1 + 0.04, H - 0.03), (R1 + 0.045, H - 0.005), (R1 + 0.035, H),
                            (R0 - 0.015, H), (R0 - 0.02, H - 0.012), (R0, H - 0.03)], n=n)
    P.lathe(ST, (0, 0, 0), [(R0, H - 0.03), (R0, FY)], n=n)
    P.disc("jedi_mosaic", (0, FY, 0), 0.0, R0, n=n, fit=True)
    P.sweep(BR, [((R0 + R1) / 2 * math.cos(2 * math.pi * k / n), H + 0.002, (R0 + R1) / 2 * math.sin(2 * math.pi * k / n))
                 for k in range(n)], 0.014, closed=True, sides=P.n(6, 4), profile=[(-0.3, -1.0), (0.3, -1.0), (0.3, 1.0), (-0.3, 1.0)])
    if P.lod < 2:                                                            # kyber lights under the water
        for k in range(10):
            a = 2 * math.pi * (k + 0.5) / 10
            P.sphere("jedi_kyber", (0.66 * math.cos(a), FY, 0.66 * math.sin(a)), 0.03, lat0=0, lat1=90, n=6)
    # central column and the bronze upper bowl with its own pool
    P.lathe(ST, (0, 0, 0), [(0.21, FY), (0.21, 0.20), (0.16, 0.26), (0.11, 0.33), (0.08, 0.46), (0.07, 0.78),
                            (0.09, 0.82), (0.12, 0.84)], n=P.n(24, 8))
    P.lathe(BR, (0, 0, 0), [(0.12, 0.84), (0.20, 0.87), (0.29, 0.935), (0.335, 0.985), (0.34, 1.01), (0.325, 1.012),
                            (0.30, 0.995), (0.22, 0.965), (0.0, 0.955)], n=P.n(32, 10))
    P.lathe(BR, (0, 0, 0), [(0.075, 0.55), (0.088, 0.565), (0.088, 0.585), (0.075, 0.60)], n=P.n(16, 6))
    P.disc("jedi_water", (0, 0.992, 0), 0.0, 0.305, n=P.n(28, 10))
    P.disc("jedi_water", (0, WY, 0), 0.0, R0, n=n)
    # lotus spout in the bowl, a central jet and a crown of arcs falling back into the bowl
    P.lathe(BR, (0, 0, 0), [(0.07, 0.955), (0.05, 1.00), (0.032, 1.08), (0.05, 1.13), (0.075, 1.16), (0.04, 1.18),
                            (0.016, 1.21), (0.0, 1.22)], n=P.n(14, 6))
    if P.lod < 2:
        for k in range(8):
            a = math.radians(45 * k)
            P.cone(BR, (0.05 * math.cos(a), 1.14, 0.05 * math.sin(a)), (0.11 * math.cos(a), 1.20, 0.11 * math.sin(a)), 0.022,
                   n=4)
    P.sweep("jedi_falls", [(0, 1.21, 0), (0, 1.48, 0)], lambda t: 0.016 * (1 - 0.6 * t), sides=P.n(8, 4))
    m = P.n(10, 5)
    for k in range(8 if P.lod < 2 else 4):
        a = math.radians((45 if P.lod < 2 else 90) * k + 22.5)
        P.sweep("jedi_falls", _parabola((0.0, 1.44, 0.0), (0.25 * math.cos(a), 0.995, 0.25 * math.sin(a)), 0.06, m),
                lambda t: 0.0065 * (1 - 0.3 * t), sides=P.n(6, 4))
    # the overflow veil from the bowl lip down into the basin, foam rings where it lands
    veil = [(0.392, WY + 0.002), (0.386, 0.55), (0.378, 0.78), (0.37, 0.90), (0.36, 0.965), (0.348, 0.995), (0.338, 1.008)]
    P.lathe("jedi_falls", (0, 0, 0), veil, n=P.n(32, 10))
    for r0, r1 in ((0.37, 0.45), (0.52, 0.55)) if P.lod < 3 else ():
        P.disc("jedi_foam", (0, WY + 0.003, 0), r0, r1, n=P.n(32, 10))
    # lily pads with two flowers, reeds near the rim
    if P.lod < 3:
        for k, (a, r, rr) in enumerate(((30, 0.62, 0.075), (70, 0.66, 0.06), (160, 0.60, 0.085), (200, 0.65, 0.06),
                                        (300, 0.58, 0.08), (330, 0.66, 0.055))):
            c = (r * math.cos(math.radians(a)), WY + 0.004, r * math.sin(math.radians(a)))
            mm = P.n(14, 6)
            pts = [c] + [(c[0] + rr * math.cos(math.radians(a + 20 + 320 * j / mm)), c[1],
                          c[2] + rr * math.sin(math.radians(a + 20 + 320 * j / mm))) for j in range(mm + 1)]
            for j in range(1, len(pts) - 1):
                P.flat("jedi_leaf", [pts[0], pts[j], pts[j + 1]], (0, 1, 0))
            if k in (0, 4) and P.lod < 2:
                fc = v_add(c, (0.0, 0.0, 0.0))
                for j in range(6):
                    b = math.radians(60 * j)
                    P.cone("jedi_cream", v_add(fc, (0.012 * math.cos(b), 0.002, 0.012 * math.sin(b))),
                           v_add(fc, (0.045 * math.cos(b), 0.05, 0.045 * math.sin(b))), 0.014, n=4)
                P.sphere("jedi_kyber", v_add(fc, (0, 0.02, 0)), 0.012, n=5)
        for a in (115, 250):
            ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
            base = (0.68 * ca, WY, 0.68 * sa)
            for j in range(5 if P.lod < 2 else 3):
                b = math.radians(a + 70 * j)
                h = 0.42 + 0.12 * ((j * 7) % 3)
                top = v_add(base, (0.12 * math.cos(b), h, 0.12 * math.sin(b)))
                mid = v_add(base, (0.03 * math.cos(b), h * 0.6, 0.03 * math.sin(b)))
                P.sweep("jedi_leaf", [v_add(base, (0, -0.02, 0)), mid, top], lambda t: 0.012 * (1 - 0.85 * t),
                        sides=4, profile=[(-1.0, -0.25), (1.0, -0.25), (1.0, 0.25), (-1.0, 0.25)])


# ---------------------------------------------------------------------------------------------------------------
# registry

def _chair_pad(P, u0, u1, t0, t1, base, thick, nu, nt):
    """A quilted pad on the shell's inner skin: puffed in the middle, a low wall round its border."""
    puff = lambda s, q: 0.35 + 0.65 * (math.sin(math.pi * s) ** 0.35) * (math.sin(math.pi * q) ** 0.35)
    S = [[_chair_pt(u0 + (u1 - u0) * i / nu, t0 + (t1 - t0) * j / nt, base + thick * puff(i / nu, j / nt))
          for j in range(nt + 1)] for i in range(nu + 1)]
    B = [[_chair_pt(u0 + (u1 - u0) * i / nu, t0 + (t1 - t0) * j / nt, base - 0.002) for j in range(nt + 1)]
         for i in range(nu + 1)]
    sc = _uvs("jedi_tan")
    arc_len = 2 * math.pi * 0.42 * CHAIR_SPAN / 360 * (u1 - u0)
    U = [[arc_len * i / nu / sc] * (nt + 1) for i in range(nu + 1)]
    V = [[0.9 * (t1 - t0) * j / nt / sc for j in range(nt + 1)] for _ in range(nu + 1)]
    cz = CHAIR_CZ
    P.grid("jedi_tan", S, U, V, lambda q: v_sub((0.0, 0.0, cz), (q[0], 0.0, q[2])))
    for i0, i1, di in ((0, 1, None), (nu, nu - 1, None)):
        for j in range(nt):
            P.flat("jedi_tan", [S[i0][j], S[i0][j + 1], B[i0][j + 1], B[i0][j]], v_sub(S[i0][j], S[i1][j]))
    for j0, j1 in ((0, 1), (nt, nt - 1)):
        for i in range(nu):
            P.flat("jedi_tan", [S[i][j0], S[i + 1][j0], B[i + 1][j0], B[i][j0]], v_sub(S[i][j0], S[i][j1]))


# ---------------------------------------------------------------------------------------------------------------

PIECES = {
    "jedi_meditation_mat": (jedi_meditation_mat, "interact"),
    "jedi_council_chair": (jedi_council_chair, "seat"),
    "jedi_temple_lantern": (jedi_temple_lantern, "lamp"),
    "jedi_archive_shelf": (jedi_archive_shelf, "decor"),
    "jedi_training_remote": (jedi_training_remote, "decor"),
    "jedi_fountain": (jedi_fountain, "decor"),
}
_KEYS = ("jedi_stone", "jedi_frieze", "jedi_cream", "jedi_tan", "jedi_bronze", "jedi_kyber", "jedi_glow",
         "jedi_holocron", "jedi_mat", "jedi_mosaic", "jedi_tape", "jedi_tapes", "jedi_metal", "jedi_visor", "jedi_saber",
         "jedi_water", "jedi_falls", "jedi_foam", "jedi_leaf", "jedi_shadow")
SLOTS = {"jedi": {k: k for k in _KEYS}}
UV = {"jedi_stone": 1.0, "jedi_frieze": 0.5, "jedi_cream": 0.8, "jedi_tan": 0.5, "jedi_bronze": 0.4, "jedi_kyber": 0.15,
      "jedi_glow": 0.5, "jedi_holocron": 1.0, "jedi_mat": 1.0, "jedi_mosaic": 1.0, "jedi_tape": 1.0, "jedi_tapes": 0.32,
      "jedi_metal": 0.3, "jedi_visor": 0.4, "jedi_saber": 0.5, "jedi_water": 1.0, "jedi_falls": 0.6, "jedi_foam": 0.5, "jedi_leaf": 0.3,
      "jedi_shadow": 1.0}
SMOOTH = ("jedi_cream", "jedi_tan", "jedi_bronze", "jedi_metal", "jedi_glow", "jedi_water", "jedi_falls", "jedi_leaf",
          "jedi_visor",
          "jedi_saber", "jedi_foam")
COLORS = {"jedi": (0.78, 0.68, 0.52)}
