"""Kashyyyk Wookiee treehouse furniture (group `wok`): wroshyr wood, woven fibre, fur, carved tribal glyphs,
bioluminescent fungus and bronze fittings. Host half (materials, names, the lantern's light): examples/frn_sets/wok.py.

  wok_hide_frame       interact (tan)  a hide laced into a lashed wroshyr frame leaning low, a tool stump, a basket
  wok_root_chair       seat            a chair grown from twisted roots, a woven-branch back, a striped pelt throw
  wok_glow_lantern     lamp            a woven basket lantern of glowing fungus pods hanging from a carved crook
  wok_bowcaster_rack   decor           a forked-post rack holding a bowcaster, a bandolier and a basket of quarrels
  wok_carved_totem     decor           a wroshyr totem: three Wookiee faces, glyph bands, a branching crown
  wok_storage_baskets  decor           stacked lidded baskets, a tall basket, a bowl of glow-caps and a net bag

Maya space: y up, standing on the origin, front +z."""
from __future__ import annotations

import math

from ..furniture import (v_add, v_sub, v_mul, v_norm, v_len, v_dot, v_cross, rot, xf, ellipse, smoothstep,
                         seat_hardpoint, station_hardpoints, light_hardpoint)

# ---------------------------------------------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------------------------------------------


def _spline(ctrl, per):
    """Catmull-Rom curve through the control points, `per` samples per span."""
    pts = [ctrl[0]] + list(ctrl) + [ctrl[-1]]
    out = []
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[i + 1], pts[i + 2]
        for k in range(per):
            t = k / per
            t2, t3 = t * t, t * t * t
            out.append(tuple(0.5 * (2 * p1[j] + (p2[j] - p0[j]) * t + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * t2 +
                                    (3 * p1[j] - p0[j] - 3 * p2[j] + p3[j]) * t3) for j in range(3)))
    out.append(tuple(ctrl[-1]))
    return out


def _basis(ax):
    ax = v_norm(ax)
    t = v_norm(v_cross(ax, (0.0, 1.0, 0.0) if abs(ax[1]) < 0.9 else (1.0, 0.0, 0.0)))
    return t, v_cross(ax, t)


def _ring(P, slot, c, ax, R, r, n=None, sides=None):
    """A torus ring (lashing, band, rim) round axis `ax` through c."""
    t, b = _basis(ax)
    n = n or P.n(14, 6)
    path = [v_add(c, v_add(v_mul(t, R * math.cos(2 * math.pi * k / n)), v_mul(b, R * math.sin(2 * math.pi * k / n))))
            for k in range(n)]
    P.sweep(slot, path, r, sides=sides or P.n(5, 3), closed=True)


def _root(P, ctrl, r0, r1, slot="wok_bark", per=None, knob=0.12, seed=0.0, sides=None):
    """An organic tapered root / branch through control points (knobbly radius)."""
    path = _spline(ctrl, per or P.n(5, 2))
    f = lambda t: (r0 + (r1 - r0) * t) * (1.0 + knob * math.sin(t * 19.0 + seed) * math.sin(t * 7.0 + seed * 2.3))
    P.sweep(slot, path, f, sides=sides or P.n(8, 4))
    return path


def _lash(P, c, ax, R, wraps=3, r=0.006):
    """Cord lashing: a few tight wraps round a pole."""
    if P.lod >= 3:
        return
    a = v_norm(ax)
    for k in range(wraps):
        _ring(P, "wok_cord", v_add(c, v_mul(a, (k - (wraps - 1) / 2) * 2.1 * r)), a, R + r * 0.6, r,
              n=P.n(12, 6), sides=P.n(4, 3))


def _blob(P, slot, c, prof, amp=0.06, seed=0.0, n=None):
    """Lathe with a lumpy outline (stumps, trunks): rings of radius r(y) modulated round the axis."""
    n = n or P.n(20, 7)
    rings = []
    for r, y in prof:
        ring = []
        for k in range(n):
            a = 2 * math.pi * k / n
            m = 1 + amp * (0.6 * math.sin(5 * a + seed) + 0.4 * math.sin(9 * a + 2.1 * seed + y * 7))
            ring.append((c[0] + r * m * math.cos(a), c[1] + y, c[2] + r * m * math.sin(a)))
        rings.append(ring)
    P.loft(slot, rings, closed=True, caps=(False, False))
    return rings


def _strip(P, slot, left, right, nrm, t):
    """A thin plate between two edge polylines (blades, boards, leaves): front/back quads and the edge band."""
    n_ = v_norm(nrm)
    h = v_mul(n_, t / 2)
    m = len(left)
    for i in range(m - 1):
        q = [left[i], right[i], right[i + 1], left[i + 1]]
        P.flat(slot, [v_add(p, h) for p in q], n_)
        P.flat(slot, [v_sub(p, h) for p in q], v_mul(n_, -1))
    for edge, other in ((left, right), (right, left)):
        for i in range(m - 1):
            a, b = edge[i], edge[i + 1]
            out = v_sub(v_mul(v_add(a, b), 0.5), v_mul(v_add(other[i], other[i + 1]), 0.5))
            out = v_sub(out, v_mul(n_, v_dot(out, n_)))
            if v_len(out) < 1e-9 or v_len(v_sub(a, b)) < 1e-9:
                continue
            P.flat(slot, [v_add(a, h), v_add(b, h), v_sub(b, h), v_sub(a, h)], out)
    for i, j in ((0, 1), (m - 1, m - 2)):
        a, b = left[i], right[i]
        if v_len(v_sub(a, b)) < 1e-9:
            continue
        P.flat(slot, [v_add(a, h), v_add(b, h), v_sub(b, h), v_sub(a, h)],
               v_sub(v_mul(v_add(a, b), 0.5), v_mul(v_add(left[j], right[j]), 0.5)))


def _pelt(P, slot, ctrl, side, wfn, th=0.022, per=None):
    """A thick soft sheet (pelt, throw) along a path: rounded-edge sections `wfn(t)` half wide across `side`."""
    path = _spline(ctrl, per or P.n(5, 2))
    m = len(path)
    rings = []
    for k in range(m):
        t = k / (m - 1)
        tan = v_norm(v_sub(path[min(m - 1, k + 1)], path[max(0, k - 1)]))
        sd = v_norm(v_sub(side, v_mul(tan, v_dot(side, tan))))
        nrm = v_norm(v_cross(tan, sd))
        w = wfn(t)
        prof = [(w, th / 2), (w + th * 0.45, 0.0), (w, -th / 2), (0.0, -th / 2 - 0.003), (-w, -th / 2),
                (-w - th * 0.45, 0.0), (-w, th / 2), (0.0, th / 2 + 0.004)]
        rings.append([v_add(path[k], v_add(v_mul(sd, a), v_mul(nrm, b))) for a, b in prof])
    P.loft(slot, rings, closed=True)
    return path


def _ell(P, slot, c, r, sy=1.0, n=8, rows=6, r_=(0, 0, 0), lat0=-90.0):
    """Ellipsoid (or cap from lat0) with explicit resolution: local y scaled by sy, rotated by r_."""
    prof = [(r * math.cos(math.radians(lat0 + (90.0 - lat0) * k / rows)), r * sy * math.sin(math.radians(lat0 + (90.0 - lat0) * k / rows)))
            for k in range(rows + 1)]
    prof[-1] = (0.0, prof[-1][1])
    if lat0 <= -89.9:
        prof[0] = (0.0, prof[0][1])
    P.lathe(slot, c, prof, n=n, r=r_)


def _spiral(c, e1, e2, r0, r1, a0, a1, n):
    """Points of a flat spiral in the plane (e1, e2) round c, radius r0 -> r1 over angles a0 -> a1 (degrees)."""
    out = []
    for k in range(n + 1):
        t = k / n
        a = math.radians(a0 + (a1 - a0) * t)
        r = r0 + (r1 - r0) * t
        out.append(v_add(c, v_add(v_mul(e1, r * math.cos(a)), v_mul(e2, r * math.sin(a)))))
    return out


def _glowcaps(P, base, cnt, size, seed=0.0, up=(0.0, 1.0, 0.0), spread=0.05):
    """A cluster of bioluminescent mushroom caps on short stems."""
    for k in range(cnt):
        a = seed + k * 2.39996
        rr = spread * math.sqrt((k + 0.5) / cnt)
        s = size * (0.6 + 0.4 * ((k * 37 + 11) % 7) / 6)
        foot = v_add(base, (rr * math.cos(a), 0.0, rr * math.sin(a)))
        h = s * (1.4 + 0.5 * ((k * 13) % 3))
        top = v_add(foot, v_add(v_mul(up, h), (0.25 * rr * math.cos(a), 0.0, 0.25 * rr * math.sin(a))))
        P.sweep("wok_fungus", [foot, top], s * 0.28, sides=P.n(6, 4))
        P.sphere("wok_fungus", top, s, lat0=-20, lat1=90, sy=0.6, n=P.n(10, 5))
        P.disc("wok_fungus", v_add(top, (0, -s * 0.2, 0)), 0.0, s * 0.94, n=P.n(10, 5), down=True)


def _charm(P, top, length, bead=True):
    """A cord hanging from `top` with bone beads and a claw at the end."""
    if P.lod >= 2:
        return
    bot = v_add(top, (0.0, -length, 0.0))
    P.sweep("wok_cord", [top, bot], 0.004, sides=4)
    if bead:
        P.sphere("wok_bone", v_add(top, (0.0, -length * 0.45, 0.0)), 0.013, n=6)
        P.sphere("wok_bronze", v_add(top, (0.0, -length * 0.7, 0.0)), 0.010, n=6)
    P.cone("wok_bone", v_add(bot, (0.0, 0.005, 0.0)), v_add(bot, (0.012, -0.05, 0.0)), 0.011, n=5)


def _basket(P, c, prof, slot="wok_weave", wall=0.012, rims=(), rim_slot="wok_cord", open_top=True, n=None):
    """Woven basket: outer lathe (closed bottom), inner lining, a rolled rim, cord bands at the given heights."""
    n = n or P.n(24, 8)
    P.lathe(slot, c, [(0.0, prof[0][1])] + prof, n=n)
    top_r, top_y = prof[-1]
    if open_top:
        inner = [(max(0.0, r - wall), y + (wall if k == 0 else 0.0)) for k, (r, y) in enumerate(prof)]
        P.lathe(slot, c, [(0.0, inner[0][1])] + inner, n=n, inside=True)
        _ring(P, slot, (c[0], c[1] + top_y, c[2]), (0, 1, 0), top_r - wall / 2, wall * 0.9, n=n, sides=P.n(6, 4))
    for y in rims:
        rr = None
        for k in range(len(prof) - 1):
            (ra, ya), (rb, yb) = prof[k], prof[k + 1]
            if ya <= y <= yb:
                rr = ra + (rb - ra) * (y - ya) / ((yb - ya) or 1)
        if rr:
            _ring(P, rim_slot, (c[0], c[1] + y, c[2]), (0, 1, 0), rr + 0.002, 0.008, n=n, sides=P.n(5, 3))


# ---------------------------------------------------------------------------------------------------------------
# wok_hide_frame: interact, activity "tan"
# ---------------------------------------------------------------------------------------------------------------

HIDE_SPOT = (0.0, 0.0, 0.68)          # the player's feet, crouching, facing -z at the hide


def wok_hide_frame(P):
    """A fresh hide laced into a lashed wroshyr frame that leans back 45 degrees, its lower half 0.4-0.6 m ahead
    of the crouching tanner at 0.15-0.5 m up. A stump with a flesher, a ryyk blade and a paste bowl at the
    right, a basket with a rolled pelt at the left, a woven mat under the station spot."""
    O = (0.0, 0.46, 0.02)
    ex, ey = (1.0, 0.0, 0.0), v_norm((0.0, 1.0, -1.0))
    en = v_cross(ex, ey)                                      # hide normal: up and toward the tanner
    L = lambda u, v, w=0.0: v_add(O, v_add(v_mul(ex, u), v_add(v_mul(ey, v), v_mul(en, w))))
    PR, CR = 0.036, 0.030                                     # side pole / crossbar radius
    US, VC = 0.60, 0.48                                       # side poles at u = +-US, crossbars at v = +-VC
    WC = PR + CR                                              # crossbars lashed on the front of the poles
    # side poles, their feet on the floor (the end cap tilts 45 degrees: centre 0.707 r up)
    v_foot = -(O[1] - 0.7071 * PR) / 0.7071
    for sx in (-1, 1):
        P.sweep("wok_wood", _spline([L(sx * US, v_foot), L(sx * (US + 0.005), 0.0, 0.004), L(sx * US, 0.66)], P.n(4, 2)),
                lambda t: PR * (1.0 - 0.15 * t), sides=P.n(9, 5))
        # carved sleeve and a bronze cap on the top end
        P.sweep("wok_carve", [L(sx * US, 0.52), L(sx * US, 0.63)], PR * 1.12, sides=P.n(9, 5))
        P.sphere("wok_bronze", L(sx * US, 0.665), PR * 0.95, n=P.n(10, 5))
    for v in (-VC, VC):
        P.sweep("wok_wood", [L(-0.73, v, WC), L(0.0, v, WC + 0.004), L(0.73, v, WC)], CR, sides=P.n(9, 5))
        for sx in (-1, 1):
            P.sphere("wok_bronze", L(sx * 0.735, v, WC), CR * 1.05, n=P.n(10, 5))
            _lash(P, L(sx * US, v, PR * 0.5), ey, PR, wraps=3)
            _lash(P, L(sx * (US + 0.05), v, WC), ex, CR, wraps=2)
    # back props to the floor, lashed under the top crossbar
    for sx in (-1, 1):
        top = L(sx * US, VC - 0.06, -PR * 1.6)
        foot = (sx * 0.68, 0.028, -0.80)
        P.sweep("wok_wood", [top, v_mul(v_add(top, foot), 0.5), foot], lambda t: 0.030 * (1 - 0.1 * t), sides=P.n(8, 4))
        _lash(P, v_add(top, v_mul(v_norm(v_sub(foot, top)), 0.02)), v_sub(foot, top), 0.030, wraps=3)
    # the hide: an irregular pelt outline (legs, neck, tail), sagging a little, both faces and an edge band
    A, B = 0.50, 0.39

    def edge_r(th):
        d = lambda a: (th - a + 180.0) % 360.0 - 180.0
        r = 1.0
        for la in (40, 140, 220, 320):
            r += 0.15 * math.exp(-(d(la) / 17.0) ** 2)
        r += 0.06 * math.exp(-(d(90) / 11.0) ** 2) + 0.08 * math.exp(-(d(270) / 9.0) ** 2)
        r -= 0.07 * math.exp(-(d(0) / 22.0) ** 2) + 0.07 * math.exp(-(d(180) / 22.0) ** 2)
        return r + 0.02 * math.sin(math.radians(th) * 7 + 1.0)

    nt, ns = P.n(40, 12), P.n(6, 2)
    sv = [0.15 + 0.85 * k / ns for k in range(ns + 1)]

    def hp(s, th, w):
        r = edge_r(th)
        u, v = s * A * r * math.cos(math.radians(th)), s * B * r * math.sin(math.radians(th))
        return L(u, v, w - 0.030 * (1 - s * s)), u, v

    for side, wofs, want in ((1, 0.034, en), (-1, 0.028, v_mul(en, -1))):
        G, U, V = [], [], []
        for i in range(nt + 1):
            th = 360.0 * i / nt
            col_p, col_u, col_v = [], [], []
            for s in sv:
                p, u, v = hp(s, th, wofs)
                col_p.append(p)
                col_u.append(0.5 + u / 1.1)
                col_v.append(0.5 + v / 0.9)
            G.append(col_p)
            U.append(col_u)
            V.append(col_v)
        sl = "wok_hide" if side > 0 else "wok_fur"                     # flesh side to the tanner, hair side behind
        P.grid(sl, G, U, V, lambda q, w=want: w)
        P.poly(sl, [G[i][0] for i in range(nt)], [(U[i][0], V[i][0]) for i in range(nt)], want)
        if side > 0:
            outer = [G[i][-1] for i in range(nt + 1)]
    back = [hp(1.0, 360.0 * i / nt, 0.028)[0] for i in range(nt + 1)]
    hc = L(0, 0, 0.03)
    for i in range(nt):
        q = [outer[i], outer[i + 1], back[i + 1], back[i]]
        P.flat("wok_fur", q, v_sub(v_mul(v_add(outer[i], outer[i + 1]), 0.5), hc))
    # lacing: cords from the hide edge to the frame, a wrap where each meets its pole
    nl = 16 if P.lod < 2 else 8
    for k in range(nl):
        th = 360.0 * (k + 0.5) / nl
        p, u, v = hp(0.96, th, 0.031)
        cu, cv = math.cos(math.radians(th)), math.sin(math.radians(th))
        su = (US - PR * 0.3) / abs(cu) if abs(cu) > 1e-6 else 9.0
        svv = (VC - CR * 0.3) / abs(cv) if abs(cv) > 1e-6 else 9.0
        if su < svv:
            q = L(math.copysign(US, cu), su * cv, 0.0)
            ax, rr = ey, PR
        else:
            q = L(svv * cu, math.copysign(VC, cv), WC)
            ax, rr = ex, CR
        P.sweep("wok_cord", [p, q], 0.0045, sides=P.n(4, 3))
        if P.lod < 2:
            _ring(P, "wok_cord", q, ax, rr + 0.002, 0.0045, n=8, sides=4)
    # charms dangling from the crossbar ends outside the frame, a fur scrap over the top bar's left end
    for sx, ln in ((-1, 0.20), (1, 0.15)):
        _charm(P, v_add(L(sx * 0.68, VC, WC), (0, -CR, 0)), ln)
    if P.lod < 3:
        bc_ = L(-0.69, VC, WC)
        ctrl = [v_add(bc_, (0.0, -0.13, 0.052)), v_add(bc_, (0.0, -0.01, 0.045)), v_add(bc_, (0.0, 0.043, 0.0)),
                v_add(bc_, (0.0, -0.01, -0.045)), v_add(bc_, (0.0, -0.15, -0.056))]
        _pelt(P, "wok_fur", ctrl, (1.0, 0.0, 0.0), lambda t: 0.040 + 0.006 * math.sin(t * 13.0), th=0.014, per=P.n(4, 2))
    # the woven mat under the station spot
    P.prism("wok_weave_band", ellipse(0.34, 0.25, P.n(28, 10), HIDE_SPOT[0], HIDE_SPOT[2] - 0.02), 0.0, 0.012,
            side_slot="wok_cord", side_vscale=0.06)
    # the tool stump at the right: lumpy bark sides, end-grain top, root flares
    sc = (0.98, 0.0, 0.26)
    rings = _blob(P, "wok_bark", sc, [(0.235, 0.0), (0.215, 0.05), (0.195, 0.14), (0.19, 0.30), (0.185, 0.40)],
                  amp=0.07, seed=1.3)
    P.flat("wok_endgrain", rings[-1], (0, 1, 0), fit=True)
    for k in range(5):
        a = math.radians(30 + 72 * k)
        d = (math.cos(a), 0.0, math.sin(a))
        _root(P, [v_add(sc, v_add(v_mul(d, 0.14), (0, 0.17, 0))), v_add(sc, v_add(v_mul(d, 0.25), (0, 0.06, 0))),
                  v_add(sc, v_add(v_mul(d, 0.34 + 0.03 * (k % 2)), (0, 0.016, 0)))], 0.055, 0.016, seed=k)
    top = sc[1] + 0.40
    # flesher: a curved bronze blade with two wooden handles, lying on the stump top
    fc = (sc[0] - 0.02, top + 0.012, sc[2] + 0.07)
    bl = [v_add(fc, rot((0.13 * math.sin(math.radians(a)), 0.0, 0.05 * (1 - math.cos(math.radians(a)))), 0, 20, 0))
          for a in range(-60, 61, 20 if P.lod < 2 else 40)]
    br = [v_add(p, rot((0.0, 0.0, 0.035), 0, 20, 0)) for p in bl]
    _strip(P, "wok_bronze", bl, br, (0, 1, 0), 0.006)
    for p in (bl[0], bl[-1]):
        d = v_norm(v_sub(p, fc))
        P.sweep("wok_wood", [v_add(p, v_mul(d, 0.005)), v_add(p, v_mul(d, 0.10))], 0.013, sides=P.n(7, 4))
    # ryyk blade stuck into the stump: curved blade, cord-wrapped grip, bronze pommel
    bp = (sc[0] + 0.06, top, sc[2] - 0.06)
    tilt = lambda p: xf(p, bp, (0, 25, -14))
    hl, hr = [], []
    m = 7 if P.lod < 2 else 3
    for k in range(m + 1):
        t = k / m                                             # 0 = the buried tip, 1 = the guard
        y = -0.07 + 0.29 * t
        cx = 0.028 * math.sin(t * math.pi) - 0.02 * (1 - t) ** 2
        w = 0.040 * t ** 0.5 + 0.003
        hl.append(tilt((cx - w * 0.35, y, 0.0)))
        hr.append(tilt((cx + w * 0.65, y, 0.0)))
    _strip(P, "wok_metal", hl, hr, v_sub(tilt((0, 0, 1)), tilt((0, 0, 0))), 0.006)
    P.box("wok_bronze", tilt((0.006, 0.228, 0.0)), (0.042, 0.009, 0.013))
    g0, g1 = tilt((0.0, 0.25, 0.0)), tilt((0.0, 0.37, 0.0))
    P.sweep("wok_bronze", [tilt((0.0, 0.236, 0.0)), g0], 0.021, sides=P.n(8, 4))
    P.sweep("wok_wood", [g0, g1], 0.016, sides=P.n(8, 4))
    P.sphere("wok_bronze", tilt((0.0, 0.385, 0.0)), 0.021, n=P.n(8, 5))
    if P.lod < 2:
        for k in range(4):
            _ring(P, "wok_cord", tilt((0.0, 0.272 + 0.025 * k, 0.0)), v_sub(g1, g0), 0.017, 0.004, n=8, sides=4)
    # paste bowl
    pb_c = (sc[0] - 0.08, top, sc[2] - 0.08)
    P.lathe("wok_wood", pb_c, [(0.0, 0.0), (0.05, 0.0), (0.075, 0.03), (0.08, 0.05), (0.072, 0.052), (0.06, 0.032), (0.0, 0.022)],
            n=P.n(14, 6))
    P.disc("wok_bark", v_add(pb_c, (0, 0.036, 0)), 0.0, 0.066, n=P.n(14, 6))
    if P.lod < 2:
        P.sweep("wok_wood", [v_add(pb_c, (-0.02, 0.04, 0.01)), v_add(pb_c, (0.12, 0.07, 0.05))], 0.007, sides=4)
    # basket at the left holding a rolled pelt
    bc = (-0.98, 0.0, 0.30)
    _basket(P, bc, [(0.13, 0.0), (0.17, 0.08), (0.18, 0.18), (0.165, 0.30)], slot="wok_weave_band", rims=(0.06, 0.22))
    rp = [(-0.99, 0.05, 0.30), (-0.92, 0.48, 0.19)]
    P.sweep("wok_pelt", rp, 0.08, sides=P.n(14, 6))
    d = v_norm(v_sub(rp[1], rp[0]))
    t1, t2 = _basis(d)
    nc = P.n(16, 6)
    cap = [v_add(v_add(rp[1], v_mul(d, 0.002)), v_add(v_mul(t1, 0.0785 * math.cos(2 * math.pi * k / nc)),
                                                       v_mul(t2, 0.0785 * math.sin(2 * math.pi * k / nc)))) for k in range(nc)]
    P.flat("wok_hide", cap, d, fit=True)
    if P.lod < 2:
        P.sweep("wok_fur", _spiral(v_add(rp[1], v_mul(d, 0.004)), t1, t2, 0.072, 0.006, 0.0, 900.0, P.n(30, 10)), 0.0045, sides=4)
    for f in (0.40, 0.75):
        _ring(P, "wok_leather", v_add(rp[0], v_mul(d, f * 0.45)), d, 0.082, 0.008, n=P.n(14, 6), sides=4)
    station_hardpoints(P, "tan", HIDE_SPOT, yaw=180.0)


# ---------------------------------------------------------------------------------------------------------------
# wok_root_chair: seat
# ---------------------------------------------------------------------------------------------------------------

def wok_root_chair(P):
    """A chair grown from twisted wroshyr roots: twin-strand legs that flare out across the floor, armrests that
    grow back into the posts, a woven-branch back between fiddlehead-curled posts, a striped pelt thrown down the
    back and over the seat. Seat 0.46 (the pelt top), front edge z 0.30 -> foot 0.475."""
    FRONT = 0.30
    lean = lambda y: -0.205 - max(0.0, y - 0.45) * math.tan(math.radians(11))
    # seat platform: grown wood slab, bark sides
    n = P.n(28, 10)
    plan = []
    for k in range(n):
        a = 2 * math.pi * k / n
        c, s = math.cos(a), math.sin(a)
        plan.append((0.33 * math.copysign(abs(c) ** 0.55, c), 0.035 + 0.265 * math.copysign(abs(s) ** 0.55, s)))
    P.prism("wok_wood", plan, 0.375, 0.432, side_slot="wok_bark", bottom=True)
    # front legs: two strands twisting round each other, flaring onto the floor
    for sx in (-1, 1):
        cx, cz = sx * 0.25, 0.20
        for s in range(2):
            ph = s * math.pi + sx * 0.7
            ctrl = []
            for k in range(6):
                t = k / 5
                a = ph + sx * t * 2.2 * math.pi
                rr = 0.032 + 0.015 * t
                ctrl.append((cx + rr * math.cos(a) + sx * 0.05 * t * t, 0.40 - 0.36 * t, cz + rr * math.sin(a) + 0.04 * t * t))
            ctrl.append((cx + sx * (0.13 + 0.06 * s), 0.016, cz + 0.13 - 0.12 * s))
            _root(P, ctrl, 0.030, 0.015, seed=s + sx)
        P.sweep("wok_bronze", [(cx, 0.34, cz), (cx, 0.375, cz)], 0.072, sides=P.n(12, 6))
    # back legs: thick posts from a root flare to the fiddlehead curls, a thinner root spiralling up each
    for sx in (-1, 1):
        cx = sx * 0.25
        post = [(cx + sx * 0.03, 0.022, -0.20), (cx, 0.22, -0.19), (cx, 0.45, lean(0.45) + 0.01), (cx - sx * 0.01, 0.80, lean(0.80)),
                (cx, 1.12, lean(1.12)), (cx + sx * 0.03, 1.24, lean(1.24) + 0.01)]
        e1, e2 = (sx * 1.0, 0.0, 0.0), (0.0, 1.0, 0.0)
        cc = (cx + sx * 0.03 + sx * 0.075, 1.24, lean(1.24) + 0.01)
        curl = _spiral(cc, e1, e2, 0.075, 0.020, 180.0, -220.0, P.n(16, 10))
        path = _spline(post, P.n(5, 2)) + curl[1:]
        P.sweep("wok_bark", path, lambda t: 0.046 * (1 - 0.72 * t ** 1.4), sides=P.n(9, 5))
        if P.lod < 3:
            sp = []
            for k in range(12):
                t = k / 11
                a = sx * t * 3.0 * math.pi
                y = 0.03 + 0.85 * t
                sp.append((cx + 0.055 * math.cos(a), y, lean(y) + 0.015 + 0.055 * math.sin(a)))
            _root(P, sp, 0.022, 0.010, knob=0.08, seed=sx * 2)
        for k in range(3):
            a = math.radians(sx * 50 + (180 if sx < 0 else 0) + (k - 1) * 45 - 90 * sx)
            d = (math.cos(a), 0.0, math.sin(a))
            if d[2] > 0.3:
                d = (d[0], 0.0, -abs(d[2]))
            _root(P, [(cx, 0.16, -0.19), v_add((cx, 0.06, -0.19), v_mul(d, 0.10)), v_add((cx, 0.016, -0.19), v_mul(d, 0.26))],
                  0.034, 0.015, seed=k)
        for y in (0.66, 1.00):
            _ring(P, "wok_bronze", (cx, y, lean(y)), (0, 1, 0), 0.048, 0.012, n=P.n(14, 6), sides=P.n(6, 4))
    # armrests: rising from the front legs, curving back into the posts; a thin strand twined round each
    for sx in (-1, 1):
        arm = [(sx * 0.255, 0.38, 0.20), (sx * 0.29, 0.56, 0.21), (sx * 0.30, 0.655, 0.12), (sx * 0.295, 0.665, -0.05),
               (sx * 0.26, 0.69, lean(0.69) + 0.01)]
        path = _root(P, arm, 0.034, 0.032, knob=0.06, seed=sx)
        if P.lod < 3:
            tw = []
            m = len(path)
            for k in range(m):
                a, b = path[max(0, k - 1)], path[min(m - 1, k + 1)]
                t1, t2 = _basis(v_sub(b, a))
                ang = k * 0.9
                tw.append(v_add(path[k], v_add(v_mul(t1, 0.036 * math.cos(ang)), v_mul(t2, 0.036 * math.sin(ang)))))
            P.sweep("wok_bark", tw, lambda t: 0.011 * (1 - 0.5 * t), sides=P.n(6, 4))
        _lash(P, (sx * 0.30, 0.66, 0.03), (0, 0, 1), 0.034, wraps=4, r=0.006)
    # woven back: stakes and over-under withies between the posts
    stakes = (-0.15, -0.05, 0.05, 0.15)
    for x in stakes:
        pts = [(x, y, lean(y)) for y in (0.44, 0.70, 0.96, 1.13)]
        P.sweep("wok_wood", pts, 0.012, sides=P.n(6, 4))
    rows = [0.52 + 0.105 * k for k in range(6)] if P.lod < 3 else [0.57, 0.78, 0.99]
    for j, y in enumerate(rows):
        pts = []
        m = P.n(17, 6)
        for k in range(m + 1):
            x = -0.26 + 0.52 * k / m
            off = 0.016 * math.cos(math.pi * (x + 0.15) / 0.10 + j * math.pi)
            pts.append((x, y + 0.004 * math.sin(k), lean(y) + off))
        P.sweep("wok_wood", pts, 0.010, sides=P.n(6, 4))
    # crest: an arched branch over the back with a bronze glyph medallion
    zc = lean(1.17)
    arch = [(-0.25, 1.13, lean(1.13)), (-0.12, 1.20, zc), (0.0, 1.225, zc), (0.12, 1.20, zc), (0.25, 1.13, lean(1.13))]
    P.sweep("wok_wood", _spline(arch, P.n(4, 2)), 0.026, sides=P.n(8, 4))
    mc = (0.0, 1.215, zc + 0.03)
    P.lathe("wok_bronze", mc, [(0.0, -0.015), (0.075, -0.012), (0.08, 0.0), (0.072, 0.012), (0.0, 0.012)], r=(90, 0, 0),
            n=P.n(18, 8))
    P.disc("wok_glyph", v_add(mc, (0, 0, 0.0125)), 0.0, 0.066, fit=True, n=P.n(18, 8), r=(90, 0, 0))
    # the pelt: thrown from the top of the back, down it, across the seat and over the front edge
    ctrl = [(0.0, 1.10, lean(1.10) + 0.045), (0.0, 0.80, lean(0.80) + 0.045), (0.0, 0.52, lean(0.52) + 0.045),
            (0.0, 0.452, -0.10), (0.0, 0.448, 0.10), (0.0, 0.44, 0.285), (0.0, 0.39, 0.335), (0.0, 0.29, 0.348)]

    def width(t):
        w = 0.25 + 0.018 * math.sin(t * 31.0) + 0.012 * math.sin(t * 13.0 + 1.0)
        return w * (1.0 - 0.25 * smoothstep(0.85, 1.0, t) - 0.18 * (1 - smoothstep(0.0, 0.08, t)))
    _pelt(P, "wok_pelt", ctrl, (1.0, 0.0, 0.0), width, th=0.024)
    # soft fur tassels along the pelt's front edge
    if P.lod < 2:
        for k in range(6):
            x = -0.175 + 0.07 * k
            ln = 0.05 + 0.015 * (k % 2)
            P.lathe("wok_pelt", (x, 0.292 - ln, 0.350), [(0.0, 0.0), (0.012, ln * 0.25), (0.02, ln * 0.7), (0.014, ln), (0.0, ln + 0.004)],
                    n=6)
    # glow-caps sprouting from the back-left root flare
    if P.lod < 3:
        _glowcaps(P, (-0.36, 0.0, -0.33), 5, 0.028, seed=0.4)
    seat_hardpoint(P, FRONT)


# ---------------------------------------------------------------------------------------------------------------
# wok_glow_lantern: lamp
# ---------------------------------------------------------------------------------------------------------------

def wok_glow_lantern(P):
    """A woven basket lantern of glowing fungus pods hanging from a carved wroshyr crook (2.1 m) on a root
    foot; a fiddlehead branch curls up behind, bracket fungus glows on the foot. Light at the pod cluster."""
    H = 1.86
    staff = _spline([(0.0, 0.0, 0.0), (0.012, 0.5, -0.01), (-0.01, 1.0, 0.008), (0.0, 1.45, 0.0), (0.0, H, 0.0)], P.n(5, 2))
    nk = P.n(14, 6)
    crook = [(0.0, H + 0.21 * math.sin(math.radians(180.0 * k / nk)), 0.21 - 0.21 * math.cos(math.radians(180.0 * k / nk)))
             for k in range(1, nk + 1)]
    tip = (0.0, H - 0.07, 0.425)
    path = staff + crook + [tip]
    P.sweep("wok_wood", path, lambda t: 0.042 * (1 - 0.45 * t), sides=P.n(10, 5))
    P.sphere("wok_bronze", v_add(tip, (0, -0.008, 0)), 0.026, n=P.n(10, 5))
    _ring(P, "wok_bronze", (0.0, H - 0.11, 0.425), (0, 1, 0), 0.016, 0.006, n=P.n(10, 5), sides=4)
    # carved sleeve and bronze collars, a cord-wrapped grip
    P.lathe("wok_carve", (0, 0.58, 0), [(0.047, 0.0), (0.047, 0.20)], utiles=3, vscale=0.20, n=P.n(16, 6))
    for y in (0.575, 0.785, 0.31):
        P.lathe("wok_bronze", (0, y, 0), [(0.04, -0.016), (0.055, -0.008), (0.055, 0.008), (0.04, 0.016)], n=P.n(16, 6))
    if P.lod < 2:
        for k in range(7):
            _ring(P, "wok_cord", (0.0, 1.02 + 0.017 * k, 0.0), (0, 1, 0), 0.036, 0.007, n=P.n(12, 6), sides=4)
    # root foot
    for k in range(5):
        a = math.radians(18 + 72 * k)
        d = (math.cos(a), 0.0, math.sin(a))
        _root(P, [(0.0, 0.34, 0.0), v_add((0.0, 0.16, 0.0), v_mul(d, 0.10)), v_add((0.0, 0.05, 0.0), v_mul(d, 0.24)),
                  v_add((0.0, 0.016, 0.0), v_mul(d, 0.38))], 0.040, 0.016, seed=k * 1.7)
    # fiddlehead branch curling up behind
    e1, e2 = (0.0, 0.0, -1.0), (0.0, 1.0, 0.0)
    cc = (0.0, 1.80, -0.17)
    curl = _spiral(cc, e1, e2, 0.10, 0.026, 200.0, 200.0 - 400.0, P.n(26, 11))      # rises, rolls back over
    br = _spline([(0.0, 1.46, -0.01), (0.0, 1.60, -0.08), curl[0]], P.n(4, 2))
    P.sweep("wok_wood", br + curl[1:], lambda t: 0.024 * (1 - 0.62 * t), sides=P.n(8, 4))
    # bracket fungus on the staff foot
    if P.lod < 3:
        for k, (y, a, s) in enumerate(((0.42, 60, 0.07), (0.48, 120, 0.05), (0.38, 300, 0.06), (0.24, 210, 0.05))):
            aa = math.radians(a)
            c = (0.035 * math.cos(aa), y, 0.035 * math.sin(aa))
            P.sphere("wok_fungus", c, s, lat0=0, lat1=90, sy=0.32, n=P.n(12, 6))
            P.disc("wok_fungus", c, 0.0, s, n=P.n(12, 6), down=True)
    # the lantern: a woven diamond cage (twin helices of cane), cord rings, a woven cap and a moss bowl of pods
    LC = (0.0, 1.40, 0.425)
    prof = [(0.03, -0.22), (0.10, -0.185), (0.150, -0.11), (0.168, -0.02), (0.155, 0.07), (0.115, 0.14), (0.062, 0.19)]
    dense = _spline([(r, y, 0.0) for r, y in prof], P.n(3, 1))
    nr = P.n(9, 5)
    for sgn in (1, -1):
        for k in range(nr):
            a0 = 360.0 * k / nr
            pts = []
            for j, (r, y, _) in enumerate(dense):
                s = j / (len(dense) - 1)
                a = math.radians(a0 + sgn * 110.0 * s)
                pts.append((LC[0] + r * math.cos(a), LC[1] + y, LC[2] + r * math.sin(a)))
            P.sweep("wok_weave", pts, 0.0055, sides=P.n(5, 3))
    for y, r in ((-0.185, 0.10), (-0.02, 0.170), (0.14, 0.117)):
        _ring(P, "wok_cord", (LC[0], LC[1] + y, LC[2]), (0, 1, 0), r, 0.008, n=P.n(20, 8), sides=P.n(5, 3))
    P.lathe("wok_weave", LC, [(0.068, 0.175), (0.06, 0.215), (0.035, 0.245), (0.0, 0.252)], n=P.n(16, 6))
    P.disc("wok_weave", v_add(LC, (0, 0.175, 0)), 0.0, 0.068, n=P.n(16, 6), down=True)
    _ring(P, "wok_bronze", v_add(LC, (0, 0.19, 0)), (0, 1, 0), 0.064, 0.008, n=P.n(16, 6), sides=P.n(5, 3))
    _ring(P, "wok_bronze", v_add(LC, (0, 0.262, 0)), (0, 0, 1), 0.012, 0.004, n=8, sides=4)
    P.sweep("wok_cord", [v_add(LC, (0, 0.27, 0)), (0.0, H - 0.115, 0.425)], 0.005, sides=4)
    P.lathe("wok_weave", LC, [(0.0, -0.26), (0.05, -0.245), (0.095, -0.20), (0.105, -0.175), (0.0, -0.175)], n=P.n(16, 6))
    P.disc("wok_bark", v_add(LC, (0, -0.172, 0)), 0.0, 0.098, n=P.n(16, 6))
    # glowing pods: a tall central pod and capped pods round it, a soft halo
    P.sphere("wok_fungus", v_add(LC, (0, -0.05, 0)), 0.05, sy=1.9, n=P.n(12, 6))
    for k in range(6 if P.lod < 2 else 3):
        a = math.radians(30 + 60 * k * (1 if P.lod < 2 else 2))
        rr = 0.07 + 0.012 * (k % 2)
        foot = (LC[0] + rr * math.cos(a), LC[1] - 0.172, LC[2] + rr * math.sin(a))
        h = 0.06 + 0.035 * ((k * 5) % 3)
        cap = v_add(foot, (0.01 * math.cos(a), h, 0.01 * math.sin(a)))
        P.sweep("wok_fungus", [foot, cap], 0.008, sides=P.n(5, 3))
        P.sphere("wok_fungus", cap, 0.032 + 0.007 * (k % 3), lat0=-25, lat1=90, sy=0.65, n=P.n(10, 5))
        P.disc("wok_fungus", v_add(cap, (0, -0.009, 0)), 0.0, 0.031, n=P.n(10, 5), down=True)
    P.sphere("wok_glow", v_add(LC, (0, -0.045, 0)), 0.125, n=P.n(16, 8))   # glow halo (far side culled)
    if P.lod < 2:                                                     # pods hanging from the cap
        for k in range(5):
            a = math.radians(72 * k + 20)
            top = (LC[0] + 0.035 * math.cos(a), LC[1] + 0.175, LC[2] + 0.035 * math.sin(a))
            bot = v_add(top, (0.025 * math.cos(a), -0.05 - 0.02 * (k % 2), 0.025 * math.sin(a)))
            P.sweep("wok_fungus", [top, bot], 0.005, sides=4)
            _ell(P, "wok_fungus", bot, 0.017, sy=1.4, n=6, rows=4)
    # charms under the lantern: cord, bone bead, a fur tassel
    if P.lod < 2:
        b0 = v_add(LC, (0, -0.258, 0))
        P.sweep("wok_cord", [b0, v_add(b0, (0, -0.10, 0))], 0.004, sides=4)
        P.sphere("wok_bone", v_add(b0, (0, -0.05, 0)), 0.014, n=6)
        P.lathe("wok_fur", v_add(b0, (0, -0.21, 0)), [(0.0, 0.0), (0.03, 0.02), (0.022, 0.08), (0.012, 0.11), (0.0, 0.115)],
                n=P.n(8, 5))
    light_hardpoint(P, v_add(LC, (0, -0.06, 0)))


# ---------------------------------------------------------------------------------------------------------------
# wok_bowcaster_rack: decor
# ---------------------------------------------------------------------------------------------------------------

def _bowcaster(P):
    """A bowcaster in weapon space: barrel along +x (muzzle), +y up (scope), +z right. ~0.95 m long, the bow
    spanning 0.6 m. Built through P.xform."""
    # stock: lofted rounded sections, a bronze butt plate
    secs = [(-0.47, 0.11, 0.080, -0.02), (-0.42, 0.105, 0.078, -0.02), (-0.33, 0.08, 0.058, -0.005), (-0.24, 0.065, 0.048, 0.003),
            (-0.17, 0.06, 0.044, 0.005)]
    rings = []
    for x, h, w, yc in secs:
        ring = []
        for k in range(10):
            a = 2 * math.pi * k / 10
            c, s = math.cos(a), math.sin(a)
            ring.append((x, yc + h / 2 * math.copysign(abs(s) ** 0.6, s), w / 2 * math.copysign(abs(c) ** 0.6, c)))
        rings.append(ring)
    P.loft("wok_wood", rings, closed=True)
    P.box("wok_bronze", (-0.474, -0.02, 0.0), (0.006, 0.058, 0.042))
    for sz in (-1, 1):
        P.box("wok_bronze", (-0.36, -0.01, sz * 0.034), (0.07, 0.012, 0.003), r=(0, sz * 10, 0))
    # receiver body with bronze side plates and rivets
    P.rbox("wok_metal", (0.0, 0.01, 0.0), (0.19, 0.035, 0.034), 0.010)
    for sz in (-1, 1):
        P.box("wok_bronze", (-0.02, 0.012, sz * 0.035), (0.12, 0.022, 0.003))
        if P.lod < 2:
            for x in (-0.12, -0.04, 0.04, 0.10):
                P.sphere("wok_metal", (x, 0.026, sz * 0.039), 0.005, n=5)
    # grip (leather, cord wrapped), trigger guard
    g0, g1 = (-0.10, -0.02, 0.0), (-0.14, -0.13, 0.0)
    P.sweep("wok_leather", [g0, g1], 0.019, sides=P.n(8, 4))
    if P.lod < 2:
        for k in range(4):
            _ring(P, "wok_cord", v_add(g0, v_mul(v_sub(g1, g0), 0.2 + 0.2 * k)), v_sub(g1, g0), 0.019, 0.004, n=8, sides=4)
    if P.lod < 3:
        P.sweep("wok_metal", [(-0.08, -0.025, 0.0), (-0.06, -0.075, 0.0), (-0.02, -0.08, 0.0), (0.0, -0.025, 0.0)], 0.005,
                sides=P.n(5, 3))
    # barrel with bronze bands and a flared muzzle; an ammo canister underneath
    P.sweep("wok_metal", [(0.18, 0.012, 0.0), (0.46, 0.012, 0.0)], 0.019, sides=P.n(10, 5))
    P.lathe("wok_metal", (0.46, 0.012, 0.0), [(0.0, 0.0), (0.024, 0.0), (0.030, 0.03), (0.022, 0.035), (0.0, 0.035)],
            r=(0, 0, -90), n=P.n(10, 5))
    for x in ((0.22, 0.38) if P.lod < 3 else ()):
        P.lathe("wok_bronze", (x, 0.012, 0.0), [(0.019, -0.012), (0.025, -0.006), (0.025, 0.006), (0.019, 0.012)], r=(0, 0, -90),
                n=P.n(10, 5))
    P.rbox("wok_bronze", (0.10, -0.045, 0.0), (0.05, 0.02, 0.022), 0.008)
    # scope on two mounts, glowing lenses
    P.sweep("wok_metal", [(-0.07, 0.085, 0.0), (0.13, 0.085, 0.0)], 0.017, sides=P.n(10, 5))
    for x in (-0.03, 0.09):
        P.box("wok_metal", (x, 0.058, 0.0), (0.012, 0.014, 0.008))
    for x, sg in ((-0.072, -1), (0.132, 1)):
        P.disc("wok_fungus", (x, 0.085, 0.0), 0.0, 0.016, n=P.n(10, 5), r=(0, 0, -90 * sg))
    # the bow: a bronze-bound block, two recurved arms, polarizing orbs at the tips, the string
    P.box("wok_metal", (0.33, 0.012, 0.0), (0.035, 0.03, 0.045))
    for sz in (-1, 1):
        arm = [(0.33, 0.012, sz * 0.04), (0.315, 0.014, sz * 0.13), (0.285, 0.016, sz * 0.22), (0.27, 0.016, sz * 0.27),
               (0.285, 0.014, sz * 0.305)]
        path = _spline(arm, P.n(4, 2))
        P.sweep("wok_metal", path, lambda t: 0.017 * (1 - 0.45 * t), sides=P.n(8, 4))
        if P.lod < 3:
            P.sweep("wok_bronze", [path[1], path[2]], 0.0185, sides=P.n(8, 4))
        tip = (0.29, 0.014, sz * 0.315)
        P.sphere("wok_bronze", tip, 0.028, n=P.n(10, 6))
        if P.lod < 3:
            P.lathe("wok_fungus", tip, [(0.0285, -0.006), (0.0295, 0.0), (0.0285, 0.006)], r=(90, 0, 0), n=P.n(10, 6))
        P.sweep("wok_cord", [v_add(tip, (-0.02, 0, -sz * 0.012)), (0.06, 0.05, sz * 0.012)], 0.003, sides=4)
    P.box("wok_bronze", (0.06, 0.05, 0.0), (0.02, 0.012, 0.02))
    # loaded quarrel along the top and the cocking lever on the right side
    if P.lod >= 3:
        return
    P.sweep("wok_metal", [(0.06, 0.056, 0.0), (0.40, 0.056, 0.0)], 0.004, sides=4)
    P.cone("wok_bronze", (0.40, 0.056, 0.0), (0.435, 0.056, 0.0), 0.008, n=5)
    P.sweep("wok_metal", [(0.02, 0.01, 0.036), (-0.06, 0.02, 0.05), (-0.09, 0.035, 0.05)], 0.006, sides=P.n(5, 3))
    P.sphere("wok_bronze", (-0.09, 0.035, 0.05), 0.012, n=6)


def wok_bowcaster_rack(P):
    """A rack of forked wroshyr posts on log feet: the bowcaster laid on its side across two pegs (the bow
    upright), a bandolier of ammo boxes hung over the carved crossbar, a shelf with a basket of quarrels."""
    for sx in (-1, 1):
        x = sx * 0.46
        _root(P, [(x, 0.068, -0.27), (x + 0.005, 0.072, 0.0), (x, 0.068, 0.29)], 0.07, 0.064, knob=0.06, seed=sx)
        P.disc("wok_endgrain", (x, 0.068, 0.29), 0.0, 0.064, fit=True, n=P.n(12, 5), r=(90, 0, 0))
        P.disc("wok_endgrain", (x, 0.068, -0.27), 0.0, 0.066, fit=True, n=P.n(12, 5), r=(-90, 0, 0))
        post = _spline([(x, 0.10, 0.0), (x + sx * 0.006, 0.6, 0.004), (x, 1.24, 0.0)], P.n(4, 2))
        P.sweep("wok_wood", post, lambda t: 0.050 * (1 - 0.2 * t), sides=P.n(10, 5))
        for sgn in (-1, 1):
            _root(P, [(x, 1.20, 0.0), (x + sgn * 0.04, 1.36, 0.0), (x + sgn * 0.075, 1.50, 0.0)], 0.034, 0.016, slot="wok_wood",
                  knob=0.05, seed=sgn, sides=P.n(8, 3))
        _lash(P, (x, 1.12, 0.0), (0, 1, 0), 0.045, wraps=4 if P.lod < 2 else 2)
        # pegs for the weapon and the shelf
        for y, ln in ((0.74, 0.22), (0.20, 0.17)):
            P.sweep("wok_wood", [(x, y, 0.02), (x, y + 0.004, ln)], 0.017, sides=P.n(7, 4))
            P.sphere("wok_bronze", (x, y + 0.012, ln), 0.024, n=P.n(8, 5))
    # carved crossbar resting in the forks
    P.sweep("wok_wood", [(-0.66, 1.42, 0.0), (0.66, 1.42, 0.0)], 0.036, sides=P.n(10, 5))
    P.sweep("wok_carve", [(-0.26, 1.42, 0.0), (0.26, 1.42, 0.0)], 0.0395, sides=P.n(12, 5))
    for x in (-0.66, 0.66):
        P.sphere("wok_bronze", (x, 1.42, 0.0), 0.040, n=P.n(10, 5))
    for x in (-0.27, 0.27):
        _ring(P, "wok_bronze", (x, 1.42, 0.0), (1, 0, 0), 0.040, 0.007, n=P.n(12, 6), sides=4)
    P.lathe("wok_bronze", (0.0, 1.42, 0.05), [(0.0, -0.012), (0.07, -0.01), (0.075, 0.0), (0.068, 0.01), (0.0, 0.01)],
            r=(90, 0, 0), n=P.n(18, 6))
    P.disc("wok_glyph", (0.0, 1.42, 0.0605), 0.0, 0.062, fit=True, n=P.n(18, 8), r=(90, 0, 0))
    # shelf plank on the low pegs: a quarrel basket and a bronze-capped pouch
    P.box("wok_wood", (0.0, 0.235, 0.085), (0.52, 0.018, 0.085))
    qc = (-0.24, 0.253, 0.085)
    _basket(P, qc, [(0.07, 0.0), (0.085, 0.06), (0.08, 0.15)], slot="wok_weave_band", rims=(0.03,))
    if P.lod < 3:
        for k in range(7 if P.lod < 2 else 3):
            a = k * 2.4
            rr = 0.035 * math.sqrt((k + 0.5) / 7)
            b = (qc[0] + rr * math.cos(a), qc[1] + 0.02, qc[2] + rr * math.sin(a))
            t = v_add(b, (0.02 * math.cos(a), 0.30 + 0.02 * (k % 3), 0.02 * math.sin(a)))
            P.sweep("wok_metal", [b, t], 0.004, sides=4)
            P.cone("wok_bronze", t, v_add(t, v_mul(v_norm(v_sub(t, b)), 0.035)), 0.008, n=5)
    P.rbox("wok_leather", (0.14, 0.303, 0.085), (0.07, 0.05, 0.05), 0.03, puff=0.008)
    P.lathe("wok_bronze", (0.14, 0.345, 0.085), [(0.0, 0.0), (0.05, 0.0), (0.045, 0.02), (0.0, 0.025)], n=P.n(12, 6))
    # the bowcaster on its side across the pegs (bow upright), scope toward the room
    SC = 1.12
    y0, z0 = 0.74 + 0.017 + 0.025 * SC, 0.12
    old = P.xform
    P.xform = lambda p: v_add(rot(v_mul(p, SC), 90, 0, 0), (0.0, y0, z0))
    _bowcaster(P)
    P.xform = old
    # bandolier hung over the crossbar: a strap passing over the bar twice, sagging in a U, ammo boxes on it
    ctrl = [(-0.36, 1.37, -0.045), (-0.36, 1.465, -0.005), (-0.36, 1.41, 0.05), (-0.34, 1.25, 0.062), (-0.21, 1.10, 0.066),
            (-0.05, 1.11, 0.066), (0.05, 1.25, 0.062), (0.07, 1.41, 0.05), (0.07, 1.465, -0.005), (0.07, 1.37, -0.045)]
    path = _spline(ctrl, P.n(4, 2))
    strap = [(0.12, 1.0), (-0.12, 1.0), (-0.12, -1.0), (0.12, -1.0)]
    P.sweep("wok_leather", path, 0.030, profile=strap, twist_up=(0.0, 0.0, -1.0))
    u = _spline(ctrl[3:7], 12)
    nb = 6 if P.lod < 2 else 3
    for k in range(nb):
        t = (k + 0.5) / nb
        i = int(t * (len(u) - 1))
        p, q = u[i], u[min(len(u) - 1, i + 1)]
        ang = math.degrees(math.atan2(q[1] - p[1], q[0] - p[0]))
        c = v_add(p, (0, 0, 0.02))
        P.box("wok_metal", c, (0.021, 0.034, 0.016), r=(0, 0, ang))
        P.box("wok_bronze", v_add(c, (0, 0, 0.017)), (0.008, 0.026, 0.002), r=(0, 0, ang), bottom=False)
    P.box("wok_bronze", v_add(_spline(ctrl[6:9], 6)[3], (0, 0, 0.01)), (0.026, 0.02, 0.008))


# ---------------------------------------------------------------------------------------------------------------
# wok_carved_totem: decor
# ---------------------------------------------------------------------------------------------------------------

def _face(P, yc, R, mood):
    """A carved Wookiee face on the front of a trunk of radius R at height yc (0.46 m tall): a mask plate ringed by
    a mane of carved tufts, a heavy brow over dark sockets, cheeks, a long muzzle with a broad dark nose, and a
    mouth: roaring with fangs (roar), shut under a braided beard (elder), or shut under a diadem (crown)."""
    lo = P.lod >= 2
    z0 = R
    # mask plate and the mane
    P.rbox("wok_wood", (0.0, yc, z0 - 0.03), (0.15, 0.215, 0.07), 0.06, puff=0.02, seg=P.n(4, 2))
    tufts = 16 if P.lod < 2 else 8 if P.lod < 3 else 6
    for k in range(tufts):
        a = math.radians(-60.0 + 300.0 * (k + 0.5) / tufts)          # all round except under the chin
        ca, sa = math.cos(a), math.sin(a)
        ex, ey = 0.165 * ca, 0.235 * sa
        bz = math.sqrt(max(0.0, R * R - ex * ex)) + 0.01
        b = (ex, yc + ey, bz)
        d = v_norm((ca, sa * 0.9 - 0.35, 0.25))
        ln = 0.075 + 0.025 * ((k * 7) % 3) / 2
        P.cone("wok_wood", b, v_add(b, v_mul(d, ln)), 0.034, n=P.n(6, 4))
    # brow ridge (V-shaped when roaring) over dark eye sockets
    m = P.n(10, 4)
    drop = 0.035 if mood == "roar" else 0.0
    brow = []
    for k in range(m + 1):
        t = k / m
        x = -0.135 + 0.27 * t
        brow.append((x, yc + 0.085 - drop * (1 - abs(2 * t - 1)) + 0.012 * math.sin(t * math.pi), z0 + 0.075 - 0.25 * x * x))
    P.sweep("wok_wood", brow, lambda t: 0.024 + 0.014 * math.sin(math.pi * t), sides=P.n(8, 4))
    for sx in (-1, 1):
        ec = (sx * 0.062, yc + 0.035, z0 + 0.052)
        _ell(P, "wok_bark", ec, 0.036, sy=0.72, n=P.n(10, 5), rows=P.n(6, 3))
        if mood == "roar":
            _ell(P, "wok_fungus", v_add(ec, (0, 0, 0.022)), 0.017, n=P.n(8, 5), rows=P.n(5, 3))
        elif P.lod < 3:                                               # closed lids
            _ell(P, "wok_wood", v_add(ec, (0, 0.004, 0.006)), 0.033, sy=0.55, n=P.n(10, 5), rows=P.n(5, 3), r_=(-20, 0, 0))
        if P.lod < 3:
            _ell(P, "wok_wood", (sx * 0.08, yc - 0.035, z0 + 0.045), 0.05, sy=0.85, n=P.n(10, 5), rows=P.n(6, 3))
    # muzzle and broad nose
    _ell(P, "wok_wood", (0.0, yc - 0.055, z0 + 0.07), 0.075, sy=0.8, n=P.n(12, 6), rows=P.n(8, 4))
    if P.lod < 2:
        P.rbox("wok_bark", (0.0, yc - 0.012, z0 + 0.128), (0.042, 0.022, 0.024), 0.016, seg=2)
    else:
        P.box("wok_bark", (0.0, yc - 0.012, z0 + 0.128), (0.04, 0.02, 0.022))
    if mood == "roar":
        _ell(P, "wok_bark", (0.0, yc - 0.118, z0 + 0.075), 0.068, sy=0.55, n=P.n(12, 6), rows=P.n(6, 3), r_=(90, 0, 0))
        for sx in ((-1, 1) if P.lod < 3 else ()):
            for x, ln in ((0.050, 0.046), (0.022, 0.026)):
                P.cone("wok_bone", (sx * x, yc - 0.086, z0 + 0.128), (sx * x, yc - 0.086 - ln, z0 + 0.132), 0.010, n=5)
                P.cone("wok_bone", (sx * x, yc - 0.152, z0 + 0.122), (sx * x, yc - 0.152 + ln * 0.8, z0 + 0.126), 0.009, n=5)
        _ell(P, "wok_wood", (0.0, yc - 0.165, z0 + 0.06), 0.075, sy=0.42, n=P.n(12, 6), rows=P.n(6, 3))
    else:
        P.sweep("wok_bark", [(-0.055, yc - 0.105, z0 + 0.10), (0.0, yc - 0.115, z0 + 0.118), (0.055, yc - 0.105, z0 + 0.10)], 0.007,
                sides=4)
        _ell(P, "wok_wood", (0.0, yc - 0.15, z0 + 0.035), 0.07, sy=0.6, n=P.n(12, 6), rows=P.n(6, 3))
    if mood == "elder" and not lo:
        # a braided beard: three plaited strands to a bronze bead
        b0, b1 = (0.0, yc - 0.18, z0 + 0.075), (0.0, yc - 0.33, z0 + 0.06)
        for k in range(3):
            pts = []
            for j in range(13):
                t = j / 12
                ang = t * 4 * math.pi + k * 2 * math.pi / 3
                c = v_add(b0, v_mul(v_sub(b1, b0), t))
                pts.append(v_add(c, (0.016 * math.cos(ang) * (1 - 0.4 * t), 0.0, 0.012 * math.sin(ang))))
            P.sweep("wok_wood", pts, 0.012, sides=5)
        P.sphere("wok_bronze", v_add(b1, (0, -0.012, 0)), 0.022, n=8)
    if mood == "crown" and not lo:
        # a bronze diadem across the brow with a glowing jewel
        dia = [(x, yc + 0.135 - 0.2 * x * x, math.sqrt(max(0.0, (R + 0.035) ** 2 - x * x)) + 0.02) for x in
               [-0.15 + 0.3 * k / 10 for k in range(11)]]
        P.sweep("wok_bronze", dia, 0.012, sides=5)
        _ell(P, "wok_fungus", (0.0, yc + 0.14, z0 + 0.075), 0.022, n=8, rows=4)
    if not lo:
        for sx in (-1, 1):                                            # bronze rings in the mane like earrings
            _ring(P, "wok_bronze", (sx * 0.20, yc - 0.06, z0 - 0.04), (0, 0, 1), 0.026, 0.006, n=10, sides=4)


def wok_carved_totem(P):
    """A 2.5 m wroshyr totem on a root flare: a braided elder, a roaring warrior with glowing eyes, a crowned
    ancestor spreading carved branch wings, glyph bands bound in bronze between them, and a branching crown round
    a cluster of glow-caps. A glyph medallion and carved panels on the back."""
    n = P.n(24, 8)
    RB = 0.19                                                          # glyph band radius; tiers neck down under it
    tiers = [(0.18, 0.80, 0.22), (0.92, 1.44, 0.205), (1.56, 2.02, 0.19)]
    bands = [(0.80, 0.92), (1.44, 1.56), (2.02, 2.10)]
    for y0, y1, r in tiers:
        h = y1 - y0
        P.lathe("wok_wood", (0, y0, 0), [(RB - 0.003, 0.0), (r * 0.97, h * 0.12), (r, h * 0.5), (r * 0.97, h * 0.88), (RB - 0.003, h)],
                n=n)
    for y0, y1 in bands:
        P.lathe("wok_carve", (0, y0, 0), [(RB, 0.0), (RB, y1 - y0)], n=n, utiles=4, vscale=y1 - y0)
        for y in ((y0, y1) if P.lod < 3 else ()):
            P.lathe("wok_bronze", (0, y, 0), [(RB - 0.004, -0.012), (RB + 0.016, -0.006), (RB + 0.016, 0.006), (RB - 0.004, 0.012)], n=n)
    # root flare base
    P.lathe("wok_bark", (0, 0, 0), [(0.30, 0.0), (0.27, 0.04), (0.235, 0.10), (0.215, 0.18), (0.0, 0.18)], n=n)
    nroot = 7 if P.lod < 3 else 4
    for k in range(nroot):
        a = math.radians(10 + 360.0 * k / nroot)
        d = (math.cos(a), 0.0, math.sin(a))
        _root(P, [v_add((0, 0.16, 0), v_mul(d, 0.18)), v_add((0, 0.06, 0), v_mul(d, 0.32)), v_add((0, 0.018, 0), v_mul(d, 0.46))],
              0.06, 0.018, seed=k * 1.3, per=P.n(4, 2), sides=P.n(8, 4))
    # three faces
    _face(P, 0.50, 0.22, "elder")
    _face(P, 1.18, 0.205, "roar")
    _face(P, 1.78, 0.19, "crown")
    # carved wings: branch arms rising behind the top face, curling at the tips, with leaf blades
    for sx in (-1, 1):
        e1, e2 = (sx * 1.0, 0.0, 0.0), (0.0, 1.0, 0.0)
        arm = _spline([(sx * 0.17, 1.66, -0.02), (sx * 0.34, 1.78, 0.0), (sx * 0.47, 1.99, 0.0)], P.n(4, 2))
        cc = (sx * (0.47 + 0.065), 1.99, 0.0)                     # fiddlehead unrolling outward
        curl = _spiral(cc, e1, e2, 0.065, 0.026, 180.0, 180.0 - 300.0, P.n(14, 8))
        P.sweep("wok_wood", arm + curl[1:], lambda t: 0.042 * (1 - 0.62 * t), sides=P.n(8, 4))
        if P.lod < 3:
            for k, t in enumerate((0.25, 0.5, 0.75)):
                i = int(t * (len(arm) - 1))
                b = arm[i]
                d = v_norm((sx * 0.55, -0.8 + 0.22 * k, 0.0))
                tip = v_add(b, v_mul(d, 0.14))
                mid = v_mul(v_add(b, tip), 0.5)
                wd = v_mul(v_norm(v_cross(d, (0, 0, 1))), 0.03)
                _strip(P, "wok_wood", [b, v_add(mid, wd), tip], [b, v_sub(mid, wd), tip], (0, 0, 1), 0.014)
    # crown: a bulb, upturned branch spikes round a glow-cap cluster, charms on the top band
    P.lathe("wok_wood", (0, 2.10, 0), [(RB, 0.0), (0.21, 0.04), (0.17, 0.12), (0.10, 0.16), (0.0, 0.17)], n=n)
    for k in range(6):
        a = math.radians(30 + 60 * k)
        d = (math.cos(a), 0.0, math.sin(a))
        b = v_add((0, 2.17, 0), v_mul(d, 0.12))
        if P.lod < 3:
            _root(P, [b, v_add((0, 2.29, 0), v_mul(d, 0.22)), v_add((0, 2.42, 0), v_mul(d, 0.26)), v_add((0, 2.48, 0), v_mul(d, 0.22))],
                  0.032, 0.009, slot="wok_wood", knob=0.05, seed=k, per=P.n(4, 2), sides=P.n(7, 4))
        else:
            P.cone("wok_wood", b, v_add((0, 2.46, 0), v_mul(d, 0.25)), 0.03, n=4)
    if P.lod < 3:
        _glowcaps(P, (0.0, 2.255, 0.0), 6, 0.04, seed=1.1, spread=0.07)
    else:
        _ell(P, "wok_fungus", (0.0, 2.29, 0.0), 0.07, sy=0.6, n=6, rows=3)
    for k in range(4):
        a = math.radians(45 + 90 * k)
        _charm(P, (0.215 * math.cos(a), 2.09, 0.215 * math.sin(a)), 0.16 + 0.04 * (k % 2))
    # back: a glyph medallion and carved panels
    if P.lod >= 3:
        return
    P.lathe("wok_bronze", (0, 1.18, -0.205), [(0.0, -0.014), (0.09, -0.012), (0.095, 0.0), (0.085, 0.012), (0.0, 0.012)],
            r=(-90, 0, 0), n=P.n(18, 8))
    P.disc("wok_glyph", (0, 1.18, -0.218), 0.0, 0.08, fit=True, n=P.n(18, 8), r=(-90, 0, 0))
    for (y0, y1, r) in (tiers[0], tiers[2]):
        h = y1 - y0
        P.lathe("wok_carve", (0, y0 + h * 0.2, 0), [(r * 0.985 + 0.004, 0.0), (r + 0.004, h * 0.3), (r * 0.985 + 0.004, h * 0.6)],
                a0=242, a1=298, n=P.n(8, 3), utiles=1, vscale=h * 0.2)


# ---------------------------------------------------------------------------------------------------------------
# wok_storage_baskets: decor
# ---------------------------------------------------------------------------------------------------------------

def _lid(P, c, r, h, knob=True, slot="wok_weave"):
    """A woven basket lid: overhanging rim, shallow dome with a flat top, a carved wooden knob."""
    n = P.n(24, 8)
    P.lathe(slot, c, [(r + 0.012, -0.03), (r + 0.016, 0.0), (r * 0.85, h * 0.6), (r * 0.45, h), (0.0, h)], n=n)
    P.disc(slot, v_add(c, (0, -0.03, 0)), r - 0.01, r + 0.012, n=n, down=True)
    _ring(P, "wok_cord", v_add(c, (0, -0.012, 0)), (0, 1, 0), r + 0.016, 0.009, n=n, sides=P.n(5, 3))
    if knob:
        P.lathe("wok_wood", v_add(c, (0, h, 0)), [(0.0, 0.0), (0.035, 0.0), (0.02, 0.025), (0.03, 0.045), (0.0, 0.06)],
                n=P.n(10, 5))


def wok_storage_baskets(P):
    """Treehouse stores: a big lidded basket with a smaller one stacked on it, strapped with a bronze buckle; a
    tall basket of carved staffs and a fur; a low bowl-basket of glow-caps; a net bag of gourds on the floor."""
    # big basket A (dyed band) with rope handles and a lid
    A = (-0.16, 0.0, -0.06)
    profA = [(0.27, 0.0), (0.32, 0.08), (0.34, 0.20), (0.33, 0.33), (0.30, 0.42)]
    P.lathe("wok_weave_band", A, [(0.0, 0.0)] + profA, n=P.n(28, 10))
    for y, rr in ((0.06, 0.312), (0.30, 0.337)):
        _ring(P, "wok_cord", v_add(A, (0, y, 0)), (0, 1, 0), rr, 0.009, n=P.n(28, 10), sides=P.n(5, 3))
    _lid(P, v_add(A, (0, 0.42, 0)), 0.30, 0.07, knob=False)
    for sx in (-1, 1):
        hc = v_add(A, (sx * 0.345, 0.27, 0.0))
        loop = [v_add(hc, (0.0, 0.05 * math.sin(math.radians(a)), 0.07 * math.cos(math.radians(a))))
                for a in range(0, 181, 30)]
        loop = [v_add(p, (sx * 0.035 * math.sin(math.radians(a)), 0, 0)) for p, a in zip(loop, range(0, 181, 30))]
        P.sweep("wok_cord", loop, 0.012, sides=P.n(6, 4))
    # leather strap over both baskets with a bronze buckle
    # small basket B stacked on A's flat lid top, with its own lid and knob
    B = (-0.12, 0.49, -0.04)
    profB = [(0.17, 0.0), (0.205, 0.07), (0.215, 0.17), (0.20, 0.26)]
    P.lathe("wok_weave", B, [(0.0, 0.0)] + profB, n=P.n(24, 8))
    _ring(P, "wok_cord", v_add(B, (0, 0.13, 0)), (0, 1, 0), 0.214, 0.008, n=P.n(24, 8), sides=P.n(5, 3))
    _lid(P, v_add(B, (0, 0.26, 0)), 0.20, 0.06)
    # a leather strap over B's lid (beside the knob) and down its sides, a bronze buckle
    zs = 0.06
    lid_h = lambda rho: 0.0 if rho >= 0.216 else 0.036 * (0.216 - rho) / 0.046 if rho >= 0.17 else 0.036 + 0.024 * (0.17 - rho) / 0.08 if rho >= 0.09 else 0.06
    wall_r = lambda y: 0.17 + 0.035 * y / 0.07 if y < 0.07 else 0.205 + 0.01 * (y - 0.07) / 0.10 if y < 0.17 else 0.215 - 0.015 * (y - 0.17) / 0.09
    strap = []
    for y in (0.02, 0.07, 0.17, 0.235):
        strap.append(v_add(B, (-(math.sqrt(wall_r(y) ** 2 - zs * zs) + 0.007), y, zs)))
    m = P.n(14, 6)
    for k in range(m + 1):
        x = -0.212 + 0.424 * k / m
        strap.append(v_add(B, (x, 0.26 + lid_h(math.sqrt(x * x + zs * zs)) + 0.007, zs)))
    for y in (0.235, 0.17, 0.07, 0.02):
        strap.append(v_add(B, (math.sqrt(wall_r(y) ** 2 - zs * zs) + 0.007, y, zs)))
    P.sweep("wok_leather", strap, 0.024, profile=[(0.18, 1.0), (-0.18, 1.0), (-0.18, -1.0), (0.18, -1.0)], twist_up=(0.0, 0.0, 1.0))
    P.box("wok_bronze", v_add(B, (math.sqrt(wall_r(0.12) ** 2 - zs * zs) + 0.012, 0.12, zs)), (0.006, 0.03, 0.03), r=(0, -16, 0))
    # tall basket C with carved staffs and a fur hanging over the rim
    C = (0.42, 0.0, 0.10)
    _basket(P, C, [(0.13, 0.0), (0.155, 0.10), (0.165, 0.32), (0.15, 0.52), (0.16, 0.60)], rims=(0.08, 0.30, 0.50))
    if P.lod < 3:
        for k, (dx, dz, h, tilt) in enumerate(((-0.04, 0.02, 1.02, 6), (0.04, -0.03, 0.92, -8), (0.0, 0.05, 0.84, 4))):
            b = v_add(C, (dx, 0.03, dz))
            t = v_add(b, (math.sin(math.radians(tilt)) * h, h, 0.02 * k))
            P.sweep("wok_wood", [b, t], 0.016, sides=P.n(7, 4))
            P.sweep("wok_carve", [v_add(b, v_mul(v_sub(t, b), 0.72)), v_add(b, v_mul(v_sub(t, b), 0.86))], 0.0185, sides=P.n(8, 4))
            P.cone("wok_bronze", t, v_add(t, v_mul(v_norm(v_sub(t, b)), 0.05)), 0.018, n=P.n(6, 4))
    dd = v_norm((math.cos(math.radians(-50)), 0.0, math.sin(math.radians(-50))))
    side = (-dd[2], 0.0, dd[0])
    ctrl = [v_add(C, v_add(v_mul(dd, 0.02), (0, 0.50, 0))), v_add(C, v_add(v_mul(dd, 0.10), (0, 0.635, 0))),
            v_add(C, v_add(v_mul(dd, 0.18), (0, 0.628, 0))), v_add(C, v_add(v_mul(dd, 0.198), (0, 0.52, 0))),
            v_add(C, v_add(v_mul(dd, 0.19), (0, 0.36, 0))), v_add(C, v_add(v_mul(dd, 0.183), (0, 0.24, 0)))]
    _pelt(P, "wok_fur", ctrl, side, lambda t: 0.085 + 0.012 * math.sin(t * 17.0) - 0.03 * smoothstep(0.75, 1.0, t), th=0.02)
    # low bowl basket D of glow-caps
    D = (0.20, 0.0, 0.45)
    _basket(P, D, [(0.10, 0.0), (0.15, 0.05), (0.17, 0.11)], slot="wok_weave_band", rims=(0.05,))
    P.disc("wok_bark", v_add(D, (0, 0.085, 0)), 0.0, 0.155, n=P.n(16, 6))
    if P.lod < 3:
        _glowcaps(P, v_add(D, (0, 0.085, 0)), 7 if P.lod < 2 else 3, 0.032, seed=2.0, spread=0.10)
    # net bag of gourds on the floor: gourds, a mesh of crossing cords, a drawstring neck
    NB = (-0.60, 0.0, 0.34)
    gourds = [((-0.05, 0.10, 0.03), 0.10, "wok_fruit0"), ((0.07, 0.09, -0.02), 0.09, "wok_fruit2"),
              ((0.0, 0.11, -0.08), 0.085, "wok_fruit0"), ((0.01, 0.24, 0.0), 0.08, "wok_fruit2")]
    for (dx, dy, dz), r, slot in gourds:
        P.sphere(slot, v_add(NB, (dx, dy, dz)), r, sy=1.05, n=P.n(12, 6))
    if P.lod < 3:
        P.sweep("wok_wood", [v_add(NB, (0.01, 0.31, 0.0)), v_add(NB, (0.02, 0.35, 0.01))], 0.01, sides=4)
    bag = [(0.04, 0.0), (0.14, 0.04), (0.17, 0.12), (0.15, 0.24), (0.09, 0.32), (0.035, 0.37)]
    dense = _spline([(r, y, 0.0) for r, y in bag], P.n(3, 1))
    nn = P.n(10, 5)
    for sgn in (1, -1):
        for k in range(nn):
            pts = []
            for j, (r, y, _) in enumerate(dense):
                s = j / (len(dense) - 1)
                a = math.radians(360.0 * k / nn + sgn * 150.0 * s)
                pts.append(v_add(NB, (1.015 * r * math.cos(a), y + 0.004, 1.015 * r * math.sin(a))))
            P.sweep("wok_cord", pts, 0.0045, sides=P.n(4, 3))
    _ring(P, "wok_cord", v_add(NB, (0, 0.36, 0)), (0, 1, 0), 0.036, 0.009, n=P.n(10, 5), sides=4)
    P.sweep("wok_cord", [v_add(NB, (0.03, 0.36, 0.0)), v_add(NB, (0.09, 0.40, 0.03)), v_add(NB, (0.13, 0.33, 0.06))], 0.006,
            sides=4)
    P.sphere("wok_bone", v_add(NB, (0.13, 0.325, 0.06)), 0.014, n=6)
    # a wooden scoop leaning on basket A
    if P.lod < 2:
        s0, s1 = v_add(A, (0.10, 0.02, 0.345)), v_add(A, (0.18, 0.40, 0.31))
        P.sweep("wok_wood", [s0, s1], 0.012, sides=5)
        P.sphere("wok_wood", s0, 0.04, lat0=-90, lat1=10, n=P.n(10, 5))
        P.disc("wok_wood", v_add(s0, (0, 0.007, 0)), 0.0, 0.0394, n=P.n(10, 5))


PIECES = {
    "wok_hide_frame": (wok_hide_frame, "interact"),
    "wok_root_chair": (wok_root_chair, "seat"),
    "wok_glow_lantern": (wok_glow_lantern, "lamp"),
    "wok_bowcaster_rack": (wok_bowcaster_rack, "decor"),
    "wok_carved_totem": (wok_carved_totem, "decor"),
    "wok_storage_baskets": (wok_storage_baskets, "decor"),
}
SLOTS = {"wok": {
    "wok_wood": "wok_wood", "wok_bark": "wok_bark", "wok_carve": "wok_carve", "wok_glyph": "wok_glyph",
    "wok_weave": "wok_weave", "wok_weave_band": "wok_weave_band", "wok_fur": "wok_fur", "wok_pelt": "wok_pelt",
    "wok_hide": "wok_hide", "wok_bronze": "wok_bronze", "wok_fungus": "wok_fungus", "wok_glow": "wok_glow",
    "wok_cord": "wok_cord", "wok_leather": "wok_leather", "wok_endgrain": "wok_endgrain",
    "wok_metal": "reb_gunmetal", "wok_bone": "hutt_bone", "wok_fruit0": "hutt_fruit_0", "wok_fruit2": "hutt_fruit_2",
}}
UV = {"wok_wood": 0.6, "wok_bark": 0.7, "wok_carve": 0.4, "wok_glyph": 1.0, "wok_weave": 0.25, "wok_weave_band": 0.4,
      "wok_fur": 0.45, "wok_pelt": 0.8, "wok_hide": 1.0, "wok_bronze": 0.3, "wok_fungus": 0.2, "wok_glow": 0.5,
      "wok_cord": 0.06, "wok_leather": 0.35, "wok_endgrain": 1.0, "wok_metal": 0.4, "wok_bone": 0.3, "wok_fruit0": 0.3,
      "wok_fruit2": 0.3}
SMOOTH = ("wok_wood", "wok_bark", "wok_weave", "wok_weave_band", "wok_fur", "wok_pelt", "wok_hide", "wok_bronze",
          "wok_fungus", "wok_cord", "wok_leather", "wok_bone", "wok_fruit0", "wok_fruit2", "wok_metal")
COLORS = {"wok": (0.45, 0.3, 0.18)}
