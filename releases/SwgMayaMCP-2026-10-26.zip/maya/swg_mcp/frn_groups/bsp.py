"""Bespin Cloud City furniture (group bsp): sleek white and peach curves, rounded forms, amber light, art-deco
sci-fi.

  bsp_data_terminal    interact (terminal)  standing data terminal: swan-neck pedestal, tilted amber screen, keypad
  bsp_pod_chair        seat                 white egg pod lounger tilted open on a trumpet pedestal, peach lining
  bsp_light_sculpture  lamp                 crescent spine holding a glowing orb over a cascade of amber rings
  bsp_coffee_table     table                low round table: glass top over a glowing ring and a tiny Cloud City
  bsp_planter          decor                deco planter of tubular Bespin plants with glowing pods
  bsp_cloud_window     decor                free-standing curved viewport, round ribbed window onto a sunset sky

Conventions as furniture.py: Maya space, y up, the piece stands on the origin, its front faces +z."""
from __future__ import annotations

import math

from ..furniture import (v_add, v_sub, v_mul, v_norm, v_len, rot, xf, smoothstep, seat_hardpoint, station_hardpoints,
                         light_hardpoint, UV as _UV)

WHITE, PEACH, CUSH, GLOW, METAL = "bsp_white", "bsp_peach", "bsp_cushion", "bsp_glow", "bsp_metal"
PLANT, POD, SOIL = "bsp_plant", "bsp_pod", "bsp_soil"


# ---------------------------------------------------------------------------------------------------------------
# helpers (same primitives as the nab group, kept local so each group module stands alone)
# ---------------------------------------------------------------------------------------------------------------

def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _newell(q):
    nx = ny = nz = 0.0
    for i in range(len(q)):
        a, b = q[i], q[(i + 1) % len(q)]
        nx += (a[1] - b[1]) * (a[2] + b[2])
        ny += (a[2] - b[2]) * (a[0] + b[0])
        nz += (a[0] - b[0]) * (a[1] + b[1])
    return (nx, ny, nz)


def _centre(pts):
    n = len(pts)
    return (sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n, sum(p[2] for p in pts) / n)


def _hull(P, slot, rings, closed=True, flip=False, ut=1.0, vt=1.0, kref=None, swap=False):
    """Surface through rings (a 1-point ring is a pole), one consistent winding, the reference band (default the
    widest) facing away from its axis (flip: toward it)."""
    m = max(len(r) for r in rings)
    R = [list(r) * m if len(r) == 1 else list(r) for r in rings]
    cen = [_centre(r) for r in R]
    cols = m if closed else m - 1
    nk = len(R) - 1
    faces = []
    for k in range(nk):
        for j in range(cols):
            j1 = (j + 1) % m
            q = [R[k][j], R[k][j1], R[k + 1][j1], R[k + 1][j]]
            n = _newell(q)
            if v_len(n) < 1e-14:
                continue
            uv = [(ut * j / cols, vt * k / nk), (ut * (j + 1) / cols, vt * k / nk),
                  (ut * (j + 1) / cols, vt * (k + 1) / nk), (ut * j / cols, vt * (k + 1) / nk)]
            if swap:
                uv = [(b, a) for a, b in uv]
            faces.append((k, q, n, uv))
    if kref is None:
        spread = [sum(v_len(v_sub(p, c)) for p in r) / m for r, c in zip(R, cen)]
        kref = max(range(nk), key=lambda k: spread[k] + spread[k + 1])
    s = 0.0
    for k, q, n, _ in faces:
        if k == kref:
            s += _dot(v_norm(n), v_sub(_centre(q), v_mul(v_add(cen[k], cen[k + 1]), 0.5)))
    sign = (1.0 if s >= 0 else -1.0) * (-1.0 if flip else 1.0)
    for k, q, n, uv in faces:
        P.poly(slot, q, uv, v_mul(n, sign))


def _tube(P, slot, path, radius, sides=None, closed=False, caps=True, vscale=None, ax=1.0, ay=1.0):
    """Tube along a polyline (rotation-minimising frames), each face oriented away from its own segment; an
    elliptical section with ax / ay. Returns [(point, nrm, binormal, r)] per path point."""
    path = [p for i, p in enumerate(path) if i == 0 or v_len(v_sub(p, path[i - 1])) > 1e-6]
    m = len(path)
    if m < 2:
        return []
    sides = sides or P.n(8, 4)
    rad = radius if callable(radius) else (lambda t, rr=radius: rr)
    tang = []
    for k in range(m):
        a, b = (path[k - 1], path[(k + 1) % m]) if closed else (path[max(0, k - 1)], path[min(m - 1, k + 1)])
        tang.append(v_norm(v_sub(b, a)))
    up0 = (0.0, 1.0, 0.0) if abs(tang[0][1]) < 0.9 else (1.0, 0.0, 0.0)
    nrm = v_norm(_cross(_cross(tang[0], up0), tang[0]))
    L = [0.0]
    for k in range(1, m):
        L.append(L[-1] + v_len(v_sub(path[k], path[k - 1])))
    tot = L[-1] or 1.0
    rings, frames = [], []
    for k in range(m):
        if k:
            nrm = v_norm(v_sub(nrm, v_mul(tang[k], _dot(nrm, tang[k]))))
        bn = _cross(tang[k], nrm)
        rr = rad(L[k] / tot)
        frames.append((path[k], nrm, bn, rr))
        rings.append([v_add(path[k], v_add(v_mul(nrm, ax * rr * math.cos(2 * math.pi * j / sides)),
                                           v_mul(bn, ay * rr * math.sin(2 * math.pi * j / sides)))) for j in range(sides)])
    s = vscale or _UV.get(slot, 1.0)
    for k in range(m if closed else m - 1):
        k1 = (k + 1) % m
        c = v_mul(v_add(path[k], path[k1]), 0.5)
        la, lb = L[k] / s, (L[k] + v_len(v_sub(path[k1], path[k]))) / s
        for j in range(sides):
            j1 = (j + 1) % sides
            q = [rings[k][j], rings[k][j1], rings[k1][j1], rings[k1][j]]
            P.poly(slot, q, [(j / sides, la), ((j + 1) / sides, la), ((j + 1) / sides, lb), (j / sides, lb)],
                   v_sub(_centre(q), c))
    if caps and not closed:
        for k, sg in ((0, -1.0), (m - 1, 1.0)):
            if rad(L[k] / tot) > 1e-4:
                P.flat(slot, rings[k], v_mul(tang[k], sg))
    return frames


def _spline(ctrl, n):
    m = len(ctrl) - 1
    out = []
    for i in range(n + 1):
        t = i / n * m
        k = min(int(t), m - 1)
        u = t - k
        p0, p1, p2, p3 = ctrl[max(k - 1, 0)], ctrl[k], ctrl[k + 1], ctrl[min(k + 2, m)]
        out.append(tuple(0.5 * (2 * p1[j] + (p2[j] - p0[j]) * u + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * u * u +
                                (3 * p1[j] - p0[j] - 3 * p2[j] + p3[j]) * u ** 3) for j in range(3)))
    return out


def _ball(P, slot, c, r, n=None, rows=None, sy=1.0):
    n = n or P.n(8, 5)
    rows = rows or P.n(5, 3)
    P.lathe(slot, c, [(r * math.sin(math.pi * k / rows), -r * sy * math.cos(math.pi * k / rows)) for k in range(rows + 1)],
            n=n)


def _ring(P, slot, c, R, r, u=(1, 0, 0), v=(0, 0, 1), n=None, sides=None):
    n = n or P.n(24, 8)
    pts = [v_add(c, v_add(v_mul(u, R * math.cos(2 * math.pi * k / n)), v_mul(v, R * math.sin(2 * math.pi * k / n))))
           for k in range(n)]
    _tube(P, slot, pts, r, closed=True, sides=sides or P.n(6, 4))


def _bead(P, slot, c, r, y, d=0.006, n=None):
    """A closed half-round bead (triangular section) round the y axis at radius r, height y."""
    P.lathe(slot, c, [(r - d, y - d), (r + d * 0.8, y), (r - d, y + d), (r - d, y - d)], n=n or P.n(24, 10))


def _band(P, slot, c, r, y0, y1, n=None, inward=False):
    """A one-sided vertical band (a glow strip) at radius r from y0 to y1, facing out (or in)."""
    prof = [(r, y1), (r, y0)] if inward else [(r, y0), (r, y1)]
    P.lathe(slot, c, prof, n=n or P.n(24, 10))


def _leaf(P, base, d, up, L, W, droop=0.35, slot=PLANT):
    d = v_norm(d)
    side = v_norm(_cross(d, up))
    upn = _cross(side, d)
    T = W * 0.14

    def at(s, w_, h_):
        return v_add(base, v_add(v_mul(d, s * L), v_add(v_mul(side, w_), v_mul(upn, h_ - droop * L * s * s))))
    _hull(P, slot, [[at(0, 0, 0)],
                    [at(0.3, W * 0.45, 0), at(0.3, 0, T), at(0.3, -W * 0.45, 0), at(0.3, 0, -T * 0.5)],
                    [at(0.66, W * 0.36, 0), at(0.66, 0, T * 0.8), at(0.66, -W * 0.36, 0), at(0.66, 0, -T * 0.4)],
                    [at(1.0, 0, 0)]])


def _underglow(P, r, y=0.004, h=0.012, n=None):
    """Amber under-glow strip round a round base."""
    _band(P, GLOW, (0, 0, 0), r, y, y + h, n=n)


# ---------------------------------------------------------------------------------------------------------------
# bsp_data_terminal
# ---------------------------------------------------------------------------------------------------------------

TERMINAL_SPOT = (0.0, 0.0, 0.55)     # the user stands here facing the terminal (-z): keypad 0.4 m ahead at 1.05 m


def bsp_data_terminal(P):
    """Standing Cloud City data terminal, 1.6 m: a round plinth with amber under-glow, a swan-neck pedestal with a
    light channel, a tilted housing with the amber screen, a keypad shelf sloping toward the user."""
    n = P.n(28, 10)
    P.lathe(WHITE, (0, 0, 0), [(0.0, 0.0), (0.30, 0.0), (0.31, 0.02), (0.295, 0.05), (0.24, 0.075), (0.12, 0.09),
                               (0.0, 0.09)], n=n)
    _underglow(P, 0.302, n=n)
    _bead(P, PEACH, (0, 0, 0), 0.30, 0.035, 0.006, n=n)
    if P.lod < 2:
        for k in range(3):
            _bead(P, PEACH, (0, 0, 0), 0.24 - 0.04 * k, 0.078 + 0.004 * k, 0.003, n=n)
    # swan-neck pedestal: elliptical section, wide at the foot, waisted, flaring under the head
    path = _spline([(0, 0.08, -0.06), (0, 0.40, -0.10), (0, 0.72, -0.06), (0, 0.96, 0.01), (0, 1.12, 0.035)], P.n(14, 6))
    rfun = lambda t: 0.10 - 0.05 * math.sin(math.pi * min(1.0, t / 0.85)) + 0.012 * smoothstep(0.75, 1.0, t)
    fr = _tube(P, WHITE, path, rfun, sides=P.n(14, 8), ax=1.35, ay=0.85)
    # amber light channel up the front, peach pinstripes on the flanks
    strip = [v_sub(p, v_mul(bn, r * 0.85 + 0.004)) for p, nr, bn, r in fr[1:-3]]
    _tube(P, GLOW, strip, 0.008, sides=P.n(5, 3))
    if P.lod < 2:
        for sx in (-1, 1):
            pin = [v_add(p, v_mul(nr, sx * (r * 1.35 + 0.002))) for p, nr, bn, r in fr[1:-3]]
            _tube(P, PEACH, pin, 0.006, sides=4)
    P.lathe(METAL, path[0], [(0.0, 0.0), (0.13, 0.0), (0.135, 0.02), (0.12, 0.03), (0.0, 0.03)], n=P.n(18, 8))
    # the head: a rounded housing tilted back 16 degrees, peach bezel, amber screen, side fins with light bars
    tilt = -16.0
    hc = (0.0, 1.30, -0.02)
    nrm = rot((0, 0, 1), tilt)
    up = rot((0, 1, 0), tilt)
    P.rbox(WHITE, hc, (0.31, 0.21, 0.06), 0.05, r=(tilt, 0, 0), seg=P.n(3, 1))
    P.rbox(PEACH, v_add(hc, v_mul(up, -0.205)), (0.14, 0.035, 0.072), 0.025, r=(tilt, 0, 0), seg=1)    # neck yoke
    P.rbox(PEACH, v_add(hc, v_mul(nrm, 0.052)), (0.27, 0.175, 0.012), 0.01, r=(tilt, 0, 0), seg=1)
    P.decal("bsp_screen", v_add(hc, v_mul(nrm, 0.0655)), 0.50, 0.31, nrm, up=up)
    P.rbox(PEACH, v_add(hc, v_mul(nrm, -0.05)), (0.25, 0.16, 0.02), 0.015, r=(tilt, 0, 0), seg=1)    # back panel
    if P.lod < 3:
        P.decal("bsp_emblem", v_add(hc, v_mul(nrm, -0.0705)), 0.18, 0.18, v_mul(nrm, -1), up=up)
    for sx in (-1, 1):
        fc = v_add(hc, v_add((sx * 0.335, 0, 0), v_mul(nrm, 0.0)))
        P.rbox(WHITE, fc, (0.03, 0.25, 0.075), 0.025, r=(tilt, 0, 0), seg=P.n(2, 1))
        P.rbox(GLOW, v_add(fc, v_mul(nrm, 0.0755)), (0.01, 0.20, 0.004), 0.003, r=(tilt, 0, 0), seg=1)
        if P.lod < 2:
            P.rbox(GLOW, v_add(fc, v_mul(nrm, -0.0755)), (0.01, 0.20, 0.004), 0.003, r=(tilt, 0, 0), seg=1)
    # crest bar on top with an amber line, a sensor dome
    top = v_add(hc, v_mul(up, 0.215))
    P.rbox(PEACH, top, (0.22, 0.018, 0.05), 0.016, r=(tilt, 0, 0), seg=1)
    P.rbox(GLOW, v_add(top, v_mul(nrm, 0.051)), (0.18, 0.006, 0.003), 0.002, r=(tilt, 0, 0), seg=1)
    P.sphere(METAL, v_add(top, v_mul(up, 0.012)), 0.035, lat0=0, lat1=90, n=P.n(12, 6))
    # keypad shelf sloping toward the user, its support blending into the pedestal
    kc = (0.0, 1.03, 0.15)
    P.rbox(WHITE, kc, (0.24, 0.025, 0.12), 0.022, r=(20, 0, 0), seg=P.n(3, 1))
    kn = rot((0, 1, 0), 20)
    P.decal("bsp_keypad", v_add(kc, v_mul(kn, 0.0262)), 0.42, 0.20, kn, up=rot((0, 0, -1), 20))
    P.rbox(GLOW, v_add(kc, rot((0, -0.004, 0.121), 20)), (0.20, 0.004, 0.003), 0.002, r=(20, 0, 0), seg=1)
    sup = _spline([(0, 0.92, -0.01), (0, 0.97, 0.06), (0, 1.01, 0.12)], P.n(6, 3))
    _tube(P, WHITE, sup, lambda t: 0.05 - 0.015 * t, sides=P.n(10, 6), ax=1.6, ay=0.7)
    if P.lod < 2:                                                  # card slot and a little speaker grille
        P.box(METAL, v_add(kc, rot((0.15, -0.012, 0.118), 20)), (0.05, 0.004, 0.006), r=(20, 0, 0), bottom=False)
        for k in range(4):
            P.box(METAL, v_add(kc, rot((-0.18 + 0.02 * k, -0.012, 0.118), 20)), (0.005, 0.009, 0.004), r=(20, 0, 0), bottom=False)
    station_hardpoints(P, "terminal", TERMINAL_SPOT, yaw=180.0)


# ---------------------------------------------------------------------------------------------------------------
# bsp_pod_chair
# ---------------------------------------------------------------------------------------------------------------

POD_FRONT = 0.28


def bsp_pod_chair(P):
    """Egg pod lounger: an ellipsoid shell tilted 10 degrees open toward the front on a trumpet pedestal, quilted
    peach lining, a plush back cushion that follows the shell, a round seat cushion. Seat 0.46, front edge z 0.28
    -> foot 0.455; the back cushion's face is at z -0.24 at shoulder height."""
    C = (0.0, 0.76, 0.08)
    A, B, Cz = 0.52, 0.60, 0.48
    tilt = -10.0
    phimax = math.radians(108)
    nth = P.n(36, 12)
    nph = P.n(14, 5)

    def shell(phi, th, s=1.0):
        p = (s * A * math.sin(phi) * math.cos(th), s * B * math.sin(phi) * math.sin(th), -s * Cz * math.cos(phi))
        return v_add(C, rot(p, tilt, 0, 0))
    ths = [2 * math.pi * j / nth for j in range(nth)]
    phis = [phimax * k / nph for k in range(nph + 1)]
    outer = [[shell(0, 0)]] + [[shell(ph, th) for th in ths] for ph in phis[1:]]
    inner = [[shell(0, 0, 0.94)]] + [[shell(ph, th, 0.94) for th in ths] for ph in phis[1:]]
    _hull(P, WHITE, outer, ut=4.0, vt=2.0)
    _hull(P, CUSH, inner, flip=True, ut=8.0, vt=1.6)
    axis = rot((0, 0, 1), tilt, 0, 0)
    for j in range(nth):                                           # the rim between the two shells
        j1 = (j + 1) % nth
        q = [outer[-1][j], outer[-1][j1], inner[-1][j1], inner[-1][j]]
        P.poly(WHITE, q, [(j / nth * 6, 0), ((j + 1) / nth * 6, 0), ((j + 1) / nth * 6, 0.1), (j / nth * 6, 0.1)], axis)
    # amber glow line just inside the rim, peach deco bands round the back of the shell
    _tube(P, GLOW, [shell(phimax - 0.03, th, 0.935) for th in ths], 0.007, closed=True, sides=P.n(5, 3))
    for ph in ((0.40, 0.58) if P.lod < 3 else (0.50,)):
        _tube(P, PEACH, [shell(ph, th, 1.012) for th in ths], 0.011, closed=True, sides=P.n(5, 3))
    if P.lod < 2:
        _ball(P, METAL, shell(0, 0, 1.0), 0.03, n=P.n(10, 6), rows=4)
    # the plush back cushion: a cap of the shell scaled to 0.68 facing the sitter, rolled back to the lining
    phc = math.radians(56)
    nb = P.n(8, 3)
    sf = 0.68
    cap = [[shell(0, 0, sf)]] + [[shell(phc * k / nb, th, sf) for th in ths] for k in range(1, nb + 1)]
    roll = [(sf + 0.06, phc + 0.05), (sf + 0.16, phc + 0.09), (0.93, phc + 0.11)]
    rings = cap + [[shell(ph, th, s) for th in ths] for s, ph in roll]
    _hull(P, CUSH, rings, flip=True, ut=3.0, vt=1.0, kref=nb - 1, swap=True)
    if P.lod < 2:                                                  # buttons down the middle of the back cushion
        for k in range(3):
            ph = 0.12 + 0.22 * k
            _ball(P, PEACH, shell(ph, math.pi / 2, sf - 0.012) if k else shell(0.02, 0.0, sf - 0.012), 0.014, n=6, rows=3,
                  sy=0.6)
    # the round seat cushion, piped
    P.lathe(CUSH, (0.0, 0.365, 0.05), [(0.0, -0.075), (0.14, -0.075), (0.20, -0.04), (0.235, 0.015), (0.245, 0.05),
                                       (0.232, 0.08), (0.18, 0.093), (0.0, 0.097)], n=P.n(28, 10))
    if P.lod < 2:
        _bead(P, PEACH, (0.0, 0.365, 0.05), 0.243, 0.05, 0.006, n=P.n(28, 10))
        _ball(P, PEACH, (0.0, 0.462, 0.05), 0.016, n=6, rows=3, sy=0.5)
    # trumpet pedestal under the shell, bronze collar, peach band, under-glow
    lowp = min((p for ring in outer for p in ring), key=lambda p: p[1])
    ylow, px, pz = lowp[1], 0.0, lowp[2]
    P.lathe(WHITE, (px, 0, pz), [(0.0, 0.0), (0.36, 0.0), (0.37, 0.015), (0.35, 0.035), (0.16, 0.07), (0.075, 0.12),
                                 (0.06, ylow + 0.03), (0.0, ylow + 0.03)], n=P.n(28, 10))
    _band(P, GLOW, (px, 0, pz), 0.362, 0.003, 0.013, n=P.n(28, 10))
    P.lathe(METAL, (px, ylow - 0.035, pz), [(0.0, 0.0), (0.08, 0.0), (0.09, 0.015), (0.08, 0.03), (0.0, 0.035)], n=P.n(16, 8))
    _bead(P, PEACH, (px, 0, pz), 0.355, 0.026, 0.005, n=P.n(28, 10))
    seat_hardpoint(P, POD_FRONT)


# ---------------------------------------------------------------------------------------------------------------
# bsp_light_sculpture
# ---------------------------------------------------------------------------------------------------------------

def _glow_ring(P, c, R, n=None, r=(0, 0, 0)):
    """A white band ring (rounded section) with an amber light strip on its inner face and underside, tilted by r."""
    n = n or P.n(32, 12)
    P.lathe(WHITE, c, [(R - 0.008, -0.02), (R + 0.010, -0.02), (R + 0.016, 0.0), (R + 0.010, 0.02), (R - 0.008, 0.02),
                       (R - 0.008, -0.02)], n=n, r=r)
    P.lathe(GLOW, c, [(R - 0.0085, 0.015), (R - 0.0085, -0.015)], n=n, r=r)
    P.disc(GLOW, xf((0, -0.0205, 0), c, r), R - 0.006, R + 0.006, n=n, down=True, r=r)


def bsp_light_sculpture(P):
    """Sunset light sculpture, 2.05 m: a white crescent spine rising from a round base and curling over a glowing
    orb, a cascade of four amber-lit rings below the orb."""
    n = P.n(28, 10)
    P.lathe(WHITE, (0, 0, 0), [(0.0, 0.0), (0.30, 0.0), (0.31, 0.02), (0.29, 0.045), (0.16, 0.065), (0.0, 0.07)], n=n)
    _underglow(P, 0.302, n=n)
    _bead(P, PEACH, (0, 0, 0), 0.30, 0.03, 0.006, n=n)
    P.disc(GLOW, (0, 0.0715, 0), 0.075, 0.115, n=n)
    AXZ = 0.12                                                     # the rings' and the orb's axis: x 0, z AXZ
    spine = _spline([(0, 0.05, -0.17), (0, 0.45, -0.27), (0, 1.0, -0.31), (0, 1.5, -0.27), (0, 1.84, -0.15),
                     (0, 2.03, -0.01), (0, 2.08, AXZ - 0.04), (0, 2.06, AXZ), (0, 2.01, AXZ)], P.n(28, 10))
    fr = _tube(P, WHITE, spine, lambda t: 0.048 - 0.03 * t, sides=P.n(12, 6), ax=0.75, ay=1.2)
    if P.lod < 2:                                                  # a peach inlay line down the spine's outer edge
        pin = [v_add(p, v_mul(bn, r * 1.3 + 0.002)) for p, nr, bn, r in fr[2:-3]]
        _tube(P, PEACH, pin, 0.006, sides=4)
    # the orb hanging from the crook: a white cap, a glowing core inside a soft halo shell
    oc = (0.0, 1.87, AXZ)
    P.lathe(WHITE, oc, [(0.0, 0.065), (0.06, 0.065), (0.085, 0.085), (0.07, 0.11), (0.03, 0.135), (0.0, 0.138)],
            n=P.n(16, 8))
    P.lathe(METAL, oc, [(0.084, 0.078), (0.092, 0.086), (0.084, 0.094), (0.084, 0.078)], n=P.n(16, 8))
    P.sphere("bsp_core", oc, 0.088 * 0.992, n=P.n(18, 8))
    P.sphere("bsp_halo", oc, 0.088, n=P.n(18, 8))
    # the ring cascade, each held to the spine by a slim strut
    for k, (y, R, rx, rz) in enumerate(((1.67, 0.11, 7, -9), (1.48, 0.16, -6, 8), (1.27, 0.21, 8, -5), (1.04, 0.25, -5, 7))):
        c = (0.0, y, AXZ)
        _glow_ring(P, c, R, r=(rx, 0, rz))
        back = xf((0.0, 0.0, -R - 0.014), c, (rx, 0, rz))
        zs = min(spine, key=lambda p: abs(p[1] - back[1]))[2]
        _tube(P, WHITE, [(0.0, back[1], zs + 0.02), back], 0.009, sides=P.n(6, 4))
        if P.lod < 2:
            _ball(P, METAL, back, 0.014, n=6, rows=3)
    light_hardpoint(P, oc)


# ---------------------------------------------------------------------------------------------------------------
# bsp_coffee_table
# ---------------------------------------------------------------------------------------------------------------

def bsp_coffee_table(P):
    """Low round table, top 0.43 m, r 0.52: a glass disc in a white rim over a trumpet pedestal whose dish holds an
    amber light ring and a bronze miniature of Cloud City; a glowing bowl and a datapad on the glass."""
    n = P.n(36, 12)
    TOP = 0.42
    P.disc("bsp_glass", (0, TOP, 0), 0.0, 0.48, n=n)
    P.lathe(WHITE, (0, 0, 0), [(0.475, TOP - 0.025), (0.512, TOP - 0.025), (0.525, TOP - 0.008), (0.518, TOP + 0.01),
                               (0.475, TOP + 0.012), (0.475, TOP - 0.025)], n=n)
    _bead(P, PEACH, (0, 0, 0), 0.52, TOP - 0.006, 0.005, n=n)
    _band(P, GLOW, (0, 0, 0), 0.474, TOP - 0.02, TOP - 0.004, n=n, inward=True)
    # trumpet pedestal flaring into a wide dish under the glass
    P.lathe(WHITE, (0, 0, 0), [(0.0, 0.0), (0.30, 0.0), (0.31, 0.015), (0.29, 0.032), (0.16, 0.06), (0.10, 0.12),
                               (0.09, 0.21), (0.13, 0.27), (0.28, 0.31), (0.40, 0.322), (0.412, 0.33), (0.40, 0.338),
                               (0.0, 0.335)], n=n)
    _underglow(P, 0.302, n=n)
    _bead(P, PEACH, (0, 0, 0), 0.295, 0.024, 0.005, n=n)
    _bead(P, PEACH, (0, 0, 0), 0.41, 0.33, 0.006, n=n)
    _ring(P, GLOW, (0, 0.346, 0), 0.30, 0.012, n=P.n(36, 12), sides=P.n(6, 4))
    for r in ((0.16, 0.22) if P.lod < 2 else (0.20,)):
        P.lathe(PEACH, (0, 0.335, 0), [(r - 0.012, -0.002), (r + 0.012, -0.002), (r, 0.004), (r - 0.012, -0.002)], n=n)
    # six slim posts from the dish edge up to the rim
    for k in range(6 if P.lod < 2 else 3):
        a = math.radians(90 + (60 if P.lod < 2 else 120) * k)
        ca, sa = math.cos(a), math.sin(a)
        arm = _spline([(0.395 * ca, 0.33, 0.395 * sa), (0.44 * ca, 0.35, 0.44 * sa), (0.48 * ca, 0.375, 0.48 * sa),
                       (0.495 * ca, TOP - 0.024, 0.495 * sa)], P.n(6, 3))
        _tube(P, WHITE, arm, lambda t: 0.013 - 0.004 * t, sides=P.n(7, 4))
    # the miniature Cloud City in bronze on the dish: stalk, saucer, central spires
    cc = (0.0, 0.335, 0.0)
    P.lathe(METAL, cc, [(0.0, 0.0), (0.02, 0.0), (0.012, 0.01), (0.008, 0.026), (0.035, 0.03), (0.10, 0.037),
                        (0.11, 0.042), (0.07, 0.047), (0.04, 0.049), (0.028, 0.058), (0.015, 0.06), (0.0, 0.061)],
            n=P.n(20, 8))
    if P.lod < 2:
        for k in range(6):
            a = 2 * math.pi * k / 6
            P.box(METAL, (0.03 * math.cos(a), 0.392 + 0.004 * (k % 2), 0.03 * math.sin(a)), (0.006, 0.008 + 0.004 * (k % 2), 0.006))
        _ring(P, GLOW, (0.0, 0.3785, 0.0), 0.105, 0.003, n=P.n(20, 8), sides=3)
    # on the glass: a shallow bowl of glowing stones and a datapad
    bw = (0.20, TOP, -0.14)
    P.lathe(PEACH, bw, [(0.0, 0.0), (0.05, 0.0), (0.09, 0.03), (0.095, 0.045), (0.085, 0.045), (0.05, 0.02), (0.0, 0.016)],
            n=P.n(18, 8))
    if P.lod < 3:
        for k, (dx, dz) in enumerate(((0.0, 0.0), (0.035, 0.02), (-0.03, 0.025), (0.01, -0.035))):
            _ball(P, "bsp_core", v_add(bw, (dx, 0.03, dz)), 0.022 - 0.003 * (k % 2), n=P.n(8, 5), rows=P.n(4, 3))
    dp = (-0.18, TOP + 0.006, 0.14)
    P.rbox(WHITE, dp, (0.08, 0.006, 0.11), 0.006, r=(0, 28, 0), seg=1)
    P.decal("bsp_screen", v_add(dp, (0, 0.0065, 0)), 0.13, 0.17, (0, 1, 0), up=rot((0, 0, -1), 0, 28, 0))


# ---------------------------------------------------------------------------------------------------------------
# bsp_planter
# ---------------------------------------------------------------------------------------------------------------

def _stem(P, base, top, r0, bend, nodes=4, cap="pod", seed=0):
    """A tubular Bespin stem from base to top with node rings, bowing by `bend` (xz), topped by a cap."""
    mid = v_add(v_mul(v_add(base, top), 0.5), (bend[0], 0.0, bend[2]))
    path = _spline([base, v_add(v_mul(v_add(base, mid), 0.5), (bend[0] * 0.3, 0, bend[2] * 0.3)), mid, top], P.n(10, 4))
    _tube(P, PLANT, path, lambda t: r0 * (1.0 - 0.45 * t), sides=P.n(8, 4))
    if P.lod < 2:
        for k in range(1, nodes + 1):
            i = int(len(path) * k / (nodes + 1))
            p = path[i]
            tg = v_norm(v_sub(path[min(i + 1, len(path) - 1)], path[i - 1]))
            t = i / (len(path) - 1)
            a = v_norm(_cross(tg, (0, 0, 1) if abs(tg[2]) < 0.9 else (1, 0, 0)))
            b = _cross(tg, a)
            _ring(P, PLANT, p, r0 * (1.0 - 0.45 * t) * 1.02, r0 * 0.28, a, b, n=P.n(10, 5), sides=4)
    tg = v_norm(v_sub(path[-1], path[-2]))
    end = path[-1]
    rt = r0 * 0.85
    if cap == "pod":                                               # a glowing seed pod
        c = v_add(end, v_mul(tg, rt * 2.2))
        a = v_norm(tg)
        t1 = v_norm(_cross(a, (0, 0, 1) if abs(a[2]) < 0.9 else (1, 0, 0)))
        t2 = _cross(a, t1)
        m = P.n(10, 5)
        rings = [[end]]
        for h, rr in ((0.4, 1.4), (1.6, 2.1), (2.8, 1.6), (3.6, 0.8)):
            rings.append([v_add(v_add(end, v_mul(a, h * rt)), v_add(v_mul(t1, rr * rt * math.cos(2 * math.pi * j / m)),
                                                                   v_mul(t2, rr * rt * math.sin(2 * math.pi * j / m))))
                          for j in range(m)])
        rings.append([v_add(end, v_mul(a, 4.1 * rt))])
        _hull(P, POD, rings)
        return c
    if cap == "trumpet":                                           # an open trumpet, glowing inside
        a = v_norm(tg)
        lip = [(rt, 0.0), (rt * 1.3, rt * 2.0), (rt * 2.4, rt * 3.6), (rt * 3.4, rt * 4.4)]
        old = P.xform
        t1 = v_norm(_cross(a, (0, 0, 1) if abs(a[2]) < 0.9 else (1, 0, 0)))
        t2 = _cross(t1, a)

        def X(p, end=end, a=a, t1=t1, t2=t2):
            return v_add(end, v_add(v_mul(t1, p[0]), v_add(v_mul(a, p[1]), v_mul(t2, p[2]))))
        P.xform = X
        P.lathe(PLANT, (0, 0, 0), lip, n=P.n(10, 5))
        P.lathe(POD, (0, 0, 0), [(p[0] * 0.86, p[1]) for p in lip[::-1]] + [(0.0, rt * 0.4)], n=P.n(10, 5))
        P.lathe(POD, (0, 0, 0), [(rt * 3.4, rt * 4.4), (rt * 3.4 * 0.86, rt * 4.4)], n=P.n(10, 5))
        if P.lod < 2:
            P.cone(POD, (0, rt * 0.4, 0), (0, rt * 3.0, 0), rt * 0.35, n=4)
        P.xform = old
        return end
    # cluster of little orbs
    for k in range(5 if P.lod < 2 else 2):
        a = 2 * math.pi * k / 5 + seed
        _ball(P, POD, v_add(end, (rt * 1.8 * math.cos(a), rt * (1.2 + 0.8 * (k % 2)), rt * 1.8 * math.sin(a))), rt * 1.1,
              n=P.n(7, 4), rows=P.n(4, 3))
    return end


def bsp_planter(P):
    """Round deco planter, white with peach bands and amber foot light, holding tall tubular Bespin plants with
    node rings, glowing seed pods and trumpets, broad leaves and curling tendrils at the soil."""
    n = P.n(32, 12)
    SOILY = 0.40
    P.lathe(WHITE, (0, 0, 0), [(0.0, 0.0), (0.20, 0.0), (0.21, 0.018), (0.20, 0.04), (0.25, 0.10), (0.30, 0.24),
                               (0.315, 0.36), (0.335, 0.41), (0.34, 0.43), (0.325, 0.44), (0.305, 0.43), (0.295, SOILY - 0.01),
                               (0.29, SOILY - 0.02)], n=n)
    P.disc(SOIL, (0, SOILY, 0), 0.0, 0.30, n=n)
    _underglow(P, 0.203, y=0.004, h=0.012, n=n)
    _bead(P, PEACH, (0, 0, 0), 0.301, 0.25, 0.012, n=n)
    if P.lod < 2:
        for y in (0.30, 0.325):
            _bead(P, PEACH, (0, 0, 0), 0.306 + (y - 0.30) * 0.25, y, 0.004, n=n)
        for y in (0.14, 0.17):
            _bead(P, PEACH, (0, 0, 0), 0.25 + (y - 0.10) * 0.36, y, 0.003, n=n)
    # the plants
    stems = [((0.02, -0.03), 1.50, (0.06, 0, -0.04), 0.032, "pod"), ((-0.12, 0.05), 1.18, (-0.10, 0, 0.03), 0.028, "trumpet"),
             ((0.13, 0.07), 1.05, (0.10, 0, 0.06), 0.026, "orbs"), ((-0.06, -0.15), 1.30, (-0.04, 0, -0.10), 0.027, "pod"),
             ((0.10, -0.14), 0.88, (0.12, 0, -0.08), 0.022, "trumpet"), ((-0.18, -0.06), 0.80, (-0.14, 0, -0.02), 0.020, "orbs"),
             ((0.03, 0.16), 0.70, (0.02, 0, 0.12), 0.020, "pod")]
    for k, ((x, z), h, bend, r0, cap) in enumerate(stems):
        if P.lod >= 3 and k > 3:
            continue
        top = (x + bend[0] * 1.4, SOILY + h, z + bend[2] * 1.4)
        _stem(P, (x, SOILY - 0.01, z), top, r0, bend, nodes=3 + k % 3, cap=cap, seed=k)
    if P.lod < 3:                                                  # broad strap leaves arching over the rim
        for k in range(8 if P.lod < 2 else 4):
            a = 2 * math.pi * k / 8 + 0.3
            d = (math.cos(a), 1.25, math.sin(a))
            _leaf(P, (0.08 * math.cos(a), SOILY - 0.01, 0.08 * math.sin(a)), d, (0, 1, 0), 0.46 + 0.06 * (k % 3), 0.10,
                  droop=0.9)
        for k, (x, z, h, r) in enumerate(((0.16, -0.02, 0.30, 0.06), (-0.14, 0.14, 0.22, 0.05))):   # puffball pods
            top = (x * 1.2, SOILY + h, z * 1.2)
            _tube(P, PLANT, [(x, SOILY - 0.01, z), (x * 1.1, SOILY + h * 0.5, z * 1.1), top], 0.012, sides=P.n(6, 4))
            _ball(P, POD, v_add(top, (0, r * 0.8, 0)), r, n=P.n(12, 6), rows=P.n(6, 4))
            if P.lod < 2:
                for j in range(6):
                    b = 2 * math.pi * j / 6 + k
                    P.cone(PLANT, v_add(top, (r * 0.7 * math.cos(b), r * 0.3, r * 0.7 * math.sin(b))),
                           v_add(top, (r * 1.5 * math.cos(b), r * 1.1, r * 1.5 * math.sin(b))), r * 0.25, n=4)
    if P.lod < 2:
        for k in range(3):
            a = 2 * math.pi * k / 3 + 1.0
            c = (0.12 * math.cos(a), SOILY + 0.10, 0.12 * math.sin(a))
            u = (math.cos(a), 0.0, math.sin(a))
            pts = [v_add(c, v_add(v_mul(u, 0.07 * (1 - 0.8 * t) * math.cos(6 * t)), (0, 0.07 * (1 - 0.8 * t) * math.sin(6 * t) - 0.05 * (1 - t), 0)))
                   for t in [i / 14 for i in range(15)]]
            pts = [(0.12 * math.cos(a) * 0.6, SOILY, 0.12 * math.sin(a) * 0.6)] + pts
            _tube(P, PLANT, pts, lambda t: 0.008 * (1 - 0.7 * t), sides=4)


# ---------------------------------------------------------------------------------------------------------------
# bsp_cloud_window
# ---------------------------------------------------------------------------------------------------------------

def bsp_cloud_window(P):
    """Free-standing Cloud City viewport, 1.7 x 2.2 m, curved in plan (concave to the front, radius 2.4 m): a white
    surround with peach pinstripes, a round window with eight radial ribs and a hub ring, the sunset cloudscape
    glowing in it from both sides, an amber ring round the window, a curved plinth with feet and under-glow."""
    R, T = 2.4, 0.10                     # plan radius of the mid-surface, surround thickness
    W, YB, YT, RT, RBc = 0.82, 0.14, 2.18, 0.42, 0.06
    YC, RW = 1.24, 0.60

    def cyl(x, y, off):                  # unrolled (x, y) -> world; off > 0 toward the front (the axis side)
        a = x / R
        rr = R - off
        return (rr * math.sin(a), y, R - rr * math.cos(a))

    def tang(x):
        a = x / R
        return (math.cos(a), 0.0, math.sin(a))

    def front_n(x):
        a = x / R
        return (-math.sin(a), 0.0, math.cos(a))

    # the outline: a tall rounded rectangle (big top radii)
    nc = P.n(8, 3)
    outline = []
    for cx, cy, rr, a0 in ((W - RBc, YB + RBc, RBc, -90), (W - RT, YT - RT, RT, 0), (-W + RT, YT - RT, RT, 90),
                           (-W + RBc, YB + RBc, RBc, 180)):
        for k in range(nc + 1):
            a = math.radians(a0 + 90 * k / nc)
            outline.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))

    def ray_hit(th):
        dx, dy = math.cos(th), math.sin(th)
        best = None
        for i in range(len(outline)):
            (ax, ay), (bx, by) = outline[i], outline[(i + 1) % len(outline)]
            ex, ey = bx - ax, by - ay
            den = dx * (-ey) - dy * (-ex)
            if abs(den) < 1e-12:
                continue
            ox, oy = ax - 0.0, ay - YC
            t = (ox * (-ey) - oy * (-ex)) / den
            u = (dx * oy - dy * ox) / den
            if t > 0 and -1e-9 <= u <= 1 + 1e-9 and (best is None or t < best):
                best = t
        return (best * dx, YC + best * dy)
    na = P.n(48, 16)
    J = P.n(4, 2)
    ths = [2 * math.pi * k / na - math.pi / 2 for k in range(na)]
    inner2 = [(RW * math.cos(t), YC + RW * math.sin(t)) for t in ths]
    outer2 = [ray_hit(t) for t in ths]
    s = _UV.get(WHITE, 1.0)
    for side, off in ((1, T / 2), (-1, -T / 2)):
        for k in range(na):
            k1 = (k + 1) % na
            for j in range(J):
                f0, f1 = j / J, (j + 1) / J
                pts2 = [(inner2[k][0] + (outer2[k][0] - inner2[k][0]) * f0, inner2[k][1] + (outer2[k][1] - inner2[k][1]) * f0),
                        (inner2[k1][0] + (outer2[k1][0] - inner2[k1][0]) * f0, inner2[k1][1] + (outer2[k1][1] - inner2[k1][1]) * f0),
                        (inner2[k1][0] + (outer2[k1][0] - inner2[k1][0]) * f1, inner2[k1][1] + (outer2[k1][1] - inner2[k1][1]) * f1),
                        (inner2[k][0] + (outer2[k][0] - inner2[k][0]) * f1, inner2[k][1] + (outer2[k][1] - inner2[k][1]) * f1)]
                q = [cyl(x, y, off) for x, y in pts2]
                xm = sum(x for x, _ in pts2) / 4
                P.poly(WHITE, q, [(x * side / s, y / s) for x, y in pts2], v_mul(front_n(xm), side))
    # outer edge strip (rounded by a bullnose tube) and the window reveal
    per = 0.0
    for k in range(na):
        k1 = (k + 1) % na
        (ax, ay), (bx, by) = outer2[k], outer2[k1]
        q = [cyl(ax, ay, T / 2), cyl(bx, by, T / 2), cyl(bx, by, -T / 2), cyl(ax, ay, -T / 2)]
        d2 = v_norm(((ax + bx) / 2, (ay + by) / 2 - YC, 0.0))
        xm = (ax + bx) / 2
        want = v_add(v_mul(tang(xm), d2[0]), (0.0, d2[1], 0.0))
        ln = math.hypot(bx - ax, by - ay)
        P.poly(WHITE, q, [(per / s, 0), ((per + ln) / s, 0), ((per + ln) / s, T / s), (per / s, T / s)], want)
        per += ln
        (ax, ay), (bx, by) = inner2[k], inner2[k1]
        q = [cyl(ax, ay, T / 2), cyl(bx, by, T / 2), cyl(bx, by, -T / 2), cyl(ax, ay, -T / 2)]
        xm = (ax + bx) / 2
        d2 = v_norm((xm, (ay + by) / 2 - YC, 0.0))
        want = v_mul(v_add(v_mul(tang(xm), d2[0]), (0.0, d2[1], 0.0)), -1.0)
        P.poly(PEACH, q, [(k / na * 8, 0), ((k + 1) / na * 8, 0), ((k + 1) / na * 8, 0.3), (k / na * 8, 0.3)], want)
    _tube(P, WHITE, [cyl(x, y, 0.0) for x, y in outer2], T * 0.56, closed=True, sides=P.n(10, 6))
    # the sky, both sides, fit once over the window circle
    nr = P.n(4, 2)
    for side, off in ((1, 0.006), (-1, -0.006)):
        for k in range(na):
            k1 = (k + 1) % na
            for j in range(nr):
                r0, r1 = RW * j / nr, RW * (j + 1) / nr
                pts2 = [(r0 * math.cos(ths[k]), YC + r0 * math.sin(ths[k])), (r0 * math.cos(ths[k1]), YC + r0 * math.sin(ths[k1])),
                        (r1 * math.cos(ths[k1]), YC + r1 * math.sin(ths[k1])), (r1 * math.cos(ths[k]), YC + r1 * math.sin(ths[k]))]
                q = [cyl(x, y, off) for x, y in pts2]
                uv = [(0.5 + side * x / (2 * RW), 0.5 + (y - YC) / (2 * RW)) for x, y in pts2]
                P.poly("bsp_sky", q, uv, v_mul(front_n(sum(x for x, _ in pts2) / 4), side))
    # ribs: eight spokes, a mid ring, a heavy outer ring over the reveal edge, the hub
    nn = P.n(32, 12)
    _tube(P, WHITE, [cyl(RW * math.cos(2 * math.pi * k / nn), YC + RW * math.sin(2 * math.pi * k / nn), 0.0) for k in range(nn)],
          0.035, closed=True, sides=P.n(8, 5), ax=1.0, ay=1.6)
    _tube(P, WHITE, [cyl(RW * 0.52 * math.cos(2 * math.pi * k / nn), YC + RW * 0.52 * math.sin(2 * math.pi * k / nn), 0.0)
                     for k in range(nn)], 0.016, closed=True, sides=P.n(6, 4), ax=1.0, ay=1.5)
    for k in range(8):
        a = 2 * math.pi * k / 8 + math.pi / 8
        pts = [cyl(r * math.cos(a), YC + r * math.sin(a), 0.0) for r in (0.07, RW * 0.5, RW * 0.98)]
        _tube(P, WHITE, pts, 0.017, sides=P.n(6, 4), ax=1.0, ay=1.5)
    hub = cyl(0.0, YC, 0.0)
    P.lathe(WHITE, hub, [(0.0, -0.04), (0.07, -0.04), (0.085, 0.0), (0.07, 0.04), (0.0, 0.04)], r=(90, 0, 0), n=P.n(18, 8))
    for sg in (1, -1):
        P.lathe(PEACH, v_add(hub, (0, 0, sg * 0.040)), [(0.0, 0.0), (0.045, 0.0), (0.035, 0.008), (0.0, 0.01)],
                r=(sg * 90, 0, 0), n=P.n(14, 6))
        _ring(P, GLOW, v_add(hub, (0, 0, sg * 0.03)), 0.075, 0.006, (1, 0, 0), (0, 1, 0), n=P.n(16, 8), sides=4)
    # amber ring round the window and peach pinstripes on both faces
    for side in (1, -1):
        off = side * (T / 2 + 0.006)
        _tube(P, GLOW, [cyl((RW + 0.07) * math.cos(2 * math.pi * k / nn), YC + (RW + 0.07) * math.sin(2 * math.pi * k / nn), off)
                        for k in range(nn)], 0.009, closed=True, sides=P.n(5, 3))
        if P.lod < 3:
            for y in (0.42, 0.48):
                xs = [-W + 0.1 + (2 * W - 0.2) * i / P.n(12, 4) for i in range(P.n(12, 4) + 1)]
                _tube(P, PEACH, [cyl(x, y, side * (T / 2 + 0.002)) for x in xs], 0.007, sides=4)
            insetp = [(x * 0.9, YC + (y - YC) * 0.93 + 0.0) for x, y in outline]
            if P.lod < 2:
                _tube(P, PEACH, [cyl(x, y, side * (T / 2 + 0.002)) for x, y in insetp if y > YC + 0.25], 0.006, sides=4)
    # deco: three amber light slots over the window and peach fluting down the sides, both faces
    for side in (1, -1):
        off = side * (T / 2 + 0.003)
        for x, h in ((-0.14, 0.10), (0.0, 0.16), (0.14, 0.10)):
            y0 = YC + RW + 0.13
            q = [cyl(x - 0.012, y0, off), cyl(x + 0.012, y0, off), cyl(x + 0.012, y0 + h, off), cyl(x - 0.012, y0 + h, off)]
            P.poly(GLOW, q if side > 0 else q[::-1], [(0, 0), (1, 0), (1, 1), (0, 1)], v_mul(front_n(x), side))
        if P.lod < 2:
            for x in (-0.66, -0.62, 0.62, 0.66):
                _tube(P, PEACH, [cyl(x, y, side * (T / 2 + 0.002)) for y in (0.62, 1.20, 1.78)], 0.005, sides=4)
    # curved plinth with feet and under-glow
    m = P.n(16, 6)
    xs = [-0.92 + 1.84 * i / m for i in range(m + 1)]
    D, H = 0.11, 0.14
    for i in range(m):
        q = [cyl(xs[i], H, D), cyl(xs[i + 1], H, D), cyl(xs[i + 1], H, -D), cyl(xs[i], H, -D)]
        P.flat(PEACH, q, (0, 1, 0))
        xm = (xs[i] + xs[i + 1]) / 2
        for side in (1, -1):
            q = [cyl(xs[i], 0.0, side * D), cyl(xs[i + 1], 0.0, side * D), cyl(xs[i + 1], H, side * D), cyl(xs[i], H, side * D)]
            P.poly(WHITE, q, [(xs[i] / s, 0), (xs[i + 1] / s, 0), (xs[i + 1] / s, H / s), (xs[i] / s, H / s)],
                   v_mul(front_n(xm), side))
        for side in (1, -1):
            g = [cyl(xs[i], 0.012, side * (D + 0.002)), cyl(xs[i + 1], 0.012, side * (D + 0.002)),
                 cyl(xs[i + 1], 0.026, side * (D + 0.002)), cyl(xs[i], 0.026, side * (D + 0.002))]
            P.poly(GLOW, g, [(0, 0), (1, 0), (1, 1), (0, 1)], v_mul(front_n((xs[i] + xs[i + 1]) / 2), side))
    for x, sg in ((xs[0], -1), (xs[-1], 1)):
        q = [cyl(x, 0.0, D), cyl(x, 0.0, -D), cyl(x, H, -D), cyl(x, H, D)]
        P.flat(WHITE, q, v_mul(tang(x), sg))
    for sx in (-1, 1):
        fx = sx * 0.70
        c = cyl(fx, 0.06, 0.0)
        P.rbox(WHITE, c, (0.07, 0.06, 0.30), 0.05, r=(0, -math.degrees(fx / R), 0), seg=P.n(3, 1))
        if P.lod < 2:
            for sg in (1, -1):
                tip = v_add(c, v_mul(front_n(fx), sg * 0.30))
                P.box(GLOW, v_add(tip, v_mul(front_n(fx), sg * 0.0015)), (0.05, 0.008, 0.001), r=(0, -math.degrees(fx / R), 0),
                      bottom=False)


# ---------------------------------------------------------------------------------------------------------------
# registry
# ---------------------------------------------------------------------------------------------------------------

PIECES = {
    "bsp_data_terminal": (bsp_data_terminal, "interact"),
    "bsp_pod_chair": (bsp_pod_chair, "seat"),
    "bsp_light_sculpture": (bsp_light_sculpture, "lamp"),
    "bsp_coffee_table": (bsp_coffee_table, "table"),
    "bsp_planter": (bsp_planter, "decor"),
    "bsp_cloud_window": (bsp_cloud_window, "decor"),
}
_KEYS = ("bsp_white", "bsp_peach", "bsp_cushion", "bsp_glow", "bsp_core", "bsp_halo", "bsp_metal", "bsp_glass",
         "bsp_screen", "bsp_keypad", "bsp_emblem", "bsp_plant", "bsp_pod", "bsp_soil", "bsp_sky")
SLOTS = {"bsp": {k: k for k in _KEYS}}
UV = {"bsp_white": 0.8, "bsp_peach": 0.5, "bsp_cushion": 0.4, "bsp_glow": 0.3, "bsp_core": 0.3, "bsp_halo": 0.3,
      "bsp_metal": 0.3, "bsp_glass": 1.0, "bsp_screen": 1.0, "bsp_keypad": 1.0, "bsp_emblem": 1.0, "bsp_plant": 0.4,
      "bsp_pod": 0.15, "bsp_soil": 0.3, "bsp_sky": 1.0}
SMOOTH = ("bsp_white", "bsp_peach", "bsp_cushion", "bsp_glow", "bsp_core", "bsp_halo", "bsp_metal", "bsp_plant", "bsp_pod")
COLORS = {"bsp": (0.96, 0.88, 0.80)}
