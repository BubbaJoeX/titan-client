"""Naboo royal furniture (group nab): Theed palace pieces in cream marble, gold filigree, silk and flowers.

  nab_tea_service     interact (pour)  gilded two-tier tea cart: porcelain service, petit-four stand, spoked wheels
  nab_royal_settee    seat             camelback settee in cream damask, scrolled gold arms, cabriole legs, crest
  nab_globe_lamp      lamp             Theed street lamp: marble plinth, gilded post wound with a vine, three
                                       frosted glass globes
  nab_column_planter  decor            fluted marble column, gilded capital, urn of blooms with trailing vines
  nab_side_table      table            round marble top on three gilded cabriole legs, a vase of flowers
  nab_folding_screen  decor            four-panel screen: painted Theed panorama in gilded frames, damask back

Conventions as furniture.py: Maya space, y up, the piece stands on the origin, its front faces +z."""
from __future__ import annotations

import math

from ..furniture import (v_add, v_sub, v_mul, v_norm, v_len, smoothstep, seat_hardpoint, station_hardpoints,
                         light_hardpoint, UV as _UV)

GOLD, MARBLE, SILK, BROC = "nab_gold", "nab_marble", "nab_silk", "nab_brocade"
PORC, LEAF, POLLEN = "nab_porcelain", "nab_leaf", "nab_pollen"
BLOOMS = ("nab_bloom", "nab_bloom2", "nab_bloom3")


# ---------------------------------------------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------------------------------------------

def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _newell(q):
    nx = ny = nz = 0.0
    for i in range(len(q)):
        a, b = q[i], q[(i + 1) % len(q)]
        nx += (a[1] - b[1]) * (a[2] + b[2])
        ny += (a[2] - b[2]) * (a[0] + b[0])
        nz += (a[0] - b[0]) * (a[1] + b[1])
    return (nx, ny, nz)


def _centre(pts):
    n = len(pts)
    return (sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n, sum(p[2] for p in pts) / n)


def _hull(P, slot, rings, closed=True, flip=False, ut=1.0, vt=0.98, kref=None, scale=None):
    """Surface through rings of points (a 1-point ring is a pole) with one consistent winding; the side is picked
    so the reference band (default the widest) faces away from its axis (flip=True: toward it). Robust for
    leaves, petals, lobed shells."""
    m = max(len(r) for r in rings)
    R = [list(r) * m if len(r) == 1 else list(r) for r in rings]
    cen = [_centre(r) for r in R]
    cols = m if closed else m - 1
    nk = len(R) - 1
    if scale:                                        # world-scaled UVs: arc length round each ring, along the rings
        U = []
        for r in R:
            acc = [0.0]
            for j in range(cols):
                acc.append(acc[-1] + v_len(v_sub(r[(j + 1) % m], r[j])))
            U.append([a / scale for a in acc])
        Vk = [0.0]
        for k in range(nk):
            Vk.append(Vk[-1] + v_len(v_sub(cen[k + 1], cen[k])) / scale)
    faces = []
    for k in range(nk):
        for j in range(cols):
            j1 = (j + 1) % m
            q = [R[k][j], R[k][j1], R[k + 1][j1], R[k + 1][j]]
            n = _newell(q)
            if v_len(n) < 1e-14:
                continue
            if scale:
                uv = [(U[k][j], Vk[k]), (U[k][j + 1], Vk[k]), (U[k + 1][j + 1], Vk[k + 1]), (U[k + 1][j], Vk[k + 1])]
            else:
                uv = [(ut * j / cols, vt * k / nk), (ut * (j + 1) / cols, vt * k / nk),
                      (ut * (j + 1) / cols, vt * (k + 1) / nk), (ut * j / cols, vt * (k + 1) / nk)]
            faces.append((k, q, n, uv))
    spread = [sum(v_len(v_sub(p, c)) for p in r) / m for r, c in zip(R, cen)]
    if kref is None:
        kref = max(range(nk), key=lambda k: spread[k] + spread[k + 1])
    s = 0.0
    for k, q, n, _ in faces:
        if k == kref:
            s += _dot(v_norm(n), v_sub(_centre(q), v_mul(v_add(cen[k], cen[k + 1]), 0.5)))
    sign = (1.0 if s >= 0 else -1.0) * (-1.0 if flip else 1.0)
    for k, q, n, uv in faces:
        P.poly(slot, q, uv, v_mul(n, sign))


def _tube(P, slot, path, radius, sides=None, closed=False, caps=True, vscale=None):
    """F.sweep with each face oriented away from its own segment's midpoint (F.sweep uses the nearest path
    vertex, which flips faces along long straight runs and tight scrolls)."""
    path = [p for i, p in enumerate(path) if i == 0 or v_len(v_sub(p, path[i - 1])) > 1e-6]
    m = len(path)
    if m < 2:
        return
    sides = sides or P.n(8, 4)
    rad = radius if callable(radius) else (lambda t, rr=radius: rr)
    tang = []
    for k in range(m):
        a, b = (path[k - 1], path[(k + 1) % m]) if closed else (path[max(0, k - 1)], path[min(m - 1, k + 1)])
        tang.append(v_norm(v_sub(b, a)))
    up0 = (0.0, 1.0, 0.0) if abs(tang[0][1]) < 0.9 else (1.0, 0.0, 0.0)
    nrm = v_norm(_cross(_cross(tang[0], up0), tang[0]))
    L = [0.0]
    for k in range(1, m):
        L.append(L[-1] + v_len(v_sub(path[k], path[k - 1])))
    tot = L[-1] or 1.0
    rings = []
    for k in range(m):
        if k:
            nrm = v_norm(v_sub(nrm, v_mul(tang[k], _dot(nrm, tang[k]))))
        bn = _cross(tang[k], nrm)
        rr = rad(L[k] / tot)
        rings.append([v_add(path[k], v_add(v_mul(nrm, rr * math.cos(2 * math.pi * j / sides)),
                                           v_mul(bn, rr * math.sin(2 * math.pi * j / sides)))) for j in range(sides)])
    s = vscale or _UV.get(slot, 1.0)
    for k in range(m if closed else m - 1):
        k1 = (k + 1) % m
        c = v_mul(v_add(path[k], path[k1]), 0.5)
        la, lb = L[k] / s, (L[k] + v_len(v_sub(path[k1], path[k]))) / s
        for j in range(sides):
            j1 = (j + 1) % sides
            q = [rings[k][j], rings[k][j1], rings[k1][j1], rings[k1][j]]
            P.poly(slot, q, [(j / sides, la), ((j + 1) / sides, la), ((j + 1) / sides, lb), (j / sides, lb)],
                   v_sub(_centre(q), c))
    if caps and not closed:
        for k, sg in ((0, -1.0), (m - 1, 1.0)):
            if rad(L[k] / tot) > 1e-4:
                P.flat(slot, rings[k], v_mul(tang[k], sg))


def _ball(P, slot, c, r, n=None, rows=None, sy=1.0):
    """Low-poly sphere (beads, knobs, feet)."""
    n = n or P.n(8, 5)
    rows = rows or P.n(5, 3)
    prof = [(r * math.sin(math.pi * k / rows), -r * sy * math.cos(math.pi * k / rows)) for k in range(rows + 1)]
    P.lathe(slot, c, prof, n=n)


def _frame(axis):
    a = v_norm(axis)
    t = v_norm(_cross(a, (0.0, 0.0, 1.0) if abs(a[2]) < 0.9 else (1.0, 0.0, 0.0)))
    return a, t, _cross(a, t)


def _ring(P, slot, c, R, r, u=(1, 0, 0), v=(0, 0, 1), n=None, sides=None):
    """Torus: circle of radius R round c in the plane (u, v), tube radius r."""
    n = n or P.n(24, 8)
    pts = [v_add(c, v_add(v_mul(u, R * math.cos(2 * math.pi * k / n)), v_mul(v, R * math.sin(2 * math.pi * k / n))))
           for k in range(n)]
    _tube(P, slot, pts, r, closed=True, sides=sides or P.n(6, 4))


def _spline(ctrl, n):
    """Catmull-Rom through 3D control points, n + 1 samples."""
    m = len(ctrl) - 1
    out = []
    for i in range(n + 1):
        t = i / n * m
        k = min(int(t), m - 1)
        u = t - k
        p0, p1, p2, p3 = ctrl[max(k - 1, 0)], ctrl[k], ctrl[k + 1], ctrl[min(k + 2, m)]
        out.append(tuple(0.5 * (2 * p1[j] + (p2[j] - p0[j]) * u + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * u * u +
                                (3 * p1[j] - p0[j] - 3 * p2[j] + p3[j]) * u ** 3) for j in range(3)))
    return out


def _plane(o, u, v):
    return lambda x, y: (o[0] + u[0] * x + v[0] * y, o[1] + u[1] * x + v[1] * y, o[2] + u[2] * x + v[2] * y)


def _s_scroll(ca, ra, cb, rb, turns=1.1, n=10):
    """2D S-scroll: a spiral round ca unwinding toward cb and winding into a spiral round cb (opposite sense)."""
    phi = math.atan2(cb[1] - ca[1], cb[0] - ca[0])
    tha, thb = phi + math.pi / 2, phi - math.pi / 2
    pts = []
    for i in range(n + 1):                        # inner -> outer of A, moving clockwise at the outer point
        t = i / n
        a = tha + turns * 2 * math.pi * (1 - t)
        r = ra * (0.22 + 0.78 * t)
        pts.append((ca[0] + r * math.cos(a), ca[1] + r * math.sin(a)))
    for i in range(1, n + 1):                     # outer -> inner of B, counter-clockwise
        t = i / n
        a = thb + turns * 2 * math.pi * t
        r = rb * (1 - 0.78 * t)
        pts.append((cb[0] + r * math.cos(a), cb[1] + r * math.sin(a)))
    return pts


def _c_scroll(c, r0, a0, turns=1.2, sense=1, n=12, shrink=0.78):
    """2D spiral from radius r0 at angle a0 winding inward (sense +1 counter-clockwise)."""
    return [(c[0] + r0 * (1 - shrink * i / n) * math.cos(a0 + sense * turns * 2 * math.pi * i / n),
             c[1] + r0 * (1 - shrink * i / n) * math.sin(a0 + sense * turns * 2 * math.pi * i / n)) for i in range(n + 1)]


def _filigree(P, o, u, v, s, r=0.006, slot=GOLD, drop=True):
    """A lyre of two mirrored S-scrolls with a bead drop, in the plane (o; u right, v up), size s (half width)."""
    if P.lod >= 3:
        return
    pl = _plane(o, u, v)
    n = P.n(8, 4)
    for sx in (-1, 1):
        pts = _s_scroll((sx * 0.22 * s, 0.30 * s), 0.20 * s, (sx * 0.70 * s, -0.12 * s), 0.24 * s, turns=0.9, n=n)
        if sx < 0:
            pts = [(-x, y) for x, y in _s_scroll((0.22 * s, 0.30 * s), 0.20 * s, (0.70 * s, -0.12 * s), 0.24 * s, turns=0.9, n=n)]
        _tube(P, slot, [pl(x, y) for x, y in pts], r, sides=4)
    if drop and P.lod < 2:
        _ball(P, slot, pl(0.0, 0.05 * s), r * 2.2, n=6, rows=3)
        P.cone(slot, pl(0.0, -0.02 * s), pl(0.0, -0.45 * s), r * 1.6, n=5)


def _leaf(P, base, d, up, L, W, droop=0.35, slot=LEAF):
    """A leaf from `base` along d (its face toward `up`), length L, width W, drooping toward its tip."""
    d = v_norm(d)
    side = v_norm(_cross(d, up))
    upn = _cross(side, d)
    T = W * 0.14

    def at(s, w_, h_):
        return v_add(base, v_add(v_mul(d, s * L), v_add(v_mul(side, w_), v_mul(upn, h_ - droop * L * s * s))))
    rings = [[at(0, 0, 0)],
             [at(0.3, W * 0.45, 0), at(0.3, 0, T), at(0.3, -W * 0.45, 0), at(0.3, 0, -T * 0.5)],
             [at(0.66, W * 0.36, 0), at(0.66, 0, T * 0.8), at(0.66, -W * 0.36, 0), at(0.66, 0, -T * 0.4)],
             [at(1.0, 0, 0)]]
    _hull(P, slot, rings)


def _bloom(P, c, r, axis=(0, 1, 0), slot="nab_bloom", lobes=5, sharp=0.6, cup=0.30, twist=0.0, centre=POLLEN):
    """A rosette flower: lobed petal ring (cupped up by `cup`), calyx below, a pollen bead in the heart."""
    a, t, b = _frame(axis)
    per = P.n(4, 2)
    m = lobes * per

    def pt(rr, h, th):
        return v_add(c, v_add(v_add(v_mul(t, rr * math.cos(th)), v_mul(b, rr * math.sin(th))), v_mul(a, h)))

    def star(th):
        return 0.58 + 0.42 * abs(math.cos(lobes * (th - twist) / 2)) ** sharp
    ths = [twist + 2 * math.pi * j / m for j in range(m)]
    rings = [[pt(0.0, -0.42 * r, 0.0)],
             [pt(0.30 * r, -0.26 * r, th) for th in ths],
             [pt(r * star(th), cup * r * star(th) ** 3 - 0.05 * r, th) for th in ths],
             [pt(0.40 * r * star(th), 0.10 * r, th) for th in ths],
             [pt(0.0, 0.04 * r, 0.0)]]
    _hull(P, slot, rings, kref=1)                    # orient by the calyx-to-rim underside
    if centre and P.lod < 2:
        _ball(P, centre, v_add(c, v_mul(a, 0.08 * r)), 0.16 * r, n=5, rows=3)


def _bud(P, c, r, axis=(0, 1, 0), slot="nab_bloom"):
    a, t, b = _frame(axis)
    n = P.n(6, 4)
    rings = [[v_add(c, v_mul(a, -0.6 * r))]]
    for h, rr in ((-0.3, 0.7), (0.2, 0.85), (0.6, 0.5)):
        rings.append([v_add(c, v_add(v_mul(a, h * r), v_add(v_mul(t, rr * r * math.cos(2 * math.pi * k / n)),
                                                             v_mul(b, rr * r * math.sin(2 * math.pi * k / n))))) for k in range(n)])
    rings.append([v_add(c, v_mul(a, 1.1 * r))])
    _hull(P, slot, rings)


def _resample(ring, spacing):
    """Points every `spacing` metres along a closed (x, z) polyline."""
    segs = [(ring[i], ring[(i + 1) % len(ring)]) for i in range(len(ring))]
    total = sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in segs)
    cnt = max(4, int(round(total / spacing)))
    out, k, acc = [], 0, 0.0
    for i in range(cnt):
        target = total * i / cnt
        while acc + math.hypot(segs[k][1][0] - segs[k][0][0], segs[k][1][1] - segs[k][0][1]) < target:
            acc += math.hypot(segs[k][1][0] - segs[k][0][0], segs[k][1][1] - segs[k][0][1])
            k += 1
        a, b = segs[k]
        ln = math.hypot(b[0] - a[0], b[1] - a[1]) or 1.0
        f = (target - acc) / ln
        out.append((a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f))
    return out


def _round_rect(hx, hz, rc, nc):
    pts = []
    for cx, cz, a0 in ((hx - rc, hz - rc, 0), (-hx + rc, hz - rc, 90), (-hx + rc, -hz + rc, 180), (hx - rc, -hz + rc, 270)):
        for k in range(nc + 1):
            a = math.radians(a0 + 90 * k / nc)
            pts.append((cx + rc * math.cos(a), cz + rc * math.sin(a)))
    return pts


def _sheet2(P, slot_front, slot_back, pts, uvs_front, uvs_back, n, gap=0.0015):
    """A thin two-sided sheet: front face offset along n, back face along -n (each its own UVs and slot)."""
    n = v_norm(n)
    P.poly(slot_front, [v_add(p, v_mul(n, gap)) for p in pts], uvs_front, n)
    P.poly(slot_back, [v_sub(p, v_mul(n, gap)) for p in pts], uvs_back, v_mul(n, -1.0))


def _cabriole(P, top, out, r0=0.032, foot_r=0.028, slot=GOLD, knee=0.06, toe=0.035):
    """Cabriole leg from `top` (x, y, z) to a gold bun foot on the floor; the knee bows along `out` (xz unit)."""
    o = v_norm((out[0], 0.0, out[2]))
    h = top[1] - foot_r * 1.6
    offs = [(0.0, 0.0), (0.16, knee * 0.9), (0.34, knee), (0.62, knee * 0.15), (0.86, -0.004), (1.0, toe)]
    ctrl = [v_add((top[0], top[1] - h * t, top[2]), v_mul(o, d)) for t, d in offs]
    path = _spline(ctrl, P.n(14, 6))
    _tube(P, slot, path, lambda t: r0 * (1.0 + 0.25 * math.sin(math.pi * min(1.0, t / 0.5)) - 0.5 * smoothstep(0.35, 0.85, t)
                                        + 0.25 * smoothstep(0.85, 1.0, t)), sides=P.n(8, 5))
    foot = v_add((top[0], foot_r, top[2]), v_mul(o, toe + 0.01))
    _ball(P, slot, foot, foot_r, sy=0.95)
    if P.lod < 2:                                             # acanthus leaf at the knee
        kp = path[len(path) // 4]
        P.cone(slot, v_add(kp, v_mul(o, r0 * 0.8)), v_add(kp, v_add(v_mul(o, r0 * 1.6), (0, -0.07, 0))), r0 * 0.55, n=5)
    return path


# ---------------------------------------------------------------------------------------------------------------
# nab_tea_service
# ---------------------------------------------------------------------------------------------------------------

TEA_SPOT = (0.0, 0.0, 0.50)          # the server stands here, facing the cart (-z); top tray centre 0.5 m ahead


def _tray(P, y, hx, hz, rc, gallery=True, spacing=0.085):
    nc = P.n(5, 2)
    ring = _round_rect(hx, hz, rc, nc)
    P.prism(MARBLE, ring, y - 0.03, y, top=True, bottom=True, side_slot=GOLD, side_vscale=0.03)
    _tube(P, GOLD, [(x, y, z) for x, z in _round_rect(hx + 0.004, hz + 0.004, rc + 0.004, nc)], 0.009, closed=True,
          sides=P.n(4, 3))
    if P.lod < 3:
        _tube(P, GOLD, [(x, y - 0.03, z) for x, z in _round_rect(hx + 0.002, hz + 0.002, rc + 0.002, nc)], 0.007,
              closed=True, sides=P.n(4, 3))
    if gallery and P.lod < 3:
        rail = _round_rect(hx - 0.012, hz - 0.012, rc - 0.012, nc)
        _tube(P, GOLD, [(x, y + 0.052, z) for x, z in rail], 0.006, closed=True, sides=P.n(5, 3))
        if P.lod < 2:
            for x, z in _resample(rail, spacing * (1 if P.lod == 0 else 2)):
                P.lathe(GOLD, (x, y, z), [(0.0, 0.0), (0.007, 0.0), (0.0045, 0.014), (0.0075, 0.03), (0.004, 0.052),
                                          (0.0, 0.052)], n=4)


def _saucer(P, c, r=0.065):
    P.lathe(PORC, c, [(0.0, 0.0), (r * 0.55, 0.0), (r, 0.011), (r * 0.97, 0.014), (r * 0.5, 0.006), (0.0, 0.006)],
            n=P.n(14, 6))
    if P.lod < 1:
        P.lathe(GOLD, c, [(r * 0.97, 0.0115), (r * 1.0, 0.0125), (r * 0.985, 0.0145), (r * 0.97, 0.0115)], n=P.n(14, 6))


def _cup(P, c, handle_dir=(1, 0, 0)):
    """Teacup on a saucer at c (the saucer's base), tea inside, gilded rim, a loop handle."""
    _saucer(P, c)
    b = v_add(c, (0, 0.006, 0))
    P.lathe(PORC, b, [(0.0, 0.0), (0.02, 0.0), (0.022, 0.004), (0.034, 0.02), (0.041, 0.044), (0.039, 0.047),
                      (0.035, 0.04), (0.033, 0.034)], n=P.n(14, 6))
    P.disc("nab_tea", v_add(b, (0, 0.034, 0)), 0.0, 0.0335, n=P.n(14, 6))
    if P.lod < 1:
        P.lathe(GOLD, b, [(0.0405, 0.0445), (0.0415, 0.046), (0.0395, 0.0475), (0.0405, 0.0445)], n=P.n(14, 6))
    if P.lod < 2:
        d = v_norm(handle_dir)
        hp = [v_add(b, v_add(v_mul(d, 0.036 + 0.018 * math.sin(math.pi * k / 6)), (0, 0.040 - 0.026 * k / 6, 0)))
              for k in range(7)]
        _tube(P, PORC, hp, 0.0045, sides=4)


def _petit_four(P, c, slot, k):
    P.rbox(slot, v_add(c, (0, 0.014, 0)), (0.017, 0.014, 0.017), 0.004, r=(0, 20 * k, 0), seg=1)
    if P.lod < 1:
        _ball(P, BLOOMS[k % 3] if k % 2 else "nab_cake", v_add(c, (0, 0.032, 0)), 0.0065, n=5, rows=3)


def _teapot(P, c):
    n = P.n(16, 7)
    P.lathe(PORC, c, [(0.0, 0.0), (0.05, 0.0), (0.056, 0.008), (0.08, 0.04), (0.088, 0.075), (0.08, 0.11),
                      (0.058, 0.138), (0.047, 0.146), (0.05, 0.15), (0.044, 0.162), (0.026, 0.178), (0.0, 0.183)], n=n)
    for y, r in ((0.004, 0.053), (0.075, 0.089), (0.148, 0.05)):
        if P.lod < 1 or (y == 0.075 and P.lod < 3):
            P.lathe(GOLD, c, [(r - 0.001, y - 0.003), (r + 0.0025, y), (r - 0.001, y + 0.003), (r - 0.001, y - 0.003)], n=n)
    _ball(P, GOLD, v_add(c, (0, 0.194, 0)), 0.014, n=6, rows=3)
    # spout to +x, handle to -x
    sp = _spline([v_add(c, p) for p in ((0.06, 0.05, 0), (0.10, 0.07, 0), (0.135, 0.12, 0), (0.165, 0.155, 0))], P.n(7, 3))
    _tube(P, PORC, sp, lambda t: 0.019 * (1 - t) + 0.007 * t, sides=P.n(8, 4))
    hd = _spline([v_add(c, p) for p in ((-0.07, 0.125, 0), (-0.125, 0.13, 0), (-0.15, 0.09, 0), (-0.125, 0.045, 0),
                                        (-0.075, 0.035, 0))], P.n(9, 4))
    _tube(P, PORC, hd, 0.0085, sides=P.n(6, 4))
    if P.lod < 1:
        _tube(P, GOLD, [v_add(p, (0, 0.009, 0)) for p in hd[2:-2]], 0.003, sides=4)


def nab_tea_service(P):
    """Gilded tea cart: marble trays at 0.80 / 0.34 m (0.92 x 0.52), gold posts, two big spoked wheels at -x,
    scrolled legs and a push handle at +x. The server stands at TEA_SPOT facing the cart."""
    HX, HZ, RC = 0.46, 0.26, 0.10
    TOP, LOW = 0.80, 0.34
    lod = P.lod
    _tray(P, TOP, HX, HZ, RC, spacing=0.10)
    _tray(P, LOW, HX - 0.02, HZ - 0.02, RC - 0.02, spacing=0.22)
    # four turned gold posts through both trays, urn finials over the gallery
    posts = [(sx * (HX - 0.045), sz * (HZ - 0.045)) for sx in (-1, 1) for sz in (-1, 1)]
    for x, z in posts:
        y0 = 0.17 if x < 0 else 0.26
        if lod < 2:
            prof = [(0.0, 0.0), (0.016, 0.0), (0.016, 0.02), (0.012, 0.03), (0.012, LOW - 0.06 - y0),
                    (0.02, LOW - 0.045 - y0), (0.013, LOW - 0.03 - y0), (0.013, LOW + 0.04 - y0),
                    (0.022, LOW + 0.08 - y0), (0.011, LOW + 0.13 - y0), (0.010, TOP - 0.10 - y0),
                    (0.020, TOP - 0.07 - y0), (0.013, TOP - 0.03 - y0), (0.0, TOP - 0.03 - y0)]
        else:
            prof = [(0.0, 0.0), (0.016, 0.0), (0.012, 0.03), (0.012, TOP - 0.03 - y0), (0.0, TOP - 0.03 - y0)]
        P.lathe(GOLD, (x, y0, z), prof, n=P.n(8, 4))
        P.lathe(GOLD, (x, TOP, z), [(0.0, 0.0), (0.014, 0.0), (0.009, 0.02), (0.017, 0.045), (0.02, 0.06),
                                    (0.012, 0.075), (0.004, 0.09), (0.0, 0.10)] if lod < 2 else
                [(0.0, 0.0), (0.014, 0.0), (0.02, 0.06), (0.0, 0.10)], n=P.n(8, 4))
    # +x end: scrolled legs to bun feet
    for sz in (-1, 1):
        x, z = HX - 0.045, sz * (HZ - 0.045)
        _cabriole(P, (x, 0.27, z), (1.0, 0.0, 0.25 * sz), r0=0.018, foot_r=0.024, knee=0.05, toe=0.05)
    # -x end: big spoked wheels on an axle
    WX, WY, WZ, WR = -(HX - 0.045), 0.174, HZ + 0.07, 0.164
    _tube(P, GOLD, [(WX, WY, -WZ - 0.02), (WX, WY, WZ + 0.02)], 0.011, sides=P.n(8, 4))
    for sz in (-1, 1):
        cz = sz * WZ
        u, v = (1, 0, 0), (0, 1, 0)
        _ring(P, PORC, (WX, WY, cz), WR - 0.004, 0.010, u, v, n=P.n(28, 10), sides=P.n(4, 3))      # ivory tyre
        _ring(P, GOLD, (WX, WY, cz), WR - 0.020, 0.008, u, v, n=P.n(28, 10), sides=P.n(4, 3))      # gold rim
        if lod < 2:
            _ring(P, GOLD, (WX, WY, cz), 0.075, 0.005, u, v, n=P.n(20, 8), sides=4)
        P.lathe(GOLD, (WX, WY, cz), [(0.0, -0.032), (0.022, -0.032), (0.034, -0.016), (0.036, 0.0), (0.034, 0.016),
                                     (0.022, 0.032), (0.0, 0.032)], r=(90, 0, 0), n=P.n(10, 5))
        if lod < 2:
            _ball(P, GOLD, (WX, WY, cz + sz * 0.036), 0.014, n=6, rows=3)
        spokes = 8
        seg = P.n(6, 2)
        for k in range(spokes):
            a0 = 2 * math.pi * k / spokes
            bend = 0.32 * (1 if k % 2 else -1)
            path = []
            for j in range(seg + 1):
                t = j / seg
                rr = 0.032 + (WR - 0.052) * t
                a = a0 + bend * math.sin(math.pi * t)
                path.append((WX + rr * math.cos(a), WY + rr * math.sin(a), cz))
            _tube(P, GOLD, path, lambda t: 0.0065 - 0.002 * math.sin(math.pi * t), sides=P.n(4, 3), caps=False)
    # push handle at +x with an ivory grip
    hp = [(HX - 0.045 + 0.13 * math.cos(math.radians(a)), TOP + 0.10 + 0.03 * math.cos(math.radians(a)),
           (HZ - 0.045) * math.sin(math.radians(a))) for a in range(-90, 91, 12 if lod < 2 else 30)]
    _tube(P, GOLD, hp, 0.010, sides=P.n(7, 4))
    grip = [p for p in hp if abs(p[2]) < 0.11]
    _tube(P, PORC, grip, 0.017, sides=P.n(8, 4))
    if lod < 2:
        for p in (grip[0], grip[-1]):
            _ring(P, GOLD, p, 0.017, 0.005, (0, 1, 0), (1, 0, 0), n=P.n(10, 6), sides=4)
    # apron filigree under the top tray, front and back
    for sz in (-1, 1):
        _filigree(P, (0.0, TOP - 0.05, sz * (HZ + 0.006)), (sz, 0, 0), (0, 1, 0), 0.10, r=0.0055)
        for sx in (-1, 1):
            if lod < 2:
                pts = _c_scroll((sx * 0.25, TOP - 0.06), 0.035, math.pi / 2, turns=1.1, sense=sx * sz * -1, n=P.n(10, 5))
                _tube(P, GOLD, [(x, y, sz * (HZ + 0.006)) for x, y in pts], 0.005, sides=4)
    # --- the service on the top tray ---
    if lod < 3:
        P.disc("nab_lace", (-0.17, TOP + 0.0015, -0.03), 0.0, 0.14, fit=True, n=P.n(20, 8))
    _teapot(P, (-0.17, TOP + 0.002, -0.03))
    if lod < 3:
        _cup(P, (0.03, TOP, 0.13), (1, 0, 0.3))
        _cup(P, (0.20, TOP, 0.15), (1, 0, -0.2))
        _cup(P, (-0.35, TOP, 0.14), (1, 0, 0.5))
        sb = (0.03, TOP, -0.12)                                   # sugar bowl
        P.lathe(PORC, sb, [(0.0, 0.0), (0.026, 0.0), (0.03, 0.006), (0.045, 0.03), (0.046, 0.05), (0.04, 0.058),
                           (0.042, 0.062), (0.03, 0.075), (0.0, 0.08)], n=P.n(14, 6))
        _ball(P, GOLD, v_add(sb, (0, 0.088, 0)), 0.01, n=6, rows=3)
        if lod < 1:
            P.lathe(GOLD, sb, [(0.045, 0.047), (0.048, 0.05), (0.045, 0.053), (0.045, 0.047)], n=P.n(14, 6))
    # three-tier petit-four stand
    st = (0.25, TOP, -0.08)
    P.lathe(GOLD, st, [(0.0, 0.0), (0.035, 0.0), (0.03, 0.008), (0.008, 0.02), (0.006, 0.27), (0.0, 0.27)], n=P.n(8, 4))
    if lod < 3:
        _ring(P, GOLD, v_add(st, (0, 0.30, 0)), 0.025, 0.004, (1, 0, 0), (0, 1, 0), n=P.n(12, 6), sides=4)
    for k, (h, r, cnt) in enumerate(((0.03, 0.105, 4), (0.13, 0.08, 3), (0.22, 0.055, 2))):
        pc = v_add(st, (0, h, 0))
        P.lathe(PORC, pc, [(0.0, 0.0), (r * 0.6, 0.0), (r, 0.012), (r * 0.97, 0.015), (r * 0.6, 0.006), (0.0, 0.006)],
                n=P.n(14, 6))
        if lod < 1:
            P.lathe(GOLD, pc, [(r * 0.97, 0.0125), (r * 1.005, 0.0135), (r * 0.985, 0.0155), (r * 0.97, 0.0125)], n=P.n(14, 6))
        if lod < 2:
            for j in range(cnt if lod == 0 else max(2, cnt - 2)):
                a = 2 * math.pi * (j + 0.5 * k) / cnt
                rr = r * 0.62 if cnt > 3 else r * 0.45
                _petit_four(P, v_add(pc, (rr * math.cos(a), 0.006, rr * math.sin(a))), ("nab_cake", "nab_cake2")[(j + k) % 2], j + k)
    # folded silk napkin and a posy in a bud vase
    if lod < 3:
        P.rbox(BROC, (0.35, TOP + 0.008, 0.12), (0.06, 0.007, 0.06), 0.006, r=(0, 35, 0), seg=1)
        bv = (-0.36, TOP, -0.13)
        P.lathe(PORC, bv, [(0.0, 0.0), (0.022, 0.0), (0.03, 0.03), (0.022, 0.07), (0.012, 0.10), (0.018, 0.115),
                           (0.0, 0.115)], n=P.n(10, 5))
        for k, (dx, dz, ax, sl) in enumerate(((0.0, 0.0, (0, 1, 0.1), 0), (0.03, 0.02, (0.5, 0.8, 0.3), 1),
                                              (-0.03, 0.015, (-0.5, 0.8, 0.2), 2))):
            if lod >= 2 and k:
                continue
            top = v_add(bv, (dx, 0.17 - 0.02 * k, dz))
            _tube(P, LEAF, [v_add(bv, (0, 0.10, 0)), top], 0.003, sides=3)
            _bloom(P, top, 0.035, axis=ax, slot=BLOOMS[sl], lobes=5 + k)
    # --- lower tray: a gold cloche on a plate, a stack of plates, a bowl of blooms ---
    cl = (-0.20, LOW, 0.0)
    P.lathe(PORC, cl, [(0.0, 0.0), (0.09, 0.0), (0.13, 0.012), (0.125, 0.015), (0.08, 0.006), (0.0, 0.006)], n=P.n(16, 6))
    P.sphere(GOLD, v_add(cl, (0, 0.012, 0)), 0.11, lat0=0, lat1=90, sy=0.85, n=P.n(16, 6))
    P.disc(GOLD, v_add(cl, (0, 0.012, 0)), 0.0, 0.11, n=P.n(16, 6), down=True)
    if lod < 2:
        _ring(P, GOLD, v_add(cl, (0, 0.012, 0)), 0.112, 0.005, n=P.n(16, 8), sides=4)
    _ring(P, GOLD, v_add(cl, (0, 0.122, 0)), 0.022, 0.006, (1, 0, 0), (0, 1, 0), n=P.n(10, 5), sides=P.n(4, 3))
    if lod < 3:                                                   # a stack of four plates in one turned profile
        prof = [(0.0, 0.0), (0.05, 0.0)]
        for k in range(4):
            prof += [(0.09, 0.012 + 0.014 * k), (0.072, 0.014 + 0.014 * k)]
        prof += [(0.045, 0.05), (0.0, 0.05)]
        P.lathe(PORC, (0.10, LOW, 0.02), prof, n=P.n(16, 6))
        pb_ = (0.30, LOW, -0.04)
        P.lathe(PORC, pb_, [(0.0, 0.0), (0.04, 0.0), (0.07, 0.04), (0.075, 0.06), (0.068, 0.062), (0.0, 0.05)], n=P.n(14, 6))
        for k in range((3, 2, 1)[lod]):
            a = 2 * math.pi * k / 3 + 0.4
            _bloom(P, v_add(pb_, (0.03 * math.cos(a), 0.075, 0.03 * math.sin(a))), 0.032,
                   axis=(0.4 * math.cos(a), 1, 0.4 * math.sin(a)), slot=BLOOMS[k % 3], lobes=5 + k % 2)
    station_hardpoints(P, "pour", TEA_SPOT, yaw=180.0)


# ---------------------------------------------------------------------------------------------------------------
# nab_royal_settee
# ---------------------------------------------------------------------------------------------------------------

SETTEE_FRONT = 0.30


def _plate(P, slot, xs, ytop, ybot, z, t):
    """Vertical plate in x-y, front +z: column x samples, top ytop(x), bottom ybot(x), thickness t."""
    zf, zb = z + t / 2, z - t / 2
    for i in range(len(xs) - 1):
        x0, x1 = xs[i], xs[i + 1]
        a0, a1, b0, b1 = ytop(x0), ytop(x1), ybot(x0), ybot(x1)
        P.flat(slot, [(x0, b0, zf), (x1, b1, zf), (x1, a1, zf), (x0, a0, zf)], (0, 0, 1))
        P.flat(slot, [(x0, b0, zb), (x1, b1, zb), (x1, a1, zb), (x0, a0, zb)], (0, 0, -1))
        P.flat(slot, [(x0, b0, zf), (x1, b1, zf), (x1, b1, zb), (x0, b0, zb)], (b1 - b0, -(x1 - x0), 0))
        P.flat(slot, [(x0, a0, zf), (x1, a1, zf), (x1, a1, zb), (x0, a0, zb)], (-(a1 - a0), x1 - x0, 0))
    for x, s in ((xs[0], -1), (xs[-1], 1)):
        P.flat(slot, [(x, ybot(x), zf), (x, ybot(x), zb), (x, ytop(x), zb), (x, ytop(x), zf)], (s, 0, 0))


def nab_royal_settee(P):
    """Theed palace settee, 1.7 m. Seat top 0.46, front edge z 0.30 -> foot 0.475; the camelback leans back
    from z -0.25 (the sitter's back rests against it)."""
    W = 0.76
    # upholstered deck and the long seat cushion
    P.rbox(SILK, (0, 0.295, 0.02), (W, 0.055, 0.29), 0.03, seg=1 if P.lod >= 3 else 2)
    P.rbox(SILK, (0, 0.405, 0.025), (0.705, 0.05, 0.275), 0.045, puff=0.012, seg=1 if P.lod >= 3 else P.n(4, 2))
    if P.lod < 2:
        _tube(P, GOLD, [(-0.70, 0.40, 0.302), (0.70, 0.40, 0.302)], 0.006, sides=4)                   # piping cord
    # gold seat rail and the scalloped apron with its cartouche
    _tube(P, GOLD, [(-W - 0.01, 0.245, -0.27), (-W - 0.01, 0.245, 0.315), (W + 0.01, 0.245, 0.315), (W + 0.01, 0.245, -0.27)],
            0.016, sides=P.n(8, 4))
    xs = [-0.66 + 1.32 * k / P.n(24, 8) for k in range(P.n(24, 8) + 1)]
    _plate(P, GOLD, xs, lambda x: 0.238,
           lambda x: 0.205 - 0.075 * math.exp(-(x / 0.12) ** 2) - 0.012 * abs(math.sin(x / 0.66 * math.pi * 3)), 0.318, 0.018)
    P.lathe(GOLD, (0, 0.175, 0.325), [(0.0, 0.0), (0.05, 0.0), (0.056, 0.008), (0.04, 0.018), (0.0, 0.02)], r=(90, 0, 0),
            n=P.n(16, 8))
    if P.lod < 2:
        _bloom(P, (0, 0.175, 0.348), 0.03, axis=(0, 0, 1), slot=GOLD, lobes=6, centre=GOLD, cup=0.1)
    for sx in (-1, 1):
        _filigree(P, (sx * 0.30, 0.205, 0.329), (sx, 0, 0), (0, 1, 0), 0.085, r=0.006, drop=False)
    # cabriole legs at the corners
    for sx in (-1, 1):
        for sz, z in ((1, 0.27), (-1, -0.24)):
            _cabriole(P, (sx * 0.70, 0.245, z), (sx * 0.6, 0.0, sz), r0=0.03, knee=0.05, toe=0.04)
    # camelback: an upholstered loft along x, tilted back 10 degrees, gold frame along its crest
    M = P.n(26, 10)
    tilt = math.radians(10)
    ytop = lambda x: 0.74 + 0.27 * max(0.0, math.cos(math.pi * x / (2 * 0.80))) ** 0.8 + 0.035 * math.exp(-(x / 0.14) ** 2)
    zb = lambda x: -0.255 + 0.11 * (x / W) ** 2
    nc = P.n(3, 2)

    def section(x):
        h = ytop(x) - 0.34
        d0, rt, rb = 0.065, 0.06, 0.025
        loop = []
        for cx, cy, rr, a0 in ((d0 - rb, rb, rb, -90), (d0 - rt, h - rt, rt, 0), (-d0 + rt, h - rt, rt, 90),
                               (-d0 + rb, rb, rb, 180)):
            for k in range(nc + 1):
                a = math.radians(a0 + 90 * k / nc)
                loop.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
        return [(x, 0.34 + hh * math.cos(tilt) - 0.0, zb(x) + d * math.cos(tilt) - hh * math.sin(tilt)) for d, hh in loop]

    def on_back(x, d, hh):
        return (x, 0.34 + hh * math.cos(tilt), zb(x) + d * math.cos(tilt) - hh * math.sin(tilt))
    rings = [section(-W + 2 * W * i / M) for i in range(M + 1)]
    _hull(P, SILK, rings, scale=_UV.get(SILK, 0.5))
    P.flat(SILK, rings[0], (-1, 0, 0))
    P.flat(SILK, rings[-1], (1, 0, 0))
    crest = [on_back(x, 0.0, ytop(x) - 0.34 + 0.004) for x in [-W + 2 * W * i / M for i in range(M + 1)]]
    crest = [on_back(-W - 0.01, 0.0, 0.33)] + crest + [on_back(W + 0.01, 0.0, 0.33)]
    _tube(P, GOLD, crest, 0.02, sides=P.n(8, 5))
    # tufting buttons on the front of the back
    if P.lod < 2:
        for row, hh in enumerate((0.20, 0.38, 0.54)):
            for k in range(-3, 4):
                x = k * 0.19 + (0.095 if row % 2 else 0.0)
                if abs(x) > 0.62 or hh > ytop(x) - 0.34 - 0.08:
                    continue
                _ball(P, GOLD, on_back(x, 0.068, hh), 0.011, n=6, rows=3)
    # the crest: a gilded medallion with a flower, scrolls each side, a fan of rays
    cc = on_back(0.0, 0.0, ytop(0.0) - 0.34 + 0.07)
    P.lathe(GOLD, cc, [(0.0, -0.025), (0.075, -0.025), (0.085, 0.0), (0.075, 0.025), (0.0, 0.025)], r=(90 - 10, 0, 0),
            n=P.n(18, 8))
    for sg in ((1, -1) if P.lod < 3 else ()):
        _bloom(P, v_add(cc, (0, sg * 0.004, sg * 0.024)), 0.05, axis=(0, sg * math.sin(tilt), sg * math.cos(tilt)),
               slot=GOLD, lobes=8, centre="nab_bloom", cup=0.15)
    up_t = (0, math.cos(tilt), -math.sin(tilt))
    for sx in ((-1, 1) if P.lod < 3 else ()):
        pts = _s_scroll((sx * 0.10, 0.0), 0.05, (sx * 0.215, -0.072), 0.045, turns=1.0, n=P.n(12, 5))
        pl = _plane(cc, (1, 0, 0), up_t)
        _tube(P, GOLD, [pl(x, y) for x, y in pts], 0.009, sides=P.n(6, 4))
    for k in range(7 if P.lod < 3 else 0):
        a = math.radians(30 + 120 * k / 6)
        base = v_add(cc, v_mul(up_t, 0.06 * math.sin(a)))
        base = v_add(base, (0.06 * math.cos(a), 0, 0))
        tip = v_add(base, v_add((0.07 * math.cos(a), 0, 0), v_mul(up_t, (0.11 if k % 2 == 0 else 0.07) * math.sin(a))))
        P.cone(GOLD, base, tip, 0.014, n=P.n(6, 4))
    # scrolled arms: upholstered side panels and pads, gold volutes, turned supports
    for sx in (-1, 1):
        x = sx * 0.775
        P.rbox(SILK, (x, 0.50, -0.01), (0.045, 0.165, 0.245), 0.03, seg=1 if P.lod >= 3 else 2)
        P.rbox(SILK, (x, 0.675, 0.0), (0.065, 0.03, 0.28), 0.028, puff=0.008, seg=1 if P.lod >= 3 else P.n(3, 2))
        vol = [(x, 0.675 + 0.0, -0.26)] + [(x, 0.60 + r * math.sin(a), 0.28 + r * math.cos(a)) for r, a in
                                            [(0.075 * (1 - 0.72 * t), math.radians(90 - 400 * t)) for t in
                                             [k / P.n(16, 6) for k in range(P.n(16, 6) + 1)]]]
        _tube(P, GOLD, vol, lambda t: 0.022 - 0.01 * smoothstep(0.3, 1.0, t), sides=P.n(8, 5))
        for sxx in ((-1, 1) if P.lod < 3 else ()):                         # rosette caps on the volute faces
            P.lathe(GOLD, (x + sxx * 0.012, 0.60, 0.28), [(0.0, 0.0), (0.03, 0.0), (0.025, 0.008), (0.0, 0.01)],
                    r=(0, 0, -90 * sxx), n=P.n(12, 6))
        P.lathe(GOLD, (x, 0.245, 0.27), [(0.0, 0.0), (0.024, 0.0), (0.02, 0.02), (0.014, 0.05), (0.024, 0.11),
                                        (0.026, 0.16), (0.016, 0.22), (0.02, 0.27), (0.0, 0.29)], n=P.n(12, 6))
        # bolster against the arm, gold end rosettes and a tassel
        P.lathe(BROC, (sx * 0.61, 0.535, 0.03), [(0.0, -0.17), (0.055, -0.17), (0.074, -0.15), (0.078, 0.0), (0.074, 0.15),
                                                 (0.055, 0.17), (0.0, 0.17)], r=(90, 0, 0), n=P.n(16, 8))
        for ez in ((-1, 1) if P.lod < 3 else ()):
            P.lathe(GOLD, (sx * 0.61, 0.535, 0.03 + ez * 0.168), [(0.0, 0.0), (0.035, 0.0), (0.03, 0.01), (0.0, 0.012)],
                    r=(ez * 90, 0, 0), n=P.n(12, 6))
        if P.lod < 2:
            _tube(P, GOLD, [(sx * 0.61, 0.535, 0.21), (sx * 0.61, 0.50, 0.225), (sx * 0.61, 0.46, 0.225)], 0.003, sides=4)
            P.lathe(GOLD, (sx * 0.61, 0.38, 0.225), [(0.0, 0.0), (0.016, 0.0), (0.007, 0.06), (0.012, 0.075), (0.0, 0.085)],
                    n=P.n(8, 5))
    # throw pillows leaning on the back
    if P.lod < 3:
        P.rbox(BROC, (-0.40, 0.62, -0.17), (0.16, 0.15, 0.05), 0.05, r=(-18, 12, 4), puff=0.03, seg=1 if P.lod >= 3 else P.n(3, 2))
        P.rbox(SILK, (0.42, 0.61, -0.16), (0.15, 0.14, 0.05), 0.05, r=(-20, -14, -6), puff=0.03, seg=1 if P.lod >= 3 else P.n(3, 2))
        if P.lod < 2:
            for x, z, sgn in ((-0.40, -0.12, 1), (0.42, -0.11, -1)):
                _bloom(P, (x, 0.625, z + 0.01), 0.028, axis=(sgn * 0.2, 0.3, 0.93), slot=GOLD, lobes=6, centre=None, cup=0.1)
    seat_hardpoint(P, SETTEE_FRONT)


# ---------------------------------------------------------------------------------------------------------------
# nab_globe_lamp
# ---------------------------------------------------------------------------------------------------------------

def _globe(P, c, R, cage=6):
    """Frosted glass globe (alpha glow shell over an opaque glowing core) in a gold cup with a cap and a cage."""
    P.sphere("nab_glow", c, R * 0.992, n=P.n(20, 8))
    P.sphere("nab_glass", c, R, n=P.n(20, 8))
    P.lathe(GOLD, v_add(c, (0, -R * 0.98, 0)), [(0.0, -0.035), (0.025, -0.035), (0.02, -0.018), (0.035, -0.006),
                                                (R * 0.62, 0.012), (R * 0.66, 0.03), (R * 0.58, 0.026), (0.0, 0.01)],
            n=P.n(16, 8))
    P.lathe(GOLD, v_add(c, (0, R * 0.9, 0)), [(0.0, 0.0), (R * 0.45, 0.0), (R * 0.5, 0.015), (R * 0.3, 0.04),
                                              (0.012, 0.06), (0.0, 0.065)], n=P.n(14, 6))
    P.cone(GOLD, v_add(c, (0, R * 0.9 + 0.06, 0)), v_add(c, (0, R * 0.9 + 0.13, 0)), 0.01, n=P.n(6, 4))
    _ball(P, GOLD, v_add(c, (0, R * 0.9 + 0.075, 0)), 0.013, n=6, rows=3)
    if P.lod < 3:
        for k in range(cage):
            a = 2 * math.pi * k / cage
            path = [(c[0] + R * 1.012 * math.cos(math.radians(lat)) * math.cos(a), c[1] + R * 1.012 * math.sin(math.radians(lat)),
                     c[2] + R * 1.012 * math.cos(math.radians(lat)) * math.sin(a)) for lat in range(-62, 66, 16)]
            _tube(P, GOLD, path, 0.0035, sides=4)
        _ring(P, GOLD, c, R * 1.012, 0.004, n=P.n(20, 8), sides=4)


def nab_globe_lamp(P):
    """Theed street lamp, 2.2 m: marble plinth, a gilded baluster post wound with a flowering vine, an S-scroll
    crown carrying a 0.32 m frosted globe on top and two smaller globes on the arms."""
    P.lathe(MARBLE, (0, 0, 0), [(0.0, 0.0), (0.25, 0.0), (0.25, 0.035), (0.225, 0.05), (0.21, 0.09), (0.17, 0.115),
                                (0.155, 0.15), (0.0, 0.15)], n=P.n(28, 10))
    for y, r in ((0.042, 0.238), (0.118, 0.168)):
        P.lathe(GOLD, (0, 0, 0), [(r - 0.004, y - 0.008), (r + 0.006, y), (r - 0.004, y + 0.008), (r - 0.004, y - 0.008)], n=P.n(28, 10))
    # claw-scroll buttresses round the foot of the post
    for k in range(4):
        a = math.radians(45 + 90 * k)
        ca, sa = math.cos(a), math.sin(a)
        pts = [(0.03 * ca, 0.40, 0.03 * sa), (0.07 * ca, 0.30, 0.07 * sa), (0.12 * ca, 0.20, 0.12 * sa), (0.15 * ca, 0.155, 0.15 * sa)]
        _tube(P, GOLD, _spline(pts, P.n(8, 4)), lambda t: 0.012 + 0.008 * t, sides=P.n(6, 4))
        _ball(P, GOLD, (0.155 * ca, 0.165, 0.155 * sa), 0.02, n=6, rows=3)
    post = [(0.0, 0.0), (0.06, 0.0), (0.055, 0.03), (0.04, 0.08), (0.032, 0.26), (0.05, 0.30), (0.056, 0.34),
            (0.05, 0.38), (0.03, 0.42), (0.024, 1.12), (0.038, 1.16), (0.046, 1.22), (0.034, 1.27), (0.022, 1.30),
            (0.022, 1.42), (0.0, 1.42)]
    P.lathe(GOLD, (0, 0.15, 0), post, n=P.n(14, 8))
    if P.lod < 2:                                                 # flutes on the lower shaft
        for k in range(8):
            a = 2 * math.pi * k / 8
            _tube(P, GOLD, [(0.034 * math.cos(a), 0.45, 0.034 * math.sin(a)), (0.0335 * math.cos(a), 0.56, 0.0335 * math.sin(a))],
                    0.005, sides=4)
    # a flowering vine winding up the post
    m = P.n(40, 12)
    vine = [(0.032 * math.cos(2 * math.pi * 2.6 * k / m), 0.62 + 0.62 * k / m, 0.032 * math.sin(2 * math.pi * 2.6 * k / m))
            for k in range(m + 1)]
    _tube(P, LEAF, vine, 0.0055, sides=P.n(5, 3))
    if P.lod < 3:
        for i, k in enumerate(range(2, m, max(2, m // 14))):
            p = vine[k]
            out = v_norm((p[0], 0.0, p[2]))
            tang = v_norm(v_sub(vine[min(k + 1, m)], vine[k - 1]))
            if P.lod < 2:
                _leaf(P, p, v_add(out, (0, 0.5, 0)), _cross(out, tang), 0.055, 0.03, droop=0.4)
            if i % 2 == 1 and (P.lod < 2 or i % 4 == 1):
                _bloom(P, v_add(p, v_mul(out, 0.02)), 0.026, axis=v_add(out, (0, 0.3, 0)), slot=BLOOMS[i % 3], lobes=5)
    # the crown: collar, a centre stem to the main globe, S-scroll arms to the side globes
    yc = 1.57
    P.lathe(GOLD, (0, yc, 0), [(0.0, 0.0), (0.03, 0.0), (0.075, 0.03), (0.08, 0.045), (0.05, 0.05), (0.03, 0.08),
                               (0.022, 0.20), (0.0, 0.20)], n=P.n(14, 8))
    for k in range(P.n(8, 4)):                                    # gilded acanthus ring on the collar
        a = 2 * math.pi * k / P.n(8, 4)
        P.cone(GOLD, (0.06 * math.cos(a), yc + 0.04, 0.06 * math.sin(a)), (0.11 * math.cos(a), yc - 0.03, 0.11 * math.sin(a)),
               0.018, n=P.n(5, 3))
    main = (0.0, 1.97, 0.0)
    _globe(P, main, 0.16, cage=8)
    for sx in (-1, 1):
        g = (sx * 0.40, 1.80, 0.0)
        ctrl = [(0.0, yc + 0.05, 0.0), (sx * 0.08, yc + 0.01, 0.0), (sx * 0.18, yc - 0.03, 0.0), (sx * 0.28, yc - 0.01, 0.0),
                (sx * 0.36, yc + 0.035, 0.0), (sx * 0.395, yc + 0.07, 0.0), (g[0], 1.668, 0.0)]
        _tube(P, GOLD, _spline(ctrl, P.n(14, 5)), lambda t: 0.016 - 0.005 * t, sides=P.n(7, 4))
        # a spiral curl hanging under each arm, a leaf collar where the arm meets the cup
        curl = [(sx * 0.21, yc - 0.035)] + _c_scroll((sx * 0.21, yc - 0.09), 0.045, math.pi / 2, turns=1.15, sense=-sx,
                                                     n=P.n(12, 5))
        _tube(P, GOLD, [(x, y, 0.0) for x, y in curl], 0.0065, sides=P.n(5, 3))
        _globe(P, g, 0.105, cage=6)
        if P.lod < 2:
            for k in range(5):
                a = 2 * math.pi * k / 5
                P.cone(GOLD, (g[0] + 0.02 * math.cos(a), 1.655, 0.02 * math.sin(a)),
                       (g[0] + 0.05 * math.cos(a), 1.62, 0.05 * math.sin(a)), 0.012, n=4)
            for j in range(3):                                    # a tassel of blooms hanging from each arm
                _bloom(P, (sx * (0.30 + 0.015 * j), yc - 0.07 - 0.04 * j, 0.025 * (j - 1)), 0.022,
                       axis=(sx * 0.3, -0.2, 1 if j % 2 else -1), slot=BLOOMS[j], lobes=5)
            _tube(P, LEAF, [(sx * 0.29, yc - 0.015, 0.0), (sx * 0.30, yc - 0.07, 0.0), (sx * 0.33, yc - 0.15, 0.0)], 0.003,
                  sides=3)
    light_hardpoint(P, main)


# ---------------------------------------------------------------------------------------------------------------
# nab_column_planter
# ---------------------------------------------------------------------------------------------------------------

def _urn(P, base, scale=1.0, gadroons=12):
    """Gilded urn standing at `base`: foot, stem, gadrooned bowl, egg-and-dart rim; returns (rim centre, rim r)."""
    s = scale
    P.lathe(GOLD, base, [(0.0, 0.0), (0.085 * s, 0.0), (0.085 * s, 0.015 * s), (0.06 * s, 0.03 * s), (0.035 * s, 0.05 * s),
                         (0.03 * s, 0.075 * s), (0.05 * s, 0.09 * s), (0.0, 0.095 * s)], n=P.n(16, 8))
    # gadrooned lower bowl (lobed rings)
    m = gadroons * P.n(3, 2)
    rings = []
    for h, rr, lob in ((0.09, 0.05, 0.0), (0.12, 0.12, 0.10), (0.16, 0.165, 0.08), (0.20, 0.175, 0.0)):
        rings.append([(base[0] + rr * s * (1 + lob * math.cos(gadroons * 2 * math.pi * j / m)) * math.cos(2 * math.pi * j / m),
                       base[1] + h * s,
                       base[2] + rr * s * (1 + lob * math.cos(gadroons * 2 * math.pi * j / m)) * math.sin(2 * math.pi * j / m))
                      for j in range(m)])
    _hull(P, GOLD, rings, ut=4.0, vt=1.0)
    top = base[1] + 0.20 * s
    P.lathe(GOLD, (base[0], top, base[2]), [(0.0, -0.012 * s), (0.172 * s, -0.012 * s), (0.17 * s, 0.05 * s), (0.18 * s, 0.075 * s),
                                            (0.2 * s, 0.09 * s), (0.2 * s, 0.105 * s), (0.18 * s, 0.11 * s),
                                            (0.165 * s, 0.095 * s), (0.0, 0.085 * s)], n=P.n(24, 10))
    for sx in (-1, 1):                                            # scroll handles
        pts = _s_scroll((sx * 0.215 * s, 0.085 * s), 0.035 * s, (sx * 0.17 * s, -0.02 * s), 0.03 * s, turns=0.8, n=P.n(8, 4))
        pts = [(x, y) for x, y in pts]
        _tube(P, GOLD, [(base[0] + x, top + y, base[2]) for x, y in pts], 0.011 * s, sides=P.n(6, 4))
    return (base[0], top + 0.085 * s, base[2]), 0.165 * s


def nab_column_planter(P):
    """Fluted marble column (1.13 m) with a gilded acanthus capital, an urn of Naboo blooms, vines trailing down."""
    P.box(MARBLE, (0, 0.04, 0), (0.21, 0.04, 0.21))
    P.lathe(MARBLE, (0, 0.08, 0), [(0.0, 0.0), (0.19, 0.0), (0.19, 0.02), (0.175, 0.035), (0.155, 0.04), (0.15, 0.055),
                                   (0.165, 0.065), (0.15, 0.085), (0.13, 0.09), (0.0, 0.09)], n=P.n(28, 10))
    P.lathe(GOLD, (0, 0.08, 0), [(0.185, 0.018), (0.196, 0.026), (0.18, 0.034), (0.185, 0.018)], n=P.n(28, 10))
    # fluted shaft with entasis
    fl = 16
    per = P.n(4, 2)
    m = fl * per
    rings = []
    for y, R in ((0.17, 0.122), (0.45, 0.12), (0.75, 0.113), (1.0, 0.105)):
        ring = []
        for j in range(m):
            a = 2 * math.pi * j / m
            ph = (j % per) / per
            groove = math.sin(math.pi * ph) ** 2 if per > 2 else (0.7 if ph else 0.0)
            ring.append((R * (1 - 0.07 * groove) * math.cos(a), y, R * (1 - 0.07 * groove) * math.sin(a)))
        rings.append(ring)
    _hull(P, MARBLE, rings, ut=2.0, vt=1.0)
    P.lathe(MARBLE, (0, 0.165, 0), [(0.125, -0.01), (0.135, 0.0), (0.125, 0.012), (0.125, -0.01)], n=P.n(24, 10))
    # capital: astragal, a ring of gilded acanthus leaves, volutes, the abacus
    P.lathe(GOLD, (0, 1.0, 0), [(0.10, -0.005), (0.118, 0.006), (0.10, 0.017), (0.10, -0.005)], n=P.n(24, 10))
    P.lathe(MARBLE, (0, 1.012, 0), [(0.0, 0.0), (0.105, 0.0), (0.12, 0.03), (0.15, 0.065), (0.155, 0.075), (0.0, 0.075)],
            n=P.n(24, 10))
    nl = P.n(12, 6)
    for k in range(nl):
        a = 2 * math.pi * (k + 0.5) / nl
        out = (math.cos(a), 0.0, math.sin(a))
        base = (0.105 * out[0], 1.02, 0.105 * out[2])
        _leaf(P, base, v_add(v_mul(out, 0.45), (0, 1, 0)), _cross((0, 1, 0), out), 0.075, 0.05, droop=-0.35, slot=GOLD)
    P.box(MARBLE, (0, 1.105, 0), (0.17, 0.018, 0.17))
    P.box(GOLD, (0, 1.083, 0), (0.172, 0.004, 0.172))
    for sz in (-1, 1):
        for sx in (-1, 1):
            pts = _c_scroll((sx * 0.12, 1.06), 0.04, math.pi / 2, turns=1.25, sense=sx, n=P.n(12, 5))
            _tube(P, GOLD, [(x, y, sz * 0.165) for x, y in pts], 0.008, sides=P.n(6, 4))
    # the urn, a moss mound, a dome of blooms, buds and tall lilac spires
    rim, rr = _urn(P, (0, 1.123, 0), scale=1.0)
    P.sphere(LEAF, (rim[0], rim[1] - 0.02, rim[2]), rr * 0.98, lat0=0, lat1=90, sy=0.45, n=P.n(18, 8))
    blooms = []
    nb = (22, 14, 8, 5)[P.lod]
    gold_ang = math.pi * (3 - math.sqrt(5))
    for k in range(nb):
        f = (k + 0.5) / nb
        rad = rr * 0.92 * math.sqrt(f)
        a = k * gold_ang
        h = 0.10 * (1 - f) + 0.02
        blooms.append(((rad * math.cos(a), rim[1] + h, rad * math.sin(a)), a, f))
    for k, (p, a, f) in enumerate(blooms):
        ax = (math.cos(a) * f * 0.9, 1.0, math.sin(a) * f * 0.9)
        _bloom(P, p, 0.045 if k % 4 else 0.055, axis=ax, slot=BLOOMS[k % 3], lobes=(5, 6, 8)[k % 3],
               sharp=(0.6, 0.9, 1.6)[k % 3], twist=k * 0.7)
        if P.lod < 2 and k % 2 == 0:
            _leaf(P, v_add(p, (0, -0.02, 0)), (math.cos(a + 0.6), 0.15, math.sin(a + 0.6)), (0, 1, 0), 0.07, 0.035, droop=0.4)
    if P.lod < 3:                                                 # tall spires of tiny lilac blooms
        for k, (dx, dz, hgt) in enumerate(((-0.05, -0.06, 0.34), (0.06, -0.03, 0.28), (0.0, 0.07, 0.24))):
            base = (dx, rim[1] + 0.05, dz)
            tip = (dx * 1.6, rim[1] + hgt, dz * 1.6)
            _tube(P, LEAF, [base, tip], 0.005, sides=4)
            for j in range(P.n(7, 3)):
                t = 0.35 + 0.65 * j / max(1, P.n(7, 3) - 1)
                p = v_add(base, v_mul(v_sub(tip, base), t))
                if P.lod < 2:
                    _bloom(P, p, 0.022 * (1.2 - 0.6 * t), axis=(math.cos(j * 2.4), 0.6, math.sin(j * 2.4)), slot="nab_bloom2",
                           lobes=5, centre=None)
                else:
                    _bud(P, p, 0.015, slot="nab_bloom2")
    # trailing vines spilling over the rim and down the column
    nv = (4, 3, 2, 0)[P.lod]
    for k in range(nv):
        a = math.radians(30 + 90 * k + 20 * (k % 2))
        ca, sa = math.cos(a), math.sin(a)
        ctrl = [(0.12 * ca, rim[1], 0.12 * sa), (0.22 * ca, rim[1] + 0.02, 0.22 * sa), (0.25 * ca, rim[1] - 0.12, 0.25 * sa),
                (0.20 * ca + 0.05 * sa, rim[1] - 0.32 - 0.05 * k, 0.20 * sa - 0.05 * ca),
                (0.15 * ca - 0.04 * sa, rim[1] - 0.55 - 0.08 * k, 0.15 * sa + 0.04 * ca)]
        path = _spline(ctrl, P.n(16, 6))
        _tube(P, LEAF, path, lambda t: 0.007 * (1 - 0.6 * t), sides=P.n(5, 3))
        step = max(1, len(path) // (8 if P.lod == 0 else 4))
        for j in range(2, len(path) - 1, step):
            p = path[j]
            out = v_norm((p[0], 0.0, p[2]))
            side = 1 if j % 2 else -1
            tang = v_norm(v_sub(path[j + 1], path[j - 1]))
            sd = _cross(tang, out)
            if P.lod < 2:
                _leaf(P, p, v_add(v_mul(sd, side), v_mul(tang, 0.6)), out, 0.06, 0.032, droop=0.3)
            if j % 3 == 1:
                _bloom(P, v_add(p, v_mul(out, 0.015)), 0.03, axis=v_add(out, (0, 0.2, 0)), slot=BLOOMS[(j + k) % 3], lobes=5)


# ---------------------------------------------------------------------------------------------------------------
# nab_side_table
# ---------------------------------------------------------------------------------------------------------------

def nab_side_table(P):
    """Round marble side table, top 0.665 m, r 0.35, on three gilded cabriole legs with a scrolled stretcher, a
    porcelain vase of flowers on a lace doily."""
    TOP = 0.665
    P.lathe(MARBLE, (0, 0, 0), [(0.0, TOP - 0.045), (0.31, TOP - 0.045), (0.335, TOP - 0.036), (0.35, TOP - 0.02),
                                (0.346, TOP - 0.006), (0.335, TOP), (0.0, TOP)], n=P.n(36, 12))
    P.lathe(GOLD, (0, 0, 0), [(0.30, TOP - 0.055), (0.318, TOP - 0.046), (0.30, TOP - 0.038), (0.30, TOP - 0.055)], n=P.n(36, 12))
    # apron ring with hanging filigree between the legs
    P.lathe(GOLD, (0, 0, 0), [(0.0, TOP - 0.11), (0.27, TOP - 0.11), (0.285, TOP - 0.10), (0.28, TOP - 0.06),
                              (0.29, TOP - 0.05), (0.0, TOP - 0.045)], n=P.n(32, 12))
    for k in range(3):
        a = math.radians(90 + 120 * k)
        ca, sa = math.cos(a), math.sin(a)
        _cabriole(P, (0.235 * ca, TOP - 0.06, 0.235 * sa), (ca, 0, sa), r0=0.03, foot_r=0.026, knee=0.075, toe=0.05)
        b = math.radians(150 + 120 * k)
        cb, sb = math.cos(b), math.sin(b)
        _filigree(P, (0.289 * cb, TOP - 0.10, 0.289 * sb), (sb, 0, -cb), (0, 1, 0), 0.075, r=0.0055)
        # stretcher bar from the leg's ankle rising to the centre finial
        pts = _spline([(0.235 * ca + 0.02 * ca, 0.17, 0.235 * sa + 0.02 * sa), (0.15 * ca, 0.20, 0.15 * sa),
                       (0.06 * ca, 0.24, 0.06 * sa), (0.0, 0.25, 0.0)], P.n(8, 4))
        _tube(P, GOLD, pts, 0.011, sides=P.n(6, 4))
        if P.lod < 2:
            curl = _c_scroll((0.0, 0.0), 0.035, math.pi, turns=1.1, sense=-1, n=P.n(10, 5))
            u = (ca, 0, sa)
            _tube(P, GOLD, [v_add((0.13 * ca, 0.215, 0.13 * sa), v_add(v_mul(u, x), (0, y, 0))) for x, y in curl], 0.005, sides=4)
    P.lathe(GOLD, (0, 0.20, 0), [(0.0, 0.0), (0.025, 0.0), (0.04, 0.03), (0.03, 0.05), (0.02, 0.06), (0.03, 0.08),
                                 (0.0, 0.09)], n=P.n(12, 6))
    _ball(P, MARBLE, (0, 0.33, 0), 0.045, n=P.n(12, 6), rows=P.n(6, 4))
    P.cone(GOLD, (0, 0.205, 0), (0, 0.12, 0), 0.02, n=P.n(8, 4))
    # on top: lace doily, baluster vase with a bouquet, a little gilt box
    P.disc("nab_lace", (0.02, TOP + 0.0015, -0.02), 0.0, 0.16, fit=True, n=P.n(24, 10))
    vb = (0.02, TOP, -0.02)
    P.lathe(PORC, vb, [(0.0, 0.0), (0.045, 0.0), (0.05, 0.01), (0.04, 0.02), (0.07, 0.07), (0.075, 0.11), (0.055, 0.16),
                       (0.035, 0.19), (0.04, 0.215), (0.05, 0.225), (0.042, 0.228), (0.0, 0.21)], n=P.n(20, 8))
    for y, r in ((0.012, 0.05), (0.11, 0.077), (0.222, 0.05)):
        P.lathe(GOLD, vb, [(r - 0.002, y - 0.004), (r + 0.002, y), (r - 0.002, y + 0.004), (r - 0.002, y - 0.004)], n=P.n(20, 8))
    top = v_add(vb, (0, 0.215, 0))
    nb = (11, 7, 5, 3)[P.lod]
    ga = math.pi * (3 - math.sqrt(5))
    for k in range(nb):
        f = (k + 0.5) / nb
        a = k * ga
        d = (0.16 * math.sqrt(f) * math.cos(a), 0.0, 0.16 * math.sqrt(f) * math.sin(a))
        head = v_add(top, (d[0], 0.17 - 0.07 * f + 0.02 * math.sin(k), d[2]))
        _tube(P, LEAF, _spline([top, v_add(top, (d[0] * 0.3, 0.06, d[2] * 0.3)), head], P.n(4, 2)), 0.0035,
              sides=4 if P.lod < 2 else 3)
        _bloom(P, head, 0.04 if k % 3 else 0.05, axis=(d[0] * 4, 1.0, d[2] * 4), slot=BLOOMS[k % 3], lobes=(5, 6, 8)[k % 3],
               sharp=(0.6, 0.9, 1.6)[k % 3], twist=k)
        if P.lod < 2 and k % 2:
            _leaf(P, v_add(top, (d[0] * 0.5, 0.07, d[2] * 0.5)), (d[0] * 6, 0.4, d[2] * 6), (0, 1, 0), 0.08, 0.035, droop=0.45)
    gb = (-0.16, TOP, 0.13)
    P.box(GOLD, v_add(gb, (0, 0.022, 0)), (0.05, 0.022, 0.035), r=(0, 25, 0))
    P.box(MARBLE, v_add(gb, (0, 0.049, 0)), (0.054, 0.005, 0.039), r=(0, 25, 0))
    _ball(P, GOLD, v_add(gb, (0, 0.06, 0)), 0.009, n=6, rows=3)


# ---------------------------------------------------------------------------------------------------------------
# nab_folding_screen
# ---------------------------------------------------------------------------------------------------------------

def nab_folding_screen(P):
    """Four-panel folding screen, 1.75 m wide: gilded tube frames with arched tops (the inner panels taller), a
    painted Theed panorama running across the front silk, damask with a royal medallion on the back, a brocade
    lower panel with filigree, hinges, finials and ball feet."""
    N, WP, ANG = 4, 0.48, 24.0
    heights = (1.66, 1.80, 1.80, 1.66)
    rise = 0.12
    fr = 0.02
    total = N * WP * math.cos(math.radians(ANG))
    hinge = [(-total / 2, 0.0)]
    for k in range(N):
        a = math.radians(-ANG if k % 2 == 0 else ANG)
        hinge.append((hinge[-1][0] + WP * math.cos(a), hinge[-1][1] + WP * math.sin(a)))
    zc = sum(z for _, z in hinge) / len(hinge)
    hinge = [(x, z - zc) for x, z in hinge]
    y_lo, y_mid = 0.10, 0.50
    v0, v1 = y_mid, max(heights)
    for k in range(N):
        (ax, az), (bx, bz) = hinge[k], hinge[k + 1]
        d = (bx - ax, 0.0, bz - az)
        L = v_len(d)
        d = v_mul(d, 1 / L)
        n = (-d[2], 0.0, d[0])                                   # the front (+z side)
        if n[2] < 0:
            n = v_mul(n, -1)
        H = heights[k]

        def P3(s, y, off=0.0, ax=ax, az=az, d=d, n=n):
            return (ax + d[0] * s + n[0] * off, y, az + d[2] * s + n[2] * off)
        s0, s1 = fr + 0.004, L - fr - 0.004
        wspan = s1 - s0

        def top_y(s, H=H, s0=s0, wspan=wspan):
            t = (s - s0) / wspan
            return H - rise + rise * math.sin(math.pi * t) ** 0.6
        na = P.n(12, 5)
        arch = [(s0 + wspan * i / na, top_y(s0 + wspan * i / na)) for i in range(na + 1)]
        outline = [(s0, y_lo)] + [(s1, y_lo)] + arch[::-1]
        _tube(P, GOLD, [P3(s, y) for s, y in outline], fr, closed=True, sides=P.n(8, 5))
        _tube(P, GOLD, [P3(s0, y_mid), P3(s1, y_mid)], fr * 0.8, sides=P.n(8, 5))
        # upper silk: the panorama in front (u spans this panel's quarter), damask medallion behind
        poly = [(s0 + fr * 0.4, y_mid), (s1 - fr * 0.4, y_mid)] + [(s, top_y(s) - fr * 0.4) for s, _ in arch[::-1]
                                                                   if s0 + fr * 0.4 <= s <= s1 - fr * 0.4]
        poly = [(s1 - fr * 0.4 if s > s1 - fr * 0.4 else s, y) for s, y in poly]
        pts = [P3(s, y) for s, y in poly]
        uf = [((k + (s - s0) / wspan) / N, (y - v0) / (v1 - v0)) for s, y in poly]
        ub = [((N - 1 - k + 1 - (s - s0) / wspan) / N, (y - v0) / (v1 - v0)) for s, y in poly]
        _sheet2(P, "nab_panel", "nab_panel_back", pts, uf, ub, n)
        # lower brocade panel, filigree on both faces
        low = [(s0, y_lo), (s1, y_lo), (s1, y_mid), (s0, y_mid)]
        lp = [P3(s, y) for s, y in low]
        luv = [(s / 0.4, y / 0.4) for s, y in low]
        _sheet2(P, BROC, BROC, lp, luv, luv, n)
        for off in (-1, 1):
            o = P3((s0 + s1) / 2, (y_lo + y_mid) / 2 + 0.02, off * 0.004)
            _filigree(P, o, d if off > 0 else v_mul(d, -1), (0, 1, 0), 0.17, r=0.0055)
        # ball feet and turned posts under the corners
        for s in (s0, s1):
            p = P3(s, 0.0)
            _ball(P, GOLD, (p[0], 0.032, p[2]), 0.032, n=P.n(10, 5), rows=P.n(5, 3))
            if P.lod < 3:
                P.lathe(GOLD, (p[0], 0.055, p[2]), [(0.0, 0.0), (0.016, 0.0), (0.011, 0.02), (0.016, 0.045), (0.0, 0.05)],
                        n=P.n(8, 5))
        # arch crest: a gilded bloom and spire on both faces
        ct = P3((s0 + s1) / 2, H + fr * 0.6)
        P.lathe(GOLD, ct, [(0.0, 0.0), (0.03, 0.0), (0.035, 0.02), (0.02, 0.045), (0.008, 0.06), (0.0, 0.13)], n=P.n(10, 5))
        if P.lod < 3:
            _ball(P, GOLD, v_add(ct, (0, 0.07, 0)), 0.018, n=6, rows=3)
        for off in ((-1, 1) if P.lod < 2 else ()):
            _bloom(P, P3((s0 + s1) / 2, H - rise * 0.5, off * (fr + 0.01)), 0.045, axis=v_mul(n, off), slot=GOLD, lobes=6,
                   centre="nab_bloom", cup=0.1)
    # hinges between the panels, tall finials at the two ends
    for k in range(1, N):
        x, z = hinge[k]
        for y in ((0.30, 0.95, 1.45) if P.lod < 3 else (0.30, 1.45)):
            P.lathe(GOLD, (x, y - 0.04, z), [(0.0, 0.0), (0.013, 0.0), (0.013, 0.08), (0.0, 0.08)], n=P.n(8, 4))
            if P.lod < 2:
                _ball(P, GOLD, (x, y + 0.045, z), 0.009, n=6, rows=3)
    for k, (x, z) in ((0, hinge[0]), (N, hinge[N])):
        a = (hinge[1][0] - x, hinge[1][1] - z) if k == 0 else (hinge[N - 1][0] - x, hinge[N - 1][1] - z)
        ln = math.hypot(*a)
        px, pz = x + a[0] / ln * (fr + 0.004), z + a[1] / ln * (fr + 0.004)
        h = heights[0 if k == 0 else N - 1] - rise
        P.lathe(GOLD, (px, h, pz), [(0.0, 0.0), (0.024, 0.0), (0.03, 0.03), (0.018, 0.06), (0.026, 0.09), (0.0, 0.10)],
                n=P.n(10, 6))
        P.cone(GOLD, (px, h + 0.10, pz), (px, h + 0.20, pz), 0.012, n=P.n(6, 4))


# ---------------------------------------------------------------------------------------------------------------
# registry
# ---------------------------------------------------------------------------------------------------------------

PIECES = {
    "nab_tea_service": (nab_tea_service, "interact"),
    "nab_royal_settee": (nab_royal_settee, "seat"),
    "nab_globe_lamp": (nab_globe_lamp, "lamp"),
    "nab_column_planter": (nab_column_planter, "decor"),
    "nab_side_table": (nab_side_table, "table"),
    "nab_folding_screen": (nab_folding_screen, "decor"),
}
_KEYS = ("nab_marble", "nab_gold", "nab_silk", "nab_brocade", "nab_porcelain", "nab_glass", "nab_glow", "nab_leaf",
         "nab_bloom", "nab_bloom2", "nab_bloom3", "nab_pollen", "nab_cake", "nab_cake2", "nab_tea", "nab_lace",
         "nab_panel", "nab_panel_back")
SLOTS = {"nab": {k: k for k in _KEYS}}
UV = {"nab_marble": 0.8, "nab_gold": 0.3, "nab_silk": 0.5, "nab_brocade": 0.4, "nab_porcelain": 0.25, "nab_glass": 0.4,
      "nab_glow": 0.4, "nab_leaf": 0.15, "nab_bloom": 0.1, "nab_bloom2": 0.1, "nab_bloom3": 0.1, "nab_pollen": 0.05,
      "nab_cake": 0.08, "nab_cake2": 0.08, "nab_tea": 0.1, "nab_lace": 1.0, "nab_panel": 1.0, "nab_panel_back": 1.0}
SMOOTH = ("nab_silk", "nab_brocade", "nab_porcelain", "nab_glass", "nab_glow", "nab_leaf", "nab_bloom", "nab_bloom2",
          "nab_bloom3", "nab_pollen", "nab_cake", "nab_cake2", "nab_gold")
COLORS = {"nab": (0.93, 0.89, 0.80)}
