"""Sith set (Mustafar / Sith temple): black obsidian, lava, red kyber - angular and menacing. Pieces sith_*,
materials sith_* (examples/frn_sets/sith.py).

  sith_dark_shrine      kneeling cushion before a carved obsidian stele of glowing runes and a red Sith holocron
                        floating over a pedestal                                                interact (kneel)
  sith_throne           angular obsidian throne on a stepped dais, lava-vein seams, a tall crown of blades  seat
  sith_lava_brazier     faceted obsidian bowl brimming with molten lava on four taloned legs, embers        lamp
  sith_hooded_statue    a hooded Sith in robes, hands resting on the pommel of an ancient sword, on a plinth
  sith_saber_rack       crossed red lightsabers (straight and curved hilts), a double-bladed saber, kyber
  sith_obsidian_table   low obsidian table with glowing lava inlay channels                         table"""
from __future__ import annotations

import math
import random
from contextlib import contextmanager

from .. import furniture as _fu
from ..furniture import v_add, v_cross, v_len, v_mul, v_norm, v_sub, xf, smoothstep, seat_hardpoint, \
    station_hardpoints, light_hardpoint

SHRINE_SPOT = (0.0, 0.0, 0.62)        # the kneeling player's feet: on the cushion, the holocron 0.7 m ahead (-z)


# ---------------------------------------------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------------------------------------------

@contextmanager
def _tx(P, c=(0.0, 0.0, 0.0), r=(0.0, 0.0, 0.0), s=(1.0, 1.0, 1.0), pivot=(0.0, 0.0, 0.0)):
    """Add a sub-assembly through: scale s (local axes), rotate r about pivot, translate c."""
    old = P.xform

    def f(p):
        q = xf((p[0] * s[0], p[1] * s[1], p[2] * s[2]), c, r, pivot)
        return old(q) if old else q
    P.xform = f
    try:
        yield
    finally:
        P.xform = old


def _ellipsoid(P, slot, c, rad, r=(0.0, 0.0, 0.0), lat0=-90.0, lat1=90.0, n=None, inside=False, rows=None):
    rows = rows or max(2, P.n(12, 4) * int(abs(lat1 - lat0)) // 180 or 2)
    prof = [(math.cos(math.radians(lat0 + (lat1 - lat0) * k / rows)), math.sin(math.radians(lat0 + (lat1 - lat0) * k / rows)))
            for k in range(rows + 1)]
    s = _fu.UV.get(slot, 1.0)
    m = max(rad)
    with _tx(P, c, r, rad):
        P.lathe(slot, (0.0, 0.0, 0.0), prof, n=n or P.n(16, 6), utiles=max(1, round(2 * math.pi * m / s)), vscale=s / m,
                inside=inside)


def _spline(ctrl, n):
    """Catmull-Rom curve through the control points (tuples of any length), n segments."""
    m = len(ctrl)
    out = []
    for i in range(n + 1):
        s = i / n * (m - 1)
        k = min(int(s), m - 2)
        t = s - k
        p0, p1, p2, p3 = ctrl[max(k - 1, 0)], ctrl[k], ctrl[k + 1], ctrl[min(k + 2, m - 1)]
        out.append(tuple(0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t + (-a + 3 * b - 3 * c + d) * t ** 3)
                         for a, b, c, d in zip(p0, p1, p2, p3)))
    return out


def _yaxis_to(n):
    """Euler angles (rx, ry, rz) for furniture.rot that turn local +y onto direction n."""
    n = v_norm(n)
    b = math.degrees(math.acos(max(-1.0, min(1.0, n[1]))))
    c = math.degrees(math.atan2(n[2], -n[0])) if abs(n[1]) < 0.9999 else 0.0
    return (0.0, c, b)


def _inset(poly, d):
    """Convex polygon [(u, v)] offset inward by d (outward for d < 0), corners mitred."""
    n = len(poly)
    area = sum(poly[i][0] * poly[(i + 1) % n][1] - poly[(i + 1) % n][0] * poly[i][1] for i in range(n))
    sgn = 1.0 if area > 0 else -1.0
    lines = []
    for i in range(n):
        (ax, ay), (bx, by) = poly[i], poly[(i + 1) % n]
        dx, dy = bx - ax, by - ay
        ln = math.hypot(dx, dy) or 1.0
        nx, ny = -dy / ln * sgn, dx / ln * sgn
        lines.append(((ax + nx * d, ay + ny * d), (dx, dy)))
    out = []
    for i in range(n):
        (p, r), (q, s) = lines[i - 1], lines[i]
        den = r[0] * s[1] - r[1] * s[0]
        if abs(den) < 1e-12:
            out.append(q)
            continue
        t = ((q[0] - p[0]) * s[1] - (q[1] - p[1]) * s[0]) / den
        out.append((p[0] + t * r[0], p[1] + t * r[1]))
    return out


def _extrude(P, slot, outline, a0, a1, chamfer=0.0, axis="y", side_slot=None, cap0=True):
    """Convex outline extruded from a0 to a1 along an axis, edges chamfered. axis "y": outline = plan (x, z);
    "z": outline = elevation (x, y); "x": outline = side elevation (z, y)."""
    M = (lambda u, v, w: (u, w, v)) if axis == "y" else (lambda u, v, w: (u, v, w)) if axis == "z" else (lambda u, v, w: (w, v, u))
    n = len(outline)
    c = chamfer
    inner = _inset(outline, c) if c > 0 else outline
    cu, cv = sum(p[0] for p in outline) / n, sum(p[1] for p in outline) / n
    mid = M(cu, cv, (a0 + a1) / 2)
    lev = [(inner, a0), (outline, a0 + c), (outline, a1 - c), (inner, a1)] if c > 0 else [(outline, a0), (outline, a1)]
    side_k = 1 if c > 0 else 0                                  # the straight sides (not the chamfers)
    for k in range(len(lev) - 1):
        (ra, wa), (rb, wb) = lev[k], lev[k + 1]
        for i in range(n):
            j = (i + 1) % n
            q = [M(*ra[i], wa), M(*ra[j], wa), M(*rb[j], wb), M(*rb[i], wb)]
            cen = tuple(sum(p[x] for p in q) / 4 for x in range(3))
            P.flat(side_slot if side_slot and k == side_k else slot, q, v_sub(cen, mid))
    P.flat(slot, [M(u, v, a1) for u, v in inner], M(0.0, 0.0, 1.0))
    if cap0:
        P.flat(slot, [M(u, v, a0) for u, v in inner], M(0.0, 0.0, -1.0))


def _strip(P, slot, pts, width, nrm, lift=0.002, taper=True, closed=False):
    """A flat glowing strip (crack, vein, inlay channel) along a polyline lying on a surface with normal nrm."""
    nrm = v_norm(nrm)
    if closed:
        pts = list(pts) + [pts[0]]
    m = len(pts)
    L = [0.0]
    for k in range(1, m):
        L.append(L[-1] + v_len(v_sub(pts[k], pts[k - 1])))
    tot = L[-1] or 1.0
    sides = []
    for k in range(m):
        if closed and k in (0, m - 1):
            d = v_norm(v_sub(pts[1], pts[-2]))
        else:
            d = v_norm(v_sub(pts[min(k + 1, m - 1)], pts[max(k - 1, 0)]))
        sd = v_norm(v_cross(nrm, d))
        w = width * (max(0.15, max(0.0, math.sin(math.pi * L[k] / tot)) ** 0.6) if taper else 1.0)
        base = v_add(pts[k], v_mul(nrm, lift))
        sides.append((v_add(base, v_mul(sd, w / 2)), v_sub(base, v_mul(sd, w / 2))))
    s = _fu.UV.get(slot, 1.0)
    for k in range(m - 1):
        q = [sides[k][0], sides[k + 1][0], sides[k + 1][1], sides[k][1]]
        P.poly(slot, q, [(0.0, L[k] / s), (0.0, L[k + 1] / s), (1.0, L[k + 1] / s), (1.0, L[k] / s)], nrm)


def _densify(pts, step=0.08, closed=True, lod=0):
    """Insert points along a polyline every `step` m (coarser at higher LODs): F.sweep orients faces by the nearest
    path point, so long straight runs need intermediate points."""
    step *= (1.0, 1.5, 3.0, 5.0)[lod]
    out = []
    m = len(pts)
    for k in range(m if closed else m - 1):
        a, b = pts[k], pts[(k + 1) % m]
        cnt = max(1, int(math.ceil(v_len(v_sub(b, a)) / step)))
        out += [v_add(a, v_mul(v_sub(b, a), j / cnt)) for j in range(cnt)]
    if not closed:
        out.append(pts[-1])
    return out


def _zigzag(a, b, n, amp, seed, plane_n):
    """Points from a to b with seeded sideways jitter in the plane with normal plane_n (a lava crack)."""
    rnd = random.Random(seed)
    d = v_sub(b, a)
    side = v_norm(v_cross(v_norm(plane_n), v_norm(d)))
    out = []
    for k in range(n + 1):
        t = k / n
        j = 0.0 if k in (0, n) else (rnd.random() - 0.5) * 2 * amp
        out.append(v_add(v_add(a, v_mul(d, t)), v_mul(side, j)))
    return out


def _crystal(P, slot, base, d, L, rad, sides=6, tip=0.3, spin=0.0):
    """A crystal / shard: a prism of `sides` from base along d, flaring slightly, ending in a pyramid point."""
    d = v_norm(d)
    t = v_norm(v_cross(d, (0.0, 1.0, 0.0) if abs(d[1]) < 0.9 else (1.0, 0.0, 0.0)))
    b = v_cross(d, t)
    ang = [2 * math.pi * k / sides + spin for k in range(sides)]
    ring = lambda c, rr: [v_add(c, v_add(v_mul(t, rr * math.cos(a)), v_mul(b, rr * math.sin(a)))) for a in ang]
    top = v_add(base, v_mul(d, L * (1 - tip)))
    r0, r1, apex = ring(base, rad * 0.85), ring(top, rad), v_add(base, v_mul(d, L))
    for k in range(sides):
        j = (k + 1) % sides
        mid = v_mul(v_add(r1[k], r1[j]), 0.5)
        P.poly(slot, [r0[k], r0[j], r1[j], r1[k]], [(k / sides, 0.0), ((k + 1) / sides, 0.0), ((k + 1) / sides, 0.7), (k / sides, 0.7)],
               v_sub(mid, top))
        P.poly(slot, [r1[k], r1[j], apex], [(k / sides, 0.7), ((k + 1) / sides, 0.7), ((k + 0.5) / sides, 1.0)],
               v_add(v_sub(mid, top), v_mul(d, rad)))
    P.flat(slot, r0, v_mul(d, -1.0))


def _ray(P, slot, base, tip, w, th, up):
    """A flat blade / spike: a pyramid on a w x th rectangle at base (th along `up`) pointing at tip."""
    d = v_norm(v_sub(tip, base))
    up = v_norm(v_sub(up, v_mul(d, sum(up[i] * d[i] for i in range(3)))))
    side = v_cross(d, up)
    c = [v_add(base, v_add(v_mul(side, sx * w / 2), v_mul(up, sy * th / 2))) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    for k in range(4):
        a, b = c[k], c[(k + 1) % 4]
        P.poly(slot, [a, b, tip], [(0.0, 0.0), (1.0, 0.0), (0.5, 1.0)], v_sub(v_mul(v_add(a, b), 0.5), base))
    P.flat(slot, c, v_mul(d, -1.0))


def _flame(P, slot, base, h, r, lean=(0.0, 0.0), n=None):
    """An opaque self-lit flame tongue (closed teardrop of revolution, bent by lean), hot root at v 0."""
    prof = [(0.0, 0.0), (0.55 * r, 0.04 * h), (r, 0.18 * h), (0.92 * r, 0.36 * h), (0.6 * r, 0.62 * h), (0.25 * r, 0.86 * h), (0.0, h)]
    L = sum(math.hypot(prof[k + 1][0] - prof[k][0], prof[k + 1][1] - prof[k][1]) for k in range(len(prof) - 1))
    old = P.xform

    def f(p):
        t = max(0.0, min(1.0, (p[1] - base[1]) / h))
        q = (p[0] + lean[0] * t * t, p[1], p[2] + lean[1] * t * t)
        return old(q) if old else q
    P.xform = f
    try:
        P.lathe(slot, base, prof, n=n or P.n(8, 5), utiles=1, vscale=L)
    finally:
        P.xform = old


def _glow(P, c, R, n=None):
    """A soft glow halo lying flat, facing up (seen from above only, so it needs no back side)."""
    P.disc("sith_glow", c, 0.0, R, n=n or P.n(16, 8), fit=True)


def _holocron(P, c, e, h, ry=0.0, rx=0.0):
    """A Sith holocron: a pyramid of glowing red panes in a blackened metal frame."""
    with _tx(P, c, (rx, ry, 0.0)):
        b = [(-e / 2, -h / 3, -e / 2), (e / 2, -h / 3, -e / 2), (e / 2, -h / 3, e / 2), (-e / 2, -h / 3, e / 2)]
        apex = (0.0, h * 2 / 3, 0.0)
        for k in range(4):
            p, q = b[k], b[(k + 1) % 4]
            mid = v_mul(v_add(p, q), 0.5)
            P.poly("sith_holocron", [p, q, apex], [(0.0, 0.0), (1.0, 0.0), (0.5, 1.0)], (mid[0], 0.35 * e, mid[2]))
        P.poly("sith_holocron", b, [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)], (0.0, -1.0, 0.0))
        fr = 0.006 if e < 0.12 else 0.008
        for k in range(4):
            P.sweep("sith_metal", [b[k], b[(k + 1) % 4]], fr, sides=4)
            P.sweep("sith_metal", [b[k], apex], fr, sides=4)
        if P.lod < 2:
            for p in b + [apex]:
                P.sphere("sith_metal", p, fr * 1.8, n=5)


# ---------------------------------------------------------------------------------------------------------------
# sith_dark_shrine
# ---------------------------------------------------------------------------------------------------------------

def sith_dark_shrine(P):
    """Dark-side shrine: a velvet kneeling cushion on an obsidian slab (SHRINE_SPOT) before a stepped obsidian dais
    with a carved stele of glowing red runes, flanking blades and kyber clusters, and a red Sith holocron floating
    over a projector pedestal 0.7 m ahead of the kneeler. Station: kneel at SHRINE_SPOT facing the stele."""
    plan1 = [(-1.05, -0.95), (1.05, -0.95), (1.20, -0.45), (0.80, 0.18), (-0.80, 0.18), (-1.20, -0.45)]
    plan2 = _inset(plan1, 0.11)
    _extrude(P, "sith_obsidian", plan1, 0.0, 0.09, chamfer=0.015)
    _extrude(P, "sith_obsidian", plan2, 0.09, 0.17, chamfer=0.012, cap0=False)
    seam = _inset(plan2, -0.016)
    _strip(P, "sith_vein", [(x, 0.09, z) for x, z in seam], 0.016, (0, 1, 0), lift=0.0015, taper=False, closed=True)
    # lava cracks running out from the stele base over the dais
    for k, (a, b) in enumerate((((-0.20, -0.48), (-0.62, 0.08)), ((0.22, -0.48), (0.66, 0.02)), ((-0.35, -0.60), (-0.95, -0.55)),
                                ((0.38, -0.62), (0.98, -0.40)), ((0.0, -0.45), (0.10, 0.04)))):
        pts = _zigzag((a[0], 0.17, a[1]), (b[0], 0.17, b[1]), P.n(7, 3), 0.05, 7 + k, (0, 1, 0))
        _strip(P, "sith_vein", pts, 0.022, (0, 1, 0))
    # -- the stele: a tapered pointed slab, a metal-framed panel of runes, a kyber diamond near the apex
    zs0, zs1 = -0.65, -0.45
    stele = [(-0.40, 0.17), (0.40, 0.17), (0.34, 1.62), (0.0, 2.25), (-0.34, 1.62)]
    _extrude(P, "sith_obsidian", stele, zs0, zs1, chamfer=0.03, axis="z")
    P.decal("sith_runes", (0.0, 0.98, zs1 + 0.0012), 0.50, 1.22, (0, 0, 1))
    P.decal("sith_runes", (0.0, 1.02, zs0 - 0.0012), 0.40, 0.90, (0, 0, -1))
    if P.lod < 2:                                               # thorns along the stele edges
        for sx in (-1, 1):
            for k in range(4):
                y = 0.32 + 0.22 * k
                x = sx * (0.40 - 0.06 * (y - 0.17) / 1.45)
                _ray(P, "sith_metal", (x - sx * 0.02, y, (zs0 + zs1) / 2), (x + sx * 0.09, y + 0.07, (zs0 + zs1) / 2), 0.05, 0.03, (0, 0, 1))
    for (cx, cy, hx, hy) in ((0.0, 1.605, 0.27, 0.014), (0.0, 0.355, 0.27, 0.014), (-0.27, 0.98, 0.014, 0.264), (0.27, 0.98, 0.014, 0.264)):
        P.box("sith_metal", (cx, cy, zs1 + 0.008), (hx, hy, 0.008), bottom=True)
    diamond = [(0.0, 1.70), (0.085, 1.86), (0.0, 2.02), (-0.085, 1.86)]
    _extrude(P, "sith_kyber", diamond, zs1 - 0.01, zs1 + 0.022, chamfer=0.01, axis="z", cap0=False)
    P.sweep("sith_metal", [(x * 1.25, 1.86 + (y - 1.86) * 1.18, zs1 + 0.006) for x, y in diamond], 0.011, closed=True, sides=4)
    for sx in (-1, 1):                                          # side blades leaning out of the stele
        blade = [(sx * 0.30, 0.70), (sx * 0.44, 0.62), (sx * 0.74, 1.95), (sx * 0.47, 1.20)]
        _extrude(P, "sith_obsidian", blade, -0.60, -0.50, chamfer=0.008, axis="z")
        _strip(P, "sith_vein", _zigzag((sx * 0.43, 0.72, -0.497), (sx * 0.70, 1.86, -0.497), P.n(6, 3), 0.015, 21 + sx, (0, 0, 1)),
               0.014, (0, 0, 1), lift=0.0015)
    # -- kyber clusters at the stele foot, obsidian shards at the back corners
    for sx in (-1, 1):
        cx, cz = sx * 0.62, -0.32
        for k, (dx, dz, ln, rr, tilt) in enumerate(((0.0, 0.0, 0.30, 0.038, 0), (0.07, 0.04, 0.20, 0.03, 25), (-0.06, 0.05, 0.17, 0.028, -28),
                                                    (0.03, -0.07, 0.15, 0.026, 18), (-0.05, -0.05, 0.12, 0.022, -22))):
            if P.lod >= 2 and k > 2:
                continue
            d = (math.sin(math.radians(tilt)) * sx, math.cos(math.radians(tilt)), 0.25 * math.sin(math.radians(tilt * 2)))
            _crystal(P, "sith_kyber", (cx + dx * sx, 0.16, cz + dz), d, ln, rr, spin=0.4 * k)
        _crystal(P, "sith_obsidian", (sx * 0.98, 0.07, -0.80), (sx * 0.30, 1.0, -0.15), 0.95, 0.075, sides=5, tip=0.35)
        _crystal(P, "sith_obsidian", (sx * 1.07, 0.07, -0.58), (sx * 0.55, 1.0, 0.1), 0.55, 0.05, sides=5, tip=0.4)
    # -- red candles in faceted obsidian holders at the front corners of the upper tier
    for sx in (-1, 1):
        cx, cz = sx * 0.58, 0.02
        P.lathe("sith_obsidian", (cx, 0.17, cz), [(0.0, 0.0), (0.09, 0.0), (0.06, 0.05), (0.035, 0.08), (0.035, 0.30), (0.075, 0.36),
                                                  (0.07, 0.38), (0.0, 0.38)], n=6)
        P.lathe("sith_void", (cx, 0.55, cz), [(0.0, 0.0), (0.03, 0.0), (0.03, 0.10), (0.0, 0.11)], n=P.n(8, 5))
        _flame(P, "sith_fire", (cx, 0.655, cz), 0.13, 0.024, lean=(0.0, 0.01))
    # -- projector pedestal and the floating holocron
    pc = (0.0, 0.0, -0.06)
    sq = lambda r, y: [(pc[0] + r * math.cos(math.radians(45 + 90 * k)), y, pc[2] + r * math.sin(math.radians(45 + 90 * k))) for k in range(4)]
    _extrude(P, "sith_obsidian", [(p[0], p[2]) for p in sq(0.24, 0.0)], 0.17, 0.24, chamfer=0.012, cap0=False)
    P.loft("sith_obsidian", [sq(0.14, 0.24), sq(0.095, 0.86)], caps=(False, False), vscale=1.0)
    P.loft("sith_obsidian", [sq(0.095, 0.86), sq(0.19, 0.94), sq(0.19, 0.965)], caps=(False, True), vscale=1.0)
    P.loft("sith_metal", [sq(0.13, 0.50), sq(0.13, 0.54)], caps=(True, True), vscale=0.3)          # metal band
    P.lathe("sith_vein", (pc[0], 0.965, pc[2]), [(0.10, 0.0), (0.085, 0.01), (0.03, 0.016), (0.0, 0.017)], n=P.n(16, 8))
    _glow(P, (pc[0], 0.984, pc[2]), 0.24)
    for k in range(4):                                          # talons gripping the projector head
        a = math.radians(45 + 90 * k)
        ca, sa = math.cos(a), math.sin(a)
        _ray(P, "sith_metal", (pc[0] + 0.17 * ca, 0.95, pc[2] + 0.17 * sa), (pc[0] + 0.12 * ca, 1.10, pc[2] + 0.12 * sa), 0.05, 0.016,
             (ca, 0.0, sa))
    hc = (pc[0], 1.33, pc[2])
    _holocron(P, hc, 0.22, 0.21, ry=28.0, rx=8.0)
    if P.lod < 3:                                               # shards levitating round the holocron
        for k in range(5):
            a = 2 * math.pi * k / 5 + 0.3
            p0 = (hc[0] + 0.30 * math.cos(a), hc[1] - 0.06 + 0.10 * math.sin(3 * a), hc[2] + 0.30 * math.sin(a))
            _crystal(P, "sith_obsidian", p0, (math.cos(a + 1.2), 0.6, math.sin(a + 1.2)), 0.07 + 0.02 * (k % 2), 0.018, sides=4, tip=0.45)
    # a ring of runes glowing on the dais round the pedestal
    P.disc("sith_rune_ring", (pc[0], 0.1715, pc[2]), 0.0, 0.46, fit=True, n=P.n(24, 10))
    # -- the kneeler: an obsidian slab ringed with a lava seam, a crimson velvet cushion
    sx_, sz_ = SHRINE_SPOT[0], SHRINE_SPOT[2]
    kplan = [(sx_ - 0.37, sz_), (sx_ - 0.25, sz_ - 0.23), (sx_ + 0.25, sz_ - 0.23), (sx_ + 0.37, sz_), (sx_ + 0.25, sz_ + 0.23),
             (sx_ - 0.25, sz_ + 0.23)]
    _extrude(P, "sith_obsidian", kplan, 0.0, 0.035, chamfer=0.008)
    _strip(P, "sith_vein", [(x, 0.035, z) for x, z in _inset(kplan, 0.03)], 0.01, (0, 1, 0), lift=0.0015, taper=False, closed=True)
    P.rbox("sith_velvet", (sx_, 0.062, sz_), (0.27, 0.03, 0.17), 0.025, puff=0.01, seg=P.n(3, 2))
    station_hardpoints(P, "kneel", SHRINE_SPOT, yaw=180.0)


# ---------------------------------------------------------------------------------------------------------------
# sith_throne
# ---------------------------------------------------------------------------------------------------------------

def sith_throne(P):
    """Sith obsidian throne on a two-step dais: angular seat block and armrests ending in iron talons, a crimson
    velvet seat and back pad, a 2.4 m back slab leaning back under a crown of black blades, lava glowing in the
    seams and cracks, a kyber diamond at the apex, shards at the back corners. Seat 0.46, front edge z 0.24 ->
    foot 0.415 (on the floor just in front of the lower step)."""
    zf = 0.24
    t1 = [(-1.10, -1.00), (1.10, -1.00), (1.25, -0.20), (0.95, 0.26), (-0.95, 0.26), (-1.25, -0.20)]
    t2 = [(-0.92, -0.92), (0.92, -0.92), (1.05, -0.25), (0.78, 0.14), (-0.78, 0.14), (-1.05, -0.25)]
    _extrude(P, "sith_obsidian", t1, 0.0, 0.08, chamfer=0.015)
    _extrude(P, "sith_obsidian", t2, 0.08, 0.16, chamfer=0.012, cap0=False)
    _strip(P, "sith_vein", [(x, 0.08, z) for x, z in _inset(t2, -0.016)], 0.016, (0, 1, 0), lift=0.0015, taper=False, closed=True)
    for k, (a, b, y) in enumerate((((-0.55, 0.05), (-0.98, -0.30), 0.16), ((0.60, 0.02), (0.96, -0.55), 0.16),
                                   ((-0.70, -0.70), (-0.98, -0.88), 0.16), ((-0.88, 0.20), (-1.12, -0.12), 0.08),
                                   ((0.86, 0.21), (1.15, -0.05), 0.08), ((0.62, -0.72), (0.40, -0.90), 0.16))):
        _strip(P, "sith_vein", _zigzag((a[0], y, a[1]), (b[0], y, b[1]), P.n(6, 3), 0.04, 50 + k, (0, 1, 0)), 0.02, (0, 1, 0))
    # -- seat block and cushion, lava cracks down its front
    seat = [(-0.44, -0.46), (0.44, -0.46), (0.46, 0.18), (0.36, 0.26), (-0.36, 0.26), (-0.46, 0.18)]
    _extrude(P, "sith_obsidian", seat, 0.16, 0.40, chamfer=0.02, cap0=False)
    P.rbox("sith_velvet", (0.0, 0.43, -0.10), (0.38, 0.03, 0.34), 0.025, puff=0.008, seg=P.n(3, 2))
    _strip(P, "sith_vein", _zigzag((-0.30, 0.19, 0.26), (0.28, 0.37, 0.26), P.n(7, 3), 0.04, 61, (0, 0, 1)), 0.02, (0, 0, 1))
    _strip(P, "sith_vein", _zigzag((-0.05, 0.36, 0.26), (0.22, 0.19, 0.26), P.n(5, 3), 0.03, 62, (0, 0, 1)), 0.014, (0, 0, 1))
    # -- armrests with lava grooves and iron talons gripping their front edge
    for sx in (-1, 1):
        arm = [(sx * 0.44, -0.46), (sx * 0.64, -0.46), (sx * 0.66, 0.10), (sx * 0.56, 0.22), (sx * 0.44, 0.22)]
        _extrude(P, "sith_obsidian", arm, 0.16, 0.66, chamfer=0.02, cap0=False)
        _extrude(P, "sith_obsidian", _inset(arm, -0.02), 0.66, 0.71, chamfer=0.012)
        _strip(P, "sith_vein", [(sx * 0.545, 0.71, -0.42), (sx * 0.548, 0.71, -0.10), (sx * 0.55, 0.71, 0.15)], 0.016, (0, 1, 0),
               lift=0.0015)
        _strip(P, "sith_vein", _zigzag((sx * 0.651, 0.22, -0.38), (sx * 0.661, 0.62, 0.04), P.n(6, 3), 0.04, 70 + sx, (sx, 0, 0)), 0.02,
               (sx, 0, -0.035 * sx))
        for k, dx in enumerate((-0.05, 0.0, 0.05)):
            x = sx * 0.55 + dx
            _ray(P, "sith_metal", (x, 0.69, 0.17), (x * 1.02, 0.52 - 0.03 * (k == 1), 0.33), 0.04, 0.03, (0, 1, 0.3))
    # -- the back: leaning slab, velvet pad, lava inlay, crown of blades, kyber diamond, an iron spine behind
    with _tx(P, r=(-7.0, 0, 0), pivot=(0.0, 0.40, -0.50)):
        back = [(-0.42, 0.40), (0.42, 0.40), (0.48, 1.55), (0.0, 2.45), (-0.48, 1.55)]
        _extrude(P, "sith_obsidian", back, -0.58, -0.42, chamfer=0.025, axis="z")
        P.rbox("sith_velvet", (0.0, 0.98, -0.405), (0.30, 0.42, 0.025), 0.02, puff=0.006, seg=P.n(3, 2))
        frame = [(-0.315, 0.545, -0.405), (0.315, 0.545, -0.405), (0.315, 1.415, -0.405), (-0.315, 1.415, -0.405)]
        P.sweep("sith_metal", _densify(frame, lod=P.lod), 0.013, closed=True, sides=P.n(6, 4))           # iron frame round the pad
        _strip(P, "sith_vein", [(x, y, -0.42) for x, y in _inset(back, 0.075)], 0.014, (0, 0, 1), lift=0.0015, taper=False, closed=True)
        _strip(P, "sith_vein", _zigzag((0.0, 2.22, -0.42), (0.0, 1.45, -0.42), P.n(6, 3), 0.03, 81, (0, 0, 1)), 0.018, (0, 0, 1))
        _extrude(P, "sith_kyber", [(0.0, 1.76), (0.08, 1.91), (0.0, 2.06), (-0.08, 1.91)], -0.43, -0.40, chamfer=0.008, axis="z",
                 cap0=False)
        P.box("sith_metal", (0.0, 1.20, -0.59), (0.05, 0.70, 0.012))
        if P.lod < 2:
            for k in range(5):
                P.box("sith_metal", (0.0, 0.70 + 0.22 * k, -0.596), (0.16 - 0.015 * k, 0.018, 0.01))
        for sx in (-1, 1):
            b1 = [(sx * 0.30, 0.55), (sx * 0.46, 0.50), (sx * 0.88, 1.95), (sx * 0.50, 1.30)]
            _extrude(P, "sith_obsidian", b1, -0.56, -0.46, chamfer=0.008, axis="z")
            b2 = [(sx * 0.40, 0.45), (sx * 0.52, 0.40), (sx * 1.05, 1.35), (sx * 0.62, 0.95)]
            _extrude(P, "sith_obsidian", b2, -0.545, -0.475, chamfer=0.006, axis="z")
            _strip(P, "sith_vein", _zigzag((sx * 0.46, 0.62, -0.46), (sx * 0.84, 1.86, -0.46), P.n(6, 3), 0.018, 90 + sx, (0, 0, 1)),
                   0.014, (0, 0, 1), lift=0.0015)
            _strip(P, "sith_vein", _zigzag((sx * 0.53, 0.50, -0.475), (sx * 1.00, 1.30, -0.475), P.n(5, 3), 0.015, 95 + sx, (0, 0, 1)),
                   0.012, (0, 0, 1), lift=0.0015)
    for sx in (-1, 1):
        _crystal(P, "sith_obsidian", (sx * 1.00, 0.07, -0.86), (sx * 0.35, 1.0, -0.2), 0.95, 0.075, sides=5, tip=0.35)
        _crystal(P, "sith_obsidian", (sx * 1.14, 0.07, -0.50), (sx * 0.6, 1.0, 0.05), 0.50, 0.05, sides=5, tip=0.4)
        cx, cz = sx * 0.86, 0.02                                 # kyber clusters at the front corners of the upper step
        for k, (dx, dz, ln, rr, tilt) in enumerate(((0.0, 0.0, 0.24, 0.032, 0), (0.06, 0.04, 0.16, 0.026, 26), (-0.05, 0.05, 0.14, 0.024, -24),
                                                    (0.03, -0.06, 0.12, 0.022, 18))):
            if P.lod >= 2 and k > 1:
                continue
            d = (math.sin(math.radians(tilt)) * sx, math.cos(math.radians(tilt)), 0.3 * math.sin(math.radians(tilt * 2)))
            _crystal(P, "sith_kyber", (cx + dx * sx, 0.155, cz + dz), d, ln, rr, spin=0.4 * k)
        if P.lod < 2:                                            # spikes along the armrest's outer top edge
            for k in range(3):
                z = -0.36 + 0.2 * k
                _ray(P, "sith_obsidian", (sx * 0.655, 0.69, z), (sx * 0.78, 0.80, z - 0.04), 0.07, 0.03, (0, 0, 1))
    seat_hardpoint(P, zf)


# ---------------------------------------------------------------------------------------------------------------
# sith_lava_brazier
# ---------------------------------------------------------------------------------------------------------------

def _bowl_r(y):
    """Outer radius of the brazier bowl profile at local height y."""
    pts = [(0.14, 0.0), (0.30, 0.09), (0.42, 0.24), (0.46, 0.31)]
    for (r0, y0), (r1, y1) in zip(pts, pts[1:]):
        if y <= y1:
            return r0 + (r1 - r0) * max(0.0, (y - y0)) / (y1 - y0)
    return pts[-1][0]


def sith_lava_brazier(P):
    """Mustafar lava brazier, 1.2 m: a faceted obsidian bowl brimming with molten lava (rim 0.95 m) behind a ring
    of black spikes, lava spilling over in drips, on four blackened-iron talon legs; an ember glow and drifting
    sparks over it. Light just above the lava."""
    by = 0.62
    P.lathe("sith_obsidian", (0.0, by, 0.0), [(0.0, 0.0), (0.14, 0.0), (0.30, 0.09), (0.42, 0.24), (0.46, 0.31), (0.445, 0.335),
                                             (0.41, 0.325), (0.37, 0.28), (0.33, 0.22)], n=8)
    P.lathe("sith_lava", (0.0, by + 0.27, 0.0), [(0.375, -0.03), (0.30, 0.02), (0.18, 0.045), (0.0, 0.055)], n=P.n(16, 8))
    for k in range(8):
        a = 2 * math.pi * k / 8
        ca, sa = math.cos(a), math.sin(a)
        ln = 0.20 if k % 2 == 0 else 0.13
        _ray(P, "sith_obsidian", (0.437 * ca, by + 0.322, 0.437 * sa), ((0.46 + 0.5 * ln) * ca, by + 0.335 + ln, (0.46 + 0.5 * ln) * sa),
             0.05, 0.016, (-0.4 * ca, 1.0, -0.4 * sa))
    for k, (a, y1) in enumerate(((22.5, 0.12), (157.5, 0.17), (292.5, 0.08))):      # lava spilling over the rim
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        ys = [y for y in (0.33, 0.30, 0.26, 0.21, 0.16, 0.11, 0.07) if y >= y1] + [y1]
        path = [((0.924 * _bowl_r(y) + 0.012 + (0.01 if y > 0.3 else 0.0)) * ca, by + y, (0.924 * _bowl_r(y) + 0.012) * sa) for y in ys]
        P.sweep("sith_lava", path, lambda t: 0.03 - 0.016 * t, sides=P.n(8, 4))
        _ellipsoid(P, "sith_lava", v_add(path[-1], (0.0, -0.012, 0.0)), (0.02, 0.026, 0.02), n=P.n(8, 5), rows=4)
    P.cone("sith_lava", (0.0, by + 0.01, 0.0), (0.0, by - 0.12, 0.0), 0.03, n=P.n(8, 5))
    _ellipsoid(P, "sith_lava", (0.0, by - 0.145, 0.0), (0.022, 0.03, 0.022), n=P.n(8, 5), rows=4)
    # four talon legs on clawed feet, a tie ring with spurs
    ctrl = [(0.10, by + 0.04), (0.28, by - 0.02), (0.44, by - 0.18), (0.50, 0.30), (0.47, 0.12), (0.50, 0.05)]
    for k in range(4):
        a = math.radians(45 + 90 * k)
        ca, sa = math.cos(a), math.sin(a)
        P.sweep("sith_metal", [(r * ca, y, r * sa) for r, y in _spline(ctrl, P.n(14, 6))], lambda t: 0.036 - 0.014 * t, sides=P.n(8, 4))
        knee = (0.462 * ca, by - 0.15, 0.462 * sa)
        P.sphere("sith_metal", knee, 0.042, n=P.n(8, 5))
        P.cone("sith_metal", knee, (0.60 * ca, by - 0.02, 0.60 * sa), 0.022, n=P.n(6, 4))
        foot = (0.50 * ca, 0.05, 0.50 * sa)
        P.sphere("sith_metal", foot, 0.03, n=P.n(8, 5))
        for j in ((-0.5, 0.0, 0.5) if P.lod < 3 else (0.0,)):
            dx, dz = math.cos(a + j), math.sin(a + j)
            path = _spline([(foot[0], 0.055, foot[2]), (foot[0] + 0.07 * dx, 0.06, foot[2] + 0.07 * dz),
                            (foot[0] + 0.13 * dx, 0.03, foot[2] + 0.13 * dz), (foot[0] + 0.155 * dx, 0.004, foot[2] + 0.155 * dz)],
                           P.n(6, 3))
            P.sweep("sith_metal", path, lambda t: 0.018 * (1 - t) + 0.003, sides=P.n(6, 4))
        if P.lod < 3:
            path = _spline([(foot[0], 0.05, foot[2]), (foot[0] - 0.06 * ca, 0.045, foot[2] - 0.06 * sa),
                            (foot[0] - 0.09 * ca, 0.004, foot[2] - 0.09 * sa)], P.n(4, 3))
            P.sweep("sith_metal", path, lambda t: 0.015 * (1 - t) + 0.003, sides=P.n(6, 4))
    n = P.n(28, 10)
    P.sweep("sith_metal", [(0.488 * math.cos(2 * math.pi * k / n), 0.30, 0.488 * math.sin(2 * math.pi * k / n)) for k in range(n)], 0.013,
            closed=True, sides=P.n(6, 4))
    for k in range(4):
        a = math.radians(90 * k)
        _ray(P, "sith_metal", (0.49 * math.cos(a), 0.30, 0.49 * math.sin(a)), (0.47 * math.cos(a), 0.17, 0.47 * math.sin(a)), 0.035,
             0.022, (math.cos(a), 0.0, math.sin(a)))
    # ember glow over the lava, sparks drifting up
    _glow(P, (0.0, by + 0.337, 0.0), 0.62)
    if P.lod < 2:
        rnd = random.Random(5)
        for k in range(9):
            a = rnd.random() * 2 * math.pi
            rr = 0.05 + 0.25 * rnd.random()
            P.sphere("sith_lava", (rr * math.cos(a), by + 0.42 + 0.40 * rnd.random(), rr * math.sin(a)), 0.008 + 0.007 * rnd.random(), n=5)
    light_hardpoint(P, (0.0, by + 0.40, 0.0))


# ---------------------------------------------------------------------------------------------------------------
# sith_hooded_statue
# ---------------------------------------------------------------------------------------------------------------

def _interp(keys, y):
    """Linear interpolation of key rows (y, a, b, c...) at y."""
    if y <= keys[0][0]:
        return keys[0][1:]
    for k0, k1 in zip(keys, keys[1:]):
        if y <= k1[0]:
            t = (y - k0[0]) / (k1[0] - k0[0])
            return tuple(a + (b - a) * t for a, b in zip(k0[1:], k1[1:]))
    return keys[-1][1:]


ROBE = [(0.42, 0.42, 0.36, 0.02), (0.60, 0.40, 0.33, 0.015), (0.90, 0.34, 0.27, 0.01), (1.20, 0.27, 0.21, 0.0),
        (1.45, 0.29, 0.20, -0.005), (1.70, 0.33, 0.20, -0.01), (1.86, 0.35, 0.20, -0.02), (1.95, 0.27, 0.17, -0.02),
        (2.00, 0.12, 0.10, -0.02)]                    # (y, half width, half depth, centre z)
HOOD = [(1.88, 0.31, 0.25, -0.02), (1.98, 0.27, 0.26, 0.005), (2.10, 0.235, 0.265, 0.025), (2.22, 0.215, 0.255, 0.03),
        (2.33, 0.18, 0.225, 0.01), (2.42, 0.125, 0.165, -0.03), (2.49, 0.04, 0.06, -0.08)]   # the cowl juts forward
FACE = (0.0, 2.13, 0.11, 0.17)                        # the hood opening: centre x, y and semi-axes (pointed at the top)


def _face_w(y):
    """Half width of the pointed hood opening at height y."""
    fx, fy, fa, fb = FACE
    t = (y - fy) / fb
    return fa * math.sqrt(max(0.0, 1 - t * t)) * (1 - 0.45 * max(0.0, t))


def sith_hooded_statue(P):
    """A 2.5 m hooded Sith in basalt: a robe falling in deep folds, wide sleeves, the face lost in a black cowl
    (two embers for eyes), hands folded over the pommel of an ancient sword whose point rests on the plinth;
    a two-tier obsidian plinth with a glowing rune band and lava seams."""
    oct_ = lambda h, c: [(h, -h + c), (h, h - c), (h - c, h), (-h + c, h), (-h, h - c), (-h, -h + c), (-h + c, -h), (h - c, -h)]
    _extrude(P, "sith_obsidian", oct_(0.54, 0.13), 0.0, 0.12, chamfer=0.015)
    _extrude(P, "sith_obsidian", oct_(0.45, 0.11), 0.12, 0.42, chamfer=0.015, cap0=False)
    P.decal("sith_rune_band", (0.0, 0.27, 0.4512), 0.56, 0.20, (0, 0, 1))
    for sx in (-1, 1):                                          # lava seams down the chamfered corners
        for sz in (-1, 1):
            mid = (sx * 0.395, sz * 0.395)
            nrm = (sx, 0.0, sz)
            _strip(P, "sith_vein", _zigzag((mid[0], 0.14, mid[1]), (mid[0], 0.40, mid[1]), P.n(5, 3), 0.02, 100 + 2 * sx + sz, nrm), 0.016,
                   nrm, lift=0.002)
    _strip(P, "sith_vein", [(x, 0.12, z) for x, z in _inset(oct_(0.45, 0.11), -0.016)], 0.016, (0, 1, 0), lift=0.0015, taper=False,
           closed=True)
    # -- robe: deep vertical folds that soften toward the chest
    na = P.n(32, 12)
    ys = [0.42 + (2.00 - 0.42) * k / P.n(16, 6) for k in range(P.n(16, 6) + 1)]
    rings = []
    for y in ys:
        rx, rz, cz = _interp(ROBE, y)
        amp = 0.075 * (1 - smoothstep(0.42, 1.35, y)) + 0.012
        ring = []
        for j in range(na):
            th = 2 * math.pi * j / na
            f = 1 + amp * (0.6 * math.sin(7 * th + 0.4) + 0.4 * math.sin(11 * th + 1.3))
            ring.append((rx * math.cos(th) * f, y, cz + rz * math.sin(th) * f))
        rings.append(ring)
    P.loft("sith_statue", rings, caps=(True, True), vscale=0.9)
    # a shoulder mantle over the robe, its hem ragged, closed underneath by a ring back to the robe
    mys = [1.93 - 0.33 * k / P.n(6, 3) for k in range(P.n(6, 3) + 1)]
    mrings = []
    for k, y in enumerate(mys):
        ring = []
        for j in range(na):
            th = 2 * math.pi * j / na
            yy = y - (0.05 * (0.5 + 0.5 * math.sin(5 * th + 0.7)) if k == len(mys) - 1 else 0.0)
            rx, rz, cz = _interp(ROBE, yy)
            grow = 0.06 * (k / (len(mys) - 1)) ** 0.8
            f = 1 + 0.03 * math.sin(9 * th + 2.0) * k / len(mys)
            ring.append(((rx + grow) * math.cos(th) * f, yy, cz + (rz + grow) * math.sin(th) * f))
        mrings.append(ring)
    P.loft("sith_statue", mrings, closed=True, caps=(False, False), vscale=0.9)
    hem = mrings[-1]
    for j in range(na):
        j1 = (j + 1) % na
        inner = []
        for p_ in (hem[j], hem[j1]):
            th = math.atan2((p_[2] - _interp(ROBE, p_[1])[2]) / _interp(ROBE, p_[1])[1], p_[0] / _interp(ROBE, p_[1])[0])
            rx, rz, cz = _interp(ROBE, p_[1])
            inner.append((rx * 0.97 * math.cos(th), p_[1], cz + rz * 0.97 * math.sin(th)))
        P.flat("sith_statue", [hem[j], hem[j1], inner[1], inner[0]], (0.0, -1.0, 0.0))
    # -- hood: a cowl with the face opening cut away, a heavy rolled lip, the void inside and two ember eyes
    hy = [1.88 + (2.49 - 1.88) * k / P.n(16, 6) for k in range(P.n(16, 6) + 1)]
    na2 = P.n(36, 12)
    hrings = []
    for y in hy:
        rx, rz, cz = _interp(HOOD, y)
        hrings.append([(rx * math.cos(2 * math.pi * j / na2 + math.pi / 2), y, cz + rz * math.sin(2 * math.pi * j / na2 + math.pi / 2))
                       for j in range(na2)])
    fx, fy, fa, fb = FACE
    cents = [tuple(sum(p[i] for p in rg) / na2 for i in range(3)) for rg in hrings]
    sv = _fu.UV.get("sith_statue", 1.0)
    for k in range(len(hrings) - 1):
        mid = v_mul(v_add(cents[k], cents[k + 1]), 0.5)
        for j in range(na2):
            j1 = (j + 1) % na2
            q = [hrings[k][j], hrings[k][j1], hrings[k + 1][j1], hrings[k + 1][j]]
            c = tuple(sum(p[i] for p in q) / 4 for i in range(3))
            if P.lod < 2 and c[2] > mid[2] + 0.05 and abs(c[0] - fx) < _face_w(c[1]):
                continue
            P.poly("sith_statue", q, [(j * 0.05 / sv, (hy[k] - 1.88) / sv), ((j + 1) * 0.05 / sv, (hy[k] - 1.88) / sv),
                                      ((j + 1) * 0.05 / sv, (hy[k + 1] - 1.88) / sv), (j * 0.05 / sv, (hy[k + 1] - 1.88) / sv)],
                   v_sub(c, mid))
    P.flat("sith_statue", hrings[0], (0, -1, 0))
    P.flat("sith_statue", hrings[-1], (0, 1, 0))

    def hood_front(x, y):
        rx, rz, cz = _interp(HOOD, y)
        return cz + rz * math.sqrt(max(0.0, 1 - (x / rx) ** 2))
    lip = []
    for k in range(20):
        ph = 2 * math.pi * k / 20
        sn = math.sin(ph)
        lip.append((fx + fa * 1.06 * math.cos(ph) * (1 - 0.45 * max(0.0, sn)), fy + fb * 1.04 * sn))
    P.sweep("sith_statue", [(x, y, hood_front(x, y) - 0.008) for x, y in lip], 0.034, closed=True, sides=P.n(8, 5))
    if P.lod < 2:                                               # the void inside the cut-away face, ember eyes deep in it
        with _tx(P, (fx, fy, 0.235), (90, 0, 0), (fa * 1.08, 0.17, fb * 1.08)):
            P.sphere("sith_void", (0.0, 0.0, 0.0), 1.0, lat0=-90, lat1=0, inside=True, n=P.n(14, 8))
        for sx in (-1, 1):
            _ellipsoid(P, "sith_kyber", (sx * 0.04, 2.15, 0.12), (0.019, 0.009, 0.01), n=P.n(8, 5), rows=4)
    else:                                                       # far LODs: a dark plug over the (uncut) face
        _ellipsoid(P, "sith_void", (fx, fy, hood_front(0.0, fy) - 0.012), (fa, fb, 0.03), n=P.n(12, 6), rows=4)
    # -- sleeves, hands on the pommel, the sword point-down, belt and sash, a chain clasp
    for sx in (-1, 1):
        sl = _spline([(sx * 0.29, 1.84, -0.01), (sx * 0.36, 1.58, 0.05), (sx * 0.30, 1.38, 0.17), (sx * 0.13, 1.25, 0.28)], P.n(10, 5))
        P.sweep("sith_statue", sl, lambda t: 0.085 + 0.06 * t ** 1.5, sides=P.n(12, 6))
        tan = v_norm(v_sub(sl[-1], sl[-2]))
        P.disc("sith_void", v_add(sl[-1], v_mul(tan, 0.003)), 0.0, 0.145 * 0.82, n=P.n(12, 6), r=_yaxis_to(tan))
        _ellipsoid(P, "sith_statue", (sx * 0.042, 1.235, 0.34), (0.046, 0.052, 0.068), r=(10, sx * 15, 0), n=P.n(10, 6))
        if P.lod < 2:
            for k in range(3):
                P.sweep("sith_statue", [(sx * 0.07, 1.215 + 0.02 * k, 0.37), (sx * 0.012, 1.21 + 0.02 * k, 0.385)], 0.011, sides=4)
    P.sphere("sith_obsidian", (0.0, 1.31, 0.345), 0.032, n=P.n(10, 6))
    _ellipsoid(P, "sith_kyber", (0.0, 1.31, 0.374), (0.016, 0.022, 0.008), n=P.n(8, 5), rows=4)
    P.lathe("sith_metal", (0.0, 1.10, 0.35), [(0.0, 0.0), (0.02, 0.0), (0.016, 0.02), (0.016, 0.18), (0.02, 0.19), (0.0, 0.195)], n=P.n(8, 5))
    _extrude(P, "sith_obsidian", [(-0.20, 1.065), (0.20, 1.065), (0.24, 1.10), (-0.24, 1.10)], 0.325, 0.375, chamfer=0.006, axis="z")
    for sx in (-1, 1):
        _ray(P, "sith_obsidian", (sx * 0.215, 1.083, 0.35), (sx * 0.30, 1.0, 0.35), 0.03, 0.04, (0, 0, 1))
    blade = [(0.0, 1.07, 0.35), (0.0, 0.75, 0.38), (0.0, 0.43, 0.41)]
    P.sweep("sith_obsidian", blade, lambda t: 0.045 * (1 - smoothstep(0.86, 1.0, t)) + 0.002, sides=4,
            profile=[(1.0, 0.0), (0.0, 0.22), (-1.0, 0.0), (0.0, -0.22)])
    for sgn in (1, -1):                                         # a glowing fuller down both faces of the blade
        _strip(P, "sith_vein", [(0.0, 1.05, 0.35 + sgn * 0.009), (0.0, 0.75, 0.38 + sgn * 0.009), (0.0, 0.50, 0.405 + sgn * 0.009)], 0.012,
               (0, 0.09 * sgn, sgn), lift=0.0005)
    belt = []
    for j in range(P.n(24, 10)):
        th = 2 * math.pi * j / P.n(24, 10)
        rx, rz, cz = _interp(ROBE, 1.22)
        belt.append((rx * 1.04 * math.cos(th), 1.22, cz + rz * 1.06 * math.sin(th)))
    P.sweep("sith_statue", belt, 0.02, closed=True, sides=P.n(6, 4))
    for sx in (-1, 1):
        P.sweep("sith_statue", [(sx * 0.05, 1.21, 0.225), (sx * 0.07, 1.05, 0.27), (sx * 0.075, 0.88, 0.32)], lambda t: 0.024 - 0.008 * t,
                sides=P.n(6, 4), profile=[(1.0, 0.0), (0.0, 0.35), (-1.0, 0.0), (0.0, -0.35)])
        P.lathe("sith_obsidian", (sx * 0.12, 1.85, 0.208), [(0.0, -0.01), (0.04, -0.01), (0.045, 0.005), (0.0, 0.015)], r=(80, 0, 0),
                n=P.n(10, 6))
    P.sweep("sith_metal", [(-0.11, 1.845, 0.222), (0.0, 1.81, 0.232), (0.11, 1.845, 0.222)], 0.007, sides=4)


# ---------------------------------------------------------------------------------------------------------------
# sith_saber_rack
# ---------------------------------------------------------------------------------------------------------------

def _blade(P, emitter, tip):
    """An ignited red blade: a white-hot core inside an alpha glow, rounded off at the tip."""
    d = v_norm(v_sub(tip, emitter))
    P.sweep("sith_blade_core", [v_add(emitter, v_mul(d, -0.004)), tip], lambda t: 0.0105 * (1 - 0.5 * smoothstep(0.96, 1.0, t)),
            sides=P.n(8, 5))
    P.sweep("sith_blade", [v_add(emitter, v_mul(d, -0.002)), v_add(tip, v_mul(d, 0.009))],
            lambda t: 0.0195 * (1 - 0.45 * smoothstep(0.95, 1.0, t)), sides=P.n(10, 6))


def _saber(P, pommel, d, blade=0.95, curved=False, hilt=0.28):
    """An ignited lightsaber from the pommel along d (in the x-y plane). Straight: blackened grip, chrome
    activation section and flared emitter. Curved: an electrum grip bent 20 degrees off the blade line under a
    straight emitter. Returns the points where wall clamps should hold the hilt."""
    d = v_norm(d)
    rz = math.degrees(math.atan2(-d[0], d[1]))
    n = P.n(12, 6)
    if not curved:
        with _tx(P, pommel, (0.0, 0.0, rz)):
            P.lathe("sith_metal", (0.0, 0.0, 0.0), [(0.0, 0.0), (0.017, 0.0), (0.02, 0.012), (0.02, 0.035), (0.016, 0.042), (0.016, 0.135),
                                                    (0.018, 0.14)], n=n)
            P.lathe("chrome", (0.0, 0.0, 0.0), [(0.018, 0.14), (0.0185, 0.20), (0.017, 0.205), (0.021, 0.215), (0.024, 0.27), (0.024, hilt),
                                               (0.012, hilt), (0.0, hilt - 0.005)], n=n)
            P.box("chrome", (0.0, 0.17, 0.019), (0.009, 0.022, 0.006))
            if P.lod < 2:
                P.box("sith_kyber", (0.0, 0.165, 0.0255), (0.004, 0.005, 0.0015), bottom=False)
                P.box("sith_kyber", (0.0, 0.18, 0.0255), (0.004, 0.003, 0.0015), bottom=False)
        emitter = v_add(pommel, v_mul(d, hilt))
        holds = [v_add(pommel, v_mul(d, 0.09)), v_add(pommel, v_mul(d, 0.23))]
    else:
        side = (-d[1], d[0], 0.0) if rz >= 0 else (d[1], -d[0], 0.0)
        bend = v_add(pommel, v_add(v_mul(d, 0.16), v_mul(side, 0.058)))
        dg = v_norm(v_sub(bend, pommel))
        rzg = math.degrees(math.atan2(-dg[0], dg[1]))
        lg = v_len(v_sub(bend, pommel))
        with _tx(P, pommel, (0.0, 0.0, rzg)):
            P.lathe("sith_electrum", (0.0, 0.0, 0.0), [(0.0, 0.0), (0.016, 0.0), (0.021, 0.015), (0.019, 0.03), (0.016, 0.035), (0.017, lg),
                                                       (0.0, lg)], n=n)
            if P.lod < 2:
                for k in range(4):
                    P.lathe("sith_metal", (0.0, 0.05 + 0.025 * k, 0.0), [(0.0165, -0.006), (0.019, -0.003), (0.019, 0.003), (0.0165, 0.006),
                                                                         (0.0165, -0.006)], n=n)
        P.sphere("sith_electrum", bend, 0.019, n=n)
        with _tx(P, bend, (0.0, 0.0, rz)):
            P.lathe("sith_electrum", (0.0, 0.0, 0.0), [(0.0, -0.005), (0.018, 0.0), (0.018, 0.07), (0.023, 0.08), (0.023, 0.11), (0.012, 0.11),
                                                       (0.0, 0.105)], n=n)
        emitter = v_add(bend, v_mul(d, 0.11))
        holds = [v_add(pommel, v_mul(dg, lg * 0.55)), v_add(bend, v_mul(d, 0.05))]
    _blade(P, emitter, v_add(emitter, v_mul(d, blade)))
    return holds


def sith_saber_rack(P):
    """Sith saber rack, 1.95 m: an angular obsidian shield on a stepped base, two ignited red lightsabers crossed
    in front of it (a straight hilt and a curved electrum one), a double-bladed saber staff across the top,
    iron clamps, a kyber diamond and rune strips, and a dish of bled kyber crystals on the base."""
    base = [(-0.56, -0.30), (0.56, -0.30), (0.62, -0.18), (0.62, 0.18), (0.56, 0.30), (-0.56, 0.30), (-0.62, 0.18), (-0.62, -0.18)]
    _extrude(P, "sith_obsidian", base, 0.0, 0.12, chamfer=0.015)
    _extrude(P, "sith_obsidian", _inset(base, 0.08), 0.12, 0.20, chamfer=0.012, cap0=False)
    _strip(P, "sith_vein", [(x, 0.12, z) for x, z in _inset(base, 0.064)], 0.014, (0, 1, 0), lift=0.0015, taper=False, closed=True)
    shield = [(-0.44, 0.20), (0.44, 0.20), (0.52, 1.25), (0.0, 1.95), (-0.52, 1.25)]
    _extrude(P, "sith_obsidian", shield, -0.20, -0.12, chamfer=0.02, axis="z")
    P.sweep("sith_metal", _densify([(x, y, -0.118) for x, y in _inset(shield, 0.035)], lod=P.lod), 0.012, closed=True, sides=P.n(6, 4))
    P.box("sith_metal", (0.0, 1.0, -0.208), (0.04, 0.75, 0.01))                     # iron spine and struts behind
    for sx in (-1, 1):
        P.sweep("sith_metal", [(sx * 0.30, 0.20, -0.27), (sx * 0.24, 1.05, -0.205)], 0.016, sides=P.n(6, 4))
        P.box("sith_metal", (sx * 0.30, 0.205, -0.27), (0.035, 0.008, 0.03))
    _extrude(P, "sith_kyber", [(0.0, 1.56), (0.075, 1.70), (0.0, 1.84), (-0.075, 1.70)], -0.13, -0.10, chamfer=0.008, axis="z", cap0=False)
    for sx in (-1, 1):
        P.decal("sith_runes", (sx * 0.36, 0.74, -0.1188), 0.10, 0.62, (0, 0, 1))
    # the double-bladed staff across the top on two clamps
    staff_y, staff_z = 1.47, -0.07
    with _tx(P, (-0.17, staff_y, staff_z), (0.0, 0.0, -90.0)):
        P.lathe("sith_metal", (0.0, 0.0, 0.0), [(0.0, 0.0), (0.022, 0.0), (0.024, 0.03), (0.019, 0.04), (0.019, 0.30), (0.024, 0.31),
                                                (0.022, 0.34), (0.0, 0.34)], n=P.n(12, 6))
        if P.lod < 2:
            for k in range(6):
                P.lathe("chrome", (0.0, 0.08 + 0.036 * k, 0.0), [(0.019, -0.006), (0.0215, -0.003), (0.0215, 0.003), (0.019, 0.006),
                                                                 (0.019, -0.006)], n=P.n(12, 6))
    for sgn in (-1, 1):
        _blade(P, (sgn * 0.17, staff_y, staff_z), (sgn * 0.62, staff_y, staff_z))
        P.box("sith_metal", (sgn * 0.10, staff_y, -0.098), (0.016, 0.03, 0.026))
    # the crossed sabers and their clamps
    for pommel, d, curved in (((-0.36, 0.40, -0.035), (0.5, 0.866, 0.0), False), ((0.36, 0.40, 0.015), (-0.5, 0.866, 0.0), True)):
        rz = math.degrees(math.atan2(-d[0], d[1]))
        for x, y, z in _saber(P, pommel, d, blade=0.92, curved=curved):
            P.box("sith_metal", (x, y, (z - 0.12) / 2 - 0.014), (0.022, 0.014, (z + 0.12) / 2 - 0.004), r=(0, 0, rz))
    # a dish of bled kyber crystals on the base
    dc = (0.0, 0.20, 0.13)
    P.lathe("sith_obsidian", dc, [(0.0, 0.0), (0.09, 0.0), (0.14, 0.04), (0.15, 0.055), (0.13, 0.055), (0.10, 0.03), (0.0, 0.03)], n=6)
    for k, (dx, dz, ln, rr, tx_, tz_) in enumerate(((0.0, 0.0, 0.17, 0.028, 0.0, 0.0), (0.06, 0.02, 0.11, 0.022, 0.5, 0.1),
                                                    (-0.05, 0.03, 0.10, 0.02, -0.5, 0.2), (0.02, -0.06, 0.09, 0.018, 0.2, -0.5),
                                                    (-0.04, -0.04, 0.08, 0.018, -0.3, -0.4))):
        if P.lod >= 2 and k > 2:
            continue
        _crystal(P, "sith_kyber", (dc[0] + dx, dc[1] + 0.025, dc[2] + dz), (tx_, 1.0, tz_), ln, rr, spin=0.5 * k)
    _glow(P, (dc[0], dc[1] + 0.057, dc[2]), 0.2)


# ---------------------------------------------------------------------------------------------------------------
# sith_obsidian_table
# ---------------------------------------------------------------------------------------------------------------

def sith_obsidian_table(P):
    """Low obsidian table (top 0.42 m, 1.72 x 0.88 m): an elongated hexagon slab inlaid with lava channels in the
    pattern of a Sith sigil, a glowing seam round its edge, two inverted-shard legs veined with lava, a stretcher;
    a small holocron on a stand and an obsidian goblet at the ends."""
    top = [(-0.86, 0.0), (-0.56, -0.44), (0.56, -0.44), (0.86, 0.0), (0.56, 0.44), (-0.56, 0.44)]
    y0, y1 = 0.34, 0.42
    _extrude(P, "sith_obsidian", top, y0, y1, chamfer=0.015)
    edge = _inset(top, -0.0015)
    for i in range(len(edge)):
        a, b = edge[i], edge[(i + 1) % len(edge)]
        P.flat("sith_vein", [(a[0], 0.374, a[1]), (b[0], 0.374, b[1]), (b[0], 0.386, b[1]), (a[0], 0.386, a[1])],
               ((a[0] + b[0]) / 2, 0.0, (a[1] + b[1]) / 2))
    # inlay: a border channel, a diamond pool in the middle, channels from the corners converging on it
    yt = y1 + 0.0015
    o, i_ = _inset(top, 0.07), _inset(top, 0.088)
    for k in range(len(o)):
        j = (k + 1) % len(o)
        P.poly("sith_vein", [(o[k][0], yt, o[k][1]), (o[j][0], yt, o[j][1]), (i_[j][0], yt, i_[j][1]), (i_[k][0], yt, i_[k][1])],
               [(0.0, 0.0), (1.0, 0.0), (1.0, 0.1), (0.0, 0.1)], (0, 1, 0))
    dia = [(-0.17, 0.0), (0.0, -0.115), (0.17, 0.0), (0.0, 0.115)]
    dio = _inset(dia, 0.018)
    for k in range(4):
        j = (k + 1) % 4
        P.poly("sith_vein", [(dia[k][0], yt, dia[k][1]), (dia[j][0], yt, dia[j][1]), (dio[j][0], yt, dio[j][1]), (dio[k][0], yt, dio[k][1])],
               [(0.0, 0.0), (1.0, 0.0), (1.0, 0.1), (0.0, 0.1)], (0, 1, 0))
    P.poly("sith_lava", [(x, y1 + 0.001, z) for x, z in dio], [(0.0, 0.0), (0.5, 0.0), (0.5, 0.5), (0.0, 0.5)], (0, 1, 0))
    for a, b in ((i_[0], dia[0]), (i_[3], dia[2]), (i_[1], dia[1]), (i_[2], dia[1]), (i_[4], dia[3]), (i_[5], dia[3])):
        _strip(P, "sith_vein", [(a[0], y1, a[1]), (b[0], y1, b[1])], 0.016, (0, 1, 0), lift=0.0015, taper=False)
    # legs: inverted shards with lava veins, a stretcher between them
    for sx in (-1, 1):
        x = sx * 0.46
        _extrude(P, "sith_obsidian", [(-0.30, y0), (0.30, y0), (0.12, 0.0), (-0.12, 0.0)], x - 0.06, x + 0.06, chamfer=0.012, axis="x")
        for sgn in (-1, 1):
            nrm = (sgn, 0.0, 0.0)
            _strip(P, "sith_vein", _zigzag((x + sgn * 0.06, 0.03, 0.02 * sgn), (x + sgn * 0.06, 0.32, -0.05 * sgn), P.n(6, 3), 0.035,
                                           110 + 2 * sx + sgn, nrm), 0.018, nrm, lift=0.0015)
        for sz in (-1, 1):                                       # iron claws gripping the floor at each foot
            _ray(P, "sith_metal", (x, 0.035, sz * 0.10), (x + sx * 0.03, 0.0, sz * 0.20), 0.07, 0.03, (0, 1, 0))
    for (u, v) in i_:                                            # kyber studs set into the channel corners
        P.lathe("sith_kyber", (u, y1, v), [(0.024, 0.0), (0.016, 0.012), (0.0, 0.014)], n=6)
    P.box("sith_obsidian", (0.0, 0.10, 0.0), (0.42, 0.025, 0.045))
    _strip(P, "sith_vein", [(-0.40, 0.125, 0.0), (0.40, 0.125, 0.0)], 0.014, (0, 1, 0), lift=0.0015)
    # props: a small holocron on a stand, an obsidian goblet
    P.lathe("sith_obsidian", (0.56, y1, 0.0), [(0.0, 0.0), (0.06, 0.0), (0.04, 0.02), (0.025, 0.06), (0.05, 0.075), (0.0, 0.075)], n=6)
    _holocron(P, (0.56, y1 + 0.135, 0.0), 0.10, 0.10, ry=20.0)
    P.lathe("sith_obsidian", (-0.55, y1, 0.12), [(0.0, 0.0), (0.045, 0.0), (0.012, 0.015), (0.01, 0.08), (0.045, 0.11), (0.05, 0.17),
                                                (0.044, 0.17), (0.0, 0.12)], n=8)


PIECES = {
    "sith_dark_shrine": (sith_dark_shrine, "interact"),
    "sith_throne": (sith_throne, "seat"),
    "sith_lava_brazier": (sith_lava_brazier, "lamp"),
    "sith_hooded_statue": (sith_hooded_statue, "decor"),
    "sith_saber_rack": (sith_saber_rack, "decor"),
    "sith_obsidian_table": (sith_obsidian_table, "table"),
}
SLOTS = {"sith": {"sith_obsidian": "sith_obsidian", "sith_basalt": "sith_basalt", "sith_statue": "sith_basalt",
                  "sith_lava": "sith_lava", "sith_vein": "sith_vein", "sith_runes": "sith_runes",
                  "sith_holocron": "sith_holocron", "sith_kyber": "sith_kyber", "sith_blade": "sith_blade",
                  "sith_blade_core": "sith_blade_core", "sith_metal": "sith_metal", "sith_velvet": "sith_velvet",
                  "sith_glow": "sith_glow", "sith_void": "sith_void", "sith_fire": "sith_fire", "chrome": "imp_chrome",
                  "sith_rune_ring": "sith_rune_ring", "sith_rune_band": "sith_rune_band",
                  "sith_electrum": "gilt"}}
UV = {"sith_obsidian": 1.0, "sith_basalt": 1.0, "sith_statue": 0.9, "sith_lava": 0.6, "sith_vein": 0.3, "sith_runes": 1.0,
      "sith_holocron": 0.3, "sith_kyber": 0.15, "sith_blade": 0.5, "sith_blade_core": 0.5, "sith_metal": 0.25,
      "sith_velvet": 0.4, "sith_glow": 1.0, "sith_void": 1.0, "sith_fire": 1.0, "sith_electrum": 0.3,
      "sith_rune_ring": 1.0, "sith_rune_band": 1.0}
SMOOTH = ("sith_statue", "sith_velvet", "sith_blade", "sith_blade_core", "sith_glow", "sith_lava", "sith_vein", "sith_void",
          "sith_metal", "sith_electrum", "sith_fire")
COLORS = {"sith": (0.14, 0.1, 0.12)}
