"""Hutt palace, second set: six more pieces for Jabba-grade interiors. They use the Hutt theme's slots
(furniture.SLOTS["hutt"]: sandstone, frieze, velvet, silk, brass, wood, bone, coals...) so they match the first
set, plus hutt2_* slots for the new materials (examples/frn_sets/hutt2.py).

  hutt_gong             the great palace gong: a 1.2 m hammered bronze disc on chains from a carved wood and
                        brass frame with tusk horns and the Hutt sigil, a padded mallet on a hook  interact (gong)
  hutt_rancor_chaise    rancor-hide chaise longue: scrolled head end held by great curving tusks, a velvet
                        bolster and silk cushions, rancor-claw feet                                 seat (foot)
  hutt_brazier          tall brass tripod brazier: sunburst bowl of glowing coals, flames, chain swags  lamp
  hutt_carbonite_slab   a smuggler frozen in carbonite, upright on a sandstone, wood and brass stand,
                        blinking side panels                                                       decor
  hutt_rancor_skull     giant rancor skull trophy, jaws agape, on a carved sandstone plinth, brass plaque
  hutt_treasure_chest   open chest overflowing with peggats, gold bars, gems and credit chips      decor"""
from __future__ import annotations

import math
from contextlib import contextmanager

from .. import furniture as _fu
from ..furniture import (v_add, v_cross, v_len, v_mul, v_norm, v_sub, xf, smoothstep, seat_hardpoint,
                         station_hardpoints, light_hardpoint, _tassel)

GONG_SPOT = (0.0, 0.0, 0.74)          # the gong player's feet: 0.70 m in front of the gong face, facing it (-z)


# ---------------------------------------------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------------------------------------------

@contextmanager
def _tx(P, c=(0.0, 0.0, 0.0), r=(0.0, 0.0, 0.0), s=(1.0, 1.0, 1.0), pivot=(0.0, 0.0, 0.0)):
    """Add a sub-assembly through: scale s (local axes), rotate r about pivot, translate c."""
    old = P.xform

    def f(p):
        q = xf((p[0] * s[0], p[1] * s[1], p[2] * s[2]), c, r, pivot)
        return old(q) if old else q
    P.xform = f
    try:
        yield
    finally:
        P.xform = old


def _ellipsoid(P, slot, c, rad, r=(0.0, 0.0, 0.0), lat0=-90.0, lat1=90.0, n=None, inside=False, rows=None):
    """Ellipsoid with semi-axes rad (rotated by r), textured at roughly world scale."""
    rows = rows or max(2, P.n(12, 4) * int(abs(lat1 - lat0)) // 180 or 2)
    prof = [(math.cos(math.radians(lat0 + (lat1 - lat0) * k / rows)), math.sin(math.radians(lat0 + (lat1 - lat0) * k / rows)))
            for k in range(rows + 1)]
    s = _fu.UV.get(slot, 1.0)
    m = max(rad)
    with _tx(P, c, r, rad):
        P.lathe(slot, (0.0, 0.0, 0.0), prof, n=n or P.n(16, 6), utiles=max(1, round(2 * math.pi * m / s)),
                vscale=s / m, inside=inside)


def _spline(ctrl, n):
    """Catmull-Rom curve through the control points (tuples of any length), n segments."""
    m = len(ctrl)
    out = []
    for i in range(n + 1):
        s = i / n * (m - 1)
        k = min(int(s), m - 2)
        t = s - k
        p0, p1, p2, p3 = ctrl[max(k - 1, 0)], ctrl[k], ctrl[k + 1], ctrl[min(k + 2, m - 1)]
        out.append(tuple(0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t + (-a + 3 * b - 3 * c + d) * t ** 3)
                         for a, b, c, d in zip(p0, p1, p2, p3)))
    return out


def _rrect(hx, hz, rad, seg=4, cz=0.0):
    """Rounded-rectangle plan ring [(x, z)]."""
    pts = []
    for cx, cc, a0 in ((hx - rad, hz - rad, 0), (-hx + rad, hz - rad, 90), (-hx + rad, -hz + rad, 180), (hx - rad, -hz + rad, 270)):
        for k in range(seg + 1):
            a = math.radians(a0 + 90 * k / seg)
            pts.append((cx + rad * math.cos(a), cz + cc + rad * math.sin(a)))
    return pts


def _densify(pts, step=0.08, closed=True, lod=0):
    """Insert points along a polyline every `step` m (coarser at higher LODs): F.sweep orients faces by the nearest
    path point, so long straight runs need intermediate points."""
    step *= (1.0, 1.5, 3.0, 5.0)[lod]
    out = []
    m = len(pts)
    for k in range(m if closed else m - 1):
        a, b = pts[k], pts[(k + 1) % m]
        cnt = max(1, int(math.ceil(v_len(v_sub(b, a)) / step)))
        out += [v_add(a, v_mul(v_sub(b, a), j / cnt)) for j in range(cnt)]
    if not closed:
        out.append(pts[-1])
    return out


def _chain(P, slot, path, link=0.05, wire=0.007):
    """A chain of alternating oval links along a polyline (a plain cord from LOD 2)."""
    if P.lod >= 2:
        P.sweep(slot, path, wire * 1.4, sides=4)
        return
    L = [0.0]
    for k in range(1, len(path)):
        L.append(L[-1] + v_len(v_sub(path[k], path[k - 1])))
    cnt = max(1, int(round(L[-1] / (link * 0.78))))
    k = 0
    for i in range(cnt):
        s = (i + 0.5) * L[-1] / cnt
        while k < len(path) - 2 and L[k + 1] < s:
            k += 1
        t = (s - L[k]) / ((L[k + 1] - L[k]) or 1.0)
        p = v_add(path[k], v_mul(v_sub(path[k + 1], path[k]), t))
        d = v_norm(v_sub(path[k + 1], path[k]))
        e1 = v_norm(v_cross(d, (0.0, 1.0, 0.0) if abs(d[1]) < 0.9 else (1.0, 0.0, 0.0)))
        e = e1 if i % 2 else v_cross(d, e1)
        ring = [v_add(p, v_add(v_mul(d, link * 0.5 * math.cos(2 * math.pi * j / 6)), v_mul(e, link * 0.27 * math.sin(2 * math.pi * j / 6))))
                for j in range(6)]
        P.sweep(slot, ring, wire, sides=4, closed=True)


def _yaxis_to(n):
    """Euler angles (rx, ry, rz) for furniture.rot that turn local +y onto direction n."""
    n = v_norm(n)
    b = math.degrees(math.acos(max(-1.0, min(1.0, n[1]))))
    c = math.degrees(math.atan2(n[2], -n[0])) if abs(n[1]) < 0.9999 else 0.0
    return (0.0, c, b)


def _tusk(P, ctrl, r0, n=None, slot="bone", r1=0.006, sides=None):
    """A curved tusk / horn along a spline, r0 at the root tapering to a point."""
    path = _spline(ctrl, n or P.n(12, 5))
    P.sweep(slot, path, lambda t: r0 * (1 - t) ** 0.85 + r1, sides=sides or P.n(10, 5), vscale=0.3)
    return path


def _studs(P, slot, pts, r=0.016, nrm=(0.0, 0.0, 1.0)):
    """Low domed studs on a surface facing nrm (cheap rivet heads; none from LOD 2)."""
    if P.lod >= 2:
        return
    rr = _yaxis_to(nrm)
    for p in pts:
        P.lathe(slot, p, [(r, -0.3 * r), (r, 0.0), (0.7 * r, 0.55 * r), (0.0, 0.75 * r)], n=P.n(8, 5), r=rr)


def _ray(P, slot, base, tip, w, th, up):
    """A flat sunburst ray: a pyramid on a w x th rectangle at base (th along `up`) pointing at tip."""
    d = v_norm(v_sub(tip, base))
    up = v_norm(v_sub(up, v_mul(d, sum(up[i] * d[i] for i in range(3)))))
    side = v_cross(d, up)
    c = [v_add(base, v_add(v_mul(side, sx * w / 2), v_mul(up, sy * th / 2))) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    for k in range(4):
        a, b = c[k], c[(k + 1) % 4]
        P.poly(slot, [a, b, tip], [(0.0, 0.0), (1.0, 0.0), (0.5, 1.0)], v_sub(v_mul(v_add(a, b), 0.5), base))
    P.flat(slot, c, v_mul(d, -1.0))


def _flame(P, slot, base, h, r, lean=(0.0, 0.0), n=None):
    """An opaque self-lit flame tongue: a teardrop of revolution bent by `lean` (dx, dz at the tip), its texture
    running from the hot root (v 0) to the tip (v 1). Closed, so it reads from every side with no sorting."""
    prof = [(0.0, 0.0), (0.55 * r, 0.04 * h), (r, 0.18 * h), (0.92 * r, 0.36 * h), (0.6 * r, 0.62 * h), (0.25 * r, 0.86 * h), (0.0, h)]
    L = sum(math.hypot(prof[k + 1][0] - prof[k][0], prof[k + 1][1] - prof[k][1]) for k in range(len(prof) - 1))
    old = P.xform

    def f(p):
        t = max(0.0, min(1.0, (p[1] - base[1]) / h))
        q = (p[0] + lean[0] * t * t, p[1], p[2] + lean[1] * t * t)
        return old(q) if old else q
    P.xform = f
    try:
        P.lathe(slot, base, prof, n=n or P.n(8, 5), utiles=1, vscale=L)
    finally:
        P.xform = old


def _mound(P, slot, c, R, H, rings=None, n=None):
    """A low heap (coins, sand) on the floor with planar world-scaled UVs (no pinching at the top)."""
    rings = rings or P.n(4, 2)
    n = n or P.n(18, 8)
    s = _fu.UV.get(slot, 1.0)
    pt = lambda rr, a: (c[0] + rr * math.cos(a), c[1] + H * max(0.0, 1 - (rr / R) ** 2) ** 0.8, c[2] + rr * math.sin(a))
    for k in range(rings):
        r0, r1 = R * k / rings, R * (k + 1) / rings
        for i in range(n):
            a0, a1 = 2 * math.pi * i / n, 2 * math.pi * (i + 1) / n
            q = [pt(r1, a0), pt(r1, a1)] + ([pt(r0, a1), pt(r0, a0)] if k else [pt(0.0, 0.0)])
            P.poly(slot, q, [(p[0] / s, -p[2] / s) for p in q], (0.0, 1.0, 0.0))


# ---------------------------------------------------------------------------------------------------------------
# hutt_gong
# ---------------------------------------------------------------------------------------------------------------

def _gong_depth(r, R):
    """Forward offset of the gong face at radius r: a gentle dome with a raised polished boss."""
    return 0.040 + 0.012 * (1 - (r / R) ** 2) + 0.030 * (1 - smoothstep(0.085, 0.13, r)) + 0.012 * max(0.0, 1 - (r / 0.085) ** 2)


def _gong_face(P, slot, c, R):
    """The hammered gong face facing +z, the texture fit once across it (radius R)."""
    radii = [0.0, 0.05, 0.085, 0.11, 0.13, 0.17, 0.25, 0.33, 0.41, 0.49, R] if P.lod < 2 else [0.0, 0.085, 0.13, 0.30, R]
    na = P.n(40, 14)                       # = the rim lathe's count, so the seam vertices coincide
    for k in range(len(radii) - 1):
        r0, r1 = radii[k], radii[k + 1]
        for i in range(na):
            a0, a1 = 2 * math.pi * i / na, 2 * math.pi * (i + 1) / na
            loc = [(r1 * math.cos(a0), r1 * math.sin(a0)), (r1 * math.cos(a1), r1 * math.sin(a1))]
            loc += [(r0 * math.cos(a1), r0 * math.sin(a1)), (r0 * math.cos(a0), r0 * math.sin(a0))] if r0 > 0 else [(0.0, 0.0)]
            pts = [(c[0] + x, c[1] + y, c[2] + _gong_depth(math.hypot(x, y), R)) for x, y in loc]
            P.poly(slot, pts, [(0.5 + x / (2 * R), 0.5 + y / (2 * R)) for x, y in loc], (0.0, 0.0, 1.0))


def hutt_gong(P):
    """The great palace gong: a 1.2 m hammered bronze disc (centre 1.42 m, face at z ~0.05) hung on two chains
    from a carved wood and brass frame; tusk horns on the crossbeam ends, the Hutt sigil in a brass sunburst on
    top, a padded mallet on a hook on the right post, a sandstone base. Station: GONG_SPOT, facing the gong."""
    gy, R, Rf = 1.42, 0.61, 0.565            # gong centre height, rim radius, face radius
    PX = 0.82                                # post centres x = +-PX
    BY0, BY1 = 2.24, 2.40                    # crossbeam bottom / top
    # -- sandstone base: rounded slab with a carved frieze edge, a second tier, foot blocks under the posts
    P.prism("sandstone", _rrect(1.16, 0.36, 0.12, P.n(4, 2)), 0.0, 0.10, side_slot="frieze", side_vscale=0.10)
    P.prism("sandstone", _rrect(1.04, 0.27, 0.08, P.n(4, 2)), 0.10, 0.16)
    for sx in (-1, 1):
        x = sx * PX
        P.prism("sandstone", [(x - 0.20, -0.24), (x + 0.20, -0.24), (x + 0.20, 0.24), (x - 0.20, 0.24)], 0.16, 0.42,
                side_slot="frieze", side_vscale=0.13)
        P.box("brass", (x, 0.428, 0.0), (0.21, 0.008, 0.25))
        # turned wood post with brass collars
        P.lathe("wood", (x, 0.436, 0.0), [(0.0, 0.0), (0.12, 0.0), (0.12, 0.05), (0.095, 0.09), (0.095, 0.15), (0.11, 0.18),
                                          (0.08, 0.24), (0.068, 0.40), (0.064, 1.46), (0.08, 1.52), (0.095, 1.58), (0.08, 1.64),
                                          (0.088, 1.70), (0.088, BY0 - 0.426), (0.0, BY0 - 0.426)], n=P.n(14, 6))
        for yy in ((0.84, 1.40) if P.lod < 3 else ()):
            P.lathe("brass", (x, yy, 0.0), [(0.066, -0.03), (0.085, -0.02), (0.085, 0.02), (0.066, 0.03)], n=P.n(14, 6))
        # A-frame braces from the foot block to the post
        for sz in (-1, 1):
            a, b = (x, 0.43, sz * 0.20), (x, 0.98, sz * 0.05)
            P.sweep("wood", [a, b], 0.03, sides=P.n(8, 4))
            if P.lod < 3:
                P.sphere("brass", (x, 0.44, sz * 0.20), 0.042, n=P.n(8, 5))
        # finial over the post: brass knob, a coal-glow jewel and a spike
        P.lathe("brass", (x, BY1 + 0.016, 0.0), [(0.0, 0.0), (0.075, 0.0), (0.055, 0.04), (0.035, 0.06), (0.06, 0.10),
                                                 (0.03, 0.13), (0.0, 0.135)], n=P.n(12, 6))
        P.sphere("coals", (x, BY1 + 0.19, 0.0), 0.045, n=P.n(8, 5))
        P.cone("brass", (x, BY1 + 0.22, 0.0), (x, BY1 + 0.36, 0.0), 0.022, n=P.n(6, 4))
    # -- crossbeam: carved frieze faces, brass edges, tusk horns at the ends, tassels under them
    bx = PX + 0.16
    P.prism("wood", [(-bx, -0.10), (bx, -0.10), (bx, 0.10), (-bx, 0.10)], BY0, BY1, bottom=True, side_slot="frieze",
            side_vscale=BY1 - BY0)
    for y in (BY0 - 0.008, BY1 + 0.008):
        P.box("brass", (0.0, y, 0.0), (PX + 0.17, 0.008, 0.11))
    for sz in (-1, 1):
        _studs(P, "brass", [(x * 0.1, BY1 - 0.022, sz * 0.1) for x in range(-9, 10, 3)], r=0.016, nrm=(0, 0, sz))
    for sx in (-1, 1):
        cx, cy, rho = sx * (PX + 0.14), BY0 + 0.08 + 0.26, 0.26
        ctrl = [(cx + sx * rho * math.sin(math.radians(a)), cy - rho * math.cos(math.radians(a)), 0.0) for a in (0, 35, 70, 100, 125)]
        _tusk(P, [(sx * (PX + 0.06), BY0 + 0.08, 0.0)] + ctrl, 0.075)
        P.lathe("brass", (sx * (PX + 0.19), BY0 + 0.08, 0.0), [(0.066, -0.035), (0.092, -0.025), (0.092, 0.025), (0.066, 0.035),
                                                               (0.066, -0.035)], r=(0, 0, -90 * sx), n=P.n(14, 6))
        _tassel(P, (sx * (PX + 0.10), BY0 - 0.02, 0.0), 0.16)
    # -- the Hutt sigil in a brass sunburst medallion over the beam
    mc = (0.0, BY1 + 0.29, 0.0)
    P.lathe("brass", (0.0, BY1 + 0.016, 0.0), [(0.0, 0.0), (0.09, 0.0), (0.06, 0.03), (0.035, 0.05), (0.035, 0.08), (0.0, 0.08)],
            n=P.n(12, 6))
    P.lathe("brass", mc, [(0.0, -0.035), (0.20, -0.035), (0.225, -0.015), (0.225, 0.015), (0.20, 0.035), (0.0, 0.035)],
            r=(90, 0, 0), n=P.n(28, 10))
    P.disc("hutt2_sigil", v_add(mc, (0.0, 0.0, 0.0365)), 0.0, 0.198, fit=True, n=P.n(28, 10), r=(90, 0, 0))
    P.disc("hutt2_sigil", v_add(mc, (0.0, 0.0, -0.0365)), 0.0, 0.198, fit=True, n=P.n(28, 10), r=(90, 180, 0))
    for k in range(11):
        a = math.radians(-18 + 216 * k / 10)
        ln = 0.42 if k % 2 == 0 else 0.33
        _ray(P, "brass", (0.17 * math.cos(a), mc[1] + 0.17 * math.sin(a), 0.0),
             (ln * math.cos(a), mc[1] + ln * math.sin(a), 0.0), 0.06, 0.028, (0.0, 0.0, 1.0))
    # -- lower brass rail between the posts
    P.sweep("brass", _densify([(-PX, 0.62, 0.0), (PX, 0.62, 0.0)], 0.1, closed=False, lod=P.lod), 0.022, sides=P.n(8, 4))
    P.lathe("brass", (0.0, 0.62, 0.0), [(0.0, -0.06), (0.04, -0.05), (0.05, 0.0), (0.04, 0.05), (0.0, 0.06)], n=P.n(10, 5))
    # -- the gong: bronze rim and back, hammered face fit once
    gc = (0.0, gy, 0.0)
    P.lathe("hutt2_bronze", gc, [(0.0, -0.045), (0.30, -0.052), (0.52, -0.058), (0.585, -0.055), (R, -0.035), (R + 0.006, 0.0),
                                 (R, 0.032), (0.598, 0.046), (0.578, 0.047), (Rf, _gong_depth(Rf, Rf))],
            r=(90, 0, 0), n=P.n(40, 14))
    _gong_face(P, "hutt2_gong", gc, Rf)
    # chains from eye bolts under the beam to eyelets on the rim
    for sx in (-1, 1):
        a = math.radians(90 - sx * 27)
        rad = (math.cos(a), math.sin(a), 0.0)
        eye = (gc[0] + (R + 0.018) * rad[0], gc[1] + (R + 0.018) * rad[1], 0.0)
        P.sweep("brass", [v_add(eye, v_add(v_mul(rad, 0.022 * math.cos(2 * math.pi * j / 8)), (0.0, 0.0, 0.022 * math.sin(2 * math.pi * j / 8))))
                          for j in range(8)], 0.007, closed=True, sides=P.n(5, 4))
        top = (sx * 0.30, BY0 - 0.03, 0.0)
        P.lathe("brass", (sx * 0.30, BY0 - 0.035, 0.0), [(0.0, 0.0), (0.03, 0.0), (0.03, 0.02), (0.0, 0.02)], n=P.n(8, 5))
        _chain(P, "brass", [top, v_add(eye, v_mul(rad, 0.03))], link=0.055, wire=0.0075)
    # -- the mallet: padded velvet head, silk band, wood handle hanging by a silk loop from a brass hook
    hx, hz = PX, 0.16
    P.sweep("brass", [(hx, 1.56, 0.04), (hx, 1.56, 0.15), (hx, 1.585, 0.18), (hx, 1.62, 0.185)], 0.011, sides=P.n(6, 4))
    P.sweep("silk", [(hx - 0.022, 1.50, hz), (hx - 0.012, 1.565, hz), (hx + 0.012, 1.565, hz), (hx + 0.022, 1.50, hz)], 0.006,
            sides=4)
    P.lathe("wood", (hx, 0.98, hz), [(0.0, 0.0), (0.02, 0.0), (0.016, 0.06), (0.014, 0.48), (0.02, 0.52), (0.022, 0.54),
                                     (0.0, 0.545)], n=P.n(8, 5))
    P.lathe("brass", (hx, 0.995, hz), [(0.022, -0.01), (0.028, 0.0), (0.028, 0.03), (0.02, 0.04)], n=P.n(8, 5))
    _ellipsoid(P, "velvet", (hx, 0.915, hz), (0.085, 0.095, 0.085))
    P.lathe("silk", (hx, 0.915, hz), [(0.084, -0.028), (0.092, 0.0), (0.084, 0.028)], n=P.n(16, 6))
    _tassel(P, (hx, 1.49, hz + 0.03), 0.07)
    station_hardpoints(P, "gong", GONG_SPOT, yaw=180.0)


# ---------------------------------------------------------------------------------------------------------------
# hutt_rancor_chaise
# ---------------------------------------------------------------------------------------------------------------

def _claw_foot(P, c):
    """Rancor-claw foot: three bone talons gripping a brass ball under a short carved wood collar."""
    x, _, z = c
    P.lathe("brass", (x, 0.05, z), [(0.05 * math.cos(math.radians(a)), 0.05 * math.sin(math.radians(a))) for a in range(-90, 91, 30)],
            n=P.n(10, 6))
    if P.lod >= 3:
        return
    P.lathe("wood", (x, 0.085, z), [(0.0, 0.0), (0.045, 0.0), (0.035, 0.02), (0.05, 0.035), (0.06, 0.05), (0.0, 0.05)], n=P.n(10, 5))
    for k in range(3):
        a = math.radians(90 + 120 * k)
        ca, sa = math.cos(a), math.sin(a)
        ctrl = [(x + 0.02 * ca, 0.11, z + 0.02 * sa), (x + 0.055 * ca, 0.085, z + 0.055 * sa), (x + 0.066 * ca, 0.045, z + 0.066 * sa),
                (x + 0.058 * ca, 0.012, z + 0.058 * sa)]
        _tusk(P, ctrl, 0.017, n=P.n(5, 3), r1=0.003, sides=5)


def hutt_rancor_chaise(P):
    """Rancor-hide chaise longue, 2.4 m over the tusks: a scrolled head end (-x) held by great curving bone tusks,
    a low roll on smaller tusks at the foot (+x), a raked hide back, velvet bolster, silk cushions, a carved wood
    frame with brass banding on rancor-claw feet. Seat 0.46, front edge z 0.30 -> foot 0.475."""
    L, zf, zb = 0.96, 0.30, -0.40
    zc = (zf + zb) / 2
    fz0, fz1 = zb - 0.07, zf + 0.03                         # frame depth
    # -- frame: wood apron with brass bands, a fringe of rancor teeth, six claw feet
    P.box("wood", (0.0, 0.245, (fz0 + fz1) / 2), (L + 0.04, 0.115, (fz1 - fz0) / 2))
    for y in (0.14, 0.352):
        ring = _densify([(x, y, z) for x, z in _rrect(L + 0.048, (fz1 - fz0) / 2 + 0.008, 0.02, 1, cz=(fz0 + fz1) / 2)], lod=P.lod)
        P.sweep("brass", ring, 0.011, closed=True, sides=P.n(6, 4))
    _studs(P, "brass", [(x * 0.12, 0.245, fz1) for x in range(-7, 8)], r=0.016)
    if P.lod < 2:
        for k in range(15):
            x = -0.84 + 0.12 * k
            P.cone("bone", (x, 0.135, fz1 - 0.01), (x, 0.08, fz1 + 0.005), 0.016, n=5)
    for x in (-0.64, 0.0, 0.64):
        for z in (fz1 - 0.08, fz0 + 0.07):
            _claw_foot(P, (x, 0.0, z))
    # -- seat: hide cushion with silk piping along the front
    P.rbox("hutt2_hide", (0.0, 0.405, zc), (L, 0.055, (zf - zb) / 2), 0.045, puff=0.012, seg=P.n(3, 2))
    P.sweep("silk", _densify([(-L, 0.43, zf + 0.004), (L, 0.43, zf + 0.004)], 0.1, closed=False, lod=P.lod), 0.014, sides=P.n(8, 4))
    # -- raked back: hide front, wood back, a carved top rail falling from the head end to the open end
    xe = 0.60
    rail_h = lambda x: 0.62 + 0.36 * smoothstep(xe, -L, x)
    zfr = lambda y: zb + 0.03 - 0.10 * (y - 0.42) / 0.55
    nx, ny = P.n(14, 6), P.n(5, 3)
    xs = [-L + (xe + L) * i / nx for i in range(nx + 1)]
    front = [[(x, 0.30 + (rail_h(x) - 0.30) * j / ny, zfr(0.30 + (rail_h(x) - 0.30) * j / ny)) for j in range(ny + 1)] for x in xs]
    back = [[(x, y, z - 0.07) for x, y, z in col] for col in front]
    U = [[x / 0.5] * (ny + 1) for x in xs]
    V = [[p[1] / 0.5 for p in col] for col in front]
    P.grid("hutt2_hide", front, U, V, lambda q: (0.0, 0.12, 1.0))
    P.grid("wood", back, U, V, lambda q: (0.0, -0.1, -1.0))
    P.flat("wood", [front[-1][0], back[-1][0], back[-1][-1], front[-1][-1]], (1, 0, 0))
    P.sweep("wood", [(x, rail_h(x) + 0.012, zfr(rail_h(x)) - 0.035) for x in xs] + [(xe + 0.06, rail_h(xe) - 0.02, zfr(rail_h(xe)) - 0.035)],
            0.042, sides=P.n(8, 4))
    _studs(P, "brass", [(x, y, zfr(y)) for x in (-0.72, -0.42, -0.12, 0.18, 0.46) for y in (0.60, 0.78)
                        if y < rail_h(x) - 0.07], r=0.018, nrm=(0.0, 0.18, 1.0))
    # -- head end: upholstered arm with an outward scroll roll, brass rosettes, two great tusks round it
    P.box("hutt2_hide", (-L - 0.01, 0.60, zc), (0.06, 0.22, (zf - zb) / 2 + 0.02))
    rz0, rz1 = zf + 0.05, zb - 0.06
    P.sweep("hutt2_hide", [(-L - 0.05, 0.84, rz0), (-L - 0.05, 0.84, rz1)], 0.125, sides=P.n(16, 8), caps=False)
    for z, rx in ((rz0, 90), (rz1, -90)):
        P.lathe("brass", (-L - 0.05, 0.84, z), [(0.0, -0.005), (0.128, -0.005), (0.135, 0.008), (0.11, 0.022), (0.06, 0.03),
                                                (0.0, 0.034)], r=(rx, 0, 0), n=P.n(18, 8))
        P.sphere("coals", (-L - 0.05, 0.84, z + (0.04 if rx > 0 else -0.04)), 0.028, n=P.n(8, 5))
    for z in (rz0 + 0.055, rz1 - 0.055):
        ctrl = [(-L + 0.04, 0.06, z), (-L - 0.10, 0.26, z), (-L - 0.22, 0.58, z), (-L - 0.25, 0.88, z), (-L - 0.15, 1.08, z),
                (-L + 0.03, 1.16, z), (-L + 0.17, 1.10, z)]
        _tusk(P, ctrl, 0.072, n=P.n(16, 6))
        P.lathe("brass", (-L + 0.04, 0.0, z), [(0.0, 0.0), (0.10, 0.0), (0.095, 0.035), (0.075, 0.055), (0.085, 0.085), (0.06, 0.10),
                                              (0.0, 0.10)], n=P.n(14, 6))
        P.lathe("brass", (-L - 0.22, 0.58, z), [(0.058, -0.03), (0.08, -0.02), (0.08, 0.02), (0.058, 0.03), (0.058, -0.03)],
                r=(0, 0, -22), n=P.n(12, 6))
    # -- foot end: a low hide roll on smaller tusks
    P.box("hutt2_hide", (L - 0.02, 0.50, zc), (0.05, 0.06, (zf - zb) / 2))
    P.sweep("hutt2_hide", [(L + 0.02, 0.57, zf + 0.04), (L + 0.02, 0.57, zb - 0.04)], 0.09, sides=P.n(14, 6), caps=False)
    for z, rx in ((zf + 0.04, 90), (zb - 0.04, -90)):
        P.lathe("brass", (L + 0.02, 0.57, z), [(0.0, -0.005), (0.092, -0.005), (0.098, 0.006), (0.07, 0.02), (0.0, 0.026)],
                r=(rx, 0, 0), n=P.n(14, 6))
    for z in (zf + 0.08, zb - 0.08):
        ctrl = [(L - 0.03, 0.05, z), (L + 0.10, 0.22, z), (L + 0.17, 0.48, z), (L + 0.12, 0.70, z), (L - 0.02, 0.80, z)]
        _tusk(P, ctrl, 0.05, n=P.n(12, 5))
        P.lathe("brass", (L - 0.03, 0.0, z), [(0.0, 0.0), (0.075, 0.0), (0.07, 0.03), (0.055, 0.045), (0.06, 0.07), (0.0, 0.07)],
                n=P.n(12, 6))
    # -- velvet bolster against the head arm, silk cushions against the back
    P.sweep("velvet", [(-L + 0.15, 0.565, zf - 0.03), (-L + 0.15, 0.565, zb + 0.07)], 0.10, sides=P.n(14, 6))
    for z, sgn in ((zf - 0.03, 1), (zb + 0.07, -1)):
        P.lathe("brass", (-L + 0.15, 0.565, z), [(0.0, -0.004), (0.10, -0.004), (0.104, 0.006), (0.05, 0.02), (0.0, 0.024)],
                r=(90 * sgn, 0, 0), n=P.n(14, 6))
        _tassel(P, (-L + 0.15, 0.565, z + sgn * 0.035), 0.10)
    if P.lod < 3:
        P.rbox("silk", (-0.48, 0.64, zb + 0.12), (0.22, 0.18, 0.07), 0.07, r=(-16, 12, 5), puff=0.03, seg=P.n(3, 2))
        P.rbox("silk", (0.10, 0.61, zb + 0.11), (0.19, 0.15, 0.065), 0.06, r=(-20, -10, -4), puff=0.03, seg=P.n(3, 2))
        P.rbox("velvet", (-0.16, 0.56, zb + 0.18), (0.15, 0.11, 0.06), 0.05, r=(-55, 18, 0), puff=0.025, seg=P.n(3, 2))
    seat_hardpoint(P, zf)


# ---------------------------------------------------------------------------------------------------------------
# hutt_brazier
# ---------------------------------------------------------------------------------------------------------------

def hutt_brazier(P):
    """Tall brass tripod brazier: a sunburst-rimmed bowl of glowing coals (rim 1.24 m), flames to 1.75 m, chain
    swags with brass drops round the rim, scrolled S-legs on claw feet, a carved sandstone foot. Light at the
    flame core."""
    by = 0.98                                                # bowl base
    oct8 = [(0.44 * math.cos(math.radians(22.5 + 45 * k)), 0.44 * math.sin(math.radians(22.5 + 45 * k))) for k in range(8)]
    P.prism("sandstone", oct8, 0.0, 0.09, side_slot="frieze", side_vscale=0.09)
    P.lathe("brass", (0.0, 0.09, 0.0), [(0.0, 0.0), (0.37, 0.0), (0.38, 0.014), (0.35, 0.028), (0.0, 0.028)], n=P.n(28, 10))
    # central stem with knops
    P.lathe("brass", (0.0, 0.118, 0.0), [(0.0, 0.0), (0.09, 0.0), (0.05, 0.05), (0.03, 0.10), (0.03, 0.24), (0.065, 0.28),
                                         (0.065, 0.32), (0.03, 0.36), (0.026, 0.56), (0.05, 0.60), (0.026, 0.64),
                                         (0.026, by - 0.118 - 0.04), (0.09, by - 0.118 + 0.005), (0.0, by - 0.118 + 0.005)],
            n=P.n(12, 6))
    # three scrolled legs on claw feet, a tie ring
    ctrl = [(0.10, by + 0.03), (0.27, by - 0.10), (0.37, by - 0.34), (0.33, 0.50), (0.27, 0.27), (0.31, 0.16), (0.345, 0.125)]
    for k in range(3):
        a = math.radians(90 + 120 * k)
        ca, sa = math.cos(a), math.sin(a)
        pts = [(r * ca, y, r * sa) for r, y in _spline(ctrl, P.n(16, 6))]
        P.sweep("brass", pts, lambda t: 0.027 - 0.009 * t, sides=P.n(8, 4))
        knee = (0.375 * ca, by - 0.30, 0.375 * sa)
        P.sphere("brass", knee, 0.036, n=P.n(8, 5))
        P.cone("brass", knee, (0.47 * ca, by - 0.26, 0.47 * sa), 0.02, n=P.n(6, 4))
        if P.lod < 2:                                       # a scroll curl where the leg meets the bowl
            curl = [(0.20 * ca + 0.06 * math.cos(u) * ca, by - 0.03 + 0.06 * math.sin(u), 0.20 * sa + 0.06 * math.cos(u) * sa)
                    for u in [math.radians(d) for d in range(-90, 200, 30)]]
            P.sweep("brass", curl, 0.012, sides=4)
        foot = (0.345 * ca, 0.118, 0.345 * sa)
        P.sphere("brass", v_add(foot, (0.0, 0.025, 0.0)), 0.035, n=P.n(8, 5))
        for j in (-1, 0, 1):
            b = a + j * 0.45
            P.cone("brass", v_add(foot, (0.0, 0.02, 0.0)), (foot[0] + 0.075 * math.cos(b), 0.118, foot[2] + 0.075 * math.sin(b)), 0.016, n=5)
    n = P.n(28, 10)
    P.sweep("brass", [(0.315 * math.cos(2 * math.pi * k / n), 0.45, 0.315 * math.sin(2 * math.pi * k / n)) for k in range(n)], 0.012,
            closed=True, sides=P.n(6, 4))
    for k in range(3):
        a = math.radians(30 + 120 * k)
        P.sweep("brass", [(0.03 * math.cos(a), 0.45, 0.03 * math.sin(a)), (0.31 * math.cos(a), 0.45, 0.31 * math.sin(a))], 0.01, sides=4)
    # the bowl: rolled rim, coals heaped inside, a sunburst of rays round the rim, medallions between the legs
    P.lathe("brass", (0.0, by, 0.0), [(0.0, 0.0), (0.10, 0.0), (0.20, 0.03), (0.29, 0.10), (0.35, 0.17), (0.38, 0.21), (0.395, 0.235),
                                      (0.39, 0.255), (0.37, 0.262), (0.35, 0.248), (0.335, 0.20), (0.30, 0.15)], n=P.n(32, 12))
    P.lathe("coals", (0.0, by + 0.20, 0.0), [(0.345, -0.01), (0.25, 0.04), (0.13, 0.068), (0.0, 0.078)], n=P.n(24, 8))
    if P.lod < 2:
        for k in range(14):
            a = 2 * math.pi * k / 14 + 0.3
            rr = 0.07 + 0.22 * ((k * 5) % 14) / 13
            yb = by + 0.20 + 0.078 * max(0.0, 1 - (rr / 0.336) ** 2)
            _ellipsoid(P, "coals", (rr * math.cos(a), yb + 0.008, rr * math.sin(a)), (0.045 + 0.02 * (k % 3), 0.026, 0.035 + 0.012 * (k % 2)),
                       r=(10 * (k % 3) - 10, 37 * k, 8 * (k % 2)), n=6, rows=4)
    for k in range(16):
        a = 2 * math.pi * (k + 0.5) / 16
        ca, sa = math.cos(a), math.sin(a)
        ln = 0.17 if k % 2 == 0 else 0.10
        _ray(P, "brass", (0.376 * ca, by + 0.245, 0.376 * sa), ((0.392 + ln) * ca, by + 0.245 + 0.45 * ln, (0.392 + ln) * sa),
             0.05, 0.016, (-0.45 * ca, 1.0, -0.45 * sa))
    for k in range(3):
        a = math.radians(30 + 120 * k)
        ca, sa = math.cos(a), math.sin(a)
        c = (0.335 * ca, by + 0.13, 0.335 * sa)
        P.lathe("brass", c, [(0.0, -0.02), (0.075, -0.02), (0.085, 0.0), (0.06, 0.02), (0.0, 0.025)],
                r=_yaxis_to((ca, -0.55, sa)), n=P.n(12, 6))
        P.sphere("coals", v_add(c, v_mul(v_norm((ca, -0.55, sa)), 0.03)), 0.026, n=P.n(8, 5))
    # chain swags with brass drops hanging from the rim
    for k in range(6):
        a0 = math.radians(60 * k + 15)
        path = [((0.40 + 0.02 * math.sin(math.pi * s)) * math.cos(a0 + math.radians(60) * s), by + 0.215 - 0.11 * math.sin(math.pi * s),
                 (0.40 + 0.02 * math.sin(math.pi * s)) * math.sin(a0 + math.radians(60) * s)) for s in [j / 8 for j in range(9)]]
        _chain(P, "brass", path, link=0.04, wire=0.0055)
        low = path[4]
        if P.lod < 3:
            P.lathe("brass", v_add(low, (0.0, -0.10, 0.0)), [(0.0, 0.0), (0.02, 0.025), (0.026, 0.05), (0.012, 0.085), (0.0, 0.095)],
                    n=P.n(8, 5))
            P.sweep("brass", [low, v_add(low, (0.0, -0.01, 0.0))], 0.004, sides=4)
    # flames: a tall central tongue with a ring of smaller ones leaning out of the coals
    fb = by + 0.24
    _flame(P, "hutt2_fire", (0.0, fb, 0.0), 0.50, 0.11, lean=(0.03, -0.02), n=P.n(10, 6))
    for k in range(7 if P.lod < 2 else 4):
        a = 2 * math.pi * k / (7 if P.lod < 2 else 4) + 0.5
        ca, sa = math.cos(a), math.sin(a)
        rr = 0.10 + 0.07 * (k % 2)
        h = 0.34 - 0.12 * (k % 2) - 0.03 * (k % 3)
        _flame(P, "hutt2_fire", (rr * ca, fb + 0.02 - 0.02 * (k % 2), rr * sa), h, 0.055 - 0.012 * (k % 2),
               lean=(0.06 * ca + 0.03 * sa, 0.06 * sa - 0.03 * ca), n=P.n(8, 5))
    light_hardpoint(P, (0.0, fb + 0.20, 0.0))


# ---------------------------------------------------------------------------------------------------------------
# hutt_carbonite_slab
# ---------------------------------------------------------------------------------------------------------------

def hutt_carbonite_slab(P):
    """A smuggler in carbonite (Jabba's favourite decoration): a 0.9 x 1.86 m slab with the figure in relief -
    head thrown back, hands raised - and blinking control panels on its sides, upright in a brass cradle on a
    carved wood and sandstone stand with back struts and an engraved plaque."""
    W, D = 0.45, 0.15
    y0, y1 = 0.31, 2.17
    ym = (y0 + y1) / 2
    car = "hutt2_carbonite"
    # -- stand
    P.prism("sandstone", _rrect(0.70, 0.42, 0.10, P.n(4, 2)), 0.0, 0.11, side_slot="frieze", side_vscale=0.11)
    P.box("wood", (0.0, 0.185, 0.0), (0.60, 0.075, 0.33), bottom=False)
    P.box("brass", (0.0, 0.118, 0.0), (0.608, 0.01, 0.338), bottom=False)
    P.box("brass", (0.0, 0.257, 0.0), (0.608, 0.008, 0.338), bottom=False)
    for sx in (-1, 1):
        for sz in (-1, 1):
            P.lathe("brass", (sx * 0.56, 0.265, sz * 0.29), [(0.0, 0.0), (0.045, 0.0), (0.03, 0.03), (0.04, 0.05), (0.0, 0.075)],
                    n=P.n(10, 5))
    P.box("brass", (0.0, 0.286, 0.0), (W + 0.05, 0.024, D + 0.05))                       # cradle
    P.box("brass", (0.0, 0.205, 0.336), (0.23, 0.045, 0.006), bottom=False)              # plaque
    P.decal("hutt2_plaque", (0.0, 0.205, 0.3435), 0.42, 0.075, (0, 0, 1))
    _studs(P, "brass", [(sx * 0.215, 0.205, 0.343) for sx in (-1, 1)], r=0.01)
    for sx in (-1, 1):
        x = sx * (W + 0.03)
        P.box("brass", (x, 0.56, 0.0), (0.02, 0.27, D + 0.03))                          # side clamps
        _studs(P, "brass", [(x + sx * 0.02, y, z) for y in (0.42, 0.70) for z in (-0.09, 0.09)], r=0.016, nrm=(sx, 0, 0))
        P.sweep("brass", [(sx * 0.28, 0.26, -0.30), (sx * 0.28, 1.35, -D - 0.012)], 0.022, sides=P.n(8, 4))
        P.box("brass", (sx * 0.28, 1.35, -D - 0.008), (0.055, 0.08, 0.008))
        P.lathe("brass", (sx * 0.28, 0.26, -0.30), [(0.0, 0.0), (0.05, 0.0), (0.035, 0.03), (0.0, 0.04)], n=P.n(10, 5))
        # a pair of tusks rising from brass cups at the front corners, framing the slab like a trophy
        P.lathe("brass", (sx * 0.60, 0.265, 0.24), [(0.0, 0.0), (0.07, 0.0), (0.065, 0.03), (0.05, 0.05), (0.058, 0.08), (0.0, 0.08)],
                n=P.n(12, 6))
        _tusk(P, [(sx * 0.60, 0.29, 0.24), (sx * 0.66, 0.55, 0.26), (sx * 0.68, 0.85, 0.22), (sx * 0.62, 1.10, 0.14),
                  (sx * 0.53, 1.24, 0.08)], 0.055, n=P.n(12, 5))
    # -- the slab, a raised border round the front, side control boxes with panels, top vents, back panelling
    P.rbox(car, (0.0, ym, 0.0), (W, (y1 - y0) / 2, D), 0.03, seg=P.n(3, 2))
    bw = 0.05
    for cx, cy, hx, hy in ((0.0, y1 - bw, W - 0.015, bw - 0.012), (0.0, y0 + bw, W - 0.015, bw - 0.012),
                           (-W + bw, ym, bw - 0.012, (y1 - y0) / 2 - 0.015), (W - bw, ym, bw - 0.012, (y1 - y0) / 2 - 0.015)):
        P.box(car, (cx, cy, D + 0.008), (hx, hy, 0.012), bottom=False)
    for sx in (-1, 1):
        P.box(car, (sx * (W + 0.028), 1.72, 0.0), (0.03, 0.24, 0.085))
        P.decal("hutt2_panel", (sx * (W + 0.0585), 1.72, 0.0), 0.13, 0.40, (sx, 0, 0))
        P.box(car, (sx * (W + 0.024), 0.98, 0.0), (0.026, 0.12, 0.07))
        P.decal("hutt2_panel", (sx * (W + 0.0505), 0.98, 0.0), 0.11, 0.20, (sx, 0, 0))
        for y in (1.45, 1.30, 1.15):
            P.box(car, (sx * (W + 0.008), y, 0.0), (0.012, 0.025, D - 0.02), bottom=True)
    for sx in (-1, 1):
        P.box(car, (sx * 0.22, y1 + 0.03, 0.0), (0.12, 0.03, 0.08), bottom=False)
        if P.lod < 2:
            for k in range(4):
                P.box(car, (sx * 0.22 - 0.075 + 0.05 * k, y1 + 0.062, 0.0), (0.012, 0.004, 0.065), bottom=False)
    P.box(car, (0.0, ym + 0.1, -D - 0.008), (W - 0.09, 0.62, 0.01), bottom=False)
    if P.lod < 2:
        _studs(P, car, [(sx * (W - 0.12), ym + 0.1 + sy * 0.56, -D - 0.018) for sx in (-1, 1) for sy in (-1, 0, 1)], r=0.02,
               nrm=(0, 0, -1))
    # -- the figure in relief on the front face (z = D): head thrown back, his right hand up and out, his left
    #    hand raised beside his face, legs braced; every part half sunk into the slab
    z0 = D
    _ellipsoid(P, car, (0.0, 1.33, z0), (0.20, 0.27, 0.058))                          # torso
    _ellipsoid(P, car, (0.0, 1.50, z0), (0.235, 0.12, 0.056))                         # chest and shoulders
    _ellipsoid(P, car, (0.0, 1.08, z0), (0.17, 0.10, 0.05))                           # hips
    P.sweep(car, [(-0.165, 1.12, z0 + 0.038), (0.165, 1.12, z0 + 0.038)], 0.016, sides=P.n(6, 4))   # belt
    P.box(car, (-0.155, 1.02, z0 + 0.044), (0.032, 0.075, 0.018), r=(0, 0, -6))                   # holster
    for sx in (-1, 1):
        P.sweep(car, [(sx * 0.06, 1.60, z0 + 0.044), (sx * 0.095, 1.40, z0 + 0.054), (sx * 0.09, 1.17, z0 + 0.046)], 0.011, sides=4)
        P.sweep(car, [(sx * 0.085, 1.04, z0 + 0.012), (sx * 0.10, 0.76, z0 + 0.026)], lambda t: 0.072 - 0.008 * t, sides=P.n(10, 5))
        _ellipsoid(P, car, (sx * 0.102, 0.75, z0 + 0.03), (0.062, 0.06, 0.06))                # knee
        P.sweep(car, [(sx * 0.10, 0.75, z0 + 0.026), (sx * 0.11, 0.47, z0 + 0.016)], lambda t: 0.062 - 0.012 * t, sides=P.n(10, 5))
        _ellipsoid(P, car, (sx * 0.112, 0.435, z0 + 0.035), (0.058, 0.05, 0.072))         # boots
    P.sweep(car, [(0.0, 1.58, z0 + 0.01), (0.0, 1.67, z0 + 0.022)], 0.052, sides=P.n(8, 4))           # neck
    hc = (0.0, 1.765, z0 + 0.008)
    _ellipsoid(P, car, v_add(hc, (0.0, 0.045, -0.025)), (0.095, 0.085, 0.06))         # hair, behind the brow
    _ellipsoid(P, car, hc, (0.082, 0.105, 0.068), r=(-26, 0, 0))                      # face, thrown back
    if P.lod < 3:
        P.cone(car, v_add(hc, (0.0, 0.0, 0.06)), v_add(hc, (0.0, -0.012, 0.098)), 0.019, n=P.n(6, 4))   # nose
        _ellipsoid(P, car, v_add(hc, (0.0, -0.085, 0.045)), (0.038, 0.026, 0.026))   # chin
    if P.lod < 2:
        for sx in (-1, 1):
            P.sweep(car, [v_add(hc, (sx * 0.012, 0.035, 0.064)), v_add(hc, (sx * 0.055, 0.03, 0.052))], 0.009, sides=4)  # brows
            P.sweep(car, [v_add(hc, (sx * 0.005, -0.048, 0.066)), v_add(hc, (sx * 0.03, -0.042, 0.058))], 0.006, sides=4)  # lips
    for sx, (sh, el, wr) in ((-1, ((-0.20, 1.53, z0 + 0.008), (-0.35, 1.38, z0 + 0.02), (-0.33, 1.62, z0 + 0.03))),
                             (1, ((0.20, 1.53, z0 + 0.008), (0.31, 1.43, z0 + 0.02), (0.185, 1.72, z0 + 0.034)))):
        P.sweep(car, [sh, el], lambda t: 0.05 - 0.006 * t, sides=P.n(8, 4))
        _ellipsoid(P, car, el, (0.046, 0.046, 0.044))                                  # elbow
        P.sweep(car, [el, wr], lambda t: 0.044 - 0.01 * t, sides=P.n(8, 4))
        hand = v_add(wr, (0.0, 0.04, 0.008))
        _ellipsoid(P, car, hand, (0.044, 0.056, 0.024), r=(0, 0, -sx * 10))
        if P.lod < 2:                                                          # splayed fingers, thumb out
            for k, dx in enumerate((-0.03, -0.01, 0.01, 0.03)):
                P.sweep(car, [v_add(hand, (dx, 0.035, 0.012)), v_add(hand, (dx * 1.4, 0.095 - 0.012 * abs(k - 1.5), 0.018))], 0.0095,
                        sides=4)
            P.sweep(car, [v_add(hand, (-sx * 0.03, -0.012, 0.012)), v_add(hand, (-sx * 0.075, 0.02, 0.018))], 0.01, sides=4)
    if P.lod < 2:                                                    # low melt ridges round the figure
        for c, rad in (((0.0, 1.95, z0), (0.16, 0.06, 0.022)), ((-0.33, 1.73, z0), (0.07, 0.09, 0.02)),
                       ((0.24, 1.86, z0), (0.07, 0.07, 0.018)), ((0.0, 0.62, z0 - 0.01), (0.22, 0.28, 0.028))):
            _ellipsoid(P, car, c, rad)


# ---------------------------------------------------------------------------------------------------------------
# hutt_rancor_skull
# ---------------------------------------------------------------------------------------------------------------

SKULL_HINGE = (0.0, 0.98, -0.30)
SKULL_TILT = -13.0                     # degrees about x: the cranium tipped up on the jaw hinge, jaws agape


def _skull_dims(t):
    """Cranium cross-section at length t (0 back .. 1 snout): half width, base y, top y, end rounding."""
    w = 0.37 + 0.09 * math.exp(-((t - 0.40) / 0.12) ** 2) - 0.13 * smoothstep(0.50, 1.0, t)
    top = (0.94 + 0.26 + 0.12 * math.exp(-((t - 0.20) / 0.22) ** 2) + 0.03 * math.exp(-((t - 0.40) / 0.06) ** 2)
           - 0.11 * smoothstep(0.45, 1.0, t))
    bot = 0.94 - 0.10 * (1 - smoothstep(0.0, 0.35, t)) - 0.02
    rb = math.sqrt(max(0.0, 1 - ((0.16 - t) / 0.16) ** 2)) if t < 0.16 else 1.0
    rf = math.sqrt(max(0.0, 1 - ((t - 0.90) / 0.10) ** 2)) if t > 0.90 else 1.0
    return w, bot, top, max(0.10, rb) * max(0.14, rf)


def _skull_pt(t, th):
    """Cranium surface point (untilted) at t and angle th (degrees; 0 = +x, 90 = up, 270 = down)."""
    w, bot, top, k = _skull_dims(t)
    ym = bot + 0.36 * (top - bot)
    c, s = math.cos(math.radians(th)), math.sin(math.radians(th))
    if s >= 0:
        x = w * math.copysign(abs(c) ** 0.8, c)
        y = ym + (top - ym) * s ** 0.85
    else:                                                # boxy underside: flat palate, square jaw corners
        x = w * math.copysign(abs(c) ** 0.35, c)
        y = ym - (ym - bot) * abs(s) ** 0.35
    return (k * x, ym + k * (y - ym), -0.60 + 1.30 * t)


def _skull_normal(t, th):
    p = _skull_pt(t, th)
    du = v_sub(_skull_pt(t, th + 2.0), _skull_pt(t, th - 2.0))
    dv = v_sub(_skull_pt(min(1.0, t + 0.01), th), _skull_pt(max(0.0, t - 0.01), th))
    n = v_norm(v_cross(dv, du))
    w, bot, top, _ = _skull_dims(t)
    cen = (0.0, bot + 0.36 * (top - bot), p[2])
    return n if sum(n[i] * (p[i] - cen[i]) for i in range(3)) > 0 else v_mul(n, -1.0)


def _cranium(P, slot, holes):
    """The cranium loft, leaving out the quads inside the hole spheres (eye sockets, nostrils)."""
    nt, na = P.n(34, 10), P.n(36, 12)
    ts = [k / nt for k in range(nt + 1)]
    rings = [[_skull_pt(t, 360.0 * j / na) for j in range(na)] for t in ts]
    s = _fu.UV.get(slot, 1.0)
    cents = [tuple(sum(p[i] for p in rg) / na for i in range(3)) for rg in rings]
    L = [0.0]
    for k in range(1, len(rings)):
        L.append(L[-1] + v_len(v_sub(cents[k], cents[k - 1])))
    du = 2.4 / na / s
    for k in range(len(rings) - 1):
        mid = v_mul(v_add(cents[k], cents[k + 1]), 0.5)
        for j in range(na):
            j1 = (j + 1) % na
            q = [rings[k][j], rings[k][j1], rings[k + 1][j1], rings[k + 1][j]]
            c = tuple(sum(p[i] for p in q) / 4 for i in range(3))
            if any(v_len(v_sub(c, hc)) < hr - 0.006 for hc, hr in holes):
                continue
            uv = [(j * du, L[k] / s), ((j + 1) * du, L[k] / s), ((j + 1) * du, L[k + 1] / s), (j * du, L[k + 1] / s)]
            P.poly(slot, q, uv, v_sub(c, mid))
    P.flat(slot, rings[0], v_sub(cents[0], cents[1]))
    P.flat(slot, rings[-1], v_sub(cents[-1], cents[-2]))


def hutt_rancor_skull(P):
    """Giant rancor skull trophy, 1.3 m long, jaws agape (the cranium tipped up on the jaw hinge): deep eye sockets
    under heavy brows, tusk-like fangs, a sagittal crest, on a carved sandstone plinth with a silk runner and a
    brass plaque."""
    # -- plinth
    P.prism("sandstone", _rrect(0.64, 0.54, 0.08, P.n(4, 2)), 0.0, 0.10, side_slot="frieze", side_vscale=0.10)
    P.prism("sandstone", _rrect(0.56, 0.46, 0.06, P.n(4, 2)), 0.10, 0.18)
    bot_r, top_r = _rrect(0.44, 0.36, 0.05, P.n(3, 2)), _rrect(0.40, 0.32, 0.05, P.n(3, 2))
    P.loft("sandstone", [[(x, 0.18, z) for x, z in bot_r], [(x, 0.50, z) for x, z in top_r]], caps=(False, False), vscale=1.2)
    P.prism("sandstone", _rrect(0.43, 0.35, 0.05, P.n(3, 2)), 0.50, 0.60, side_slot="frieze", side_vscale=0.10)
    P.prism("sandstone", _rrect(0.52, 0.44, 0.06, P.n(4, 2)), 0.60, 0.70, bottom=True)
    for y, (hx, hz, rr, w) in ((0.70, (0.525, 0.445, 0.06, 0.012)), (0.60, (0.435, 0.355, 0.05, 0.01))):
        P.sweep("brass", _densify([(x, y, z) for x, z in _rrect(hx, hz, rr, P.n(4, 2))], lod=P.lod), w, closed=True, sides=P.n(6, 4))
    P.box("brass", (0.0, 0.34, 0.345), (0.20, 0.075, 0.006), r=(-7.1, 0, 0))
    P.decal("hutt2_plaque", (0.0, 0.34, 0.352), 0.37, 0.12, (0, 0.124, 0.992))
    _studs(P, "brass", [(sx * 0.18, 0.34, 0.351) for sx in (-1, 1)], r=0.012, nrm=(0, 0.124, 0.992))
    # silk runner over the top, hanging down the front with tassels
    if P.lod < 3:
        P.box("silk", (0.0, 0.703, 0.0), (0.16, 0.003, 0.445), bottom=False)
        P.box("silk", (0.0, 0.62, 0.448), (0.16, 0.083, 0.003), bottom=False)
        for sx in (-1, 1):
            _tassel(P, (sx * 0.13, 0.535, 0.452), 0.10)
    # -- lower jaw resting on the plinth: a U-shaped mandible with up-curving fangs and teeth
    jaw = []
    for t in [0.24 + 0.67 * k / 9 for k in range(10)]:
        w, bot, top, kk = _skull_dims(t)
        jaw.append((0.88 * w * kk - 0.03, -0.60 + 1.30 * t))
    left = [(-x, 0.785, z) for x, z in jaw]
    tip = jaw[-1]
    chin = [(tip[0] * math.cos(math.radians(a)), 0.785, tip[1] + 0.05 * math.sin(math.radians(a))) for a in (150, 120, 90, 60, 30)]
    path = [(-jaw[0][0] + 0.01, 1.02, jaw[0][1] - 0.04), (-jaw[0][0], 0.90, jaw[0][1])] + left[1:] + chin + \
           [(-x, y, z) for x, y, z in reversed(left[1:])] + [(jaw[0][0], 0.90, jaw[0][1]), (jaw[0][0] - 0.01, 1.02, jaw[0][1] - 0.04)]
    prof = [(math.copysign(abs(math.cos(a)) ** 0.5, math.cos(a)), 0.55 * math.copysign(abs(math.sin(a)) ** 0.5, math.sin(a)))
            for a in [2 * math.pi * k / P.n(10, 6) for k in range(P.n(10, 6))]]
    P.sweep("bone", path, 0.085, profile=prof, vscale=0.3)
    for side in (-1, 1):
        for k, t in enumerate([0.46, 0.53, 0.60, 0.67, 0.74, 0.80]):
            w, bot, top, kk = _skull_dims(t)
            x, z = side * (0.88 * w * kk - 0.03), -0.60 + 1.30 * t
            ln = 0.07 + 0.03 * (k % 2)
            P.cone("bone", (x, 0.86, z), (x * 0.97, 0.86 + ln, z + 0.01), 0.022, n=P.n(6, 4))
        w, bot, top, kk = _skull_dims(0.88)
        x, z = side * (0.88 * w * kk - 0.03), -0.60 + 1.30 * 0.88
        _tusk(P, [(x, 0.84, z), (x * 1.05, 0.95, z + 0.01), (x * 1.12, 1.06, z - 0.01), (x * 1.08, 1.13, z - 0.04)], 0.034, n=P.n(8, 4))
    # -- cranium, tipped up on the hinge: loft with eye sockets and nostrils cut through, brows, crest, fangs
    socks = [(0.40, 36.0, 0.105), (0.40, 144.0, 0.105)]
    nost = [(0.94, 64.0, 0.04), (0.94, 116.0, 0.04)]
    cut = P.lod < 2                                             # the coarse far LODs plug the sockets instead
    holes = [(_skull_pt(t, th), r) for t, th, r in socks] if cut else []
    with _tx(P, r=(SKULL_TILT, 0, 0), pivot=SKULL_HINGE):
        _cranium(P, "bone", holes)
        for t, th, r in socks + nost:
            hc, nrm = _skull_pt(t, th), _skull_normal(t, th)
            if r > 0.05 and cut:                                    # eye socket: a dark cup under the cut hole
                with _tx(P, v_sub(hc, v_mul(nrm, 0.006)), _yaxis_to(nrm), (r, 0.13, r)):
                    P.sphere("hutt2_socket", (0.0, 0.0, 0.0), 1.0, lat0=-90, lat1=0, inside=True, n=P.n(12, 6))
            else:                                                   # nostril (or far-LOD socket): a dark plug in its rim
                _ellipsoid(P, "hutt2_socket", hc, (r * 0.95, 0.016, r * 0.95), r=_yaxis_to(nrm), n=P.n(10, 6), rows=4)
            # a bone rim hugging the cranium round the hole: covers the cut edge and the cup's lip
            st = v_len(v_sub(_skull_pt(t + 0.01, th), _skull_pt(t - 0.01, th))) / 0.02
            sth = v_len(v_sub(_skull_pt(t, th + 1.0), _skull_pt(t, th - 1.0))) / 2.0
            rim = [_skull_pt(t + r * math.cos(2 * math.pi * j / 14) / st, th + r * math.sin(2 * math.pi * j / 14) / sth) for j in range(14)]
            P.sweep("bone", rim, 0.034 if r > 0.05 else 0.016, closed=True, sides=P.n(6, 4))
        for th in (38.0, 142.0):                                    # heavy brow ridges over the sockets
            sgn = 1 if th < 90 else -1
            brow = [v_add(_skull_pt(t, th + sgn * d), v_mul(_skull_normal(t, th + sgn * d), 0.025)) for t, d in
                    ((0.31, 16.0), (0.35, 27.0), (0.41, 30.0), (0.47, 24.0), (0.51, 10.0))]
            P.sweep("bone", brow, lambda u: 0.026 + 0.03 * math.sin(math.pi * u), sides=P.n(8, 4))
        for th in (-4.0, 184.0):                                    # cheekbones
            cheek = [v_add(_skull_pt(t, th), v_mul(_skull_normal(t, th), 0.012)) for t in (0.24, 0.33, 0.43, 0.53, 0.60)]
            P.sweep("bone", cheek, lambda u: 0.024 + 0.018 * math.sin(math.pi * u), sides=P.n(8, 4))
        crest = [v_add(_skull_pt(t, 90.0), (0.0, -0.01, 0.0)) for t in (0.04, 0.12, 0.22, 0.32, 0.42, 0.50)]
        P.sweep("bone", crest, lambda u: 0.04 * math.sin(math.pi * min(1.0, u * 1.15)) + 0.006, sides=P.n(8, 4),
                profile=[(math.cos(a), 0.35 * math.sin(a)) for a in [2 * math.pi * k / 8 for k in range(8)]])
        for th in (55.0, 125.0):                                    # stubby horns at the back of the skull
            b = _skull_pt(0.12, th)
            nrm = _skull_normal(0.12, th)
            P.cone("bone", v_sub(b, v_mul(nrm, 0.02)), v_add(b, v_add(v_mul(nrm, 0.13), (0.0, 0.0, -0.08))), 0.05, n=P.n(8, 5))
        # upper teeth along the palate corners, a pair of great fangs near the front
        for th in (227.0, 313.0):
            for k, t in enumerate([0.47, 0.54, 0.61, 0.68, 0.75, 0.82, 0.93]):
                b = _skull_pt(t, th)
                ln = 0.08 + 0.03 * (k % 2)
                P.cone("bone", v_add(b, (0.0, 0.02, 0.0)), (b[0] * 0.95, b[1] - ln, b[2] + 0.01), 0.023, n=P.n(6, 4))
            b = _skull_pt(0.87, th)
            _tusk(P, [v_add(b, (0.0, 0.03, 0.0)), (b[0] * 1.02, b[1] - 0.12, b[2] + 0.03), (b[0] * 0.95, b[1] - 0.24, b[2] + 0.01),
                      (b[0] * 0.85, b[1] - 0.30, b[2] - 0.03)], 0.04, n=P.n(8, 4))


# ---------------------------------------------------------------------------------------------------------------
# hutt_treasure_chest
# ---------------------------------------------------------------------------------------------------------------

CHEST_RIM = 0.50


def _heap_h(x, z):
    """Height of the hoard inside the chest: a mound peaking ~0.2 m over the rim, edges tucked under it."""
    bx = max(0.0, 1.0 - (x / 0.425) ** 2)
    bz = max(0.0, 1.0 - (z / 0.235) ** 2)
    b = (bx * bz) ** 0.55
    lump = (0.05 * math.exp(-((x + 0.14) ** 2 + (z - 0.03) ** 2) / 0.012) + 0.035 * math.exp(-((x - 0.21) ** 2 + (z + 0.05) ** 2) / 0.008)
            + 0.025 * math.exp(-((x - 0.02) ** 2 + (z + 0.12) ** 2) / 0.006))
    return CHEST_RIM - 0.008 + (0.15 + lump) * b


def _gold_bar(P, c, r=(0.0, 0.0, 0.0)):
    lo = [(-0.075, 0.0, -0.03), (0.075, 0.0, -0.03), (0.075, 0.0, 0.03), (-0.075, 0.0, 0.03)]
    hi = [(-0.062, 0.034, -0.022), (0.062, 0.034, -0.022), (0.062, 0.034, 0.022), (-0.062, 0.034, 0.022)]
    with _tx(P, c, r):
        P.loft("hutt2_gold", [lo, hi], closed=True, caps=(True, True), vscale=0.3)


def _gem(P, slot, c, rad, r=(0.0, 0.0, 0.0)):
    """A brilliant-cut gem: a shallow crown with a table over a deep pavilion."""
    n = P.n(8, 5)
    with _tx(P, c, r):
        P.cone(slot, (0.0, 0.0, 0.0), (0.0, -rad * 1.1, 0.0), rad, n=n)
        P.lathe(slot, (0.0, 0.0, 0.0), [(rad, 0.0), (rad * 0.62, rad * 0.45), (0.0, rad * 0.45)], n=n)


def _coin(P, c, r=(0.0, 0.0, 0.0), rad=0.014):
    P.lathe("hutt2_gold", c, [(0.0, 0.0), (rad, 0.0), (rad, 0.003), (0.0, 0.003)], n=P.n(10, 6), r=r)


def hutt_treasure_chest(P):
    """An open treasure chest (0.92 x 0.54 m, rim 0.50) overflowing with peggats, gold bars, gems and credit
    chips, a jewelled crown and a pearl rope; carved wood, brass banding, a velvet-lined barrel lid thrown open,
    a sprung padlock, coins spilling onto the floor."""
    W, D, t = 0.46, 0.27, 0.035
    y0, y1 = 0.075, CHEST_RIM
    yc, hy = (y0 + y1) / 2, (y1 - y0) / 2
    # -- feet, walls, inner floor
    for sx in (-1, 1):
        for sz in (-1, 1):
            P.lathe("brass", (sx * (W - 0.05), 0.0, sz * (D - 0.05)), [(0.0, 0.0), (0.035, 0.0), (0.05, 0.03), (0.045, 0.06),
                                                                      (0.03, y0 + 0.004), (0.0, y0 + 0.004)], n=P.n(10, 6))
    for sz in (-1, 1):
        P.box("wood", (0.0, yc, sz * (D - t / 2)), (W, hy, t / 2))
    for sx in (-1, 1):
        P.box("wood", (sx * (W - t / 2), yc, 0.0), (t / 2, hy, D - t))
    P.box("wood", (0.0, y0 + 0.015, 0.0), (W - t, 0.015, D - t), top=False)
    # -- brass: bands, rim cap, straps, corner guards, studs, the hasp and a sprung padlock
    for y in (y0 + 0.03, y1 - 0.035):
        P.box("brass", (0.0, y, 0.0), (W + 0.005, 0.018, D + 0.005), top=False, bottom=False)
    for sz in (-1, 1):
        P.box("brass", (0.0, y1 + 0.005, sz * (D - t / 2)), (W + 0.006, 0.005, t / 2 + 0.006))
    for sx in (-1, 1):
        P.box("brass", (sx * (W - t / 2), y1 + 0.005, 0.0), (t / 2 + 0.006, 0.005, D - t))
        for sz in (-1, 1):
            P.box("brass", (sx * 0.24, yc, sz * (D + 0.004)), (0.022, hy, 0.006), bottom=False)
            P.box("brass", (sx * W, yc, sz * D), (0.016, hy + 0.004, 0.016))
    _studs(P, "brass", [(x * 0.1, y, D + 0.005) for x in (-3.4, -1.4, 1.4, 3.4) for y in (y0 + 0.03, y1 - 0.035)], r=0.012)
    P.box("brass", (0.0, y1 - 0.075, D + 0.008), (0.065, 0.07, 0.006), bottom=False)
    P.box("hutt2_socket", (0.0, y1 - 0.09, D + 0.0145), (0.008, 0.02, 0.001), bottom=False)
    with _tx(P, (0.0, y1 - 0.20, D + 0.03), (0, 0, 14)):
        P.box("brass", (0.0, 0.0, 0.0), (0.045, 0.045, 0.016))
        P.box("hutt2_socket", (0.0, -0.01, 0.0165), (0.006, 0.014, 0.001), bottom=False)
        P.sweep("brass", [(0.028, 0.045, 0.0), (0.028, 0.07, 0.0), (0.0, 0.10, 0.0), (-0.028, 0.08, 0.0), (-0.05, 0.10, 0.0)], 0.007,
                sides=P.n(6, 4))
    # -- the lid: barrel-topped, velvet lined, thrown open on its back hinge, brass bands, the sigil inside
    piv = (0.0, y1, -D)
    Ro, Ri = D, D - 0.022
    with _tx(P, r=(-108.0, 0, 0), pivot=piv):
        n = P.n(14, 6)
        arc_ = [math.pi * i / n for i in range(n + 1)]
        outer = [[(x, y1 + Ro * math.sin(a), Ro * math.cos(a)) for x in (-W, W)] for a in arc_]
        inner = [[(x, y1 + Ri * math.sin(a), Ri * math.cos(a)) for x in (-W + 0.022, W - 0.022)] for a in arc_]
        U = [[Ro * a / 0.8] * 2 for a in arc_]
        V = [[-W / 0.8, W / 0.8] for _ in arc_]
        P.grid("wood", outer, U, V, lambda q: (0.0, q[1] - y1, q[2]))
        P.grid("velvet", inner, U, V, lambda q: (0.0, y1 - q[1], -q[2]))
        for sgn in (1, -1):
            P.flat("wood", [(sgn * W, y1 + Ro * math.sin(a), Ro * math.cos(a)) for a in arc_], (sgn, 0, 0))
            P.flat("wood", [(sgn * (W - 0.022), y1 + Ri * math.sin(a), Ri * math.cos(a)) for a in arc_], (-sgn, 0, 0))
            P.flat("wood", [(sgn * (W - 0.022), y1, -Ro), (sgn * W, y1, -Ro), (sgn * W, y1, Ro), (sgn * (W - 0.022), y1, Ro)], (0, -1, 0))
            P.flat("wood", [(-W, y1, sgn * Ri), (W, y1, sgn * Ri), (W, y1, sgn * Ro), (-W, y1, sgn * Ro)], (0, -1, 0))
        for x in (-W + 0.008, -0.24, 0.24, W - 0.008):
            P.sweep("brass", [(x, y1 + (Ro + 0.004) * math.sin(a), (Ro + 0.004) * math.cos(a)) for a in arc_], 0.011, sides=P.n(6, 4))
        P.sweep("brass", _densify([(-W, y1 + 0.006, Ro + 0.002), (W, y1 + 0.006, Ro + 0.002)], 0.1, closed=False, lod=P.lod), 0.011,
                sides=P.n(6, 4))
        P.disc("hutt2_sigil", (0.0, y1 + Ri - 0.003, 0.0), 0.0, 0.09, fit=True, n=P.n(20, 8), r=(180, 0, 0))
        P.lathe("brass", (0.0, y1 + Ri, 0.0), [(0.09, -0.001), (0.09, -0.011), (0.104, -0.011), (0.104, -0.001)], n=P.n(20, 8))
    # -- the hoard: a mound of peggats inside, bars, gems, chips, a crown and a goblet on it
    Wi, Di = W - t, D - t
    nx, nz = P.n(16, 6), P.n(9, 4)
    xs = [-Wi + 2 * Wi * i / nx for i in range(nx + 1)]
    zs = [-Di + 2 * Di * j / nz for j in range(nz + 1)]
    G = [[(x, _heap_h(x, z), z) for z in zs] for x in xs]
    P.grid("hutt2_coins", G, [[x / 0.25] * len(zs) for x in xs], [[z / 0.25 for z in zs] for _ in xs], lambda q: (0.0, 1.0, 0.0))
    on = lambda x, z, lift=0.0: (x, _heap_h(x, z) + lift, z)
    for x, z, yaw, tilt in ((-0.24, 0.07, 20, 10), (0.10, -0.07, -35, -9), (0.27, 0.10, 70, 8)):
        _gold_bar(P, on(x, z, -0.012), (tilt, yaw, 0))
    _gem(P, "hutt2_gem_r", on(-0.12, 0.03, 0.035), 0.05, (8, 0, 14))                   # the Hutt's Eye
    for k, (x, z, r, slot) in enumerate(((0.05, 0.12, 0.028, "hutt2_gem_g"), (-0.32, -0.08, 0.025, "hutt2_gem_b"),
                                         (0.20, -0.10, 0.026, "hutt2_gem_r"), (0.33, -0.02, 0.022, "hutt2_gem_g"),
                                         (-0.02, -0.15, 0.024, "hutt2_gem_b"), (-0.30, 0.14, 0.022, "hutt2_gem_r"))):
        if P.lod < 2 or k < 3:
            _gem(P, slot, on(x, z, r * 0.6), r, (20 * (k % 3) - 15, 40 * k, 25 - 10 * k))
    if P.lod < 2:
        for k, (x, z, yaw) in enumerate(((-0.05, 0.16, 30), (0.16, 0.02, -50), (-0.36, 0.02, 80), (0.30, -0.14, 10), (-0.18, -0.12, 60))):
            P.box("hutt2_chip", on(x, z, 0.004), (0.032, 0.0025, 0.02), r=(6 * (k - 2), yaw, 8 - 4 * k), fit=True)
        for k in range(6):                                         # a stack of chips
            P.box("hutt2_chip", on(0.17, 0.14, 0.003 + 0.0055 * k), (0.032, 0.0025, 0.02), r=(0, 12 * k, 0), fit=True)
    # crown on the summit
    cc = on(-0.02, 0.0, -0.01)
    with _tx(P, cc, (-12, 25, 8)):
        P.lathe("brass", (0.0, 0.0, 0.0), [(0.075, 0.0), (0.08, 0.01), (0.08, 0.04), (0.074, 0.045)], n=P.n(16, 8))
        P.lathe("velvet", (0.0, 0.0, 0.0), [(0.073, 0.044), (0.06, 0.07), (0.0, 0.09)], n=P.n(12, 6))
        for k in range(8):
            a = 2 * math.pi * k / 8
            base = (0.077 * math.cos(a), 0.04, 0.077 * math.sin(a))
            P.cone("brass", base, (0.085 * math.cos(a), 0.10, 0.085 * math.sin(a)), 0.016, n=P.n(5, 3))
            if P.lod < 2:
                P.sphere("bone", (0.086 * math.cos(a), 0.104, 0.086 * math.sin(a)), 0.009, n=5)
        if P.lod < 2:
            for k in range(4):
                a = 2 * math.pi * k / 4 + 0.4
                P.sphere(("hutt2_gem_r", "hutt2_gem_g", "hutt2_gem_b", "hutt2_gem_g")[k], (0.082 * math.cos(a), 0.025, 0.082 * math.sin(a)),
                         0.012, n=6)
        P.sphere("hutt2_gem_r", (0.0, 0.095, 0.0), 0.014, n=6)
    # a goblet tipped over on the heap
    gc = on(0.30, 0.05, 0.03)
    P.lathe("brass", gc, [(0.0, -0.07), (0.035, -0.07), (0.012, -0.055), (0.01, -0.01), (0.04, 0.02), (0.045, 0.07), (0.038, 0.07),
                          (0.0, 0.03)], r=(0, 0, 70), n=P.n(10, 6))
    # pearl rope draped over the front rim
    if P.lod < 2:
        rope = _spline([on(-0.34, 0.12, 0.01), (-0.33, y1 + 0.014, D + 0.012), (-0.27, 0.40, D + 0.02), (-0.16, 0.33, D + 0.02),
                        (-0.06, 0.38, D + 0.02), (-0.03, y1 + 0.014, D + 0.012), on(-0.04, 0.13, 0.01)], 30)
        for p in rope:
            P.sphere("bone", p, 0.011, n=5)
    # -- spill: coins down the front corner into a floor pile, a bar and a stack on the floor
    _mound(P, "hutt2_coins", (-0.30, 0.0, D + 0.17), 0.21, 0.065)
    _mound(P, "hutt2_coins", (-0.40, 0.0, D + 0.04), 0.10, 0.10, rings=P.n(3, 2), n=P.n(12, 6))
    for k, (x, y, z, r) in enumerate(((-0.42, 0.30, D + 0.012, (80, 0, 10)), (-0.36, 0.18, D + 0.015, (75, 20, -15)),
                                      (-0.12, 0.012, D + 0.16, (8, 0, 12)), (-0.05, 0.004, D + 0.24, (0, 0, 0)),
                                      (-0.52, 0.004, D + 0.12, (0, 0, 0)), (-0.18, 0.04, D + 0.34, (40, 0, 70)))):
        if P.lod < 2 or k < 2:
            _coin(P, (x, y, z), r)
    _gold_bar(P, (0.30, 0.0, D + 0.13), (0, 18, 0))
    _gold_bar(P, (0.31, 0.034, D + 0.13), (0, 8, 0))
    _gold_bar(P, (0.14, 0.0, D + 0.24), (0, -28, 0))
    if P.lod < 2:
        _gem(P, "hutt2_gem_b", (-0.30, 0.09, D + 0.17), 0.025, (10, 30, 0))
        _gem(P, "hutt2_gem_r", (0.02, 0.022, D + 0.30), 0.022, (0, 0, 65))


PIECES = {
    "hutt_gong": (hutt_gong, "interact"),
    "hutt_rancor_chaise": (hutt_rancor_chaise, "seat"),
    "hutt_brazier": (hutt_brazier, "lamp"),
    "hutt_carbonite_slab": (hutt_carbonite_slab, "decor"),
    "hutt_rancor_skull": (hutt_rancor_skull, "decor"),
    "hutt_treasure_chest": (hutt_treasure_chest, "decor"),
}
SLOTS = {"hutt": {"hutt2_bronze": "hutt2_bronze", "hutt2_gong": "hutt2_gong", "hutt2_sigil": "hutt2_sigil",
                  "hutt2_hide": "hutt2_hide", "hutt2_fire": "hutt2_fire", "hutt2_carbonite": "hutt2_carbonite",
                  "hutt2_panel": "hutt2_carbon_panel", "hutt2_plaque": "hutt2_plaque", "hutt2_coins": "hutt2_coins",
                  "hutt2_gold": "hutt2_gold", "hutt2_gem_r": "hutt2_gem_ruby", "hutt2_gem_g": "hutt2_gem_emerald",
                  "hutt2_gem_b": "hutt2_gem_sapphire", "hutt2_chip": "hutt2_credit_chip", "hutt2_socket": "hutt2_socket"}}
UV = {"hutt2_bronze": 0.35, "hutt2_gong": 1.0, "hutt2_sigil": 1.0, "hutt2_hide": 0.5, "hutt2_fire": 1.0,
      "hutt2_carbonite": 0.7, "hutt2_panel": 1.0, "hutt2_plaque": 1.0, "hutt2_coins": 0.25, "hutt2_gold": 0.3,
      "hutt2_gem_r": 0.1, "hutt2_gem_g": 0.1, "hutt2_gem_b": 0.1, "hutt2_chip": 1.0, "hutt2_socket": 0.4}
SMOOTH = ("hutt2_bronze", "hutt2_hide", "hutt2_fire", "hutt2_carbonite", "hutt2_coins", "hutt2_socket")
COLORS = {}
