"""Galactic Empire, second wave (pieces imp_*; they reuse furniture.py's SLOTS["imp"] so they match the first set):

  imp_interrogation_rig   interact  IT-O interrogation rig: a tilted restraint table on a hydraulic pedestal, the
                                    IT-O droid hanging from an articulated arm over the prisoner, and the operator's
                                    standing console with its red readout (station `console`, the player works it)
  imp_emperor_throne      seat      the Emperor's black swivel throne: angular control arms, a high back, on a
                                    round stepped dais cut straight at the front (the feet stay on the floor)
  imp_light_pillar        lamp      Death Star corridor light pillar: black octagonal column, white light panels
                                    between grey blade fins, stepped capital and plinth; cool white light
  imp_probe_droid         decor     Viper probe droid on a display stand: dome head, sensor eyes, antennae,
                                    dangling manipulator legs, a chrome support arm clamped to its back
  imp_weapon_rack         decor     armoury rack: four E-11 blaster rifles, a stormtrooper helmet and thermal
                                    detonators on the shelf, the crest on the back panel
  imp_cargo_crates        decor     stacked Imperial cargo containers with crest stencils, handles and status
                                    lights, a fuel canister and a field case

Maya space, metres: y up, the piece stands on the origin (lowest point y = 0), its front faces +z."""
from __future__ import annotations

import math

from ..furniture import (UV as _UV, arc, light_hardpoint, rot, seat_hardpoint, station_hardpoints, v_add, v_cross,
                         v_dot, v_len, v_mul, v_norm, v_sub, xf)


# ---------------------------------------------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------------------------------------------

def _uvs(slot):
    return _UV.get(slot.split(":")[0], 1.0)


def _frame(origin, fwd, up=(0.0, 1.0, 0.0)):
    """Point transform: local x right, y up, z = fwd, placed at origin."""
    f = v_norm(fwd)
    if abs(v_dot(f, v_norm(up))) > 0.98:
        up = (1.0, 0.0, 0.0) if abs(f[0]) < 0.9 else (0.0, 0.0, 1.0)
    r = v_norm(v_cross(up, f))
    u = v_cross(f, r)
    return lambda p: (origin[0] + p[0] * r[0] + p[1] * u[0] + p[2] * f[0],
                      origin[1] + p[0] * r[1] + p[1] * u[1] + p[2] * f[1],
                      origin[2] + p[0] * r[2] + p[1] * u[2] + p[2] * f[2])


class _Sub:
    """`with _Sub(P, fn):` everything added inside goes through fn (then through any outer transform)."""

    def __init__(self, P, fn):
        self.P, self.fn = P, fn

    def __enter__(self):
        self.old = self.P.xform
        o, fn = self.old, self.fn
        self.P.xform = (lambda p: o(fn(p))) if o else fn
        return self.P

    def __exit__(self, *exc):
        self.P.xform = self.old


def _area2(pts):
    n = len(pts)
    return sum(pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1] for i in range(n)) / 2.0


def _convex(pts):
    n = len(pts)
    s = 0
    for i in range(n):
        a, b, c = pts[i - 1], pts[i], pts[(i + 1) % n]
        cr = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
        if abs(cr) < 1e-12:
            continue
        if s == 0:
            s = 1 if cr > 0 else -1
        elif (cr > 0) != (s > 0):
            return False
    return True


def _tri2d(pts):
    """Ear-clip a simple polygon [(u, v)] -> index triangles."""
    idx = list(range(len(pts)))
    if _area2(pts) < 0:
        idx.reverse()
    cross = lambda o, a, b: (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    tris = []
    guard = 0
    while len(idx) > 3 and guard < 4 * len(pts) * len(pts):
        guard += 1
        m = len(idx)
        for k in range(m):
            i0, i1, i2 = idx[k - 1], idx[k], idx[(k + 1) % m]
            a, b, c = pts[i0], pts[i1], pts[i2]
            if cross(a, b, c) <= 1e-12:
                continue
            if any(cross(a, b, pts[j]) >= 0 and cross(b, c, pts[j]) >= 0 and cross(c, a, pts[j]) >= 0
                   for j in idx if j not in (i0, i1, i2)):
                continue
            tris.append((i0, i1, i2))
            idx.pop(k)
            break
        else:
            break
    if len(idx) == 3:
        tris.append(tuple(idx))
    return tris


def _to3(plane, u, v, w):
    if plane == "zy":                     # profile in the side view (u = z, v = y), extruded along x
        return (w, v, u)
    if plane == "xy":                     # profile in the front view (u = x, v = y), extruded along z
        return (u, v, w)
    return (u, w, v)                      # "xz": plan (u = x, v = z), extruded along y


def _extrude(P, slot, pts2, w0, w1, plane="xy", side=None, caps=(True, True), side_slots=None):
    """Prism of the 2D polygon pts2 (any winding, convex or not) between w0 and w1 along the plane's normal axis."""
    n = len(pts2)
    s = 1.0 if _area2(pts2) > 0 else -1.0
    ax = _to3(plane, 0.0, 0.0, 1.0)
    acc = 0.0
    for i in range(n):
        (u0, v0), (u1, v1) = pts2[i], pts2[(i + 1) % n]
        du, dv = u1 - u0, v1 - v0
        ln = math.hypot(du, dv)
        if ln < 1e-9:
            continue
        sl = (side_slots[i] if side_slots and side_slots[i] else None) or side or slot
        sc = _uvs(sl)
        q = [_to3(plane, u0, v0, w0), _to3(plane, u1, v1, w0), _to3(plane, u1, v1, w1), _to3(plane, u0, v0, w1)]
        uv = [(acc / sc, w0 / sc), ((acc + ln) / sc, w0 / sc), ((acc + ln) / sc, w1 / sc), (acc / sc, w1 / sc)]
        P.poly(sl, q, uv, _to3(plane, dv * s, -du * s, 0.0))
        acc += ln
    tris = None if _convex(pts2) else _tri2d(pts2)
    for w, sgn, on in ((w0, -1.0, caps[0]), (w1, 1.0, caps[1])):
        if not on:
            continue
        want = v_mul(ax, sgn)
        if tris is None:
            P.flat(slot, [_to3(plane, u, v, w) for u, v in pts2], want)
        else:
            for t in tris:
                P.flat(slot, [_to3(plane, pts2[k][0], pts2[k][1], w) for k in t], want)


def _bar(P, slot, a, b, w, h=None, up=(0.0, 1.0, 0.0), fit=False):
    """A box beam from a to b, cross-section w x h."""
    d = v_sub(b, a)
    L = v_len(d)
    if L < 1e-6:
        return
    with _Sub(P, _frame(v_mul(v_add(a, b), 0.5), d, up)):
        P.box(slot, (0, 0, 0), (w / 2, (h or w) / 2, L / 2), fit=fit)


def _sphere_ring(P, slot, c, R, lat, n, dlat=1.6, h=0.006):
    """A raised seam ring hugging a sphere (centre c, radius R) at latitude lat: both edges sink into the sphere."""
    prof = []
    for la, rr in ((lat - dlat, R - h), (lat, R + h), (lat + dlat, R - h)):
        prof.append((rr * math.cos(math.radians(la)), rr * math.sin(math.radians(la))))
    P.lathe(slot, c, prof, n=n)


def _lens(P, slot, rr, z0, bezel=None, n=None):
    """A domed lens of radius rr whose base sits at local z = z0 (axis +z), sunk into its mount, in an optional
    bezel ring (bezel = slot) with an inner wall."""
    m = 4
    prof = [(rr, z0 - 0.02)] + [(rr * math.cos(math.radians(90 * k / m)), z0 + rr * math.sin(math.radians(90 * k / m)))
                                for k in range(m + 1)]
    P.lathe(slot, (0, 0, 0), prof, r=(90, 0, 0), n=n)
    if bezel:
        P.lathe(bezel, (0, 0, 0), [(rr + 0.014, z0 - 0.018), (rr + 0.014, z0 + 0.002), (rr + 0.004, z0 + 0.008),
                                   (rr + 0.002, z0 - 0.012)], r=(90, 0, 0), n=n)


def _oct(r, rot_deg=22.5):
    return [(r * math.cos(math.radians(rot_deg + 45 * k)), r * math.sin(math.radians(rot_deg + 45 * k))) for k in range(8)]


def _ring_arc(P, slot, c, r0, r1, y0, y1, a0, a1, n, top=None, side=None):
    """Annular solid between radii r0 < r1 and heights y0 < y1 over the angle range a0..a1 (degrees), capped."""
    P.lathe(side or slot, c, [(r1, y0), (r1, y1)], n=n, a0=a0, a1=a1)
    P.lathe(side or slot, c, [(r0, y1), (r0, y0)], n=n, a0=a0, a1=a1)
    P.lathe(top or slot, c, [(r1, y1), (r0, y1)], n=n, a0=a0, a1=a1)
    if abs(a1 - a0) < 359.9:
        for a, sgn in ((a0, -1.0), (a1, 1.0)):
            ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
            q = [(c[0] + r0 * ca, c[1] + y0, c[2] + r0 * sa), (c[0] + r1 * ca, c[1] + y0, c[2] + r1 * sa),
                 (c[0] + r1 * ca, c[1] + y1, c[2] + r1 * sa), (c[0] + r0 * ca, c[1] + y1, c[2] + r0 * sa)]
            P.flat(side or slot, q, (-sa * sgn, 0.0, ca * sgn))


# ---------------------------------------------------------------------------------------------------------------
# IT-O interrogation rig
# ---------------------------------------------------------------------------------------------------------------

RIG_SPOT = (0.62, 0.0, 1.02)          # the operator's feet in front of the console, facing it (yaw 180 = -z)
RIG_TABLE = (-0.30, 0.90, -0.42)      # restraint table pivot
RIG_TILT = 52.0                       # table tilt from horizontal, head end up and back
RIG_MAST = (0.50, -0.98)              # the droid arm's mast (x, z)
RIG_TOP = (0.77, 0.955, 0.40, 1.10)   # console top: front edge (z, y) -> back edge (z, y)


def _rig_table_xf(p):
    return xf(p, RIG_TABLE, (RIG_TILT, 0, 0))


def _cuff(P, x, z, rad=0.045, y=0.07, band=0.022):
    """A hinged restraint cuff arching over the pad at (x, z) (table-local), across a limb lying along z."""
    m = P.n(8, 4)
    path = [(x + rad * math.cos(math.pi * k / m), y + rad * math.sin(math.pi * k / m), z) for k in range(m + 1)]
    P.sweep("chrome", path, band, profile=[(-0.35, -1.0), (0.35, -1.0), (0.35, 1.0), (-0.35, 1.0)])
    for sx in (-1, 1):
        P.box("black", (x + sx * rad, y - 0.004, z), (0.014, 0.016, band * 1.25))
    if P.lod < 2:
        P.box("red", (x, y + rad + 0.009, z), (0.012, 0.003, 0.006))


def _ito_droid(P):
    """IT-O interrogator droid in local space: centre at the origin, its eye and instruments toward +z."""
    R = 0.16
    P.sphere("black", (0, 0, 0), R, n=P.n(22, 8))
    P.lathe("grey", (0, 0, 0), [(R - 0.003, -0.024), (R + 0.008, -0.013), (R + 0.008, 0.013), (R - 0.003, 0.024)],
            n=P.n(22, 8))
    for lat in (-38, 38) if P.lod < 2 else ():               # hull seams
        _sphere_ring(P, "grey", (0, 0, 0), R, lat, P.n(18, 8), h=0.004)
    # the photoreceptor eye in a grey bezel
    ez = math.sqrt(R * R - 0.04 ** 2)
    with _Sub(P, _frame((0, 0.04, 0.0), (0.0, 0.0, 1.0))):
        _lens(P, "imp2_lens", 0.036, ez - 0.002, bezel="grey", n=P.n(14, 6))
    # hypodermic injector, laser scalpel, grasping claw, all reaching forward and down
    for base, d, kind in () if P.lod >= 3 else (((0.075, -0.075, 0.12), (0.12, -0.40, 1.0), "needle"),
                          ((-0.085, -0.06, 0.12), (-0.18, -0.30, 1.0), "laser"),
                          ((0.0, -0.13, 0.08), (0.0, -1.0, 0.55), "claw")):
        d = v_norm(d)
        a = v_sub(base, v_mul(d, 0.04))
        b = v_add(base, v_mul(d, 0.11))
        P.sweep("black", [a, v_add(base, v_mul(d, 0.02))], 0.024, sides=P.n(10, 5))
        if kind == "needle":
            P.sweep("chrome", [v_add(base, v_mul(d, 0.02)), b], 0.016, sides=P.n(10, 5))
            P.sweep("imp2_lens", [v_add(base, v_mul(d, 0.05)), v_add(base, v_mul(d, 0.09))], 0.0165, sides=P.n(10, 5),
                    caps=False)
            P.cone("chrome", b, v_add(b, v_mul(d, 0.15)), 0.0055, n=P.n(6, 4))
        elif kind == "laser":
            P.sweep("grey", [v_add(base, v_mul(d, 0.02)), b], 0.012, sides=P.n(8, 4))
            P.sphere("red", b, 0.014, n=P.n(8, 5))
        else:
            P.sweep("chrome", [v_add(base, v_mul(d, 0.02)), b], 0.012, sides=P.n(8, 4))
            if P.lod < 3:
                for k in range(3):
                    ang = 2 * math.pi * k / 3
                    off = (0.035 * math.cos(ang), 0.0, 0.035 * math.sin(ang))
                    knuckle = v_add(b, (off[0] * 0.5, -0.01, off[2] * 0.5))
                    P.sweep("grey", [b, knuckle, v_add(b, (off[0], -0.07, off[2]))], 0.006, sides=4)
    # audio grille on the left flank, a red telltale on the back
    P.lathe("grey", (-(R - 0.03), 0, 0), [(0.062, 0.0), (0.062, 0.036), (0.0, 0.036)], r=(0, 0, 90), n=P.n(16, 6))
    if P.lod < 2:
        for k in range(5):
            P.box("black", (-R - 0.0075, 0.0, -0.04 + 0.02 * k), (0.002, 0.045, 0.004))
    P.sphere("red", (0, 0.05, -R + 0.004), 0.016, n=P.n(8, 5))
    # top mount socket
    P.lathe("chrome", (0, 0, 0), [(0.058, R - 0.015), (0.060, R + 0.012), (0.035, R + 0.032), (0.0, R + 0.032)],
            n=P.n(14, 6))


def imp_interrogation_rig(P):
    """IT-O interrogation rig on a deck plate: restraint table, the droid on an articulated arm, the operator's
    console. Station `console` at RIG_SPOT facing -z: the console top's centre is 0.44 m ahead at 1.03 m."""
    n = P.n(32, 12)
    sx, _, sz = RIG_SPOT
    tx, ty, tz = RIG_TABLE
    # -- deck plate under the rig; the operator's spot stays on the floor just in front of it
    deck = [(-1.00, -1.08), (-0.88, -1.20), (0.82, -1.20), (0.94, -1.08), (0.94, 0.70), (0.86, 0.78),
            (-0.92, 0.78), (-1.00, 0.70)]
    P.prism("grey", deck, 0.0, 0.035, side_slot="black")
    P.box("red", (-0.03, 0.018, 0.7815), (0.86, 0.006, 0.002), bottom=False)
    for x0, x1 in ((-0.95, -0.55), (0.10, 0.35)) if P.lod < 3 else ():  # floor grates in the plate
        P.box("black", ((x0 + x1) / 2, 0.036, 0.52), ((x1 - x0) / 2, 0.0012, 0.16), bottom=False)
        if P.lod < 2:
            for k in range(7):
                P.box("grey", (x0 + (x1 - x0) * (k + 0.5) / 7, 0.038, 0.52), (0.006, 0.0015, 0.15), bottom=False)

    # -- the operator's console: a sloped desk on a waisted pedestal, red readout in a raised hood
    cx = sx
    x0, x1 = cx - 0.32, cx + 0.32
    zf, yf, zb, yb = RIG_TOP
    prof = [(0.36, 0.035), (0.62, 0.035), (0.64, 0.70), (zf, 0.91), (zf, yf), (zb, yb), (0.36, yb)]
    _extrude(P, "black", prof, x0, x1, "zy")
    sl_a = math.degrees(math.atan2(yb - yf, zf - zb))
    ca, sa = math.cos(math.radians(sl_a)), math.sin(math.radians(sl_a))
    nt = (0.0, ca, sa)

    def on_top(s, x, h=0.0):
        """a point on the sloped top: s 0 = front edge .. 1 = back edge, h above the surface"""
        return (x, yf + (yb - yf) * s + h * ca, zf + (zb - zf) * s + h * sa)
    P.decal("console_face", on_top(0.42, cx, 0.002), 0.58, 0.26, nt)
    P.box("grey", on_top(0.0, cx, -0.006), (0.325, 0.012, 0.012), r=(sl_a, 0, 0))            # front nosing
    P.box("red", (cx, 0.93, zf + 0.002), (0.30, 0.008, 0.002), bottom=False)                  # lip light strip
    if P.lod < 3:
        for k in range(9):                                                                  # key bank
            P.box("red" if k % 4 else "white", on_top(0.12, cx - 0.24 + 0.06 * k, 0.006), (0.02, 0.006, 0.013),
                  r=(sl_a, 0, 0))
        for k in range(6):                                                                  # toggles
            base = on_top(0.80, cx - 0.06 + 0.035 * k, 0.004)
            P.box("grey", base, (0.012, 0.004, 0.012), r=(sl_a, 0, 0))
            P.sweep("chrome", [base, v_add(base, (0.0, 0.035, 0.012 * (1 if k % 2 else -1)))], 0.004, sides=4)
        for k, x in enumerate((cx - 0.235, cx - 0.145)):                                   # gauges
            c = on_top(0.72, x, 0.0)
            P.lathe("grey", c, [(0.042, 0.0), (0.042, 0.012), (0.034, 0.016), (0.0, 0.016)], r=(sl_a, 0, 0), n=P.n(14, 6))
            P.box("red", v_add(c, v_mul(nt, 0.018)), (0.003, 0.002, 0.026), r=(sl_a, 25 - 50 * k, 0))
        jb = on_top(0.66, cx + 0.22, 0.0)                                                   # IT-O control stick
        P.lathe("chrome", jb, [(0.045, 0.0), (0.045, 0.01), (0.02, 0.025), (0.0, 0.025)], r=(sl_a, 0, 0), n=P.n(12, 6))
        tip = v_add(jb, (0.0, 0.11, 0.02))
        P.sweep("black", [jb, tip], 0.009, sides=P.n(8, 4))
        P.sphere("red", tip, 0.02, n=P.n(8, 5))
    P.decal("imp2_status", on_top(0.82, cx + 0.06 + 0.13, 0.003), 0.10, 0.05, nt)
    # the readout hood on a neck at the back of the desk
    hood_c, tilt = (cx, 1.35, 0.42), -16.0
    P.box("black", (cx, 1.14, 0.44), (0.07, 0.07, 0.035))
    with _Sub(P, lambda p: xf(p, hood_c, (tilt, 0, 0))):
        P.box("black", (0, 0, 0), (0.31, 0.205, 0.05))
        P.decal("imp2_screen", (0, 0.0, 0.0515), 0.52, 0.32, (0, 0, 1))
        for (bx, by, hx, hy) in ((0, 0.172, 0.285, 0.012), (0, -0.172, 0.285, 0.012), (0.272, 0, 0.012, 0.16),
                                 (-0.272, 0, 0.012, 0.16)) if P.lod < 3 else ():
            P.box("grey", (bx, by, 0.056), (hx, hy, 0.006))
        for s in (-1, 1):                                                                   # side blinkers
            P.box("grey", (s * 0.335, 0.0, 0.02), (0.025, 0.19, 0.075), r=(0, s * 18, 0))
        P.box("black", (0, 0.215, -0.01), (0.25, 0.012, 0.06))                              # brow
        P.box("red", (0, 0.205, 0.051), (0.22, 0.004, 0.002), bottom=False)
        P.box("grey", (0, 0.0, -0.06), (0.20, 0.13, 0.012))                                 # back plate
    P.sphere("red", (cx + 0.22, 1.58, 0.41), 0.022, lat0=0, lat1=90, n=P.n(10, 5))          # beacon
    P.lathe("black", (cx + 0.22, 1.55, 0.41), [(0.03, 0.0), (0.03, 0.03), (0.0, 0.03)], n=P.n(10, 5))
    # pedestal sides: grey inset panels with vents; the crest on the front
    for xs, sgn in ((x0, -1), (x1, 1)):
        P.box("grey", (xs + sgn * 0.004, 0.45, 0.50), (0.004, 0.30, 0.09), bottom=False)
        if P.lod < 2:
            for k in range(6):
                P.box("black", (xs + sgn * 0.009, 0.30 + 0.05 * k, 0.50), (0.002, 0.008, 0.06), bottom=False)
    P.decal("crest", (cx, 0.42, 0.6355), 0.22, 0.22, (0.0, -0.03, 1.0))
    P.box("grey", (cx, 0.055, 0.49), (0.335, 0.02, 0.15))                                   # plinth

    # -- restraint table, tilted on a yoke
    with _Sub(P, _rig_table_xf):
        P.rbox("grey", (0, 0, 0), (0.36, 0.05, 0.98), 0.03)
        P.rbox("black", (0, 0.03, 0.07), (0.30, 0.03, 0.86), 0.02)
        P.rbox("leather", (0, 0.058, 0.07), (0.28, 0.024, 0.84), 0.02, puff=0.006)
        P.rbox("leather", (0, 0.07, -0.83), (0.15, 0.03, 0.11), 0.025, puff=0.01)
        for s in (-1, 1):
            if P.lod < 3:
                P.box("grey", (s * 0.18, 0.10, -0.82), (0.022, 0.05, 0.075))                # head clamps
            P.box("grey", (s * 0.372, 0.0, 0.0), (0.012, 0.036, 0.93))                       # side rails
            P.box("red", (s * 0.386, 0.0, 0.0), (0.0025, 0.008, 0.86))
            P.sweep("chrome", [(s * 0.372, 0.0, 0.0), (s * 0.45, 0.0, 0.0)], 0.055, sides=P.n(14, 6))   # pivots
        for x, z in ((-0.24, -0.02), (0.24, -0.02), (-0.09, 0.80), (0.09, 0.80)) if P.lod < 3 else ():
            _cuff(P, x, z)
        strap = [(x, 0.088 + 0.016 * (1 - (x / 0.31) ** 2), -0.44) for x in [-0.31 + 0.62 * k / 8 for k in range(9)]]
        P.sweep("chrome", strap, 0.03, profile=[(-0.3, -1.0), (0.3, -1.0), (0.3, 1.0), (-0.3, 1.0)])
        P.box("black", (0, 0.106, -0.44), (0.04, 0.012, 0.036))
        P.box("red", (0, 0.119, -0.44), (0.02, 0.002, 0.012))
        for z in (-0.62, 0.0, 0.62):                                                        # underside ribs
            P.box("grey", (0, -0.062, z), (0.30, 0.012, 0.03))
        P.box("grey", (0, -0.076, -0.55), (0.05, 0.026, 0.05))                              # ram clevis
    # pedestal, yoke and the hydraulic ram holding the tilt
    P.lathe("black", (tx, 0.035, tz), [(0.40, 0.0), (0.40, 0.035), (0.30, 0.065), (0.14, 0.085), (0.12, 0.50),
                                       (0.15, 0.53), (0.0, 0.53)], n=n)
    P.lathe("red", (tx, 0.035, tz), [(0.403, 0.012), (0.403, 0.024)], n=n)
    P.box("grey", (tx, 0.60, tz), (0.50, 0.035, 0.07))
    for s in (-1, 1):
        P.box("grey", (tx + s * 0.47, (0.565 + ty + 0.07) / 2, tz), (0.03, (ty + 0.07 - 0.565) / 2, 0.065))
        P.sweep("chrome", [(tx + s * 0.50, ty, tz), (tx + s * 0.52, ty, tz)], 0.045, sides=P.n(14, 6))
    top = _rig_table_xf((0.0, -0.10, -0.55))
    foot = (tx, 0.09, tz - 0.36)
    mid = v_add(foot, v_mul(v_sub(top, foot), 0.55))
    P.box("grey", foot, (0.055, 0.045, 0.055))
    P.sweep("black", [foot, mid], 0.04, sides=P.n(12, 6))
    P.sweep("chrome", [mid, top], 0.022, sides=P.n(10, 5))

    # -- the IT-O droid, hanging from an articulated arm on a mast, its eye on the prisoner's face
    head = _rig_table_xf((0.0, 0.11, -0.80))
    nrm = v_sub(_rig_table_xf((0, 1, 0)), _rig_table_xf((0, 0, 0)))
    D = v_add(head, v_mul(nrm, 0.45))
    mx, mz = RIG_MAST
    P.box("black", (mx, 0.06, mz), (0.17, 0.025, 0.17))
    P.prism("black", [(mx + x, mz + z) for x, z in _oct(0.08)], 0.085, 2.0, top=False)
    for y0, y1 in ((0.10, 0.16), (1.30, 1.36), (1.94, 2.0)):
        P.prism("grey", [(mx + x, mz + z) for x, z in _oct(0.09)], y0, y1, bottom=True)
    if P.lod < 2:
        P.box("red", (mx, 0.70, mz + 0.0745), (0.012, 0.32, 0.002), bottom=False)
    S = (mx, 2.06, mz)
    W = v_add(D, (0.0, 0.31, 0.02))
    E = v_add(v_mul(v_add(S, W), 0.5), (0.0, 0.17, 0.05))
    P.lathe("black", (mx, 2.0, mz), [(0.07, 0.0), (0.07, 0.05), (0.0, 0.05)], n=P.n(14, 6))
    _bar(P, "black", S, E, 0.075, 0.065)
    _bar(P, "black", E, W, 0.06, 0.055)
    for j, rad in ((S, 0.055), (E, 0.05), (W, 0.042)):
        P.sphere("chrome", j, rad, n=P.n(12, 6))
    for a_, b_ in ((S, E), (E, W)) if P.lod < 3 else ():                                    # hydraulic pistons
        d = v_norm(v_sub(b_, a_))
        side = v_norm(v_cross(d, (0.0, 1.0, 0.0)))
        off = v_add(v_mul(side, 0.055), (0.0, -0.025, 0.0))
        pa, pb = v_add(v_add(a_, off), v_mul(d, 0.07)), v_add(v_add(b_, off), v_mul(d, -0.07))
        pm = v_add(pa, v_mul(v_sub(pb, pa), 0.5))
        P.sweep("grey", [pa, pm], 0.014, sides=P.n(8, 4))
        P.sweep("chrome", [pm, pb], 0.008, sides=P.n(8, 4))
    dxf = _frame(D, v_mul(nrm, -1.0))
    mount = dxf((0.0, 0.192, 0.0))
    P.sweep("chrome", [W, mount], 0.016, sides=P.n(10, 5))
    P.sweep("black", [W, v_add(W, v_mul(v_sub(mount, W), 0.35))], 0.03, sides=P.n(10, 5))
    with _Sub(P, dxf):
        _ito_droid(P)

    # -- instrument tray on a pole beside the table: injectors, vials, a scalpel
    tc = (-0.78, 0.0, 0.40)
    P.lathe("black", (tc[0], 0.035, tc[2]), [(0.13, 0.0), (0.13, 0.02), (0.04, 0.04), (0.0, 0.04)], n=P.n(16, 6))
    P.sweep("chrome", [(tc[0], 0.07, tc[2]), (tc[0], 0.92, tc[2])], 0.014, sides=P.n(8, 4))
    P.box("grey", (tc[0], 0.935, tc[2]), (0.17, 0.012, 0.12))
    for s_ in (-1, 1) if P.lod < 3 else ():
        P.box("grey", (tc[0] + s_ * 0.17, 0.955, tc[2]), (0.006, 0.02, 0.12))
        P.box("grey", (tc[0], 0.955, tc[2] + s_ * 0.12), (0.17, 0.02, 0.006))
    if P.lod < 2:
        for k in range(4):                                                                   # vials in a rack
            vc = (tc[0] - 0.10 + 0.035 * k, 0.947, tc[2] - 0.06)
            P.lathe("imp2_lens", vc, [(0.012, 0.0), (0.012, 0.07), (0.0, 0.07)], n=6)
            P.lathe("chrome", v_add(vc, (0, 0.07, 0)), [(0.013, 0.0), (0.013, 0.012), (0.0, 0.012)], n=6)
        for k in range(2):                                                                   # injectors
            a = (tc[0] + 0.02 + 0.05 * k, 0.958, tc[2] + 0.04)
            P.sweep("chrome", [a, v_add(a, (0.09, 0.0, -0.03))], 0.009, sides=6)
            P.cone("chrome", v_add(a, (0.09, 0.0, -0.03)), v_add(a, (0.15, 0.0, -0.05)), 0.003, n=4)
        P.box("black", (tc[0] - 0.06, 0.952, tc[2] + 0.06), (0.05, 0.005, 0.02))
        P.decal("imp2_status", (tc[0] - 0.06, 0.9575, tc[2] + 0.06), 0.09, 0.03, (0, 1, 0), up=(0, 0, -1))

    # -- cables over the deck: console to the table pedestal and to the mast
    if P.lod < 3:
        P.sweep("black", [(cx - 0.18, 0.05, 0.37), (0.20, 0.051, 0.18), (-0.02, 0.051, -0.05), (tx + 0.10, 0.06, tz + 0.33)],
                0.016, sides=P.n(8, 4))
        P.sweep("black", [(cx + 0.10, 0.05, 0.37), (0.62, 0.051, 0.0), (0.50, 0.051, -0.55), (mx, 0.06, mz + 0.18)],
                0.014, sides=P.n(8, 4))
    station_hardpoints(P, "console", RIG_SPOT, yaw=180.0)


# ---------------------------------------------------------------------------------------------------------------
# the Emperor's throne
# ---------------------------------------------------------------------------------------------------------------

THRONE_FRONT = 0.42                   # seat front edge (foot 0.175 m ahead)


def _dplan(R, cz, zcut, m):
    """A circle (radius R about z = cz) cut straight at z = zcut: plan ring [(x, z)]."""
    a_cut = math.degrees(math.asin(max(-1.0, min(1.0, (zcut - cz) / R))))
    a0, a1 = 180.0 - a_cut, 360.0 + a_cut
    return [(R * math.cos(math.radians(a0 + (a1 - a0) * k / m)), cz + R * math.sin(math.radians(a0 + (a1 - a0) * k / m)))
            for k in range(m + 1)]


def imp_emperor_throne(P):
    """The Emperor's throne. Seat 0.46, front edge z 0.42 -> foot 0.595; the dais is cut straight at z 0.47."""
    m = P.n(40, 14)
    cz = -0.26
    low, up = _dplan(0.95, cz, 0.47, m), _dplan(0.78, cz, 0.33, m)
    P.prism("grey", low, 0.0, 0.06, side_slot="black")
    P.prism("black", up, 0.06, 0.12, side_slot="black")
    grow = lambda p, d: (p[0] + d * v_norm((p[0], 0, p[1] - cz))[0], p[1] + d * v_norm((p[0], 0, p[1] - cz))[2])
    for ring, y in ((low, 0.06), (up, 0.12)):
        P.sweep("chrome", [(x, y, z) for x, z in (grow(p, 0.002) for p in ring)], 0.008, closed=True, sides=P.n(6, 4))
        P.sweep("red", [(x, y * 0.5, z) for x, z in (grow(p, 0.001) for p in ring)], 0.005, closed=True, sides=4)
    # grey inlay ring and radial seams on the black upper tier
    inlay = _dplan(0.60, cz, 0.25, m)
    P.sweep("grey", [(x, 0.121, z) for x, z in inlay], 0.006, closed=True, sides=4)
    if P.lod < 2:
        for k in range(11):                                                          # floor lights, lower tier
            a = math.radians(200 + 14 * k)
            c = (0.865 * math.cos(a), 0.0605, cz + 0.865 * math.sin(a))
            P.box("red", c, (0.022, 0.0015, 0.008), r=(0, -math.degrees(a) + 90, 0), bottom=False)
        for k in range(7):                                                           # radial seams, upper tier
            a = math.radians(205 + 21.7 * k)
            p0 = (0.62 * math.cos(a), 0.1215, cz + 0.62 * math.sin(a))
            p1 = (0.76 * math.cos(a), 0.1215, cz + 0.76 * math.sin(a))
            _bar(P, "grey", p0, p1, 0.012, 0.003)
    # swivel pedestal
    pc = (0.0, 0.12, 0.10)
    P.lathe("black", pc, [(0.36, 0.0), (0.36, 0.025), (0.24, 0.06), (0.14, 0.09), (0.12, 0.15), (0.20, 0.18),
                          (0.0, 0.18)], n=P.n(32, 10))
    P.lathe("chrome", pc, [(0.115, 0.10), (0.132, 0.11), (0.115, 0.12)], n=P.n(24, 8))
    P.lathe("red", pc, [(0.355, 0.004), (0.362, 0.008), (0.362, 0.018), (0.355, 0.022)], n=P.n(32, 10))
    # seat shell and cushion
    shell = [(-0.36, -0.12), (0.36, -0.12), (0.36, 0.34), (0.30, THRONE_FRONT), (-0.30, THRONE_FRONT), (-0.36, 0.34)]
    P.prism("black", shell, 0.30, 0.405, bottom=True)
    P.rbox("leather", (0.0, 0.433, 0.15), (0.30, 0.028, 0.265), 0.024, puff=0.008)
    P.box("grey", (0.0, 0.352, THRONE_FRONT + 0.003), (0.27, 0.02, 0.003), bottom=False)
    # wide angular arms carrying control panels
    arm = [(-0.18, 0.30), (0.26, 0.30), (0.50, 0.55), (0.50, 0.62), (0.45, 0.68), (-0.18, 0.68)]
    for s in (-1, 1):
        xa, xb = (0.365, 0.585) if s > 0 else (-0.585, -0.365)
        _extrude(P, "black", arm, xa, xb, "zy")
        xc = s * 0.475
        P.box("chrome", (s * 0.588, 0.664, 0.135), (0.003, 0.010, 0.31))
        nf = v_norm((0.0, -0.24, 0.25))                                               # red strip under the nose
        P.box("red", v_add((xc, 0.425, 0.38), v_mul(nf, 0.003)), (0.09, 0.006, 0.002),
              r=(math.degrees(math.atan2(0.24, 0.25)), 0, 0))
        P.box("grey", (xc, 0.684, 0.13), (0.09, 0.005, 0.27))
        P.decal("console_face", (xc, 0.6895, 0.04), 0.15, 0.30, (0, 1, 0), up=(0, 0, -1))
        hc = (xc, 0.70, 0.33)
        P.box("black", hc, (0.072, 0.016, 0.052), r=(-24, 0, 0))
        nl = rot((0, 1, 0), -24)
        P.decal("lcd", v_add(hc, v_mul(nl, 0.0165)), 0.12, 0.085, nl, up=(0, 0, -1))
        if P.lod < 3:
            for k in range(4):
                P.box("red" if k != 1 else "white", (xc - 0.054 + 0.036 * k, 0.6925, 0.225), (0.012, 0.004, 0.012))
            P.sweep("chrome", [(xc + s * 0.06, 0.689, -0.06), (xc + s * 0.06, 0.73, -0.075)], 0.005, sides=4)
            P.sphere("red", (xc + s * 0.06, 0.733, -0.076), 0.01, n=6)
        P.box("black", (s * 0.47, 0.22, 0.02), (0.07, 0.08, 0.16))                           # arm support fin
        P.box("grey", (s * 0.47, 0.22, 0.182), (0.06, 0.06, 0.003), bottom=False)
    # the high back, leaning 9 degrees: angular shoulder wings, a pointed crown, leather inset, grey edge trim
    back = [(-0.33, 0.0), (0.33, 0.0), (0.40, 0.50), (0.48, 0.98), (0.41, 1.05), (0.38, 1.30), (0.22, 1.52),
            (0.0, 1.62), (-0.22, 1.52), (-0.38, 1.30), (-0.41, 1.05), (-0.48, 0.98), (-0.40, 0.50)]
    inset = [(-0.27, 0.10), (0.27, 0.10), (0.32, 0.55), (0.32, 1.25), (0.18, 1.44), (0.0, 1.51), (-0.18, 1.44),
             (-0.32, 1.25), (-0.32, 0.55)]
    with _Sub(P, lambda p: xf(p, (0.0, 0.40, -0.16), (-9, 0, 0))):
        _extrude(P, "black", back, -0.075, 0.075, "xy")
        _extrude(P, "leather", inset, 0.075, 0.09, "xy", caps=(False, True))
        P.sweep("grey", [(x, y, 0.077) for x, y in back], 0.011, closed=True, sides=P.n(6, 4))
        P.rbox("leather", (0.0, 1.10, 0.105), (0.17, 0.085, 0.03), 0.025, puff=0.008)
        P.box("black", (0.0, 0.70, -0.09), (0.09, 0.62, 0.02))
        if P.lod < 2:
            for k in range(7):
                P.box("grey", (0.0, 0.30 + 0.13 * k, -0.111), (0.06, 0.012, 0.002), bottom=False)
        for s in (-1, 1):                                                                    # wing light strips
            a = (s * 0.405, 0.52, 0.077)
            b = (s * 0.475, 0.97, 0.077)
            _bar(P, "red", v_add(a, (0, 0, 0.004)), v_add(b, (0, 0, 0.004)), 0.008, 0.004)
        P.box("chrome", (0.0, 1.59, 0.03), (0.035, 0.035, 0.035), r=(0, 0, 45))               # crown stud
    seat_hardpoint(P, THRONE_FRONT)


# ---------------------------------------------------------------------------------------------------------------
# Death Star corridor light pillar
# ---------------------------------------------------------------------------------------------------------------

def imp_light_pillar(P):
    """2.3 m light pillar: chamfered-square black core with a framed white light channel on each face (four
    segments behind mullions), grey blade fins on the chamfers, stepped plinth and capital. Light at the heart."""
    H = 2.30
    sq = lambda a, c: [(a, -(a - c)), (a, a - c), (a - c, a), (-(a - c), a), (-a, a - c), (-a, -(a - c)), (-(a - c), -a),
                       (a - c, -a)]
    a0 = 0.16
    P.prism("black", sq(0.29, 0.09), 0.0, 0.07, bottom=False)
    P.prism("grey", sq(0.265, 0.08), 0.07, 0.11)
    P.prism("black", sq(0.215, 0.065), 0.11, 0.24)
    P.prism("black", sq(a0, 0.05), 0.24, H - 0.26, top=False)
    P.prism("black", sq(0.215, 0.065), H - 0.26, H - 0.15, bottom=True)
    P.prism("grey", sq(0.265, 0.08), H - 0.15, H - 0.09, bottom=True)
    P.prism("black", sq(0.20, 0.06), H - 0.09, H - 0.025)
    P.prism("grey", sq(0.13, 0.04), H - 0.025, H)
    y0, y1 = 0.36, H - 0.38
    segs = 4
    for k in range(4):
        a = 90.0 * k
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        ry = -a + 90.0
        out = lambda d, t, y: (ca * d - sa * t, y, sa * d + ca * t)       # d along the face normal, t along the face
        P.box("black", out(a0 + 0.002, 0.0, (y0 + y1) / 2), (0.090, (y1 - y0) / 2 + 0.02, 0.004), r=(0, ry, 0))
        hseg = (y1 - y0) / segs
        for j in range(segs):
            yc = y0 + hseg * (j + 0.5)
            P.box("imp2_light", out(a0 + 0.010, 0.0, yc), (0.072, hseg / 2 - 0.012, 0.006), r=(0, ry, 0), fit=True)
            if j:
                P.box("grey", out(a0 + 0.016, 0.0, y0 + hseg * j), (0.080, 0.012, 0.010), r=(0, ry, 0))
        for s in (-1, 1):                                                   # frame rails
            P.box("black", out(a0 + 0.024, s * 0.088, (y0 + y1) / 2), (0.014, (y1 - y0) / 2 + 0.04, 0.024), r=(0, ry, 0))
            P.box("grey", out(a0 + 0.049, s * 0.088, (y0 + y1) / 2), (0.016, (y1 - y0) / 2 + 0.02, 0.002), r=(0, ry, 0))
        for yy in (y0 - 0.03, y1 + 0.03):
            P.box("grey", out(a0 + 0.02, 0.0, yy), (0.10, 0.022, 0.022), r=(0, ry, 0))
        # capital slot light, base telltale
        P.box("imp2_light", out(0.215 + 0.002, 0.0, H - 0.205), (0.09, 0.014, 0.003), r=(0, ry, 0), fit=True)
        if P.lod < 2:
            P.box("red", out(0.215 + 0.002, 0.0, 0.175), (0.035, 0.007, 0.002), r=(0, ry, 0), bottom=False)
            for t in (-0.06, 0.06):
                P.box("grey", out(0.215 + 0.002, t, 0.175), (0.012, 0.03, 0.002), r=(0, ry, 0), bottom=False)
    ch = (a0 - 0.025) * math.sqrt(2.0)                                       # chamfer face distance from the axis
    for k in range(4):                                                      # grey blade fins on the chamfers
        a = 45.0 + 90.0 * k
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        fin = [(0.0, 0.27), (0.05, 0.31), (0.11, 0.52), (0.11, H - 0.52), (0.05, H - 0.31), (0.0, H - 0.27)]
        with _Sub(P, lambda p, ca=ca, sa=sa: (ca * (ch + p[0]) - sa * p[2], p[1], sa * (ch + p[0]) + ca * p[2])):
            _extrude(P, "grey", fin, -0.012, 0.012, "xy")
            if P.lod < 2:
                for yy in (0.75, 1.15, 1.55):
                    P.box("black", (0.08, yy, 0.0), (0.014, 0.06, 0.0135))
                P.box("red", (0.112, 1.15, 0.0), (0.002, 0.25, 0.004))
    if P.lod < 3:                                                           # top sensor dome
        P.sphere("chrome", (0, H, 0), 0.06, lat0=0, lat1=90, n=P.n(12, 6))
    light_hardpoint(P, (0.0, 1.20, 0.0))


# ---------------------------------------------------------------------------------------------------------------
# Viper probe droid on a display stand
# ---------------------------------------------------------------------------------------------------------------

PROBE_C = (0.0, 1.46, 0.06)           # centre of the head's collar band


def _probe_eye(P, c, nrm, rr):
    with _Sub(P, _frame(c, nrm)):
        _lens(P, "imp2_lens", rr, 0.006, bezel="grey" if P.lod < 3 else None, n=P.n(12, 6))


def imp_probe_droid(P):
    """Viper probe droid (head 0.6 m across, legs hanging to 0.25 m) clamped to a display stand; antenna tip 2.3 m."""
    cx, cy, cz = PROBE_C
    n = P.n(28, 10)
    R = 0.30
    # head: domed top, collar band, tapering lower body, leg hub
    P.sphere("black", (cx, cy + 0.05, cz), R, lat0=0, lat1=90, n=n)
    P.lathe("grey", (cx, cy, cz), [(R - 0.012, -0.055), (R + 0.008, -0.04), (R + 0.008, 0.04), (R - 0.002, 0.052)], n=n)
    P.lathe("imp2_gunmetal", (cx, cy, cz), [(0.0, -0.38), (0.11, -0.38), (0.15, -0.32), (0.23, -0.21), (0.275, -0.12),
                                            (R - 0.012, -0.055)], n=n)
    P.lathe("grey", (cx, cy, cz), [(0.0, -0.44), (0.085, -0.44), (0.105, -0.40), (0.115, -0.37)], n=P.n(16, 8))
    P.lathe("chrome", (cx, cy, cz), [(0.135, -0.335), (0.158, -0.31), (0.135, -0.285)], n=P.n(16, 8))
    P.lathe("grey", (cx, cy, cz), [(0.235, -0.215), (0.252, -0.20), (0.262, -0.17), (0.252, -0.155)], n=n)
    for lat in (35, 62):                                                          # dome panel rings
        _sphere_ring(P, "grey", (cx, cy + 0.05, cz), R, lat, n)
    P.lathe("grey", (cx, cy + 0.05, cz), [(0.07, R - 0.012), (0.074, R + 0.012), (0.0, R + 0.014)], n=P.n(12, 6))
    # sensor eyes round the front of the dome
    hc = (cx, cy + 0.05, cz)
    for el, az, rr in ((20, 90, 0.046), (10, 62, 0.030), (10, 118, 0.030), (34, 72, 0.022), (34, 108, 0.022),
                       (6, 36, 0.020), (6, 144, 0.020), (48, 90, 0.018)):
        if P.lod >= 2 and rr < 0.025:
            continue
        d = (math.cos(math.radians(el)) * math.cos(math.radians(az)), math.sin(math.radians(el)),
             math.cos(math.radians(el)) * math.sin(math.radians(az)))
        _probe_eye(P, v_add(hc, v_mul(d, R - 0.004)), d, rr)
    # collar vents, side sensor pods, a blaster port on the lower body
    if P.lod < 2:
        for k in range(10):
            a = math.radians(200 + 14 * k)
            P.box("black", (cx + (R + 0.010) * math.cos(a), cy, cz + (R + 0.010) * math.sin(a)), (0.012, 0.028, 0.004),
                  r=(0, -math.degrees(a) + 90, 0))
        for k in range(6):
            a = math.radians(30 + 60 * k)
            p = (cx + 0.205 * math.cos(a), cy - 0.25, cz + 0.205 * math.sin(a))
            P.box("grey", p, (0.03, 0.022, 0.004), r=(-30, -math.degrees(a) + 90, 0))
    for s in (-1, 1):
        a = math.radians(90 - s * 80)
        pc = (cx + (R + 0.02) * math.cos(a), cy - 0.02, cz + (R + 0.02) * math.sin(a))
        P.sphere("grey", pc, 0.05, n=P.n(10, 6), sy=0.8)
        P.sphere("imp2_lens", v_add(pc, (0, -0.005, 0.03)), 0.022, n=P.n(8, 5))
    bp = (cx + 0.17, cy - 0.17, cz + 0.17)
    P.sweep("imp2_gunmetal", [bp, v_add(bp, (0.05, -0.06, 0.12))], 0.022, sides=P.n(8, 4))
    P.sweep("black", [v_add(bp, (0.05, -0.06, 0.12)), v_add(bp, (0.065, -0.08, 0.17))], 0.014, sides=P.n(8, 4))
    # antennae from the top rear
    for (ax, az, h, lean, r0) in ((0.07, -0.12, 0.62, 0.05, 0.010), (-0.10, -0.10, 0.36, -0.04, 0.009),
                                  (0.0, -0.17, 0.46, 0.0, 0.008), (0.14, -0.04, 0.22, 0.06, 0.007)):
        base = (cx + ax, cy + 0.05 + math.sqrt(max(0.0, R * R - ax * ax - az * az)) - 0.01, cz + az)
        tip = v_add(base, (lean, h, -0.04))
        if P.lod < 3:
            P.lathe("grey", base, [(r0 * 2.2, -0.01), (r0 * 2.2, 0.025), (0.0, 0.03)], n=P.n(8, 4))
        P.sweep("chrome", [base, tip], r0, sides=P.n(6, 4))
        P.sphere("black", tip, r0 * 1.6, n=6)
    # manipulator legs: three long walkers, two short pincers, all dangling
    legs = ((30, 1.00, 0.20), (150, 1.00, 0.20), (270, 0.95, 0.16), (70, 0.55, 0.10), (110, 0.60, 0.10))
    for k, (phi, ln, spread) in enumerate(legs):
        ca, sa = math.cos(math.radians(phi)), math.sin(math.radians(phi))
        S = (cx + 0.08 * ca, cy - 0.40, cz + 0.08 * sa)
        K = v_add(S, (spread * ca, -0.28 * ln, spread * sa))
        A = v_add(K, (0.03 * ca, -0.55 * ln, 0.03 * sa))
        P.sweep("imp2_gunmetal", [S, K], 0.022 if ln > 0.8 else 0.016, sides=P.n(8, 4))
        P.sweep("imp2_gunmetal", [K, A], 0.016 if ln > 0.8 else 0.012, sides=P.n(8, 4))
        P.sphere("grey", K, 0.03 if ln > 0.8 else 0.022, n=P.n(8, 5))
        P.sphere("grey", S, 0.026, n=P.n(8, 5))
        if P.lod < 2 and ln > 0.8:                                                 # piston along the thigh
            P.sweep("chrome", [v_add(S, (0.0, -0.03, 0.0)), v_add(K, (0.0, 0.05, 0.0))], 0.007, sides=4)
            P.lathe("grey", K, [(0.012, -0.22 * ln), (0.026, -0.205 * ln), (0.026, -0.14 * ln), (0.012, -0.125 * ln)],
                    n=P.n(8, 4))
        P.sphere("grey", A, 0.024 if ln > 0.8 else 0.018, n=P.n(8, 5))
        fingers = (3 if ln > 0.8 else 2) if P.lod < 3 else 0
        for j in range(fingers):
            b = math.radians(phi + (360.0 / fingers) * j + 30)
            mid = v_add(A, (0.04 * math.cos(b), -0.03, 0.04 * math.sin(b)))
            P.sweep("imp2_gunmetal", [A, mid], 0.008, sides=4)
            P.cone("grey", mid, v_add(mid, (0.01 * math.cos(b), -0.07, 0.01 * math.sin(b))), 0.009, n=P.n(5, 4))
    # display stand: round base, crest roundel, a post rising behind and a chrome arm clamped to the head's back
    P.lathe("black", (0, 0, 0), [(0.48, 0.0), (0.48, 0.045), (0.45, 0.07), (0.0, 0.07)], n=P.n(36, 12))
    P.lathe("grey", (0, 0, 0), [(0.40, 0.065), (0.40, 0.085), (0.0, 0.085)], n=P.n(36, 12))
    P.lathe("red", (0, 0, 0), [(0.475, 0.012), (0.483, 0.016), (0.483, 0.03), (0.475, 0.034)], n=P.n(36, 12))
    if P.lod < 3:
        P.disc("crest", (0, 0.0865, 0.0), 0.0, 0.22, fit=True, n=P.n(24, 8))
    with _Sub(P, lambda p: xf(p, (0.0, 0.075, 0.40), (-35, 0, 0))):
        P.box("black", (0, 0.03, 0), (0.15, 0.03, 0.055))
        P.decal("imp2_status", (0, 0.061, 0.0), 0.22, 0.07, (0, 1, 0), up=(0, 0, -1))
    post = [(0.0, 0.085, -0.34), (0.0, 0.80, -0.38), (0.0, 1.20, -0.40), (0.0, 1.36, -0.36)]
    P.sweep("black", post, 0.04, profile=[(-1, -1), (1, -1), (1, 1), (-1, 1)], sides=4)
    P.box("grey", (0.0, 0.12, -0.34), (0.08, 0.04, 0.08))
    if P.lod < 2:
        P.box("red", (0.0, 0.75, -0.3375), (0.008, 0.40, 0.002), bottom=False)
    clamp = [(0.0, 1.36, -0.36), (0.0, 1.42, -0.32), (0.0, cy - 0.01, cz - R - 0.01)]
    P.sweep("chrome", clamp, 0.026, sides=P.n(10, 5))
    P.box("black", (0.0, cy, cz - R - 0.02), (0.07, 0.06, 0.03))


# ---------------------------------------------------------------------------------------------------------------
# armoury rack: E-11 rifles, stormtrooper helmet
# ---------------------------------------------------------------------------------------------------------------

def _e11(P):
    """E-11 blaster rifle in local space, standing on its butt at the origin: barrel up +y (muzzle 0.80), the top
    (scope side) toward +x, the power pack out of the left side toward +z."""
    g = "imp2_gunmetal"
    s = P.n(10, 5)
    # folding stock, extended: butt plate and two struts
    P.box(g, (0.02, 0.017, 0.0), (0.06, 0.013, 0.014))
    if P.lod < 3:
        P.box("black", (0.02, 0.002, 0.0), (0.058, 0.002, 0.012))
    for x in (0.055, -0.015):
        P.sweep(g, [(x, 0.03, 0.0), (0.012 if x > 0 else -0.004, 0.27, 0.0)], 0.006, sides=P.n(6, 4))
    P.box(g, (0.004, 0.27, 0.0), (0.022, 0.012, 0.016))
    # receiver with a top rail, barrel shroud with cooling rings and vent holes, flash hider
    P.sweep(g, [(0.0, 0.27, 0.0), (0.0, 0.56, 0.0)], 0.025, sides=s)
    if P.lod < 3:
        P.box("grey", (0.024, 0.43, 0.0), (0.006, 0.12, 0.008))
        P.box(g, (0.026, 0.71, 0.0), (0.008, 0.012, 0.004))                   # front sight
    P.sweep(g, [(0.0, 0.56, 0.0), (0.0, 0.73, 0.0)], 0.020, sides=s)
    if P.lod < 2:
        for k in range(4):
            y = 0.585 + 0.035 * k
            P.lathe("grey", (0, y, 0), [(0.018, -0.006), (0.0225, 0.0), (0.018, 0.006)], n=s)
            P.box("black", (0.0, y + 0.017, 0.0195), (0.006, 0.006, 0.0015))
    P.lathe(g, (0, 0.73, 0), [(0.016, 0.0), (0.018, 0.04), (0.013, 0.07), (0.0, 0.07)], n=s)
    # scope on two mounts: eyepiece at the back, objective bell forward
    for y in (0.43, 0.53):
        P.box(g, (0.036, y, 0.0), (0.012, 0.010, 0.008))
    P.sweep("black", [(0.054, 0.39, 0.0), (0.054, 0.57, 0.0)], 0.013, sides=s)
    P.lathe("black", (0.054, 0.57, 0.0), [(0.013, 0.0), (0.018, 0.025), (0.018, 0.04)], n=s)
    P.lathe("chrome", (0.054, 0.39, 0.0), [(0.0155, -0.018), (0.0155, 0.0), (0.012, 0.004)], n=s)
    P.lathe("chrome", (0.054, 0.61, 0.0), [(0.017, 0.0), (0.0185, 0.004), (0.0185, 0.012)], n=s)
    P.disc("imp2_lens", (0.054, 0.372, 0.0), 0.0, 0.0155, n=s, down=True)
    P.disc("imp2_lens", (0.054, 0.622, 0.0), 0.0, 0.0185, n=s)
    # pistol grip, trigger and guard, power pack, ejection port
    P.box(g, (-0.052, 0.355, 0.0), (0.04, 0.016, 0.013), r=(0, 0, 18))
    if P.lod < 3:
        P.box("black", (-0.032, 0.395, 0.0), (0.012, 0.004, 0.0035))
        P.box(g, (-0.046, 0.400, 0.0), (0.004, 0.022, 0.004))
        P.box(g, (-0.034, 0.421, 0.0), (0.014, 0.004, 0.004))
    P.sweep(g, [(0.0, 0.47, 0.0), (0.0, 0.47, 0.12)], 0.012, sides=s)
    P.lathe("grey", (0.0, 0.47, 0.12), [(0.0125, -0.02), (0.0135, -0.015), (0.0135, 0.0), (0.0, 0.0)], r=(90, 0, 0), n=s)
    if P.lod < 3:
        P.box("grey", (0.0, 0.50, 0.024), (0.014, 0.03, 0.003), bottom=False)


def _trooper_helmet(P):
    """Stylised stormtrooper helmet in local space: centred on the skull, facing +z, about 0.32 x 0.36 x 0.33."""
    n = P.n(20, 8)
    w = "imp2_armour"
    P.sphere(w, (0, 0.02, -0.01), 0.15, lat0=0, lat1=90, n=n)
    P.lathe(w, (0, 0, -0.01), [(0.170, -0.205), (0.175, -0.195), (0.160, -0.175), (0.150, -0.08), (0.150, 0.02)], n=n)
    P.disc("black", (0, -0.203, -0.01), 0.0, 0.168, n=n, down=True)                       # neck opening
    # brow ridge, the grey "trap" stripes at the back
    brow = [(0.153 * math.sin(math.radians(a)), 0.024, -0.01 + 0.153 * math.cos(math.radians(a))) for a in range(-60, 61, 10)]
    P.sweep(w, brow, 0.012, sides=P.n(6, 4))
    for s in (-1, 1) if P.lod < 3 else ():
        P.box("grey", (s * 0.035, 0.06, -0.153), (0.012, 0.04, 0.008), r=(-18, s * 12, 0))
    # eye lenses: dark angled teardrops, set into the face
    for s in (-1, 1):
        ex, ey = s * 0.057, -0.026
        ez = -0.01 + math.sqrt(0.150 ** 2 - ex ** 2)
        lens = [(-0.036 * s, 0.020), (0.030 * s, 0.022), (0.039 * s, -0.003), (0.012 * s, -0.031), (-0.030 * s, -0.014)]
        with _Sub(P, _frame((ex, ey, ez), v_norm((s * 0.42, 0.10, 1.0)))):
            _extrude(P, "black", lens, -0.025, 0.003, "xy")
    P.box(w, (0.0, -0.058, 0.136), (0.013, 0.042, 0.013))                                   # nose ridge
    # the "frown": a downturned grey vent band with teeth
    frown = []
    for a in range(-90, 91, 15):
        x = 0.075 * math.sin(math.radians(a))
        frown.append((x, -0.104 - 0.022 * math.sin(math.radians(a)) ** 2, -0.01 + math.sqrt(0.155 ** 2 - x * x)))
    P.sweep("grey", frown, 0.010, sides=P.n(6, 4))
    if P.lod < 2:
        for k in range(7):
            x = -0.045 + 0.015 * k
            P.box("black", (x, -0.104 - 0.022 * (x / 0.075) ** 2 + 0.002, -0.01 + math.sqrt(0.162 ** 2 - x * x)),
                  (0.003, 0.008, 0.003))
    # the breather snout below, cheek tubes, side "ears"
    P.box(w, (0.0, -0.142, 0.128), (0.036, 0.030, 0.032), r=(-18, 0, 0))
    P.box("grey", (0.0, -0.143, 0.158), (0.027, 0.021, 0.004), r=(-18, 0, 0))
    if P.lod < 2:
        for k in range(3):
            P.box("black", (0.0, -0.152 + 0.011 * k, 0.1615 - 0.0035 * k), (0.022, 0.0025, 0.002), r=(-18, 0, 0))
    for s in (-1, 1):
        a, b = (s * 0.068, -0.122, 0.125), (s * 0.118, -0.162, 0.082)
        P.sweep(w, [a, b], 0.018, sides=P.n(8, 4))
        if P.lod < 3:
            P.sphere("grey", b, 0.0185, n=P.n(8, 4))
        P.lathe("grey", (s * 0.145, -0.045, -0.01), [(0.036, 0.0), (0.036, 0.014), (0.026, 0.02), (0.0, 0.02)],
                r=(0, 0, -90 * s), n=P.n(12, 6))
        P.lathe(w, (s * 0.145, -0.045, -0.01), [(0.044, -0.004), (0.044, 0.008), (0.036, 0.012)], r=(0, 0, -90 * s),
                n=P.n(12, 6))


def imp_weapon_rack(P):
    """Armoury rack 1.35 x 1.95 m: four E-11 rifles standing in the butt tray, clamped at the barrels; a trooper
    helmet and thermal detonators on the shelf; the crest above."""
    W = 0.665
    P.box("black", (0, 0.05, -0.02), (W, 0.05, 0.20))
    P.box("grey", (0, 0.115, 0.0), (0.60, 0.015, 0.13))
    P.box("red", (0, 0.07, 0.1805), (0.62, 0.006, 0.002), bottom=False)
    P.box("black", (0, 1.0, -0.19), (0.62, 0.90, 0.025))
    P.box("grey", (0, 0.66, -0.163), (0.55, 0.47, 0.003), bottom=False)                  # back inset
    for x in (-0.42, -0.14, 0.14, 0.42):                                                # backlights behind the rifles
        P.box("imp2_light", (x, 0.64, -0.157), (0.032, 0.40, 0.003), fit=True)
    for x in (-0.31, 0.31):                                                             # rear face panels
        P.box("grey", (x, 1.0, -0.2165), (0.25, 0.75, 0.002), bottom=False)
    P.decal("imp2_stencil", (0.0, 1.05, -0.2195), 0.40, 0.48, (0, 0, -1))
    up = [(-0.22, 0.0), (0.18, 0.0), (0.18, 0.14), (0.07, 1.20), (0.07, 1.93), (-0.22, 1.93)]
    for s in (-1, 1):
        xa, xb = (0.615, W) if s > 0 else (-W, -0.615)
        _extrude(P, "black", up, xa, xb, "zy")
        P.box("red", (s * 0.64, 1.56, 0.072), (0.012, 0.34, 0.002), bottom=False)
        P.box("grey", (s * (W + 0.002), 0.95, -0.05), (0.002, 0.70, 0.08), bottom=False)
    P.box("grey", (0, 1.935, -0.075), (W + 0.01, 0.012, 0.16))                             # top cap
    P.box("red", (0, 1.935, 0.087), (0.60, 0.004, 0.002), bottom=False)
    # barrel clamp bar and the shelf
    yc = 0.90
    P.box("grey", (0, yc, -0.12), (0.60, 0.025, 0.05))
    P.box("black", (0, 1.27, -0.03), (0.615, 0.02, 0.15))
    P.box("red", (0, 1.247, 0.0), (0.58, 0.003, 0.006))
    P.box("grey", (0, 1.27, 0.122), (0.615, 0.022, 0.004))
    for k, x in enumerate((-0.42, -0.14, 0.14, 0.42)):
        with _Sub(P, lambda p, x=x, k=k: xf(v_mul(p, 1.2), (x, 0.13, -0.035), (0, 8 if k % 2 else -8, 0))):
            _e11(P)
        if P.lod < 3:
            P.box("grey", (x, 0.135, -0.035), (0.055, 0.006, 0.035))                        # butt cup
        clamp = arc((x, yc, -0.035), 0.033, 180, 360, P.n(8, 4), y=yc)
        P.sweep("chrome", [(px, yc, 2 * (-0.035) - pz) for px, _, pz in clamp], 0.008, sides=4)
    # the crest above the shelf, the helmet and detonators on it
    P.decal("crest", (0.10, 1.64, -0.1635), 0.36, 0.36, (0, 0, 1))
    P.lathe("black", (-0.36, 1.29, -0.02), [(0.08, 0.0), (0.08, 0.03), (0.05, 0.05), (0.05, 0.10), (0.0, 0.10)],
            n=P.n(14, 6))
    with _Sub(P, lambda p: xf(p, (-0.36, 1.595, -0.02), (0, 18, 0))):
        _trooper_helmet(P)
    P.box("grey", (0.42, 1.305, -0.02), (0.14, 0.015, 0.08))
    for k in range(3):
        c = (0.33 + 0.09 * k, 1.36, -0.02)
        P.sphere("chrome", c, 0.04, n=P.n(12, 6))
        if P.lod < 3:
            P.lathe("grey", c, [(0.039, -0.008), (0.0415, 0.0), (0.039, 0.008)], n=P.n(12, 6))
        if P.lod < 2:
            P.box("red", v_add(c, (0.0, 0.0, 0.041)), (0.008, 0.004, 0.002), bottom=False)
    P.box("imp2_gunmetal", (0.36, 1.40, -0.10), (0.14, 0.04, 0.045))                       # spare power cells
    P.decal("imp2_status", (0.36, 1.40, -0.0545), 0.20, 0.05, (0, 0, 1))


# ---------------------------------------------------------------------------------------------------------------
# Imperial cargo crates
# ---------------------------------------------------------------------------------------------------------------

def _crate(P, c, h, ry=0.0, lid=True, skid=0.0):
    """Imperial cargo container standing at c with half sizes h: plating, black corner caps and edge rails, skids,
    a lid seam with latches, end handles, a status panel and crest stencils front and back."""
    hx, hy, hz = h
    b = skid
    with _Sub(P, lambda p: xf(p, c, (0, ry, 0))):
        if skid:
            for sz in (-1, 1):
                P.box("black", (0, skid / 2, sz * (hz - 0.08)), (hx - 0.04, skid / 2, 0.045))
        P.box("imp2_crate", (0, b + hy, 0), (hx, hy, hz))
        for sx in (-1, 1):
            for sz in (-1, 1):
                P.box("black", (sx * (hx - 0.018), b + hy, sz * (hz - 0.018)), (0.024, hy, 0.024))
                for sy in (0, 1):
                    P.box("black", (sx * (hx - 0.04), b + sy * 2 * hy + (0.024 if sy == 0 else -0.022), sz * (hz - 0.04)),
                          (0.046, 0.024, 0.046))
        P.box("grey", (0, b + 2 * hy + 0.002, 0), (hx - 0.09, 0.002, hz - 0.09), bottom=False)
        if lid:
            ys = b + hy * 2 * 0.82
            for sz in (-1, 1):
                P.box("black", (0, ys, sz * (hz + 0.002)), (hx - 0.04, 0.012, 0.003), bottom=False)
                for lx in (-0.5, 0.5):                                                   # latches
                    P.box("black", (lx * hx, ys - 0.012, sz * (hz + 0.010)), (0.032, 0.035, 0.008))
                    P.box("chrome", (lx * hx, ys - 0.03, sz * (hz + 0.019)), (0.02, 0.012, 0.003))
            for sx in (-1, 1):
                P.box("black", (sx * (hx + 0.002), ys, 0), (0.003, 0.012, hz - 0.04), bottom=False)
        for sx in (-1, 1):                                                       # end handles on standoffs
            for dz in (-0.07, 0.07):
                P.box("grey", (sx * (hx + 0.012), b + hy * 1.25, dz), (0.012, 0.015, 0.012))
            P.sweep("chrome", [(sx * (hx + 0.030), b + hy * 1.25, -0.075), (sx * (hx + 0.030), b + hy * 1.25, 0.075)], 0.011,
                    sides=P.n(8, 4))
        for sz in (-1, 1):
            P.decal("imp2_stencil", (-hx * 0.42, b + hy * 0.95, sz * (hz + 0.003)), min(0.30, hx * 0.7),
                    min(0.36, hy * 1.2), (0, 0, sz))
        P.box("black", (hx * 0.45, b + hy * 1.05, hz + 0.008), (0.075, 0.035, 0.008))
        P.decal("imp2_status", (hx * 0.45, b + hy * 1.05, hz + 0.0165), 0.13, 0.05, (0, 0, 1))
        P.box("red", (hx * 0.45, b + hy * 1.05 - 0.05, hz + 0.003), (0.06, 0.004, 0.003), bottom=False)


def imp_cargo_crates(P):
    """A 1.1 m container on skids with a smaller one stacked askew on top, a fuel canister and a field case."""
    _crate(P, (0.0, 0.0, 0.0), (0.55, 0.30, 0.36), skid=0.04)
    top_xf = lambda p: xf(p, (-0.04, 0.64, -0.02), (0, 9.0, 0))
    _crate(P, (-0.04, 0.64, -0.02), (0.38, 0.21, 0.27), ry=9.0)
    with _Sub(P, top_xf):                                                       # a datapad left on the lid
        P.box("black", (0.14, 0.428, 0.06), (0.065, 0.006, 0.095), r=(0, 28, 0))
        P.decal("lcd", (0.14, 0.4345, 0.06), 0.10, 0.15, (0, 1, 0), up=rot((0, 0, -1), 0, 28, 0))
    _crate(P, (0.80, 0.0, 0.18), (0.20, 0.11, 0.15), ry=-24.0, lid=False)
    with _Sub(P, lambda p: xf(p, (0.80, 0.0, 0.18), (0, -24.0, 0))):                       # field case handle
        for dx in (-0.06, 0.06):
            P.box("grey", (dx, 0.23, 0.0), (0.012, 0.012, 0.012))
        P.sweep("chrome", [(-0.065, 0.24, 0.0), (-0.04, 0.27, 0.0), (0.04, 0.27, 0.0), (0.065, 0.24, 0.0)], 0.009,
                sides=P.n(6, 4))
    # fuel canister with bands, a warning stripe and a valve
    fc = (-0.80, 0.0, 0.10)
    n = P.n(20, 8)
    P.lathe("grey", fc, [(0.17, 0.0), (0.18, 0.02), (0.18, 0.70), (0.15, 0.76), (0.06, 0.78), (0.0, 0.78)], n=n)
    for y in (0.10, 0.62):
        P.lathe("black", fc, [(0.176, y - 0.03), (0.186, y - 0.025), (0.186, y + 0.025), (0.176, y + 0.03)], n=n)
    P.lathe("red", fc, [(0.176, 0.355), (0.1825, 0.36), (0.1825, 0.40), (0.176, 0.405)], n=n)
    P.decal("imp2_stencil", (fc[0], 0.25, fc[2] + 0.186), 0.16, 0.18, (0, 0, 1))
    P.lathe("chrome", (fc[0], 0.775, fc[2]), [(0.03, 0.0), (0.03, 0.065), (0.0, 0.065)], n=P.n(10, 5))
    P.sweep("chrome", [(fc[0] - 0.06, 0.83, fc[2]), (fc[0] + 0.06, 0.83, fc[2])], 0.01, sides=P.n(6, 4))
    P.sphere("red", (fc[0], 0.845, fc[2]), 0.018, n=6)
    if P.lod < 3:                                                                # a hose from the canister to the stack
        P.sweep("black", [(fc[0] + 0.03, 0.80, fc[2]), (fc[0] + 0.12, 0.86, fc[2] + 0.05), (-0.48, 0.70, 0.20),
                          (-0.56, 0.45, 0.30)], 0.012, sides=P.n(6, 4))


# ---------------------------------------------------------------------------------------------------------------
# registry
# ---------------------------------------------------------------------------------------------------------------

PIECES = {
    "imp_interrogation_rig": (imp_interrogation_rig, "interact"),
    "imp_emperor_throne": (imp_emperor_throne, "seat"),
    "imp_light_pillar": (imp_light_pillar, "lamp"),
    "imp_probe_droid": (imp_probe_droid, "decor"),
    "imp_weapon_rack": (imp_weapon_rack, "decor"),
    "imp_cargo_crates": (imp_cargo_crates, "decor"),
}
SLOTS = {"imp": {"imp2_screen": "imp2_screen", "imp2_light": "imp2_light", "imp2_lens": "imp2_lens",
                 "imp2_gunmetal": "imp2_gunmetal", "imp2_crate": "imp2_crate", "imp2_stencil": "imp2_stencil",
                 "imp2_status": "imp2_status", "imp2_armour": "imp2_armour"}}
UV = {"imp2_screen": 1.0, "imp2_light": 0.5, "imp2_lens": 0.06, "imp2_gunmetal": 0.3, "imp2_crate": 1.0,
      "imp2_stencil": 1.0, "imp2_status": 1.0, "imp2_armour": 0.6}
SMOOTH = ("imp2_lens", "imp2_gunmetal", "imp2_armour")
COLORS = {}
