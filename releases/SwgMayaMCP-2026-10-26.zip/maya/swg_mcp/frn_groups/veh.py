"""Vessel cabin fittings (group `veh`): the transport cabin's in-flight entertainment hardware, in the stock ship
interior look (grey panelling, beige trim). Host half (materials, names): examples/frn_sets/veh.py.

  veh_wall_monitor     screen  a slim 16:9 display on a wall bracket; only its glass takes the video (slot "video")
  veh_ceiling_speaker  decor   a flush round ceiling speaker: perforated grille in a beige trim ring

Maya space: y up, front +z. The monitor's back is the wall plane z = 0, its origin on the floor under it (the
screen's centre 1.9 m up). The speaker hangs from the ceiling plane y = 0, everything below it; it faces -y."""
from __future__ import annotations

from ..furniture import _frame_ring

SW, SH, YC = 1.44, 0.81, 1.9           # monitor glass (16:9) and the height of its centre above the floor
GAP, DEPTH = 0.02, 0.04                # housing off the wall (the bracket shows in the gap), housing depth
BEZEL = 0.022                          # bezel face proud of the housing front


def veh_wall_monitor(P):
    """A slim wall-mounted display: graphite housing on a bracket, a thin bevelled bezel, beige status strip."""
    front = GAP + DEPTH                                                         # housing front plane
    face = front + BEZEL                                                        # bezel face plane
    _frame_ring(P, "bezel", front, YC, 0.0, SW, SH,
                [(0.0, 0.0), (0.0, 0.012), (0.01, BEZEL), (0.035, BEZEL), (0.04, BEZEL - 0.006)], axis="z", uscale=0.4)
    P.box("housing", (0, YC, GAP + DEPTH / 2), (SW / 2 + 0.03, SH / 2 + 0.03, DEPTH / 2))
    P.decal("video", (0, YC, face - 0.0055), SW, SH, (0, 0, 1))             # glass, just behind the sight edge
    P.box("trim", (0, YC - SH / 2 - 0.022, face + 0.002), (0.18, 0.005, 0.002), bottom=False)     # status strip
    P.box("lamp", (SW / 2 - 0.01, YC - SH / 2 - 0.022, face + 0.0025), (0.008, 0.004, 0.0025), bottom=False)
    # wall bracket: a plate on the wall and two arms across the gap into the housing
    P.box("housing", (0, YC, 0.004), (0.17, 0.13, 0.004))
    for sx in (-1, 1):
        P.box("trim", (sx * 0.1, YC, GAP / 2 + 0.004), (0.016, 0.11, GAP / 2 - 0.002))


def detail_veh_wall_monitor(P):
    if P.lod < 2:
        # vent slots along the top of the housing
        for k in range(10):
            P.box("trim", (-0.45 + 0.1 * k, YC + SH / 2 + 0.031, GAP + DEPTH / 2), (0.03, 0.0015, 0.012), bottom=False)


def veh_ceiling_speaker(P):
    """Flush ceiling speaker: a beige trim ring round a perforated grille, facing down."""
    r = 0.16
    P.lathe("trim", (0, 0, 0), [(r - 0.012, -0.036), (r, -0.03), (r + 0.03, -0.012), (r + 0.03, 0.0)],
            n=P.n(28, 10))
    P.disc("grille", (0, -0.033, 0), 0.0, r - 0.008, n=P.n(28, 10), down=True, fit=True)


PIECES = {
    "veh_wall_monitor": (veh_wall_monitor, "screen"),
    "veh_ceiling_speaker": (veh_ceiling_speaker, "decor"),
}
DETAILS = {"veh_wall_monitor": detail_veh_wall_monitor}
SLOTS = {"veh": {"bezel": "veh_bezel", "housing": "veh_housing", "trim": "veh_trim", "lamp": "veh_lamp",
                 "video": "veh_monitor_screen", "grille": "veh_speaker_grille"}}
UV = {"bezel": 0.4, "housing": 0.5, "trim": 0.3, "lamp": 0.1, "grille": 0.3}
COLORS = {"veh": (0.42, 0.43, 0.45)}
