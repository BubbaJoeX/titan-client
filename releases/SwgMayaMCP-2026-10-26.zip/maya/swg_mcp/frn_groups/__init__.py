"""Themed furniture groups beyond the first three sets: one module per group, merged into furniture.py's
registries by register(). A group module defines

  PIECES  {piece: (builder(P), kind)}     kind: seat / interact / lamp / table / decor / cabinet / bed
  SLOTS   {theme: {slot: material key}}    theme = the piece-name prefix; material keys are examples/frn_sets MATS
  UV      {slot: metres per texture tile}  new slot names only (existing names keep their scale)
  SMOOTH  (slot, ...)                      slots soft-edged at 70 degrees (fabric, organic, polished round parts)
  COLORS  {theme: (r, g, b)}               Maya viewport colour of the theme's untextured materials
  DETAILS {piece: detail(P)}               optional second pass, run after the builder

The host-side half of each group (materials, names and descriptions, lights) is examples/frn_sets/<group>.py."""
from __future__ import annotations

import importlib
import sys
import traceback

GROUPS = ["hutt2", "imp2", "sith", "jedi", "nab", "wok", "bsp", "can", "veh"]
ERRORS = {}          # group -> error text, for groups that failed to import (missing or broken)


def register(ns):
    ERRORS.clear()
    for g in GROUPS:
        full = f"{__name__}.{g}"
        try:
            m = importlib.reload(sys.modules[full]) if full in sys.modules else importlib.import_module(full)
        except ModuleNotFoundError as e:
            if e.name == full:
                ERRORS[g] = "missing"
                continue
            ERRORS[g] = traceback.format_exc(limit=-3)
            continue
        except Exception as e:                       # noqa: BLE001 - keep the other groups usable
            ERRORS[g] = traceback.format_exc(limit=-3)
            continue
        ns["PIECES"].update(m.PIECES)
        ns["DETAILS"].update(getattr(m, "DETAILS", {}))
        for theme, slots in m.SLOTS.items():
            ns["SLOTS"].setdefault(theme, {}).update(slots)
        ns["COLORS"].update(getattr(m, "COLORS", {}))
        for slot, scale in getattr(m, "UV", {}).items():
            ns["UV"].setdefault(slot, scale)
        ns["SMOOTH_SLOTS"] = tuple(ns["SMOOTH_SLOTS"]) + tuple(s for s in getattr(m, "SMOOTH", ()) if s not in ns["SMOOTH_SLOTS"])
