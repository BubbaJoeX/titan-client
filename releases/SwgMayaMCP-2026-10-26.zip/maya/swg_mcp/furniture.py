"""Themed furniture sets (Hutt palace, Rebel Alliance, Galactic Empire) - runs inside Maya with SwgMayaEditor.

Five pieces per theme, two of them signature pieces unlike any stock furniture:

  hutt_throne        signature  Hutt lounging throne: two-tier carved dais, velvet seat, sweeping silk bolster,
                                carved arch backboard with a brass sunburst crown              seat (foot)
  hutt_sarlacc_bed   signature  round bed inside a Sarlacc maw: fleshy lip, two rows of bone teeth,
                                tentacles, sunken velvet mattress, tongue rug at the mouth      bed (foot + bed)
  hutt_hookah                   palace water pipe: green-water glass globe in a brass cage, glowing coals,
                                three velvet hoses, round palace rug
  hutt_pouf                     tufted velvet pouf on a brass claw-foot ring                    seat
  hutt_table                    low oval banquet table, carved legs, brass banding, Jabba's gorg jar
  reb_xwing_chair    signature  salvaged X-wing cockpit section: pilot seat, raised canopy, astromech dome,
                                instrument deck with live screens over the footwell              seat
  reb_holotable      signature  Yavin war-room table projecting the Death Star (dish, trench, light cone)
  reb_bunk                      Echo Base survival cot with a thermal hood, footlocker, helmet   bed
  reb_crate_bench               bench on two supply crates, quilted cushion, armour-plate back   seat
  reb_locker                    Alliance gear locker: one door open on rifles, helmet, flight suit
  imp_pod            signature  meditation pod: black clamshell, the upper shell raised on chrome rams,
                                toothed rims, red-lit interior, leather seat                     seat
  imp_sd_table       signature  Star Destroyer conference table with a holographic bridge tower
  imp_bunk                      officer's bunk: gloss frame, red under-glow, crest headboard     bed
  imp_chair                     officer's swivel chair, winged high back, red-lit armrests       seat
  imp_holo_crest                pedestal projecting the Imperial crest, two holo TIE fighters orbiting

Conventions (Maya space; the exporter mirrors X): y up, the piece stands on its origin, its front faces +z.
Seats carry the stock chair hardpoint `foot` on the floor 0.17-0.18 m in front of the seat edge (stock
frn_all_mdrn_chair_s01 / couch_lg_s1 measure the same); the sit script puts the player's feet there and the
stock sitting_chair pose (its transition slides the root 0.38 m back) lands the hips on a 0.46 m seat. Beds also
carry `bed` (see clientGame GamePlaybackScript): once seated the client snaps the player there facing +z and plays
the stock bed animations on the loop track, which lay the body across +z: centre 0.85 m ahead, the underside
0.34 m up, the head toward Maya +x (engine -x), so mattresses top out at ~0.36 m.
Like stock furniture the .lod has no collision (NULL), only the extent box, and 4 detail levels."""

from __future__ import annotations

import math
import os

import maya.cmds as cmds
import maya.mel as mel

from . import pob_builder as pb

PREFIX = "frn_titan_"
DET = (1.0, 0.6, 0.38, 0.22)            # tessellation per LOD (l0..l3)
LOD_RANGES = (12.0, 30.0, 80.0)         # metres where l0 -> l1 -> l2 -> l3 (stock chair: 15 / 30 / 100)
SOFT = {"default": 40.0}                 # polySoftEdge angle per slot (fabric/flesh smoother)
SMOOTH_SLOTS = ("velvet", "silk", "flesh", "quilt", "blanket", "canvas", "leather", "linen", "pillow", "bone",
                "brass", "chrome", "r2", "holo", "gorg", "glass")
# material slot -> material key in examples/frn_materials.py (an absolute .sht in the export tree), or a stock
# shader tree path; metres per texture tile for world-mapped faces
UV = {"sandstone": 1.2, "frieze": 0.6, "velvet": 0.6, "silk": 0.5, "brass": 0.4, "wood": 0.8, "flesh": 0.9,
      "bone": 0.3, "coals": 0.4, "gorg": 0.6, "olive": 1.0, "hull": 1.2, "quilt": 0.6, "canvas": 0.5,
      "blanket": 0.8, "console": 0.5, "black": 1.0, "grey": 1.2, "white": 0.8, "leather": 0.6, "chrome": 0.5,
      "linen": 0.7, "pillow": 0.5, "gunmetal": 0.4, "glass": 1.0, "holo": 0.5, "red": 1.0}
SHADER_ROOT = None                      # set by configure(): the export root holding shader/frn_titan_*.sht


def configure(export_root):
    global SHADER_ROOT
    SHADER_ROOT = export_root.replace("\\", "/")


# ---------------------------------------------------------------------------------------------------------------
# vector helpers
# ---------------------------------------------------------------------------------------------------------------

def v_add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def v_sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def v_mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def v_dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def v_cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def v_len(a):
    return math.sqrt(v_dot(a, a))


def v_norm(a):
    l_ = v_len(a) or 1.0
    return (a[0] / l_, a[1] / l_, a[2] / l_)


def rot(p, rx=0.0, ry=0.0, rz=0.0):
    """Rotate p by rx, then ry, then rz degrees about the origin (x right, y up, z front)."""
    x, y, z = p
    if rx:
        a = math.radians(rx)
        y, z = y * math.cos(a) - z * math.sin(a), y * math.sin(a) + z * math.cos(a)
    if rz:
        a = math.radians(rz)
        x, y = x * math.cos(a) - y * math.sin(a), x * math.sin(a) + y * math.cos(a)
    if ry:
        a = math.radians(ry)
        x, z = x * math.cos(a) + z * math.sin(a), -x * math.sin(a) + z * math.cos(a)
    return (x, y, z)


def xf(p, c=(0, 0, 0), r=(0, 0, 0), pivot=(0, 0, 0)):
    """Rotate about `pivot` by r (degrees), then translate by c."""
    q = rot(v_sub(p, pivot), *r)
    return v_add(v_add(q, pivot), c)


# ---------------------------------------------------------------------------------------------------------------
# piece: per-slot mesh accumulators, primitives with explicit UVs, hardpoints
# ---------------------------------------------------------------------------------------------------------------

class F:
    def __init__(self, lod=0):
        self.lod = lod
        self.acc = {}
        self.hardpoints = []             # (name, (x, y, z))
        self.xform = None                # optional point transform applied to everything added (sub-assemblies)

    def A(self, slot):
        if slot not in self.acc:
            self.acc[slot] = pb.MeshAccumulator(UV.get(slot.split(":")[0], 1.0))
        return self.acc[slot]

    def n(self, k, lo=4):
        return max(lo, int(round(k * DET[self.lod])))

    def T(self, p):
        return self.xform(p) if self.xform else p

    # -- faces ----------------------------------------------------------------------------------------------
    def poly(self, slot, pts, uvs, want):
        pts = [self.T(p) for p in pts]
        if self.xform:
            o = self.T((0.0, 0.0, 0.0))
            want = v_sub(self.T(want), o)
        n = pb._normal3(pts)
        if v_dot(n, want) < 0:
            pts, uvs = pts[::-1], uvs[::-1]
        self.A(slot).poly(pts, uvs)

    def flat(self, slot, pts, want, scale=None, fit=False):
        """Planar polygon, UVs projected in its own plane (world scaled, or fit 0..1 when fit=True)."""
        n = v_norm(want)
        up = (0.0, 1.0, 0.0) if abs(n[1]) < 0.9 else (0.0, 0.0, -1.0)
        t = v_norm(v_cross(up, n))
        b = v_cross(n, t)
        s = scale or UV.get(slot.split(":")[0], 1.0)
        uv = [(v_dot(p, t) / s, v_dot(p, b) / s) for p in pts]
        if fit:
            us, vs = [u for u, _ in uv], [v for _, v in uv]
            du, dv = (max(us) - min(us)) or 1.0, (max(vs) - min(vs)) or 1.0
            uv = [((u - min(us)) / du, (v - min(vs)) / dv) for u, v in uv]
        self.poly(slot, pts, uv, want)

    def grid(self, slot, P, U, V, want, closed_u=False):
        """Quads over a grid of points P[i][j] (i along u, j along v) with UVs; want(p) = outward direction."""
        ni, nj = len(P), len(P[0])
        for i in range(ni - (0 if closed_u else 1)):
            i1 = (i + 1) % ni
            for j in range(nj - 1):
                q = [P[i][j], P[i1][j], P[i1][j + 1], P[i][j + 1]]
                uv = [(U[i][j], V[i][j]), (U[i1][j] if i1 else U[i][j] + (U[i][j] - U[i - 1][j] if i else 1.0), V[i1][j]),
                      (U[i1][j + 1] if i1 else U[i][j + 1] + (U[i][j + 1] - U[i - 1][j + 1] if i else 1.0), V[i1][j + 1]),
                      (U[i][j + 1], V[i][j + 1])]
                c = tuple(sum(p[k] for p in q) / 4 for k in range(3))
                if v_len(pb._normal3(q)) < 1e-12 and len(set(q)) < 3:
                    continue
                self.poly(slot, q, uv, want(c))

    # -- primitives -----------------------------------------------------------------------------------------
    def box(self, slot, c, h, r=(0, 0, 0), bottom=True, top=True, fit=False):
        """Oriented box: centre c, half sizes h, rotation r (degrees)."""
        corner = lambda sx, sy, sz: xf((sx * h[0], sy * h[1], sz * h[2]), c, r)
        faces = [((1, 0, 0), [(1, -1, -1), (1, 1, -1), (1, 1, 1), (1, -1, 1)]),
                 ((-1, 0, 0), [(-1, -1, -1), (-1, 1, -1), (-1, 1, 1), (-1, -1, 1)]),
                 ((0, 0, 1), [(-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)]),
                 ((0, 0, -1), [(-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1)])]
        if top:
            faces.append(((0, 1, 0), [(-1, 1, -1), (1, 1, -1), (1, 1, 1), (-1, 1, 1)]))
        if bottom:
            faces.append(((0, -1, 0), [(-1, -1, -1), (1, -1, -1), (1, -1, 1), (-1, -1, 1)]))
        for nrm, cs in faces:
            pts = [corner(*k) for k in cs]
            self.flat(slot, pts, rot(nrm, *r), fit=fit)

    def rbox(self, slot, c, h, rad, r=(0, 0, 0), puff=0.0, seg=None, bottom=True):
        """Rounded box / cushion: half sizes h, edge radius rad, faces bulging by `puff`, rotation r."""
        m = seg or self.n(5, 2)
        inner = [max(1e-4, h[k] - rad) for k in range(3)]

        def surf(p):                                   # cube point (-1..1) -> rounded surface
            q = [p[k] * h[k] for k in range(3)]
            cl = [max(-inner[k], min(inner[k], q[k])) for k in range(3)]
            d = v_sub(q, cl)
            dl = v_len(d)
            nrm = v_norm(d) if dl > 1e-9 else (0.0, 1.0, 0.0)
            out = v_add(cl, v_mul(nrm, rad))
            if puff:
                bul = (1 - p[0] ** 2) * (1 - p[1] ** 2) * (1 - p[2] ** 2) * 4
                out = v_add(out, v_mul(nrm, puff * max(0.0, bul)))
            return xf(out, c, r)

        # nonuniform grid: dense near the edges so the rounds stay round
        ts = [math.copysign(abs(t) ** 0.7, t) for t in (-1 + 2 * k / (m * 2) for k in range(m * 2 + 1))]
        faces = [(0, 1, 2, 1), (0, 1, 2, -1), (0, 2, 1, 1), (0, 2, 1, -1), (2, 1, 0, 1), (2, 1, 0, -1)]
        for a, b, fixed, s in faces:
            if fixed == 1 and s < 0 and not bottom:
                continue
            P, U, V = [], [], []
            for ta in ts:
                row, ur, vr = [], [], []
                for tb in ts:
                    p = [0.0, 0.0, 0.0]
                    p[a], p[b], p[fixed] = ta, tb, float(s)
                    row.append(surf(p))
                    ur.append(ta * h[a] / UV.get(slot.split(":")[0], 1.0))
                    vr.append(tb * h[b] / UV.get(slot.split(":")[0], 1.0))
                P.append(row)
                U.append(ur)
                V.append(vr)
            ctr = xf((0, 0, 0), c, r)
            self.grid(slot, P, U, V, lambda q, ctr=ctr: v_sub(q, ctr))

    def lathe(self, slot, c, prof, n=None, a0=0.0, a1=360.0, inside=False, utiles=None, vscale=None, r=(0, 0, 0)):
        """Surface of revolution round the local y axis through c: prof [(radius, y)] bottom to top.
        UVs: u = angle (utiles repeats round, default by circumference), v = profile length / vscale."""
        n = n or self.n(24, 6)
        full = abs(a1 - a0) >= 359.999
        cnt = n if full else n + 1
        L = [0.0]
        for k in range(len(prof) - 1):
            L.append(L[-1] + math.hypot(prof[k + 1][0] - prof[k][0], prof[k + 1][1] - prof[k][1]))
        s = vscale or UV.get(slot.split(":")[0], 1.0)
        rmax = max(p[0] for p in prof) or 0.1
        ut = utiles or max(1, round(2 * math.pi * rmax * abs(a1 - a0) / 360.0 / s))
        P, U, V = [], [], []
        for i in range(cnt):
            a = math.radians(a0 + (a1 - a0) * i / n)
            P.append([xf((rr * math.cos(a), yy, rr * math.sin(a)), c, r) for rr, yy in prof])
            U.append([ut * i / n] * len(prof))
            V.append([L[k] / s for k in range(len(prof))])
        # outward = the profile's right-hand normal walking bottom -> top: (dy, -dr) in the (radial, y) plane
        o = xf((0, 0, 0), c, r)
        for i in range(n if full else cnt - 1):
            i1 = (i + 1) % cnt
            amid = math.radians(a0 + (a1 - a0) * (i + 0.5) / n)
            for j in range(len(prof) - 1):
                dr, dy = prof[j + 1][0] - prof[j][0], prof[j + 1][1] - prof[j][1]
                if abs(dr) + abs(dy) < 1e-9:
                    continue
                nl = (dy * math.cos(amid), -dr, dy * math.sin(amid))
                w = v_sub(xf(nl, c, r), o)
                if inside:
                    w = v_mul(w, -1.0)
                q = [P[i][j], P[i1][j], P[i1][j + 1], P[i][j + 1]]
                ui1 = U[i1][j] if i1 else ut
                uv = [(U[i][j], V[i][j]), (ui1, V[i1][j]), (ui1, V[i1][j + 1]), (U[i][j + 1], V[i][j + 1])]
                self.poly(slot, q, uv, w)

    def disc(self, slot, c, r0, r1, n=None, down=False, fit=False, r=(0, 0, 0)):
        """Flat disc / ring at c (local y up), planar UVs (fit: the disc spans the texture once)."""
        n = n or self.n(24, 6)
        want = v_sub(xf((0, -1 if down else 1, 0), c, r), xf((0, 0, 0), c, r))
        s = UV.get(slot.split(":")[0], 1.0)
        for i in range(n):
            a, b = 2 * math.pi * i / n, 2 * math.pi * (i + 1) / n
            loc = [(r1 * math.cos(a), 0, r1 * math.sin(a)), (r1 * math.cos(b), 0, r1 * math.sin(b))]
            loc += [(r0 * math.cos(b), 0, r0 * math.sin(b)), (r0 * math.cos(a), 0, r0 * math.sin(a))] if r0 > 1e-6 else [(0, 0, 0)]
            uv = [((p[0] / (2 * r1) + 0.5), (0.5 - p[2] / (2 * r1))) if fit else (p[0] / s, -p[2] / s) for p in loc]
            self.poly(slot, [xf(p, c, r) for p in loc], uv, want)

    def sphere(self, slot, c, rad, lat0=-90.0, lat1=90.0, n=None, sy=1.0, inside=False, r=(0, 0, 0), utiles=None):
        rows = max(2, self.n(12, 4) * int(abs(lat1 - lat0)) // 180 or 2)
        prof = [(rad * math.cos(math.radians(lat0 + (lat1 - lat0) * k / rows)),
                 rad * sy * math.sin(math.radians(lat0 + (lat1 - lat0) * k / rows))) for k in range(rows + 1)]
        self.lathe(slot, c, prof, n=n, inside=inside, r=r, utiles=utiles)

    def sweep(self, slot, path, radius, sides=None, closed=False, caps=True, profile=None, vscale=None, twist_up=None):
        """Tube along a polyline (rotation-minimising frames). radius: float or f(t); profile: [(x, y)] unit
        outline (default a circle) scaled by radius."""
        sides = sides or self.n(10, 4)
        rad = radius if callable(radius) else (lambda t, rr=radius: rr)
        prof = profile or [(math.cos(2 * math.pi * k / sides), math.sin(2 * math.pi * k / sides)) for k in range(sides)]
        m = len(path)
        tang = []
        for k in range(m):
            if closed:
                a, b = path[k - 1], path[(k + 1) % m]
            else:
                a, b = path[max(0, k - 1)], path[min(m - 1, k + 1)]
            tang.append(v_norm(v_sub(b, a)))
        up0 = twist_up or ((0.0, 1.0, 0.0) if abs(tang[0][1]) < 0.9 else (1.0, 0.0, 0.0))
        nrm = v_norm(v_cross(v_cross(tang[0], up0), tang[0]))
        frames = []
        for k in range(m):
            if k:
                nrm = v_norm(v_sub(nrm, v_mul(tang[k], v_dot(nrm, tang[k]))))
            frames.append((nrm, v_cross(tang[k], nrm)))
        L = [0.0]
        for k in range(1, m):
            L.append(L[-1] + v_len(v_sub(path[k], path[k - 1])))
        tot = L[-1] or 1.0
        s = vscale or UV.get(slot.split(":")[0], 1.0)
        rings = []
        for k in range(m):
            nk, bk = frames[k]
            rr = rad(L[k] / tot)
            rings.append([v_add(path[k], v_add(v_mul(nk, px * rr), v_mul(bk, py * rr))) for px, py in prof])
        P = [[rings[k][j] for k in range(m)] + ([rings[0][j]] if closed else []) for j in range(len(prof))]
        U = [[j / len(prof)] * len(P[0]) for j in range(len(prof))]
        V = [[L[k] / s for k in range(m)] + ([tot / s] if closed else []) for _ in range(len(prof))]
        centres = path + ([path[0]] if closed else [])

        def want(q):
            best = min(range(len(centres)), key=lambda k: v_len(v_sub(q, centres[k])))
            return v_sub(q, centres[best])
        self.grid(slot, P, U, V, want, closed_u=True)
        if caps and not closed:
            for k, sgn in ((0, -1), (m - 1, 1)):
                if rad(L[k] / tot) > 1e-4:
                    self.flat(slot, rings[k], v_mul(tang[k], sgn))

    def loft(self, slot, rings, closed=True, caps=(True, True), vscale=None, inside=False):
        """Surface through rings of equal point count (each ring a closed loop when closed=True)."""
        m, nr = len(rings), len(rings[0])
        L = [0.0]
        for k in range(1, m):
            ca = tuple(sum(p[i] for p in rings[k]) / nr for i in range(3))
            cb = tuple(sum(p[i] for p in rings[k - 1]) / nr for i in range(3))
            L.append(L[-1] + v_len(v_sub(ca, cb)))
        s = vscale or UV.get(slot.split(":")[0], 1.0)
        per = sum(v_len(v_sub(rings[0][j], rings[0][j - 1])) for j in range(nr)) or 1.0
        P = [[rings[k][j] for k in range(m)] for j in range(nr)]
        U = [[j * per / nr / s] * m for j in range(nr)]
        V = [[L[k] / s for k in range(m)] for _ in range(nr)]
        cents = [tuple(sum(p[i] for p in rg) / nr for i in range(3)) for rg in rings]

        def want(q):
            best = min(range(m), key=lambda k: v_len(v_sub(q, cents[k])))
            d = v_sub(q, cents[best])
            return v_mul(d, -1.0) if inside else d
        self.grid(slot, P, U, V, want, closed_u=closed)
        if closed:
            for k, other in ((0, 1), (m - 1, m - 2)):
                if caps[0 if k == 0 else 1]:
                    self.flat(slot, rings[k], v_sub(cents[k], cents[other]))

    def prism(self, slot, ring, y0, y1, top=True, bottom=False, side_slot=None, side_vscale=None):
        """Vertical prism over a plan ring [(x, z)] (convex or not); sides UV'd along the perimeter."""
        ss = side_slot or slot
        s = side_vscale or UV.get(ss.split(":")[0], 1.0)
        n = len(ring)
        cx, cz = sum(p[0] for p in ring) / n, sum(p[1] for p in ring) / n
        acc = 0.0
        for i in range(n):
            (ax, az), (bx, bz) = ring[i], ring[(i + 1) % n]
            ln = math.hypot(bx - ax, bz - az)
            nx, nz = (bz - az), -(bx - ax)
            if nx * ((ax + bx) / 2 - cx) + nz * ((az + bz) / 2 - cz) < 0:
                nx, nz = -nx, -nz
            pts = [(ax, y0, az), (bx, y0, bz), (bx, y1, bz), (ax, y1, az)]
            uv = [(acc / s, 0.0), ((acc + ln) / s, 0.0), ((acc + ln) / s, (y1 - y0) / s), (acc / s, (y1 - y0) / s)]
            self.poly(ss, pts, uv, (nx, 0.0, nz))
            acc += ln
        if top:
            self.flat(slot, [(x, y1, z) for x, z in ring], (0, 1, 0))
        if bottom:
            self.flat(slot, [(x, y0, z) for x, z in ring], (0, -1, 0))

    def cone(self, slot, base, tip, rad, n=None):
        """Cone (spike, tooth, finial) from a disc of radius rad at `base` to the point `tip`."""
        n = n or self.n(8, 4)
        ax = v_norm(v_sub(tip, base))
        t = v_norm(v_cross(ax, (0, 1, 0) if abs(ax[1]) < 0.9 else (1, 0, 0)))
        b = v_cross(ax, t)
        ring = [v_add(base, v_add(v_mul(t, rad * math.cos(2 * math.pi * k / n)), v_mul(b, rad * math.sin(2 * math.pi * k / n))))
                for k in range(n)]
        for k in range(n):
            p, q = ring[k], ring[(k + 1) % n]
            mid = v_mul(v_add(p, q), 0.5)
            self.poly(slot, [p, q, tip], [(k / n, 0.0), ((k + 1) / n, 0.0), ((k + 0.5) / n, 1.0)], v_sub(mid, base))
        self.flat(slot, ring, v_mul(ax, -1.0))

    def decal(self, slot, c, w, h, normal, up=(0, 1, 0)):
        """A w x h quad at c facing `normal`, the texture fit once (crests, screens, labels)."""
        n = v_norm(normal)
        t = v_norm(v_cross(up, n))
        b = v_cross(n, t)
        pts = [v_add(c, v_add(v_mul(t, sx * w / 2), v_mul(b, sy * h / 2))) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
        self.poly(slot, pts, [(0, 0), (1, 0), (1, 1), (0, 1)], n)


def arc(c, rad, a0, a1, n, y=None):
    """Points on a horizontal arc round c (degrees, 0 = +x, 90 = +z)."""
    return [(c[0] + rad * math.cos(math.radians(a0 + (a1 - a0) * k / n)), c[1] if y is None else y,
             c[2] + rad * math.sin(math.radians(a0 + (a1 - a0) * k / n))) for k in range(n + 1)]


def ellipse(a, b, n, cx=0.0, cz=0.0):
    return [(cx + a * math.cos(2 * math.pi * k / n), cz + b * math.sin(2 * math.pi * k / n)) for k in range(n)]


def smoothstep(e0, e1, x):
    t = max(0.0, min(1.0, (x - e0) / (e1 - e0)))
    return t * t * (3 - 2 * t)


def seat_hardpoint(P, seat_front_z, x=0.0):
    P.hardpoints.append(("foot", (x, 0.0, seat_front_z + 0.175)))


def bed_hardpoints(P, body_centre):
    """`bed` 0.85 m in front (-z) of the body centre, facing +z: the client snaps the player there once seated
    and plays the stock bed animations, which lay the body across +z with its centre 0.85 m ahead. `foot` with
    it (chairs need it to be sat on at all)."""
    x, _, z = body_centre
    P.hardpoints.append(("foot", (x, 0.0, z - 0.85)))
    P.hardpoints.append(("bed", (x, 0.0, z - 0.85)))


# Station activities (clientGame GamePlaybackScript cs_stations): a piece carrying `foot` and one of these
# hardpoints is "sat on" (/sit, or Sit in the radial menu), and once the sitting posture arrives the client drops
# the chair pose, snaps the player onto the hardpoint (feet on the floor there, facing the hardpoint's +z) and loops
# the activity until /stand.
STATIONS = ("meditate", "kneel", "gong", "wipe", "pour", "terminal", "tan", "console")


def station_hardpoints(P, activity, spot, yaw=180.0):
    """The station spot on the floor, the player facing yaw (degrees about y; 180 = toward -z, the usual case of
    a player standing in front of the piece and facing it). `foot` goes with it (chairs need it to be sat on)."""
    assert activity in STATIONS, activity
    x, _, z = spot
    # `foot` faces the same way: the sit script's alignment turns the player to it, and a foot facing +z left the
    # player facing away on the meditation mat (whose spot is at the origin) once the alignment had finished
    P.hardpoints.append(("foot", (x, 0.0, z), (0.0, yaw, 0.0)))
    P.hardpoints.append((activity, (x, 0.0, z), (0.0, yaw, 0.0)))


def light_hardpoint(P, pos, name="light"):
    """Where the piece's light sits (the client data file hangs the light on it): the bulb, flame or glow core."""
    P.hardpoints.append((name, tuple(pos)))


# ---------------------------------------------------------------------------------------------------------------
# Hutt palace
# ---------------------------------------------------------------------------------------------------------------

def hutt_throne(P):
    """Hutt lounging throne. Seat 0.46 m, its front edge at z 0.53 -> foot at 0.705."""
    n = P.n(28, 10)
    # two-tier D-shaped dais: back half a circle, front a shallow curve (the feet stay on the floor in front)
    def dplan(R, front):
        back = [(R * math.cos(math.radians(a)), -0.15 + R * math.sin(math.radians(a))) for a in
                [180 + 180 * k / n for k in range(n + 1)]]
        rc = 0.22                                         # rounded front corners
        corner = lambda cx, a0: [(cx + rc * math.cos(math.radians(a0 + 90 * k / 4)),
                                  front - rc + rc * math.sin(math.radians(a0 + 90 * k / 4))) for k in range(5)]
        return back + corner(R - rc, 0) + corner(-R + rc, 90)
    P.prism("sandstone", dplan(1.82, 0.52), 0.0, 0.12, side_slot="frieze", side_vscale=0.12)
    P.prism("sandstone", dplan(1.68, 0.40), 0.12, 0.26, side_slot="frieze", side_vscale=0.14)
    # seat cushion and front roll
    P.rbox("velvet", (0, 0.36, 0.06), (0.98, 0.10, 0.47), 0.08, puff=0.025)
    P.sweep("silk", [(-0.98, 0.43, 0.52), (0.98, 0.43, 0.52)], 0.045, caps=True)
    # sweeping bolster: armrests at the front corners rising into the big back roll
    pts = []
    for k in range(P.n(24, 8) + 1):
        a = math.radians(180 + 180 * k / P.n(24, 8))
        bk = math.sin(a - math.pi) ** 2 if False else (math.sin(-a)) ** 1.0      # 0 at the sides, 1 at the back
        bk = max(0.0, -math.sin(a))
        pts.append((1.06 * math.cos(a), 0.56 + 0.26 * bk, -0.02 + 0.62 * math.sin(a) * 1.0))
    pts = [(-1.06, 0.52, 0.42)] + pts + [(1.06, 0.52, 0.42)]
    P.sweep("silk", pts, lambda t: 0.16 + 0.12 * math.sin(math.pi * t) ** 2, vscale=0.5)
    # carved arch backboard with brass edge and sunburst crown
    W, H0, H1, zb = 1.25, 0.26, 1.45, -0.86
    arch = [(-W, H0)] + [(W * math.cos(math.radians(180 - 180 * k / n)), H1 - 0.55 + 0.55 * math.sin(math.radians(180 - 180 * k / n)) + 0.0)
                         for k in range(n + 1)] + [(W, H0)]
    front = [(x, y, zb + 0.06) for x, y in arch]
    back = [(x, y, zb - 0.06) for x, y in arch]
    P.flat("wood", front, (0, 0, 1))
    P.flat("wood", back, (0, 0, -1))
    for i in range(len(arch) - 1):
        a, b = arch[i], arch[i + 1]
        q = [(a[0], a[1], zb + 0.06), (b[0], b[1], zb + 0.06), (b[0], b[1], zb - 0.06), (a[0], a[1], zb - 0.06)]
        nx, ny = (b[1] - a[1]), -(b[0] - a[0])
        if nx * ((a[0] + b[0]) / 2) + ny * ((a[1] + b[1]) / 2 - 0.9) < 0:
            nx, ny = -nx, -ny
        P.flat("wood", q, (nx, ny, 0))
    P.sweep("brass", [(x, y, zb + 0.07) for x, y in arch[1:-1]], 0.035)
    top = (0.0, H1 + 0.0, zb)
    for k in range(9):
        a = math.radians(20 + 140 * k / 8)
        base = (0.9 * W * math.cos(a), H1 - 0.55 + 0.55 * math.sin(a) * 0.98 + 0.02, zb)
        tip = v_add(base, (0.30 * math.cos(a), (0.42 if k % 2 == 0 else 0.26) * math.sin(a) + 0.05, 0.0))
        P.cone("brass", base, tip, 0.045)
    P.lathe("brass", (0, H1 - 0.12, zb + 0.10), [(0.0, -0.02), (0.22, 0.0), (0.24, 0.03), (0.16, 0.06), (0.0, 0.07)],
            r=(90, 0, 0))
    if P.lod < 2:
        P.sphere("coals", (0, H1 - 0.12, zb + 0.18), 0.07)
    # brass finial posts at the front corners of the dais
    for sx in (-1, 1):
        x, z = sx * 1.45, 0.20
        P.lathe("brass", (x, 0.26, z), [(0.0, 0.0), (0.10, 0.0), (0.10, 0.05), (0.05, 0.10), (0.045, 0.62),
                                       (0.08, 0.66), (0.0, 0.68)])
        P.sphere("brass", (x, 0.78, z), 0.10)
        P.cone("brass", (x, 0.86, z), (x, 1.02, z), 0.03)
    # pillows tossed against the bolster
    if P.lod < 3:
        P.rbox("silk", (-0.62, 0.62, -0.18), (0.24, 0.20, 0.08), 0.07, r=(-25, 20, 8), puff=0.03)
        P.rbox("velvet", (0.66, 0.60, -0.12), (0.22, 0.19, 0.08), 0.07, r=(-28, -25, -10), puff=0.03)
        P.rbox("silk", (0.18, 0.52, -0.22), (0.20, 0.14, 0.07), 0.06, r=(-60, 5, 0), puff=0.03)
    seat_hardpoint(P, 0.53)


def hutt_sarlacc_bed(P):
    """Sarlacc maw bed. Mattress r 1.15, top 0.36 (domed to 0.38); the mouth (gap in the lip) faces -z where
    the player stands on the tongue; body centre (0, -0.40) -> bed hardpoint at z -1.25."""
    gap = 52.0                                            # half-angle of the mouth at -z (270 degrees)
    n = P.n(40, 14)
    prof = [(1.50, 0.0), (1.60, 0.10), (1.63, 0.26), (1.56, 0.42), (1.43, 0.52), (1.31, 0.52), (1.22, 0.45),
            (1.17, 0.36)]
    a0, a1 = 270 + gap, 270 + 360 - gap
    rings = []
    for i in range(n + 1):
        a = a0 + (a1 - a0) * i / n
        taper = smoothstep(0.0, 0.14, i / n) * smoothstep(0.0, 0.14, 1 - i / n)
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        ring = []
        for rr, yy in prof:
            rrr = 1.17 + (rr - 1.17) * (0.55 + 0.45 * taper)
            ring.append((rrr * ca, yy * (0.12 + 0.88 * taper), rrr * sa))
        rings.append(ring)
    P_ = [list(r) for r in rings]
    U = [[3.0 * i / n] * len(prof) for i in range(n + 1)]
    V = [[k / (len(prof) - 1) * 2.0 for k in range(len(prof))] for _ in range(n + 1)]
    def lip_out(q):                                       # away from the lip's own cross-section centre
        a = math.degrees(math.atan2(q[2], q[0])) % 360
        t = ((a - a0) % 360) / (a1 - a0)
        taper = smoothstep(0.0, 0.14, t) * smoothstep(0.0, 0.14, 1 - t)
        rc = 1.17 + (1.42 - 1.17) * (0.55 + 0.45 * taper)
        yc = 0.24 * (0.12 + 0.88 * taper)
        d = math.hypot(q[0], q[2]) or 1.0
        return (q[0] - q[0] / d * rc, q[1] - yc, q[2] - q[2] / d * rc)
    P.grid("flesh", P_, U, V, lip_out)
    for ring, nxt in ((rings[0], rings[1]), (rings[-1], rings[-2])):    # close the lip ends at the mouth
        c0 = tuple(sum(p[k] for p in ring) / len(ring) for k in range(3))
        c1 = tuple(sum(p[k] for p in nxt) / len(nxt) for k in range(3))
        P.flat("flesh", ring + [(ring[-1][0] * 0.99, 0.0, ring[-1][2] * 0.99)], v_sub(c0, c1))
    # mattress (domed velvet), its skirt down to the floor inside the lip
    P.lathe("velvet", (0, 0, 0), [(1.16, 0.0), (1.16, 0.30), (1.10, 0.36), (0.85, 0.375), (0.4, 0.38), (0.0, 0.381)],
            n=P.n(40, 12))
    # teeth: outer row on the lip crest, inner row smaller, all leaning into the maw
    for row, (rad, y, ln, w, cnt) in enumerate(((1.38, 0.50, 0.30, 0.055, 22), (1.24, 0.46, 0.18, 0.035, 26))):
        cnt = P.n(cnt, 8)
        for k in range(cnt):
            a = a0 + (a1 - a0) * (k + 0.5) / cnt
            if row == 1 and P.lod >= 2:
                continue
            ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
            taper = smoothstep(0.0, 0.14, (a - a0) / (a1 - a0)) * smoothstep(0.0, 0.14, (a1 - a) / (a1 - a0))
            base = (rad * ca, y * (0.12 + 0.88 * taper), rad * sa)
            tip = v_add(base, (-ca * ln * 0.55, ln * (0.85 if k % 2 else 1.0) * (0.4 + 0.6 * taper), -sa * ln * 0.55))
            P.cone("bone", base, tip, w * (0.5 + 0.5 * taper))
    # tentacles curling out over the floor (sides and back)
    if P.lod < 3:
        for k, a in enumerate((20, 75, 130, 170, 215)):
            ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
            path = []
            for j in range(P.n(12, 5) + 1):
                t = j / P.n(12, 5)
                rr = 1.5 + 0.9 * t
                ang = math.radians(a + 35 * t * (1 if k % 2 else -1))
                path.append((rr * math.cos(ang), 0.05 + 0.10 * math.sin(math.pi * t) + 0.25 * max(0, t - 0.75) ** 1.5 * 8,
                             rr * math.sin(ang)))
            P.sweep("flesh", path, lambda t: 0.10 * (1 - t) + 0.015, sides=P.n(8, 4))
    # tongue rug through the mouth
    tongue = [(0.62 * math.sin(math.radians(a)) * (1 - 0.25 * max(0, -math.cos(math.radians(a)))), 0.012,
               -1.05 - 0.55 * (1 - math.cos(math.radians(a))) / 2 * 1.9) for a in range(0, 361, 20)][:-1]
    tongue = [(x, y, max(z, -2.1)) for x, y, z in tongue]
    P.flat("flesh", tongue, (0, 1, 0))
    P.sweep("flesh", [(0, 0.02, -1.15), (0, 0.02, -1.95)], 0.03, sides=P.n(6, 4))      # its centre groove ridge
    # crescent bolster at the head end (Maya +x)
    pts = arc((0.30, 0.0, -0.40), 0.62, -60, 60, P.n(12, 5), y=0.44)
    P.sweep("silk", pts, lambda t: 0.09 + 0.05 * math.sin(math.pi * t), vscale=0.4)
    if P.lod < 2:
        P.rbox("velvet", (-0.45, 0.43, 0.55), (0.22, 0.06, 0.20), 0.05, r=(0, 30, 0), puff=0.02)
    bed_hardpoints(P, (0.0, 0.36, -0.40))


def hutt_hookah(P):
    """Palace hookah, 1.5 m, on a round rug."""
    P.disc("rug", (0, 0.006, 0), 0.0, 0.95, fit=True, n=P.n(40, 12))
    P.lathe("sandstone", (0, 0, 0), [(0.36, 0.0), (0.36, 0.08), (0.30, 0.12), (0.0, 0.12)], n=8)
    P.lathe("brass", (0, 0.12, 0), [(0.0, 0.0), (0.20, 0.0), (0.24, 0.04), (0.16, 0.10), (0.30, 0.13), (0.0, 0.13)])
    P.sphere("gorg", (0, 0.42, 0), 0.27)
    for k in range(P.n(8, 4)):
        a = 2 * math.pi * k / P.n(8, 4)
        path = [(0.285 * math.cos(math.radians(lat)) * math.cos(a), 0.42 + 0.285 * math.sin(math.radians(lat)),
                 0.285 * math.cos(math.radians(lat)) * math.sin(a)) for lat in range(-70, 71, 14)]
        P.sweep("brass", path, 0.012, sides=P.n(6, 3))
    for y, rr in ((0.18, 0.12), (0.66, 0.12)):
        P.lathe("brass", (0, y, 0), [(rr, -0.02), (rr + 0.03, 0.0), (rr, 0.02)], n=P.n(16, 6))
    P.lathe("brass", (0, 0.66, 0), [(0.10, 0.0), (0.07, 0.06), (0.035, 0.10), (0.035, 0.72), (0.0, 0.72)], n=P.n(12, 6))
    for y, rr in ((0.92, 0.07), (1.06, 0.17), (1.20, 0.06)):
        P.lathe("brass", (0, y, 0), [(0.03, -0.015), (rr, -0.008), (rr, 0.008), (0.03, 0.015)], n=P.n(16, 6))
    P.lathe("brass", (0, 1.38, 0), [(0.03, 0.0), (0.06, 0.02), (0.13, 0.08), (0.14, 0.12), (0.12, 0.12),
                                   (0.10, 0.09), (0.0, 0.09)], n=P.n(16, 6))
    P.disc("coals", (0, 1.495, 0), 0.0, 0.12, n=P.n(12, 6))
    if P.lod < 2:
        for k in range(5):
            a = 2 * math.pi * k / 5
            P.sphere("coals", (0.05 * math.cos(a), 1.505, 0.05 * math.sin(a)), 0.025, n=6)
    # hoses from the ports at 0.86 m, looping to the floor and up to brass mouthpieces at the rug edge
    for k in range(3):
        a = math.radians(90 + 120 * k)
        ca, sa = math.cos(a), math.sin(a)
        port = (0.05 * ca, 0.86, 0.05 * sa)
        path = []
        m = P.n(16, 6)
        for j in range(m + 1):
            t = j / m
            rr = 0.05 + 0.72 * t
            y = 0.86 * (1 - t) ** 2 + 0.03 + 0.25 * max(0.0, t - 0.8) * 5 * (1 - t) * 4
            path.append((rr * math.cos(a + 0.5 * t), y, rr * math.sin(a + 0.5 * t)))
        path[0] = port
        P.sweep("velvet", path, 0.022, sides=P.n(8, 4))
        end = path[-1]
        tip = v_add(end, v_mul(v_norm(v_sub(end, path[-2])), 0.12))
        P.cone("brass", end, tip, 0.03)


def hutt_pouf(P):
    """Tufted velvet pouf on a brass claw-foot ring. Seat 0.47 -> front edge z 0.46, foot 0.635."""
    P.lathe("brass", (0, 0, 0), [(0.36, 0.06), (0.43, 0.08), (0.44, 0.12), (0.36, 0.13)], n=P.n(28, 10))
    for k in range(4):
        a = math.radians(45 + 90 * k)
        c = (0.40 * math.cos(a), 0.0, 0.40 * math.sin(a))
        P.sphere("brass", v_add(c, (0, 0.05, 0)), 0.05)
        for j in (-1, 0, 1):
            b = a + j * 0.35
            P.cone("brass", v_add(c, (0, 0.03, 0)), (c[0] + 0.09 * math.cos(b), 0.0, c[2] + 0.09 * math.sin(b)), 0.02, n=5)
    P.lathe("velvet", (0, 0, 0), [(0.0, 0.12), (0.38, 0.12), (0.45, 0.17), (0.48, 0.28), (0.46, 0.40),
                                  (0.40, 0.46), (0.25, 0.475), (0.0, 0.47)], n=P.n(32, 10))
    P.lathe("silk", (0, 0, 0), [(0.483, 0.26), (0.49, 0.29), (0.483, 0.32)], n=P.n(32, 10), vscale=0.06)
    P.sphere("brass", (0, 0.47, 0), 0.03, n=8)
    if P.lod < 2:
        for k in range(8):
            a = 2 * math.pi * (k + 0.5) / 8
            top = (0.49 * math.cos(a), 0.29, 0.49 * math.sin(a))
            P.sweep("silk", [top, (0.50 * math.cos(a), 0.22, 0.50 * math.sin(a))], 0.008, sides=4)
            P.cone("brass", (0.50 * math.cos(a), 0.22, 0.50 * math.sin(a)), (0.50 * math.cos(a), 0.15, 0.50 * math.sin(a)), 0.025, n=6)
    seat_hardpoint(P, 0.46)


def hutt_table(P):
    """Low oval banquet table (0.45 m, Hutt lounging height) with Jabba's gorg jar."""
    a, b = 1.25, 0.62
    ring = ellipse(a, b, P.n(36, 12))
    P.prism("sandstone", ring, 0.385, 0.445, side_slot="brass", side_vscale=0.06, bottom=True)
    for y in (0.385, 0.445):
        P.sweep("brass", [(x * 1.005, y, z * 1.005) for x, z in ring], 0.018, closed=True, sides=P.n(6, 4))
    P.prism("wood", ellipse(a - 0.10, b - 0.10, P.n(36, 12)), 0.30, 0.385, side_slot="frieze", side_vscale=0.085)
    for sx in (-1, 1):
        for sz in (-1, 1):
            c = (sx * 0.82, 0.0, sz * 0.32)
            P.lathe("wood", c, [(0.0, 0.03), (0.08, 0.03), (0.06, 0.07), (0.09, 0.12), (0.05, 0.20), (0.06, 0.26),
                                (0.09, 0.30), (0.0, 0.30)], n=P.n(12, 6))
            P.sphere("brass", v_add(c, (0, 0.03, 0)), 0.045, n=8)
    # the gorg jar: brass foot, green-water globe, brass rim
    P.lathe("brass", (0, 0.445, 0), [(0.0, 0.0), (0.16, 0.0), (0.12, 0.04), (0.08, 0.06), (0.0, 0.06)], n=P.n(16, 6))
    P.sphere("gorg", (0, 0.72, 0), 0.24, lat0=-75, lat1=62)
    P.sphere("gorg", (0, 0.72, 0), 0.235, lat0=-75, lat1=62, inside=True)
    P.disc("gorg", (0, 0.86, 0), 0.0, 0.18, n=P.n(16, 6))                        # water surface
    P.lathe("brass", (0, 0.72, 0), [(0.105, 0.20), (0.135, 0.215), (0.14, 0.235), (0.11, 0.235)], n=P.n(16, 6))
    if P.lod < 2:
        for k, (x, y, z) in enumerate(((0.06, 0.64, 0.03), (-0.07, 0.75, -0.04), (0.02, 0.83, 0.07))):
            P.sphere("flesh", (x, y, z), 0.035, sy=0.7, n=6)
    # goblets and a covered brass cloche
    for sx in (-1, 1):
        c = (sx * 0.75, 0.445, 0.20 * sx)
        P.lathe("brass", c, [(0.0, 0.0), (0.05, 0.0), (0.015, 0.02), (0.012, 0.09), (0.05, 0.12), (0.055, 0.19),
                             (0.045, 0.19), (0.0, 0.13)], n=P.n(12, 6))
    P.lathe("brass", (-0.62, 0.445, -0.22), [(0.0, 0.0), (0.20, 0.0), (0.22, 0.015), (0.0, 0.015)], n=P.n(16, 6))
    P.sphere("brass", (-0.62, 0.46, -0.22), 0.17, lat0=0, lat1=90)
    P.sphere("brass", (-0.62, 0.64, -0.22), 0.025, n=6)


# ---------------------------------------------------------------------------------------------------------------
# Rebel Alliance
# ---------------------------------------------------------------------------------------------------------------

def _xwing_section(t, open_top):
    """Cross-section of the salvaged fuselage at z-parameter t (0 rear .. 1 nose): (x, y) loop, clockwise."""
    w = 0.52 - 0.17 * t ** 1.5
    top = 0.80 - 0.26 * t
    shoulder = top - 0.18
    if open_top:                                          # the cockpit tub: walls cut down to elbow height
        top, shoulder = 0.62, 0.52
    if open_top:                                          # a U from the left rim down round the keel to the right rim
        return [(-w * 0.72, top), (-w, shoulder), (-w, 0.16), (-w * 0.78, 0.04),
                (w * 0.78, 0.04), (w, 0.16), (w, shoulder), (w * 0.72, top)]
    return [(-w * 0.78, 0.04), (-w, 0.16), (-w, shoulder), (-w * 0.72, top), (-w * 0.25, top + 0.05),
            (w * 0.25, top + 0.05), (w * 0.72, top), (w, shoulder), (w, 0.16), (w * 0.78, 0.04)]


def reb_xwing_chair(P):
    """X-wing cockpit section armchair. Seat 0.46, front edge z 0.02 -> foot 0.195 (inside the footwell)."""
    z_rear, z_tub0, z_tub1, z_nose = -1.05, -0.62, 0.70, 1.40
    m = P.n(10, 4)
    # rear hump (closed), cockpit tub walls (open U), nose deck (closed, legs go under it)
    for (za, zb, open_top, slot) in ((z_rear, z_tub0, False, "hull"), (z_tub0, z_tub1, True, "hull"),
                                     (z_tub1, z_nose, False, "hull")):
        rings = []
        for k in range(m + 1):
            z = za + (zb - za) * k / m
            t = (z - z_rear) / (z_nose - z_rear)
            rings.append([(x, y, z) for x, y in _xwing_section(t, open_top)])
        if open_top:
            # outer skin as an open strip, inner liner offset inward, rim faces on top
            ni = len(rings[0])
            P_ = [[rings[k][j] for k in range(m + 1)] for j in range(ni)]
            U = [[j / ni * 2] * (m + 1) for j in range(ni)]
            V = [[(rings[k][0][2] - za) / 1.2 for k in range(m + 1)] for _ in range(ni)]
            P.grid(slot, P_, U, V, lambda q: (q[0], q[1] - 0.45, 0.0))
            inner = [[(x * 0.88, 0.07 + (y - 0.04) * 0.97, z) for x, y, z in rg] for rg in rings]
            Pi = [[inner[k][j] for k in range(m + 1)] for j in range(ni)]
            P.grid("console", Pi, U, V, lambda q: (-q[0], 0.45 - q[1], 0.0))
            for side in (0, ni - 1):
                for k in range(m):
                    q = [rings[k][side], rings[k + 1][side], inner[k + 1][side], inner[k][side]]
                    P.flat(slot, q, (0, 1, 0))
            seg = rings, inner
        else:
            P.loft(slot, rings, closed=True, caps=(za == z_rear, zb == z_nose), vscale=1.2)
    # cut faces where the tub meets the hump and the deck (bulkhead walls facing the pilot)
    rings, inner = seg
    for k, sgn in ((0, 1), (-1, -1)):
        t = (rings[k][0][2] - z_rear) / (z_nose - z_rear)
        full = [(x, y, rings[k][0][2]) for x, y in _xwing_section(t, False)]
        P.flat("console", full, (0, 0, sgn))
    # instrument panel facing the pilot on the deck's rear wall, two live screens
    P.decal("screen", (-0.16, 0.52, z_tub1 - 0.012), 0.22, 0.14, (0, 0.2, -1))
    P.decal("screen", (0.16, 0.52, z_tub1 - 0.012), 0.22, 0.14, (0, 0.2, -1))
    # tub floor
    P.flat("console", [(-0.36, 0.075, z_tub0), (0.36, 0.075, z_tub0), (0.32, 0.075, z_tub1), (-0.32, 0.075, z_tub1)], (0, 1, 0))
    # pilot seat: frame, quilted orange cushions, headrest
    P.box("gunmetal", (0, 0.24, -0.22), (0.24, 0.16, 0.24))
    P.rbox("quilt", (0, 0.42, -0.22), (0.25, 0.045, 0.24), 0.035, puff=0.012)
    P.rbox("quilt", (0, 0.78, -0.50), (0.25, 0.30, 0.05), 0.04, r=(-12, 0, 0), puff=0.012)
    P.rbox("quilt", (0, 1.15, -0.58), (0.16, 0.08, 0.05), 0.035, r=(-12, 0, 0))
    # canopy: hinged at the rear of the tub and swung up, frame tubes and glass
    piv = (0.0, 0.80, z_tub0)
    can = lambda p: xf(p, (0, 0, 0), (-38, 0, 0), piv)
    frame = [(-0.36, 0.80, z_tub0), (-0.30, 1.00, z_tub0 + 0.40), (-0.18, 1.08, z_tub0 + 0.95), (0.18, 1.08, z_tub0 + 0.95),
             (0.30, 1.00, z_tub0 + 0.40), (0.36, 0.80, z_tub0)]
    fr = [can(p) for p in frame]
    P.sweep("gunmetal", fr, 0.025, sides=P.n(6, 4))
    P.sweep("gunmetal", [can((0, 1.09, z_tub0 + 0.95)), can((0, 0.86, z_tub0))], 0.02, sides=P.n(6, 4))
    for half in (-1, 1):
        g = [fr[0 if half < 0 else 5], fr[1 if half < 0 else 4], fr[2 if half < 0 else 3], can((0, 1.09, z_tub0 + 0.95)),
             can((0, 0.86, z_tub0))]
        g = [v_add(p, (0, 0, 0)) for p in g]
        P.flat("glass", g, v_sub(can((half * 0.6, 1.3, z_tub0 + 0.4)), can((0, 0.8, z_tub0 + 0.3))))
        P.flat("glass", g, v_mul(v_sub(can((half * 0.6, 1.3, z_tub0 + 0.4)), can((0, 0.8, z_tub0 + 0.3))), -1))
    # astromech dome in its socket behind the hump
    P.lathe("gunmetal", (0, 0.86, -0.86), [(0.0, -0.04), (0.20, -0.04), (0.21, 0.0), (0.0, 0.0)], n=P.n(20, 8))
    P.sphere("r2", (0, 0.86, -0.86), 0.19, lat0=0, lat1=90, utiles=1)
    # landing skids and a sensor tip on the cut nose
    for sx in (-1, 1):
        P.box("gunmetal", (sx * 0.30, 0.025, -0.2), (0.05, 0.025, 0.75))
    P.lathe("red", (0, 0.40, z_nose), [(0.18, 0.0), (0.12, 0.10), (0.05, 0.16), (0.0, 0.17)], r=(90, 0, 0), n=P.n(14, 6))
    # crest on the hump flank
    for sx in (-1, 1):
        P.decal("crest", (sx * 0.525, 0.45, -0.85), 0.28, 0.28, (sx, 0, 0))
    seat_hardpoint(P, 0.02)


def reb_holotable(P):
    """Yavin war-room holotable: 1.9 m, rim 0.95 m, the Death Star at 1.75 m."""
    P.lathe("olive", (0, 0, 0), [(0.0, 0.0), (0.62, 0.0), (0.62, 0.08), (0.42, 0.14), (0.34, 0.20), (0.32, 0.70),
                                 (0.55, 0.80), (0.93, 0.86), (0.95, 0.95), (0.88, 0.955)], n=P.n(36, 12))
    P.disc("console", (0, 0.955, 0), 0.58, 0.88, n=P.n(36, 12))
    P.lathe("olive", (0, 0, 0), [(0.58, 0.955), (0.55, 0.93), (0.52, 0.90)], n=P.n(36, 12))
    P.disc("olive", (0, 0.90, 0), 0.0, 0.52, n=P.n(36, 12))
    P.lathe("screen", (0, 0.90, 0), [(0.13, 0.0), (0.10, 0.04), (0.0, 0.06)], n=P.n(16, 6))
    # rim consoles with screens, every 120 degrees
    for k in range(3):
        a = math.radians(90 + 120 * k)
        c = (0.74 * math.cos(a), 1.0, 0.74 * math.sin(a))
        P.box("olive", c, (0.16, 0.045, 0.09), r=(0, -math.degrees(a) + 90, 0))
        nrm = (math.cos(a) * 0.4, 1.0, math.sin(a) * 0.4)
        P.decal("screen", v_add(c, (0, 0.047, 0)), 0.26, 0.13, nrm, up=(-math.sin(a), 0, math.cos(a)))
    # light cone (both sides), the Death Star, its dish and the trench
    m = P.n(20, 8)
    for inside in (False, True):
        P.lathe("holo", (0, 0.96, 0), [(0.11, 0.0), (0.40, 0.48)], n=m, inside=inside)
    c = (0, 1.75, 0)
    P.sphere("holo", c, 0.42, n=P.n(24, 10), utiles=4)
    P.sphere("holo", c, 0.42, n=P.n(24, 10), inside=True, utiles=4)
    dish_c = v_add(c, v_mul(v_norm((0.45, 0.55, 0.70)), 0.43))
    P.decal("holo_dish", dish_c, 0.26, 0.26, (0.45, 0.55, 0.70))
    P.lathe("holo", c, [(0.43, -0.012), (0.445, 0.0), (0.43, 0.012)], n=P.n(32, 10))
    # an orbit ring of target markers
    if P.lod < 2:
        orbit = arc((0, 0, 0), 0.68, 0, 360, P.n(32, 12))
        orbit = [xf(p, c, (14, 0, 8)) for p in orbit[:-1]]
        P.sweep("holo", orbit, 0.006, closed=True, sides=4)
        tgt = xf((0.68, 0, 0), c, (14, 0, 8))
        P.sphere("holo", tgt, 0.035, n=6)


def reb_bunk(P):
    """Echo Base survival cot. Mattress 2.0 x 0.9 m, top 0.36, centred at z 0.20 (body centre) -> bed 0.85 m in
    front at z -0.65; the head end (thermal hood) is Maya +x."""
    zc, L, W = 0.20, 1.02, 0.46
    for sx in (-1, 1):
        for sz in (-1, 1):
            P.sweep("olive", [(sx * L, 0.0, zc + sz * W), (sx * L, 0.27, zc + sz * W)], 0.025, sides=P.n(8, 4))
    for sz in (-1, 1):
        P.sweep("olive", [(-L - 0.02, 0.25, zc + sz * W), (L + 0.02, 0.25, zc + sz * W)], 0.022, sides=P.n(8, 4))
    for sx in (-1, 1):
        P.sweep("olive", [(sx * L, 0.25, zc - W), (sx * L, 0.25, zc + W)], 0.022, sides=P.n(8, 4))
    # foot rail loop
    loop = [(-L, 0.27, zc - W)] + [(-L, 0.27 + 0.30 * math.sin(math.pi * k / 8), zc - W + 2 * W * k / 8) for k in range(1, 8)] + [(-L, 0.27, zc + W)]
    P.sweep("olive", loop, 0.02, sides=P.n(8, 4))
    P.box("canvas", (0, 0.255, zc), (L, 0.012, W))                                     # sling
    P.rbox("canvas", (0.02, 0.30, zc), (0.98, 0.055, 0.44), 0.04, puff=0.01)           # pad, top 0.355
    P.rbox("blanket", (-0.30, 0.365, zc), (0.66, 0.02, 0.455), 0.02, puff=0.004)
    P.sweep("blanket", [(0.36, 0.385, zc - 0.45), (0.36, 0.385, zc + 0.45)], 0.035, sides=P.n(8, 4))
    P.rbox("canvas", (0.80, 0.40, zc), (0.17, 0.05, 0.30), 0.045, puff=0.02)           # pillow
    if P.lod < 2:
        P.sweep("quilt", [(-0.95, 0.42, zc - 0.36), (-0.95, 0.42, zc + 0.36)], 0.07, sides=P.n(10, 5))
    # thermal hood over the head end
    m = P.n(12, 5)
    rings = []
    for k in range(m + 1):
        t = k / m
        x = 0.62 + 0.46 * t
        h = 1.35 - 0.25 * t ** 2
        rings.append([(x, 0.25 + (h - 0.25) * math.sin(math.pi * j / 10), zc - (W + 0.03) * math.cos(math.pi * j / 10)) for j in range(11)])
    P_ = [[rings[k][j] for k in range(m + 1)] for j in range(11)]
    U = [[j / 10 * 2] * (m + 1) for j in range(11)]
    V = [[k / m for k in range(m + 1)] for _ in range(11)]
    for sgn in (1, -1):
        P.grid("canvas", P_, U, V, lambda q, s=sgn: v_mul((0.0, q[1] - 0.25, q[2] - zc), s))
    for x in (0.62, 1.08):
        hoop = [(x, 0.25 + (1.35 - 0.25 * ((x - 0.62) / 0.46) ** 2 - 0.25) * math.sin(math.pi * j / 12), zc - (W + 0.04) * math.cos(math.pi * j / 12)) for j in range(13)]
        P.sweep("olive", hoop, 0.018, sides=P.n(6, 4))
    P.flat("canvas", rings[-1], (1, 0, 0))
    P.flat("canvas", rings[-1], (-1, 0, 0))
    # footlocker under the foot end with the starbird facing the player, a helmet on the foot post
    P.box("olive", (-0.45, 0.115, zc), (0.38, 0.11, 0.26))
    P.box("gunmetal", (-0.45, 0.235, zc), (0.39, 0.012, 0.27))
    P.decal("crest", (-0.45, 0.12, zc - 0.262), 0.16, 0.16, (0, 0, -1))
    if P.lod < 2:
        P.sphere("hull", (-L, 0.66, zc + W), 0.13, lat0=-10, lat1=90)
        P.lathe("olive", (-L, 0.64, zc + W), [(0.13, -0.01), (0.16, 0.0), (0.13, 0.02)], n=P.n(14, 6))
    bed_hardpoints(P, (0.0, 0.36, zc))


def reb_crate_bench(P):
    """Bench on two supply crates. Seat 0.46, front edge z 0.24 -> foot 0.415."""
    for sx in (-1, 1):
        c = (sx * 0.56, 0.20, 0.0)
        P.box("olive", c, (0.26, 0.20, 0.26))
        for dz in (-0.262, 0.262):
            P.box("gunmetal", (c[0], 0.20, dz), (0.27, 0.025, 0.006), bottom=False)
        for dx in (-0.262, 0.262):
            P.box("gunmetal", (c[0] + dx, 0.20, 0), (0.006, 0.20, 0.265), bottom=False)
        P.decal("crest", (c[0], 0.22, 0.263), 0.18, 0.18, (0, 0, 1))
        P.box("gunmetal", (c[0], 0.30, -0.265), (0.08, 0.015, 0.01))              # handle
    P.box("olive", (0, 0.405, 0.0), (0.86, 0.012, 0.25))                           # plank
    P.rbox("quilt", (0, 0.435, 0.0), (0.84, 0.03, 0.24), 0.025, puff=0.01)
    P.box("canvas", (0.0, 0.44, 0.0), (0.04, 0.035, 0.252))                        # tie-down strap
    for sx in (-1, 1):
        P.sweep("gunmetal", [(sx * 0.62, 0.40, -0.22), (sx * 0.62, 1.02, -0.32)], 0.025, sides=P.n(8, 4))
    P.box("hull_stripe", (0, 0.80, -0.29), (0.78, 0.20, 0.025), r=(-10, 0, 0))
    if P.lod < 2:
        P.lathe("olive", (0.62, 0.62, -0.30), [(0.0, -0.08), (0.06, -0.07), (0.065, 0.04), (0.02, 0.07), (0.015, 0.10), (0.0, 0.10)], n=10)
        P.sweep("canvas", [(0.62, 0.72, -0.26), (0.62, 0.95, -0.29)], 0.008, sides=4)
    seat_hardpoint(P, 0.24)


def reb_locker(P):
    """Alliance gear locker 1.1 x 0.55 x 2.0, the right door swung open on rifles, a helmet and a flight suit."""
    W, D, H = 0.55, 0.275, 2.0
    t = 0.02
    P.box("olive", (0, H / 2, -D + t), (W, H / 2, t))                               # back
    for sx in (-1, 1):
        P.box("olive", (sx * (W - t), H / 2, 0), (t, H / 2, D))
    P.box("olive", (0, H - t, 0), (W, t, D))
    P.box("olive", (0, 0.06, 0), (W, 0.06, D))
    P.box("olive", (0, 1.50, 0), (W - 2 * t, 0.012, D - t))                         # shelf
    P.box("gunmetal", (0, 0.015, 0), (W + 0.02, 0.015, D + 0.02))
    # left door closed (crest, vents), right door open 105 degrees about its hinge
    P.box("olive", (-W / 2, H / 2 + 0.03, D + 0.012), (W / 2 - 0.005, H / 2 - 0.05, 0.012))
    P.decal("crest", (-W / 2, 1.35, D + 0.026), 0.32, 0.32, (0, 0, 1))
    for k in range(5):
        P.box("gunmetal", (-W / 2, 0.40 + 0.06 * k, D + 0.026), (0.16, 0.012, 0.004), bottom=False)
    hinge = (W, 0.0, D)
    P.box("olive", xf((W / 2, H / 2 + 0.03, D + 0.012), (0, 0, 0), (0, 105, 0), hinge), (W / 2 - 0.005, H / 2 - 0.05, 0.012), r=(0, 105, 0))
    # rifles on the rack (right half), a helmet and pouches on the shelf, a flight suit on the left
    for k, x in enumerate((0.18, 0.38)):
        P.box("gunmetal", (x, 0.95, -0.12), (0.03, 0.42, 0.045))                    # body
        P.sweep("gunmetal", [(x, 1.36, -0.10), (x, 1.46, -0.10)], 0.012, sides=6)  # barrel
        P.box("gunmetal", (x, 0.62, -0.08), (0.025, 0.08, 0.07))                    # stock
        P.box("gunmetal", (x, 1.05, -0.04), (0.02, 0.10, 0.03))                     # scope
    P.box("gunmetal", (0.28, 1.30, -0.22), (0.22, 0.015, 0.04))                     # rack bar
    P.sphere("hull", (0.25, 1.52, -0.02), 0.13, lat0=-5, lat1=90)
    P.lathe("hull", (0.25, 1.51, -0.02), [(0.12, 0.0), (0.16, 0.01), (0.12, 0.03)], n=P.n(14, 6))
    P.rbox("canvas", (-0.22, 1.57, -0.05), (0.14, 0.06, 0.09), 0.03)
    P.rbox("canvas", (-0.38, 1.56, 0.02), (0.08, 0.05, 0.07), 0.025)
    P.sweep("gunmetal", [(-0.52, 1.40, -0.05), (0.0, 1.40, -0.05)], 0.008, sides=4)    # hanger rail
    P.rbox("quilt", (-0.30, 0.95, -0.06), (0.18, 0.40, 0.05), 0.04, puff=0.01)
    P.rbox("quilt", (-0.30, 1.30, -0.06), (0.22, 0.06, 0.055), 0.04)


# ---------------------------------------------------------------------------------------------------------------
# Galactic Empire
# ---------------------------------------------------------------------------------------------------------------

def _teeth(P, slot, c, rad, y, cnt, up, skip=None, xform=None):
    """Rectangular teeth along a rim circle; up = +1 pointing up, -1 down; skip(a) leaves gaps."""
    for k in range(cnt):
        a = 360.0 * (k + 0.5) / cnt
        if skip and skip(a):
            continue
        p = (c[0] + rad * math.cos(math.radians(a)), y + up * 0.05, c[2] + rad * math.sin(math.radians(a)))
        if xform:
            old = P.xform
            P.xform = xform
        P.box(slot, p, (0.035, 0.05, 0.025), r=(0, -a + 90, 0))
        if xform:
            P.xform = old


def imp_pod(P):
    """Meditation pod. Shell R 1.15 round (0, 1.05, -0.1); front notch for the legs; seat 0.46, front edge
    z 0.22 -> foot 0.395; the upper shell hinges up-back 58 degrees on chrome rams."""
    R, cy, cz = 1.15, 1.05, -0.10
    n = P.n(36, 12)
    lat_floor = math.degrees(math.asin((0.03 - cy) / R))
    notch = lambda a: abs(((a - 90 + 180) % 360) - 180) < 30          # front (+z) notch half-angle
    # lower shell: outer gloss, inner grey panels, both cut by the front notch (built as an arc 120..420 deg)
    a0, a1 = 90 + 30, 90 + 330
    rows = P.n(9, 4)
    prof = [(R * math.cos(math.radians(lat_floor + (0 - lat_floor) * k / rows)), cy + R * math.sin(math.radians(lat_floor + (0 - lat_floor) * k / rows)) - cy)
            for k in range(rows + 1)]
    P.lathe("black", (0, cy, cz), prof, n=n, a0=a0, a1=a1)
    pin = [(rr * 0.95, yy * 0.95 + 0.01) for rr, yy in prof]
    P.lathe("grey", (0, cy, cz), pin, n=n, a0=a0, a1=a1, inside=True)
    # rim band (chrome) on the lower shell and notch edges
    for a in (a0, a1):
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        q = [(prof[k][0] * ca, cy + prof[k][1], cz + prof[k][0] * sa) for k in range(rows + 1)]
        qi = [(pin[k][0] * ca, cy + pin[k][1], cz + pin[k][0] * sa) for k in range(rows + 1)]
        for k in range(rows):
            quad = [q[k], q[k + 1], qi[k + 1], qi[k]]
            P.flat("chrome", quad, (-sa if a == a0 else sa, 0, ca if a == a0 else -ca))
    rim_in, rim_out = R * 0.95, R
    for i in range(n):
        aa, bb = a0 + (a1 - a0) * i / n, a0 + (a1 - a0) * (i + 1) / n
        pa = [(rim_out * math.cos(math.radians(aa)), cy, cz + rim_out * math.sin(math.radians(aa))),
              (rim_out * math.cos(math.radians(bb)), cy, cz + rim_out * math.sin(math.radians(bb))),
              (rim_in * math.cos(math.radians(bb)), cy + 0.01, cz + rim_in * math.sin(math.radians(bb))),
              (rim_in * math.cos(math.radians(aa)), cy + 0.01, cz + rim_in * math.sin(math.radians(aa)))]
        P.flat("chrome", pa, (0, 1, 0))
    _teeth(P, "white", (0, 0, cz), R * 0.975, cy, P.n(28, 10), 1, skip=lambda a: notch(a) or abs(((a - 270 + 180) % 360) - 180) < 14)
    # floor disc, pedestal ring with red under-glow
    rf = R * math.cos(math.radians(lat_floor)) * 0.95
    P.disc("grey", (0, 0.035, cz), 0.0, rf, n=n)
    P.lathe("black", (0, 0, cz), [(0.95, 0.0), (0.98, 0.04), (0.92, 0.10), (0.70, 0.12)], n=n)
    P.lathe("red", (0, 0, cz), [(0.96, 0.012), (0.975, 0.03)], n=n)
    # seat: chrome column, leather seat and tall winged back
    P.lathe("chrome", (0, 0.035, -0.02), [(0.16, 0.0), (0.10, 0.03), (0.06, 0.05), (0.06, 0.34), (0.12, 0.38), (0.0, 0.38)], n=P.n(16, 6))
    P.rbox("leather", (0, 0.42, -0.02), (0.27, 0.045, 0.24), 0.04, puff=0.01)
    P.rbox("black", (0, 0.36, -0.02), (0.29, 0.03, 0.26), 0.02)
    P.rbox("leather", (0, 0.92, -0.32), (0.27, 0.42, 0.06), 0.05, r=(-10, 0, 0), puff=0.01)
    P.rbox("black", (0, 0.92, -0.36), (0.30, 0.46, 0.04), 0.03, r=(-10, 0, 0))
    for sx in (-1, 1):
        P.rbox("black", (sx * 0.33, 0.58, -0.05), (0.05, 0.04, 0.22), 0.02)
        P.box("red", (sx * 0.33, 0.62, 0.17), (0.04, 0.008, 0.012), bottom=False)
    # upper shell: hinged at the back rim, swung up 58 degrees
    piv = (0.0, cy, cz - R)
    up = lambda p: xf(p, (0, 0, 0), (-58, 0, 0), piv)
    old = P.xform
    P.xform = up
    rows_u = P.n(9, 4)
    profu = [(R * math.cos(math.radians(85 * k / rows_u)), R * math.sin(math.radians(85 * k / rows_u))) for k in range(rows_u + 1)]
    P.lathe("black", (0, cy, cz), profu, n=n)
    P.lathe("grey", (0, cy, cz), [(rr * 0.95, yy * 0.95 + 0.0) for rr, yy in profu], n=n, inside=True)
    P.disc("black", (0, cy + R * math.sin(math.radians(85)), cz), 0.0, R * math.cos(math.radians(85)), n=n)
    for i in range(n):
        aa, bb = 360 * i / n, 360 * (i + 1) / n
        pa = [(rim_out * math.cos(math.radians(aa)), cy, cz + rim_out * math.sin(math.radians(aa))),
              (rim_out * math.cos(math.radians(bb)), cy, cz + rim_out * math.sin(math.radians(bb))),
              (rim_in * math.cos(math.radians(bb)), cy, cz + rim_in * math.sin(math.radians(bb))),
              (rim_in * math.cos(math.radians(aa)), cy, cz + rim_in * math.sin(math.radians(aa)))]
        P.flat("chrome", pa, (0, -1, 0))
    for k in range(3):                                                          # red light rings inside
        lat = 25 + 20 * k
        rr, yy = R * 0.94 * math.cos(math.radians(lat)), R * 0.94 * math.sin(math.radians(lat))
        P.lathe("red", (0, cy, cz), [(rr, yy - 0.012), (rr - 0.004, yy + 0.012)], n=n, inside=True)
    P.xform = old
    _teeth(P, "white", (0, 0, cz), R * 0.975, cy, P.n(28, 10), -1, xform=up)
    # chrome rams from the pedestal sides to the raised shell
    for sx in (-1, 1):
        a = (sx * 0.98, 0.35, cz - 0.55)
        b = up((sx * 1.0, cy + 0.25, cz - 0.55))
        P.sweep("chrome", [a, b], 0.04, sides=P.n(10, 5))
        P.sweep("black", [(sx * 0.98, 0.10, cz - 0.55), a], 0.07, sides=P.n(10, 5))
    seat_hardpoint(P, 0.22)


def imp_sd_table(P):
    """Star Destroyer conference table: a 3.1 m dagger, top 0.78 m, its holographic bridge tower at the stern."""
    tip, stern, half = 1.70, -1.40, 0.82
    def tri(inset, y):
        k = inset
        return [(tip - k * 2.2, y, 0.0), (stern + k, y, -half + k), (stern + k, y, half - k)]
    bot, mid, top = tri(0.10, 0.70), tri(0.0, 0.745), tri(0.06, 0.78)
    P.flat("grey", top, (0, 1, 0))
    P.flat("black", bot, (0, -1, 0))
    for ra, rb, slot in ((bot, mid, "black"), (mid, top, "grey")):
        for i in range(3):
            q = [ra[i], ra[(i + 1) % 3], rb[(i + 1) % 3], rb[i]]
            c = tuple(sum(p[k] for p in q) / 4 for k in range(3))
            P.flat(slot, q, (c[0] - 0.0, 0.0, c[2]) if i != 1 else (-1, 0, 0))
    # red edge strips along the long edges
    for s in (-1, 1):
        a, b = mid[0], mid[1 if s < 0 else 2]
        d = v_norm(v_sub(b, a))
        nrm = v_norm((s * -d[2] * -1 if False else -d[2] * (1 if s > 0 else -1), 0.0, d[0] * (1 if s > 0 else -1)))
        nrm = v_norm(v_cross((0, 1, 0), d)) if s < 0 else v_norm(v_cross(d, (0, 1, 0)))
        if v_dot(nrm, (0.0, 0.0, s)) < 0:
            nrm = v_mul(nrm, -1)
        off = v_mul(nrm, 0.004)
        q = [v_add(a, v_add(off, (0, -0.012, 0))), v_add(b, v_add(off, (0, -0.012, 0))),
             v_add(b, v_add(off, (0, 0.012, 0))), v_add(a, v_add(off, (0, 0.012, 0)))]
        P.poly("red", q, [(0, 0.2), (4, 0.2), (4, 0.8), (0, 0.8)], nrm)
    # trench lines and the crest inlay on the top
    P.decal("crest", (stern + 0.45, 0.782, 0.0), 0.5, 0.5, (0, 1, 0), up=(1, 0, 0))
    # pedestals
    for x, w in ((-0.75, 0.5), (0.55, 0.32)):
        P.box("black", (x, 0.35, 0), (0.12, 0.35, w * 0.6))
        P.box("black", (x, 0.03, 0), (0.22, 0.03, w))
        P.box("red", (x, 0.065, 0), (0.18, 0.006, w * 0.9), bottom=False)
    P.box("black", (-0.1, 0.62, 0), (0.75, 0.05, 0.06))
    # the holographic bridge tower over the stern: stepped superstructure, bridge deck, the two shield domes on
    # their necks, a projector cone from the inlay (dense holo so it reads in any light)
    hx = stern + 0.32
    for (x0, x1, y0, y1, w) in ((hx - 0.16, hx + 0.62, 0.80, 0.98, 0.42), (hx - 0.10, hx + 0.40, 0.98, 1.16, 0.30),
                                (hx - 0.04, hx + 0.26, 1.16, 1.36, 0.18), (hx, hx + 0.18, 1.36, 1.50, 0.12),
                                (hx + 0.02, hx + 0.16, 1.50, 1.60, 0.54)):
        P.box("holo_solid", ((x0 + x1) / 2, (y0 + y1) / 2, 0), ((x1 - x0) / 2, (y1 - y0) / 2, w / 2), fit=True)
    for sz in (-1, 1):
        P.sweep("holo_solid", [(hx + 0.09, 1.60, sz * 0.22), (hx + 0.09, 1.68, sz * 0.22)], 0.025, sides=P.n(8, 4))
        P.sphere("holo_solid", (hx + 0.09, 1.73, sz * 0.22), 0.075, n=P.n(12, 6))
    for inside in (False, True):
        P.lathe("holo", (hx + 0.20, 0.785, 0), [(0.08, 0.0), (0.42, 0.015)], n=P.n(16, 6), inside=inside)


def imp_bunk(P):
    """Officer's bunk: gloss frame on a red-lit plinth, linen, crest headboard at Maya +x (the head end).
    Mattress 2.0 x 0.9, top 0.36, centred at z 0.20 -> bed at z -0.65."""
    zc, L, W = 0.20, 1.04, 0.48
    P.box("black", (0, 0.06, zc), (L - 0.06, 0.06, W - 0.06))                     # recessed plinth
    P.box("red", (0, 0.03, zc), (L - 0.05, 0.008, W - 0.05), bottom=False, top=False)
    P.box("black", (0, 0.20, zc), (L, 0.08, W))                                    # frame
    for k, x in enumerate((-0.5, 0.2)):
        P.decal("grey", (x, 0.20, zc - W - 0.003), 0.6, 0.12, (0, 0, -1))
        P.box("chrome", (x, 0.20, zc - W - 0.012), (0.12, 0.01, 0.008))
    P.rbox("linen", (0.02, 0.32, zc), (0.98, 0.045, 0.45), 0.035, puff=0.008)       # top 0.365
    P.rbox("linen", (-0.32, 0.37, zc), (0.66, 0.012, 0.462), 0.012)
    P.rbox("pillow", (0.80, 0.40, zc), (0.17, 0.05, 0.32), 0.045, puff=0.02)
    # headboard unit at +x: panel, shelf, red strip, crest
    P.box("black", (L + 0.06, 0.62, zc), (0.06, 0.62, W + 0.04))
    P.box("grey", (L - 0.02, 0.85, zc), (0.02, 0.30, W - 0.04), bottom=False)
    P.box("black", (L - 0.06, 1.18, zc), (0.10, 0.02, W))
    P.box("red", (L - 0.005, 0.52, zc), (0.004, 0.012, W - 0.06), bottom=False)
    P.decal("crest", (L - 0.045, 0.86, zc), 0.36, 0.36, (-1, 0, 0))
    # foot board, low
    P.box("black", (-L - 0.03, 0.30, zc), (0.03, 0.18, W))
    bed_hardpoints(P, (0.0, 0.36, zc))


def imp_chair(P):
    """Officer's swivel chair. Seat 0.46, front edge z 0.25 -> foot 0.425."""
    P.lathe("black", (0, 0, 0), [(0.0, 0.0), (0.34, 0.0), (0.33, 0.03), (0.20, 0.06), (0.07, 0.10), (0.0, 0.10)], n=P.n(24, 8))
    P.lathe("red", (0, 0, 0), [(0.342, 0.004), (0.338, 0.02)], n=P.n(24, 8))
    P.lathe("chrome", (0, 0.10, 0), [(0.05, 0.0), (0.045, 0.24), (0.08, 0.26), (0.0, 0.27)], n=P.n(14, 6))
    P.rbox("black", (0, 0.38, 0), (0.27, 0.035, 0.26), 0.025)
    P.rbox("leather", (0, 0.43, 0.0), (0.25, 0.035, 0.25), 0.03, puff=0.01)
    # high back with angled wings
    P.rbox("black", (0, 0.88, -0.27), (0.26, 0.42, 0.035), 0.03, r=(-8, 0, 0))
    P.rbox("leather", (0, 0.88, -0.23), (0.22, 0.38, 0.03), 0.03, r=(-8, 0, 0), puff=0.008)
    for sx in (-1, 1):
        P.rbox("black", (sx * 0.30, 1.12, -0.22), (0.035, 0.20, 0.10), 0.02, r=(-8, sx * -25, 0))
        P.rbox("black", (sx * 0.30, 0.60, 0.0), (0.04, 0.03, 0.22), 0.015)
        P.sweep("black", [(sx * 0.30, 0.40, -0.12), (sx * 0.30, 0.58, -0.10)], 0.02, sides=6)
        P.box("red", (sx * 0.30, 0.632, 0.18), (0.03, 0.004, 0.02), bottom=False)
    seat_hardpoint(P, 0.25)


def imp_holo_crest(P):
    """Pedestal (1.1 m) projecting a 1 m holographic Imperial crest; two holo TIE fighters orbit it."""
    oct8 = [(0.30 * math.cos(math.radians(22.5 + 45 * k)), 0.30 * math.sin(math.radians(22.5 + 45 * k))) for k in range(8)]
    P.prism("black", [(x * 1.4, z * 1.4) for x, z in oct8], 0.0, 0.08)
    P.prism("black", oct8, 0.08, 0.95)
    P.prism("grey", [(x * 1.25, z * 1.25) for x, z in oct8], 0.95, 1.05, bottom=True)
    for k in range(8):
        a = math.radians(45 * k)
        P.box("red", (0.27 * math.cos(a), 0.52, 0.27 * math.sin(a)), (0.012, 0.35, 0.012), r=(0, -45 * k, 0), bottom=False)
    P.lathe("chrome", (0, 1.05, 0), [(0.14, 0.0), (0.10, 0.04), (0.06, 0.05), (0.0, 0.05)], n=P.n(16, 6))
    P.lathe("holo", (0, 1.10, 0), [(0.05, 0.0), (0.0, 0.0)], n=8)
    c = (0, 1.75, 0)
    for sgn in (1, -1):                                                     # crest seen from both sides
        P.decal("holo_crest", c, 1.0, 1.0, (0, 0, sgn))
    for inside in (False, True):
        P.lathe("holo", (0, 1.10, 0), [(0.05, 0.0), (0.42, 0.20)], n=P.n(16, 6), inside=inside)
    # orbiting TIE fighters: ball cockpit + two hex wings
    for k, (a, y) in enumerate(((30, 1.95), (210, 1.55))):
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        tc = (0.72 * ca, y, 0.72 * sa)
        P.sphere("holo", tc, 0.05, n=P.n(8, 5))
        for s in (-1, 1):
            wc = v_add(tc, (s * 0.09 * -sa, 0, s * 0.09 * ca))
            hexagon = [v_add(wc, (0.0, 0.09 * math.sin(math.radians(60 * j)), 0.0)) for j in range(6)]
            hexagon = [v_add(wc, v_add(v_mul((ca, 0, sa), 0.09 * math.cos(math.radians(60 * j))), (0, 0.09 * math.sin(math.radians(60 * j)), 0)))
                       for j in range(6)]
            nrm = (-sa, 0, ca)
            P.flat("holo", hexagon, nrm, fit=True)
            P.flat("holo", hexagon, v_mul(nrm, -1), fit=True)
            P.sweep("holo", [tc, wc], 0.01, sides=4)


# ---------------------------------------------------------------------------------------------------------------
# details pass: trims, hardware, props and greebles layered over each base piece (run after its builder)
# ---------------------------------------------------------------------------------------------------------------

def _studs(P, slot, pts, r=0.018):
    if P.lod < 2:
        for p in pts:
            P.sphere(slot, p, r, n=6)


def _tassel(P, top, length=0.12, slot="silk", cap="brass"):
    """A hanging tassel: brass cap bead and a fringe cone."""
    if P.lod >= 2:
        return
    P.sphere(cap, top, 0.018, n=6)
    P.lathe(slot, v_add(top, (0, -0.02 - length, 0)), [(0.0, 0.0), (0.035, 0.0), (0.012, length * 0.8), (0.0, length)],
            n=P.n(8, 5))


def _brazier(P, c, r=0.16):
    """Brass bowl brazier on a short tripod with glowing coals."""
    P.lathe("brass", (c[0], c[1] + 0.32, c[2]), [(0.03, 0.0), (r * 0.6, 0.02), (r, 0.10), (r * 1.06, 0.14),
                                                  (r * 0.95, 0.14), (r * 0.55, 0.06), (0.0, 0.06)], n=P.n(16, 6))
    P.disc("coals", (c[0], c[1] + 0.455, c[2]), 0.0, r * 0.92, n=P.n(14, 6))
    for k in range(3):
        a = 2 * math.pi * k / 3
        P.sweep("brass", [(c[0] + 0.03 * math.cos(a), c[1] + 0.34, c[2] + 0.03 * math.sin(a)),
                          (c[0] + r * 0.9 * math.cos(a), c[1] + 0.0, c[2] + r * 0.9 * math.sin(a))], 0.014, sides=P.n(6, 4))
    if P.lod < 2:
        for k in range(6):
            a = 2 * math.pi * k / 6
            P.cone("coals", (c[0] + r * 0.5 * math.cos(a), c[1] + 0.455, c[2] + r * 0.5 * math.sin(a)),
                   (c[0] + r * 0.45 * math.cos(a), c[1] + 0.53, c[2] + r * 0.45 * math.sin(a)), 0.03, n=5)


def detail_hutt_throne(P):
    # brass studs along the front roll and the dais nosing, tassels on the bolster ends
    _studs(P, "brass", [(x / 10.0, 0.43, 0.575) for x in range(-9, 10, 2)])
    _studs(P, "brass", [(x / 10.0, 0.265, 0.41) for x in range(-14, 15, 2)], r=0.014)
    for sx in (-1, 1):
        P.lathe("brass", (sx * 1.06, 0.52, 0.42), [(0.15, -0.02), (0.18, 0.0), (0.15, 0.02)], r=(90, 0, 0), n=P.n(14, 6))
        _tassel(P, (sx * 1.06, 0.36, 0.44), 0.14)
    # carved frieze panel across the backboard front, braziers on the rear corners of the upper tier
    P.decal("frieze", (0, 0.62, -0.795), 2.2, 0.16, (0, 0, 1))
    P.decal("frieze", (0, 0.95, -0.795), 1.9, 0.12, (0, 0, 1))
    for sx in (-1, 1):
        _brazier(P, (sx * 1.18, 0.26, -0.55))
    # a footstool cushion and a draped silk runner down the front tier
    if P.lod < 3:
        P.box("silk", (0, 0.124, 0.47), (0.42, 0.004, 0.07), bottom=False)


def detail_hutt_sarlacc_bed(P):
    # gum ridge along the inner lip, beak spikes guarding the mouth corners, suckers on the tentacles
    n = P.n(36, 12)
    gap = 52.0
    a0, a1 = 270 + gap + 6, 270 + 360 - gap - 6
    ridge = [(1.19 * math.cos(math.radians(a0 + (a1 - a0) * k / n)), 0.40, 1.19 * math.sin(math.radians(a0 + (a1 - a0) * k / n)))
             for k in range(n + 1)]
    P.sweep("flesh", ridge, lambda t: 0.035 * (0.4 + 0.6 * math.sin(math.pi * t)), sides=P.n(8, 4))
    for sgn in (-1, 1):
        a = math.radians(270 + sgn * (gap - 2))
        base = (1.36 * math.cos(a), 0.10, 1.36 * math.sin(a))
        P.cone("bone", base, v_add(base, (-0.25 * math.cos(a) + sgn * 0.18, 0.62, -0.25 * math.sin(a))), 0.09, n=P.n(10, 6))
    if P.lod < 2:
        for k, a in enumerate((20, 75, 130, 170, 215)):
            for j in range(1, 5):
                t = j / 5
                rr = 1.5 + 0.9 * t
                ang = math.radians(a + 35 * t * (1 if k % 2 else -1))
                P.sphere("bone", (rr * math.cos(ang), 0.05 + 0.10 * math.sin(math.pi * t) + (0.10 * (1 - t) + 0.015) * 0.8,
                                  rr * math.sin(ang)), 0.022 * (1.2 - t), n=6, sy=0.5)
    # more pillows heaped against the head bolster, a silk throw across the foot
    if P.lod < 3:
        P.rbox("velvet", (0.62, 0.47, -0.72), (0.18, 0.12, 0.06), 0.05, r=(-15, 60, 0), puff=0.025)
        P.rbox("silk", (0.70, 0.46, -0.10), (0.17, 0.11, 0.06), 0.05, r=(-12, -65, 0), puff=0.025)
        P.rbox("silk", (-0.55, 0.392, -0.30), (0.40, 0.008, 0.55), 0.008, r=(0, 15, 0))


def detail_hutt_hookah(P):
    # filigree rings on the stem, a pierced dome lid over the coals, tassels on the hoses, chains on the cage
    for y in (0.78, 0.86, 1.13, 1.28):
        P.lathe("brass", (0, y, 0), [(0.035, -0.012), (0.055, 0.0), (0.035, 0.012)], n=P.n(12, 6))
    if P.lod < 2:
        for k in range(8):
            a = 2 * math.pi * k / 8
            P.cone("brass", (0.12 * math.cos(a), 1.49, 0.12 * math.sin(a)), (0.05 * math.cos(a), 1.62, 0.05 * math.sin(a)), 0.012, n=4)
        P.sphere("brass", (0, 1.64, 0), 0.025, n=6)
        for k in range(3):
            a = math.radians(90 + 120 * k)
            _tassel(P, (0.06 * math.cos(a), 0.84, 0.06 * math.sin(a)), 0.10)
            sag = [(0.30 * math.cos(a + d), 0.60 - 0.06 * math.sin(math.pi * (d + 0.4) / 0.8), 0.30 * math.sin(a + d))
                   for d in (-0.4, -0.2, 0.0, 0.2, 0.4)]
            P.sweep("brass", sag, 0.006, sides=4)


def detail_hutt_pouf(P):
    # piped edges top and bottom, deeper tufting buttons on the sides
    n = P.n(32, 10)
    for y, r in ((0.455, 0.405), (0.15, 0.415)):
        P.sweep("silk", [(r * math.cos(2 * math.pi * k / n), y, r * math.sin(2 * math.pi * k / n)) for k in range(n)],
                0.018, closed=True, sides=P.n(6, 4))
    _studs(P, "brass", [(0.475 * math.cos(2 * math.pi * k / 12), 0.37, 0.475 * math.sin(2 * math.pi * k / 12)) for k in range(12)], 0.014)


def detail_hutt_table(P):
    # fluted apron, brass corner medallions, a fruit platter and a roast on a board
    if P.lod < 2:
        for k in range(28):
            a = 2 * math.pi * k / 28
            P.box("brass", (1.155 * math.cos(a), 0.342, 0.525 * math.sin(a)), (0.008, 0.032, 0.008), r=(0, -math.degrees(a), 0))
    for sx in (-1, 1):
        P.lathe("brass", (sx * 1.235, 0.415, 0), [(0.0, -0.035), (0.05, -0.03), (0.05, 0.03), (0.0, 0.035)], r=(0, 0, 90), n=P.n(12, 6))
    P.lathe("brass", (0.55, 0.445, 0.12), [(0.0, 0.0), (0.18, 0.0), (0.2, 0.025), (0.17, 0.02), (0.0, 0.015)], n=P.n(16, 6))
    if P.lod < 3:
        for k, (dx, dz, r) in enumerate(((0.0, 0.0, 0.06), (0.09, 0.05, 0.05), (-0.08, 0.06, 0.05), (0.03, -0.09, 0.055),
                                         (-0.06, -0.06, 0.045), (0.02, 0.02, 0.05))):
            y = 0.47 + r + (0.06 if k == 5 else 0.0)
            P.sphere("fruit%d" % (k % 4), (0.55 + dx, y, 0.12 + dz), r, n=P.n(8, 5))
    # roast on a wooden board: a lumpy joint with a bone sticking out
    P.box("wood", (-0.35, 0.455, 0.25), (0.22, 0.01, 0.13), r=(0, 12, 0))
    P.sphere("roast", (-0.36, 0.53, 0.25), 0.12, sy=0.6, r=(0, 12, 0))
    P.sweep("bone", [(-0.25, 0.53, 0.27), (-0.12, 0.56, 0.30)], 0.022, sides=P.n(8, 4))
    P.sphere("bone", (-0.11, 0.565, 0.30), 0.032, n=6)


def _xwing_band(P, z0, z1, slot="red", grow=1.012):
    t0, t1 = [(z + 1.05) / 2.45 for z in (z0, z1)]
    rings = [[(x * grow, 0.04 + (y - 0.04) * grow, z) for x, y in _xwing_section(t, False)] for t, z in ((t0, z0), (t1, z1))]
    P.loft(slot, rings, closed=True, caps=(False, False), vscale=0.5)


def detail_reb_xwing_chair(P):
    # squadron stripes as painted bands round the hump and the nose deck (the tub keeps plain hull)
    for z0, z1 in ((-0.98, -0.92), (-0.86, -0.80), (0.86, 0.93), (1.01, 1.08)):
        _xwing_band(P, z0, z1)
    # flight stick and throttle, side consoles with screens inside the tub
    P.sweep("gunmetal", [(0.0, 0.08, 0.30), (0.0, 0.38, 0.22)], 0.018, sides=P.n(8, 4))
    P.sphere("red", (0.0, 0.40, 0.21), 0.035, n=P.n(8, 5))
    for sx in (-1, 1):
        P.box("console", (sx * 0.40, 0.48, 0.15), (0.05, 0.06, 0.26), r=(0, 0, sx * -12))
        P.decal("screen", (sx * 0.345, 0.52, 0.15), 0.16, 0.06, (-sx, 0.35, 0))
    P.sweep("gunmetal", [(-0.30, 0.50, -0.05), (-0.22, 0.52, 0.05)], 0.015, sides=6)
    # hull greebles: vents and access panels on the hump, a sensor dome on the nose deck
    if P.lod < 2:
        for sx in (-1, 1):
            for k in range(3):
                P.box("gunmetal", (sx * 0.505, 0.36 + 0.07 * k, -0.85), (0.012, 0.022, 0.12), bottom=False)
            P.box("console", (sx * 0.44, 0.16, 0.40), (0.012, 0.05, 0.14), bottom=False)
        P.sphere("glass", (0.0, 0.63, 1.12), 0.05, lat0=0, lat1=90, n=P.n(10, 6))


def detail_reb_holotable(P):
    # hand rail on posts round the rim, cable runs over the floor, vents in the pedestal
    n = P.n(36, 12)
    rail = [(1.0 * math.cos(2 * math.pi * k / n), 1.05, 1.0 * math.sin(2 * math.pi * k / n)) for k in range(n)]
    P.sweep("gunmetal", rail, 0.018, closed=True, sides=P.n(6, 4))
    for k in range(6):
        a = 2 * math.pi * (k + 0.5) / 6
        P.sweep("gunmetal", [(0.94 * math.cos(a), 0.94, 0.94 * math.sin(a)), (1.0 * math.cos(a), 1.05, 1.0 * math.sin(a))], 0.015, sides=6)
    if P.lod < 3:
        for k, a in enumerate((25, 160, 250)):
            ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
            path = [(0.55 * ca, 0.04, 0.55 * sa), (0.9 * ca, 0.02, 0.9 * sa), (1.25 * ca + 0.2 * sa, 0.02, 1.25 * sa - 0.2 * ca)]
            P.sweep("gunmetal", path, 0.025, sides=P.n(6, 4))
    if P.lod < 2:
        for k in range(8):
            a = 2 * math.pi * k / 8
            P.box("gunmetal", (0.33 * math.cos(a), 0.45, 0.33 * math.sin(a)), (0.015, 0.18, 0.04), r=(0, -math.degrees(a), 0), bottom=False)


def detail_reb_bunk(P):
    zc, W = 0.20, 0.46
    # tie-down straps over the hood, a clip lamp on the hood hoop, boots tucked under, a datapad on the footlocker
    for x in (0.75, 0.95):
        hoop = [(x, 0.25 + (1.35 - 0.25 * ((x - 0.62) / 0.46) ** 2 - 0.25) * math.sin(math.pi * j / 12) + 0.012,
                 zc - (W + 0.045) * math.cos(math.pi * j / 12)) for j in range(13)]
        P.sweep("canvas", hoop, 0.012, sides=4)
    P.lathe("gunmetal", (0.62, 1.20, zc - 0.30), [(0.0, 0.0), (0.06, 0.0), (0.04, 0.08), (0.0, 0.09)], r=(150, 0, 0), n=P.n(10, 5))
    P.disc("screen", (0.62, 1.195, zc - 0.30), 0.0, 0.05, n=P.n(10, 5), r=(150, 0, 0))
    if P.lod < 2:
        for dx in (-0.08, 0.08):
            P.rbox("gunmetal", (0.25 + dx, 0.07, zc - 0.25), (0.05, 0.07, 0.11), 0.03)
        P.box("console", (-0.42, 0.25, zc), (0.10, 0.006, 0.07))
        P.decal("screen", (-0.42, 0.257, zc), 0.15, 0.10, (0, 1, 0), up=(1, 0, 0))


def detail_reb_crate_bench(P):
    # straps with buckles round each crate, stencilled numbers, a blaster and a helmet on the bench end
    for sx in (-1, 1):
        x = sx * 0.56
        P.box("canvas", (x, 0.20, 0.0), (0.04, 0.205, 0.265), bottom=False)
        P.box("gunmetal", (x, 0.30, 0.268), (0.03, 0.025, 0.004), bottom=False)
        P.decal("crest", (x + 0.15, 0.10, 0.263), 0.10, 0.10, (0, 0, 1))
    if P.lod < 2:
        P.box("gunmetal", (0.62, 0.475, 0.05), (0.13, 0.02, 0.03), r=(0, 20, 0))
        P.box("gunmetal", (0.58, 0.445, 0.07), (0.02, 0.04, 0.025), r=(0, 20, 0))
        P.sphere("hull", (-0.66, 0.465, 0.02), 0.12, lat0=-5, lat1=90, n=P.n(12, 6))


def detail_reb_locker(P):
    W, D, H = 0.55, 0.275, 2.0
    # hinges and a pull handle on the closed door, ammo boxes on the floor, a hook with a canteen
    for y in (0.35, 1.0, 1.65):
        P.sweep("gunmetal", [(-W + 0.01, y - 0.05, D + 0.02), (-W + 0.01, y + 0.05, D + 0.02)], 0.012, sides=6)
        P.sweep("gunmetal", [(W - 0.01, y - 0.05, D + 0.02), (W - 0.01, y + 0.05, D + 0.02)], 0.012, sides=6)
    P.box("gunmetal", (-0.06, 1.00, D + 0.035), (0.012, 0.10, 0.012))
    if P.lod < 2:
        for k, (x, z) in enumerate(((0.25, 0.0), (0.30, -0.12))):
            P.box("olive", (x, 0.12 + 0.11 * k, z), (0.14, 0.055, 0.08), r=(0, 10 * k, 0))
        P.lathe("olive", (0.42, 1.18, 0.12), [(0.0, -0.08), (0.06, -0.07), (0.065, 0.04), (0.02, 0.07), (0.015, 0.10), (0.0, 0.10)], n=10)


def detail_imp_pod(P):
    R, cy, cz = 1.15, 1.05, -0.10
    # raised panel ribs on the lower shell, conduits from the base, a control arm swung over the seat
    if P.lod < 3:
        for k in range(10):
            a = 360.0 * (k + 0.5) / 10
            if abs(((a - 90 + 180) % 360) - 180) < 36:
                continue
            ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
            arcp = [((R + 0.012) * math.cos(math.radians(lat)) * ca, cy + (R + 0.012) * math.sin(math.radians(lat)),
                     cz + (R + 0.012) * math.cos(math.radians(lat)) * sa) for lat in range(-55, -4, 10)]
            P.sweep("chrome", arcp, 0.012, sides=4)
    for sx in (-1, 1):
        P.sweep("black", [(sx * 0.6, 0.02, cz - 0.7), (sx * 0.75, 0.25, cz - 0.85), (sx * 0.85, 0.6, cz - 0.9)], 0.035, sides=P.n(8, 4))
    arm = [(0.30, 0.60, -0.30), (0.42, 0.85, -0.05), (0.32, 0.88, 0.30)]
    P.sweep("chrome", arm, 0.025, sides=P.n(8, 4))
    P.box("black", (0.22, 0.86, 0.36), (0.14, 0.015, 0.09), r=(25, 0, 0))
    P.decal("red", (0.22, 0.88, 0.36), 0.20, 0.10, (0, 0.9, -0.42))


def detail_imp_sd_table(P):
    # surface trench greebles down the centreline, chrome edge rims, the inlaid crest ringed in red
    if P.lod < 2:
        for k in range(9):
            x = -0.9 + 0.25 * k
            w = 0.04 + 0.03 * (k % 3)
            P.box("grey", (x, 0.79, 0.0), (0.08, 0.012, w))
        for s in (-1, 1):
            for k in range(6):
                x = -1.1 + 0.4 * k
                zz = s * (0.30 - 0.12 * (x + 1.4) / 3.1)
                P.box("black", (x, 0.786, zz), (0.10, 0.006, 0.02), bottom=False)
    P.lathe("red", (-1.40 + 0.45, 0.781, 0.0), [(0.26, 0.0), (0.27, 0.004), (0.26, 0.008)], n=P.n(24, 8))


def detail_imp_bunk(P):
    zc, L, W = 0.20, 1.04, 0.48
    # an officer's cap and a datapad on the shelf, a reading lamp, a folded blanket at the foot
    if P.lod < 2:
        P.lathe("grey", (L - 0.06, 1.20, zc + 0.20), [(0.0, 0.0), (0.10, 0.0), (0.11, 0.03), (0.09, 0.06), (0.0, 0.065)], n=P.n(12, 6))
        P.box("black", (L - 0.07, 1.205, zc + 0.20), (0.06, 0.004, 0.07))
        P.box("black", (L - 0.06, 1.21, zc - 0.20), (0.05, 0.006, 0.08))
        P.decal("screen", (L - 0.06, 1.217, zc - 0.20), 0.08, 0.13, (0, 1, 0), up=(0, 0, 1))
    P.sweep("chrome", [(L - 0.04, 1.18, zc - 0.40), (L - 0.20, 1.45, zc - 0.40)], 0.012, sides=6)
    P.lathe("black", (L - 0.22, 1.42, zc - 0.40), [(0.0, 0.0), (0.07, 0.0), (0.05, 0.06), (0.0, 0.07)], r=(0, 0, 160), n=P.n(10, 5))
    P.disc("red", (L - 0.22, 1.42, zc - 0.40), 0.0, 0.055, n=P.n(10, 5), r=(0, 0, 160))
    P.rbox("linen", (-0.78, 0.40, zc), (0.20, 0.03, 0.44), 0.025)


def detail_imp_chair(P):
    # armrest console keys, piping round the cushions, base fins
    for sx in (-1, 1):
        P.decal("screen", (sx * 0.30, 0.632, 0.05), 0.06, 0.16, (0, 1, 0), up=(0, 0, 1))
    if P.lod < 2:
        for k in range(5):
            a = 2 * math.pi * k / 5
            P.box("black", (0.22 * math.cos(a), 0.05, 0.22 * math.sin(a)), (0.012, 0.045, 0.10), r=(0, -math.degrees(a) + 90, 0))
        P.sweep("chrome", [(-0.25, 0.465, 0.25), (0.25, 0.465, 0.25)], 0.008, sides=4)


def detail_imp_holo_crest(P):
    # emitter lens ring, an orbit ring for the TIEs, base vents
    n = P.n(32, 10)
    orbit = [(0.72 * math.cos(2 * math.pi * k / n), 1.75 + 0.2 * math.sin(2 * math.pi * k / n + 0.5), 0.72 * math.sin(2 * math.pi * k / n))
             for k in range(n)]
    P.sweep("holo", orbit, 0.006, closed=True, sides=4)
    P.lathe("red", (0, 1.06, 0), [(0.15, 0.0), (0.155, 0.01), (0.15, 0.02)], n=P.n(16, 6))
    if P.lod < 2:
        for k in range(8):
            a = math.radians(22.5 + 45 * k)
            P.box("grey", (0.38 * math.cos(a), 0.05, 0.38 * math.sin(a)), (0.05, 0.012, 0.012), r=(0, -math.degrees(a) + 90, 0))


# ---------------------------------------------------------------------------------------------------------------
# interactable pieces: seats whose appearance carries a seat-activity hardpoint (see GamePlaybackScript)
# ---------------------------------------------------------------------------------------------------------------

def imp_superlaser_console(P):
    """Death Star superlaser fire-control station: a gunnery seat facing a curved black console with the firing
    lever bank and the targeting display. Sit (/sit) and the player works the console
    (all_b_int_sitting_use_console). Seat 0.46, front edge z 0.0 -> foot 0.175; the desk edge is at z 0.42."""
    # seat on a pedestal, low back
    P.lathe("black", (0, 0, 0), [(0.0, 0.0), (0.32, 0.0), (0.30, 0.03), (0.08, 0.08), (0.0, 0.08)], n=P.n(20, 8))
    P.lathe("chrome", (0, 0.08, -0.22), [(0.05, 0.0), (0.045, 0.28), (0.08, 0.30), (0.0, 0.31)], n=P.n(12, 6))
    P.rbox("black", (0, 0.40, -0.22), (0.25, 0.03, 0.23), 0.02)
    P.rbox("leather", (0, 0.43, -0.22), (0.23, 0.03, 0.22), 0.025, puff=0.01)
    P.rbox("black", (0, 0.72, -0.45), (0.22, 0.24, 0.03), 0.025, r=(-8, 0, 0))
    P.rbox("leather", (0, 0.72, -0.42), (0.19, 0.21, 0.025), 0.02, r=(-8, 0, 0), puff=0.008)
    # the console: a curved desk arc in front of the seat, a sloped control face, a raised display hood
    n = P.n(16, 6)
    r0, r1, cz = 0.62, 1.05, -0.20
    a0, a1 = 55, 125
    for k in range(n):
        aa, bb = math.radians(a0 + (a1 - a0) * k / n), math.radians(a0 + (a1 - a0) * (k + 1) / n)
        fa = (r0 * math.cos(aa), cz + r0 * math.sin(aa)); fb = (r0 * math.cos(bb), cz + r0 * math.sin(bb))
        ba = (r1 * math.cos(aa), cz + r1 * math.sin(aa)); bb_ = (r1 * math.cos(bb), cz + r1 * math.sin(bb))
        top = [(fa[0], 0.72, fa[1]), (fb[0], 0.72, fb[1]), (bb_[0], 0.86, bb_[1]), (ba[0], 0.86, ba[1])]
        P.poly("console_face", top, [(k / n, 0.0), ((k + 1) / n, 0.0), ((k + 1) / n, 1.0), (k / n, 1.0)], (0, 1, -0.4))
        P.flat("black", [(fa[0], 0.0, fa[1]), (fb[0], 0.0, fb[1]), (fb[0], 0.72, fb[1]), (fa[0], 0.72, fa[1])],
               (-(fa[0] + fb[0]) / 2, 0, -((fa[1] + fb[1]) / 2 - cz)))
        P.flat("black", [(ba[0], 0.0, ba[1]), (bb_[0], 0.0, bb_[1]), (bb_[0], 0.86, bb_[1]), (ba[0], 0.86, ba[1])],
               ((ba[0] + bb_[0]) / 2, 0, (ba[1] + bb_[1]) / 2 - cz))
    for a in (a0, a1):
        ar = math.radians(a)
        f, b = (r0 * math.cos(ar), cz + r0 * math.sin(ar)), (r1 * math.cos(ar), cz + r1 * math.sin(ar))
        side = (math.sin(ar) * (1 if a == a0 else -1), 0, -math.cos(ar) * (1 if a == a0 else -1))
        P.flat("black", [(f[0], 0.0, f[1]), (b[0], 0.0, b[1]), (b[0], 0.86, b[1]), (f[0], 0.72, f[1])], side)
    # knee recess under the desk front stays open; a red light strip along the desk lip
    lip = [((r0 - 0.005) * math.cos(math.radians(a0 + (a1 - a0) * k / n)), 0.70, cz + (r0 - 0.005) * math.sin(math.radians(a0 + (a1 - a0) * k / n)))
           for k in range(n + 1)]
    P.sweep("red", lip, 0.008, sides=4)
    # display hood: the targeting screen tilted toward the gunner, a black frame round it
    sc = (0.0, 1.12, cz + 1.02)
    P.box("black", v_add(sc, (0, 0, 0.03)), (0.40, 0.25, 0.025), r=(-18, 0, 0))
    P.decal("lcd", v_add(sc, (0, 0.01, -0.0)), 0.70, 0.42, (0, 0.31, -0.95))
    P.box("black", (0, 0.92, cz + 1.07), (0.06, 0.08, 0.04))
    # the firing levers: two banks of four with red grips, and the master switch under a guard
    if P.lod < 3:
        for bank, ax in ((-1, 0.27), (1, 0.27)):
            for k in range(4):
                x = bank * (ax + 0.05 * k)
                base = (x, 0.79, cz + 0.84)
                tip = v_add(base, (0, 0.13, -0.05 - 0.02 * k))
                P.sweep("chrome", [base, tip], 0.008, sides=4)
                P.sphere("red", tip, 0.018, n=6)
        P.box("chrome", (0, 0.785, cz + 0.78), (0.06, 0.01, 0.04), r=(-18, 0, 0))
        P.box("red", (0, 0.80, cz + 0.78), (0.03, 0.012, 0.02), r=(-18, 0, 0))
    P.decal("crest", (0, 0.36, cz + r0 * 0.99 + 0.004), 0.30, 0.30, (0, 0, -1))
    P.hardpoints.append(("use_console", (0.0, 0.75, cz + 0.85)))
    seat_hardpoint(P, 0.0)


def hutt_feast_lounge(P):
    """Hutt feasting lounge: a curved velvet couch facing a low half-moon banquet board laden with a roast,
    fruit, goblets and a gorg bowl. Sit (/sit) and the player eats (all_b_int_eat_sitting). Seat 0.46, front
    edge z 0.0 -> foot 0.175; the board edge is at z 0.38, its top at 0.50."""
    # couch: carved wooden base, deep velvet seat, curved silk back roll with brass finials
    P.box("wood", (0, 0.16, -0.25), (0.75, 0.16, 0.26))
    P.decal("frieze", (0, 0.17, 0.012), 1.48, 0.16, (0, 0, 1))
    P.rbox("velvet", (0, 0.40, -0.24), (0.76, 0.08, 0.25), 0.06, puff=0.02)
    back = [(0.80 * math.cos(math.radians(a)), 0.60 + 0.12 * math.sin(math.radians(a - 180)) ** 2, -0.24 + 0.36 * math.sin(math.radians(a)))
            for a in range(180, 361, 15)]
    back = [(x, y, min(z, -0.10)) for x, y, z in back]
    P.sweep("silk", back, lambda t: 0.12 + 0.06 * math.sin(math.pi * t), sides=P.n(10, 6), vscale=0.5)
    for sx in (-1, 1):
        P.lathe("brass", (sx * 0.80, 0.0, -0.10), [(0.0, 0.0), (0.06, 0.0), (0.05, 0.05), (0.035, 0.62), (0.06, 0.66), (0.0, 0.68)], n=P.n(12, 6))
        P.sphere("brass", (sx * 0.80, 0.74, -0.10), 0.06, n=P.n(10, 6))
    if P.lod < 3:
        P.rbox("silk", (-0.45, 0.58, -0.36), (0.20, 0.15, 0.06), 0.05, r=(-25, 15, 0), puff=0.03)
        P.rbox("velvet", (0.48, 0.57, -0.36), (0.18, 0.14, 0.06), 0.05, r=(-25, -15, 0), puff=0.03)
    # the banquet board: half-moon, brass rim, carved legs
    n = P.n(24, 8)
    board = [(0.85 * math.cos(math.pi * k / n), 0.38 + 0.45 * math.sin(math.pi * k / n)) for k in range(n + 1)]
    P.prism("wood", board, 0.46, 0.50, side_slot="brass", side_vscale=0.04, bottom=True)
    P.sweep("brass", [(x, 0.50, z) for x, z in board], 0.015, sides=P.n(6, 4))
    for x, z in ((-0.6, 0.48), (0.6, 0.48), (0.0, 0.76)):
        P.lathe("wood", (x, 0.0, z), [(0.0, 0.0), (0.06, 0.0), (0.04, 0.06), (0.06, 0.16), (0.03, 0.30), (0.05, 0.42),
                                      (0.06, 0.46), (0.0, 0.46)], n=P.n(10, 5))
    # the feast: a roast joint on a platter, a fruit heap, goblets, the gorg bowl, a candle
    P.lathe("brass", (-0.32, 0.50, 0.56), [(0.0, 0.0), (0.18, 0.0), (0.2, 0.02), (0.0, 0.015)], n=P.n(14, 6))
    P.sphere("roast", (-0.32, 0.58, 0.56), 0.13, sy=0.55, r=(0, 30, 0))
    P.sweep("bone", [(-0.22, 0.58, 0.62), (-0.10, 0.62, 0.68)], 0.022, sides=P.n(8, 4))
    P.sphere("bone", (-0.09, 0.625, 0.685), 0.034, n=6)
    P.lathe("brass", (0.30, 0.50, 0.58), [(0.0, 0.0), (0.12, 0.0), (0.16, 0.06), (0.14, 0.06), (0.0, 0.02)], n=P.n(14, 6))
    if P.lod < 3:
        for k, (dx, dz, r) in enumerate(((0.0, 0.0, 0.05), (0.07, 0.04, 0.045), (-0.06, 0.05, 0.04), (0.02, -0.07, 0.045),
                                         (-0.05, -0.04, 0.04), (0.01, 0.01, 0.045))):
            P.sphere("fruit%d" % (k % 4), (0.30 + dx, 0.56 + r * 0.6 + (0.05 if k == 5 else 0.0), 0.58 + dz), r, n=P.n(8, 5))
    for x in (-0.62, 0.62):
        P.lathe("brass", (x, 0.50, 0.50), [(0.0, 0.0), (0.04, 0.0), (0.012, 0.02), (0.01, 0.08), (0.045, 0.11), (0.05, 0.17), (0.04, 0.17), (0.0, 0.12)], n=P.n(10, 5))
    P.sphere("gorg", (0.0, 0.62, 0.70), 0.11, lat0=-80, lat1=60, n=P.n(12, 6))
    P.lathe("brass", (0.0, 0.50, 0.70), [(0.0, 0.0), (0.07, 0.0), (0.05, 0.03), (0.0, 0.03)], n=P.n(10, 5))
    P.lathe("wood", (0.0, 0.50, 0.46), [(0.0, 0.0), (0.03, 0.0), (0.025, 0.10), (0.0, 0.10)], n=8)
    P.cone("coals", (0.0, 0.60, 0.46), (0.0, 0.65, 0.46), 0.012, n=5)
    P.hardpoints.append(("eat", (-0.20, 0.55, 0.50)))
    seat_hardpoint(P, 0.0)


DETAILS = {name[len("detail_"):]: fn for name, fn in list(globals().items()) if name.startswith("detail_")}


# ---------------------------------------------------------------------------------------------------------------
# media pieces: themed video screens, magic-painting frames, the RT camera droid
#   The client (TangibleObject / ShaderPrimitiveSet "screen surfaces") puts video, magic-painting and RT-camera
#   textures only on shaders whose name contains "screen" or "canvas" when the appearance has one: slot "video"
#   (frn_titan_<theme>_video_screen) and slot "canvas" (frn_titan_painting_canvas) are those surfaces; frames
#   never use them. Screens face +z; paintings hang like stock ones: picture toward Maya +x (engine -x), the
#   wall at the origin plane x = 0, bottom edge at y = 0.
# ---------------------------------------------------------------------------------------------------------------

def _frame_ring(P, slot, x0, yc, zc, w, h, profile, axis="x", uscale=0.5):
    """Mitred picture-frame moulding round a w x h opening. profile: [(inset, depth)] from the outer back edge
    round to the sight edge (inset = distance in from the outer rectangle, depth = distance out from x0 along
    the facing axis). The outer rectangle is the opening grown by the largest inset."""
    B = max(i for i, _ in profile)
    if axis == "x":                       # picture faces +x: the ring lies in y-z
        def pt(u, v, d):
            return (x0 + d, yc + v, zc + u)
        out = (1.0, 0.0, 0.0)
        to3 = lambda iu, iv: (0.0, iv, iu)
    else:                                 # faces +z: the ring lies in x-y
        def pt(u, v, d):
            return (zc + u, yc + v, x0 + d)
        out = (0.0, 0.0, 1.0)
        to3 = lambda iu, iv: (iu, iv, 0.0)
    hw, hh = w / 2 + B, h / 2 + B
    L = [0.0]
    for k in range(1, len(profile)):
        L.append(L[-1] + math.hypot(profile[k][0] - profile[k - 1][0], profile[k][1] - profile[k - 1][1]))
    corners = lambda ins: [(-hw + ins, -hh + ins), (hw - ins, -hh + ins), (hw - ins, hh - ins), (-hw + ins, hh - ins)]
    inward = [(0.0, 1.0), (-1.0, 0.0), (0.0, -1.0), (1.0, 0.0)]          # bottom, right, top, left sides
    for k in range(len(profile) - 1):
        (i0, d0), (i1, d1) = profile[k], profile[k + 1]
        dI, dD = i1 - i0, d1 - d0
        nI, nD = -dD, dI
        ca, cb = corners(i0), corners(i1)
        for s in range(4):
            a0, a1 = ca[s], ca[(s + 1) % 4]
            b0, b1 = cb[s], cb[(s + 1) % 4]
            q = [pt(a0[0], a0[1], d0), pt(a1[0], a1[1], d0), pt(b1[0], b1[1], d1), pt(b0[0], b0[1], d1)]
            iv = to3(*inward[s])
            want = tuple(nI * iv[j] + nD * out[j] for j in range(3))
            side_len = math.hypot(a1[0] - a0[0], a1[1] - a0[1])
            uv = [(0.0, L[k] / uscale), (side_len / uscale, L[k] / uscale), (side_len / uscale, L[k + 1] / uscale),
                  (0.0, L[k + 1] / uscale)]
            P.poly(slot, q, uv, want)
    return B


def _video_surface(P, slot, c, w, h):
    """The video screen: one quad facing +z, the texture fit once (u right, v up)."""
    P.decal(slot, c, w, h, (0, 0, 1))


def imp_video_screen(P):
    """Imperial briefing screen: a 2.0 x 1.125 m display in a gloss-black monolith frame with chrome bevel and
    red light strips, on a crest-badged plinth. Only the screen surface takes the video."""
    sw, sh, yc = 2.0, 1.125, 1.42
    _frame_ring(P, "black", -0.07, yc, 0.0, sw, sh, [(0.0, 0.0), (0.0, 0.10), (0.03, 0.14), (0.12, 0.14), (0.13, 0.12)],
                axis="z", uscale=1.0)
    _frame_ring(P, "chrome", 0.05, yc, 0.0, sw, sh, [(0.0, 0.0), (0.02, 0.01), (0.03, -0.01)], axis="z", uscale=0.3)
    P.box("black", (0, yc, -0.075), (sw / 2 + 0.13, sh / 2 + 0.13, 0.005))                  # back panel
    _video_surface(P, "video", (0, yc, 0.041), sw, sh)
    for sx in (-1, 1):                                                                       # red edge strips
        P.box("red", (sx * (sw / 2 + 0.135), yc, 0.0), (0.006, sh / 2 + 0.06, 0.012), bottom=False)
    P.box("red", (0, yc - sh / 2 - 0.135, 0.0), (sw / 2 + 0.06, 0.006, 0.012))
    # plinth: stepped base, a tapered column with a light channel, the crest on the front
    P.box("black", (0, 0.04, 0.0), (0.62, 0.04, 0.34))
    P.box("grey", (0, 0.11, 0.0), (0.52, 0.03, 0.28))
    P.prism("black", [(-0.22, -0.12), (0.22, -0.12), (0.17, 0.12), (-0.17, 0.12)], 0.14, yc - sh / 2 - 0.12)
    P.box("red", (0, 0.45, 0.123), (0.02, 0.28, 0.004), bottom=False)
    P.lathe("chrome", (0, 0.32, 0.14), [(0.0, -0.01), (0.15, -0.01), (0.16, 0.01), (0.0, 0.012)], r=(90, 0, 0), n=P.n(20, 8))
    P.disc("crest", (0, 0.32, 0.153), 0.0, 0.14, fit=True, n=P.n(20, 8), r=(90, 0, 0))
    # antenna fins on the top corners
    if P.lod < 3:
        for sx in (-1, 1):
            P.box("black", (sx * (sw / 2 + 0.05), yc + sh / 2 + 0.2, -0.02), (0.012, 0.08, 0.05), r=(0, 0, sx * -12))


def detail_imp_video_screen(P):
    sw, sh, yc = 2.0, 1.125, 1.42
    # speaker grilles down the frame sides, a light bar on top, panel seams and vents on the plinth
    for sx in (-1, 1):
        for k in range(9):
            P.box("grey", (sx * (sw / 2 + 0.065), yc - 0.4 + 0.1 * k, 0.072), (0.035, 0.012, 0.004), bottom=False)
    P.box("black", (0, yc + sh / 2 + 0.17, -0.01), (0.6, 0.03, 0.06))
    P.box("red", (0, yc + sh / 2 + 0.17, 0.052), (0.55, 0.008, 0.004), bottom=False)
    if P.lod < 2:
        for k in range(6):
            P.box("grey", (-0.3 + 0.12 * k, 0.11, 0.282), (0.04, 0.012, 0.004), bottom=False)
        for sx in (-1, 1):
            P.box("chrome", (sx * 0.22, 0.14 + 0.5, 0.0), (0.008, 0.45, 0.13))
        P.decal("crest", (0, yc + sh / 2 + 0.17, 0.0565), 0.05, 0.05, (0, 0, 1))


DETAILS["imp_video_screen"] = detail_imp_video_screen


def reb_video_screen(P):
    """Alliance field briefing screen: a 1.6 x 0.9 m display in a riveted olive frame on a tripod, a keyboard
    shelf, a power crate and a comm antenna. Only the screen surface takes the video."""
    sw, sh, yc = 1.6, 0.9, 1.36
    _frame_ring(P, "olive", -0.05, yc, 0.0, sw, sh, [(0.0, 0.0), (0.0, 0.08), (0.10, 0.08), (0.10, 0.05)], axis="z", uscale=1.0)
    P.box("olive", (0, yc, -0.052), (sw / 2 + 0.10, sh / 2 + 0.10, 0.006))
    _video_surface(P, "video", (0, yc, 0.031), sw, sh)
    _studs(P, "gunmetal", [(sx * (sw / 2 + 0.05), yc + sy * (sh / 2 + 0.05), 0.083) for sx in (-1, 0, 1) for sy in (-1, 1)] +
           [(sx * (sw / 2 + 0.05), yc, 0.083) for sx in (-1, 1)], r=0.014)
    P.decal("crest", (sw / 2 - 0.02, yc - sh / 2 - 0.05, 0.081), 0.08, 0.08, (0, 0, 1))
    # tripod and yoke
    P.sweep("gunmetal", [(0, yc - sh / 2 - 0.10, -0.05), (0, 0.80, -0.08)], 0.03, sides=P.n(8, 4))
    for k in range(3):
        a = math.radians(90 + 120 * k)
        P.sweep("gunmetal", [(0, 0.80, -0.08), (0.62 * math.cos(a), 0.0, -0.08 + 0.62 * math.sin(a))], 0.022, sides=P.n(8, 4))
        P.sphere("gunmetal", (0.62 * math.cos(a), 0.02, -0.08 + 0.62 * math.sin(a)), 0.035, n=6)
    P.box("gunmetal", (0, yc - sh / 2 - 0.10, -0.06), (0.25, 0.025, 0.03))
    # keyboard shelf in front, power crate with a cable, antenna with a dish
    P.box("olive", (0, 0.82, 0.22), (0.35, 0.02, 0.14), r=(12, 0, 0))
    P.decal("console", (0, 0.845, 0.22), 0.66, 0.24, (0, 0.98, 0.2), up=(0, 0.2, -0.98))
    P.sweep("gunmetal", [(0, 0.80, 0.10), (0, 0.80, -0.06)], 0.015, sides=6)
    P.box("olive", (0.75, 0.18, 0.05), (0.22, 0.18, 0.16))
    P.decal("crest", (0.75, 0.20, 0.212), 0.16, 0.16, (0, 0, 1))
    if P.lod < 3:
        P.sweep("gunmetal", [(0.62, 0.30, 0.05), (0.45, 0.10, 0.0), (0.15, 0.04, -0.05), (0.02, 0.6, -0.08)], 0.012, sides=5)
        P.sweep("gunmetal", [(-sw / 2 - 0.06, yc + 0.2, -0.04), (-sw / 2 - 0.06, yc + sh / 2 + 0.55, -0.04)], 0.01, sides=5)
        P.lathe("gunmetal", (-sw / 2 - 0.06, yc + sh / 2 + 0.55, -0.04), [(0.0, 0.0), (0.12, 0.03), (0.13, 0.05), (0.0, 0.02)],
                r=(70, 0, 0), n=P.n(12, 6))


def hutt_video_screen(P):
    """Hutt palace screen: a 1.8 x 1.0 m display in a carved wood and brass frame under a sunburst crown, silk
    drapes tied back at the sides, on two carved posts. Only the screen surface takes the video."""
    sw, sh, yc = 1.8, 1.0, 1.55
    _frame_ring(P, "wood", -0.06, yc, 0.0, sw, sh, [(0.0, 0.0), (0.0, 0.08), (0.04, 0.12), (0.10, 0.12), (0.14, 0.10),
                                                   (0.16, 0.06)], axis="z", uscale=0.8)
    _frame_ring(P, "brass", 0.055, yc, 0.0, sw, sh, [(0.0, 0.0), (0.015, 0.012), (0.03, 0.0)], axis="z", uscale=0.3)
    P.box("wood", (0, yc, -0.065), (sw / 2 + 0.16, sh / 2 + 0.16, 0.006))
    _video_surface(P, "video", (0, yc, 0.031), sw, sh)
    for sx in (-1, 1):
        for sy in (-1, 1):
            P.lathe("brass", (sx * (sw / 2 + 0.08), yc + sy * (sh / 2 + 0.08), 0.12),
                    [(0.0, 0.0), (0.06, 0.0), (0.07, 0.02), (0.04, 0.04), (0.0, 0.045)], r=(90, 0, 0), n=P.n(14, 6))
    # sunburst crown over the frame
    top = yc + sh / 2 + 0.16
    P.lathe("brass", (0, top, 0.02), [(0.0, -0.02), (0.20, 0.0), (0.22, 0.03), (0.0, 0.05)], r=(90, 0, 0), n=P.n(18, 8))
    for k in range(9):
        a = math.radians(15 + 150 * k / 8)
        base = (0.18 * math.cos(a), top + 0.18 * math.sin(a), 0.02)
        P.cone("brass", base, v_add(base, (0.22 * math.cos(a), (0.30 if k % 2 == 0 else 0.18) * math.sin(a), 0.0)), 0.035)
    P.sphere("coals", (0, top + 0.01, 0.075), 0.05, n=P.n(10, 6))
    # posts on a sandstone base, drapes hanging from a brass rod
    P.box("sandstone", (0, 0.06, 0.0), (sw / 2 + 0.30, 0.06, 0.30))
    for sx in (-1, 1):
        x = sx * (sw / 2 + 0.10)
        P.lathe("wood", (x, 0.12, -0.02), [(0.0, 0.0), (0.09, 0.0), (0.07, 0.08), (0.05, 0.25), (0.06, 0.6), (0.045, 0.9),
                                           (0.05, yc - sh / 2 - 0.28), (0.0, yc - sh / 2 - 0.28)], n=P.n(12, 6))
    rod_y = top + 0.10
    P.sweep("brass", [(-sw / 2 - 0.45, rod_y, 0.14), (sw / 2 + 0.45, rod_y, 0.14)], 0.02, sides=P.n(8, 4))
    for sx in (-1, 1):
        P.sphere("brass", (sx * (sw / 2 + 0.47), rod_y, 0.14), 0.04, n=P.n(8, 5))
        # a drape: a pleated sheet from the rod, gathered by a tie-back at screen height
        m = P.n(10, 4)
        rows = []
        for j in range(m + 1):
            t = j / m
            y = rod_y - t * (rod_y - 0.14)
            gather = 1.0 - 0.75 * math.exp(-((y - (yc - 0.1)) / 0.25) ** 2)
            x_in = sx * (sw / 2 + 0.05 + (0.20 * (1 - gather)))
            x_out = sx * (sw / 2 + 0.42)
            ring = []
            for i in range(9):
                u = i / 8
                x = x_out + (x_in - x_out) * u * gather + (x_in - x_out) * (1 - gather) * 0.0
                z = 0.16 + 0.035 * math.sin(u * math.pi * 6) * gather
                ring.append((x, y, z))
            rows.append(ring)
        Pg = [[rows[j][i] for j in range(m + 1)] for i in range(9)]
        U = [[i / 8 * 2.0] * (m + 1) for i in range(9)]
        V = [[j / m * 2.5 for j in range(m + 1)] for _ in range(9)]
        for sgn in (1, -1):
            P.grid("silk", Pg, U, V, lambda q, s=sgn: (0.0, 0.0, s))
        P.sweep("brass", [(sx * (sw / 2 + 0.12), yc - 0.1, 0.17), (sx * (sw / 2 + 0.30), yc - 0.1, 0.17)], 0.015, sides=6)
        _tassel(P, (sx * (sw / 2 + 0.30), yc - 0.12, 0.17), 0.12)


def _painting(P, frame_slot, profile, canvas_w=1.2, canvas_h=0.9):
    """Canvas + mitred frame hung like stock paintings; returns (border, canvas centre y)."""
    B = max(i for i, _ in profile)
    yc = B + canvas_h / 2
    _frame_ring_x(P, frame_slot, yc, canvas_w, canvas_h, profile)
    P.decal("canvas", (0.016, yc, 0.0), canvas_w, canvas_h, (1, 0, 0))
    # back board
    P.flat(frame_slot, [(0.006, yc - canvas_h / 2 - B, -canvas_w / 2 - B), (0.006, yc - canvas_h / 2 - B, canvas_w / 2 + B),
                        (0.006, yc + canvas_h / 2 + B, canvas_w / 2 + B), (0.006, yc + canvas_h / 2 + B, -canvas_w / 2 - B)], (-1, 0, 0))
    return B, yc


def _frame_ring_x(P, slot, yc, w, h, profile):
    """_frame_ring for a picture facing +x: width along z, height along y, from the wall plane x = 0.006."""
    return _frame_ring(P, slot, 0.006, yc, 0.0, w, h, profile, axis="x", uscale=0.5)


def gilded_painting(P):
    """Gilded gallery frame: an ornate gold moulding (bead, cove, flat, sight bead), corner rosettes and a shell
    cartouche. The canvas takes the magic-painting image."""
    prof = [(0.0, 0.0), (0.0, 0.045), (0.012, 0.06), (0.03, 0.065), (0.045, 0.05), (0.07, 0.042), (0.10, 0.045),
            (0.115, 0.052), (0.13, 0.04), (0.14, 0.012)]
    B, yc = _painting(P, "gilt", prof)
    cw, ch = 1.2, 0.9
    for sy in (-1, 1):
        for sz in (-1, 1):
            P.lathe("gilt", (0.055, yc + sy * (ch / 2 + B * 0.55), sz * (cw / 2 + B * 0.55)),
                    [(0.0, 0.0), (0.045, 0.0), (0.05, 0.012), (0.03, 0.028), (0.0, 0.03)], r=(0, 0, -90), n=P.n(12, 6))
    for k in range(7):
        a = math.radians(25 + 130 * k / 6)
        base = (0.05, yc + ch / 2 + B * 0.7, 0.0)
        P.cone("gilt", base, v_add(base, (0.0, 0.10 * math.sin(a) + 0.02, 0.14 * math.cos(a))), 0.025, n=P.n(6, 4))
    P.sphere("gilt", (0.06, yc + ch / 2 + B * 0.75, 0.0), 0.035, n=P.n(10, 6))


def hutt_painting(P):
    """Hutt palace frame: deep carved wood with a brass sight edge, brass studs, a jewelled medallion on top and
    silk tassels. The canvas takes the magic-painting image."""
    prof = [(0.0, 0.0), (0.0, 0.07), (0.03, 0.09), (0.12, 0.09), (0.15, 0.07), (0.16, 0.03)]
    B, yc = _painting(P, "wood", prof)
    cw, ch = 1.2, 0.9
    _frame_ring(P, "brass", 0.036, yc, 0.0, cw, ch, [(0.0, 0.0), (0.01, 0.006), (0.02, -0.012)], axis="x", uscale=0.3)
    zs = [(-cw / 2 - B / 2) + k * (cw + B) / 8 for k in range(9)]
    _studs(P, "brass", [(0.098, yc + sy * (ch / 2 + B / 2), z) for z in zs for sy in (-1, 1)], r=0.013)
    P.lathe("brass", (0.08, yc + ch / 2 + B + 0.08, 0.0), [(0.0, -0.02), (0.12, 0.0), (0.13, 0.025), (0.0, 0.04)],
            r=(0, 0, -90), n=P.n(16, 6))
    P.sphere("coals", (0.125, yc + ch / 2 + B + 0.08, 0.0), 0.04, n=P.n(10, 6))
    for sz in (-1, 1):
        _tassel(P, (0.09, yc - ch / 2 - B - 0.01, sz * (cw / 2 + B * 0.5)), 0.14)


def reb_painting(P):
    """Alliance salvage frame: a hull-plate border with a squadron stripe, rivets and a starbird plaque. The
    canvas takes the magic-painting image."""
    prof = [(0.0, 0.0), (0.0, 0.05), (0.13, 0.05), (0.13, 0.02)]
    B, yc = _painting(P, "hull", prof)
    cw, ch = 1.2, 0.9
    _frame_ring(P, "red", 0.056, yc, 0.0, cw + 0.14, ch + 0.14, [(0.0, 0.0), (0.03, 0.0)], axis="x", uscale=0.5)
    zs = [(-cw / 2 - B / 2) + k * (cw + B) / 10 for k in range(11)]
    _studs(P, "gunmetal", [(0.058, yc + sy * (ch / 2 + B * 0.25), z) for z in zs for sy in (-1, 1)], r=0.01)
    P.box("gunmetal", (0.065, yc - ch / 2 - B / 2, 0.0), (0.012, 0.045, 0.16))
    P.decal("crest", (0.078, yc - ch / 2 - B / 2, 0.0), 0.075, 0.075, (1, 0, 0))


def imp_painting(P):
    """Imperial frame: stepped gloss-black moulding, a chrome sight bevel, a red light strip round the canvas and
    the crest on top. The canvas takes the magic-painting image."""
    prof = [(0.0, 0.0), (0.0, 0.06), (0.04, 0.06), (0.04, 0.075), (0.11, 0.075), (0.12, 0.05), (0.13, 0.02)]
    B, yc = _painting(P, "black", prof)
    cw, ch = 1.2, 0.9
    _frame_ring(P, "chrome", 0.022, yc, 0.0, cw, ch, [(0.0, 0.0), (0.012, 0.012), (0.018, 0.0)], axis="x", uscale=0.3)
    _frame_ring(P, "red", 0.077, yc, 0.0, cw + 0.15, ch + 0.15, [(0.0, 0.0), (0.012, 0.0)], axis="x", uscale=0.5)
    P.lathe("chrome", (0.06, yc + ch / 2 + B + 0.07, 0.0), [(0.0, -0.01), (0.09, -0.01), (0.1, 0.01), (0.0, 0.012)],
            r=(0, 0, -90), n=P.n(18, 8))
    P.disc("crest", (0.073, yc + ch / 2 + B + 0.07, 0.0), 0.0, 0.085, fit=True, n=P.n(18, 8), r=(0, 0, -90))


def cam_droid(P):
    """RT camera droid: a hovering cam droid over its charging pad. The lens faces +z and carries the `lens`
    hardpoint, where the client renders the camera feed from (RtCameraManager)."""
    cy = 1.55
    # charging pad and the repulsor column
    P.lathe("cam_metal", (0, 0, 0), [(0.0, 0.0), (0.30, 0.0), (0.31, 0.03), (0.26, 0.06), (0.0, 0.06)], n=P.n(24, 8))
    P.disc("cam_glow", (0, 0.061, 0), 0.0, 0.22, fit=True, n=P.n(20, 8))
    for inside in (False, True):
        P.lathe("holo", (0, 0.06, 0), [(0.16, 0.0), (0.07, cy - 0.27)], n=P.n(16, 6), inside=inside)
    # body: a sphere with a waist band, the lens barrel forward
    P.sphere("cam_metal", (0, cy, 0), 0.20, n=P.n(24, 10))
    P.lathe("black", (0, cy, 0), [(0.205, -0.02), (0.215, 0.0), (0.205, 0.02)], n=P.n(24, 10))
    P.lathe("cam_metal", (0, cy, 0.12), [(0.12, 0.0), (0.125, 0.06), (0.11, 0.14), (0.10, 0.19), (0.115, 0.205), (0.0, 0.205)],
            r=(90, 0, 0), n=P.n(20, 8))
    P.disc("cam_lens", (0, cy, 0.326), 0.0, 0.085, fit=True, n=P.n(20, 8), r=(90, 0, 0))
    P.lathe("black", (0, cy, 0.31), [(0.115, 0.0), (0.122, 0.02), (0.112, 0.03), (0.09, 0.025)], r=(90, 0, 0), n=P.n(20, 8))
    # side repulsor pods with downward glow, antennas, the red recording light
    for sx in (-1, 1):
        c = (sx * 0.23, cy - 0.04, -0.02)
        P.sphere("cam_metal", c, 0.07, n=P.n(12, 6), sy=0.8)
        P.disc("cam_glow", v_add(c, (0, -0.058, 0)), 0.0, 0.05, fit=True, n=P.n(10, 5), down=True)
        P.sweep("black", [(sx * 0.10, cy + 0.17, -0.08), (sx * 0.16, cy + 0.38, -0.16)], 0.006, sides=4)
        P.sphere("red", (sx * 0.16, cy + 0.385, -0.16), 0.012, n=6)
    P.disc("cam_glow", (0, cy - 0.201, 0), 0.0, 0.09, fit=True, n=P.n(12, 6), down=True)
    P.sphere("red", (0.0, cy + 0.17, 0.11), 0.022, n=P.n(8, 5))
    if P.lod < 2:
        for k in range(6):
            a = math.radians(-60 + 24 * k)
            P.box("black", (0.205 * math.sin(a), cy + 0.08, -0.205 * math.cos(a) * 0.98), (0.03, 0.006, 0.004), r=(0, -math.degrees(a), 0))
    P.hardpoints.append(("lens", (0.0, cy, 0.33)))


# ---------------------------------------------------------------------------------------------------------------
# registry, materials, export
# ---------------------------------------------------------------------------------------------------------------

# name -> builder, kind (seat / bed / table / decor), material slot -> material key or stock shader
PIECES = {
    "hutt_throne": (hutt_throne, "seat"),
    "hutt_sarlacc_bed": (hutt_sarlacc_bed, "bed"),
    "hutt_hookah": (hutt_hookah, "decor"),
    "hutt_pouf": (hutt_pouf, "seat"),
    "hutt_table": (hutt_table, "table"),
    "reb_xwing_chair": (reb_xwing_chair, "seat"),
    "reb_holotable": (reb_holotable, "table"),
    "reb_bunk": (reb_bunk, "bed"),
    "reb_crate_bench": (reb_crate_bench, "seat"),
    "reb_locker": (reb_locker, "decor"),
    "imp_pod": (imp_pod, "seat"),
    "imp_sd_table": (imp_sd_table, "table"),
    "imp_bunk": (imp_bunk, "bed"),
    "imp_chair": (imp_chair, "seat"),
    "imp_holo_crest": (imp_holo_crest, "decor"),
    "imp_superlaser_console": (imp_superlaser_console, "seat"),
    "hutt_feast_lounge": (hutt_feast_lounge, "seat"),
    "imp_video_screen": (imp_video_screen, "screen"),
    "reb_video_screen": (reb_video_screen, "screen"),
    "hutt_video_screen": (hutt_video_screen, "screen"),
    "gilded_painting": (gilded_painting, "painting"),
    "hutt_painting": (hutt_painting, "painting"),
    "reb_painting": (reb_painting, "painting"),
    "imp_painting": (imp_painting, "painting"),
    "cam_droid": (cam_droid, "rtcamera"),
}
# slot -> material key per theme prefix (frn_materials.MATS keys)
SLOTS = {
    "hutt": {"sandstone": "hutt_sandstone", "frieze": "hutt_frieze", "velvet": "hutt_velvet", "silk": "hutt_silk",
             "brass": "hutt_brass", "wood": "hutt_wood", "flesh": "hutt_flesh", "bone": "hutt_bone",
             "coals": "hutt_coals", "gorg": "hutt_gorg_water", "rug": "hutt_rug", "roast": "hutt_roast",
             "video": "hutt_video_screen", "canvas": "painting_canvas",
             "fruit0": "hutt_fruit_0", "fruit1": "hutt_fruit_1", "fruit2": "hutt_fruit_2", "fruit3": "hutt_fruit_3"},
    "reb": {"olive": "reb_olive", "hull": "reb_hull", "hull_stripe": "reb_hull_stripe", "quilt": "reb_quilt",
            "canvas": "reb_canvas", "blanket": "reb_blanket", "crest": "reb_crest", "console": "reb_console",
            "screen": "reb_screen", "holo": "reb_holo", "holo_dish": "reb_holo_dish", "glass": "reb_glass",
            "r2": "reb_r2", "gunmetal": "reb_gunmetal", "red": "reb_red",
            "video": "reb_video_screen", "canvas": "painting_canvas"},
    "imp": {"black": "imp_black", "grey": "imp_grey", "white": "imp_white", "leather": "imp_leather",
            "red": "imp_red", "crest": "imp_crest", "chrome": "imp_chrome", "holo": "imp_holo",
            "holo_crest": "imp_holo_crest", "linen": "imp_linen", "pillow": "imp_pillow",
            "holo_solid": "imp_holo_solid", "screen": "imp_screen", "lcd": "imp_screen", "console_face": "reb_console",
            "video": "imp_video_screen", "canvas": "painting_canvas"},
    "gilded": {"gilt": "gilt", "canvas": "painting_canvas"},
    "cam": {"cam_metal": "cam_metal", "cam_glow": "cam_glow", "cam_lens": "cam_lens", "holo": "reb_holo",
            "black": "imp_black", "red": "imp_red"},
}
COLORS = {"hutt": (0.7, 0.5, 0.3), "reb": (0.5, 0.55, 0.4), "imp": (0.3, 0.3, 0.32), "gilded": (0.8, 0.65, 0.3),
          "cam": (0.4, 0.42, 0.46)}

# the themed groups in frn_groups/ (one module per group) add their pieces, slots and UV scales here
from . import frn_groups as _frn_groups  # noqa: E402
_frn_groups.register(globals())


def build_piece(name, lod=0):
    P = F(lod)
    PIECES[name][0](P)
    if name in DETAILS:
        DETAILS[name](P)
    return P


def piece_name(name):
    return PREFIX + name


def _sg(theme, slot):
    key = SLOTS[theme][slot]
    sgn = f"frn_{key}SG"
    if cmds.objExists(sgn):
        return sgn
    sht = f"{SHADER_ROOT}/shader/{PREFIX}{key}.sht"
    tex = f"{SHADER_ROOT}/texture/{PREFIX}{key}.dds"
    sg = pb._material(f"frn_{key}", COLORS[theme], tex if os.path.exists(tex) else None, sht)
    return sg


def _place(P, theme, root, tag):
    made = []
    for slot, acc in P.acc.items():
        if not acc.counts:
            continue
        m = acc.build(f"{tag}_{slot}", "|" + root)
        if m is None:
            continue
        cmds.polySoftEdge(m, angle=70 if slot in SMOOTH_SLOTS or slot.startswith("holo") else SOFT["default"], ch=False)
        cmds.sets(m, edit=True, forceElement=_sg(theme, slot))
        made.append(m)
    return made


def _faces(root):
    meshes = cmds.listRelatives("|" + root, allDescendents=True, type="mesh", fullPath=True) or []
    return sum(int(cmds.polyEvaluate(m, face=True)) for m in meshes)


def build(name, export_root):
    """Build one piece (4 LODs) in a fresh scene and export appearance/frn_titan_<name>.apt (+ _l1.._l3)."""
    configure(export_root)
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    theme = name.split("_")[0]
    full = piece_name(name)
    out = {"name": name, "template_name": full, "kind": PIECES[name][1], "lods": []}
    root = cmds.createNode("transform", name=full)
    for lod in range(4):
        P = build_piece(name, lod)
        for m in cmds.listRelatives("|" + root, children=True, type="transform", fullPath=True) or []:
            cmds.delete(m)
        _place(P, theme, root, f"{full}_l{lod}")
        if lod == 0:
            for hp in P.hardpoints:
                t = cmds.createNode("transform", name=hp[0], parent="|" + root)
                cmds.setAttr(t + ".translate", *hp[1], type="double3")
                if len(hp) > 2:
                    cmds.setAttr(t + ".rotate", *hp[2], type="double3")
            out["hardpoints"] = [[hp[0], list(hp[1])] + ([list(hp[2])] if len(hp) > 2 else []) for hp in P.hardpoints]
            out["bounds"] = [round(v, 3) for v in cmds.exactWorldBoundingBox("|" + root)]
            out["faces"] = [_faces(root)]
            rel = f"appearance/{full}.apt"
        else:
            out["faces"].append(_faces(root))
            rel = f"appearance/{full}_l{lod}.apt"
            out["lods"].append(rel)
        os.makedirs(os.path.dirname(f"{export_root}/{rel}"), exist_ok=True)
        cmds.select("|" + root, replace=True)
        mel.eval(f'exportStaticMesh -path "{export_root}/{rel}" -collision none')
        if lod == 0:
            out["apt"] = rel
    out["shaders"] = sorted({SLOTS[theme][s] for s in build_piece(name, 0).acc})
    return out


def preview(names, gap=0.8, lod=0, export_root=None):
    """Pieces side by side for review renders (nothing exported)."""
    if export_root:
        configure(export_root)
    cmds.file(new=True, force=True)
    x = 0.0
    for name in names:
        P = build_piece(name, lod)
        grp = cmds.createNode("transform", name=f"pv_{name}")
        _place(P, name.split("_")[0], grp, f"pv_{name}")
        bb = cmds.exactWorldBoundingBox("|" + grp)
        cmds.setAttr(f"|{grp}.translateX", x - bb[0])
        x += (bb[3] - bb[0]) + gap
    return {"width": x}
