"""Battle of Naboo heroic set (Titan): Trade Federation vehicles and Gungan Grand Army pieces, built with the
furniture.F primitives - runs inside Maya with SwgMayaEditor for export, and outside Maya (maya stubbed) for
examples/geo_preview.py renders.

  MTT  (Multi-Troop Transport, ~30 m)   mtt_hull + three moving parts hung on hull hardpoints (hp_dyn "part"):
         mtt_lid    the upper front door, hinged at the top front of the hull     rot about X, -80 deg (lifts)
         mtt_chin   the lower front ramp between the cannon pods                   rot about X, +72 deg (drops)
         mtt_rack   the droid rack, 112 B1s folded on four shelves a side          move along +Z, 10 m
         mtt_rack_empty  the same rack once the droids have deployed (swapped in by the server)
  AAT  (Armored Assault Tank, ~9.8 m)   see aat_* below.

Conventions (Maya space, the exporter mirrors X): y up, the vehicle's front faces +z, the ground is y = 0 under
the hovering hull. A part is modelled in its own hardpoint space: the hardpoint's origin is the hinge (or the
slide origin) and its axes are the hull's, so state 0 is the part as modelled. Rotations about X are unchanged by
the X mirror; rotations about Y and Z change sign in engine space.
"""

from __future__ import annotations

import math

from . import furniture as fu
from .furniture import F, xf, v_add, v_sub, v_mul, v_norm, v_cross, v_len

# material slot -> texture name (examples/naboo_battle_materials.py) and metres per texture tile
SLOT_TEX = {
    "mtt": "tf_mtt_paint", "mtt_hard": "tf_mtt_paint", "aat": "tf_aat_paint", "cream": "tf_aat_cream", "dark": "tf_metal_dark",
    "vent": "tf_vent", "glow_red": "tf_glow_red", "droid": "tf_aat_cream",
    "dome": "nboo_shield_dome", "rim": "nboo_shield_rim", "hshield": "nboo_hand_shield",
    "brass": "nboo_gungan_brass", "hide": "nboo_gungan_hide", "glow": "nboo_gungan_glow",
    "plasma": "tf_plasma_bolt", "booma": "nboo_booma_glow", "disk": "titan_info_disk_historical",
    "rbeam": "nboo_rally_beam", "rring": "nboo_rally_ring",
}
UV_SCALE = {"mtt": 11.0, "mtt_hard": 11.0, "aat": 3.2, "cream": 1.6, "dark": 1.4, "vent": 1.0, "glow_red": 1.0, "droid": 0.8,
            "dome": 24.0, "rim": 6.0, "hshield": 1.0, "brass": 1.2, "hide": 0.8, "glow": 0.6, "plasma": 1.0,
            "booma": 1.0, "disk": 1.0, "rbeam": 1.0, "rring": 1.0}
fu.UV.update(UV_SCALE)
fu.SMOOTH_SLOTS = tuple(fu.SMOOTH_SLOTS) + ("mtt", "aat", "cream", "dome", "hshield", "glow", "booma")

PREVIEW_TEX = dict(SLOT_TEX)
PREVIEW_COL = {"mtt": (0.55, 0.27, 0.18), "aat": (0.77, 0.55, 0.22), "dark": (0.22, 0.23, 0.25)}

DET = (1.0, 0.55, 0.28)                 # tessellation per LOD (l0..l2)


class V(F):
    """F with the vehicle LOD table."""

    def n(self, k, lo=4):
        return max(lo, int(round(k * DET[self.lod])))


# ============================================================================
# shared helpers
# ============================================================================

def superellipse(n_pts, ex, phase=0.0):
    """Unit superellipse ring (ux, uy), counter-clockwise from +x; ex = 2 ellipse, larger = boxier."""
    out = []
    for i in range(n_pts):
        a = 2 * math.pi * i / n_pts + phase
        c, s = math.cos(a), math.sin(a)
        out.append((math.copysign(abs(c) ** (2.0 / ex), c), math.copysign(abs(s) ** (2.0 / ex), s)))
    return out


def lerp(a, b, t):
    return a + (b - a) * t


def station_ring(st, n_pts):
    """A hull section: st = (z, y_bottom, y_top, half_width_bottom, half_width_top, exponent)."""
    z, yb, yt, wb, wt, ex = st
    yc, hh = (yb + yt) / 2, (yt - yb) / 2
    ring = []
    for ux, uy in superellipse(n_pts, ex, math.pi / n_pts):
        t = (uy + 1) / 2
        ring.append((ux * lerp(wb, wt, t), yc + uy * hh, z))
    return ring


def interp_station(stations, z):
    for a, b in zip(stations, stations[1:]):
        if a[0] <= z <= b[0]:
            t = (z - a[0]) / ((b[0] - a[0]) or 1.0)
            return tuple(lerp(a[k], b[k], t) for k in range(6))
    return stations[0] if z < stations[0][0] else stations[-1]


def side_point(stations, z, uy, side=1.0, inset=0.0):
    """A point on the hull side at station z and normalised height uy (-1 bottom .. 1 top) and its outward
    normal (approximate, from the superellipse at that height)."""
    zz, yb, yt, wb, wt, ex = interp_station(stations, z)
    yc, hh = (yb + yt) / 2, (yt - yb) / 2
    ux = (max(0.0, 1.0 - abs(uy) ** ex)) ** (1.0 / ex)
    t = (uy + 1) / 2
    w = lerp(wb, wt, t)
    p = (side * (ux * w - inset), yc + uy * hh, z)
    # normal: gradient of |x/w|^ex + |(y-yc)/hh|^ex, plus the lean of w with height
    gx = ex * (ux ** (ex - 1)) / w
    gy = ex * (abs(uy) ** (ex - 1)) / hh * math.copysign(1.0, uy) - gx * ux * (wt - wb) / (2 * hh) * 0.0
    nrm = v_norm((side * gx, gy - gx * ux * (wt - wb) / (2 * hh) * (ex / 2), 0.0))
    return p, nrm


def panel(P, slot, c, nrm, w, h, up=(0.0, 1.0, 0.0), lift=0.025):
    """A decal panel (texture fit once) lifted off a surface along its normal."""
    P.decal(slot, v_add(c, v_mul(nrm, lift)), w, h, nrm, up)


def barrel(P, slot, base, tip, r, sides=None, rings=()):
    """A gun barrel: a tube base -> tip with optional collars [(t, radius, length)]."""
    sides = sides or P.n(10, 5)
    P.sweep(slot, [base, tip], r, sides=sides)
    d = v_norm(v_sub(tip, base))
    L = v_len(v_sub(tip, base))
    for t, rr, ln in rings:
        a = v_add(base, v_mul(d, L * t - ln / 2))
        b = v_add(base, v_mul(d, L * t + ln / 2))
        P.sweep(slot, [a, b], rr, sides=sides)


def ellipsoid(P, slot, c, rx, ry, rz, lat0=-90.0, lat1=90.0, r=(0, 0, 0)):
    rows = max(3, P.n(12, 4) * int(abs(lat1 - lat0)) // 180 or 3)
    prof = [(math.cos(math.radians(lerp(lat0, lat1, k / rows))), math.sin(math.radians(lerp(lat0, lat1, k / rows))))
            for k in range(rows + 1)]
    n = P.n(20, 8)
    rings = []
    for cr, sy in prof:
        rings.append([xf((rx * cr * math.cos(2 * math.pi * i / n), ry * sy, rz * cr * math.sin(2 * math.pi * i / n)),
                         c, r) for i in range(n)])
    # loft between latitude rings; poles collapse (degenerate quads are dropped by the accumulator)
    for k in range(len(rings) - 1):
        for i in range(n):
            i1 = (i + 1) % n
            q = [rings[k][i], rings[k][i1], rings[k + 1][i1], rings[k + 1][i]]
            mid = tuple(sum(p[j] for p in q) / 4 for j in range(3))
            uv = [(i / n * 2 * math.pi * max(rx, rz) / fu.UV.get(slot, 1.0), k / rows * math.pi * ry / fu.UV.get(slot, 1.0)),
                  ((i + 1) / n * 2 * math.pi * max(rx, rz) / fu.UV.get(slot, 1.0), k / rows * math.pi * ry / fu.UV.get(slot, 1.0)),
                  ((i + 1) / n * 2 * math.pi * max(rx, rz) / fu.UV.get(slot, 1.0), (k + 1) / rows * math.pi * ry / fu.UV.get(slot, 1.0)),
                  (i / n * 2 * math.pi * max(rx, rz) / fu.UV.get(slot, 1.0), (k + 1) / rows * math.pi * ry / fu.UV.get(slot, 1.0))]
            P.poly(slot, q, uv, v_sub(mid, c))


# ============================================================================
# MTT
# ============================================================================

# ----------------------------------------------------------------------------------------------------------------
# MTT layout, from the front and side orthographic references (scale ~0.057 m/px on the side view): a long, angular
# rear body (hexagonal section with a horizontal crease, lower than the head); a tall narrow head (cowl) over the
# front of the body; the droid rack filling the face under the head, its nose the round-hub shield plate; two trunk
# pods that sweep from the head sides down to the bottom front corners, twin cannons stacked in each; rack
# machinery exposed under the head behind the pods.

# rear body sections: z, then (half-width, y) pairs bottom -> crease -> shoulder -> top (mirrored for -x)
MTT_BODY = [
    (-15.0, [(3.5, 2.0), (4.5, 4.2), (3.6, 6.6), (2.8, 7.3)]),
    (-14.4, [(4.15, 1.05), (5.3, 4.9), (4.0, 7.9), (3.15, 8.45)]),
    (-12.6, [(4.3, 1.0), (5.45, 5.25), (4.2, 8.7), (3.3, 9.3)]),
    (-9.9, [(4.35, 1.0), (5.5, 5.35), (4.3, 9.1), (3.4, 10.0)]),
    (1.0, [(4.35, 1.0), (5.5, 5.35), (4.3, 9.1), (3.4, 10.0)]),
]
# the front face of the body leans back under the head (bottom further forward than the shoulder)
MTT_BODY_FRONT = [(4.2, 1.0, 4.4), (5.3, 5.3, 3.4), (4.2, 9.0, 2.6), (3.3, 9.9, 2.3)]
# head (cowl): z, (half-width, y) bottom -> mid -> shoulder -> top
MTT_HEAD = [
    (0.2, [(3.3, 5.6), (3.3, 8.0), (2.3, 9.9), (1.4, 10.4)]),
    (2.6, [(3.45, 5.0), (3.5, 8.3), (2.6, 11.5), (1.6, 12.55)]),
    (9.4, [(3.45, 5.0), (3.5, 8.3), (2.6, 11.5), (1.6, 12.55)]),
    (10.3, [(3.3, 5.0), (3.35, 8.3), (2.45, 11.4), (1.45, 12.35)]),
]
MTT_LID_HINGE = (0.0, 12.45, 9.7)          # the upper front cowl lifts about its top edge
MTT_CHIN_HINGE = (0.0, 1.0, 11.0)          # the step plate under the rack nose drops forward
MTT_RACK_ORIGIN = (0.0, 0.0, 0.0)
MTT_RACK_TRAVEL = 10.0
MTT_LID_ANGLE = -100.0
MTT_CHIN_ANGLE = 70.0
# trunk pods: centreline (x for the +x pod, y, z) from the head side to the tip, and radius along it
MTT_TRUNK = [(2.95, 10.4, 6.4), (3.2, 9.6, 9.1), (3.55, 7.4, 11.3), (3.8, 4.6, 12.9), (3.9, 2.2, 13.5)]
MTT_TRUNK_R = (2.0, 2.05, 1.85, 1.6, 1.38)
MTT_BARRELS = ((2.8, 18.2), (1.65, 18.2))        # (y, tip z) of the stacked twin cannons
# rack: half width, shelf heights, stowed z range (nose cap flush with the head front), droids per shelf per side
RACK_HALF = 2.2
RACK_SHELVES = (1.75, 3.25, 4.75, 6.25)
RACK_TOP = 7.65
RACK_Z0, RACK_Z1 = -4.8, 10.45
RACK_PER_SHELF = 14


def _mirror_ring(half, z=None):
    """(half-width, y[, z]) pairs bottom -> top on +x, completed by the mirror: a closed ring, counter-clockwise
    seen from the front."""
    right = [(w, y, (p[2] if len(p) > 2 else z)) for p in half for w, y in [p[:2]]]
    left = [(-x, y, zz) for x, y, zz in reversed(right)]
    return right + left


def _subdivide(ring, n):
    """Ring with each edge split into n segments (keeps the facets, gives the soft-edge pass more to work with)."""
    out = []
    for k in range(len(ring)):
        a, b = ring[k], ring[(k + 1) % len(ring)]
        for i in range(n):
            t = i / n
            out.append(tuple(a[j] + (b[j] - a[j]) * t for j in range(3)))
    return out


def mtt_hull(lod=0):
    P = V(lod)
    sub = 2 if lod == 0 else 1
    # rear body: faceted loft closed at the back, open at the front where its leaning front face is capped
    rings = [_subdivide(_mirror_ring(h, z), sub) for z, h in MTT_BODY]
    front = _subdivide(_mirror_ring(MTT_BODY_FRONT), sub)
    P.loft("mtt_hard", rings + [front], caps=(True, True))
    # head: same treatment, its back sloping down onto the body top
    hrings = [_subdivide(_mirror_ring(h, z), sub) for z, h in MTT_HEAD]
    P.loft("mtt_hard", hrings, caps=(True, False))
    _mtt_head_front(P, hrings[-1])
    _mtt_trunks(P)
    _mtt_machinery(P)
    _mtt_details(P)
    P.hardpoints += [("hp_lid", MTT_LID_HINGE), ("hp_chin", MTT_CHIN_HINGE), ("hp_rack", MTT_RACK_ORIGIN)]
    for side, sx in (("l", 1.0), ("r", -1.0)):
        for k, (y, z) in enumerate(MTT_BARRELS):
            P.hardpoints.append((f"muzzle_{side}{k + 1}", (sx * MTT_TRUNK[-1][0], y, z)))
    P.hardpoints += [("hp_dust", (0.0, 0.2, 0.0)), ("hp_exhaust", (0.0, 4.6, -15.3)),
                     ("hp_deploy", (0.0, 0.0, 22.0))]
    return P


def _mtt_head_front(P, last):
    """The head's front: a bevelled frame round the opening the rack nose and the cowl fill, and a dark throat
    behind it the rack retracts into."""
    zf = MTT_HEAD[-1][0]
    # opening: rack width, from below the head (the rack runs out under it) up to the cowl's top edge
    ox, oy0, oy1 = RACK_HALF + 0.3, 0.9, 12.1
    n = len(last)
    lip = [(max(-ox, min(ox, x)), max(oy0, min(oy1, y)), zf + 0.25) for x, y, z in last]
    P.loft("mtt", [last, lip], closed=True, caps=(False, False))
    # the head's front face round the opening (the part of the lip ring outside the opening rectangle is face)
    throat_front = [(ox, oy0, zf + 0.25), (ox, oy1, zf + 0.25), (-ox, oy1, zf + 0.25), (-ox, oy0, zf + 0.25)]
    throat_back = [(x, y, MTT_HEAD[1][0] + 0.4) for x, y, z in throat_front]      # inside the full-height head
    P.loft("dark", [throat_front, throat_back], closed=True, caps=(False, False), inside=True)
    P.flat("dark", list(reversed(throat_back)), (0, 0, 1))


def _mtt_trunks(P):
    """The two trunk pods: swept shells from the head sides to the bottom front corners, a domed tip with a dark
    grille face and two stacked cannons."""
    n = len(MTT_TRUNK)
    for sx in (1.0, -1.0):
        path = [(sx * x, y, z) for x, y, z in MTT_TRUNK]
        # a cowling, not a tube: full depth in the side view, thin across (x), rounding out into the tip pod
        sides = P.n(16, 8)
        prof = [(math.cos(2 * math.pi * k / sides), 0.62 * math.sin(2 * math.pi * k / sides)) for k in range(sides)]
        P.sweep("mtt", path, lambda t: MTT_TRUNK_R[min(n - 1, int(round(t * (n - 1))))], sides=sides,
                caps=False, profile=prof)
        # rounded root into the head side and the tip dome
        ellipsoid(P, "mtt", path[0], 1.25, 2.0, 2.4)
        # fairing that blends the trunk root into the head side and the cowl's front corner
        ellipsoid(P, "mtt", (sx * 2.85, 9.3, 8.4), 0.95, 2.4, 2.2)
        tip = path[-1]
        ellipsoid(P, "mtt", (tip[0], tip[1] + 0.05, tip[2] + 0.1), 1.38, 1.38, 0.95, -90.0, 90.0)
        # grille face (dark, slatted) on the front of the tip
        P.disc("dark", (tip[0], tip[1] + 0.05, tip[2] + 1.02), 0.0, 0.95, n=P.n(16, 8), r=(90, 0, 0))
        for k in range(5):
            y = tip[1] - 0.6 + k * 0.3
            P.box("dark", (tip[0], y, tip[2] + 1.06), (0.75, 0.04, 0.04))
        for y, zt in MTT_BARRELS:
            barrel(P, "dark", (tip[0], y, tip[2] + 0.6), (tip[0], y, zt), 0.15,
                   rings=((0.12, 0.24, 0.45), (0.55, 0.19, 0.25), (0.93, 0.2, 0.3)))
        # side plate where the trunk meets the head (a cheek)
        P.rbox("mtt", (sx * 3.45, 7.2, 8.6), (0.25, 1.6, 1.6), 0.2)


def _mtt_machinery(P):
    """Rack drive gear exposed under the head behind the pods: cylinders and rails along the rack sides."""
    for sx in (1.0, -1.0):
        x = sx * (RACK_HALF + 0.75)
        P.sweep("dark", [(x, 2.0, 2.4), (x, 2.0, 9.6)], 0.55, sides=P.n(14, 6))
        P.sweep("dark", [(x, 3.3, 3.0), (x, 3.3, 9.2)], 0.35, sides=P.n(12, 6))
        for z in (3.4, 6.0, 8.6):
            P.lathe("dark", (x, 2.0, z), [(0.0, -0.35), (0.7, -0.35), (0.7, 0.35), (0.0, 0.35)], n=P.n(14, 6),
                    r=(0, 0, 90))
        P.box("dark", (x, 4.4, 6.0), (0.18, 0.6, 3.6))


def _mtt_details(P):
    # long louvred vents high on the rear body flanks and the small square vents above them
    for sx in (1.0, -1.0):
        for (z0, z1, y) in ((-9.2, -1.4, 8.55), (-9.2, -1.4, 7.85)):
            c = (sx * 4.42, y, (z0 + z1) / 2)
            nrm = v_norm((sx * 1.0, 0.33, 0.0))
            panel(P, "vent", c, nrm, z1 - z0, 0.5, lift=0.04)
        for k in range(10):
            panel(P, "dark", (sx * 4.05, 9.45, -8.6 + k * 0.4), v_norm((sx * 0.7, 1.0, 0.0)), 0.16, 0.16, lift=0.03)
        # lower slots along the crease
        for k in range(3):
            panel(P, "vent", (sx * 5.2, 3.6, -11.0 + k * 3.4), v_norm((sx * 1.0, -0.25, 0.0)), 2.6, 0.45, lift=0.04)
        # head side: a column of square ports, a vertical vent strip at the back, red sensor slits
        for i in range(3):
            for j in range(2):
                panel(P, "dark", (sx * 3.5, 10.0 - j * 0.45, 4.6 + i * 0.45), (sx, 0.0, 0.0), 0.22, 0.22, lift=0.03)
        panel(P, "vent", (sx * 3.52, 9.3, 3.0), (sx, 0.0, 0.0), 0.45, 2.6, lift=0.03)
        panel(P, "glow_red", (sx * 2.85, 11.05, 8.4), v_norm((sx * 1.0, 0.75, 0.0)), 1.2, 0.09, lift=0.03)
        # hand rail along the body shoulder
        P.sweep("dark", [(sx * 4.45, 8.95, -12.0), (sx * 4.45, 8.95, -2.0)], 0.05, sides=P.n(6, 4))
    # rear: engine block, exhausts, tail lights
    P.rbox("dark", (0.0, 4.6, -15.05), (2.8, 1.5, 0.4), 0.2)
    for x in (-1.8, -0.6, 0.6, 1.8):
        P.lathe("dark", (x, 4.6, -15.4), [(0.0, 0.0), (0.42, 0.0), (0.42, 0.35), (0.3, 0.35), (0.3, 0.05)],
                n=P.n(12, 6), r=(-90, 0, 0))
        P.disc("glow_red", (x, 4.6, -15.46), 0.0, 0.29, n=P.n(12, 6), r=(-90, 0, 0))
    # top: deck hatch, sensor dome, antennas
    P.rbox("mtt", (0.0, 10.15, -5.5), (1.5, 0.2, 2.2), 0.15, bottom=False)
    for k in range(3):
        panel(P, "vent", (0.0, 10.02, -12.6 + k * 1.3), (0, 1, 0), 4.6, 0.9, up=(0, 0, 1), lift=0.03)
    ellipsoid(P, "dark", (0.0, 12.55, 5.2), 0.5, 0.3, 0.5, 0.0, 90.0)
    P.sweep("dark", [(-1.2, 12.5, 3.4), (-1.2, 14.6, 3.4)], 0.05, sides=P.n(6, 4))
    P.sweep("dark", [(1.0, 12.5, 3.0), (1.0, 13.6, 3.0)], 0.04, sides=P.n(6, 4))
    # underside repulsor units
    for z in (-11.5, -5.0, 1.0):
        for sx in (1.0, -1.0):
            P.rbox("dark", (sx * 2.9, 0.82, z), (1.4, 0.25, 2.2), 0.15)


def mtt_lid(lod=0):
    """The upper front cowl in hardpoint space (origin = hinge on the head's top front edge): a bowed plate over
    the opening above the rack, two hinge straps on its face (the two bars of the reference's front view)."""
    P = V(lod)
    hx, hy, hz = MTT_LID_HINGE
    w0, w1 = 1.55, 2.5                 # half-width at the top and at the bottom edge
    y0, y1 = 12.45, 7.75               # top and bottom (rack top) in hull space
    nu, nv = P.n(12, 4), P.n(10, 4)

    def pt(u, v, off=0.0):
        y = y0 + (y1 - y0) * v
        w = w0 + (w1 - w0) * math.sin(v * math.pi / 2)
        z = MTT_HEAD[-1][0] + 0.35 + 0.55 * math.sin(v * math.pi) * (1 - 0.5 * u * u) + off
        return (u * w - hx, y - hy, z - hz)
    outer = [[pt(-1 + 2 * i / nu, j / nv) for j in range(nv + 1)] for i in range(nu + 1)]
    inner = [[pt(-1 + 2 * i / nu, j / nv, -0.22) for j in range(nv + 1)] for i in range(nu + 1)]
    s = fu.UV["mtt"]
    U = [[p[0] / s for p in col] for col in outer]
    Vv = [[-p[1] / s for p in col] for col in outer]
    P.grid("mtt", outer, U, Vv, lambda q: (0.0, 0.15, 1.0))
    P.grid("dark", inner, U, Vv, lambda q: (0.0, -0.15, -1.0))
    for i in (0, nu):
        for j in range(nv):
            P.poly("mtt", [outer[i][j], outer[i][j + 1], inner[i][j + 1], inner[i][j]],
                   [(0, 0), (1, 0), (1, 0.1), (0, 0.1)], (1.0 if i else -1.0, 0.0, 0.0))
    for j in (0, nv):
        for i in range(nu):
            P.poly("mtt", [outer[i][j], outer[i + 1][j], inner[i + 1][j], inner[i][j]],
                   [(0, 0), (1, 0), (1, 0.1), (0, 0.1)], (0.0, 1.0 if j == 0 else -1.0, 0.0))
    for sx in (1.0, -1.0):
        top = pt(sx * 0.3, 0.02, 0.08)
        bot = pt(sx * 0.3, 0.42, 0.12)
        P.sweep("cream", [top, bot], 0.11, sides=P.n(6, 4))
        P.rbox("dark", (sx * 0.3, -0.05, -0.1), (0.16, 0.18, 0.35), 0.06)
    return P


def mtt_chin(lod=0):
    """The step plate under the rack nose (hardpoint space, origin = hinge at its foot): closed it stands upright,
    open it drops forward as a step for the droids; tread ribs on the inner face."""
    P = V(lod)
    w, h, t = 2.0, 0.85, 0.2
    P.box("mtt", (0.0, h / 2, -t / 2), (w, h / 2, t / 2))
    for k in range(3):
        P.box("dark", (0.0, 0.15 + k * 0.28, -t - 0.03), (w * 0.85, 0.04, 0.04))
    return P


def _folded_droid(P, c, facing, lod):
    """A B1 battle droid folded for transport: backpack, torso, tucked head, folded limbs (~1 m cube).
    facing: +1 droids on the +x side face +x, -1 the other side."""
    x, y, z = c
    f = facing
    if lod >= 2:
        P.box("droid", (x, y + 0.5, z), (0.42, 0.5, 0.4), bottom=False)
        return
    P.box("droid", (x - f * 0.18, y + 0.62, z), (0.12, 0.34, 0.3))                 # backpack
    P.box("droid", (x + f * 0.02, y + 0.52, z), (0.14, 0.26, 0.2))                 # torso
    # head folded down in front of the torso, snout pointing down
    P.box("droid", (x + f * 0.22, y + 0.48, z), (0.08, 0.3, 0.09), r=(0, 0, f * 12))
    P.box("droid", (x + f * 0.18, y + 0.86, z), (0.1, 0.1, 0.11))                  # neck knuckle
    for dz in (-0.17, 0.17):
        P.box("droid", (x + f * 0.12, y + 0.18, z + dz), (0.2, 0.06, 0.05))        # folded thighs
        P.box("droid", (x - f * 0.02, y + 0.06, z + dz), (0.24, 0.05, 0.05))       # shins
        P.box("droid", (x + f * 0.06, y + 0.55, z + dz * 1.55), (0.05, 0.2, 0.04))  # arms at the sides
    if lod == 0:
        P.box("dark", (x + f * 0.29, y + 0.3, z), (0.03, 0.03, 0.03))              # photoreceptor tip


def mtt_rack(lod=0, full=True):
    """The droid rack in hardpoint space (= hull space stowed): spine, roof, four shelves a side, and the nose:
    the shield plate with the round hub that fills the MTT's face under the cowl."""
    P = V(lod)
    y0, y1 = RACK_SHELVES[0] - 0.2, RACK_TOP
    zc, zl = (RACK_Z0 + RACK_Z1) / 2, (RACK_Z1 - RACK_Z0) / 2
    P.box("dark", (0.0, (y0 + y1) / 2, zc), (0.4, (y1 - y0) / 2, zl))                 # spine
    P.box("dark", (0.0, y1 + 0.08, zc), (RACK_HALF, 0.08, zl))                         # roof
    for sy in RACK_SHELVES:
        P.box("dark", (0.0, sy - 0.06, zc), (RACK_HALF, 0.06, zl), bottom=True)        # shelf decks
    for k in range(6):
        zz = RACK_Z0 + 0.15 + k * (RACK_Z1 - RACK_Z0 - 0.3) / 5
        for sx in (1.0, -1.0):
            P.box("dark", (sx * (RACK_HALF - 0.05), (y0 + y1) / 2, zz), (0.05, (y1 - y0) / 2, 0.07))
    # nose: shield plate (wide top, tapering to the foot), bevelled, with a domed hub and a step ladder below it
    zn = RACK_Z1
    half = [(1.2, 0.95), (2.45, 3.2), (2.5, 7.2), (2.1, 7.85)]
    outline = [(x, y) for x, y in half] + [(-x, y) for x, y in reversed(half)]
    front = [(x, y, zn + 0.3) for x, y in outline]
    back = [(x, y, zn - 0.05) for x, y in outline]
    bevel = [(x * 0.93, (y - 4.4) * 0.95 + 4.4, zn + 0.42) for x, y in outline]
    P.loft("cream", [back, front, bevel], closed=True, caps=(True, False))
    P.flat("cream", list(reversed(bevel)), (0, 0, 1))
    hub = (0.0, 5.55, zn + 0.42)
    P.lathe("cream", hub, [(0.0, 0.42), (1.2, 0.36), (1.75, 0.2), (1.95, 0.05), (1.95, 0.0)], n=P.n(28, 10),
            r=(90, 0, 0))
    P.lathe("dark", hub, [(1.95, 0.0), (2.05, 0.0), (2.05, 0.12), (1.98, 0.14)], n=P.n(28, 10), r=(90, 0, 0))
    P.box("cream", (0.0, 5.55, zn + 0.86), (0.09, 1.7, 0.06))                          # hub ridge
    P.lathe("dark", (0.0, 5.55, zn + 0.84), [(0.0, 0.12), (0.32, 0.1), (0.36, 0.0)], n=P.n(12, 6), r=(90, 0, 0))
    for k in range(6):                                                                  # step ladder
        P.box("dark", (0.0, 1.25 + k * 0.38, zn + 0.48), (0.42, 0.04, 0.06))
    for sx in (1.0, -1.0):
        P.box("dark", (sx * 0.46, 2.2, zn + 0.46), (0.04, 1.1, 0.05))
    if full:
        pitch = (RACK_Z1 - RACK_Z0 - 0.6) / RACK_PER_SHELF
        for sy in RACK_SHELVES:
            for sx in (1.0, -1.0):
                for k in range(RACK_PER_SHELF):
                    _folded_droid(P, (sx * (RACK_HALF - 0.85), sy, RACK_Z0 + 0.25 + pitch * (k + 0.5)), sx,
                                  0 if lod == 0 else 2)
    return P


def mtt_rack_empty(lod=0):
    return mtt_rack(lod, full=False)


def _merge(dst, src, fn):
    """Append src's polygons to dst, each point mapped by fn (part poses for previews)."""
    for slot, acc in src.acc.items():
        a = dst.A(slot)
        k = 0
        for cnt in acc.counts:
            ids = acc.connects[k:k + cnt]
            uvs = [acc.uvs[acc.uv_ids[k + j]] for j in range(cnt)]
            a.poly([fn(acc.points[i]) for i in ids], uvs)
            k += cnt


def _rot_x(p, deg, pivot):
    a = math.radians(deg)
    y, z = p[1] - pivot[1], p[2] - pivot[2]
    return (p[0], pivot[1] + y * math.cos(a) - z * math.sin(a), pivot[2] + y * math.sin(a) + z * math.cos(a))


def mtt_preview(lod=0, state="open"):
    """Hull plus parts posed (state 'closed' or 'open') in hull space, for geo_preview."""
    t = 1.0 if state == "open" else 0.0
    P = mtt_hull(lod)
    lid, chin = mtt_lid(lod), mtt_chin(lod)
    hx, hy, hz = MTT_LID_HINGE
    _merge(P, lid, lambda p: _rot_x((p[0] + hx, p[1] + hy, p[2] + hz), MTT_LID_ANGLE * t, MTT_LID_HINGE))
    cx, cy, cz = MTT_CHIN_HINGE
    _merge(P, chin, lambda p: _rot_x((p[0] + cx, p[1] + cy, p[2] + cz), MTT_CHIN_ANGLE * t, MTT_CHIN_HINGE))
    _merge(P, mtt_rack(lod), lambda p: (p[0], p[1], p[2] + MTT_RACK_TRAVEL * t))
    return P


# ============================================================================
# AAT
# ============================================================================
# After the reference render: a broad ochre bow plate (the hull's lower front, three launcher ports in its front
# face) under a bulbous body; side pods with twin lasers; bone-white T struts from the body down to the bow plate;
# an exposed engine cylinder at the rear flank; a round turret with the long main gun and two antennas.
# ~9.8 m long, 6.4 m wide, 3.9 m to the turret top; the hull hovers 0.55 m up.

AAT_HOVER = 0.55
AAT_TURRET = (0.0, 3.5, -0.55)        # turret ring centre (hp_turret)
AAT_SEAT_DRIVER = (0.0, 2.55, 0.6)
AAT_SEAT_GUNNER = (0.0, 3.25, -0.9)


def _bow_outline(n):
    """Plan of the bow plate (x, z), counter-clockwise from the right rear corner: a broad rounded front."""
    pts = []
    for i in range(n + 1):
        a = math.pi * i / n                                   # 0 = right side, pi = left side, through the front
        x = 3.2 * math.cos(a)
        z = 0.6 + 4.45 * (math.sin(a) ** 0.7)
        pts.append((x, z))
    pts += [(-3.05, -2.2), (-2.6, -3.0), (2.6, -3.0), (3.05, -2.2)]
    return pts


def aat_hull(lod=0):
    """Everything but the turret, Maya space with the ground at y = 0 (the hull hovering AAT_HOVER over it)."""
    P = V(lod)
    h = AAT_HOVER
    # --- bow plate: a domed shell over the plan outline, a vertical front band, a flat underside
    n = P.n(28, 10)
    out = _bow_outline(n)
    m = len(out)
    cz = 0.4

    def dome(x, z, k):
        """Top of the bow plate at plan point (x, z) scaled toward the centre by k (1 = rim)."""
        px, pz = x * k, cz + (z - cz) * k
        r = math.hypot(x / 3.2, (z - cz) / 4.2)
        rise = 0.55 * (1 - (k * r) ** 2)
        return (px, h + 0.95 + rise, pz)
    rings = [[dome(x, z, k) for x, z in out] for k in (1.0, 0.86, 0.66, 0.42, 0.15)]
    band = [[(x * k, h + y, cz + (z - cz) * k) for x, z in out] for k, y in
            ((0.93, 0.08), (0.985, 0.25), (1.02, 0.5), (1.01, 0.72), (0.99, 0.86))]
    rim_low, rim_lip = band[0], band[-1]
    # rounded nose band (perimeter-mapped) and the domed top (planar-mapped: the soot streaks run front to back)
    P.loft("aat", band, closed=True, caps=(False, False))
    top = [rim_lip] + rings
    s_ = fu.UV["aat"]
    cols = [[top[r][i] for r in range(len(top))] for i in range(m)]
    P.grid("aat", cols, [[q[0] / s_ for q in col] for col in cols], [[q[2] / s_ for q in col] for col in cols],
           lambda q: (0.0, 1.0, 0.0), closed_u=True)
    P.flat("aat", rings[-1], (0, 1, 0))
    P.flat("dark", rim_low, (0, -1, 0))
    # three launcher ports in the front band (dark tubes set into the bow)
    for k, a in enumerate((70.0, 90.0, 110.0)):
        ar = math.radians(a)
        x = 3.2 * math.cos(ar) * 0.985
        z = 0.6 + 4.45 * (math.sin(ar) ** 0.7) * 0.995
        c = (x, h + 0.45, z)
        d = v_norm((math.cos(ar) * 0.6, 0.0, math.sin(ar)))
        yaw = math.degrees(math.atan2(d[0], d[2]))
        P.sweep("dark", [v_sub(c, v_mul(d, 0.9)), v_add(c, v_mul(d, 0.06))], 0.27, sides=P.n(14, 8))
        P.sweep("aat", [v_add(c, v_mul(d, -0.05)), v_add(c, v_mul(d, 0.1))], 0.36, sides=P.n(14, 8), caps=False)
        P.hardpoints.append((f"muzzle_launcher_{k + 1}", v_add(c, v_mul(d, 0.1))))
    # --- body: a bulbous hull on the bow plate, sloping down at the front
    st = [(-3.4, 1.0, 2.15, 1.5, 1.2, 3.0), (-2.6, 0.95, 2.75, 1.85, 1.45, 3.0), (-0.8, 0.9, 3.05, 2.0, 1.6, 3.2),
          (0.9, 0.95, 2.95, 1.95, 1.5, 3.0), (2.0, 1.1, 2.55, 1.7, 1.25, 2.6), (2.7, 1.3, 2.1, 1.35, 0.9, 2.3),
          (3.05, 1.45, 1.75, 0.85, 0.55, 2.2)]
    nb = P.n(32, 12)
    rings_b = [[(x, y + h, z) for x, y, z in station_ring(s, nb)] for s in st]
    P.loft("aat", rings_b, caps=(True, True))
    # hatch and the raised spine plate on top of the body
    P.rbox("aat", (0.0, h + 3.05, 1.1), (0.7, 0.08, 0.55), 0.06, bottom=False)
    # --- side pods: housings with twin lasers, and the engine cylinder exposed at the rear flank
    for sx in (1.0, -1.0):
        pod = (sx * 2.25, h + 2.05, 0.9)
        P.sweep("aat", [(pod[0], pod[1], -0.3), (pod[0], pod[1], 2.1)], 0.48, sides=P.n(16, 8))
        ellipsoid(P, "aat", (pod[0], pod[1], -0.3), 0.48, 0.48, 0.35)
        P.rbox("cream", (pod[0] + sx * 0.05, pod[1] - 0.05, 2.35), (0.42, 0.32, 0.3), 0.06)       # gun block
        for k, (dx, dy, ln) in enumerate(((0.12, 0.12, 1.25), (-0.14, -0.14, 0.95))):
            b0 = (pod[0] + sx * dx, pod[1] + dy, 2.6)
            barrel(P, "dark", b0, (b0[0], b0[1], 2.6 + ln), 0.055, rings=((0.85, 0.08, 0.12),))
            P.hardpoints.append((f"muzzle_laser_{'l' if sx > 0 else 'r'}{k + 1}", (b0[0], b0[1], 2.6 + ln)))
        P.box("aat", (sx * 1.95, h + 2.05, 0.9), (0.3, 0.22, 0.9))                                  # pod pylon
        # T strut: post from the body side down to a T foot on the bow plate
        top, foot = (sx * 2.2, h + 1.75, 1.15), (sx * 2.7, h + 1.2, 1.75)
        P.sweep("cream", [top, foot], 0.2, sides=4, profile=[(1.0, 0.5), (-1.0, 0.5), (-1.0, -0.5), (1.0, -0.5)])
        P.box("cream", (foot[0], foot[1] - 0.02, foot[2]), (0.24, 0.09, 0.85))
        P.box("cream", (top[0], top[1] + 0.08, top[2] - 0.1), (0.2, 0.16, 0.32))
        # rear engine cylinder (the dark machinery at the back flank)
        P.sweep("dark", [(sx * 1.55, h + 1.5, -3.25), (sx * 1.55, h + 1.5, -1.55)], 0.5, sides=P.n(14, 6))
        for z in (-3.1, -2.6, -2.1, -1.7):
            P.sweep("dark", [(sx * 1.55, h + 1.5, z - 0.06), (sx * 1.55, h + 1.5, z + 0.06)], 0.56, sides=P.n(14, 6))
        # small side lights and grab handles
        for k in range(3):
            P.box("dark", (sx * 1.98, h + 2.35, -1.6 + k * 0.35), (0.03, 0.22, 0.05))
        panel(P, "glow_red", (sx * 1.62, h + 2.6, 2.0), v_norm((sx * 1.0, 0.4, 0.6)), 0.3, 0.07, lift=0.02)
    # rear: exhaust grille and repulsor skirts under the hull
    P.rbox("dark", (0.0, h + 1.7, -3.45), (1.0, 0.45, 0.12), 0.05)
    panel(P, "vent", (0.0, h + 1.7, -3.58), (0, 0, -1), 1.8, 0.75, lift=0.01)
    for z in (-2.0, 0.6, 2.8):
        P.rbox("dark", (0.0, h + 0.1, z), (1.8, 0.12, 0.8), 0.06)
    P.hardpoints += [("hp_turret", AAT_TURRET), ("seat_driver", AAT_SEAT_DRIVER), ("seat_gunner", AAT_SEAT_GUNNER),
                     ("hp_dust", (0.0, 0.05, 0.0))]
    return P


def aat_turret(lod=0):
    """Turret and main gun in hardpoint space (origin = the turret ring on the body top); rotates about Y."""
    P = V(lod)
    # turret body: a flattened rounded pod, longer than wide, set slightly back
    ellipsoid(P, "aat", (0.0, 0.42, -0.2), 1.05, 0.48, 1.35)
    P.lathe("dark", (0.0, 0.0, 0.0), [(0.0, 0.0), (0.95, 0.0), (0.95, 0.16), (0.0, 0.16)], n=P.n(20, 8))      # ring
    ellipsoid(P, "aat", (0.0, 0.88, -0.45), 0.42, 0.24, 0.42, 0.0, 90.0)                                   # cupola
    for sx in (1.0, -1.0):                                                                                  # side ears
        ellipsoid(P, "aat", (sx * 0.98, 0.45, -0.35), 0.28, 0.3, 0.55)
    # main gun: mantlet, barrel, muzzle brake
    P.rbox("aat", (0.0, 0.42, 1.05), (0.34, 0.26, 0.35), 0.08)
    barrel(P, "dark", (0.0, 0.42, 1.3), (0.0, 0.42, 4.9), 0.1,
           rings=((0.05, 0.16, 0.3), (0.5, 0.125, 0.2), (0.97, 0.16, 0.28)))
    P.hardpoints.append(("muzzle_main", (0.0, 0.42, 5.0)))
    # antennas at the back
    for sx, ht in ((0.35, 1.6), (0.55, 1.2)):
        P.sweep("dark", [(sx, 0.8, -1.1), (sx, 0.8 + ht, -1.15)], 0.022, sides=4, caps=False)
    return P


def aat_preview(lod=0, state="", yaw=25.0):
    """Hull plus the turret turned `yaw` degrees (Maya space), for geo_preview."""
    P = aat_hull(lod)
    a = math.radians(yaw)
    tx, ty, tz = AAT_TURRET

    def turn(p):
        x, y, z = p
        return (tx + x * math.cos(a) + z * math.sin(a), ty + y, tz - x * math.sin(a) + z * math.cos(a))
    _merge(P, aat_turret(lod), turn)
    return P


# ============================================================================
# Gungan Grand Army
# ============================================================================

DOME_R = 90.0           # the shield dome over the army (examples/naboo_battle_layout.py: centre (-60, 0), radius 90)
DOME_RIM_H = 7.0


def _two_sided_shell(P, slot, rings, uv, ctr):
    """Grid of rings (each a closed loop) drawn from both sides: alpha shells seen from inside and outside."""
    cols = [[rings[r][i] for r in range(len(rings))] for i in range(len(rings[0]))]
    U = [[uv(r, i)[0] for r in range(len(rings))] for i in range(len(rings[0]))]
    V = [[uv(r, i)[1] for r in range(len(rings))] for i in range(len(rings[0]))]
    P.grid(slot, cols, U, V, lambda q: v_sub(q, ctr), closed_u=True)
    P.grid(slot, cols, U, V, lambda q: v_sub(ctr, q), closed_u=True)


def shield_dome(lod=0):
    """The Gungan shield: a slightly flattened dome, its membrane two-sided (the army stands inside it), and a
    bright crackling band where it meets the ground. Origin = the dome centre on the ground."""
    P = V(lod)
    n = P.n(72, 24)
    rows = P.n(18, 6)
    ctr = (0.0, 0.0, 0.0)
    s = fu.UV["dome"]
    rings = []
    for r in range(rows + 1):
        lat = math.radians(90.0 * r / rows) * 0.999
        rr, yy = DOME_R * math.cos(lat), DOME_R * 0.82 * math.sin(lat)
        rings.append([(rr * math.cos(2 * math.pi * i / n), yy, rr * math.sin(2 * math.pi * i / n)) for i in range(n)])
    _two_sided_shell(P, "dome", rings, lambda r, i: (i / n * 2 * math.pi * DOME_R / s, r / rows * DOME_R * 1.3 / s), ctr)
    band = [[(DOME_R * 1.002 * math.cos(2 * math.pi * i / n), y, DOME_R * 1.002 * math.sin(2 * math.pi * i / n))
             for i in range(n)] for y in (-0.3, DOME_RIM_H)]
    reps = max(8, int(2 * math.pi * DOME_R / fu.UV["rim"]))
    _two_sided_shell(P, "rim", band, lambda r, i: (i / n * reps, 0.0 if r == 0 else 1.0), ctr)
    return P


def shield_generator(lod=0):
    """The generator a fambaa carries: saddle, banded drum, ribbed mast, the emitter bulb in a three-prong
    crown. Origin = where it sits on the fambaa's back (y up), front +z. ~4.2 m tall."""
    P = V(lod)
    # saddle pad and girth straps
    P.rbox("hide", (0.0, 0.18, 0.0), (1.25, 0.18, 1.7), 0.12)
    for z in (-1.0, 1.0):
        P.sweep("hide", [(-1.5, -1.2, z), (-1.35, 0.15, z), (1.35, 0.15, z), (1.5, -1.2, z)], 0.07, sides=P.n(6, 4))
    # drum
    P.lathe("brass", (0.0, 0.35, 0.0), [(0.0, 0.0), (0.95, 0.0), (1.05, 0.15), (1.05, 0.85), (0.95, 1.0),
                                        (0.55, 1.15), (0.0, 1.15)], n=P.n(20, 8))
    for y in (0.55, 1.0):
        P.lathe("hide", (0.0, 0.35 + y - 0.05, 0.0), [(1.07, 0.0), (1.07, 0.1)], n=P.n(20, 8))
    # glowing vents round the drum
    for k in range(6):
        a = 2 * math.pi * k / 6
        c = (1.06 * math.cos(a), 0.85, 1.06 * math.sin(a))
        panel(P, "glow", c, (math.cos(a), 0.0, math.sin(a)), 0.28, 0.32, lift=0.01)
    # mast with ribs
    P.sweep("brass", [(0.0, 1.45, 0.0), (0.0, 3.4, 0.0)], lambda t: 0.28 - 0.08 * t, sides=P.n(12, 6))
    for y in (1.8, 2.3, 2.8):
        P.lathe("brass", (0.0, y, 0.0), [(0.0, 0.0), (0.42, 0.0), (0.42, 0.08), (0.0, 0.08)], n=P.n(12, 6))
    # crown: three prongs curving up round the bulb
    for k in range(3):
        a = 2 * math.pi * k / 3
        ca, sa = math.cos(a), math.sin(a)
        P.sweep("brass", [(0.2 * ca, 3.3, 0.2 * sa), (0.75 * ca, 3.6, 0.75 * sa), (0.8 * ca, 4.05, 0.8 * sa),
                          (0.55 * ca, 4.35, 0.55 * sa)], lambda t: 0.09 - 0.05 * t, sides=P.n(8, 4))
    ellipsoid(P, "glow", (0.0, 3.85, 0.0), 0.5, 0.55, 0.5)
    P.hardpoints += [("hp_emitter", (0.0, 3.85, 0.0))]
    return P


def hand_shield(lod=0):
    """A Gungan warrior's energy shield: a bowed oval membrane in a bronze hoop with a grip and a centre boss.
    Origin = the grip, the face toward +z, ~0.8 x 1.15 m (hand_shield_wrist hangs it on lWrist)."""
    P = V(lod)
    n = P.n(28, 10)
    a_, b_ = 0.4, 0.58
    rim = [(a_ * math.cos(2 * math.pi * i / n), b_ * math.sin(2 * math.pi * i / n), 0.0) for i in range(n)]
    bow = lambda x, y: 0.09 * (1 - (x / a_) ** 2 - (y / b_) ** 2)
    rings = []
    for k in (1.0, 0.66, 0.33, 0.02):
        rings.append([(x * k, y * k, 0.2 + bow(x * k, y * k)) for x, y, _ in rim])
    ctr = (0.0, 0.0, 0.0)
    cols = [[rings[r][i] for r in range(len(rings))] for i in range(n)]
    U = [[0.5 + c[0] / (2 * a_) for c in col] for col in cols]
    Vv = [[0.5 + c[1] / (2 * b_) for c in col] for col in cols]
    P.grid("hshield", cols, U, Vv, lambda q: (0.0, 0.0, 1.0), closed_u=True)
    P.grid("hshield", cols, U, Vv, lambda q: (0.0, 0.0, -1.0), closed_u=True)
    P.sweep("brass", [(x, y, 0.2) for x, y, _ in rim], 0.03, sides=P.n(6, 4), closed=True, caps=False)
    ellipsoid(P, "brass", (0.0, 0.0, 0.2 + 0.1), 0.08, 0.08, 0.045)
    P.sweep("brass", [(0.0, -0.11, 0.2), (0.0, -0.11, 0.06), (0.0, 0.11, 0.06), (0.0, 0.11, 0.2)], 0.022,
            sides=P.n(6, 4))
    return P


# hand_shield in the Gungan's lWrist joint frame (row vectors: p_wrist = p_shield * A), measured in Maya on
# gungan_m.sat in the stock standing idle: grip in the hand, face forward and a little out to the left, long
# axis up the forearm. The hp_dyn app row hangs it on hardpoint lWrist with no offset.
HAND_SHIELD_TO_WRIST = (0.281417, 0.453501, -0.84566, 0.0, -0.427087, 0.848371, 0.31283, 0.0,
                        0.859303, 0.273135, 0.43243, 0.0, 0.008696, 0.042129, 0.025486, 1.0)


def _row_affine(A):
    def f(p):
        x, y, z = p
        return (x * A[0] + y * A[4] + z * A[8] + A[12], x * A[1] + y * A[5] + z * A[9] + A[13],
                x * A[2] + y * A[6] + z * A[10] + A[14])
    return f


def hand_shield_wrist(lod=0):
    """hand_shield as it hangs on hardpoint lWrist (the exported titan_hrc_nboo_hand_shield)."""
    P = V(lod)
    P.xform = _row_affine(HAND_SHIELD_TO_WRIST)
    src = hand_shield(lod)
    _merge(P, src, P.xform)
    P.xform = None
    return P


# shield_generator in the fambaa's root joint frame, standing upright on its back (stock fambaa.sat at scale 1:
# the back tops out at y 10.1 m over the root at y 9.3 m; the root joint is turned, so the pose is baked in here)
GENERATOR_TO_FAMBAA_ROOT = (0.0, 0.0, 1.0, 0.0, -0.14237, -0.989813, 0.0, 0.0, 0.989813, -0.14237, 0.0, 0.0,
                            -0.393658, -0.629679, 0.0, 1.0)


def shield_generator_fambaa(lod=0):
    """shield_generator as it hangs on the fambaa's root joint (the exported titan_hrc_nboo_shield_generator)."""
    P = V(lod)
    src = shield_generator(lod)
    sc, drop = 1.5, 0.25                                    # sized for the 21 m stock fambaa, saddle on the hide
    place = lambda p: _row_affine(GENERATOR_TO_FAMBAA_ROOT)((p[0] * sc, p[1] * sc - drop, p[2] * sc))
    _merge(P, src, place)
    P.hardpoints = [(n, place(p)) for n, p in src.hardpoints]
    return P


def booma(lod=0):
    """A booma (energy ball, ~0.6 m): a glowing core inside two crossed halo cards and a soft shell."""
    P = V(lod)
    ellipsoid(P, "glow", (0.0, 0.0, 0.0), 0.2, 0.2, 0.2)
    ctr = (0.0, 0.0, 0.0)
    for ax in ((0, 1, 0), (1, 0, 0), (0, 0, 1)):
        P.decal("booma", ctr, 0.75, 0.75, ax, up=(0, 0, 1) if ax[1] else (0, 1, 0))
        P.decal("booma", ctr, 0.75, 0.75, v_mul(ax, -1.0), up=(0, 0, 1) if ax[1] else (0, 1, 0))
    return P


def shield_hit(lod=0):
    """A shell striking the shield: a membrane flash that needs no orientation (hp_dyn apps take an offset only) -
    a two-sided rippling sphere round three crossed glow cards. Origin = the impact point, ~9 m across."""
    P = V(lod)
    n, rows, r = P.n(20, 10), P.n(10, 6), 4.5
    rings = []
    for k in range(rows + 1):
        lat = math.radians(-90.0 + 180.0 * k / rows) * 0.999
        rings.append([(r * math.cos(lat) * math.cos(2 * math.pi * i / n), r * math.sin(lat),
                       r * math.cos(lat) * math.sin(2 * math.pi * i / n)) for i in range(n)])
    s_ = 6.0
    _two_sided_shell(P, "dome", rings, lambda k, i: (i / n * 2 * math.pi * r / s_, k / rows * math.pi * r / s_),
                     (0.0, 0.0, 0.0))
    for ax in ((0, 1, 0), (1, 0, 0), (0, 0, 1)):
        up = (0, 0, 1) if ax[1] else (0, 1, 0)
        P.decal("booma", (0.0, 0.0, 0.0), 9.0, 9.0, ax, up=up)
        P.decal("booma", (0.0, 0.0, 0.0), 9.0, 9.0, v_mul(ax, -1.0), up=up)
    return P


def plasma_shell(lod=0):
    """The AAT's energy shell in flight: a white-hot core and an orange sheath streaming back along -z
    (crossed cards with the bolt texture, U along the bolt). Origin = the shell's head, flying toward +z."""
    P = V(lod)
    L, w = 2.6, 0.55
    for rot in (0.0, 60.0, 120.0):
        a = math.radians(rot)
        side = (math.cos(a) * w / 2, math.sin(a) * w / 2, 0.0)
        q = [v_mul(side, -1.0), side, v_add(side, (0, 0, -L)), v_add(v_mul(side, -1.0), (0, 0, -L))]
        uv = [(1.0, 0.0), (1.0, 1.0), (0.0, 1.0), (0.0, 0.0)]
        nrm = (-math.sin(a), math.cos(a), 0.0)
        P.poly("plasma", q, uv, nrm)
        P.poly("plasma", q, uv, v_mul(nrm, -1.0))
    ellipsoid(P, "glow_red", (0.0, 0.0, -0.1), 0.14, 0.14, 0.22)
    return P


def catapult(lod=0):
    """A Gungan catapult (~5 m): a sledge frame on two runners, a sprung throwing arm with a cup holding a booma,
    bronze fittings, a basket of spare boomas. Origin on the ground, the throw toward +z."""
    P = V(lod)
    for sx in (1.0, -1.0):
        P.sweep("hide", [(sx * 1.1, 0.15, -2.4), (sx * 1.1, 0.12, 1.6), (sx * 1.1, 0.4, 2.3)], 0.14, sides=P.n(8, 4))
        P.sweep("hide", [(sx * 1.1, 0.2, -1.6), (sx * 0.45, 2.3, -0.1)], 0.11, sides=P.n(8, 4))       # A-frame
        P.sweep("hide", [(sx * 1.1, 0.2, 1.2), (sx * 0.45, 2.3, -0.1)], 0.11, sides=P.n(8, 4))
        P.lathe("brass", (sx * 0.45, 2.3, -0.1), [(0.0, -0.12), (0.18, -0.12), (0.18, 0.12), (0.0, 0.12)],
                n=P.n(10, 6), r=(0, 0, 90))
    for z in (-2.0, 0.0, 1.4):
        P.sweep("hide", [(-1.1, 0.25, z), (1.1, 0.25, z)], 0.1, sides=P.n(8, 4))
    P.sweep("brass", [(-0.5, 2.3, -0.1), (0.5, 2.3, -0.1)], 0.06, sides=P.n(8, 4))                       # axle
    # throwing arm cocked back, cup at its end
    arm = [(0.0, 2.3, -0.1), (0.0, 1.3, -1.6), (0.0, 0.85, -2.6)]
    P.sweep("hide", [(0.0, 2.6, 0.4)] + arm, 0.12, sides=P.n(8, 4))
    cup = (0.0, 0.95, -2.75)
    P.lathe("brass", cup, [(0.0, -0.12), (0.32, -0.08), (0.38, 0.12)], n=P.n(12, 6))
    ellipsoid(P, "glow", (cup[0], cup[1] + 0.22, cup[2]), 0.22, 0.22, 0.22)
    # counter-spring coils and the basket
    P.sweep("brass", [(0.0, 0.3, 0.6), (0.0, 1.9, 0.3)], 0.16, sides=P.n(10, 6))
    P.lathe("hide", (1.7, 0.0, -1.0), [(0.0, 0.05), (0.45, 0.05), (0.55, 0.55), (0.5, 0.6)], n=P.n(12, 6))
    for k, (dx, dz) in enumerate(((0.0, 0.0), (0.18, 0.15), (-0.17, 0.12), (0.05, -0.2))):
        ellipsoid(P, "glow", (1.7 + dx, 0.6, -1.0 + dz), 0.17, 0.17, 0.17)
    P.hardpoints += [("hp_launch", (cup[0], cup[1] + 0.3, cup[2]))]
    return P


def info_disk_historical(lod=0):
    """The Historical quest marker: a gold medal disc with the Aurebesh Herf, the stock info_disk's size and pose
    (0.2 m across standing on its lower edge, faces along z). Spun by the client's interesting-object dynamics."""
    P = V(lod)
    r, t = 0.11, 0.018
    n = P.n(32, 16)
    c = (0.0, r, 0.0)
    for side in (1.0, -1.0):
        ring = [(r * math.cos(2 * math.pi * i / n), r + r * math.sin(2 * math.pi * i / n), side * t) for i in range(n)]
        uv = [(0.5 + 0.5 * math.cos(2 * math.pi * i / n) * side, 0.5 + 0.5 * math.sin(2 * math.pi * i / n))
              for i in range(n)]
        for i in range(n):
            j = (i + 1) % n
            P.poly("disk", [(0.0, r, side * t), ring[i], ring[j]], [(0.5, 0.5), uv[i], uv[j]], (0.0, 0.0, side))
    for i in range(n):
        a0, a1 = 2 * math.pi * i / n, 2 * math.pi * (i + 1) / n
        q = [(r * math.cos(a0), r + r * math.sin(a0), t), (r * math.cos(a1), r + r * math.sin(a1), t),
             (r * math.cos(a1), r + r * math.sin(a1), -t), (r * math.cos(a0), r + r * math.sin(a0), -t)]
        P.poly("disk", q, [(0.5, 0.97)] * 4, (math.cos((a0 + a1) / 2), math.sin((a0 + a1) / 2), 0.0))
    return P


def rally_marker(lod=0):
    """Where Jar Jar's narration sends the group: three crossed vertical light planes (a 24 m gold shaft, 4 m wide,
    that reads from any side and far away) over a dashed gold ring on the ground (r 2.4..3.1), and the Historical
    "H" emblem (the quest disc's texture, 1.6 m) as two crossed discs at 3.4 m. No collision."""
    P = V(lod)
    H, W = 24.0, 4.0
    for k in range(3):
        a = math.radians(60.0 * k)
        d = (math.cos(a) * W / 2, 0.0, math.sin(a) * W / 2)
        q = [(-d[0], 0.0, -d[2]), (d[0], 0.0, d[2]), (d[0], H, d[2]), (-d[0], H, d[2])]
        uv = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
        nrm = (-math.sin(a), 0.0, math.cos(a))
        P.poly("rbeam", q, uv, nrm)
        P.poly("rbeam", q[::-1], uv[::-1], (-nrm[0], 0.0, -nrm[2]))
    n, r0, r1, y, dashes = P.n(48, 24), 2.4, 3.1, 0.08, 12
    for i in range(n):
        a0, a1 = 2 * math.pi * i / n, 2 * math.pi * (i + 1) / n
        u0, u1 = dashes * i / n, dashes * (i + 1) / n
        q = [(r0 * math.cos(a0), y, r0 * math.sin(a0)), (r1 * math.cos(a0), y, r1 * math.sin(a0)),
             (r1 * math.cos(a1), y, r1 * math.sin(a1)), (r0 * math.cos(a1), y, r0 * math.sin(a1))]
        P.poly("rring", q, [(u0, 0.0), (u0, 1.0), (u1, 1.0), (u1, 0.0)], (0.0, 1.0, 0.0))
    # the emblem: crossed double-sided discs (playtest: the stock 0.2 m disc on top of 24 m was invisible)
    er, ey, en = 0.8, 3.4, P.n(32, 16)
    for k in range(2):
        a = math.radians(90.0 * k)
        ax, az = math.cos(a), math.sin(a)                  # the disc's in-plane horizontal axis
        nrm = (-az, 0.0, ax)
        for side in (1.0, -1.0):
            for i in range(en):
                t0, t1 = 2 * math.pi * i / en, 2 * math.pi * (i + 1) / en
                p0 = (ax * er * math.cos(t0), ey + er * math.sin(t0), az * er * math.cos(t0))
                p1 = (ax * er * math.cos(t1), ey + er * math.sin(t1), az * er * math.cos(t1))
                uv0 = (0.5 + 0.5 * math.cos(t0) * side, 0.5 + 0.5 * math.sin(t0))
                uv1 = (0.5 + 0.5 * math.cos(t1) * side, 0.5 + 0.5 * math.sin(t1))
                tri = [(0.0, ey, 0.0), p0, p1] if side > 0 else [(0.0, ey, 0.0), p1, p0]
                uvs = [(0.5, 0.5), uv0, uv1] if side > 0 else [(0.5, 0.5), uv1, uv0]
                P.poly("disk", tri, uvs, (nrm[0] * side, 0.0, nrm[2] * side))
    return P


def gungan_preview(lod=0, state=""):
    """Every Gungan piece side by side (the dome scaled down 1:40 at the back) for geo_preview."""
    P = V(lod)
    items = [(shield_generator, (0, 0, 0), 1.0), (hand_shield, (3.2, 1.0, 0), 1.0), (booma, (4.6, 0.5, 0), 1.0),
             (catapult, (-5.5, 0, 0), 1.0), (plasma_shell, (6.2, 0.8, 0), 1.0), (info_disk_historical, (7.4, 0.4, 0), 4.0),
             (shield_dome, (0, 0, -8), 1 / 40.0)]
    for fn, off, sc in items:
        _merge(P, fn(lod), lambda p, off=off, sc=sc: (p[0] * sc + off[0], p[1] * sc + off[1], p[2] * sc + off[2]))
    return P


# ============================================================================
# export (inside Maya)
# ============================================================================

PREFIX = "titan_hrc_nboo_"
# static pieces: name -> builder(lod)
PIECES = {
    "mtt": mtt_hull, "mtt_lid": mtt_lid, "mtt_chin": mtt_chin, "mtt_rack": mtt_rack,
    "mtt_rack_empty": mtt_rack_empty, "aat_turret": aat_turret,
    "shield_dome": shield_dome, "shield_generator": shield_generator_fambaa, "hand_shield": hand_shield_wrist, "booma": booma,
    "plasma_shell": plasma_shell, "shield_hit": shield_hit, "catapult": catapult, "info_disk_historical": info_disk_historical,
    "rally_marker": rally_marker,
}
LODS = 3
PIECE_LODS = {"info_disk_historical": 1, "booma": 2, "plasma_shell": 1, "shield_hit": 1, "rally_marker": 1}
# exported name when it is not PREFIX + piece
PIECE_NAMES = {"info_disk_historical": "titan_info_disk_historical"}
# polySoftEdge angle per slot: faceted hull plates stay creased, panels/vents flat, rounded shells smooth
SOFT_ANGLE = {"mtt_hard": 28.0, "dark": 40.0, "vent": 5.0, "glow_red": 5.0, "cream": 40.0}
SLOT_COLOR = {"mtt": (0.67, 0.59, 0.41), "mtt_hard": (0.67, 0.59, 0.41), "aat": (0.77, 0.55, 0.23),
              "cream": (0.84, 0.78, 0.63), "dark": (0.23, 0.24, 0.26), "vent": (0.27, 0.26, 0.24),
              "glow_red": (1.0, 0.2, 0.1), "droid": (0.84, 0.78, 0.63)}


def _sg(slot, export_root):
    import os
    import maya.cmds as cmds
    from . import pob_builder as pb
    tex = SLOT_TEX[slot]
    if cmds.objExists(f"nbh_{tex}SG"):                    # slots sharing a texture share the shading group
        return f"nbh_{tex}SG"
    sht = f"{export_root}/shader/{tex}.sht"
    if not os.path.exists(sht):
        raise RuntimeError(f"{sht} missing: run examples/naboo_battle_materials.py first")
    return pb._material(f"nbh_{tex}", SLOT_COLOR.get(slot, (0.7, 0.7, 0.7)), f"{export_root}/texture/{tex}.dds", sht)


def _place(P, root, tag, export_root):
    import maya.cmds as cmds
    made = []
    for slot, acc in P.acc.items():
        if not acc.counts:
            continue
        m = acc.build(f"{tag}_{slot}", "|" + root)
        if m is None:
            continue
        cmds.polySoftEdge(m, angle=SOFT_ANGLE.get(slot, 70.0), ch=False)
        cmds.sets(m, edit=True, forceElement=_sg(slot, export_root))
        made.append(m)
    return made


def build(name, export_root):
    """One static piece, LODS detail levels, exported as appearance/<PREFIX><name>.apt (+ _l1, _l2)."""
    import os
    import maya.cmds as cmds
    import maya.mel as mel
    cmds.file(new=True, force=True)
    if not cmds.pluginInfo("SwgMayaEditor", query=True, loaded=True):
        cmds.loadPlugin("SwgMayaEditor")
    full = PIECE_NAMES.get(name, PREFIX + name)
    root = cmds.createNode("transform", name=full)
    out = {"name": name, "apt": f"appearance/{full}.apt", "lods": [], "faces": []}
    for lod in range(PIECE_LODS.get(name, LODS)):
        P = PIECES[name](lod)
        for m in cmds.listRelatives("|" + root, children=True, type="transform", fullPath=True) or []:
            cmds.delete(m)
        _place(P, root, f"{full}_l{lod}", export_root)
        if lod == 0:
            for hp in P.hardpoints:
                t = cmds.createNode("transform", name=hp[0], parent="|" + root)
                cmds.setAttr(t + ".translate", *hp[1], type="double3")
            out["hardpoints"] = [[hp[0], list(hp[1])] for hp in P.hardpoints]
            out["bounds"] = [round(v, 3) for v in cmds.exactWorldBoundingBox("|" + root)]
            rel = out["apt"]
        else:
            rel = f"appearance/{full}_l{lod}.apt"
            out["lods"].append(rel)
        meshes = cmds.listRelatives("|" + root, allDescendents=True, type="mesh", fullPath=True) or []
        out["faces"].append(sum(int(cmds.polyEvaluate(m, face=True)) for m in meshes))
        os.makedirs(os.path.dirname(f"{export_root}/{rel}"), exist_ok=True)
        cmds.select("|" + root, replace=True)
        mel.eval(f'exportStaticMesh -path "{export_root}/{rel}" -collision none')
    return out
