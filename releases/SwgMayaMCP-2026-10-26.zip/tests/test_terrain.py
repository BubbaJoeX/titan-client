"""Terrain (.trn / .lay) tests, no Maya or client needed:

    .venv\\Scripts\\python.exe -m unittest tests.test_terrain -v

Stock round-trips need the extracted data (TITAN_DATA_ROOTS, default D:/titan/data/sku.0/...); they are skipped
without it. The last test drives the trn_ tools through a real MCP stdio client."""

import asyncio
import json
import math
import os
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

from swg_maya_mcp.terrain import author, env, generator, planet, trn  # noqa: E402
from swg_maya_mcp.terrain.fractal import MultiFractal, RandomGenerator  # noqa: E402
from swg_maya_mcp.terrain.tools import DATA_ROOTS  # noqa: E402

STOCK = Path(DATA_ROOTS[0]) / "terrain"


class StockRoundTrip(unittest.TestCase):
    @unittest.skipUnless(STOCK.is_dir(), "stock terrain not extracted")
    def test_every_stock_file_is_byte_identical(self):
        files = sorted(p for p in STOCK.iterdir() if p.suffix.lower() in (".trn", ".lay"))
        checked = 0
        for f in files:
            data = f.read_bytes()
            if not data.startswith(b"FORM"):          # test_layout_tatooine.lay is a SWGODLAY file, not IFF
                continue
            r = trn.roundtrip(f)
            self.assertTrue(r["identical"], f"{f.name}: differs at {r['first_difference']}")
            self.assertEqual(r["raw_records"], [], f"{f.name}: records not decoded")
            checked += 1
        self.assertGreater(checked, 200)

    @unittest.skipUnless(STOCK.is_dir(), "stock terrain not extracted")
    def test_upgrade_writes_a_loadable_current_file(self):
        doc = trn.TerrainDoc.load(STOCK / "floratest.trn")        # PTAT 0013
        author.upgrade(doc)
        again = trn.TerrainDoc.from_bytes(doc.to_bytes())
        self.assertEqual(again.model["version"], "0015")
        for _, it, _ in again.walk():
            self.assertEqual(it["version"], trn.LATEST[it["tag"]])


class Authoring(unittest.TestCase):
    def setUp(self):
        self.doc = author.example_terrain("unit_test", 1024.0)
        generator.bake_height_data(self.doc)

    def test_example_uses_every_type(self):
        tags = {it["tag"] for _, it, _ in self.doc.walk()}
        want = set(trn.BOUNDARIES) | set(trn.FILTERS) | set(trn.AFFECTORS) | {"LAYR"}
        self.assertEqual(tags, want)
        for g in trn.GROUP_TAGS:
            self.assertTrue(self.doc.model["groups"][g]["families"], g)

    def test_example_validates_and_round_trips(self):
        generator.bake_terrain(self.doc)
        v = author.validate(self.doc)
        self.assertEqual(v["errors"], [])
        data = self.doc.to_bytes()
        again = trn.TerrainDoc.from_bytes(data)
        self.assertEqual(again.to_bytes(), data)
        self.assertEqual(again.raw_records(), [])

    def test_unbaked_road_is_an_error(self):
        lp = author.add_road(self.doc, [[0, 0], [50, 50]], shader_family=1)
        self.assertTrue(any("not baked" in e for e in author.validate(self.doc)["errors"]))
        generator.bake_height_data(self.doc)
        self.assertEqual(author.validate(self.doc)["errors"], [])
        self.assertEqual(len(self.doc.node(lp + "/0")["height_data"]), 1)

    def test_missing_family_is_an_error(self):
        author.add_item(self.doc, "0", "shader_constant", "bad", {"family_id": 99})
        self.assertTrue(any("99" in e for e in author.validate(self.doc)["errors"]))

    def test_flatten_pad_is_flat(self):
        doc = author.new_terrain("flat")
        fam = author.add_family(doc, "fractal", {"name": "f", "seed": 3})["id"]
        base = author.add_layer(doc, "", "base")
        author.add_item(doc, base, "height_fractal", "hills", {"family_id": fam, "scale_y": 40.0})
        author.add_flatten(doc, {"rect": [-20, -20, 20, 20]}, height=7.5, feather=10)
        hs = generator.heights_at(doc, [[0, 0], [15, -15], [-19, 19]])
        self.assertTrue(all(abs(h - 7.5) < 1e-4 for h in hs), hs)
        outside = generator.heights_at(doc, [[200, 200]])[0]
        self.assertNotAlmostEqual(outside, 7.5, places=2)

    def test_items_keep_editor_order(self):
        lp = author.add_layer(self.doc, "", "order")
        author.add_item(self.doc, lp, "height_constant")
        author.add_item(self.doc, lp, "circle")
        author.add_item(self.doc, lp, "slope")
        author.add_layer(self.doc, lp, "sub")
        kinds = [c["kind"] for c in self.doc.node(lp)["items"]]
        self.assertEqual(kinds, ["boundary", "filter", "affector", "layer"])

    def test_fine_exclude_round_trips(self):
        lp = author.add_layer(self.doc, "", "fine hole")
        author.add_item(self.doc, lp, "circle", "hole", {"center_x": 0.0, "center_z": 0.0, "radius": 5.0})
        author.add_item(self.doc, lp, "exclude", "fine cut", {"fine": True})
        data = self.doc.to_bytes()
        again = trn.TerrainDoc.from_bytes(data)
        item = again.node(lp + "/1")
        self.assertEqual((item["version"], item["params"]), ("0001", {"fine": True}))
        self.assertEqual(again.raw_records(), [])
        author.upgrade(again)
        self.assertEqual(again.node(lp + "/1")["version"], "0001")

    def test_hole_has_no_height(self):
        hs = generator.heights_at(self.doc, [[700, -600], [700, -560]])
        self.assertIsNone(hs[0])
        self.assertIsNotNone(hs[1])


class Environment(unittest.TestCase):
    GAME = Path(DATA_ROOTS[0])

    @unittest.skipUnless((Path(DATA_ROOTS[0]) / "terrain/environment").is_dir(), "stock data not extracted")
    def test_stock_environments_round_trip(self):
        files = list((self.GAME / "terrain/environment").glob("*.iff")) +             list((self.GAME / "datatables/environment").glob("*.iff"))
        for f in files:
            data = f.read_bytes()
            if data[8:12] == b"ENVM":
                self.assertEqual(env.write_envm(env.read_envm(data)), data, f.name)
            elif data[8:12] == b"DTII":
                self.assertEqual(env.write_datatable(env.read_datatable(data)), data, f.name)
        self.assertGreater(len(files), 50)

    @unittest.skipUnless((Path(DATA_ROOTS[0]) / "terrain/environment").is_dir(), "stock data not extracted")
    def test_edit_sky_and_rows(self):
        sky, table = env.copy_from("lok", DATA_ROOTS)
        n = len([e for e in sky["entries"] if e["kind"] == "celestial"])
        env.set_envm(sky, "celestial", {"shader": "shader/cels_planet_ring.sht", "size": 1.6, "yaw": 35.0})
        env.set_envm(sky, "sun", {"size": 1.2})
        env.set_env_row(table, {"family": "hive", "weather_index": 0, "fog_max_density": 0.01},
                        template_family="global")
        out = tempfile.mkdtemp(prefix="env_test_")
        env.save("unit", sky, table, out)
        sky2, table2, _ = env.load("unit", [out])
        self.assertEqual(len([e for e in sky2["entries"] if e["kind"] == "celestial"]), n + 1)
        self.assertAlmostEqual(next(e for e in sky2["entries"] if e["kind"] == "sun")["size"], 1.2, places=5)
        row = next(r for r in env.env_rows(table2) if r["family"] == "hive")
        self.assertAlmostEqual(row["fog_max_density"], 0.01, places=6)
        self.assertEqual(env.check_families(table2, ["global", "hive", "missing"]), ["missing"])


REPO = Path(os.environ.get("TITAN_REPO", "D:/titan"))


class PlanetRegistration(unittest.TestCase):
    FILES = [planet.GAME + "/terrain/environment/lok.iff", planet.GAME + "/datatables/environment/lok.iff",
             planet.GAME + "/datatables/loading/general.iff", planet.GAME + "/string/en/planet_n.stf",
             planet.SERVER + "/universe/planets.iff", planet.DSRC_SERVER + "/universe/planets.mif",
             planet.SHARED + "/misc/planet_crc_string_table.iff",
             planet.DSRC_SHARED + "/misc/planet_crc_string_table.txt",
             planet.DSRC_SERVER + "/datatables/region/region_lok.tab",
             planet.DSRC_SERVER + "/datatables/region/planets.tab", "exe/linux/localOptions.cfg",
             "client/src/game/client/application/SwgGodClient/src/BuildoutEditorWindow.cpp"]

    @unittest.skipUnless((REPO / planet.GAME).is_dir(), "repository data not found")
    def test_formats_round_trip(self):
        for rel, read, write in ((planet.SHARED + "/misc/planet_crc_string_table.iff", planet.read_cstb,
                                  planet.write_cstb),
                                 (planet.GAME + "/string/en/planet_n.stf", planet.read_stf, planet.write_stf)):
            data = (REPO / rel).read_bytes()
            self.assertEqual(write(read(data)), data, rel)
        for tab in (REPO / planet.DSRC_SERVER / "datatables/region").glob("*.tab"):
            iff = REPO / planet.SERVER / "datatables/region" / (tab.stem + ".iff")
            if iff.exists():
                self.assertEqual(env.write_datatable(env.compile_tab(tab.read_text(encoding="latin1"))),
                                 iff.read_bytes(), tab.name)

    @unittest.skipUnless((REPO / planet.GAME).is_dir(), "repository data not found")
    def test_register_into_a_copy(self):
        root = Path(tempfile.mkdtemp(prefix="planet_test_"))
        for rel in self.FILES:
            (root / rel).parent.mkdir(parents=True, exist_ok=True)
            (root / rel).write_bytes((REPO / rel).read_bytes())
        doc = author.example_terrain("unitplanet", 1024.0)
        generator.bake_height_data(doc)
        trn_path = root / "unitplanet.trn"
        doc.save(trn_path)
        regions = [{"name": "middle", "x": 0.0, "z": 0.0, "radius": 100.0, "geographical": "plains"}]
        first = planet.register(root, "unitplanet", trn_path, "Unit Planet", regions, env_template="lok",
                                map_image=False)
        self.assertTrue(first["changed"])
        again = planet.register(root, "unitplanet", trn_path, "Unit Planet", regions, env_template="lok",
                                map_image=False)
        self.assertEqual(again["changed"], [])                                   # idempotent
        self.assertIn("unitplanet", planet.read_cstb((root / planet.SHARED / "misc/planet_crc_string_table.iff")
                                                     .read_bytes()))
        stf = planet.read_stf((root / planet.GAME / "string/en/planet_n.stf").read_bytes())
        self.assertIn("unitplanet", [n for _, n in stf["names"]])
        self.assertIn(b"unitplanet\0", (root / planet.SERVER / "universe/planets.iff").read_bytes())
        self.assertIn("startPlanet=unitplanet", (root / "exe/linux/localOptions.cfg").read_text(encoding="latin1"))
        self.assertIn('insertItem("unitplanet")', (root / self.FILES[-1]).read_text(encoding="latin1"))
        reg = env.read_datatable((root / planet.SERVER / "datatables/region/region_unitplanet.iff").read_bytes())
        self.assertEqual([r[0] for r in reg["rows"]][:3], ["unitplanet_mission_default", "unitplanet_world_spawner", "middle"])
        self.assertTrue((root / planet.GAME / "terrain/unitplanet.trn").exists())
        self.assertTrue((root / planet.GAME / "terrain/environment/unitplanet.iff").exists())

    def test_regions_fit_the_planet(self):
        log = []
        rows = planet._region_rows("p", [{"name": "edge", "x": 7000.0, "z": 0.0, "radius": 2000.0},
                                    {"name": "inside", "x": 0.0, "z": 0.0, "radius": 100.0},
                                    {"name": "gone", "x0": 9000.0, "z0": 9000.0, "x1": 9500.0, "z1": 9500.0},
                                    {"name": "Used", "x": 10.0, "z": 10.0, "radius": 5.0}],
                                   8000.0, log, taken={"used"})
        names = [r["name"] for r in rows]
        self.assertEqual(names, ["p_mission_default", "p_world_spawner", "edge", "inside", "p Used"])
        edge = rows[2]
        self.assertEqual((edge["x0"], edge["x1"], edge["z0"], edge["z1"]), (5000.0, 8000.0, -2000.0, 2000.0))
        self.assertIn("radius", rows[3])
        self.assertTrue(any("gone" in x for x in log))


class FineExclusionAndBuildings(unittest.TestCase):
    """Titan's fine exclusion (AEXC 0001) and building layer placement, against hand-computed geometry."""

    def flat(self, h=10.0):
        doc = author.new_terrain("flat", map_width=2048.0)
        lp = author.add_layer(doc, "", "ground")
        author.add_item(doc, lp, "height_constant", "h", {"height": h})
        return doc

    def building(self, radius=7.0, center=(1.5, 0.0), local=True, fine=True):
        lay = author.new_terrain("lay")
        lp = author.add_layer(lay, "", "building")
        author.add_item(lay, lp, "rectangle", "flatten", {"x0": -20.0, "z0": -10.0, "x1": 20.0, "z1": 10.0})
        author.add_item(lay, lp, "height_constant", "flat", {"operation": 0, "height": 0.0})
        author.add_item(lay, lp, "height_constant", "offset", {"operation": 1, "height": 0.5})
        hole = author.add_layer(lay, lp, "hole")
        author.add_item(lay, hole, "circle", ("local hole" if local else "hole"),
                        {"center_x": center[0], "center_z": center[1], "radius": radius})
        author.add_item(lay, hole, "exclude", "cut", {"fine": fine})
        return lay

    def test_fine_hole_follows_the_circle(self):
        doc = generator.place_layer(self.flat(), self.building(), 100.0, 200.0, 0.0, 12.0)
        cx, cz, r = 101.5, 200.0, 7.0
        for a in range(0, 360, 15):
            c, s_ = math.cos(math.radians(a)), math.sin(math.radians(a))
            # the cut follows chords between edge vertices snapped onto the circle, so test 0.6 m inside
            inside, outside = generator.heights_at(doc, [[cx + (r - 0.6) * c, cz + (r - 0.6) * s_],
                                                         [cx + (r + 0.1) * c, cz + (r + 0.1) * s_]])
            self.assertIsNone(inside, f"angle {a}")
            self.assertAlmostEqual(outside, 12.5, places=4, msg=f"angle {a}")     # replace -> 12, add 0.5 kept

    def test_stock_exclude_drops_whole_tiles(self):
        doc = generator.place_layer(self.flat(), self.building(fine=False), 100.0, 200.0, 0.0, 12.0)
        hs = generator.heights_at(doc, [[101.5 + 7.5, 200.0], [101.5, 200.0]])
        self.assertIsNone(hs[1])
        # a coarse cut: some points just outside the circle are still dropped or kept by whole tiles
        self.assertTrue(hs[0] is None or abs(hs[0] - 12.5) < 1e-4)

    def test_local_circle_turns_with_the_building(self):
        # yaw 90 deg: local +x maps to world -z (SWG Transform::yaw_l, x' = x cos + z sin, z' = -x sin + z cos)
        # holes need to be larger than a 4 m tile: smaller ones only fold the tile fans (engine behaviour)
        doc = generator.place_layer(self.flat(), self.building(radius=8.0, center=(10.0, 0.0)), 0.0, 0.0, 90.0, 5.0)
        self.assertIsNone(generator.heights_at(doc, [[0.0, -10.0]])[0])
        self.assertIsNotNone(generator.heights_at(doc, [[10.0, 0.0]])[0])

    def test_plain_circle_is_moved_onto_the_origin(self):
        doc = generator.place_layer(self.flat(), self.building(radius=8.0, center=(10.0, 0.0), local=False),
                                    50.0, 50.0, 0.0, 5.0)
        self.assertIsNone(generator.heights_at(doc, [[50.0, 50.0]])[0])            # offset lost, as in the engine
        self.assertIsNotNone(generator.heights_at(doc, [[60.0, 50.0]])[0])

    def test_rectangle_turns_with_the_building(self):
        doc = generator.place_layer(self.flat(1.0), self.building(radius=0.5), 0.0, 0.0, 90.0, 5.0)
        # the 40 x 20 rectangle is 20 x 40 in world after a quarter turn
        self.assertAlmostEqual(generator.heights_at(doc, [[0.0, 18.0]])[0], 5.5, places=4)
        self.assertAlmostEqual(generator.heights_at(doc, [[18.0, 0.0]])[0], 1.0, places=4)

    @unittest.skipUnless(Path("D:/exported/terrain/titan_atmo_starport.lay").exists(), "starport not exported")
    def test_starport_hole_radius(self):
        lay = trn.TerrainDoc.load("D:/exported/terrain/titan_atmo_starport.lay")
        doc = generator.place_layer(self.flat(), lay, 45.0, 450.0, 0.0, 10.0)
        cx, cz = 46.5, 450.0
        pts = [[cx + rr * math.cos(math.radians(a)), cz + rr * math.sin(math.radians(a))]
               for a in range(0, 360, 10) for rr in (28.8, 29.2)]
        hs = generator.heights_at(doc, pts)
        self.assertTrue(all(h is None for h in hs[0::2]))
        self.assertTrue(all(h is not None for h in hs[1::2]))


class Fractal(unittest.TestCase):
    def test_random_generator_matches_ran1(self):
        # ran1 seeded with -1 (Numerical Recipes test values, NTAB 322 variant is deterministic)
        r = RandomGenerator(0)
        a = [r.random() for _ in range(3)]
        r2 = RandomGenerator(0)
        self.assertEqual(a, [r2.random() for _ in range(3)])
        self.assertTrue(all(0 < v < 2 ** 31 for v in a))

    def test_fractal_range(self):
        m = MultiFractal.from_family({"seed": 42, "octaves": 3, "scale_x": 0.01, "scale_y": 0.01})
        vals = [m.value2(x * 7.3, x * 3.1) for x in range(200)]
        self.assertTrue(all(0.0 <= v <= 1.0 for v in vals))
        self.assertGreater(max(vals) - min(vals), 0.2)


class McpTools(unittest.TestCase):
    def test_tools_through_stdio(self):
        try:
            from mcp import ClientSession, StdioServerParameters
            from mcp.client.stdio import stdio_client
        except ImportError:
            self.skipTest("mcp package not installed (use the .venv)")

        out_dir = Path(tempfile.mkdtemp(prefix="trn_test_"))

        async def run():
            params = StdioServerParameters(command=sys.executable, args=["-m", "swg_maya_mcp"], cwd=str(HERE),
                                           env={**os.environ, "TITAN_EXPORT_ROOT": str(out_dir)})
            async with stdio_client(params) as (read, write):
                async with ClientSession(read, write) as s:
                    await s.initialize()

                    async def call(name, args):
                        r = await s.call_tool(name, args)
                        self.assertFalse(r.is_error, f"{name}: {[getattr(c, 'text', '') for c in r.content]}")
                        return r

                    def body(r):
                        sc = r.structured_content
                        if sc is not None:
                            return sc.get("result", sc) if set(sc) == {"result"} else sc
                        return json.loads(next(c.text for c in r.content if getattr(c, "text", None)))

                    await call("trn_new", {"path": "terrain/mcp_test.trn", "settings": {"map_width": 1024.0}})
                    await call("trn_family_set", {"path": "terrain/mcp_test.trn", "group": "shader",
                                                  "family": {"name": "dirt", "children": [{"shader": "dirt_coolmud"}]}})
                    await call("trn_family_set", {"path": "terrain/mcp_test.trn", "group": "fractal",
                                                  "family": {"name": "hills", "seed": 9}})
                    await call("trn_add", {"path": "terrain/mcp_test.trn", "parent": "", "type": "layer",
                                           "name": "ground"})
                    await call("trn_add", {"path": "terrain/mcp_test.trn", "parent": "0", "type": "height_fractal",
                                           "params": {"family_id": 1, "scale_y": 30.0}})
                    await call("trn_add", {"path": "terrain/mcp_test.trn", "parent": "0", "type": "shader_constant",
                                           "params": {"family_id": 1}})
                    r = body(await call("trn_add_feature", {"path": "terrain/mcp_test.trn", "feature": "road",
                                                            "spec": {"points": [[0, 0], [100, 30]],
                                                                     "shader_family": 1}}))
                    self.assertEqual(r["errors"], [])
                    insp = body(await call("trn_inspect", {"path": "terrain/mcp_test.trn"}))
                    self.assertEqual([e["type"] for e in insp["tree"]],
                                     ["layer", "height_fractal", "shader_constant", "layer", "road"])
                    rt = body(await call("trn_roundtrip", {"path": "terrain/mcp_test.trn"}))
                    self.assertEqual(rt["identical"], 1)
                    pv = await call("trn_preview", {"path": "terrain/mcp_test.trn", "resolution": 32})
                    self.assertTrue(any(c.type == "image" for c in pv.content))
                    h = body(await call("trn_heights", {"path": "terrain/mcp_test.trn", "points": [[50, 15]]}))
                    self.assertEqual(len(h["heights"]), 1)
        asyncio.run(run())


if __name__ == "__main__":
    unittest.main()
