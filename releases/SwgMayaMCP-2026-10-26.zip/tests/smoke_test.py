"""End-to-end check through a real MCP stdio client: status -> pob_build -> pob_export_structure.

    .venv\\Scripts\\python.exe tests\\smoke_test.py [export_root]

Uses headless mayapy unless SWG_MAYA_MCP_MODE says otherwise. Exit code 0 = everything verified.
"""

import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

HERE = Path(__file__).resolve().parent.parent
SPEC = {
    "name": "mcp_smoke_bldg",
    "rooms": [
        {"name": "foyer", "min": [-4, 0], "max": [4, 6], "height": 4.0},
        {"name": "hall", "min": [-4, -8], "max": [4, 0], "height": 5.0},
        {"name": "east", "min": [4, -8], "max": [12, 0], "height": 4.0},
    ],
    "doors": [{"rooms": ["foyer", "hall"]}, {"rooms": ["hall", "east"], "offset": -1.5}],
    "entrances": [{"room": "foyer", "side": "+z", "width": 2.4, "height": 3.2}],
}


def payload(result):
    if result.is_error:
        raise SystemExit("tool error: " + " ".join(getattr(c, "text", "") for c in result.content))
    if result.structured_content is not None:
        sc = result.structured_content
        return sc.get("result", sc) if isinstance(sc, dict) and set(sc) == {"result"} else sc
    return json.loads(result.content[0].text)


async def main(export_root: str):
    params = StdioServerParameters(command=sys.executable, args=["-m", "swg_maya_mcp"], cwd=str(HERE),
                                   env={**os.environ, "SWG_MAYA_MCP_MODE": os.environ.get("SWG_MAYA_MCP_MODE", "headless")})
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = {t.name for t in (await session.list_tools()).tools}
            print("tools:", len(tools))
            status = payload(await session.call_tool("maya_status", {}))
            print("status:", status["maya_version"], status["plugin_version"], status["connection"]["kind"])
            built = payload(await session.call_tool("pob_build", {"spec": SPEC}))
            print("built:", built["root"], "cells", built["cells"], "portals",
                  [(p["index"], p["between"], p["rotate_y"]) for p in built["portals"]])
            val = payload(await session.call_tool("pob_validate", {"root": built["root"]}))
            print("validate warnings (pre-export):", val["warnings"])
            out = payload(await session.call_tool("pob_export_structure", {"root": built["root"], "export_root": export_root}))
            print(json.dumps({k: out[k] for k in ("pob", "cells", "floor_checks")}, indent=1))
            summary = out["pob_summary"]
            print("pob issues:", summary["issues"], "missing:", summary.get("missing_files"))
            for c in summary["cells"]:
                print(f"  r{c['index']} {c['name']:8s} seeWorld={c['can_see_world']!s:5s} lights={c['light_count']} "
                      f"portals={[(p['portal_index'], p['clockwise'], p['target_cell']) for p in c['portals']]}")
            ok = not summary["issues"] and not summary.get("missing_files") and \
                all(not f["problems"] and not f["downward_tris"] for f in out["floor_checks"].values())
            for c in summary["cells"][1:]:  # every interior doorway must be walkable through the floor
                tagged = out["floor_checks"][f"r{c['index']}"]["portal_edges_by_portal"]
                missing = [p["portal_index"] for p in c["portals"] if str(p["portal_index"]) not in tagged]
                if missing:
                    print(f"  r{c['index']}: floor has no edge for portal(s) {missing}")
                    ok = False
            print("RESULT:", "PASS" if ok else "FAIL")
            return 0 if ok else 1


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else str(Path(tempfile.gettempdir()) / "swg_maya_mcp_smoke")
    sys.exit(asyncio.run(main(root)))
