"""Jedi Temple, Coruscant: materials, names and the lantern's light (geometry: maya/swg_mcp/frn_groups/jedi.py).
Palette: warm sandstone and cream, tan upholstery, polished bronze, blue kyber glow."""
from __future__ import annotations

import math

import numpy as np

import frn_materials as fm


def _sand(seed=3011):
    n = fm.fbm(seed, 4, 6)
    c = fm.mix(fm.col((194, 170, 134)), fm.col((230, 210, 174)), n * 0.8 + 0.1)
    pits = (fm.fbm(seed + 1, 64, 2) > 0.74).astype(np.float32) * 0.10
    return c * (1 - pits)[..., None]


def jedi_stone():
    """Temple sandstone ashlar: four courses per tile, staggered blocks, soft joints, per-block tint."""
    x, y = fm.coords()
    c = _sand()
    row = np.floor(y * 4)
    off = 0.5 * (row % 2)
    xs, ys = (x * 2 + off) % 1.0, (y * 4) % 1.0
    joint = np.maximum(1 - fm.smooth(0.0, 0.018, np.minimum(xs, 1 - xs)), 1 - fm.smooth(0.0, 0.035, np.minimum(ys, 1 - ys)))
    blk = ((np.floor(x * 2 + off) % 2) * 3 + row) % 4 / 4.0
    c = c * (0.95 + 0.07 * blk)[..., None] * (1 - 0.22 * joint)[..., None]
    return fm.rgba(c)


def jedi_frieze():
    """Carved band (one square motif per tile): rolled mouldings, a pointed niche with a gilded sunburst, a
    lozenge at the seams."""
    x, y = fm.coords()
    v = 1 - y
    c = _sand(3021)
    mould = np.exp(-((v - 0.09) / 0.025) ** 2) + np.exp(-((v - 0.91) / 0.025) ** 2)
    shadow = np.exp(-((v - 0.14) / 0.018) ** 2) + np.exp(-((v - 0.85) / 0.018) ** 2)
    dx = np.abs(x - 0.5)
    arch_top = 0.60 + 0.20 * np.clip(1 - (dx / 0.30) ** 1.4, 0, 1)
    niche = (dx < 0.30) & (v > 0.18) & (v < arch_top)
    rim = (dx < 0.335) & (v > 0.165) & (v < arch_top + 0.035) & ~niche
    ang = np.arctan2(v - 0.18, x - 0.5)
    rays = (np.abs(np.sin(ang * 9)) > 0.72) & niche & (np.hypot(x - 0.5, v - 0.18) > 0.07)
    lz = (np.abs(((x + 0.5) % 1.0) - 0.5) + np.abs(v - 0.50) * 0.55) < 0.085
    shade = 1 + 0.25 * mould - 0.28 * shadow - 0.25 * niche + 0.12 * rim - 0.25 * lz
    c = c * shade[..., None]
    c = fm.mix(c, fm.col((214, 168, 84)), rays.astype(np.float32) * 0.65)
    c = fm.mix(c, fm.col((90, 150, 220)), (np.hypot(x - 0.5, v - 0.18) < 0.045).astype(np.float32) * 0.8)
    return fm.rgba(c)


def jedi_cream():
    """Council-chair shell: smooth cream lacquer, faint flow streaks, satin sheen."""
    x, y = fm.coords()
    n = fm.fbm(3031, 4, 5)
    streak = np.sin((x + 0.05 * n) * 2 * math.pi * 3) * 0.5 + 0.5
    c = fm.mix(fm.col((222, 208, 180)), fm.col((244, 236, 216)), 0.55 + 0.35 * n - 0.1 * streak)
    return fm.rgba(c, 0.5)


def jedi_tan():
    """Tan suede upholstery, channel tufted along u, top-stitched seams."""
    x, y = fm.coords()
    u = (x * 4) % 1.0
    puff = np.sin(u * math.pi) ** 0.6
    c = fm.col((172, 128, 82)) * (0.62 + 0.45 * puff)[..., None] * (0.9 + 0.2 * fm.fbm(3041, 32, 3))[..., None]
    stitch = ((np.abs(u - 0.06) < 0.012) | (np.abs(u - 0.94) < 0.012)) & (((y * 90) % 1.0) < 0.55)
    c = fm.mix(c, fm.col((236, 214, 170)), stitch.astype(np.float32) * 0.7)
    return fm.rgba(c, 0.12 + 0.18 * puff)


def jedi_bronze():
    """Polished temple bronze: warm highlights, fine brushing, a little verdigris in the low spots."""
    x, y = fm.coords()
    n = fm.fbm(3051, 4, 5)
    c = fm.mix(fm.col((104, 70, 38)), fm.col((204, 158, 96)), 0.30 + 0.6 * n)
    c = c * (1 - 0.08 * fm.lines(y, 1 / 64, 0.002))[..., None]
    pat = fm.smooth(0.68, 0.86, fm.fbm(3052, 8, 4))
    c = fm.mix(c, fm.col((96, 118, 92)), pat * 0.35)
    return fm.rgba(c, 0.85 - 0.45 * pat)


def jedi_kyber():
    """Kyber crystal (self-lit): blue-white facets (six round u) with bright edges, a hot core along the length."""
    x, y = fm.coords()
    f = (x * 6) % 1.0
    edge = 1 - fm.smooth(0.0, 0.12, np.minimum(f, 1 - f))
    streak = 0.5 + 0.5 * np.sin((y * 3 + 0.3 * fm.fbm(3061, 4, 3)) * 2 * math.pi)
    c = fm.mix(fm.col((60, 140, 255)), fm.col((170, 220, 255)), 0.4 + 0.4 * streak)
    c = fm.mix(c, fm.col((240, 250, 255)), edge * 0.8)
    return fm.rgba(c)


def jedi_glow():
    """Soft kyber aura (a_alpha_emis_full: alpha = brightness)."""
    n = fm.fbm(3071, 4, 4)
    c = fm.mix(fm.col((90, 160, 255)), fm.col((180, 220, 255)), n)
    return fm.rgba(c, 0.24 + 0.14 * n)


def _emblem(x, y, cx=0.5, cy=0.5, s=1.0):
    """The Jedi Order's winged blade, roughly: a tapering vertical blade crossing a pair of upswept wings and a
    ring (y up, unit square)."""
    dx, dy = (x - cx) / s, (y - cy) / s
    blade = (np.abs(dx) < 0.018 + 0.012 * (0.4 - dy)) & (dy > -0.42) & (dy < 0.40)
    r = np.hypot(dx, dy + 0.02)
    ring = np.abs(r - 0.22) < 0.022
    wing = np.zeros_like(dx, bool)
    for sx in (-1, 1):
        ex = sx * dx
        wing |= (ex > 0.03) & (ex < 0.40) & (np.abs(dy - (0.10 * ex / 0.40) ** 1.0 * 1.6 + 0.02) < 0.035 * (1 - ex / 0.45))
        wing |= (ex > 0.03) & (ex < 0.30) & (np.abs(dy - 0.25 * ex + 0.06) < 0.022 * (1 - ex / 0.32))
    return (blade | ring | wing).astype(np.float32)


def jedi_holocron():
    """Holocron face (self-lit, fit once per face): nested glowing frames, corner filigree and the Order's emblem."""
    x, y = fm.coords()
    v = 1 - y
    dx, dy = x - 0.5, v - 0.5
    r = np.maximum(np.abs(dx), np.abs(dy))
    c = fm.mix(fm.col((24, 60, 130)), fm.col((90, 170, 255)), fm.smooth(0.5, 0.05, r))
    frames = (np.abs(r - 0.44) < 0.012) | (np.abs(r - 0.36) < 0.007) | (np.abs(r - 0.28) < 0.006)
    diag = (np.abs(np.abs(dx) - np.abs(dy)) < 0.012) & (r > 0.28) & (r < 0.44)
    c = fm.mix(c, fm.col((200, 236, 255)), (frames | diag).astype(np.float32))
    c = fm.mix(c, fm.col((240, 250, 255)), _emblem(x, v, s=0.55))
    return fm.rgba(c)


def jedi_mat():
    """Round meditation mat (fit on the disc): woven concentric bands in cream, tan and umber, a spoked ring and a
    blue-grey medallion with the Order's emblem."""
    x, y = fm.coords()
    v = 1 - y
    d = np.hypot(x - 0.5, v - 0.5) * 2
    a = np.arctan2(v - 0.5, x - 0.5)
    weave = (np.sin(x * fm.N * math.pi / 3) * np.sin(v * fm.N * math.pi / 3)) * 0.5 + 0.5
    bands = [(0.0, (70, 92, 116)), (0.20, (232, 220, 192)), (0.24, (176, 132, 86)), (0.56, (120, 78, 46)),
             (0.61, (228, 214, 184)), (0.88, (120, 78, 46)), (0.95, (176, 132, 86))]
    c = fm.col(bands[0][1])
    for r0, rgb in bands[1:]:
        c = fm.mix(c, fm.col(rgb), fm.smooth(r0 - 0.006, r0 + 0.006, d))
    spokes = (np.abs(np.sin(a * 12)) < 0.10) & (d > 0.26) & (d < 0.54)
    c = fm.mix(c, fm.col((232, 220, 192)), spokes.astype(np.float32) * 0.8)
    keys = (np.abs(np.sin(a * 24)) > 0.7) & (np.abs(d - 0.745) < 0.05)
    c = fm.mix(c, fm.col((176, 132, 86)), keys.astype(np.float32) * 0.8)
    c = fm.mix(c, fm.col((210, 222, 236)), _emblem(x, v, s=0.36) * (d < 0.2))
    c = c * (0.86 + 0.18 * weave)[..., None]
    return fm.rgba(c)


def jedi_mosaic():
    """Floor mosaic (fit on a disc): cream marble tesserae, a 24-ray tan and bronze sunburst, a bronze border."""
    x, y = fm.coords()
    v = 1 - y
    d = np.hypot(x - 0.5, v - 0.5) * 2
    a = np.arctan2(v - 0.5, x - 0.5)
    c = fm.mix(fm.col((222, 210, 186)), fm.col((240, 232, 214)), fm.fbm(3091, 8, 4))
    ray = np.abs(((a / (2 * math.pi) * 24) % 1.0) - 0.5) * 2
    rays = (ray < (1 - d) * 0.9) & (d > 0.16) & (d < 0.9)
    c = fm.mix(c, fm.mix(fm.col((190, 150, 100)), fm.col((170, 120, 60)), (np.floor(a / (2 * math.pi) * 24) % 2)), rays.astype(np.float32))
    border = (np.abs(d - 0.94) < 0.025) | (np.abs(d - 0.16) < 0.015)
    c = fm.mix(c, fm.col((176, 126, 62)), border.astype(np.float32))
    tess = np.maximum(fm.lines(x, 1 / 96, 0.0012), fm.lines(v, 1 / 96, 0.0012))
    return fm.rgba(c * (1 - 0.18 * tess)[..., None])


def jedi_tape():
    """One holobook data tape (self-lit, fit once per face): a glowing spine, bright edges, a label block near
    the top, brighter toward the top."""
    x, y = fm.coords()
    v = 1 - y
    edge = 1 - fm.smooth(0.0, 0.16, np.minimum(x, 1 - x))
    c = fm.mix(fm.col((26, 70, 160)), fm.col((110, 196, 255)), 0.30 + 0.70 * v)
    c = fm.mix(c, fm.col((205, 238, 255)), edge * 0.75)
    label = (v > 0.80) & (v < 0.87) & (x > 0.2) & (x < 0.8)
    c = fm.mix(c, fm.col((240, 250, 255)), label.astype(np.float32))
    band = (np.abs(v - 0.12) < 0.012)
    c = fm.mix(c, fm.col((200, 236, 255)), band.astype(np.float32) * 0.8)
    return fm.rgba(c)


def jedi_tapes():
    """Holobook data tapes in a row (self-lit, world tiled; far LODs): 16 glowing spines per tile with bright
    edges, label blocks near the top, each spine its own brightness."""
    x, y = fm.coords()
    v = 1 - y
    k = np.floor(x * 16).astype(int) % 16
    s = (x * 16) % 1.0
    bright = np.array([0.75, 1.0, 0.85, 0.6, 0.95, 0.8, 1.0, 0.7, 0.9, 0.65, 1.0, 0.8, 0.7, 0.95, 0.85, 0.6])[k]
    edge = 1 - fm.smooth(0.0, 0.14, np.minimum(s, 1 - s))
    c = fm.mix(fm.col((30, 80, 170)), fm.col((120, 200, 255)), (0.35 + 0.65 * v) * bright)
    c = fm.mix(c, fm.col((200, 236, 255)), edge * 0.7)
    label = (v > 0.80) & (v < 0.86) & (s > 0.25) & (s < 0.75)
    c = fm.mix(c, fm.col((235, 248, 255)), label.astype(np.float32))
    gap = (s < 0.04) | (s > 0.96)
    c = fm.mix(c, fm.col((10, 20, 40)), gap.astype(np.float32) * 0.8)
    return fm.rgba(c)


def jedi_metal():
    """Training-remote / hilt metal: satin silver-grey, fine brushing."""
    x, y = fm.coords()
    c = fm.mix(fm.col((140, 146, 154)), fm.col((198, 202, 208)), fm.fbm(3101, 4, 4))
    c = c * (1 - 0.08 * fm.lines(y, 1 / 48, 0.002))[..., None]
    return fm.rgba(c, 0.7)


def jedi_visor():
    """Smoked blast-shield / grip black: deep blue-grey gloss."""
    c = fm.col((32, 38, 48)) * (0.9 + 0.2 * fm.fbm(3111, 4, 4))[..., None]
    return fm.rgba(c, 0.85)


def jedi_saber():
    """Training-saber blade core (self-lit): white-hot with a faint blue cast."""
    x, y = fm.coords()
    c = fm.mix(fm.col((205, 230, 255)), fm.col((245, 250, 255)), 0.5 + 0.5 * np.sin(y * 2 * math.pi * 4))
    return fm.rgba(c)


def jedi_water():
    """Fountain water (a_alpha): blue-teal with rippling caustics."""
    x, y = fm.coords()
    n = fm.fbm(3121, 4, 5)
    caus = np.abs(np.sin((fm.fbm(3122, 6, 4) * 9) * math.pi))
    caus = 1 - fm.smooth(0.0, 0.25, caus)
    c = fm.mix(fm.col((40, 118, 150)), fm.col((110, 190, 214)), n)
    c = fm.mix(c, fm.col((220, 245, 250)), caus * 0.55)
    return fm.rgba(c, 0.5 + 0.25 * caus)


def jedi_falls():
    """Falling water (a_alpha): streaks along v (the fall), brighter white threads, a ripple every so often."""
    x, y = fm.coords()
    col_noise = fm.fbm(3125, 16, 4)[:1, :].repeat(fm.N, 0)              # varies across u only: vertical streaks
    streak = 0.5 + 0.5 * np.sin((x * 24 + 2.5 * col_noise) * 2 * math.pi)
    ripple = 0.5 + 0.5 * np.sin((y * 6 + 0.4 * fm.fbm(3126, 4, 3)) * 2 * math.pi)
    c = fm.mix(fm.col((70, 150, 180)), fm.col((200, 236, 246)), 0.35 * streak + 0.25 * ripple + 0.2 * col_noise)
    return fm.rgba(c, 0.30 + 0.30 * streak + 0.12 * ripple)


def jedi_foam():
    """Splash foam (a_alpha, world tiled): broken white bubbles."""
    n = fm.fbm(3131, 16, 4)
    return fm.rgba(fm.col((236, 246, 250)), fm.smooth(0.38, 0.66, n) * 0.85 + 0.04)


def jedi_leaf():
    """Lily-pad / reed green with fine veins."""
    x, y = fm.coords()
    c = fm.mix(fm.col((50, 104, 44)), fm.col((104, 166, 70)), fm.fbm(3141, 8, 4))
    c = c * (1 - 0.25 * fm.lines(x, 1 / 8, 0.003))[..., None]
    return fm.rgba(c, 0.35)


def jedi_shadow():
    """Recess / shelf-back brown-black, faint vertical panel lines."""
    x, y = fm.coords()
    c = fm.col((46, 35, 27)) * (0.85 + 0.3 * fm.fbm(3151, 8, 4))[..., None]
    return fm.rgba(c * (1 - 0.3 * fm.lines(x, 1 / 4, 0.003))[..., None])


MATS = {
    "jedi_stone": ("a_simple", jedi_stone, 0, 0),
    "jedi_frieze": ("a_simple", jedi_frieze, 0, 0),
    "jedi_cream": ("a_specmap", jedi_cream, 0.45, 25),
    "jedi_tan": ("a_specmap", jedi_tan, 0.25, 12),
    "jedi_bronze": ("a_specmap", jedi_bronze, 0.75, 32),
    "jedi_kyber": ("a_emis_full", jedi_kyber, 0, 0),
    "jedi_glow": ("a_alpha_emis_full", jedi_glow, 0, 0),
    "jedi_holocron": ("a_emis_full", jedi_holocron, 0, 0),
    "jedi_mat": ("a_simple", jedi_mat, 0, 0),
    "jedi_mosaic": ("a_simple", jedi_mosaic, 0, 0),
    "jedi_tape": ("a_emis_full", jedi_tape, 0, 0),
    "jedi_tapes": ("a_emis_full", jedi_tapes, 0, 0),
    "jedi_metal": ("a_specmap", jedi_metal, 0.7, 35),
    "jedi_visor": ("a_specmap", jedi_visor, 0.6, 40),
    "jedi_saber": ("a_emis_full", jedi_saber, 0, 0),
    "jedi_water": ("a_alpha", jedi_water, 0, 0),
    "jedi_falls": ("a_alpha", jedi_falls, 0, 0),
    "jedi_foam": ("a_alpha", jedi_foam, 0, 0),
    "jedi_leaf": ("a_specmap", jedi_leaf, 0.3, 15),
    "jedi_shadow": ("a_simple", jedi_shadow, 0, 0),
}

INFO = {
    "jedi_meditation_mat": ("interact", "Jedi Meditation Dais",
                            "A woven meditation mat inside a low stone dais ring, a kyber shrine ahead and holocrons "
                            "drifting in orbit beneath a bronze halo. Sit, breathe and let the Force flow. Try not to "
                            "levitate the holocrons into the ceiling."),
    "jedi_council_chair": ("seat", "Jedi Council Chair",
                           "One of the twelve seats of the Jedi High Council: a curved cream shell with sweeping "
                           "wings, tan cushions and a bronze base. The rank of Master is not included."),
    "jedi_temple_lantern": ("lamp", "Jedi Temple Lantern",
                            "A tall stone lantern from the Temple processional, its arched chamber cradling a kyber "
                            "crystal that bathes the room in a calm blue-white light."),
    "jedi_archive_shelf": ("decor", "Jedi Archives Shelf",
                           "A bay from the Jedi Archives, its bronze shelves lined with glowing holobook data tapes "
                           "beneath a master's bust and a holocron. If it is not on these shelves, it does not exist."),
    "jedi_training_remote": ("decor", "Jedi Training Display",
                             "A training remote hovering over its pedestal, a blast-shield helmet on a head form and a "
                             "training lightsaber in its cradle. Drop the shield and trust the Force, not your eyes."),
    "jedi_fountain": ("decor", "Temple Fountain",
                      "A stone basin from the Room of a Thousand Fountains: arcing jets, overflow streams from a bronze "
                      "bowl, lily pads and kyber lights glowing beneath the water. Only nine hundred and ninety-nine "
                      "to go."),
}

LIGHTS = {
    "jedi_temple_lantern": [{"hardpoint": "light", "type": 1, "rgb": (0.0034, 0.0040, 0.0050), "range": 10.0,
                             "constant": 0.0, "linear": 0.00195, "quadratic": 0.0, "flags": 0}],
}
