"""Host side of the Bespin Cloud City group (geometry: maya/swg_mcp/frn_groups/bsp.py): glossy white, peach
satin, channel-quilted cushions, amber light, bronze trim, the terminal screen and keypad, Bespin plants and a
sunset cloudscape; names and descriptions; the light sculpture's light."""
from __future__ import annotations

import math

import numpy as np

import frn_materials as fm

TAU = 2 * math.pi


def _rgb(c):
    return fm.col(c)


def bsp_white():
    """Cloud City white: warm glossy enamel, faint wide panel seams and soft art-deco grooves."""
    x, y = fm.coords()
    seam, light = fm.bevel_panels(x, y, 1, 2, 0.003)
    groove = fm.grooves(y, 0.25, 0.006) * 0.5
    c = _rgb((244, 240, 233)) * (0.965 + 0.05 * fm.fbm(801, 4, 4))[..., None]
    c = c * (1 - 0.18 * seam - 0.08 * groove)[..., None] + _rgb((255, 250, 244)) * (0.04 * light)[..., None]
    return fm.rgba(c, 0.75 - 0.4 * seam)


def bsp_peach():
    """Bespin peach satin paint (the city's sunset-pink walls)."""
    x, y = fm.coords()
    n = fm.fbm(802, 6, 4)
    c = fm.mix(_rgb((226, 150, 120)), _rgb((242, 178, 146)), n)
    return fm.rgba(c, 0.55 + 0.15 * n)


def bsp_cushion():
    """Peach-coral upholstery in horizontal channel quilting (u across, v along the channels)."""
    x, y = fm.coords()
    v = (y * 6) % 1.0
    puff = np.sin(v * math.pi) ** 0.6
    c = _rgb((236, 150, 112)) * (0.62 + 0.42 * puff)[..., None]
    stitch = (np.minimum(v, 1 - v) < 0.03) & (((x * 90) % 1.0) < 0.55)
    c = fm.mix(c, _rgb((252, 214, 186)), stitch.astype(np.float32) * 0.6)
    c *= (0.94 + 0.1 * fm.fbm(803, 32, 3))[..., None]
    return fm.rgba(c, 0.18 + 0.25 * puff)


def bsp_glow():
    """Amber light strip (a_emis_full): warm and even with a hot core sheen, reads on any mapping."""
    x, y = fm.coords()
    n = fm.fbm(804, 4, 3)
    core = 0.5 + 0.5 * np.cos((x - 0.5) * TAU)
    c = fm.mix(_rgb((246, 128, 40)), _rgb((255, 204, 120)), 0.45 * core + 0.35 * n)
    return fm.rgba(c)


def bsp_core():
    """Glowing orb core (a_emis_full): sunset gold fading to coral at the rim."""
    x, y = fm.coords()
    n = fm.fbm(805, 4, 4)
    band = 0.5 + 0.5 * np.cos((y - 0.5) * math.pi)
    c = fm.mix(_rgb((250, 132, 70)), _rgb((255, 222, 150)), 0.6 * band + 0.4 * n)
    return fm.rgba(c)


def bsp_halo():
    """Soft frosted halo shell (a_alpha_emis_full): pale amber, alpha = brightness."""
    x, y = fm.coords()
    n = fm.fbm(806, 8, 3)
    rings = fm.lines(y, 1 / 6, 0.006)
    c = fm.mix(_rgb((255, 196, 130)), _rgb((255, 236, 200)), n)
    return fm.rgba(c, 0.25 + 0.15 * n + 0.25 * rings)


def bsp_metal():
    """Brushed champagne bronze trim."""
    x, y = fm.coords()
    brush = fm.fbm(807, 64, 2)[:, :1].repeat(fm.N, 1) * 0.5 + fm.fbm(808, 4, 3) * 0.5
    c = fm.mix(_rgb((150, 112, 78)), _rgb((222, 184, 140)), brush)
    return fm.rgba(c, 0.85)


def bsp_glass():
    """Peach-tinted table glass (a_alpha): nearly clear, faint diagonal reflections and a rim frost."""
    x, y = fm.coords()
    streak = np.exp(-((((x + y) * 1.0) % 0.5 - 0.25) / 0.04) ** 2) * 0.6
    c = _rgb((250, 226, 210)) * (0.94 + 0.08 * fm.fbm(809, 4, 3))[..., None]
    return fm.rgba(c + streak[..., None] * 0.2, 0.16 + 0.2 * streak)


def bsp_screen():
    """Cloud City terminal display (fit, a_emis_full): amber on deep umber - header bar with the city emblem, a
    tibanna yield graph, a round gauge, readout rows, a status strip."""
    x, y = fm.coords()
    v = 1 - y
    c = fm.mix(_rgb((40, 18, 10)), _rgb((22, 10, 6)), v)
    grid = np.maximum(fm.lines(x, 1 / 16, 0.002), fm.lines(v, 1 / 10, 0.002)) * 0.25
    c = fm.mix(c, _rgb((140, 64, 24)), grid)
    amber, hot = _rgb((255, 160, 60)), _rgb((255, 226, 160))
    header = (v > 0.86) & (v < 0.95) & (x > 0.04) & (x < 0.96)
    c = fm.mix(c, _rgb((190, 92, 34)), header.astype(np.float32))
    em = np.sqrt(((x - 0.09) * 1.6) ** 2 + (v - 0.905) ** 2)
    c = fm.mix(c, hot, ((em < 0.035) & (em > 0.022)).astype(np.float32))
    txt = (v > 0.885) & (v < 0.925) & (x > 0.16) & (x < 0.62) & (((x * 60) % 1.0) < 0.62)
    c = fm.mix(c, hot, txt.astype(np.float32) * 0.85)
    gx0, gx1, gv0, gv1 = 0.05, 0.60, 0.40, 0.80
    box = (x > gx0) & (x < gx1) & (v > gv0) & (v < gv1)
    c = fm.mix(c, _rgb((60, 26, 12)), box.astype(np.float32) * 0.6)
    t = (x - gx0) / (gx1 - gx0)
    curve = gv0 + 0.06 + 0.25 * (0.5 + 0.5 * np.sin(t * TAU * 1.7 + 0.6)) * (0.6 + 0.4 * t)
    c = fm.mix(c, amber, (box & (np.abs(v - curve) < 0.008)).astype(np.float32))
    fill = box & (v < curve)
    c = fm.mix(c, _rgb((120, 50, 18)), fill.astype(np.float32) * 0.5)
    d = np.sqrt(((x - 0.80) * 1.6) ** 2 + (v - 0.60) ** 2)
    a = np.arctan2(v - 0.60, (x - 0.80) * 1.6)
    ring = (d > 0.13) & (d < 0.16)
    arcm = ring & (a > -0.6) & (a < 2.4)
    c = fm.mix(c, _rgb((90, 38, 14)), ring.astype(np.float32))
    c = fm.mix(c, amber, arcm.astype(np.float32))
    needle = (np.abs(np.sin(a - 1.6)) * d < 0.006) & (d < 0.12) & (np.cos(a - 1.6) > 0)
    c = fm.mix(c, hot, needle.astype(np.float32))
    for k in range(5):
        vv = 0.30 - 0.05 * k
        row = (v > vv - 0.012) & (v < vv + 0.012) & (x > 0.05)
        ln = 0.25 + 0.6 * ((k * 0.37) % 1.0)
        bar = row & (x < 0.05 + 0.55 * ln) & (((x * 70) % 1.0) < 0.6)
        c = fm.mix(c, amber * (0.6 + 0.08 * k), bar.astype(np.float32))
        lit = row & (x > 0.70) & (x < 0.70 + 0.05 * (k + 1))
        c = fm.mix(c, hot if k % 2 else amber, lit.astype(np.float32))
    border = (np.minimum(np.minimum(x, 1 - x), np.minimum(v, 1 - v)) < 0.012)
    c = fm.mix(c, _rgb((210, 110, 40)), border.astype(np.float32))
    scan = 0.93 + 0.07 * np.sin(v * fm.N * math.pi * 0.5)
    return fm.rgba(c * scan[..., None])


def bsp_keypad():
    """Keypad face (fit, a_emis_full): rows of rounded amber keys on dark bronze, a lit function row, a round
    track dial at the right, a thin amber frame."""
    x, y = fm.coords()
    v = 1 - y
    c = fm.mix(_rgb((46, 28, 20)), _rgb((64, 40, 28)), fm.fbm(810, 8, 3))
    kx = np.clip(x / 0.74, 0, 0.9999)
    cols, rows = 11, 4
    u, w = (kx * cols) % 1.0, (v * rows) % 1.0
    ku, kw = np.minimum(u, 1 - u), np.minimum(w, 1 - w)
    key = (ku > 0.14) & (kw > 0.16) & (x < 0.74) & (v > 0.04) & (v < 0.96)
    rim = key & ((ku < 0.22) | (kw < 0.24))
    ci, ri = (kx * cols).astype(int), (v * rows).astype(int)
    lit = ((ci * 7 + ri * 3) % 6 == 0)
    top = ri == rows - 1
    kc = np.where(top[..., None], _rgb((255, 200, 120)), _rgb((222, 120, 48)))
    kc = np.where((lit & ~top)[..., None], _rgb((255, 230, 176)), kc)
    c = np.where(key[..., None], kc, c)
    c = fm.mix(c, _rgb((110, 54, 22)), rim.astype(np.float32) * 0.7)
    d = np.sqrt(((x - 0.87) * 2.1) ** 2 + (v - 0.5) ** 2)
    c = fm.mix(c, _rgb((90, 46, 22)), (d < 0.30).astype(np.float32))
    c = fm.mix(c, _rgb((255, 170, 80)), ((d > 0.24) & (d < 0.28)).astype(np.float32))
    c = fm.mix(c, _rgb((255, 226, 170)), (d < 0.08).astype(np.float32))
    frame = np.minimum(np.minimum(x, 1 - x) * 2.1, np.minimum(v, 1 - v)) < 0.025
    c = fm.mix(c, _rgb((220, 120, 44)), frame.astype(np.float32))
    return fm.rgba(c)


def bsp_emblem():
    """Cloud City emblem for the back of the terminal (fit, a_alpha): the floating city in a peach roundel, clear
    outside the roundel."""
    x, y = fm.coords()
    v = 1 - y
    dx, dv = x - 0.5, v - 0.5
    r = np.sqrt(dx * dx + dv * dv)
    c = _rgb((246, 242, 236))
    c = fm.mix(c, _rgb((255, 214, 170)), ((r < 0.40)).astype(np.float32))
    disc = (np.abs(dv - 0.02) < 0.05 - 0.12 * np.abs(dx)) & (np.abs(dx) < 0.32)
    stalk = (np.abs(dx) < 0.03 + 0.06 * np.clip(-dv - 0.05, 0, 1)) & (dv < 0.0) & (dv > -0.30)
    towers = (np.abs(dx) < 0.12) & (dv > 0.04) & (dv < 0.04 + 0.16 * np.sqrt(np.clip(1 - np.abs(dx) / 0.12, 0, 1))) & (((x * 30) % 1.0) < 0.7)
    m = disc | stalk | towers
    c = fm.mix(c, _rgb((150, 80, 54)), m.astype(np.float32))
    return fm.rgba(c, fm.smooth(0.475, 0.465, r))


def bsp_plant():
    """Bespin pipe-plant skin: sea-green tube with pale growth rings along v and fine vertical striations."""
    x, y = fm.coords()
    n = fm.fbm(811, 8, 4)
    rings = fm.grooves(y, 1 / 5, 0.03)
    stri = (np.abs(((x * 12) % 1.0) - 0.5) < 0.08).astype(np.float32) * 0.15
    c = fm.mix(_rgb((52, 128, 116)), _rgb((96, 170, 140)), n)
    c = fm.mix(c, _rgb((206, 226, 190)), rings * 0.7)
    c = c * (1 - stri)[..., None]
    return fm.rgba(c, 0.35 + 0.3 * rings)


def bsp_pod():
    """Glowing seed pods and trumpet throats (a_emis_full): coral-to-gold with bright spore dots."""
    x, y = fm.coords()
    v = 1 - y
    n = fm.fbm(812, 8, 4)
    c = fm.mix(_rgb((236, 96, 88)), _rgb((255, 184, 96)), 0.5 * v + 0.5 * n)
    r = np.random.default_rng(813)
    dots = np.zeros_like(x)
    for _ in range(60):
        dots = np.maximum(dots, fm.disc_mask(x, y, r.random(), r.random(), 0.01 + 0.01 * r.random(), 0.004))
    c = fm.mix(c, _rgb((255, 240, 200)), dots * 0.8)
    return fm.rgba(c)


def bsp_soil():
    x, y = fm.coords()
    n = fm.fbm(814, 32, 3)
    peb = (fm.fbm(815, 64, 2) > 0.62).astype(np.float32)
    c = fm.mix(_rgb((54, 46, 50)), _rgb((86, 72, 70)), n)
    c = fm.mix(c, _rgb((150, 130, 120)), peb * 0.5)
    return fm.rgba(c)


def bsp_sky():
    """Bespin sunset cloudscape (fit, a_emis_full) for the round viewport: amber horizon, coral and violet sky, a
    low sun, towering lit cloud banks and distant city spires."""
    x, y = fm.coords()
    v = 1 - y
    N = fm.N
    stretch = (np.arange(N) * 0.4).astype(int)
    c = fm.mix(_rgb((255, 176, 92)), _rgb((246, 128, 112)), fm.smooth(0.30, 0.55, v))
    c = fm.mix(c, _rgb((150, 104, 160)), fm.smooth(0.55, 0.95, v))
    sd = np.sqrt((x - 0.38) ** 2 + (v - 0.42) ** 2)
    c = c + _rgb((255, 200, 120)) * (np.clip(0.35 - sd, 0, 1) * 1.1)[..., None]
    c = fm.mix(c, _rgb((255, 246, 214)), fm.smooth(0.06, 0.05, sd))
    # cloud banks: three layers, lit gold on top, coral-violet beneath
    for k, (base, amp, seed, top_c, bot_c) in enumerate((
            (0.62, 0.10, 821, (255, 200, 170), (190, 110, 140)),
            (0.44, 0.12, 822, (255, 214, 160), (210, 120, 110)),
            (0.22, 0.14, 823, (255, 226, 176), (226, 140, 96)))):
        n = fm.fbm(seed, 4, 5)[stretch]
        edge = base + amp * (n - 0.5) * 2 + 0.03 * np.sin(x * TAU * 3 + k)
        body = v < edge
        depth = np.clip((edge - v) / 0.12, 0, 1)
        col = fm.mix(_rgb(top_c), _rgb(bot_c), depth)
        c = fm.mix(c, col, body.astype(np.float32) * (0.85 if k < 2 else 1.0))
    # distant city spires on the far cloud bank
    for k, (sx, h) in enumerate(((0.70, 0.12), (0.74, 0.18), (0.78, 0.10), (0.20, 0.08), (0.23, 0.13))):
        spire = (np.abs(x - sx) < 0.008 + 0.01 * (v < 0.50)) & (v > 0.44) & (v < 0.44 + h)
        c = fm.mix(c, _rgb((120, 70, 90)), spire.astype(np.float32) * 0.7)
    # a twin-pod cloud car silhouette
    car = (np.abs(x - 0.58) < 0.03) & (np.abs(v - 0.70) < 0.006)
    car |= ((x - 0.555) ** 2 + ((v - 0.70) * 1.5) ** 2 < 0.012 ** 2) | ((x - 0.605) ** 2 + ((v - 0.70) * 1.5) ** 2 < 0.012 ** 2)
    c = fm.mix(c, _rgb((90, 50, 70)), car.astype(np.float32))
    return fm.rgba(np.clip(c, 0, 1))


MATS = {
    "bsp_white": ("a_specmap", bsp_white, 0.6, 40),
    "bsp_peach": ("a_specmap", bsp_peach, 0.45, 25),
    "bsp_cushion": ("a_specmap", bsp_cushion, 0.25, 12),
    "bsp_glow": ("a_emis_full", bsp_glow, 0, 0),
    "bsp_core": ("a_emis_full", bsp_core, 0, 0),
    "bsp_halo": ("a_alpha_emis_full", bsp_halo, 0, 0),
    "bsp_metal": ("a_specmap", bsp_metal, 0.75, 35),
    "bsp_glass": ("a_alpha", bsp_glass, 0, 0),
    "bsp_screen": ("a_emis_full", bsp_screen, 0, 0),
    "bsp_keypad": ("a_emis_full", bsp_keypad, 0, 0),
    "bsp_emblem": ("a_alpha", bsp_emblem, 0, 0),
    "bsp_plant": ("a_specmap", bsp_plant, 0.35, 18),
    "bsp_pod": ("a_emis_full", bsp_pod, 0, 0),
    "bsp_soil": ("a_simple", bsp_soil, 0, 0),
    "bsp_sky": ("a_emis_full", bsp_sky, 0, 0),
}

INFO = {
    "bsp_data_terminal": ("interact", "Cloud City Data Terminal",
                          "A standing terminal from the Administrator's levels: a swan-neck pedestal, an amber screen of "
                          "tibanna yields and a keypad that slopes politely toward you. Step up and work it."),
    "bsp_pod_chair": ("seat", "Bespin Pod Lounger",
                      "A white egg pod tilted open on a trumpet pedestal, lined in quilted peach with a plush back "
                      "cushion. The best seat for watching a sunset over the clouds."),
    "bsp_light_sculpture": ("lamp", "Sunset Light Sculpture",
                            "A white crescent curling over a glowing orb, with a cascade of amber rings below it. It "
                            "lights a room the colour of Bespin at dusk."),
    "bsp_coffee_table": ("table", "Cloud City Coffee Table",
                         "A low round table: glass over an amber light ring and a bronze miniature of Cloud City itself. "
                         "Put your caf down on the city; Lando won't mind."),
    "bsp_planter": ("decor", "Bespin Pipe-Plant Planter",
                    "A deco planter of tall tubular Bespin plants with glowing seed pods, grown in the city's sky "
                    "gardens and quite at home a mile above anything."),
    "bsp_cloud_window": ("decor", "Cloud City Viewport",
                         "A free-standing curved viewport with the city's round ribbed window, showing an endless "
                         "Bespin sunset on both sides. No carbon-freezing chamber view, guaranteed."),
}

LIGHTS = {
    "bsp_light_sculpture": [{"hardpoint": "light", "type": 1, "rgb": (0.0050, 0.0033, 0.0016), "range": 10.0,
                             "constant": 0.0, "linear": 0.00195, "quadratic": 0.0, "flags": 0}],
}
