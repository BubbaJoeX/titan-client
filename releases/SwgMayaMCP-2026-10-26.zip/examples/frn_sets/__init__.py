"""Host-side halves of the themed furniture groups (the geometry is maya/swg_mcp/frn_groups/<group>.py). A group
module defines

  MATS    {key: (effect, texture builder, specular grey, power)}   like examples/frn_materials.MATS; builders
          return an (h, w, 4) uint8 RGBA array (top row first) and may use frn_materials' noise helpers
  INFO    {piece: (kind, name, description)}                       kind picks the stock template it derives from
  LIGHTS  {piece: [light, ...]}                                    lamps: iff._light_object fields + "hardpoint"

merge() folds them into frn_materials.MATS and make_furniture_sets' INFO / LIGHTS."""
from __future__ import annotations

import importlib
import sys
import traceback

GROUPS = ["hutt2", "imp2", "sith", "jedi", "nab", "wok", "bsp", "can", "veh"]
ERRORS = {}


def modules():
    ERRORS.clear()
    out = []
    for g in GROUPS:
        full = f"{__name__}.{g}"
        try:
            out.append(importlib.reload(sys.modules[full]) if full in sys.modules else importlib.import_module(full))
        except ModuleNotFoundError as e:
            ERRORS[g] = "missing" if e.name == full else repr(e)
        except Exception as e:                       # noqa: BLE001
            ERRORS[g] = traceback.format_exc(limit=-3)
    return out


def merge(mats=None, info=None, lights=None):
    for m in modules():
        if mats is not None:
            mats.update(getattr(m, "MATS", {}))
        if info is not None:
            info.update(getattr(m, "INFO", {}))
        if lights is not None:
            lights.update(getattr(m, "LIGHTS", {}))
