"""Host side of the second Hutt palace set (geometry: maya/swg_mcp/frn_groups/hutt2.py): the new materials,
names and descriptions, and the brazier's light. The pieces reuse the first set's hutt_* materials too."""
from __future__ import annotations

import math

import numpy as np

import frn_materials as fm


# ---------------------------------------------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------------------------------------------

def _cells(seed, g, n=fm.N):
    """Tileable jittered cells on a g x g grid: (distance to the nearest centre, to the second nearest, a random
    value per cell), distances in cell units."""
    r = np.random.default_rng(seed)
    pts = r.random((g, g, 2)).astype(np.float32)
    ids = r.random((g, g)).astype(np.float32)
    x, y = fm.coords(n)
    gx, gy = x * g, y * g
    ix, iy = np.floor(gx).astype(int), np.floor(gy).astype(int)
    d1 = np.full(x.shape, 9.0, np.float32)
    d2 = d1.copy()
    cid = np.zeros_like(x)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            cx, cy = ix + dx, iy + dy
            p = pts[cy % g, cx % g]
            d = np.hypot(gx - (cx + p[..., 0]), gy - (cy + p[..., 1]))
            closer = d < d1
            d2 = np.where(closer, d1, np.minimum(d2, d))
            cid = np.where(closer, ids[cy % g, cx % g], cid)
            d1 = np.where(closer, d, d1)
    return d1, d2, cid


def _seg(x, y, a, b, aspect=1.0):
    """Distance from each pixel to the segment a-b (texture units; x stretched by `aspect`)."""
    px, py = x * aspect, y
    ax, ay, bx, by = a[0] * aspect, a[1], b[0] * aspect, b[1]
    dx, dy = bx - ax, by - ay
    t = np.clip(((px - ax) * dx + (py - ay) * dy) / max(dx * dx + dy * dy, 1e-9), 0, 1)
    return np.hypot(px - ax - t * dx, py - ay - t * dy)


def _polar(x, y):
    dx, dy = x - 0.5, 0.5 - y
    return np.sqrt(dx * dx + dy * dy) * 2, np.arctan2(dy, dx), dx * 2, dy * 2


# ---------------------------------------------------------------------------------------------------------------
# materials
# ---------------------------------------------------------------------------------------------------------------

def hutt2_bronze():
    """Hammered bell bronze: every hammer facet catches the light a little differently, verdigris in patches."""
    d1, d2, cid = _cells(1101, 10)
    n = fm.fbm(1102, 4, 5)
    c = fm.mix(fm.col((92, 48, 20)), fm.col((214, 146, 70)), 0.35 + 0.35 * cid + 0.3 * n)
    edge = 1 - fm.smooth(0.0, 0.10, d2 - d1)
    c = c * (1 - 0.28 * edge)[..., None]
    patina = fm.smooth(0.66, 0.86, fm.fbm(1103, 6, 5))
    c = fm.mix(c, fm.col((64, 112, 92)), patina * 0.45)
    return fm.rgba(c, 0.8 - 0.5 * patina - 0.2 * edge)


def hutt2_gong():
    """The gong face (fit once): a turned polished boss, hammered field, an etched sunburst of 16 rays, a
    zig-zag Huttese band and studded rings toward the darkened rim."""
    x, y = fm.coords()
    d, a, _, _ = _polar(x, y)
    _, _, cid = _cells(1111, 20)
    n = fm.fbm(1112, 6, 5)
    c = fm.mix(fm.col((112, 60, 22)), fm.col((232, 166, 82)), 0.3 + 0.45 * cid + 0.25 * n)
    boss = 1 - fm.smooth(0.20, 0.22, d)
    turned = 0.82 + 0.18 * np.sin(d * 190)
    c = fm.mix(c, fm.col((246, 196, 116)) * turned[..., None], boss)
    etch = np.zeros_like(x)
    sector = (a / (math.pi / 8)) % 1.0
    k = np.floor(a / (math.pi / 8)).astype(int)
    ang = np.minimum(sector, 1 - sector) * (math.pi / 8) * d          # arc distance to the nearest ray line
    near_k = np.where(sector < 0.5, k, k + 1)
    reach = np.where(near_k % 2 == 0, 0.60, 0.47)
    wedge = (ang < 0.032 * (1 - (d - 0.26) / (reach - 0.26))) & (d > 0.26) & (d < reach)
    etch = np.maximum(etch, wedge.astype(np.float32))
    zig = 0.80 + 0.055 * (2 * np.abs((a * 24 / (2 * math.pi)) % 1.0 - 0.5) * 2 - 1)
    etch = np.maximum(etch, (np.abs(d - zig) < 0.009).astype(np.float32))
    for r0 in (0.72, 0.885):
        dots = (np.abs(d - r0) < 0.016) & (np.minimum((a * 36 / (2 * math.pi)) % 1.0, 1 - (a * 36 / (2 * math.pi)) % 1.0) < 0.18)
        etch = np.maximum(etch, dots.astype(np.float32))
    c = c * (1 - 0.5 * etch)[..., None]
    for r0, w in ((0.225, 0.010), (0.64, 0.008), (0.675, 0.008), (0.945, 0.012)):
        g = 1 - fm.smooth(w * 0.4, w, np.abs(d - r0))
        c = c * (1 - 0.6 * g)[..., None]
    c = c * (1 - 0.35 * fm.smooth(0.82, 1.0, d))[..., None]
    return fm.rgba(c, np.clip(0.72 + 0.25 * boss - 0.4 * etch, 0, 1))


def hutt2_sigil():
    """The Desilijic clan sigil (fit once): gold tusk-crescent, a slit eye and three drops on red enamel inside a
    gold ring."""
    x, y = fm.coords()
    r, a, dx, dy = _polar(x, y)
    c = fm.col((118, 16, 22)) * (0.85 + 0.25 * fm.fbm(1121, 8, 4))[..., None]
    gold = ((r > 0.86) & (r < 0.98)) | ((r > 0.78) & (r < 0.81))
    cres = (np.hypot(dx, dy + 0.06) < 0.60) & (np.hypot(dx, dy - 0.16) > 0.52) & (r < 0.76)
    eye = (np.abs(dx) / 0.16 + np.abs(dy - 0.10) / 0.24) < 1
    slit = (np.abs(dx) < 0.025) & (np.abs(dy - 0.10) < 0.17)
    drops = np.zeros_like(x, bool)
    for cx, cy in ((-0.17, -0.17), (0.0, -0.25), (0.17, -0.17)):
        drops |= np.hypot(dx - cx, dy - cy) < 0.055
    m = (gold | cres | (eye & ~slit) | drops).astype(np.float32)
    g = fm.mix(fm.col((176, 122, 40)), fm.col((246, 206, 112)), fm.fbm(1122, 6, 3))
    c = fm.mix(c, g, m)
    rim = (r > 0.98).astype(np.float32)
    c = fm.mix(c, fm.col((150, 104, 38)), rim)
    return fm.rgba(c, 0.35 + 0.55 * m)


def hutt2_hide():
    """Rancor hide: mottled grey-brown pebbled leather, deep wrinkles, pale old scars."""
    n = fm.fbm(1131, 4, 6)
    c = fm.mix(fm.col((92, 76, 58)), fm.col((160, 134, 100)), n)
    blot = fm.smooth(0.55, 0.72, fm.fbm(1132, 6, 4))
    c = fm.mix(c, fm.col((60, 48, 38)), blot * 0.55)
    d1, d2, cid = _cells(1133, 44)
    peb = fm.smooth(0.0, 0.14, d2 - d1)
    c = c * (0.78 + 0.26 * peb + 0.08 * cid)[..., None]
    wr = 1 - fm.smooth(0.0, 0.02, np.abs(fm.fbm(1134, 5, 4) - 0.5))
    c = c * (1 - 0.45 * wr)[..., None]
    sc = 1 - fm.smooth(0.0, 0.008, np.abs(fm.fbm(1135, 3, 3) - 0.5))
    c = fm.mix(c, fm.col((192, 172, 140)), sc * 0.55)
    return fm.rgba(c, np.clip(0.3 + 0.25 * peb - 0.2 * wr, 0, 1))


def hutt2_fire():
    """Flame tongue (self-lit, on closed flame meshes): white-hot at the root (v 0) through orange to deep red
    tips (v 1), with flickering vertical streaks."""
    x, y = fm.coords()
    v = 1 - y
    row = fm.fbm(1241, 16, 3)[0]
    n = fm.fbm(1242, 6, 4)
    heat = np.clip(1.08 - v * (0.95 + 0.5 * (row[None, :] - 0.5)) - 0.18 * (n - 0.5), 0, 1)
    c = fm.mix(fm.col((150, 16, 4)), fm.col((255, 112, 18)), fm.smooth(0.12, 0.5, heat))
    c = fm.mix(c, fm.col((255, 214, 90)), fm.smooth(0.5, 0.75, heat))
    c = fm.mix(c, fm.col((255, 248, 214)), fm.smooth(0.8, 1.0, heat))
    return fm.rgba(c)


def hutt2_carbonite():
    """Carbonite: dark grey-blue metal, mottled, with vertical frost streaks and frost specks."""
    x, y = fm.coords()
    n = fm.fbm(1151, 4, 6)
    c = fm.mix(fm.col((40, 48, 60)), fm.col((92, 104, 122)), n)
    row = fm.fbm(1152, 32, 4)[0]
    streak = fm.smooth(0.55, 0.80, row[None, :] * (0.7 + 0.6 * fm.fbm(1153, 2, 3)))
    c = fm.mix(c, fm.col((150, 168, 186)), streak * 0.28)
    speck = fm.smooth(0.80, 0.9, fm.fbm(1154, 128, 2))
    c = fm.mix(c, fm.col((222, 234, 242)), speck * 0.6)
    ripple = 0.5 + 0.5 * np.sin((y * 6 + n * 1.5) * 2 * math.pi)
    c = c * (0.93 + 0.1 * ripple)[..., None]
    return fm.rgba(c, np.clip(0.75 - 0.4 * streak, 0, 1))


def hutt2_carbon_panel():
    """Carbonite chamber side panel (fit once, self-lit): bevelled plate, a readout bar and rows of red, amber and
    green indicator lamps."""
    x, y = fm.coords()
    seam, light = fm.bevel_panels(x, y, 1, 1, 0.03)
    c = fm.col((58, 62, 70)) * (0.9 + 0.15 * fm.fbm(1161, 8, 3))[..., None]
    c = c * (1 - 0.6 * seam)[..., None] * (1 + 0.3 * light)[..., None]
    bar = (x > 0.18) & (x < 0.82) & (y > 0.10) & (y < 0.20)
    c = fm.mix(c, fm.col((16, 40, 30)), bar.astype(np.float32))
    c = fm.mix(c, fm.col((90, 255, 160)), (bar & (x < 0.62) & (((x * 30) % 1.0) < 0.6)).astype(np.float32))
    r = np.random.default_rng(1162)
    pal = [(255, 40, 30), (255, 170, 30), (60, 255, 90), (40, 40, 44)]
    for i in range(3):
        for j in range(8):
            cx, cy = 0.25 + 0.25 * i, 0.30 + 0.085 * j
            lamp = (np.abs(x - cx) < 0.07) & (np.abs(y - cy) < 0.022)
            c = fm.mix(c, fm.col(pal[int(r.integers(0, 4))]), lamp.astype(np.float32))
    return fm.rgba(c)


def hutt2_plaque():
    """Engraved brass plaque (fit once on a wide plate): raised border and a line of Huttese glyphs."""
    x, y = fm.coords()
    c = fm.mix(fm.col((158, 110, 42)), fm.col((240, 198, 110)), 0.4 + 0.5 * fm.fbm(1171, 4, 4))
    edge = np.minimum(np.minimum(x, 1 - x) * 5, np.minimum(y, 1 - y))
    c = c * (1 + 0.15 * (edge < 0.08))[..., None]
    c = c * (1 - 0.45 * ((edge > 0.09) & (edge < 0.115)))[..., None]
    r = np.random.default_rng(1172)
    ink = np.zeros_like(x)
    k = 0
    for cx in np.arange(0.11, 0.90, 0.052):
        k += 1
        if k % 6 == 0:
            continue
        segs = [((0.0, -1.0), (0.0, 1.0)), ((-1.0, 1.0), (1.0, 1.0)), ((-1.0, 0.0), (1.0, 0.0)), ((-1.0, -1.0), (1.0, 1.0)),
                ((-1.0, 1.0), (1.0, -1.0)), ((1.0, -1.0), (1.0, 1.0)), ((-1.0, -1.0), (-1.0, 1.0)), ((-1.0, -1.0), (1.0, -1.0))]
        for s in r.choice(len(segs), 3, replace=False):
            (ax, ay), (bx, by) = segs[s]
            d = _seg(x, y, (cx + ax * 0.016, 0.5 + ay * 0.2), (cx + bx * 0.016, 0.5 + by * 0.2), aspect=5.0)
            ink = np.maximum(ink, 1 - fm.smooth(0.012, 0.022, d))
    c = c * (1 - 0.55 * ink)[..., None]
    return fm.rgba(c, 0.85 - 0.5 * ink)


def hutt2_coins():
    """A heap of peggats: overlapping gold coins, each with a rim, an embossed centre and its own tilt."""
    N = fm.N
    r = np.random.default_rng(1181)
    c = fm.col((120, 82, 26)) * (0.7 + 0.4 * fm.fbm(1182, 16, 3))[..., None]
    alpha = np.full((N, N), 0.35, np.float32)
    for _ in range(420):
        cx, cy = r.random() * N, r.random() * N
        rad = (0.034 + 0.014 * r.random()) * N
        th, sq, tone = r.random() * math.pi, 0.72 + 0.28 * r.random(), 0.8 + 0.4 * r.random()
        R = int(rad) + 2
        ys, xs = np.arange(int(cy) - R, int(cy) + R + 1), np.arange(int(cx) - R, int(cx) + R + 1)
        yy, xx = np.meshgrid(ys, xs, indexing="ij")
        dx, dy = xx - cx, yy - cy
        u = dx * math.cos(th) + dy * math.sin(th)
        v = (-dx * math.sin(th) + dy * math.cos(th)) / sq
        d = np.sqrt(u * u + v * v) / rad
        m = d < 1
        if not m.any():
            continue
        shade = 0.85 + 0.25 * np.clip(-(dx + dy) / (rad * 1.4), -1, 1)
        coin = 0.85 * tone * shade
        coin = coin * (1 - 0.45 * ((d > 0.78) & (d < 0.88))) * (1 + 0.18 * (d < 0.42)) * (1 - 0.5 * (d > 0.94))
        col = np.array([238, 186, 84], np.float32) / 255 * coin[..., None]
        iy, ix = yy % N, xx % N
        sub = c[iy, ix]
        sub[m] = col[m]
        c[iy, ix] = sub
        sa = alpha[iy, ix]
        sa[m] = 0.9 - 0.3 * ((d[m] > 0.8) & (d[m] < 0.88))
        alpha[iy, ix] = sa
    return fm.rgba(c, alpha)


def hutt2_gold():
    """Bullion gold: bright, brushed, faintly mottled."""
    row = fm.fbm(1191, 64, 3)[0]
    n = fm.fbm(1192, 4, 4)
    c = fm.mix(fm.col((180, 122, 30)), fm.col((255, 218, 116)), np.clip(0.45 + 0.35 * n + 0.4 * (row[None, :] - 0.5), 0, 1))
    return fm.rgba(c, 0.92)


def _gem(rgb, seed):
    """Cut gemstone: facets (bands across u) of different brightness, glints toward the tip."""
    x, y = fm.coords()
    r = np.random.default_rng(seed)
    tone = r.random(16).astype(np.float32)[(np.floor(x * 16) % 16).astype(int)]
    c = fm.col(rgb) * (0.35 + 0.9 * tone)[..., None] * (0.75 + 0.4 * (1 - y))[..., None]
    glint = fm.smooth(0.86, 0.95, fm.fbm(seed + 1, 16, 2)) * (tone > 0.6)
    c = fm.mix(c, fm.col((255, 255, 255)), glint)
    return fm.rgba(c, 0.95)


def hutt2_credit_chip():
    """Credit chip (fit once on its face): blue-black card, gold edge, gold contact block, silver data stripe."""
    x, y = fm.coords()
    c = fm.col((34, 40, 66)) * (0.9 + 0.2 * fm.fbm(1201, 8, 3))[..., None]
    edge = np.minimum(np.minimum(x, 1 - x), np.minimum(y, 1 - y))
    c = fm.mix(c, fm.col((230, 182, 80)), (edge < 0.07).astype(np.float32))
    contact = (x > 0.14) & (x < 0.40) & (y > 0.28) & (y < 0.72)
    c = fm.mix(c, fm.col((236, 196, 98)), contact.astype(np.float32))
    c = c * (1 - 0.4 * (contact & ((np.abs(((x - 0.14) * 16) % 1.0 - 0.5) < 0.08) | (np.abs(y - 0.5) < 0.012))))[..., None]
    stripe = (x > 0.48) & (x < 0.88) & (np.abs(y - 0.38) < 0.06)
    c = fm.mix(c, fm.col((200, 206, 214)), stripe.astype(np.float32))
    c = fm.mix(c, fm.col((255, 60, 40)), fm.disc_mask(x, y, 0.80, 0.70, 0.04, 0.01))
    return fm.rgba(c, 0.4 + 0.5 * (edge < 0.07) + 0.4 * contact)


def hutt2_socket():
    """The dark inside of an eye socket (or a keyhole)."""
    c = fm.col((30, 20, 14)) * (0.6 + 0.6 * fm.fbm(1211, 4, 4))[..., None]
    return fm.rgba(c)


MATS = {
    "hutt2_bronze": ("a_specmap", hutt2_bronze, 0.75, 30),
    "hutt2_gong": ("a_specmap", hutt2_gong, 0.8, 35),
    "hutt2_sigil": ("a_specmap", hutt2_sigil, 0.7, 30),
    "hutt2_hide": ("a_specmap", hutt2_hide, 0.3, 14),
    "hutt2_fire": ("a_emis_full", hutt2_fire, 0, 0),
    "hutt2_carbonite": ("a_specmap", hutt2_carbonite, 0.65, 40),
    "hutt2_carbon_panel": ("a_emis_full", hutt2_carbon_panel, 0, 0),
    "hutt2_plaque": ("a_specmap", hutt2_plaque, 0.7, 30),
    "hutt2_coins": ("a_specmap", hutt2_coins, 0.8, 30),
    "hutt2_gold": ("a_specmap", hutt2_gold, 0.85, 40),
    "hutt2_gem_ruby": ("a_specmap", lambda: _gem((200, 20, 40), 1221), 1.0, 60),
    "hutt2_gem_emerald": ("a_specmap", lambda: _gem((20, 170, 70), 1223), 1.0, 60),
    "hutt2_gem_sapphire": ("a_specmap", lambda: _gem((30, 70, 210), 1225), 1.0, 60),
    "hutt2_credit_chip": ("a_specmap", hutt2_credit_chip, 0.6, 30),
    "hutt2_socket": ("a_simple", hutt2_socket, 0, 0),
}

INFO = {
    "hutt_gong": ("interact", "Hutt Palace Gong",
                  "The great bronze gong of a Hutt audience chamber, hung on chains from a tusk-horned frame under the "
                  "clan sigil. Step up and strike it: nothing announces that His Excellency is ready to receive "
                  "visitors (or to feed them to something) quite like it."),
    "hutt_rancor_chaise": ("seat", "Rancor-Hide Chaise",
                           "A lounging chaise upholstered in genuine rancor hide, its scrolled end held aloft by the "
                           "beast's own tusks. The previous owner of the hide has no further use for it."),
    "hutt_brazier": ("lamp", "Hutt Palace Brazier",
                     "A towering brass tripod brazier: a sunburst bowl of glowing coals, chain swags and dancing "
                     "flames to light the audience chamber a flattering shade of menace."),
    "hutt_carbonite_slab": ("decor", "Smuggler in Carbonite",
                            "A smuggler frozen in carbonite, hands raised in protest, displayed on an ornate stand. "
                            "The side panels still blink: he is in perfect hibernation. The plaque reads, roughly, "
                            "'Overdue'."),
    "hutt_rancor_skull": ("decor", "Rancor Skull Trophy",
                          "The skull of a palace rancor, jaws agape, mounted on a carved sandstone plinth with a brass "
                          "plaque. A reminder to every guest that the pit below the throne is always hungry."),
    "hutt_treasure_chest": ("decor", "Hutt Treasure Chest",
                            "A carved chest thrown open on a hoard of peggats, gold bars, credit chips and gems, a "
                            "jewelled crown on top and a pearl rope trailing over the rim. Petty cash, by Hutt "
                            "standards."),
}

LIGHTS = {
    "hutt_brazier": [{"hardpoint": "light", "type": 1, "rgb": (0.0050, 0.0030, 0.0012), "range": 10.0, "constant": 0.0,
                      "linear": 0.00195, "quadratic": 0.0, "flags": 0}],
}
