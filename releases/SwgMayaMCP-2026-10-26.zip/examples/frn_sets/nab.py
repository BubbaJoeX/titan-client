"""Host side of the Naboo royal group (geometry: maya/swg_mcp/frn_groups/nab.py): Theed palace materials
(cream marble, gilded filigree, damask silk, teal brocade, porcelain, frosted glass, Naboo blooms, a painted
panorama for the folding screen), names and descriptions, the globe lamp's light."""
from __future__ import annotations

import math

import numpy as np

import frn_materials as fm

TAU = 2 * math.pi


def _rgb(c):
    return fm.col(c)


# ---------------------------------------------------------------------------------------------------------------
# stone, metal, fabric
# ---------------------------------------------------------------------------------------------------------------

def nab_marble():
    """Polished cream Theed marble: soft cloudy body, grey drift veins and a few thin gold veins."""
    x, y = fm.coords()
    n = fm.fbm(601, 4, 6)
    warp = fm.fbm(602, 2, 4)
    v1 = np.abs(np.sin((2 * x + y + 2.2 * warp) * TAU))
    vein = 1 - fm.smooth(0.0, 0.07, v1)
    v2 = np.abs(fm.fbm(603, 4, 5) - 0.5)
    vein2 = 1 - fm.smooth(0.0, 0.018, v2)
    c = fm.mix(_rgb((232, 224, 208)), _rgb((250, 247, 240)), n * 1.2 - 0.1)
    c = fm.mix(c, _rgb((190, 182, 168)), vein * (0.25 + 0.3 * fm.fbm(604, 8, 3)))
    c = fm.mix(c, _rgb((212, 172, 96)), vein2 * 0.55)
    return fm.rgba(c, 0.55 + 0.25 * n - 0.15 * vein)


def nab_gold():
    """Gilded metal with engraved filigree scrolls (tileable), bright burnished highlights."""
    x, y = fm.coords()
    n = fm.fbm(611, 4, 5)
    c = fm.mix(_rgb((170, 120, 40)), _rgb((252, 212, 116)), 0.3 + 0.6 * n)
    s1 = np.sin(x * TAU * 4 + np.sin(y * TAU * 4) * 1.7)
    s2 = np.sin(y * TAU * 4 + np.cos(x * TAU * 4) * 1.7)
    eng = np.maximum(1 - fm.smooth(0.0, 0.10, np.abs(s1)), 0.7 * (1 - fm.smooth(0.0, 0.10, np.abs(s2))))
    dots = (np.sin(x * TAU * 32) * np.sin(y * TAU * 32) > 0.92).astype(np.float32)
    c = c * (1 - 0.3 * eng - 0.15 * dots)[..., None]
    c = fm.mix(c, _rgb((255, 240, 186)), fm.smooth(0.62, 0.9, n) * 0.45)
    return fm.rgba(c, 0.92 - 0.4 * eng)


def _damask(x, y, rep=4):
    """Tone-on-tone damask mask: lobed medallions on a half-drop lattice with little diamonds between."""
    out = np.zeros_like(x)
    for ox, oy in ((0.0, 0.0), (0.5, 0.5)):
        u = (x * rep + ox) % 1.0 - 0.5
        v = (y * rep + oy) % 1.0 - 0.5
        r = np.sqrt(u * u + v * v * 0.8)
        a = np.arctan2(v, u)
        petals = (r < 0.17 + 0.10 * np.abs(np.cos(a * 2)) ** 0.8) & (r > 0.045)
        ring = np.abs(r - 0.33) < 0.012
        out = np.maximum(out, petals.astype(np.float32) + 0.6 * ring)
    for ox, oy in ((0.5, 0.0), (0.0, 0.5)):
        u = (x * rep + ox) % 1.0 - 0.5
        v = (y * rep + oy) % 1.0 - 0.5
        out = np.maximum(out, ((np.abs(u) + np.abs(v)) < 0.07).astype(np.float32))
    return np.clip(out, 0, 1)


def nab_silk():
    """Cream silk damask: glossy woven motif on a matte satin ground."""
    x, y = fm.coords()
    m = _damask(x, y)
    weave = 0.5 + 0.5 * np.sin(y * fm.N * math.pi * 0.5)
    c = fm.mix(_rgb((226, 212, 184)), _rgb((246, 238, 220)), m)
    c = c * (0.95 + 0.04 * weave + 0.05 * fm.fbm(621, 16, 3))[..., None]
    return fm.rgba(c, 0.25 + 0.5 * m)


def nab_brocade():
    """Theed teal brocade: deep verdigris silk with a gold floral repeat and narrow gold stripes."""
    x, y = fm.coords()
    m = _damask(x, y, rep=3)
    stripe = (np.abs(((x * 6) % 1.0) - 0.5) > 0.47).astype(np.float32)
    c = _rgb((28, 96, 100)) * (0.85 + 0.25 * fm.fbm(631, 16, 3))[..., None]
    c = fm.mix(c, _rgb((60, 140, 140)), 0.3 * (0.5 + 0.5 * np.sin(y * fm.N * math.pi * 0.5)))
    gold = np.maximum(m, stripe)
    c = fm.mix(c, _rgb((226, 182, 92)), gold * 0.9)
    return fm.rgba(c, 0.3 + 0.55 * gold)


def nab_porcelain():
    """Fine Naboo porcelain: glazed white with scattered painted sprigs (blue blossoms, rose buds, green leaves)."""
    x, y = fm.coords()
    c = _rgb((247, 245, 240)) * (0.975 + 0.035 * fm.fbm(641, 4, 3))[..., None]
    r = np.random.default_rng(642)
    for k in range(26):
        cx, cy = r.random(), r.random()
        col = ((84, 116, 190), (214, 120, 150), (110, 160, 110))[k % 3]
        for j in range(5 if k % 3 < 2 else 2):
            a = TAU * j / 5 + r.random()
            dx, dy = 0.012 * math.cos(a), 0.012 * math.sin(a)
            c = fm.mix(c, _rgb(col), fm.disc_mask(x, y, (cx + dx) % 1, (cy + dy) % 1, 0.008, 0.003) * 0.85)
        c = fm.mix(c, _rgb((222, 180, 80)), fm.disc_mask(x, y, cx, cy, 0.004, 0.002))
    return fm.rgba(c, 0.85)


def nab_glass():
    """Frosted lamp glass (a_alpha_emis_full): warm milky glow, a faint etched lattice, alpha = brightness."""
    x, y = fm.coords()
    n = fm.fbm(651, 8, 4)
    etch = np.maximum(fm.lines(x, 1 / 8, 0.004), fm.lines(y, 1 / 6, 0.004))
    c = fm.mix(_rgb((255, 222, 168)), _rgb((255, 246, 228)), n)
    c = fm.mix(c, _rgb((255, 252, 244)), etch * 0.7)
    return fm.rgba(c, 0.22 + 0.16 * n + 0.18 * etch)


def nab_glow():
    """The lamp core seen through the frosted glass (a_emis_full): warm candle gold, brightest round the equator."""
    x, y = fm.coords()
    n = fm.fbm(652, 4, 3)
    glow = 0.5 + 0.5 * np.cos((y - 0.5) * math.pi)                # brighter round the equator band
    c = fm.mix(_rgb((236, 150, 70)), _rgb((255, 214, 150)), 0.35 * n + 0.65 * glow)
    return fm.rgba(c)


# ---------------------------------------------------------------------------------------------------------------
# flowers, food, linens
# ---------------------------------------------------------------------------------------------------------------

def _petals(seed, base, edge, heart):
    """Bloom texture for the rosette mesh: v 0..0.25 green calyx, 0.25..0.75 petals (lighter toward the rim at
    v 0.5), 0.75..1 the deeper heart; fine veins along v."""
    x, y = fm.coords()
    v = 1 - y
    n = fm.fbm(seed, 8, 4)
    rim = np.exp(-((v - 0.5) / 0.07) ** 2)
    c = fm.mix(_rgb(base), _rgb(edge), rim * 0.8)
    c = fm.mix(c, _rgb(heart), fm.smooth(0.70, 0.92, v))
    c = fm.mix(c, _rgb((84, 128, 60)), 1 - fm.smooth(0.18, 0.27, v))
    veins = (np.abs(((x * 40) % 1.0) - 0.5) < 0.06).astype(np.float32) * (1 - rim) * 0.12
    c = c * (0.92 + 0.12 * n - veins)[..., None]
    return fm.rgba(c, 0.25 + 0.2 * rim)


def nab_bloom():
    return _petals(661, (232, 120, 152), (255, 214, 226), (190, 52, 96))


def nab_bloom2():
    return _petals(662, (156, 128, 214), (226, 214, 250), (100, 70, 170))


def nab_bloom3():
    return _petals(663, (248, 240, 226), (255, 255, 252), (240, 196, 120))


def nab_leaf():
    """Leaves, vines and moss: fresh green with a pale midrib (u 0.25 / 0.75 on the leaf mesh) and soft veins."""
    x, y = fm.coords()
    n = fm.fbm(671, 8, 5)
    c = fm.mix(_rgb((52, 104, 44)), _rgb((112, 160, 72)), n)
    rib = np.maximum(np.exp(-((x - 0.25) / 0.02) ** 2), np.exp(-((x - 0.75) / 0.02) ** 2))
    vein = (np.abs(((x * 4 + y * 6) % 1.0) - 0.5) < 0.03).astype(np.float32) * 0.15
    c = fm.mix(c, _rgb((176, 206, 120)), rib * 0.6 + vein)
    return fm.rgba(c, 0.35 + 0.2 * n)


def nab_pollen():
    x, y = fm.coords()
    n = fm.fbm(672, 32, 3)
    c = fm.mix(_rgb((230, 160, 40)), _rgb((255, 226, 90)), n)
    return fm.rgba(c, 0.3)


def _icing(seed, rgb):
    x, y = fm.coords()
    n = fm.fbm(seed, 8, 4)
    c = _rgb(rgb) * (0.94 + 0.1 * n)[..., None]
    drizzle = (np.abs(np.sin((x * 3 + 0.15 * np.sin(y * TAU * 5)) * TAU)) < 0.12).astype(np.float32)
    c = fm.mix(c, _rgb((255, 250, 244)), drizzle * 0.8)
    return fm.rgba(c, 0.6 + 0.3 * drizzle)


def nab_cake():
    return _icing(681, (240, 168, 186))


def nab_cake2():
    return _icing(682, (176, 214, 150))


def nab_tea():
    x, y = fm.coords()
    n = fm.fbm(683, 4, 3)
    c = fm.mix(_rgb((120, 56, 18)), _rgb((176, 94, 34)), n)
    return fm.rgba(c, 0.9)


def nab_lace():
    """Round lace doily (fit on a disc, a_alpha): petal rings, picot edge, open-work holes."""
    x, y = fm.coords()
    dx, dy = x - 0.5, y - 0.5
    r = np.sqrt(dx * dx + dy * dy) * 2
    a = np.arctan2(dy, dx)
    edge = 0.93 + 0.05 * np.abs(np.cos(a * 18))
    solid = r < edge
    holes = (np.abs(np.sin(a * 24)) > 0.55) & (np.abs(r - 0.78) < 0.06)
    holes |= (np.abs(np.sin(a * 12 + r * 6)) > 0.8) & (r > 0.25) & (r < 0.62)
    holes |= (np.abs(r - 0.18) < 0.025)
    petals = (r < 0.14 + 0.06 * np.abs(np.cos(a * 4)))
    m = solid & ~holes | petals
    thread = 0.9 + 0.1 * np.sin(a * 120) * np.sin(r * 90)
    c = _rgb((252, 248, 238)) * thread[..., None]
    return fm.rgba(c, m.astype(np.float32) * 0.95)


# ---------------------------------------------------------------------------------------------------------------
# folding screen: a Theed panorama across the four front panels (u quarters), damask medallions on the back
# ---------------------------------------------------------------------------------------------------------------

def _quarters_border(x, v):
    q = (x * 4) % 1.0
    outer = (np.minimum(q, 1 - q) < 0.035) | (v < 0.012) | (v > 0.988)
    inner = (np.abs(np.minimum(q, 1 - q) - 0.07) < 0.008) | (np.abs(v - 0.035) < 0.003) | (np.abs(v - 0.965) < 0.003)
    return outer.astype(np.float32), inner.astype(np.float32)


def nab_panel():
    """Painted silk: Theed at sunset across the four panels (u quarters; world 1.9 m wide x 1.3 m tall). Panel 1
    and 4: cliffs with waterfalls and domed pavilions, blossom branches from the top corners; panel 2: the Royal
    Palace under its great verdigris dome; panel 3: the colonnade wing and a slender tower against the setting
    sun; the river below mirrors it all. Main motifs sit inside a panel so no hinge cuts them."""
    x, y = fm.coords()
    v = 1 - y
    AX, AY = 1.92, 1.30
    N = fm.N
    stretch = (np.arange(N) * 0.25).astype(int)

    def ell(cx, cv, rx_m, rv_m=None):                 # inside an ellipse given in metres
        rv_m = rx_m if rv_m is None else rv_m
        return (((x - cx) * AX / rx_m) ** 2 + ((v - cv) * AY / rv_m) ** 2) < 1.0

    def rect(x0, x1, v0, v1):
        return (x > x0) & (x < x1) & (v > v0) & (v < v1)

    def arches(x0, x1, v0, v1, period, frac=0.45):
        """A row of arched openings between x0..x1, bottom v0, spring v1 - half width."""
        q = ((x - x0) / period) % 1.0
        hw = frac * 0.5
        w_m = period * frac * AX * 0.5
        top = v1 - w_m / AY
        body = (np.abs(q - 0.5) < hw) & (v > v0) & (v < top)
        cap = (((q - 0.5) * period * AX) ** 2 + ((v - top) * AY) ** 2 < w_m ** 2) & (v >= top)
        return (body | cap) & (x > x0) & (x < x1)

    # sunset sky with streaky lit clouds and the sun low over panel 3
    c = fm.mix(_rgb((255, 206, 150)), _rgb((246, 182, 178)), fm.smooth(0.34, 0.62, v))
    c = fm.mix(c, _rgb((150, 168, 222)), fm.smooth(0.6, 1.0, v))
    streak = fm.fbm(691, 4, 5)[stretch]
    clouds = fm.smooth(0.52, 0.72, streak) * fm.smooth(0.45, 0.7, v)
    c = fm.mix(c, fm.mix(_rgb((255, 228, 214)), _rgb((236, 150, 150)), fm.smooth(0.6, 0.9, v)), clouds * 0.7)
    sd = np.sqrt(((x - 0.63) * AX) ** 2 + ((v - 0.40) * AY) ** 2)
    c = c + _rgb((255, 190, 110)) * (np.clip(0.30 - sd, 0, 1) * 1.2)[..., None]
    c = fm.mix(c, _rgb((255, 246, 214)), fm.smooth(0.065, 0.055, sd))
    # far lavender mountains and nearer blue-green hills
    ridge = 0.43 + 0.05 * np.sin(x * TAU * 1.0 + 1.3) + 0.03 * np.sin(x * TAU * 3.0) + 0.025 * (fm.fbm(692, 8, 3) - 0.5)
    c = fm.mix(c, _rgb((178, 164, 204)), (v < ridge).astype(np.float32) * 0.85)
    ridge2 = 0.33 + 0.035 * np.sin(x * TAU * 2.0 + 2.0) + 0.02 * (fm.fbm(693, 16, 3) - 0.5)
    c = fm.mix(c, _rgb((118, 146, 150)), (v < ridge2).astype(np.float32))
    # cliffs with waterfalls and a domed pavilion on each (panels 1 and 4)
    rockn = fm.fbm(695, 16, 4)
    for cx, sg in ((0.075, 1), (0.925, -1)):
        d = (x - cx) * sg                                # >0 toward the middle
        edge = 0.64 - 2.2 * np.maximum(0.0, d - 0.05) ** 1.3 + 0.03 * (rockn - 0.5)
        cliff = (v < edge) & (d > -0.2)
        rock = fm.mix(_rgb((160, 146, 130)), _rgb((112, 120, 104)), rockn)
        rock = rock * (0.85 + 0.25 * fm.smooth(-0.05, 0.06, d))[..., None]
        c = fm.mix(c, rock, cliff.astype(np.float32))
        moss = cliff & (v > edge - 0.025)
        c = fm.mix(c, _rgb((96, 140, 80)), moss.astype(np.float32))
        for k, off in enumerate((-0.03, 0.0, 0.025)):
            fx = cx + sg * (0.07 + off)
            ftop = 0.60 - 2.2 * max(0.0, 0.07 + off - 0.05) ** 1.3 - 0.02
            fall = (np.abs(x - fx) < 0.008 + 0.004 * k) & (v < ftop) & (v > 0.10)
            sheen = 0.82 + 0.18 * np.sin(x * N * 2.1 + v * 9) * fm.fbm(696 + k, 32, 2)
            c = fm.mix(c, _rgb((238, 246, 252)) * sheen[..., None], fall.astype(np.float32) * 0.92)
            mist = np.exp(-((v - 0.11) / 0.035) ** 2) * np.exp(-((x - fx) / 0.03) ** 2)
            c = fm.mix(c, _rgb((252, 252, 255)), mist * 0.85)
        px = cx - sg * 0.005
        pv = 0.64
        c = fm.mix(c, _rgb((240, 230, 210)), rect(px - 0.02, px + 0.02, pv - 0.01, pv + 0.035).astype(np.float32))
        c = fm.mix(c, _rgb((70, 140, 128)), (ell(px, pv + 0.035, 0.035) & (v > pv + 0.035)).astype(np.float32))
        c = fm.mix(c, _rgb((120, 96, 80)), arches(px - 0.016, px + 0.016, pv - 0.005, pv + 0.03, 0.011, 0.5).astype(np.float32))
    # the Royal Palace (panel 2): a colonnaded base, a drum with windows, the great dome, side domes
    cream, shade = _rgb((242, 230, 208)), _rgb((206, 186, 162))
    lit = fm.smooth(0.30, 0.46, x)[..., None]
    pal = rect(0.29, 0.46, 0.17, 0.33)
    c = fm.mix(c, cream * (0.86 + 0.14 * lit), pal.astype(np.float32))
    c = fm.mix(c, shade * 0.75, (arches(0.295, 0.455, 0.19, 0.29, 0.016, 0.5)).astype(np.float32))
    c = fm.mix(c, _rgb((226, 186, 96)), (rect(0.29, 0.46, 0.325, 0.334) | rect(0.29, 0.46, 0.17, 0.176)).astype(np.float32))
    drum = rect(0.335, 0.415, 0.33, 0.40)
    c = fm.mix(c, cream * (0.86 + 0.14 * lit), drum.astype(np.float32))
    c = fm.mix(c, shade * 0.7, arches(0.34, 0.41, 0.345, 0.39, 0.012, 0.5).astype(np.float32))
    dome = ell(0.375, 0.40, 0.085, 0.11) & (v > 0.40)
    dsh = 0.7 + 0.45 * np.clip((x - 0.33) / 0.09, 0, 1)
    c = fm.mix(c, _rgb((82, 150, 136)) * dsh[..., None], dome.astype(np.float32))
    ribs = dome & (np.abs(np.sin((x - 0.375) * AX / 0.085 * 2.2)) < 0.12)
    c = fm.mix(c, _rgb((226, 188, 98)), ribs.astype(np.float32) * 0.8)
    c = fm.mix(c, _rgb((236, 196, 104)), (rect(0.372, 0.378, 0.485, 0.55) | ell(0.375, 0.556, 0.008)).astype(np.float32))
    for tx in (0.30, 0.45):
        c = fm.mix(c, cream * (0.86 + 0.14 * lit), rect(tx - 0.012, tx + 0.012, 0.30, 0.39).astype(np.float32))
        c = fm.mix(c, _rgb((82, 150, 136)), (ell(tx, 0.39, 0.026, 0.034) & (v > 0.39)).astype(np.float32))
        c = fm.mix(c, _rgb((236, 196, 104)), rect(tx - 0.002, tx + 0.002, 0.415, 0.44).astype(np.float32))
    # panel 3: the colonnade wing, a balustrade, the slender tower against the sun
    wing = rect(0.46, 0.73, 0.17, 0.27)
    c = fm.mix(c, cream * (0.9 + 0.1 * lit), wing.astype(np.float32))
    c = fm.mix(c, shade * 0.72, arches(0.465, 0.725, 0.185, 0.25, 0.014, 0.55).astype(np.float32))
    c = fm.mix(c, _rgb((226, 186, 96)), rect(0.46, 0.73, 0.265, 0.273).astype(np.float32))
    bal = rect(0.46, 0.73, 0.273, 0.29) & (np.abs(((x * 220) % 1.0) - 0.5) < 0.22)
    c = fm.mix(c, cream, bal.astype(np.float32))
    c = fm.mix(c, cream * 0.95, rect(0.615, 0.655, 0.27, 0.56).astype(np.float32))
    c = fm.mix(c, shade * 0.7, arches(0.62, 0.65, 0.40, 0.47, 0.03, 0.4).astype(np.float32))
    c = fm.mix(c, _rgb((226, 186, 96)), rect(0.613, 0.657, 0.555, 0.565).astype(np.float32))
    c = fm.mix(c, _rgb((82, 150, 136)), (ell(0.635, 0.565, 0.04, 0.06) & (v > 0.565)).astype(np.float32))
    c = fm.mix(c, _rgb((236, 196, 104)), rect(0.633, 0.637, 0.60, 0.66).astype(np.float32))
    # trees along the bank, cypresses by the palace
    bank = (v > 0.12) & (v < 0.17 + 0.05 * fm.fbm(697, 32, 3)) & (np.abs(x - 0.5) < 0.38)
    c = fm.mix(c, fm.mix(_rgb((60, 104, 60)), _rgb((116, 160, 86)), fm.fbm(698, 32, 3)), bank.astype(np.float32))
    for tx in (0.27, 0.48, 0.58, 0.75):
        cyp = ell(tx, 0.20, 0.016, 0.10) & (v > 0.12)
        c = fm.mix(c, _rgb((48, 90, 56)) * (0.85 + 0.3 * fm.smooth(tx - 0.008, tx + 0.008, x))[..., None], cyp.astype(np.float32))
    # the river mirrors the sky, ripples and a sun glitter path
    river = v < 0.125
    mirror = fm.mix(_rgb((180, 160, 190)), _rgb((120, 150, 190)), fm.smooth(0.0, 0.125, v))
    ripple = 0.88 + 0.12 * np.sin(v * N * 1.4 + 2 * np.sin(x * TAU * 10))
    glitter = np.exp(-((x - 0.63) / 0.03) ** 2) * (np.sin(v * N * 1.4 + x * 40) > 0.3) * 0.6
    water = mirror * ripple[..., None] + _rgb((255, 220, 160)) * glitter[..., None]
    c = fm.mix(c, water, river.astype(np.float32))
    # blossom branches from the top corners, birds
    for ox, sg, seed in ((0.0, 1, 699), (1.0, -1, 700)):
        t = np.clip((x - ox) * sg, 0, 0.4)
        bline = 0.97 - 0.85 * t * t - 0.10 * t
        branch = (np.abs(v - bline) < 0.004 + 0.008 * (0.4 - t)) & ((x - ox) * sg < 0.30)
        twig = (np.abs(v - (bline - 0.6 * (t - 0.12))) < 0.003) & ((x - ox) * sg > 0.12) & ((x - ox) * sg < 0.2)
        c = fm.mix(c, _rgb((84, 58, 46)), (branch | twig).astype(np.float32))
        r = np.random.default_rng(seed)
        for k in range(60):
            tt = r.random() * 0.30
            bx = ox + sg * tt
            by = 0.97 - 0.85 * tt * tt - 0.10 * tt + (r.random() - 0.5) * 0.07
            rad = 0.008 + 0.008 * r.random()
            col = ((248, 176, 200), (255, 230, 238), (236, 136, 172))[k % 3]
            dd = np.sqrt(((x - bx) * AX) ** 2 + ((v - by) * AY) ** 2)
            c = fm.mix(c, _rgb(col), fm.smooth(rad, rad * 0.55, dd))
    r = np.random.default_rng(701)
    for k in range(10):
        bx, by = 0.2 + 0.6 * r.random(), 0.62 + 0.25 * r.random()
        dx = (x - bx) * AX
        wing_ = np.abs((v - by) * AY - 0.45 * np.abs(dx)) < 0.003
        c = fm.mix(c, _rgb((92, 76, 96)), (wing_ & (np.abs(dx) < 0.014)).astype(np.float32))
    c = c * (0.95 + 0.07 * fm.fbm(702, 64, 2))[..., None]
    outer, inner = _quarters_border(x, v)
    c = fm.mix(c, _rgb((214, 170, 82)), np.maximum(outer, inner))
    return fm.rgba(c)


def nab_panel_back():
    """The back of the screen: cream damask silk, a gilded border and a royal medallion on each panel."""
    x, y = fm.coords()
    v = 1 - y
    m = _damask(x, y * 0.7, rep=8)
    c = fm.mix(_rgb((226, 212, 184)), _rgb((244, 236, 218)), m)
    q = (x * 4) % 1.0
    dx = (q - 0.5) * 0.48
    for cy, R in ((0.62, 0.11), (0.26, 0.05)):
        dy = (v - cy) * 1.30
        r = np.sqrt(dx * dx + dy * dy)
        a = np.arctan2(dy, dx)
        ring = np.abs(r - R) < 0.006
        rays = (r < R * 0.85) & (r > R * 0.25) & (np.abs(np.sin(a * 8)) < 0.35 + 0.4 * (1 - r / R))
        hub = r < R * 0.22
        c = fm.mix(c, _rgb((214, 168, 78)), (ring | rays | hub).astype(np.float32))
        c = fm.mix(c, _rgb((40, 110, 112)), (r < R * 0.12).astype(np.float32))
    outer, inner = _quarters_border(x, v)
    c = fm.mix(c, _rgb((214, 170, 82)), np.maximum(outer, inner))
    return fm.rgba(c)


MATS = {
    "nab_marble": ("a_specmap", nab_marble, 0.55, 30),
    "nab_gold": ("a_specmap", nab_gold, 0.8, 36),
    "nab_silk": ("a_specmap", nab_silk, 0.45, 18),
    "nab_brocade": ("a_specmap", nab_brocade, 0.5, 20),
    "nab_porcelain": ("a_specmap", nab_porcelain, 0.6, 40),
    "nab_glass": ("a_alpha_emis_full", nab_glass, 0, 0),
    "nab_glow": ("a_emis_full", nab_glow, 0, 0),
    "nab_leaf": ("a_specmap", nab_leaf, 0.25, 14),
    "nab_bloom": ("a_specmap", nab_bloom, 0.2, 10),
    "nab_bloom2": ("a_specmap", nab_bloom2, 0.2, 10),
    "nab_bloom3": ("a_specmap", nab_bloom3, 0.2, 10),
    "nab_pollen": ("a_simple", nab_pollen, 0, 0),
    "nab_cake": ("a_specmap", nab_cake, 0.4, 20),
    "nab_cake2": ("a_specmap", nab_cake2, 0.4, 20),
    "nab_tea": ("a_specmap", nab_tea, 0.7, 40),
    "nab_lace": ("a_alpha", nab_lace, 0, 0),
    "nab_panel": ("a_simple", nab_panel, 0, 0),
    "nab_panel_back": ("a_simple", nab_panel_back, 0, 0),
}

INFO = {
    "nab_tea_service": ("interact", "Theed Palace Tea Service",
                        "A gilded two-tier tea cart from the Queen's apartments: porcelain service, a tower of petit "
                        "fours and a posy for the tray. Stand behind it and pour; handmaidens have been dismissed for less."),
    "nab_royal_settee": ("seat", "Royal Theed Settee",
                         "A camelback settee in cream damask with scrolled gold arms, cabriole legs and the royal "
                         "crest. Built for receiving senators, or for pretending not to hear them."),
    "nab_globe_lamp": ("lamp", "Theed Globe Lamp",
                       "A Theed street lamp brought indoors: a gilded post wound with a flowering vine and three "
                       "frosted globes that glow like a Naboo sunset."),
    "nab_column_planter": ("decor", "Palace Column Planter",
                           "A fluted marble column with a gilded capital, crowned by an urn overflowing with blooms "
                           "and trailing vines from the palace gardens."),
    "nab_side_table": ("table", "Theed Marble Side Table",
                       "A round marble table on three gilded cabriole legs, a vase of fresh-cut flowers on a lace "
                       "doily. Coasters are, of course, beneath it."),
    "nab_folding_screen": ("decor", "Royal Folding Screen",
                           "Four gilded panels of painted silk: Theed on its cliffs at sunset, waterfalls and all. "
                           "The back is finished in damask, because a queen's screen has no wrong side."),
}

LIGHTS = {
    "nab_globe_lamp": [{"hardpoint": "light", "type": 1, "rgb": (0.0048, 0.0040, 0.0028), "range": 10.0,
                        "constant": 0.0, "linear": 0.00195, "quadratic": 0.0, "flags": 0}],
}
