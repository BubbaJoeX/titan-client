"""Kashyyyk Wookiee treehouse set (group `wok`), host side: materials, names and descriptions, the lantern's light.
Geometry: maya/swg_mcp/frn_groups/wok.py."""
from __future__ import annotations

import math

import numpy as np

import frn_materials as fm

N = fm.N


def _shift(m, dx, dy):
    return np.roll(np.roll(m, dy, axis=0), dx, axis=1)


def _bevel(mask, k=3):
    """Lit upper-left / shadowed lower-right rims of a carved mask (tileable)."""
    up = np.clip(mask - _shift(mask, k, k), 0, 1)
    dn = np.clip(mask - _shift(mask, -k, -k), 0, 1)
    return up, dn


def _colnoise(seed, n=N, smooth=3):
    """1-D tileable noise along x, broadcast over rows (for hair, grain)."""
    r = np.random.default_rng(seed).random(n).astype(np.float32)
    for _ in range(smooth):
        r = (r + np.roll(r, 1) + np.roll(r, -1)) / 3
    r = (r - r.min()) / (r.max() - r.min() + 1e-6)
    return np.broadcast_to(r[None, :], (n, n))


def _warp_x(arr, wx):
    """Sample arr with a per-pixel x offset (pixels), wrapping."""
    y, x = np.mgrid[0:N, 0:N]
    return arr[y, (x + wx.astype(int)) % N]


# ---------------------------------------------------------------------------------------------------------------
# wood, bark, carving
# ---------------------------------------------------------------------------------------------------------------

def wok_wood():
    """Worked wroshyr wood: warm red-brown, long flowing grain along v, a few knots, oiled sheen."""
    x, y = fm.coords()
    warp = fm.fbm(501, 2, 4) * 3.0 + fm.fbm(502, 4, 3) * 0.6
    grain = 0.5 + 0.5 * np.sin((x * 14 + warp) * 2 * math.pi)
    fine = _warp_x(_colnoise(503, smooth=1), (fm.fbm(504, 2, 3) - 0.5) * 60)
    c = fm.mix(fm.col((92, 48, 26)), fm.col((150, 86, 46)), grain * 0.55 + fm.fbm(505, 8, 4) * 0.25 + fine * 0.2)
    knot = np.zeros_like(x)
    for kx, ky, kr in ((0.23, 0.31, 0.035), (0.71, 0.78, 0.028), (0.58, 0.12, 0.022)):
        dx = ((x - kx + 0.5) % 1.0 - 0.5) * 2.2
        dy = ((y - ky + 0.5) % 1.0 - 0.5)
        d = np.sqrt(dx * dx + dy * dy)
        knot = np.maximum(knot, (1 - fm.smooth(kr * 0.4, kr, d)) * (0.6 + 0.4 * np.sin(d * 300)))
    c = fm.mix(c, fm.col((54, 26, 14)), knot * 0.8)
    return fm.rgba(c, 0.30 + 0.2 * grain)


def wok_bark():
    """Wroshyr bark: dark grey-brown, deep vertical furrows, moss and lichen flecks in the cracks."""
    x, y = fm.coords()
    warp = fm.fbm(511, 2, 4) * 2.5
    ridge = np.abs(np.sin((x * 9 + warp + fm.fbm(512, 8, 3) * 0.3) * math.pi))
    plates = fm.smooth(0.15, 0.6, ridge)
    cross = fm.grooves(y + fm.fbm(513, 4, 3) * 0.2, 0.25, 0.008) * (fm.fbm(514, 8, 3) > 0.62)
    c = fm.mix(fm.col((34, 24, 18)), fm.col((98, 76, 58)), plates * (0.75 + 0.35 * fm.fbm(515, 16, 4)))
    c = c * (1 - 0.3 * cross)[..., None]
    moss = fm.smooth(0.55, 0.75, fm.fbm(516, 6, 5)) * (1 - plates)
    c = fm.mix(c, fm.col((70, 96, 40)), moss * 0.8)
    lichen = (fm.fbm(517, 32, 3) > 0.74) * plates
    c = fm.mix(c, fm.col((150, 152, 120)), lichen * 0.5)
    return fm.rgba(c)


def _glyph_mask(u, v):
    """Four Wookiee glyphs per band tile (u 0..1 across the tile, v 0..1 up the band's inner field)."""
    cell = (u * 4) % 1.0
    k = np.floor(u * 4).astype(int) % 4
    a, b = cell - 0.5, v - 0.5
    m = np.zeros_like(u, bool)
    # diamond with a cross-hatched heart
    dia = np.abs(a) * 1.25 + np.abs(b)
    g0 = ((dia > 0.26) & (dia < 0.36)) | ((dia < 0.14) & ((np.abs(a) < 0.03) | (np.abs(b) < 0.03)))
    # stacked chevrons (claw marks)
    chev = ((b + 0.9 * np.abs(a)) * 3.5) % 1.0
    g1 = (chev < 0.36) & (np.abs(a) < 0.34) & (np.abs(b) < 0.40)
    # wroshyr tree: trunk and three branch chevrons
    g2 = ((np.abs(a) < 0.04) & (np.abs(b) < 0.40)) | ((np.abs(b - 0.8 * np.abs(a) + 0.05 - np.round((b - 0.8 * np.abs(a) + 0.05) / 0.22) * 0.22) < 0.035)
                                                      & (np.abs(a) < 0.30) & (b > -0.30) & (b < 0.38))
    # square spiral (a hunting trail)
    sq = np.maximum(np.abs(a), np.abs(b))
    g3 = ((np.abs(sq - 0.34) < 0.04) & ~((a > 0.1) & (b > 0.0) & (b < 0.34))) | ((np.abs(sq - 0.20) < 0.04) & ~((a < -0.05) & (b < 0.0))) | (sq < 0.06)
    for i, g in enumerate((g0, g1, g2, g3)):
        m |= (k == i) & g
    return m.astype(np.float32)


def wok_carve():
    """Carved glyph band: two rolled rails and a row of four Wookiee glyphs cut into dark wood, the cuts inlaid
    with ochre. Tiles along u; spans the band once along v."""
    x, y = fm.coords()
    base = wok_wood()[..., :3].astype(np.float32) / 255 * 0.82
    v = 1 - y
    rails = ((v < 0.12) | (v > 0.88)).astype(np.float32)
    railshade = np.exp(-((v - 0.06) / 0.03) ** 2) + np.exp(-((v - 0.94) / 0.03) ** 2)
    groove = ((np.abs(v - 0.13) < 0.012) | (np.abs(v - 0.87) < 0.012)).astype(np.float32)
    m = _glyph_mask(x, (v - 0.16) / 0.68) * ((v > 0.16) & (v < 0.84))
    up, dn = _bevel(m, 3)
    c = base * (1 + 0.25 * railshade - 0.35 * groove)[..., None]
    c = fm.mix(c, fm.col((176, 112, 44)) * (0.8 + 0.3 * fm.fbm(521, 16, 3))[..., None], m * 0.85)
    c = c * (1 + 0.35 * up - 0.45 * dn)[..., None]
    c = c * (1 - 0.15 * rails * (1 - railshade))[..., None]
    return fm.rgba(c)


def wok_glyph():
    """Round carved medallion (fit on a disc): rings of tally marks round a claw-and-tree emblem, ochre inlay."""
    x, y = fm.coords()
    dx, dy = x - 0.5, 0.5 - y
    r = np.sqrt(dx * dx + dy * dy) * 2
    a = np.arctan2(dy, dx)
    base = fm.mix(fm.col((70, 38, 20)), fm.col((110, 62, 32)), fm.fbm(531, 8, 4))
    ring = ((np.abs(r - 0.92) < 0.03) | (np.abs(r - 0.62) < 0.025)).astype(np.float32)
    ticks = ((np.abs(np.sin(a * 18)) < 0.25) & (r > 0.68) & (r < 0.86)).astype(np.float32)
    tree = ((np.abs(dx) < 0.025) & (dy > -0.24) & (dy < 0.22)) | \
           ((np.abs(dy - 1.0 * np.abs(dx) + 0.02 - np.round((dy - 1.0 * np.abs(dx) + 0.02) / 0.13) * 0.13) < 0.02) &
            (np.abs(dx) < 0.17) & (dy > -0.16) & (dy < 0.22))
    claws = np.zeros_like(r, bool)
    for k in (-1, 0, 1):
        ang = a - (-math.pi / 2 + k * 0.32)
        claws |= (np.abs(np.sin(ang)) * r < 0.02) & (r > 0.36) & (r < 0.52) & (np.cos(ang) > 0)
    m = np.clip(ring + ticks + tree + claws, 0, 1) * (r < 1.0)
    up, dn = _bevel(m, 3)
    c = fm.mix(base, fm.col((210, 150, 60)), m * 0.9)
    c = c * (1 + 0.3 * up - 0.4 * dn)[..., None]
    rim = fm.smooth(0.96, 1.0, r)
    c = fm.mix(c, fm.col((60, 34, 18)), rim)
    return fm.rgba(c, 0.25 + 0.5 * m)


def wok_endgrain():
    """End grain of a sawn wroshyr log (fit on the cut face): growth rings, radial checks, a bark rim."""
    x, y = fm.coords()
    dx, dy = x - 0.5, y - 0.5
    a = np.arctan2(dy, dx)
    r = np.sqrt(dx * dx + dy * dy) * 2 * (1 + 0.04 * np.sin(a * 3 + 1) + 0.03 * fm.fbm(541, 4, 3))
    rings = 0.5 + 0.5 * np.sin(r * 2 * math.pi * 14 + fm.fbm(542, 8, 3) * 2)
    c = fm.mix(fm.col((150, 98, 58)), fm.col((196, 140, 88)), rings * 0.6 + 0.4 * fm.fbm(543, 16, 3))
    c = fm.mix(c, fm.col((110, 62, 36)), fm.smooth(0.15, 0.0, r) * 0.6)
    checks = np.zeros_like(r)
    for k, a0 in enumerate((0.4, 1.9, 3.3, 4.6, 5.6)):
        da = np.abs(((a - a0 + math.pi) % (2 * math.pi)) - math.pi)
        w = 0.004 + 0.004 * (1 - r)
        checks = np.maximum(checks, (1 - fm.smooth(w * 0.4, w, da * r)) * fm.smooth(0.3, 0.4, r) * fm.smooth(0.62 + 0.06 * k % 0.18, 0.5, r))
    c = c * (1 - 0.35 * checks)[..., None]
    bark = fm.smooth(0.86, 0.92, r)
    c = fm.mix(c, fm.col((52, 36, 26)) * (0.8 + 0.4 * fm.fbm(544, 32, 2))[..., None], bark)
    return fm.rgba(c)


# ---------------------------------------------------------------------------------------------------------------
# fibre, fur, hide
# ---------------------------------------------------------------------------------------------------------------

def _weave(seed, cells=8):
    """Basket weave: over-under groups of strands; returns colour and a strand-shading map."""
    x, y = fm.coords()
    u, v = x * cells, y * cells
    cu, cv = np.floor(u).astype(int), np.floor(v).astype(int)
    fu, fv = u % 1.0, v % 1.0
    horiz = ((cu + cv) % 2 == 0)
    # three strands per cell, round in section
    s_h = np.abs(np.sin(fv * 3 * math.pi))
    s_v = np.abs(np.sin(fu * 3 * math.pi))
    shade = np.where(horiz, s_h, s_v) ** 0.5
    edge = np.where(horiz, np.minimum(fu, 1 - fu), np.minimum(fv, 1 - fv))
    shade = shade * fm.smooth(0.0, 0.12, edge) * 0.8 + 0.2 * shade
    per = np.random.default_rng(seed).random((cells * 3 + 1, cells * 3 + 1)).astype(np.float32)
    idx = np.where(horiz, (v * 3).astype(int) % (cells * 3), (u * 3).astype(int) % (cells * 3))
    tone = per[idx % (cells * 3), 0]
    c = fm.mix(fm.col((150, 112, 60)), fm.col((214, 178, 112)), 0.35 + 0.45 * tone)
    c = c * (0.35 + 0.75 * shade)[..., None] * (0.92 + 0.12 * fm.fbm(seed + 1, 32, 2))[..., None]
    return c, shade, horiz


def wok_weave():
    c, _, _ = _weave(551)
    return fm.rgba(c)


def wok_weave_band():
    """The weave with a dyed band: dark red field, black zigzag, natural rows either side (tiles along v)."""
    x, y = fm.coords()
    c, shade, horiz = _weave(561)
    band = (y > 0.30) & (y < 0.70)
    zig = np.abs((y - 0.5) - 0.12 * (np.abs(((x * 6) % 1.0) - 0.5) * 4 - 1)) < 0.05
    dots = (np.abs(y - 0.2) < 0.03) & (((x * 12) % 1.0) < 0.5) | (np.abs(y - 0.8) < 0.03) & (((x * 12 + 0.5) % 1.0) < 0.5)
    dye = np.zeros_like(c)
    dye[:] = np.array([128, 34, 22], np.float32) / 255
    dye[zig & band] = np.array([28, 18, 14], np.float32) / 255
    dye[dots] = np.array([40, 28, 20], np.float32) / 255
    m = (band | dots).astype(np.float32)
    c = fm.mix(c, dye * (0.35 + 0.75 * shade)[..., None], m * 0.9)
    return fm.rgba(c)


def wok_cord():
    """Twisted plant-fibre cord: three plies spiralling round (u around the tube, v along it)."""
    x, y = fm.coords()
    ply = ((x * 3 + y * 2) % 1.0)
    shade = np.sin(ply * math.pi) ** 0.7
    c = fm.mix(fm.col((120, 88, 50)), fm.col((196, 160, 104)), shade)
    fibres = _colnoise(571, smooth=0)
    c = c * (0.85 + 0.2 * fibres * shade)[..., None] * (0.92 + 0.1 * fm.fbm(572, 16, 2))[..., None]
    return fm.rgba(c)


def _hair(seed, dark, light, tips, locks=22, contrast=1.0):
    """Fur: rounded locks of hair flowing along v (wavy, each a different length), fine strands, darker roots
    and lighter tips. Returns colour, a strand map and the along-lock position."""
    x, y = fm.coords()
    rng = np.random.default_rng(seed)
    wave = (fm.fbm(seed, 2, 4) - 0.5) * 1.8 + (fm.fbm(seed + 1, 6, 3) - 0.5) * 0.5
    lx = x * locks + wave
    lid = np.floor(lx).astype(int) % locks
    f = lx - np.floor(lx)
    lock = 1 - contrast * (1 - np.sin(f * math.pi) ** 0.5) * 0.8
    off = rng.random(locks).astype(np.float32)[lid]
    ln = (1 + (rng.random(locks) * 2).astype(int)).astype(np.float32)[lid]
    flow = (y * ln + off + 0.12 * fm.fbm(seed + 2, 8, 2)) % 1.0
    strands = _warp_x(_colnoise(seed + 3, smooth=0), wave * N / locks)
    shade = lock * (0.6 + 0.4 * strands) * (0.62 + 0.38 * fm.smooth(0.0, 0.5, flow))
    c = fm.mix(fm.col(dark), fm.col(light), np.clip(shade, 0, 1))
    tip = fm.smooth(0.6, 0.93, flow) * (1 - fm.smooth(0.96, 1.0, flow))
    c = fm.mix(c, fm.col(tips), tip * lock * 0.45)
    return c, strands, flow


def wok_fur():
    """Shaggy Wookiee-brown fur: wavy locks, fine strands, dark roots and golden tips."""
    c, _, _ = _hair(581, (38, 22, 12), (128, 86, 50), (204, 164, 108))
    return fm.rgba(c)


def wok_pelt():
    """A striped Kashyyyk beast pelt: cream fur with broken, tapering dark-brown stripes across v."""
    x, y = fm.coords()
    c, strands, flow = _hair(591, (160, 138, 104), (236, 222, 194), (252, 246, 230), locks=30, contrast=0.6)
    w1 = fm.fbm(592, 2, 4) - 0.5
    ph = (y * 5 + 0.35 * np.sin(x * 2 * math.pi) + 0.6 * w1) % 1.0
    width = 0.10 + 0.10 * fm.fbm(593, 4, 3)
    taper = fm.smooth(0.18, 0.45, fm.fbm(594, 3, 3))                  # stripes break up and taper out
    s = (1 - fm.smooth(width * 0.7, width, np.abs(ph - 0.5))) * taper
    c = fm.mix(c, fm.col((54, 34, 20)) * (0.8 + 0.35 * strands)[..., None], s * 0.92)
    return fm.rgba(c)


def wok_hide():
    """A fresh hide on the stretching frame (fit once): pale scraped centre, darker spine and edges, a vein
    network, scrape strokes and pores."""
    x, y = fm.coords()
    dx, dy = (x - 0.5) * 2, (y - 0.5) * 2
    d = np.sqrt((dx / 0.9) ** 2 + (dy / 0.88) ** 2)
    n = fm.fbm(601, 4, 6)
    c = fm.mix(fm.col((226, 196, 152)), fm.col((196, 158, 112)), n)
    spine = np.exp(-(dx / 0.10) ** 2) * (np.abs(dy) < 0.9)
    c = fm.mix(c, fm.col((160, 116, 76)), spine * 0.45)
    veins = 1 - fm.smooth(0.0, 0.02, np.abs(fm.fbm(602, 6, 5) - 0.5))
    veins2 = 1 - fm.smooth(0.0, 0.012, np.abs(fm.fbm(603, 12, 4) - 0.5))
    c = fm.mix(c, fm.col((170, 110, 86)), (veins * 0.35 + veins2 * 0.2) * (1 - fm.smooth(0.6, 1.0, d)))
    scrape = 0.5 + 0.5 * np.sin((dx * 0.6 + dy) * 60 + fm.fbm(604, 8, 3) * 6)
    zone = fm.smooth(0.7, 0.2, d) * fm.smooth(0.45, 0.65, fm.fbm(605, 4, 3))
    c = c * (1 + 0.06 * (scrape - 0.5) * zone * 2)[..., None]
    pores = (fm.fbm(606, 128, 1) > 0.78).astype(np.float32) * 0.08
    c = c * (1 - pores)[..., None]
    edge = fm.smooth(0.70, 1.20, d + 0.18 * (fm.fbm(607, 4, 3) - 0.5))
    c = fm.mix(c, fm.col((140, 96, 60)) * (0.85 + 0.3 * n)[..., None], edge * 0.6)
    return fm.rgba(c)


def wok_leather():
    """Dark tanned leather with pebbled grain and stitching along both edges (along v)."""
    x, y = fm.coords()
    peb = fm.fbm(611, 64, 2)
    c = fm.mix(fm.col((58, 34, 20)), fm.col((104, 64, 36)), 0.4 * peb + 0.6 * fm.fbm(612, 6, 4))
    stitch = ((np.abs(x - 0.12) < 0.012) | (np.abs(x - 0.88) < 0.012)) & (((y * 24) % 1.0) < 0.55)
    c = fm.mix(c, fm.col((196, 168, 120)), stitch.astype(np.float32) * 0.8)
    edge = (x < 0.05) | (x > 0.95)
    c = c * (1 - 0.3 * edge)[..., None]
    return fm.rgba(c, 0.3 + 0.2 * peb)


# ---------------------------------------------------------------------------------------------------------------
# bronze, fungus, glow
# ---------------------------------------------------------------------------------------------------------------

def wok_bronze():
    """Hammered bronze: warm metal with dimples and verdigris creeping into the low spots."""
    x, y = fm.coords()
    n = fm.fbm(621, 4, 5)
    dimp = np.zeros_like(x)
    r = np.random.default_rng(622)
    for _ in range(90):
        dimp = np.maximum(dimp, fm.disc_mask(x, y, r.random(), r.random(), 0.02 + 0.02 * r.random(), 0.02))
    c = fm.mix(fm.col((126, 76, 34)), fm.col((214, 150, 74)), 0.35 + 0.45 * n + 0.15 * dimp)
    verd = fm.smooth(0.68, 0.82, fm.fbm(623, 8, 5)) * (1 - dimp * 0.6)
    c = fm.mix(c, fm.col((70, 140, 112)), verd * 0.7)
    return fm.rgba(c, 0.85 - 0.6 * verd)


def wok_fungus():
    """Bioluminescent fungus (self-lit): green-gold flesh, bright spots and glowing gill lines."""
    x, y = fm.coords()
    n = fm.fbm(631, 4, 5)
    c = fm.mix(fm.col((90, 170, 40)), fm.col((200, 240, 90)), n)
    gills = 0.5 + 0.5 * np.sin(x * 2 * math.pi * 16 + fm.fbm(632, 4, 3) * 3)
    c = c * (0.8 + 0.25 * gills)[..., None]
    spots = np.zeros_like(x)
    r = np.random.default_rng(633)
    for _ in range(60):
        spots = np.maximum(spots, fm.disc_mask(x, y, r.random(), r.random(), 0.01 + 0.02 * r.random(), 0.01))
    c = fm.mix(c, fm.col((255, 250, 180)), spots * 0.9)
    return fm.rgba(c)


def wok_glow():
    """Glow halo round the fungus pods (a_alpha_emis_full): a soft green-gold haze, alpha = brightness."""
    x, y = fm.coords()
    n = fm.fbm(641, 4, 4)
    c = fm.mix(fm.col((150, 220, 70)), fm.col((230, 250, 140)), n)
    return fm.rgba(c, 0.14 + 0.10 * n)


MATS = {
    "wok_wood": ("a_specmap", wok_wood, 0.25, 18),
    "wok_bark": ("a_simple", wok_bark, 0, 0),
    "wok_carve": ("a_simple", wok_carve, 0, 0),
    "wok_glyph": ("a_specmap", wok_glyph, 0.5, 25),
    "wok_endgrain": ("a_simple", wok_endgrain, 0, 0),
    "wok_weave": ("a_simple", wok_weave, 0, 0),
    "wok_weave_band": ("a_simple", wok_weave_band, 0, 0),
    "wok_cord": ("a_simple", wok_cord, 0, 0),
    "wok_fur": ("a_simple", wok_fur, 0, 0),
    "wok_pelt": ("a_simple", wok_pelt, 0, 0),
    "wok_hide": ("a_simple", wok_hide, 0, 0),
    "wok_leather": ("a_specmap", wok_leather, 0.3, 14),
    "wok_bronze": ("a_specmap", wok_bronze, 0.75, 32),
    "wok_fungus": ("a_emis_full", wok_fungus, 0, 0),
    "wok_glow": ("a_alpha_emis_full", wok_glow, 0, 0),
}

INFO = {
    "wok_hide_frame": ("interact", "Wookiee Hide-Tanning Frame",
                       "A fresh hide laced into a lashed wroshyr frame, a flesher and a ryyk blade on the stump beside "
                       "it. Sit down to crouch at the frame and work the hide; the Wookiee who owned it would like it "
                       "back by next season."),
    "wok_root_chair": ("seat", "Wroshyr Root Chair",
                       "A chair coaxed out of living wroshyr roots over a few patient decades: twisted legs, a "
                       "woven-branch back curling into fiddleheads, and a striped pelt thrown over the seat."),
    "wok_glow_lantern": ("lamp", "Kashyyyk Glow-Pod Lantern",
                         "A woven basket lantern full of bioluminescent fungus pods, hung from a carved wroshyr crook. "
                         "Feed it nothing and it glows anyway; the pods are smug about it."),
    "wok_bowcaster_rack": ("decor", "Bowcaster Rack",
                           "A forked-post rack of wroshyr wood holding a bowcaster on its side, a bandolier of ammo "
                           "boxes and a basket of quarrels. Only a Wookiee can cock it; everyone else gets to admire it."),
    "wok_carved_totem": ("decor", "Wroshyr Clan Totem",
                         "A clan totem carved from a single wroshyr trunk: a sleeping elder, a roaring warrior with "
                         "glowing eyes and a winged ancestor under a branching crown of glow-caps."),
    "wok_storage_baskets": ("decor", "Treehouse Storage Baskets",
                            "Lidded woven baskets stacked and strapped, a tall basket of carved staffs, a bowl of "
                            "glow-caps and a net bag of gourds. Every Kashyyyk treehouse has these; nobody remembers "
                            "what is in the bottom one."),
}

LIGHTS = {
    "wok_glow_lantern": [{"hardpoint": "light", "type": 1, "rgb": (0.0034, 0.0046, 0.0016), "range": 10.0,
                          "constant": 0.0, "linear": 0.00195, "quadratic": 0.0, "flags": 0}],
}
