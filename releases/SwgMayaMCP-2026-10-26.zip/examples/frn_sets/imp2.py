"""Galactic Empire, second wave: materials, names and the light (geometry: maya/swg_mcp/frn_groups/imp2.py).
The pieces reuse the first Imperial set's materials (imp_black, imp_grey, imp_white, imp_leather, imp_red, imp_crest,
imp_chrome, reb_console, imp_screen); the new ones here are imp2_*."""
from __future__ import annotations

import math

import numpy as np

import frn_materials as fm


def imp2_screen():
    """Interrogation readout (self-lit red): grid, three vital-sign traces, a pain-response bar stack and a
    reticle over a subject silhouette."""
    x, y = fm.coords()
    c = fm.col((26, 2, 2)) * (0.9 + 0.1 * np.sin(y * fm.N * math.pi / 2))[..., None]
    grid = np.maximum(fm.lines(x, 1 / 16, 0.0025), fm.lines(y, 1 / 10, 0.0025))
    c = fm.mix(c, fm.col((100, 8, 6)), grid * 0.7 * (x < 0.64))
    for k, (yc, f, amp) in enumerate(((0.20, 9.0, 0.05), (0.42, 4.0, 0.07), (0.64, 15.0, 0.03))):
        wave = yc + amp * np.sin(x * 2 * math.pi * f + k) * (0.55 + 0.45 * np.sin(x * 2 * math.pi * 2.3 + 1.7 * k))
        spike = (np.abs(((x * 3 + 0.2 * k) % 1.0) - 0.5) < 0.01) * 0.12
        d = np.abs(y - wave + spike)
        c = fm.mix(c, fm.col((255, 80, 60)), (1 - fm.smooth(0.003, 0.008, d)) * (x < 0.62))
        c = fm.mix(c, fm.col((255, 200, 180)), (1 - fm.smooth(0.0, 0.003, d)) * (x < 0.62))
    # right column: bar stack (pain response) and the subject reticle
    bars = (x > 0.70) & (x < 0.78) & (((y * 14) % 1.0) < 0.6) & (y > 0.08) & (y < 0.92)
    c = fm.mix(c, fm.col((70, 10, 8)), bars.astype(np.float32))
    c = fm.mix(c, fm.col((255, 50, 30)), (bars & (y > 0.38)).astype(np.float32))
    d = np.sqrt(((x - 0.89) * 1.6) ** 2 + (y - 0.40) ** 2)
    head = (np.sqrt(((x - 0.89) * 1.6) ** 2 + (y - 0.30) ** 2) < 0.07)
    body = (np.abs(x - 0.89) < 0.06) & (y > 0.37) & (y < 0.62)
    c = fm.mix(c, fm.col((150, 20, 14)), (head | body).astype(np.float32))
    ring = (np.abs(d - 0.22) < 0.006) | ((np.abs(x - 0.89) < 0.002) & (d > 0.16) & (d < 0.28)) | \
        ((np.abs(y - 0.40) < 0.003) & (d > 0.16) & (d < 0.28))
    c = fm.mix(c, fm.col((255, 120, 90)), ring.astype(np.float32))
    # header strip and blinking status block (asymmetric, shows orientation)
    hdr = (y > 0.92) & (y < 0.96) & (x > 0.03) & (x < 0.45)
    c = fm.mix(c, fm.col((230, 50, 40)), hdr.astype(np.float32))
    c = fm.mix(c, fm.col((255, 220, 200)), fm.disc_mask(x, y, 0.50, 0.94, 0.012, 0.004))
    edge = 1 - fm.smooth(0.0, 0.03, np.minimum(np.minimum(x, 1 - x), np.minimum(y, 1 - y)))
    return fm.rgba(c * (1 - 0.6 * edge)[..., None])


def imp2_light():
    """Death Star corridor light panel (self-lit): white diffuser, a hot centre column, fine tube segment lines,
    darker rims. Fit once per panel face."""
    x, y = fm.coords()
    core = np.exp(-((x - 0.5) / 0.28) ** 2)
    c = fm.mix(fm.col((170, 196, 230)), fm.col((250, 252, 255)), core)
    seg = fm.lines(y, 1 / 18, 0.0035)
    c = c * (1 - 0.22 * seg)[..., None]
    rim = 1 - fm.smooth(0.0, 0.07, np.minimum(np.minimum(x, 1 - x), np.minimum(y, 1 - y) * 4))
    c = fm.mix(c, fm.col((90, 110, 140)), rim * 0.7)
    return fm.rgba(c)


def imp2_lens():
    """Droid lens glass (self-lit): deep red with concentric iris rings across v and a hot pole."""
    x, y = fm.coords()
    t = 1 - y                                       # v: 0 at the rim .. ~1 at the pole
    c = fm.mix(fm.col((60, 0, 0)), fm.col((210, 24, 10)), fm.smooth(0.0, 0.9, t))
    rings = (np.abs(np.sin(t * math.pi * 4)) > 0.93).astype(np.float32) * (t < 0.8)
    c = fm.mix(c, fm.col((255, 90, 50)), rings * 0.6)
    c = fm.mix(c, fm.col((255, 220, 190)), fm.smooth(0.82, 0.97, t))
    return fm.rgba(c)


def imp2_gunmetal():
    """Blaster / droid-limb finish: satin black-grey steel, fine machining lines, worn high spots."""
    x, y = fm.coords()
    n = fm.fbm(2011, 8, 5)
    c = fm.col((50, 52, 57)) * (0.85 + 0.3 * n)[..., None]
    mach = fm.lines(y, 1 / 24, 0.002)
    c = c * (1 - 0.3 * mach)[..., None]
    wear = fm.smooth(0.70, 0.86, fm.fbm(2012, 16, 4))
    c = fm.mix(c, fm.col((96, 98, 104)), wear * 0.55)
    return fm.rgba(c, 0.45 + 0.25 * wear)


def imp2_crate():
    """Imperial cargo plating: pale grey panels, ribbed bands, panel seams, scuffs and a hazard stripe."""
    x, y = fm.coords()
    seam, light = fm.bevel_panels(x, y, 2, 2, 0.007)
    band = (y > 0.10) & (y < 0.24)
    ribs = fm.grooves(x, 1 / 16, 0.012) * band
    c = fm.col((176, 180, 186)) * (0.9 + 0.12 * fm.fbm(2021, 8, 5))[..., None]
    c = c * (1 - 0.5 * seam - 0.3 * ribs)[..., None] * (1 + 0.1 * light)[..., None]
    haz = (y > 0.90) & (y < 0.955)
    chev = (((x + y) * 16) % 1.0) < 0.5
    c = fm.mix(c, fm.mix(fm.col((30, 30, 32)), fm.col((214, 170, 40)), chev.astype(np.float32)), haz.astype(np.float32) * 0.85)
    scuff = fm.smooth(0.70, 0.90, fm.fbm(2022, 16, 4))
    c = fm.mix(c, fm.col((96, 98, 102)), scuff * 0.45)
    return fm.rgba(c, 0.35 - 0.25 * seam)


def imp2_armour():
    """Stormtrooper plastoid: clean gloss white, a cool blue-grey cast in the creases, faint moulding seams."""
    x, y = fm.coords()
    n = fm.fbm(2041, 4, 4)
    c = fm.mix(fm.col((214, 220, 228)), fm.col((246, 247, 250)), 0.5 + 0.5 * n)
    seam = fm.lines(x, 0.5, 0.003) * 0.25
    c = c * (1 - seam)[..., None]
    return fm.rgba(c, 0.8 - seam)


def _crest_mask(x, y):
    """The imp_crest roundel as a 0/1 mask over the unit square."""
    dx, dy = x - 0.5, y - 0.5
    r = np.sqrt(dx * dx + dy * dy) / 0.45
    a = np.arctan2(dy, dx)
    ring = (r < 1.0) & (r > 0.86)
    hub = (r < 0.28) & (r > 0.18)
    sector = (a * 6 / (2 * math.pi)) % 1.0
    spokes = (np.abs(sector - 0.5) < 0.16 + 0.12 * (r - 0.28)) & (r > 0.28) & (r < 0.86)
    teeth = ((a * 12 / (2 * math.pi)) % 1.0 < 0.5) & (r >= 1.0) & (r < 1.07)
    return (ring | hub | spokes | teeth).astype(np.float32)


def imp2_stencil():
    """Spray stencil (a_alpha): the crest over two rows of cargo glyphs, dark paint, worn. Fit once."""
    x, y = fm.coords()
    cx, cy = (x - 0.5) / 0.62 + 0.5, (y - 0.36) / 0.62 + 0.5
    m = _crest_mask(cx, cy) * ((cx > 0) & (cx < 1) & (cy > 0) & (cy < 1))
    r = np.random.default_rng(2031)
    for row, (y0, y1) in enumerate(((0.76, 0.84), (0.88, 0.93))):
        xx = 0.08
        while xx < 0.92:
            w = 0.03 + 0.05 * r.random()
            m = np.maximum(m, ((x > xx) & (x < min(xx + w, 0.92)) & (y > y0) & (y < y1)).astype(np.float32))
            xx += w + 0.025 + (0.04 if r.random() < 0.25 else 0.0)
    gaps = (np.abs(((x - 0.5) * 9) % 1.0 - 0.5) < 0.04) & (y < 0.7)      # stencil bridges
    wear = fm.smooth(0.30, 0.48, fm.fbm(2032, 16, 4))
    a = m * (1 - gaps) * (0.25 + 0.65 * wear)
    return fm.rgba(fm.col((24, 26, 30)), a)


def imp2_status():
    """Status panel (self-lit): two rows of LEDs, green / amber / red / cyan, on dark glass. Fit once."""
    x, y = fm.coords()
    c = fm.col((10, 12, 16))
    pal = [(60, 255, 100), (60, 255, 100), (255, 190, 40), (60, 255, 100), (255, 50, 40), (70, 200, 255)]
    for row in range(2):
        for k in range(6):
            cx, cy = (k + 0.5) / 6, 0.30 + 0.40 * row
            col = pal[(k + 3 * row) % 6]
            glow = np.exp(-(((x - cx) / 0.07) ** 2 + ((y - cy) / 0.20) ** 2))
            m = (np.abs(x - cx) < 0.045) & (np.abs(y - cy) < 0.11)
            c = c + fm.col(col) * (glow * 0.25)[..., None]
            c = fm.mix(c, fm.col(col), m.astype(np.float32))
    return fm.rgba(c)


MATS = {
    "imp2_screen": ("a_emis_full", imp2_screen, 0, 0),
    "imp2_light": ("a_emis_full", imp2_light, 0, 0),
    "imp2_lens": ("a_emis_full", imp2_lens, 0, 0),
    "imp2_gunmetal": ("a_specmap", imp2_gunmetal, 0.5, 30),
    "imp2_crate": ("a_specmap", imp2_crate, 0.35, 20),
    "imp2_stencil": ("a_alpha", imp2_stencil, 0, 0),
    "imp2_status": ("a_emis_full", imp2_status, 0, 0),
    "imp2_armour": ("a_specmap", imp2_armour, 0.65, 40),
}

INFO = {
    "imp_interrogation_rig": ("interact", "IT-O Interrogation Rig",
                              "A tilted restraint table, an IT-O interrogator droid hanging over it on an articulated "
                              "arm, and the operator's console with its red vital-signs readout. Step up to the console "
                              "and begin the questioning. Most subjects find the droid very persuasive."),
    "imp_emperor_throne": ("seat", "Emperor's Throne",
                           "The Emperor's black swivel throne on a round stepped dais, its wide angular arms carrying "
                           "the controls of an entire battle station. Sit, steeple your fingers, and let the hate flow."),
    "imp_light_pillar": ("lamp", "Death Star Corridor Light Pillar",
                         "A light pillar salvaged from a Death Star corridor: a black octagonal column with tall white "
                         "light panels between grey blade fins. Floods any room with that cold, regulation glow."),
    "imp_probe_droid": ("decor", "Viper Probe Droid Display",
                        "An Arakyd Viper probe droid, deactivated (allegedly) and clamped to a display stand, sensor "
                        "eyes, antennae and manipulator legs dangling. Do not leave it facing an open window."),
    "imp_weapon_rack": ("decor", "Imperial Armoury Rack",
                        "A garrison weapon rack holding four E-11 blaster rifles, with a stormtrooper helmet and a row "
                        "of thermal detonators on the shelf beneath the crest. Aiming lessons sold separately."),
    "imp_cargo_crates": ("decor", "Imperial Cargo Containers",
                         "Regulation cargo containers stacked as they came off the shuttle, crest-stencilled and "
                         "status-lit, with a fuel canister and a field case. Contents: classified. Probably rations."),
}

LIGHTS = {
    "imp_light_pillar": [{"hardpoint": "light", "type": 1, "rgb": (0.0040, 0.0044, 0.0050), "range": 10.0,
                          "constant": 0.0, "linear": 0.00195, "quadratic": 0.0, "flags": 0}],
}
