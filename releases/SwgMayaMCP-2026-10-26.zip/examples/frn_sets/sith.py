"""Host side of the Sith set (geometry: maya/swg_mcp/frn_groups/sith.py): obsidian, basalt, lava, runes, kyber,
lightsaber blades, the holocron; names and descriptions; the lava brazier's light."""
from __future__ import annotations

import math

import numpy as np

import frn_materials as fm


# ---------------------------------------------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------------------------------------------

def _cells(seed, g, n=fm.N):
    """Tileable jittered cells on a g x g grid: (distance to the nearest centre, to the second, a value per cell)."""
    r = np.random.default_rng(seed)
    pts = r.random((g, g, 2)).astype(np.float32)
    ids = r.random((g, g)).astype(np.float32)
    x, y = fm.coords(n)
    gx, gy = x * g, y * g
    ix, iy = np.floor(gx).astype(int), np.floor(gy).astype(int)
    d1 = np.full(x.shape, 9.0, np.float32)
    d2 = d1.copy()
    cid = np.zeros_like(x)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            cx, cy = ix + dx, iy + dy
            p = pts[cy % g, cx % g]
            d = np.hypot(gx - (cx + p[..., 0]), gy - (cy + p[..., 1]))
            closer = d < d1
            d2 = np.where(closer, d1, np.minimum(d2, d))
            cid = np.where(closer, ids[cy % g, cx % g], cid)
            d1 = np.where(closer, d, d1)
    return d1, d2, cid


def _seg(x, y, a, b, aspect=1.0):
    """Distance from each pixel to the segment a-b (x stretched by `aspect`)."""
    px, py = x * aspect, y
    ax, ay, bx, by = a[0] * aspect, a[1], b[0] * aspect, b[1]
    dx, dy = bx - ax, by - ay
    t = np.clip(((px - ax) * dx + (py - ay) * dy) / max(dx * dx + dy * dy, 1e-9), 0, 1)
    return np.hypot(px - ax - t * dx, py - ay - t * dy)


# ---------------------------------------------------------------------------------------------------------------
# materials
# ---------------------------------------------------------------------------------------------------------------

def sith_obsidian():
    """Polished obsidian: near-black volcanic glass, faint conchoidal ripples, a deep red flash in places."""
    x, y = fm.coords()
    n = fm.fbm(2101, 4, 6)
    r = np.random.default_rng(2102)
    rip = np.zeros_like(x)
    for _ in range(6):
        cx, cy = r.random(), r.random()
        d = np.sqrt(((x - cx + 0.5) % 1.0 - 0.5) ** 2 + ((y - cy + 0.5) % 1.0 - 0.5) ** 2)
        rip += np.sin(d * 70 + n * 5) * np.exp(-d * 5)
    rip = np.clip(rip / 2.0, -1, 1)
    c = fm.mix(fm.col((20, 18, 26)), fm.col((58, 52, 66)), np.clip(0.35 + 0.3 * (n - 0.5) + 0.25 * rip, 0, 1))
    sheen = fm.smooth(0.62, 0.86, fm.fbm(2103, 3, 4))
    c = fm.mix(c, fm.col((96, 22, 26)), sheen * 0.3)
    return fm.rgba(c, np.clip(0.82 + 0.12 * rip, 0, 1))


def sith_basalt():
    """Carved dark basalt for statues and plinths: fine grain, pores and chisel marks, matte."""
    x, y = fm.coords()
    n = fm.fbm(2111, 6, 6)
    c = fm.mix(fm.col((48, 46, 52)), fm.col((96, 92, 100)), n)
    pores = fm.smooth(0.74, 0.82, fm.fbm(2112, 128, 2))
    c = c * (1 - 0.16 * pores)[..., None]
    chisel = 0.5 + 0.5 * np.sin((x * 14 + y * 6 + fm.fbm(2113, 4, 3) * 2) * 2 * math.pi)
    c = c * (0.92 + 0.1 * chisel)[..., None]
    return fm.rgba(c, np.clip(0.2 + 0.15 * n, 0, 1))


def sith_lava():
    """Molten lava (self-lit): dark crust plates floating on white-hot seams, glowing hot spots."""
    d1, d2, cid = _cells(2121, 7)
    n = fm.fbm(2122, 6, 5)
    crack = 1 - fm.smooth(0.0, 0.12 + 0.08 * n, d2 - d1)
    heat = np.clip(crack + 0.45 * fm.smooth(0.45, 0.9, n) + 0.15 * cid, 0, 1)
    crust = fm.mix(fm.col((56, 10, 4)), fm.col((128, 26, 6)), fm.fbm(2123, 16, 3))
    c = fm.mix(crust, fm.col((255, 100, 14)), heat)
    c = fm.mix(c, fm.col((255, 224, 130)), fm.smooth(0.72, 1.0, heat))
    return fm.rgba(c)


def sith_vein():
    """Lava veins and inlay channels (self-lit): bright orange to yellow-white, never dark."""
    n = fm.fbm(2131, 8, 4)
    c = fm.mix(fm.col((255, 72, 10)), fm.col((255, 206, 96)), fm.smooth(0.35, 0.75, n))
    return fm.rgba(c)


def sith_runes():
    """A panel of Sith runes (fit once, alpha = glow): angular glyphs in three columns between border lines, a
    glowing halo round every stroke."""
    x, y = fm.coords()
    r = np.random.default_rng(2141)
    strokes = [((-1, 1), (1, 1)), ((-1, -1), (1, -1)), ((-1, 0), (1, 0)), ((0, -1), (0, 1)), ((-1, -1), (-1, 1)), ((1, -1), (1, 1)),
               ((-1, -1), (1, 1)), ((-1, 1), (1, -1)), ((-1, 1), (0, -1)), ((0, -1), (1, 1)), ((-1, -1), (0, 1)), ((0, 1), (1, -1))]
    ink = np.zeros_like(x)
    for cx in (0.25, 0.5, 0.75):
        for cy in np.arange(0.11, 0.95, 0.105):
            for s in r.choice(len(strokes), 3, replace=False):
                (ax, ay), (bx, by) = strokes[s]
                d = _seg(x, y, (cx + ax * 0.075, cy + ay * 0.036), (cx + bx * 0.075, cy + by * 0.036), aspect=0.42)
                ink = np.maximum(ink, 1 - fm.smooth(0.004, 0.009, d))
    border = np.zeros_like(x)
    for bx in (0.08, 0.92):
        border = np.maximum(border, 1 - fm.smooth(0.004, 0.008, np.abs(x - bx)) * 1.0)
    for by in (0.035, 0.965):
        border = np.maximum(border, (1 - fm.smooth(0.002, 0.004, np.abs(y - by))) * ((x > 0.08) & (x < 0.92)))
    m = np.maximum(ink, border * 0.8)
    halo = np.zeros_like(m)
    for sh in (-3, -2, -1, 1, 2, 3):
        halo = np.maximum(halo, np.maximum(np.roll(m, sh * 2, axis=1), np.roll(m, sh * 2, axis=0)) * (1 - abs(sh) / 4))
    glow = np.clip(m + 0.45 * halo, 0, 1)
    c = fm.mix(fm.col((200, 20, 12)), fm.col((255, 180, 150)), m)
    return fm.rgba(c, glow * (0.9 + 0.1 * fm.fbm(2142, 8, 3)))


def sith_rune_band():
    """A single row of Sith runes for a wide band (fit once on a ~2.8:1 plate, alpha = glow), lines above and below."""
    x, y = fm.coords()
    r = np.random.default_rng(2241)
    strokes = [((-1, 1), (1, 1)), ((-1, -1), (1, -1)), ((-1, 0), (1, 0)), ((0, -1), (0, 1)), ((-1, -1), (-1, 1)), ((1, -1), (1, 1)),
               ((-1, -1), (1, 1)), ((-1, 1), (1, -1)), ((-1, 1), (0, -1)), ((0, -1), (1, 1))]
    ink = np.zeros_like(x)
    for cx in np.linspace(0.1, 0.9, 7):
        for s in r.choice(len(strokes), 3, replace=False):
            (ax, ay), (bx, by) = strokes[s]
            d = _seg(x, y, (cx + ax * 0.035, 0.5 + ay * 0.2), (cx + bx * 0.035, 0.5 + by * 0.2), aspect=2.8)
            ink = np.maximum(ink, 1 - fm.smooth(0.02, 0.04, d))
    lines = np.maximum(1 - fm.smooth(0.012, 0.025, np.abs(y - 0.12)), 1 - fm.smooth(0.012, 0.025, np.abs(y - 0.88)))
    m = np.maximum(ink, lines * 0.85) * (x > 0.03) * (x < 0.97)
    halo = np.zeros_like(m)
    for sh in (-3, -2, -1, 1, 2, 3):
        halo = np.maximum(halo, np.maximum(np.roll(m, sh, axis=1), np.roll(m, sh * 3, axis=0)) * (1 - abs(sh) / 4))
    c = fm.mix(fm.col((210, 20, 12)), fm.col((255, 176, 146)), m)
    return fm.rgba(c, np.clip(m + 0.45 * halo, 0, 1))


def sith_rune_ring():
    """A ring of Sith runes laid in the floor (fit once on a disc, alpha = glow): glyphs between two circles."""
    x, y = fm.coords()
    dx, dy = x - 0.5, 0.5 - y
    r = np.sqrt(dx * dx + dy * dy) * 2
    rings = (1 - fm.smooth(0.004, 0.009, np.abs(r - 0.92))) + (1 - fm.smooth(0.003, 0.007, np.abs(r - 0.64)))
    rng = np.random.default_rng(2231)
    strokes = [((-1, 1), (1, 1)), ((-1, -1), (1, -1)), ((0, -1), (0, 1)), ((-1, -1), (1, 1)), ((-1, 1), (1, -1)), ((-1, 1), (0, -1)),
               ((0, -1), (1, 1)), ((-1, 0), (1, 0))]
    ink = np.zeros_like(x)
    cnt = 16
    for k in range(cnt):
        a0 = 2 * math.pi * (k + 0.5) / cnt
        ca, sa = math.cos(a0), math.sin(a0)
        for s in rng.choice(len(strokes), 3, replace=False):
            (ax, ay), (bx, by) = strokes[s]
            # glyph frame: tangential (along the ring) x radial (across it)
            P0 = (0.5 + 0.5 * ((0.78 + ay * 0.075) * ca - ax * 0.055 * sa), 0.5 - 0.5 * ((0.78 + ay * 0.075) * sa + ax * 0.055 * ca))
            P1 = (0.5 + 0.5 * ((0.78 + by * 0.075) * ca - bx * 0.055 * sa), 0.5 - 0.5 * ((0.78 + by * 0.075) * sa + bx * 0.055 * ca))
            ink = np.maximum(ink, 1 - fm.smooth(0.003, 0.006, _seg(x, y, P0, P1)))
    m = np.clip(np.maximum(ink, rings), 0, 1) * (r < 0.97)
    halo = np.zeros_like(m)
    for sh in (-2, -1, 1, 2):
        halo = np.maximum(halo, np.maximum(np.roll(m, sh * 2, axis=1), np.roll(m, sh * 2, axis=0)) * (1 - abs(sh) / 3))
    c = fm.mix(fm.col((210, 20, 12)), fm.col((255, 170, 140)), m)
    return fm.rgba(c, np.clip(m + 0.4 * halo, 0, 1) * (r < 0.98))


def sith_holocron():
    """A holocron pane (self-lit, mapped per triangle (0,0)-(1,0)-(0.5,1)): nested triangles of red light round
    a burning centre."""
    x, y = fm.coords()
    v = 1 - y
    e0 = v
    e1 = (2 * (1 - x) - v) / math.sqrt(5)
    e2 = (2 * x - v) / math.sqrt(5)
    inner = np.minimum(np.minimum(e0, e1), e2)
    c = fm.col((86, 4, 6)) * (0.8 + 0.3 * fm.fbm(2151, 8, 3))[..., None]
    for d0, w in ((0.03, 0.012), (0.09, 0.008), (0.15, 0.006)):
        line = 1 - fm.smooth(w * 0.5, w, np.abs(inner - d0))
        c = fm.mix(c, fm.col((255, 70, 40)), line)
    core = fm.smooth(0.18, 0.30, inner)
    c = fm.mix(c, fm.col((255, 190, 150)), core)
    return fm.rgba(c)


def sith_kyber():
    """Red kyber crystal (self-lit): facet bands of different depth, a white-hot core streak, inclusions."""
    x, y = fm.coords()
    f = (x * 6) % 1.0
    k = np.floor(x * 6) % 6
    tone = np.array([0.75, 1.0, 0.6, 0.9, 0.7, 0.95], np.float32)[k.astype(int)]
    c = fm.col((210, 14, 26)) * (tone * (0.7 + 0.3 * np.abs(f - 0.5) * 2))[..., None]
    core = np.exp(-((f - 0.5) / 0.1) ** 2) * (0.4 + 0.6 * y)
    c = fm.mix(c, fm.col((255, 170, 160)), core * 0.55)
    inc = fm.smooth(0.7, 0.85, fm.fbm(2161, 8, 3))
    c = fm.mix(c, fm.col((120, 0, 10)), inc * 0.4)
    return fm.rgba(c)


def sith_blade():
    """Lightsaber blade glow (alpha = brightness): saturated red, a slight flicker along the blade."""
    x, y = fm.coords()
    flick = 0.9 + 0.1 * np.sin(y * 2 * math.pi * 6 + 2 * fm.fbm(2171, 4, 3))
    c = fm.col((255, 36, 26)) * flick[..., None]
    return fm.rgba(c, 0.78 * flick)


def sith_blade_core():
    """Lightsaber blade core (self-lit): white with a red-pink cast."""
    c = fm.col((255, 226, 222)) * (0.97 + 0.03 * fm.fbm(2181, 8, 2))[..., None]
    return fm.rgba(c)


def sith_metal():
    """Blackened steel: dark gunmetal with ring grooves along v (hilt grips), faint panel seams, a rust-red tint."""
    x, y = fm.coords()
    n = fm.fbm(2191, 8, 4)
    c = fm.col((50, 48, 54)) * (0.8 + 0.4 * n)[..., None]
    ridges = fm.grooves(y, 1 / 16, 0.012)
    seam, light = fm.bevel_panels(x, y, 2, 4, 0.006)
    c = c * (1 - 0.5 * ridges - 0.35 * seam)[..., None] * (1 + 0.18 * light)[..., None]
    c = fm.mix(c, fm.col((80, 30, 26)), fm.smooth(0.7, 0.9, fm.fbm(2192, 6, 4)) * 0.3)
    return fm.rgba(c, np.clip(0.7 - 0.4 * ridges, 0, 1))


def sith_velvet():
    """Crimson-black velvet, channel tufted, a soft sheen."""
    x, y = fm.coords()
    n = fm.fbm(2201, 8, 5)
    u, v = (x + y) * 4 % 1.0, (x - y) * 4 % 1.0
    tuft = np.minimum(np.minimum(u, 1 - u), np.minimum(v, 1 - v))
    puff = fm.smooth(0.0, 0.25, tuft)
    c = fm.col((96, 6, 14)) * (0.45 + 0.55 * puff)[..., None] * (0.9 + 0.2 * n)[..., None]
    return fm.rgba(c, 0.2 + 0.4 * puff)


def sith_glow():
    """Soft red-orange glow halo (fit once, alpha = brightness)."""
    x, y = fm.coords()
    d = np.sqrt((x - 0.5) ** 2 + (y - 0.5) ** 2) * 2
    c = fm.mix(fm.col((255, 150, 90)), fm.col((220, 30, 10)), fm.smooth(0.0, 0.6, d))
    return fm.rgba(c, np.clip(1 - d, 0, 1) ** 2 * 0.8)


def sith_void():
    """The dark inside of a hood (near-black, faintly mottled)."""
    c = fm.col((10, 7, 10)) * (0.7 + 0.6 * fm.fbm(2211, 4, 4))[..., None]
    return fm.rgba(c)


def sith_fire():
    """Red candle flame (self-lit, on closed flame meshes): white-pink root, crimson body, dark red tips."""
    x, y = fm.coords()
    v = 1 - y
    row = fm.fbm(2221, 16, 3)[0]
    heat = np.clip(1.08 - v * (0.95 + 0.5 * (row[None, :] - 0.5)), 0, 1)
    c = fm.mix(fm.col((110, 4, 6)), fm.col((240, 30, 20)), fm.smooth(0.12, 0.5, heat))
    c = fm.mix(c, fm.col((255, 150, 120)), fm.smooth(0.6, 0.85, heat))
    c = fm.mix(c, fm.col((255, 236, 228)), fm.smooth(0.85, 1.0, heat))
    return fm.rgba(c)


MATS = {
    "sith_obsidian": ("a_specmap", sith_obsidian, 0.8, 45),
    "sith_basalt": ("a_specmap", sith_basalt, 0.2, 10),
    "sith_lava": ("a_emis_full", sith_lava, 0, 0),
    "sith_vein": ("a_emis_full", sith_vein, 0, 0),
    "sith_runes": ("a_alpha_emis_full", sith_runes, 0, 0),
    "sith_holocron": ("a_emis_full", sith_holocron, 0, 0),
    "sith_kyber": ("a_emis_full", sith_kyber, 0, 0),
    "sith_blade": ("a_alpha_emis_full", sith_blade, 0, 0),
    "sith_blade_core": ("a_emis_full", sith_blade_core, 0, 0),
    "sith_metal": ("a_specmap", sith_metal, 0.6, 35),
    "sith_velvet": ("a_specmap", sith_velvet, 0.35, 12),
    "sith_glow": ("a_alpha_emis_full", sith_glow, 0, 0),
    "sith_void": ("a_simple", sith_void, 0, 0),
    "sith_fire": ("a_emis_full", sith_fire, 0, 0),
    "sith_rune_ring": ("a_alpha_emis_full", sith_rune_ring, 0, 0),
    "sith_rune_band": ("a_alpha_emis_full", sith_rune_band, 0, 0),
}

INFO = {
    "sith_dark_shrine": ("interact", "Sith Dark Shrine",
                         "A kneeling stone before an obsidian stele carved with glowing Sith runes, a holocron burning "
                         "red above its pedestal. Kneel and let the dark side whisper; it has a great deal to say about "
                         "your enemies."),
    "sith_throne": ("seat", "Sith Obsidian Throne",
                    "An angular throne cut from Mustafar obsidian, its seams running with living lava under a crown of "
                    "black blades. Comfortable? No. Intimidating? Extremely."),
    "sith_lava_brazier": ("lamp", "Mustafar Lava Brazier",
                          "A faceted obsidian bowl brimming with molten lava, standing on four iron talons. Lights a "
                          "room in the warm, reassuring red of an active volcano."),
    "sith_hooded_statue": ("decor", "Hooded Sith Statue",
                           "A towering basalt Sith lord, face lost in the shadow of his hood, hands folded over the "
                           "pommel of an ancient sword. Something in that darkness is still watching."),
    "sith_saber_rack": ("decor", "Sith Saber Rack",
                        "Crossed crimson lightsabers - one straight, one elegantly curved - beneath a double-bladed "
                        "staff, with a tray of bled kyber crystals. Trophies, or warnings."),
    "sith_obsidian_table": ("table", "Obsidian Lava Table",
                            "A low table of polished obsidian, channels of molten lava glowing through its top in the "
                            "pattern of an old Sith sigil. Coasters strongly recommended."),
}

LIGHTS = {
    "sith_lava_brazier": [{"hardpoint": "light", "type": 1, "rgb": (0.0050, 0.0018, 0.0006), "range": 10.0, "constant": 0.0,
                           "linear": 0.00195, "quadratic": 0.0, "flags": 0}],
}
