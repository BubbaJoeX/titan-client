"""Mos Eisley cantina set (group `can`), host side: materials, names and descriptions, the neon sign's lights.
Geometry: maya/swg_mcp/frn_groups/can.py."""
from __future__ import annotations

import math

import numpy as np

import frn_materials as fm

N = fm.N


def _rng(seed):
    return np.random.default_rng(seed)


def _scratches(seed, count=60, length=0.15, width=0.0015):
    """Thin random scratch lines (tileable by wrapping), 0..1 mask."""
    x, y = fm.coords()
    r = _rng(seed)
    m = np.zeros_like(x)
    for _ in range(count):
        cx, cy, a = r.random(), r.random(), r.random() * math.pi
        ln = length * (0.3 + r.random())
        dx, dy = ((x - cx + 0.5) % 1.0) - 0.5, ((y - cy + 0.5) % 1.0) - 0.5
        along = dx * math.cos(a) + dy * math.sin(a)
        across = -dx * math.sin(a) + dy * math.cos(a)
        m = np.maximum(m, (np.abs(across) < width) * (np.abs(along) < ln / 2) * (0.4 + 0.6 * r.random()))
    return m


# ---------------------------------------------------------------------------------------------------------------
# adobe, metal
# ---------------------------------------------------------------------------------------------------------------

def can_adobe():
    """Tan adobe plaster: trowel swirls, fine grit, hairline cracks, a little sand-blown grime."""
    x, y = fm.coords()
    swirl = fm.fbm(701, 3, 4)
    grit = fm.fbm(702, 64, 2)
    c = fm.mix(fm.col((198, 170, 128)), fm.col((226, 202, 162)), 0.45 * swirl + 0.3 * grit + 0.25 * fm.fbm(703, 12, 3))
    trowel = 0.5 + 0.5 * np.sin((x * 3 + y * 2 + swirl * 2.5) * 2 * math.pi)
    c = c * (0.96 + 0.06 * trowel)[..., None]
    pits = (fm.fbm(704, 96, 1) > 0.80).astype(np.float32) * fm.smooth(0.4, 0.7, fm.fbm(705, 4, 3))
    c = c * (1 - 0.18 * pits)[..., None]
    grime = fm.smooth(0.62, 0.85, fm.fbm(706, 4, 5))
    c = fm.mix(c, fm.col((160, 128, 92)), grime * 0.25)
    return fm.rgba(c)


def can_metal():
    """Worn brushed steel: brushing along u, scratches, dull stains, a few dents."""
    x, y = fm.coords()
    r = _rng(711).random(N).astype(np.float32)
    for _ in range(2):
        r = (r + np.roll(r, 1) + np.roll(r, -1)) / 3
    brush = np.broadcast_to(r[:, None], (N, N))
    c = fm.col((150, 152, 150)) * (0.85 + 0.25 * brush + 0.1 * fm.fbm(712, 8, 3))[..., None]
    sc = _scratches(713, 90, 0.18, 0.0012)
    c = c * (1 + 0.25 * sc)[..., None]
    stain = fm.smooth(0.55, 0.8, fm.fbm(714, 4, 5))
    c = fm.mix(c, fm.col((96, 88, 76)), stain * 0.45)
    return fm.rgba(c, 0.65 - 0.35 * stain + 0.2 * sc)


def can_panel():
    """Mos Eisley tech panelling: faded blue-grey paint worn to bare metal at the seams, rivets, vent slots, rust
    streaks."""
    x, y = fm.coords()
    seam, light = fm.bevel_panels(x, y, 2, 2, 0.006)
    paint = fm.col((104, 116, 118)) * (0.9 + 0.14 * fm.fbm(721, 8, 4))[..., None]
    near_seam = np.maximum(1 - fm.smooth(0.0, 0.05, (x * 2) % 1.0), 1 - fm.smooth(0.0, 0.05, 1 - (x * 2) % 1.0))
    near_seam = np.maximum(near_seam, np.maximum(1 - fm.smooth(0.0, 0.05, (y * 2) % 1.0), 1 - fm.smooth(0.0, 0.05, 1 - (y * 2) % 1.0)))
    wear = fm.smooth(0.74, 0.8, fm.fbm(722, 24, 4) + 0.18 * near_seam)
    c = fm.mix(paint, fm.col((150, 146, 136)), wear * 0.8)
    dust = fm.smooth(0.55, 1.0, (y * 2) % 1.0) * (0.6 + 0.4 * fm.fbm(724, 8, 3))
    c = fm.mix(c, fm.col((150, 128, 96)), dust * 0.28)
    rv = np.zeros_like(x)
    for k in range(6):
        t = (k + 0.5) / 6
        for cx, cy in ((t, 0.03), (t, 0.53), (0.03, t), (0.53, t)):
            rv = np.maximum(rv, fm.disc_mask(x, y, cx, cy, 0.007, 0.003))
    vents = ((((x * 2) % 1.0) > 0.18) & (((x * 2) % 1.0) < 0.82) & (((y * 24) % 1.0) < 0.45) & (((y * 2) % 1.0) > 0.62) &
             (((y * 2) % 1.0) < 0.92) & (x < 0.5)).astype(np.float32)
    rust = fm.smooth(0.6, 0.9, fm.fbm(723, 3, 4)) * (0.5 + 0.5 * np.sin(x * 2 * math.pi * 24) ** 2) * fm.smooth(0.3, 1.0, (y * 2) % 1.0)
    c = c * (1 - 0.55 * seam)[..., None] * (1 + 0.12 * light)[..., None]
    c = fm.mix(c, fm.col((40, 44, 46)), vents * 0.85)
    c = fm.mix(c, fm.col((120, 70, 40)), rust * 0.35)
    c = fm.mix(c, fm.col((60, 64, 62)), rv * 0.8)
    return fm.rgba(c, 0.3 + 0.4 * wear + 0.2 * rv)


def can_deck():
    """Riser deck plate: diamond tread steel, scuffed."""
    x, y = fm.coords()
    u, v = (x * 10) % 1.0, (y * 10) % 1.0
    k = (np.floor(x * 10) + np.floor(y * 10)) % 2
    ax = np.where(k == 0, np.abs((u - 0.5) + (v - 0.5)), np.abs((u - 0.5) - (v - 0.5)))
    perp = np.where(k == 0, np.abs((u - 0.5) - (v - 0.5)), np.abs((u - 0.5) + (v - 0.5)))
    bump = (ax < 0.09) & (perp < 0.5)
    c = fm.col((110, 112, 110)) * (0.85 + 0.2 * fm.fbm(731, 8, 4))[..., None]
    c = c * (1 + 0.25 * bump)[..., None]
    scuff = fm.smooth(0.55, 0.8, fm.fbm(732, 6, 4))
    c = fm.mix(c, fm.col((70, 64, 56)), scuff * 0.4)
    return fm.rgba(c, 0.4 + 0.3 * bump)


# ---------------------------------------------------------------------------------------------------------------
# lights, neon, screens
# ---------------------------------------------------------------------------------------------------------------

def _tube(rgb, hot, seed):
    x, y = fm.coords()
    core = np.exp(-((x - 0.5) / 0.28) ** 2)
    c = fm.mix(fm.col(rgb), fm.col(hot), core * 0.55)
    return fm.rgba(c * (0.94 + 0.08 * fm.fbm(seed, 4, 2))[..., None])


def can_neon_m():
    return _tube((255, 50, 190), (255, 200, 240), 741)


def can_neon_c():
    return _tube((40, 220, 255), (210, 250, 255), 742)


def can_amber():
    """Warm amber lamp glass / light strip (self-lit)."""
    x, y = fm.coords()
    c = fm.mix(fm.col((255, 140, 40)), fm.col((255, 214, 140)), fm.fbm(743, 4, 3) * 0.7)
    return fm.rgba(c)


def can_screen():
    """Self-lit readout: amber text lines, a green trace, bar meters on a dark glass."""
    x, y = fm.coords()
    c = fm.col((10, 14, 12))
    grid = np.maximum(fm.lines(x, 1 / 12, 0.003), fm.lines(y, 1 / 8, 0.003))
    c = fm.mix(c, fm.col((30, 60, 40)), grid * 0.5)
    text = (((x * 40) % 1.0) < 0.6) & (((y * 16) % 1.0) < 0.45) & (y < 0.45) & (x < 0.55) & \
           (fm.fbm(744, 32, 1)[:, :1].repeat(N, 1) + fm.fbm(745, 16, 1) > 0.9)
    c = fm.mix(c, fm.col((255, 170, 60)), text.astype(np.float32))
    trace = np.abs((1 - y) - (0.72 + 0.12 * np.sin(x * 2 * math.pi * 3) * np.cos(x * 2 * math.pi * 1.3))) < 0.012
    c = fm.mix(c, fm.col((90, 255, 140)), (trace & (x > 0.05) & (x < 0.95)).astype(np.float32))
    bars = (x > 0.62) & (x < 0.95) & (((x * 14) % 1.0) < 0.6) & (y > 0.08) & (y < 0.45)
    lvl = 0.45 - 0.3 * fm.fbm(746, 16, 1)[:1, :].repeat(N, 0)
    c = fm.mix(c, fm.col((255, 70, 180)), (bars & (y > lvl)).astype(np.float32))
    return fm.rgba(c)


# ---------------------------------------------------------------------------------------------------------------
# glass, drinks
# ---------------------------------------------------------------------------------------------------------------

def _bottle(glass, label, seed):
    """Glossy bottle glass with a paper label band (v spans the bottle's profile once: bottom 0, cap 1)."""
    x, y = fm.coords()
    v = 1 - y
    c = fm.col(glass) * (0.75 + 0.35 * fm.fbm(seed, 4, 3))[..., None]
    hl = np.exp(-((x - 0.22) / 0.035) ** 2) + 0.4 * np.exp(-((x - 0.30) / 0.015) ** 2)
    c = c + fm.col((255, 255, 255)) * (hl * 0.45)[..., None]
    lab = (v > 0.20) & (v < 0.50) & (x > 0.42) & (x < 0.98)
    paper = fm.col(label) * (0.85 + 0.2 * fm.fbm(seed + 1, 16, 3))[..., None]
    border = ((np.abs(v - 0.215) < 0.006) | (np.abs(v - 0.485) < 0.006))
    glyph = ((((x * 30) % 1.0) < 0.55) & (np.abs(v - 0.35) < 0.035) & (fm.fbm(seed + 2, 32, 1) > 0.45)) | \
            (fm.disc_mask(x, y, 0.70, 1 - 0.40, 0.045, 0.004) > 0.5) & ~(fm.disc_mask(x, y, 0.70, 1 - 0.40, 0.03, 0.004) > 0.5)
    paper = fm.mix(paper, fm.col((60, 30, 20)), (border | glyph).astype(np.float32) * 0.85)
    c = fm.mix(c, paper, lab.astype(np.float32))
    return fm.rgba(c, np.where(lab, 0.2, 0.9))


def can_bottle_g():
    return _bottle((40, 110, 60), (220, 200, 150), 751)


def can_bottle_a():
    return _bottle((150, 80, 20), (200, 60, 50), 754)


def can_bottle_r():
    return _bottle((110, 20, 50), (230, 220, 200), 757)


def can_frost():
    """Frosted glass (read as glass at a glance, opaque so it never shows culled faces): pale ice, streaks."""
    x, y = fm.coords()
    c = fm.mix(fm.col((170, 196, 206)), fm.col((226, 240, 246)), fm.fbm(761, 8, 4))
    hl = np.exp(-((x - 0.25) / 0.04) ** 2)
    c = c + fm.col((255, 255, 255)) * (hl * 0.3)[..., None]
    return fm.rgba(c, 0.85)


def _drink(base, hot, seed):
    x, y = fm.coords()
    n = fm.fbm(seed, 4, 4)
    c = fm.mix(fm.col(base), fm.col(hot), n)
    bub = np.zeros_like(x)
    r = _rng(seed + 1)
    for _ in range(30):
        bub = np.maximum(bub, fm.disc_mask(x, y, r.random(), r.random(), 0.01 + 0.015 * r.random(), 0.006))
    return fm.rgba(fm.mix(c, fm.col((255, 255, 255)), bub * 0.6))


def can_drink():
    """A glowing blue cocktail surface (self-lit)."""
    return _drink((40, 140, 255), (140, 230, 255), 771)


def can_drink2():
    """A glowing Tatooine Sunset: orange into pink (self-lit)."""
    return _drink((255, 110, 40), (255, 90, 170), 774)


# ---------------------------------------------------------------------------------------------------------------
# upholstery, gaming
# ---------------------------------------------------------------------------------------------------------------

def can_leather():
    """Booth upholstery: worn rust-brown leather in puffed channels (seams across v), cracked and rubbed pale."""
    x, y = fm.coords()
    v = (y * 4) % 1.0
    puff = np.sin(v * math.pi) ** 0.5
    c = fm.col((120, 58, 34)) * (0.55 + 0.55 * puff)[..., None] * (0.9 + 0.2 * fm.fbm(781, 32, 3))[..., None]
    seam = (v < 0.03) | (v > 0.97)
    stitch = (np.abs(v - 0.06) < 0.01) & (((x * 60) % 1.0) < 0.5) | (np.abs(v - 0.94) < 0.01) & (((x * 60) % 1.0) < 0.5)
    c = c * (1 - 0.6 * seam)[..., None]
    c = fm.mix(c, fm.col((200, 170, 120)), stitch.astype(np.float32) * 0.6)
    crack = 1 - fm.smooth(0.0, 0.01, np.abs(fm.fbm(782, 12, 4) - 0.5))
    rub = fm.smooth(0.6, 0.85, fm.fbm(783, 5, 4)) * puff
    c = fm.mix(c, fm.col((60, 30, 18)), crack * 0.35)
    c = fm.mix(c, fm.col((176, 120, 84)), rub * 0.4)
    return fm.rgba(c, 0.25 + 0.35 * puff - 0.2 * rub)


def _chip(base, seed):
    """A chip stack texture: 8 chips per tile along v, white edge spots round u, dark gaps."""
    x, y = fm.coords()
    k = np.floor(y * 8)
    v = (y * 8) % 1.0
    c = fm.col(base) * (0.9 + 0.15 * fm.fbm(seed, 16, 2))[..., None]
    spot = (((x * 8 + 0.5 * (k % 2)) % 1.0) < 0.35) & (v > 0.2) & (v < 0.8)
    c = fm.mix(c, fm.col((240, 236, 226)), spot.astype(np.float32))
    gap = (v < 0.08) | (v > 0.92)
    c = c * (1 - 0.5 * gap)[..., None]
    return fm.rgba(c, 0.5)


def can_chip_r():
    return _chip((180, 30, 34), 791)


def can_chip_b():
    return _chip((30, 70, 170), 792)


def can_chip_y():
    return _chip((220, 170, 40), 793)


def can_card():
    """Sabacc card back (fit once per face): navy field, gold border, a diamond emblem and corner pips."""
    x, y = fm.coords()
    c = fm.col((20, 30, 70)) * (0.9 + 0.15 * fm.fbm(801, 32, 2))[..., None]
    d = np.minimum(np.minimum(x, 1 - x), np.minimum(y, 1 - y))
    border = (d > 0.05) & (d < 0.09)
    dia = np.abs(x - 0.5) + np.abs(y - 0.5)
    emblem = ((dia > 0.16) & (dia < 0.22)) | (dia < 0.07)
    hatch = (((x + y) * 20) % 1.0 < 0.15) & (d > 0.09)
    c = fm.mix(c, fm.col((40, 54, 110)), hatch.astype(np.float32))
    c = fm.mix(c, fm.col((220, 180, 80)), (border | emblem).astype(np.float32))
    edge = d < 0.035
    c = fm.mix(c, fm.col((236, 232, 220)), edge.astype(np.float32))
    return fm.rgba(c, 0.4)


def can_felt():
    """Sabacc felt (fit on the annulus, centre 0.5 0.5, texture angle = world angle): crimson felt, gold rings,
    six player boxes at 90 + 60k degrees, the four suit symbols between them."""
    x, y = fm.coords()
    dx, dy = x - 0.5, y - 0.5
    r = np.sqrt(dx * dx + dy * dy)
    c = fm.col((112, 22, 34)) * (0.85 + 0.15 * fm.fbm(811, 64, 2) + 0.1 * fm.fbm(812, 4, 3))[..., None]
    gold = (np.abs(r - 0.475) < 0.004) | (np.abs(r - 0.455) < 0.0025) | (np.abs(r - 0.33) < 0.003) | (np.abs(r - 0.175) < 0.004)
    m = gold.copy()
    for k in range(6):
        ang = math.radians(90 + 60 * k)
        ca, sa = math.cos(ang), math.sin(ang)
        rad = dx * ca + dy * sa
        tan = -dx * sa + dy * ca
        box = (np.abs(np.abs(tan) - 0.085) < 0.003) & (np.abs(rad - 0.375) < 0.058) | \
              (np.abs(np.abs(rad - 0.375) - 0.058) < 0.003) & (np.abs(tan) < 0.088)
        m |= box
        sym = math.radians(120 + 60 * k)
        sx, sy = 0.40 * math.cos(sym), 0.40 * math.sin(sym)
        ex, ey = dx - sx, dy - sy
        kind = k % 4
        if kind == 0:      # coins: ring
            s = np.abs(np.sqrt(ex * ex + ey * ey) - 0.022) < 0.004
        elif kind == 1:    # flasks: triangle
            s = (ey < 0.02) & (ey > -0.022) & (np.abs(ex) < (0.02 - ey) * 0.6) & ~((ey < 0.012) & (ey > -0.014) & (np.abs(ex) < (0.012 - ey) * 0.45))
        elif kind == 2:    # staves: three bars
            s = (np.abs(ey) < 0.024) & (np.abs(((ex + 0.03) % 0.02) - 0.01) < 0.003) & (np.abs(ex) < 0.024)
        else:              # sabres: crossed blades
            s = ((np.abs(ex - ey) < 0.005) | (np.abs(ex + ey) < 0.005)) & (np.abs(ex) < 0.022) & (np.abs(ey) < 0.022)
        m |= s
    c = fm.mix(c, fm.col((214, 170, 78)), m.astype(np.float32))
    return fm.rgba(c)


def can_dejarik():
    """Dejarik board (fit on the disc): a dark centre, an inner and an outer ring of twelve alternating ivory and
    teal cells offset by half a cell, gold dividers, a black rim."""
    x, y = fm.coords()
    dx, dy = x - 0.5, y - 0.5
    r = np.sqrt(dx * dx + dy * dy) * 2
    a = (np.arctan2(dy, dx) / (2 * math.pi)) % 1.0
    ivory, teal = fm.col((214, 198, 150)), fm.col((34, 74, 66))
    inner = (np.floor(a * 12) % 2 == 0)
    outer = (np.floor(a * 12 + 0.5) % 2 == 0)
    c = np.where(((r < 0.58) & inner | (r >= 0.58) & outer)[..., None], ivory, teal)
    c = np.where((r < 0.26)[..., None], fm.col((28, 40, 44)), c)
    c = c * (0.9 + 0.12 * fm.fbm(821, 16, 3))[..., None]
    div = (np.abs(r - 0.26) < 0.008) | (np.abs(r - 0.58) < 0.007) | (np.abs(r - 0.93) < 0.008)
    spokes = (np.minimum((a * 12) % 1.0, 1 - (a * 12) % 1.0) * r * 2 * math.pi / 12 < 0.004) & (r > 0.26) & (r < 0.58)
    spokes2 = (np.minimum((a * 12 + 0.5) % 1.0, 1 - (a * 12 + 0.5) % 1.0) * r * 2 * math.pi / 12 < 0.004) & (r > 0.58) & (r < 0.93)
    c = fm.mix(c, fm.col((200, 160, 70)), (div | spokes | spokes2).astype(np.float32))
    c = np.where((r > 0.95)[..., None], fm.col((18, 18, 20)), c)
    return fm.rgba(c, 0.55)


def _holo_skin(tint, seed, alpha=None):
    """Hologram creature skin: scales, scanlines; alpha = brightness when used on a_alpha_emis_full."""
    x, y = fm.coords()
    u, v = (x * 10) % 1.0, (y * 10 + 0.5 * (np.floor(x * 10) % 2)) % 1.0
    scale = np.sqrt((u - 0.5) ** 2 + (v - 0.3) ** 2)
    edge = fm.smooth(0.35, 0.5, scale)
    scan = 0.7 + 0.3 * np.sin(y * N * math.pi / 3)
    c = fm.col(tint) * (0.75 + 0.35 * (1 - edge))[..., None] * scan[..., None]
    c = c + fm.col((255, 255, 255)) * (edge * 0.25)[..., None]
    if alpha is None:
        return fm.rgba(c)
    return fm.rgba(c, (alpha + 0.3 * edge) * scan)


def can_holo_a():
    return _holo_skin((255, 150, 60), 831, alpha=0.35)


def can_holo_b():
    return _holo_skin((80, 255, 170), 832, alpha=0.35)


def can_holo_core_a():
    return _holo_skin((200, 90, 30), 833)


def can_holo_core_b():
    return _holo_skin((30, 180, 120), 834)


def can_grille():
    """Speaker / instrument grille (fit once): perforated mesh over a woofer and a tweeter, a metal frame."""
    x, y = fm.coords()
    holes = (((x * 60) % 1.0 - 0.5) ** 2 + ((y * 60) % 1.0 - 0.5) ** 2) < 0.09
    c = fm.col((34, 34, 36)) * (1 - 0.4 * holes)[..., None]
    for cx, cy, rr in ((0.5, 0.62, 0.30), (0.5, 0.2, 0.12)):
        d = np.sqrt(((x - cx) * 1.0) ** 2 + ((y - cy) * 0.55) ** 2)
        cone = (d < rr) * (0.5 + 0.5 * np.cos(d / rr * math.pi * 3))
        c = c + fm.col((40, 40, 44)) * (cone * 0.6)[..., None]
    d = np.minimum(np.minimum(x, 1 - x), np.minimum(y, 1 - y))
    frame = d < 0.03
    c = fm.mix(c, fm.col((140, 140, 136)), frame.astype(np.float32))
    return fm.rgba(c, 0.3 + 0.4 * frame)


def can_keys():
    """Ommni box keyboard (fit once): two staggered rows of rounded keys in ivory and black, coloured pads."""
    x, y = fm.coords()
    c = fm.col((24, 24, 26))
    v = 1 - y
    for row, (v0, v1, off, col_) in enumerate(((0.08, 0.46, 0.0, (226, 220, 204)), (0.54, 0.92, 0.5, (40, 40, 44)))):
        inrow = (v > v0) & (v < v1)
        k = ((x * 18 + off) % 1.0)
        key = inrow & (k > 0.1) & (k < 0.9)
        c = fm.mix(c, fm.col(col_) * (0.9 + 0.15 * (1 - np.abs(k - 0.5) * 2))[..., None], key.astype(np.float32))
    pads = (v > 0.55) & (v < 0.9) & (x > 0.86) & (((x * 36) % 1.0) < 0.7)
    c = fm.mix(c, fm.col((255, 80, 160)), pads.astype(np.float32))
    return fm.rgba(c, 0.5)


MATS = {
    "can_adobe": ("a_simple", can_adobe, 0, 0),
    "can_metal": ("a_specmap", can_metal, 0.7, 28),
    "can_panel": ("a_specmap", can_panel, 0.45, 20),
    "can_deck": ("a_specmap", can_deck, 0.5, 24),
    "can_neon_m": ("a_emis_full", can_neon_m, 0, 0),
    "can_neon_c": ("a_emis_full", can_neon_c, 0, 0),
    "can_amber": ("a_emis_full", can_amber, 0, 0),
    "can_screen": ("a_emis_full", can_screen, 0, 0),
    "can_bottle_g": ("a_specmap", can_bottle_g, 0.9, 60),
    "can_bottle_a": ("a_specmap", can_bottle_a, 0.9, 60),
    "can_bottle_r": ("a_specmap", can_bottle_r, 0.9, 60),
    "can_frost": ("a_specmap", can_frost, 0.8, 50),
    "can_drink": ("a_emis_full", can_drink, 0, 0),
    "can_drink2": ("a_emis_full", can_drink2, 0, 0),
    "can_leather": ("a_specmap", can_leather, 0.35, 16),
    "can_chip_r": ("a_specmap", can_chip_r, 0.5, 30),
    "can_chip_b": ("a_specmap", can_chip_b, 0.5, 30),
    "can_chip_y": ("a_specmap", can_chip_y, 0.5, 30),
    "can_card": ("a_specmap", can_card, 0.4, 25),
    "can_felt": ("a_simple", can_felt, 0, 0),
    "can_dejarik": ("a_specmap", can_dejarik, 0.6, 35),
    "can_holo_a": ("a_alpha_emis_full", can_holo_a, 0, 0),
    "can_holo_b": ("a_alpha_emis_full", can_holo_b, 0, 0),
    "can_holo_core_a": ("a_emis_full", can_holo_core_a, 0, 0),
    "can_holo_core_b": ("a_emis_full", can_holo_core_b, 0, 0),
    "can_grille": ("a_specmap", can_grille, 0.4, 20),
    "can_keys": ("a_specmap", can_keys, 0.5, 30),
}

INFO = {
    "can_bar_counter": ("interact", "Mos Eisley Bar Counter",
                        "A curved section of the most wretched bar in the galaxy: adobe front, a worn metal top, brass "
                        "taps and a drink-mixing drum. Sit to take your place behind it and wipe the counter. No droids."),
    "can_booth": ("seat", "Cantina Alcove Booth",
                  "A padded booth curled into an adobe niche under a neon arch, with a round table for drinks and "
                  "quiet negotiations. Shoot first, then order."),
    "can_neon_sign": ("lamp", "Cantina Neon Sign",
                      "A freestanding double-sided neon sign: a cyan cocktail glass and five magenta Aurebesh glyphs "
                      "that, roughly translated, mean 'drinks'. Or 'trinks'. The tube-bender was a Jawa."),
    "can_dejarik_table": ("table", "Dejarik Holochess Table",
                          "A holochess table with six holographic monsters squaring off on the checker-ring board. "
                          "House rule: let the Wookiee win."),
    "can_band_stand": ("decor", "Bith Band Stand",
                       "A small stage riser set for a Bith band: an ommni box, a kloo horn and a three-belled fanfar on "
                       "their stands, speakers at the back. They only know one song, but they know it very well."),
    "can_sabacc_table": ("table", "Sabacc Table",
                         "A round sabacc table with a padded rail ringed in amber lamps, six player stations, chip "
                         "stacks and the dealer's well round the glowing shifter. Bring credits; leave a ship."),
}

LIGHTS = {
    "can_neon_sign": [
        {"hardpoint": "light", "type": 1, "rgb": (0.0046, 0.0012, 0.0040), "range": 10.0, "constant": 0.0,
         "linear": 0.00195, "quadratic": 0.0, "flags": 0},
        {"hardpoint": "light1", "type": 1, "rgb": (0.0010, 0.0040, 0.0046), "range": 10.0, "constant": 0.0,
         "linear": 0.00195, "quadratic": 0.0, "flags": 0},
    ],
}
