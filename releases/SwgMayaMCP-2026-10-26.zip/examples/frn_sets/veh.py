"""Vessel cabin fittings (group `veh`), host side: materials, names and descriptions.
Geometry: maya/swg_mcp/frn_groups/veh.py."""
from __future__ import annotations

import math

import numpy as np

import frn_materials as fm

N = fm.N


def veh_housing():
    """Graphite powder-coat: a fine orange-peel texture, faint wipe marks."""
    x, y = fm.coords()
    c = fm.col((52, 55, 60)) * (0.92 + 0.1 * fm.fbm(901, 48, 2) + 0.05 * fm.fbm(902, 6, 3))[..., None]
    wipe = fm.smooth(0.6, 0.85, fm.fbm(903, 3, 4))
    c = fm.mix(c, fm.col((70, 73, 78)), wipe * 0.25)
    return fm.rgba(c, 0.45 + 0.1 * fm.fbm(904, 16, 2))


def veh_bezel():
    """Satin black bezel: smoother than the housing, a soft sheen along u."""
    x, y = fm.coords()
    c = fm.col((24, 25, 28)) * (0.95 + 0.06 * fm.fbm(911, 32, 2))[..., None]
    sheen = 0.5 + 0.5 * np.sin(x * 2 * math.pi)
    c = c * (0.95 + 0.08 * sheen)[..., None]
    return fm.rgba(c, 0.7)


def veh_trim():
    """The cabin's beige trim plastic, matching the stock panelling: lightly mottled, scuffed at random."""
    c = fm.mix(fm.col((176, 156, 120)), fm.col((196, 178, 142)), 0.5 * fm.fbm(921, 8, 4) + 0.3 * fm.fbm(922, 48, 2))
    scuff = fm.smooth(0.7, 0.9, fm.fbm(923, 16, 3))
    c = fm.mix(c, fm.col((140, 124, 96)), scuff * 0.3)
    return fm.rgba(c, 0.25)


def veh_lamp():
    """The power lamp: soft green."""
    x, y = fm.coords()
    d = np.sqrt((x - 0.5) ** 2 + (y - 0.5) ** 2)
    c = fm.mix(fm.col((150, 255, 170)), fm.col((40, 200, 90)), fm.smooth(0.1, 0.5, d))
    return fm.rgba(c)


def veh_speaker_grille():
    """Perforated steel grille: a hex grid of holes on brushed grey, dark behind the holes, a darker rim."""
    x, y = fm.coords()
    cells = 28.0
    gx, gy = x * cells, y * cells * 0.866
    row = np.floor(gy)
    gx = gx + 0.5 * (row % 2)
    dx, dy = gx - np.floor(gx) - 0.5, (gy - row) - 0.5
    hole = (np.sqrt(dx * dx + dy * dy) < 0.28).astype(np.float32)
    metal = fm.col((128, 131, 134)) * (0.9 + 0.12 * fm.fbm(931, 64, 2))[..., None]
    c = fm.mix(metal, fm.col((18, 18, 20)), hole * 0.9)
    r = np.sqrt((x - 0.5) ** 2 + (y - 0.5) ** 2)
    c = c * (1 - 0.35 * fm.smooth(0.42, 0.5, r))[..., None]
    return fm.rgba(c, 0.5)


def veh_monitor_screen():
    """Standby picture (until the in-flight entertainment tunes in): a deep blue gradient, a dim transport
    silhouette with a route arc, and the status bar."""
    x, y = fm.coords()
    xs = (x - 0.5) * 1.78
    ys = y - 0.55
    hull = ((np.abs(xs) < 0.26) & (np.abs(ys) < 0.045 - 0.12 * np.abs(xs) * 0.2)).astype(np.float32)
    fin = ((np.abs(xs - 0.0) < 0.012) & (ys > -0.12) & (ys < 0.0)).astype(np.float32)
    d = np.sqrt(xs ** 2 + (ys + 0.25) ** 2)
    arc = ((np.abs(d - 0.42) < 0.006) & (ys < 0.05)).astype(np.float32)
    m = np.clip(hull + fin + arc * 0.7, 0, 1)
    return fm._standby((10, 18, 34), (120, 170, 230), m, (90, 160, 230))


MATS = {
    "veh_housing": ("a_specmap", veh_housing, 0.35, 18),
    "veh_bezel": ("a_specmap", veh_bezel, 0.5, 30),
    "veh_trim": ("a_simple", veh_trim, 0, 0),
    "veh_lamp": ("a_emis_full", veh_lamp, 0, 0),
    "veh_speaker_grille": ("a_specmap", veh_speaker_grille, 0.4, 20),
    "veh_monitor_screen": ("a_emis_full", veh_monitor_screen, 0, 0),
}

INFO = {
    "veh_wall_monitor": ("screen", "Cabin Monitor",
                         "A slim wall-mounted display for a passenger cabin: the in-flight entertainment, or any "
                         "video link."),
    "veh_ceiling_speaker": ("decor", "Cabin Speaker",
                            "A flush ceiling speaker. Linked to a screen, it carries that screen's sound."),
}
