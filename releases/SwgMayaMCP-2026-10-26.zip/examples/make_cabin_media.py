"""In-flight entertainment for the Titan vessels' cabin screen (script.space.vessel.cabin_media).

Renders the channels as looping MP4s with Pillow + ffmpeg and writes their guide,
datatables/space/titan_cabin_media.tab (name, url, aspect): the web channels in STREAMS (YouTube links; every
client plays them) and the rendered ones:

  travel_guide   HoloNet Travel Guide: the stock planet loading-screen art (cities, landmarks) with slow pans and captions
  hyperspace     Hyperspace Cam: star streaks down the tunnel, the view a passenger would like to have
  fractal        Fractal Drift: a slow Mandelbrot zoom (ffmpeg's mandelbrot source)

The screen plays file:/// URLs from D:/exported/media/titan_cabin, which is right for this machine's clients; point
the table's url column at a web server (http://...) for players elsewhere.

Run:  python examples/make_cabin_media.py [--only travel_guide,hyperspace,fractal] [--table-only] [--no-compile]
"""
import argparse
import functools
import math
import os
import random
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

sys.path.insert(0, os.path.dirname(__file__))
from make_titan_vessels import DATA, DSRC_SERVER, EXPORT, titan, wsl_path  # noqa: E402

FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
OUT = EXPORT / "media/titan_cabin"
W, H, FPS = 640, 360, 24
FONT = "C:/Windows/Fonts/bahnschrift.ttf"
LOADING = DATA / "texture/loading"

# planet, display name, a line of travel-guide copy
PLANETS = [
    ("tatooine", "Tatooine", "Arkanis sector, Outer Rim. Twin suns, moisture farms and the spaceport of Mos Eisley."),
    ("naboo", "Naboo", "Chommell sector, Mid Rim. Rolling plains, the palace city of Theed and the Gungan swamps."),
    ("corellia", "Corellia", "Corellian sector, Core Worlds. Shipyards, Coronet's boulevards and the Corellian Run."),
    ("dantooine", "Dantooine", "Raioballo sector, Outer Rim. Quiet grasslands hiding old Jedi ruins."),
    ("dathomir", "Dathomir", "Quelii sector, Outer Rim. Red forests, rancors and the Nightsister clans."),
    ("endor", "Endor", "Moddell sector, Outer Rim. The forest moon of the Ewoks."),
    ("lok", "Lok", "Karthakk sector, Mid Rim. Volcanic badlands and Nym's pirate stronghold."),
    ("rori", "Rori", "Naboo system, Mid Rim. Swamps, Narmle and the old Restuss front."),
    ("talus", "Talus", "Corellian system. Dearic, Nashal and the Corellian Security outposts."),
    ("yavin4", "Yavin 4", "Gordian Reach, Outer Rim. Jungle temples of a long-gone people."),
]
# file stem -> caption (the stock names run the words together)
PLACES = {
    "moseisley": "Mos Eisley", "mosentha": "Mos Entha", "mosespa": "Mos Espa", "anchorhead": "Anchorhead",
    "bestine": "Bestine", "wayfar": "Wayfar", "forttusken": "Fort Tusken", "jabbaspalace": "Jabba's Palace",
    "jawafortresse": "Jawa Fortress", "kraytgrave": "Krayt Graveyard", "deejapeak": "Deeja Peak", "kadaara": "Kaadara",
    "keren": "Keren", "moenia": "Moenia", "theed": "Theed", "emperorsretreat": "Emperor's Retreat",
    "gungansacredplace": "Gungan Sacred Place", "lakeretreat": "Lake Retreat", "theedpalace": "Theed Palace",
    "bellavistal": "Bela Vistal", "coronet": "Coronet", "doabaguffel": "Doaba Guerfel", "korvella": "Kor Vella",
    "tyrena": "Tyrena", "vreniisland": "Vreni Island", "agrilatswamp": "Agrilat Swamp", "rebelhideout": "Rebel Hideout",
    "abandonnedrebelbase": "Abandoned Rebel Base", "dantarivillage": "Dantari Village",
    "jeditempleruins": "Jedi Temple Ruins", "aurilia": "Aurilia", "imperialprison": "Imperial Prison",
    "outpost1": "Science Outpost", "stardestroyer1": "Crashed Star Destroyer", "stardestroyer2": "Crashed Star Destroyer",
    "tradeoutpost": "Trade Outpost", "lakevillage": "Lake Village", "marauderscamp": "Marauders' Camp",
    "pirateoutpost": "Pirate Outpost", "treevillage": "Ewok Tree Village", "imperialbase": "Imperial Outpost",
    "nymstronghold": "Nym's Stronghold", "narmle": "Narmle", "restuss": "Restuss", "dearic": "Dearic",
    "nashal": "Nashal", "blueleaftemple": "Blueleaf Temple", "exarkun": "Temple of Exar Kun",
    "greatmassassitemple": "Great Massassi Temple", "imperialoutpost": "Imperial Outpost",
    "woolamanderpalace": "Woolamander Palace", "woolamandertemple": "Woolamander Temple",
}

CHANNELS = [
    ("travel_guide", "HoloNet Travel Guide", "16:9"),
    ("hyperspace", "Hyperspace Cam", "16:9"),
    ("fractal", "Fractal Drift", "16:9"),
]
# Web channels first: they play on every client (the client resolves YouTube links with yt-dlp.exe beside it).
# Blender Studio's open movies, Creative Commons Attribution, from the studio's own channel.
STREAMS = [
    ("Big Buck Bunny (Blender open movie)", "https://www.youtube.com/watch?v=aqz-KE-bpKQ", "16:9"),
    ("Sintel (Blender open movie)", "https://www.youtube.com/watch?v=eRsGyueVLvQ", "16:9"),
    ("Tears of Steel (Blender open movie)", "https://www.youtube.com/watch?v=R6MlUcmOul8", "16:9"),
    ("Cosmos Laundromat (Blender open movie)", "https://www.youtube.com/watch?v=Y-rmzh0PI3c", "16:9"),
    ("Spring (Blender open movie)", "https://www.youtube.com/watch?v=WhWc3b3KhnY", "16:9"),
    ("Sprite Fright (Blender open movie)", "https://www.youtube.com/watch?v=_cMxraX_5RE", "16:9"),
    ("Agent 327 (Blender open movie)", "https://www.youtube.com/watch?v=mN0zPOpADL4", "16:9"),
    ("Coffee Run (Blender open movie)", "https://www.youtube.com/watch?v=PVGeM40dABA", "16:9"),
    ("Charge (Blender open movie)", "https://www.youtube.com/watch?v=UXqq0ZvbOnk", "16:9"),
]


@functools.lru_cache(maxsize=None)
def font(size):
    return ImageFont.truetype(FONT, size)


def encoder(path, seconds=None):
    """An ffmpeg process taking raw RGB frames on stdin."""
    cmd = [FFMPEG, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
           "-i", "-", "-c:v", "libx264", "-preset", "medium", "-crf", "24", "-pix_fmt", "yuv420p",
           "-movflags", "+faststart", str(path)]
    return subprocess.Popen(cmd, stdin=subprocess.PIPE)


def finish_encoder(proc):
    proc.stdin.close()
    if proc.wait() != 0:
        raise RuntimeError("ffmpeg failed")


# ----------------------------------------------------------------------------
# HoloNet Travel Guide
# ----------------------------------------------------------------------------

def guide_slides():
    """(image path, planet name, place, blurb) for each slide: the planet's card, then its cities and landmarks."""
    slides = []
    for key, name, blurb in PLANETS:
        d = LOADING / key
        if not d.is_dir():
            continue
        card = d / f"ui_load_{key}.dds"
        if card.exists():
            slides.append((card, name, "", blurb))
        for sub in ("cities", "landmarks"):
            for f in sorted((d / sub).glob("*.dds")) if (d / sub).is_dir() else []:
                stem = f.stem.split("_", 1)[1] if "_" in f.stem else f.stem
                if stem == key:
                    continue
                slides.append((f, name, PLACES.get(stem, stem.title()), blurb))
    return slides


def cover(img, zoom, pan):
    """Crop `img` to the frame aspect at `zoom` (>= 1), panned by pan in [-1, 1]^2, scaled to W x H."""
    iw, ih = img.size
    cw = iw / zoom
    ch = cw * H / W
    if ch > ih / zoom:
        ch = ih / zoom
        cw = ch * W / H
    cx = iw / 2 + pan[0] * (iw - cw) / 2
    cy = ih / 2 + pan[1] * (ih - ch) / 2
    box = (cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2)
    return img.resize((W, H), Image.BICUBIC, box=box)


def caption(frame, title, place, blurb, alpha):
    bar = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(bar)
    d.rectangle((0, H - 92, W, H), fill=(6, 14, 30, int(190 * alpha)))
    d.rectangle((0, H - 92, W, H - 90), fill=(90, 170, 255, int(230 * alpha)))
    a = int(255 * alpha)
    d.text((22, H - 84), title.upper(), font=font(30), fill=(235, 242, 255, a))
    if place:
        tw = d.textlength(title.upper(), font=font(30))
        d.text((32 + tw, H - 75), "·  " + place, font=font(22), fill=(150, 205, 255, a))
    d.text((22, H - 40), blurb, font=font(15), fill=(190, 205, 225, a))
    d.text((W - 172, 12), "HOLONET TRAVEL GUIDE", font=font(13), fill=(150, 205, 255, int(200 * alpha)))
    return Image.alpha_composite(frame.convert("RGBA"), bar).convert("RGB")


def render_travel_guide(path, slide_seconds=6.0, fade=0.8):
    slides = guide_slides()
    rng = random.Random(7)
    n = int(slide_seconds * FPS)
    nf = int(fade * FPS)
    proc = encoder(path)
    prev_last = None
    for idx, (img_path, title, place, blurb) in enumerate(slides):
        img = Image.open(img_path).convert("RGB")
        # soften the small stock art before it is blown up to the frame
        img = img.resize((img.width * 3, img.height * 3), Image.LANCZOS).filter(ImageFilter.GaussianBlur(1.2))
        p0 = (rng.uniform(-0.8, 0.8), rng.uniform(-0.8, 0.8))
        p1 = (rng.uniform(-0.8, 0.8), rng.uniform(-0.8, 0.8))
        z0, z1 = (1.0, 1.18) if idx % 2 == 0 else (1.18, 1.0)
        for i in range(n):
            s = i / (n - 1)
            e = s * s * (3 - 2 * s)
            frame = cover(img, z0 + (z1 - z0) * e, (p0[0] + (p1[0] - p0[0]) * e, p0[1] + (p1[1] - p0[1]) * e))
            alpha = min(1.0, i / nf, (n - 1 - i) / nf) if nf else 1.0
            frame = caption(frame, title, place, blurb, max(0.0, alpha))
            if prev_last is not None and i < nf:
                frame = Image.blend(prev_last, frame, i / nf)
            proc.stdin.write(frame.tobytes())
            if i == n - 1:
                prev_last = frame
    finish_encoder(proc)
    return len(slides) * slide_seconds


# ----------------------------------------------------------------------------
# Hyperspace Cam
# ----------------------------------------------------------------------------

def render_hyperspace(path, seconds=40.0, stars=900):
    """Star streaks rushing past; every star runs a whole number of laps per loop, so the loop is seamless."""
    rng = np.random.default_rng(11)
    nframes = int(seconds * FPS)
    theta = rng.uniform(0, 2 * math.pi, stars)
    phase = rng.uniform(0, 1, stars)
    laps = rng.integers(3, 9, stars)
    tint = rng.uniform(0, 1, stars)
    cx, cy = W / 2, H / 2
    g = np.zeros((H, W, 3), np.float32)
    yy, xx = np.mgrid[0:H, 0:W]
    r2 = ((xx - cx) / W) ** 2 + ((yy - cy) / H) ** 2
    g[..., 0] = 30 * np.exp(-r2 * 30)
    g[..., 1] = 60 * np.exp(-r2 * 26)
    g[..., 2] = 120 * np.exp(-r2 * 18) + 12
    glow = Image.fromarray(np.clip(g, 0, 255).astype(np.uint8))
    proc = encoder(path)
    label = font(13)
    for f in range(nframes):
        t = f / nframes
        frame = glow.copy()
        d = ImageDraw.Draw(frame)
        # tunnel swirl: faint rings sliding outward
        for k in range(6):
            ring = ((t * 6 + k / 6.0) % 1.0)
            rr = 10 + (ring ** 2.2) * W * 0.9
            c = int(40 * (1 - ring))
            d.ellipse((cx - rr, cy - rr * 0.62, cx + rr, cy + rr * 0.62), outline=(c // 2, c, c * 2))
        z = 1.0 - ((phase + t * laps) % 1.0)          # depth 1 -> 0
        z = np.maximum(z, 0.02)
        r_now = 18.0 / z
        r_tail = 18.0 / np.minimum(z + 0.06 + 0.25 * z, 1.2)
        for i in np.argsort(-z):
            if r_tail[i] > W:
                continue
            ct, st = math.cos(theta[i]), math.sin(theta[i]) * 0.62
            b = float(min(1.0, (1.0 - z[i]) * 1.6))
            col = (int(170 * b + 60 * tint[i] * b), int(200 * b + 40 * tint[i] * b), int(255 * b))
            d.line((cx + ct * r_tail[i], cy + st * r_tail[i], cx + ct * r_now[i], cy + st * r_now[i]), fill=col,
                   width=1 if z[i] > 0.35 else 2)
        d.text((14, 12), "HYPERSPACE CAM  ·  TITAN TRANSPORT SERVICE", font=label, fill=(150, 205, 255))
        proc.stdin.write(frame.tobytes())
    finish_encoder(proc)
    return seconds


# ----------------------------------------------------------------------------
# Fractal Drift
# ----------------------------------------------------------------------------

def render_fractal(path, seconds=60.0):
    src = (f"mandelbrot=size={W}x{H}:rate={FPS}:maxiter=320:start_scale=3:end_scale=0.004:end_pts={seconds}:"
           "start_x=-0.743643887037158704752191506114774:start_y=-0.131825904205311970493132056385139:"
           "outer=normalized_iteration_count:inner=period")
    vf = ("hue=h=t*4:s=1.1,drawtext=fontfile='C\\:/Windows/Fonts/bahnschrift.ttf':text='FRACTAL DRIFT':"
          "x=14:y=12:fontsize=13:fontcolor=0x96CDFF")
    cmd = [FFMPEG, "-y", "-loglevel", "error", "-f", "lavfi", "-i", src, "-t", str(seconds), "-vf", vf,
           "-c:v", "libx264", "-preset", "medium", "-crf", "24", "-pix_fmt", "yuv420p", "-movflags", "+faststart",
           str(path)]
    subprocess.run(cmd, check=True)
    return seconds


RENDER = {"travel_guide": render_travel_guide, "hyperspace": render_hyperspace, "fractal": render_fractal}


def write_table():
    tab = DSRC_SERVER / "datatables/space/titan_cabin_media.tab"
    rows = ["name\turl\taspect", "s\ts\ts"]
    for name, url, aspect in STREAMS:
        rows.append(f"{name}\t{url}\t{aspect}")
    for key, name, aspect in CHANNELS:
        url = "file:///" + str(OUT / f"{key}.mp4").replace("\\", "/")
        rows.append(f"{name} (this machine only)\t{url}\t{aspect}")
    tab.parent.mkdir(parents=True, exist_ok=True)
    tab.write_text("\n".join(rows) + "\n", newline="\n")
    return tab


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--table-only", action="store_true", help="rewrite the guide without rendering the videos")
    ap.add_argument("--no-compile", action="store_true")
    a = ap.parse_args()
    only = [s for s in a.only.split(",") if s]
    OUT.mkdir(parents=True, exist_ok=True)
    for key, name, _ in CHANNELS:
        if a.table_only or (only and key not in only):
            continue
        path = OUT / f"{key}.mp4"
        seconds = RENDER[key](path)
        print(f"{name}: {path} ({seconds:.0f} s, {path.stat().st_size / 1e6:.1f} MB)")
    tab = write_table()
    print("guide:", tab)
    if not a.no_compile:
        rc, out = titan(["sync", wsl_path(tab)])
        print("sync:", rc, "\n".join(out.strip().splitlines()[-4:]))


if __name__ == "__main__":
    main()
