"""B1 battle droid deploy animations for the Battle of Naboo heroic (docs/content/battle-of-naboo/README.md), authored
on the stock battle_droid skeleton in headless Maya and exported with SwgAns:

  titan_hrc_b1_unfold.ans      power_up    3.5 s folded for transport (the "disabled" window), a boot twitch,
                                           then 2.5 s unfolding: legs plant, torso rises, arms and head come up
  titan_hrc_b1_power_down.ans  power_down  the control-ship shutdown: head drops, torso sags, knees give, arms hang

The poses are world-space rotations applied parent first (so the rig's joint axes don't matter), stored as bind +
offset keys and blended with quaternion slerp per joint. Renders of key frames land in %TEMP%/titan_naboo_battle.

The stock all_b.ash already has the actions power_up / power_down (logical std_power_up / std_power_down, used by
droidekas); the heroic droids get their own .lat (a copy of battle_droid.lat plus those two rows) and .sat, so
stock battle droids are untouched.

Run: .venv\\Scripts\\python.exe examples/make_b1_unfold.py [--render-only]   (takes D:/titan/.locks/maya)"""
import asyncio
import base64
import json
import os
import sys
import tempfile
import time
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import iff, wearable  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
DATA = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
OUT = Path(tempfile.gettempdir()) / "titan_naboo_battle"
LOCK = Path("D:/titan/.locks/maya")
UNFOLD = "appearance/animation/titan_hrc_b1_unfold.ans"
POWER_DOWN = "appearance/animation/titan_hrc_b1_power_down.ans"
FOLDED = "appearance/animation/titan_hrc_b1_folded.ans"
FOLDED_MOOD = "titan_folded"
LAT = "appearance/lat/titan_hrc_nboo_b1.lat"
SAT = "appearance/titan_hrc_nboo_b1.sat"

CODE = r'''
import maya.cmds as cmds, maya.mel as mel, math, os
import maya.api.OpenMaya as om2
data = os.environ.get('TITAN_DATA_ROOT', 'D:/titan/data/sku.0/sys.client/compiled/game').replace(chr(92), '/')
cmds.file(new=True, force=True)
mel.eval('importSat -i "%s/appearance/battle_droid.sat"' % data)
cmds.currentUnit(time='ntsc', updateAnimation=True)
cmds.currentTime(0)

def short(j):
    # the importer renames a joint that clashes with a scene node: root -> root__battle_droid_l0
    return j.split('|')[-1].split('__')[0]

def joint(name):
    return [j for j in cmds.ls(type='joint', long=True) if short(j) == name][0]

ALL = [j for j in cmds.ls(type='joint', long=True)]
for j in ALL:
    cmds.cutKey(j, clear=True)
BIND_R = {j: list(cmds.getAttr(j + '.rotate')[0]) for j in ALL}
BIND_T = {j: list(cmds.getAttr(j + '.translate')[0]) for j in ALL}

def capture(deltas, root_drop=0.0):
    """Apply world-space rotation deltas (parents first) from the bind pose, read back local rotates."""
    for j in ALL:
        cmds.setAttr(j + '.rotate', *BIND_R[j])
        cmds.setAttr(j + '.translate', *BIND_T[j])
    if root_drop:
        r = joint('root')
        cmds.setAttr(r + '.translateY', BIND_T[r][1] - root_drop)
    for name, rot in deltas:
        cmds.rotate(rot[0], rot[1], rot[2], joint(name), relative=True, worldSpace=True, forceOrderXYZ=True)
    pose = {j: list(cmds.getAttr(j + '.rotate')[0]) for j in ALL}
    pose_t = {j: list(cmds.getAttr(j + '.translate')[0]) for j in ALL}
    for j in ALL:
        cmds.setAttr(j + '.rotate', *BIND_R[j])
        cmds.setAttr(j + '.translate', *BIND_T[j])
    return pose, pose_t

D = args['deltas']
FOLD, FOLD_T = capture([(n, r) for n, r in D['fold']], D['fold_drop'])
SLUMP, SLUMP_T = capture([(n, r) for n, r in D['slump']], D['slump_drop'])
GROUPS = D['groups']             # joint -> group name; group -> [start, end] of its unfold (frames)

def ease(a, b, f):
    t = min(1.0, max(0.0, (f - a) / float(b - a)))
    return t * t * (3.0 - 2.0 * t)

def quat(j, rot):
    order = cmds.getAttr(j + '.rotateOrder')
    return om2.MEulerRotation(*[math.radians(v) for v in rot], order).asQuaternion()

def bake(frames, weight_of, a_pose, b_pose, a_t, b_t):
    """Keys every frame: per joint slerp a_pose -> b_pose by weight_of(joint, frame)."""
    for j in ALL:
        order = cmds.getAttr(j + '.rotateOrder')
        qa, qb = quat(j, a_pose[j]), quat(j, b_pose[j])
        prev = None
        for f in frames:
            w = weight_of(j, f)
            e = om2.MQuaternion.slerp(qa, qb, w).asEulerRotation()
            e.reorderIt(order)
            if prev is not None:
                e.setToClosestSolution(prev)
            prev = e
            for axis, v in zip('XYZ', (e.x, e.y, e.z)):
                cmds.setKeyframe(j, attribute='rotate' + axis, time=f, value=math.degrees(v))
            for k, axis in enumerate('XYZ'):
                cmds.setKeyframe(j, attribute='translate' + axis, time=f, value=a_t[j][k] + (b_t[j][k] - a_t[j][k]) * w)

out = {}
# --- unfold: folded -> bind
END = D['unfold_end']
def w_unfold(j, f):
    g = GROUPS.get(short(j), 'body')
    a, b = D['windows'][g]
    w = ease(a, b, f)
    # boot twitch: the head jerks up twice while still folded
    return w
bake(range(0, END + 1), w_unfold, FOLD, BIND_R, FOLD_T, BIND_T)
h = joint('head')
for f, d in D['twitch']:
    r = cmds.getAttr(h + '.rotate', time=f)[0]
    cmds.setKeyframe(h, attribute='rotateX', time=f, value=r[0] + d)
cmds.playbackOptions(minTime=0, maxTime=END, animationStartTime=0, animationEndTime=END)
os.makedirs(os.path.dirname(args['unfold']), exist_ok=True)
cmds.select(cmds.ls(type='joint'), r=True)
cmds.file(args['unfold'], force=True, exportSelected=True, type='SwgAns', options='')
out['unfold'] = os.path.getsize(args['unfold'])

# --- power down: bind -> slump, then hold
for j in ALL:
    cmds.cutKey(j, clear=True)
PEND, HOLD = D['down_end'], D['down_hold']
def w_down(j, f):
    g = GROUPS.get(short(j), 'body')
    a, b = D['down_windows'][g]
    return ease(a, b, f)
bake(range(0, HOLD + 1), w_down, BIND_R, SLUMP, BIND_T, SLUMP_T)
cmds.playbackOptions(minTime=0, maxTime=HOLD, animationStartTime=0, animationEndTime=HOLD)
cmds.select(cmds.ls(type='joint'), r=True)
cmds.file(args['power_down'], force=True, exportSelected=True, type='SwgAns', options='')
out['power_down'] = os.path.getsize(args['power_down'])

# --- folded: the transport pose held (looped while the droid's mood is titan_folded)
for j in ALL:
    cmds.cutKey(j, clear=True)
FHOLD = D['folded_hold']
bake(range(0, FHOLD + 1), lambda j, f: 0.0, FOLD, BIND_R, FOLD_T, BIND_T)
cmds.playbackOptions(minTime=0, maxTime=FHOLD, animationStartTime=0, animationEndTime=FHOLD)
cmds.select(cmds.ls(type='joint'), r=True)
cmds.file(args['folded'], force=True, exportSelected=True, type='SwgAns', options='')
out['folded'] = os.path.getsize(args['folded'])

# leave the unfold loaded for the review renders
for j in ALL:
    cmds.cutKey(j, clear=True)
bake(range(0, END + 1), w_unfold, FOLD, BIND_R, FOLD_T, BIND_T)
meshes = [m for m in cmds.ls(type='mesh', long=True) if not cmds.getAttr(m + '.intermediateObject')]
out['meshes'] = len(meshes)
out['target'] = '|'.join(meshes[0].split('|')[:3]) if meshes else ''
result = out
'''

# world-space rotation deltas in degrees (Maya space: +X right of the droid's facing +Z, rotating +X tips +Y
# toward +Z), applied parent first; root_drop in metres
DELTAS = {
    "fold": [("root", (16, 0, 0)), ("spine", (72, 0, 0)), ("neck", (34, 0, 0)), ("head", (48, 0, 0)),
             ("lthigh", (-126, 0, 5)), ("rthigh", (-126, 0, -5)), ("lknee", (166, 0, 0)), ("rknee", (166, 0, 0)),
             ("lankle", (-44, 0, 0)), ("rankle", (-44, 0, 0)),
             ("larm", (40, 0, 10)), ("rarm", (40, 0, -10)), ("lforearm", (-142, 0, 0)), ("rforearm", (-142, 0, 0)),
             ("lwrist", (34, 0, 0)), ("rwrist", (34, 0, 0))],
    "fold_drop": 0.64,
    "slump": [("root", (6, 0, 0)), ("spine", (24, 0, 0)), ("neck", (22, 0, 0)), ("head", (38, 0, 0)),
              ("lthigh", (-14, 0, 0)), ("rthigh", (-14, 0, 0)), ("lknee", (26, 0, 0)), ("rknee", (26, 0, 0)),
              ("lankle", (-12, 0, 0)), ("rankle", (-12, 0, 0)), ("larm", (8, 0, 4)), ("rarm", (8, 0, -4)),
              ("lforearm", (6, 0, 0)), ("rforearm", (6, 0, 0))],
    "slump_drop": 0.1,
    # unfold staging (frames at 30 fps): legs plant first, the torso rises, arms and head come up last
    "groups": {"root": "legs", "lthigh": "legs", "rthigh": "legs", "lknee": "legs", "rknee": "legs",
               "lankle": "legs", "rankle": "legs", "ltoe": "legs", "rtoe": "legs",
               "spine": "body", "neck": "head", "head": "head", "head_extent": "head"},
    "windows": {"legs": [105, 150], "body": [118, 165], "arms": [135, 175], "head": [145, 180]},
    "unfold_end": 180,
    "twitch": [[96, 0.0], [98, -14.0], [100, 0.0], [102, -10.0], [104, 0.0]],
    "down_windows": {"legs": [6, 40], "body": [2, 36], "arms": [8, 44], "head": [0, 24]},
    "down_end": 44, "down_hold": 60,
    "folded_hold": 30,
}
for arm in ("larm", "lforearm", "lulna", "lwrist", "lknuckle", "lring", "lindex", "lthumb1", "lthumb2",
            "rarm", "rforearm", "rulna", "rwrist", "rknuckle", "rring", "rindex", "rthumb1", "rthumb2", "hold_r"):
    DELTAS["groups"][arm] = "arms"


def _form(tag, children):
    return iff.Block(tag, True, b"", children)


def _chunk(tag, data):
    return iff.Block(tag, False, data)


def write_lat_and_sat(root=EXPORT):
    """titan_hrc_nboo_b1.lat = battle_droid.lat + std_power_up / std_power_down rows; .sat pointing at it."""
    src = iff.parse_iff((DATA / "appearance/lat/battle_droid.lat").read_bytes())
    ver = src.first("LATT").forms()[0]
    info = ver.children[0]
    ash = info.data.split(b"\0")[0]
    count = int.from_bytes(info.data[len(ash) + 1:len(ash) + 3], "little")
    names = set()
    for a in ver.forms("ANIM"):
        names.add(a.first("INFO").data.split(b"\0")[0].decode())

    def row(logical, path):
        pxat = _form("PXAT", [_form("0000", [_chunk("INFO", path.encode() + b"\0"),
                                                      _chunk("PUNF", b"action\0action\0")])])
        return _form("ANIM", [_chunk("INFO", logical.encode() + b"\0"), pxat])
    added = [(n, p) for n, p in (("std_power_up", UNFOLD), ("std_power_down", POWER_DOWN)) if n not in names]
    ver.children.extend(row(n, p) for n, p in added)

    # Folded for transport: a creature mood (setAnimationMood, which reaches clients in the baselines, unlike a
    # one-shot action fired before the client has loaded the droid). Every loop (standing, rifle, kneeling...) becomes a string selector
    # on the "mood" animation variable: titan_folded -> the held fold, anything else -> the stock loop. The value
    # chunk is "VAL " (TAG3, trailing space) as in stock all_m.lat; "VALS" is skipped and hides DFLT too.
    def mood_selector(stock_form):
        return _form("SSAT", [_form("0000", [
            _chunk("INFO", b"mood\0"),
            _form("ANMS", [_chunk("INFO", (2).to_bytes(2, "little")), stock_form,
                               _chunk("NAME", FOLDED.encode() + b"\0")]),
            _chunk("VAL ", (1).to_bytes(2, "little") + FOLDED_MOOD.encode() + b"\0" + (1).to_bytes(2, "little")),
            _chunk("DFLT", (0).to_bytes(2, "little"))])])
    wrapped = 0
    for a in ver.forms("ANIM"):
        logical = a.first("INFO").data.split(b"\0")[0].decode()
        body = a.forms()[0]
        if logical.startswith("loop_") and body.tag != "SSAT":
            a.children[a.children.index(body)] = mood_selector(body)
            wrapped += 1
    info.data = ash + b"\0" + (count + len(added)).to_bytes(2, "little") + info.data[len(ash) + 3:]
    (root / LAT).parent.mkdir(parents=True, exist_ok=True)
    (root / LAT).write_bytes(iff.serialize_iff(src))
    stock = wearable.read_sat(DATA / "appearance/battle_droid.sat")
    skt = stock["skeletons"][0][0]
    (root / SAT).write_bytes(wearable.write_sat(stock["mesh_generators"], stock["skeletons"],
                                                create_animation_controller=True, lat=[(skt, LAT)]))
    return {"lat": LAT, "rows": count + len(added), "sat": SAT, "mood_selectors": wrapped}


# ---------------------------------------------------------------------------- the STAP scout
# The heroic STAP is a B1 creature (stock mesh, shaders and markings) held in a riding pose by its own .lat; the
# hull is the stock stap_speeder mesh scaled 1.5 (a B1 is 1.84 m, the stock STAP 2 m) as a static appearance that
# droid_unit hangs on the object origin (hp_dyn app on "-"), so it doesn't follow the droid's joints. The stock
# STAP: foot pegs beside the stalk at y 0.9 / z 0, grips under the dish at y 1.8 / z -0.38; the pilot faces +z.
STAP_SCALE = 1.5
STAP_RIDE = "appearance/animation/titan_hrc_b1_stap_ride.ans"
STAP_LAT = "appearance/lat/titan_hrc_nboo_stap.lat"
STAP_SAT = "appearance/titan_hrc_nboo_stap.sat"
STAP_HULL = "appearance/titan_hrc_nboo_stap_hull.apt"

STAP_CODE = r'''
import maya.cmds as cmds, maya.mel as mel, os
data = os.environ.get('TITAN_DATA_ROOT', 'D:/titan/data/sku.0/sys.client/compiled/game').replace(chr(92), '/')
S = args['scale']
cmds.file(new=True, force=True)
cmds.file(data + '/appearance/stap_speeder.apt', i=True) if False else None
mel.eval('importSat -i "%s/appearance/battle_droid.sat"' % data)
def short(j): return j.split('|')[-1].split('__')[0]
J = {short(j): j for j in cmds.ls(type='joint', long=True)}
for j in J.values():
    cmds.cutKey(j, clear=True)
cmds.currentTime(0)
feet_y = 0.9 * S + 0.07
root = J['root']
rp = cmds.xform(root, q=True, ws=True, t=True)
cmds.move(-rp[0], feet_y + 0.84 - rp[1], -0.40 - rp[2], root, relative=True, worldSpace=True)
cmds.rotate(-10, 0, 0, root, relative=True, worldSpace=True)       # hips back
cmds.rotate(24, 0, 0, J['spine'], relative=True, worldSpace=True)   # torso over the bars
cmds.rotate(-12, 0, 0, J['neck'], relative=True, worldSpace=True)
for side, sx in (('l', 1.0), ('r', -1.0)):
    h, e = cmds.ikHandle(sj=J[side + 'thigh'], ee=J[side + 'ankle'], solver='ikRPsolver')
    cmds.move(sx * 0.37 * S, feet_y + 0.09, 0.0, h, absolute=True, worldSpace=True)      # on the peg
    cmds.setAttr(h + '.poleVector', sx * 0.3, 0.0, 1.0)
    h2, e2 = cmds.ikHandle(sj=J[side + 'arm'], ee=J[side + 'wrist'], solver='ikRPsolver')
    cmds.move(sx * 0.36 * S, 1.79 * S - 0.04, -0.38 * S - 0.05, h2, absolute=True, worldSpace=True)  # on the grip
    cmds.setAttr(h2 + '.poleVector', sx * 1.0, -0.6, -0.4)
joints = cmds.ls(type='joint', long=True)
cmds.bakeResults(joints, t=(0, 30), simulation=True, attribute=['rx', 'ry', 'rz', 'tx', 'ty', 'tz'])
for h in cmds.ls(type='ikHandle') or []:
    cmds.delete(h)
cmds.playbackOptions(minTime=0, maxTime=30, animationStartTime=0, animationEndTime=30)
cmds.select(cmds.ls(type='joint'), r=True)
cmds.file(args['ride'], force=True, exportSelected=True, type='SwgAns', options='')
# the hull: stock STAP scaled, as a static mesh
cmds.file(new=True, force=True)
before = set(cmds.ls(assemblies=True))
cmds.SwgImport(data + '/appearance/stap_speeder.apt') if hasattr(cmds, 'SwgImport') else mel.eval('file -import "%s/appearance/mesh/stap_speeder.msh"' % data)
grp = [a for a in cmds.ls(assemblies=True) if a not in before][0]
grp = cmds.rename(grp, 'titan_hrc_nboo_stap_hull')
for k in cmds.listRelatives(grp, children=True, fullPath=True) or []:
    if k.endswith('collision'):
        cmds.delete(k)
cmds.setAttr(grp + '.scale', S, S, S)
cmds.makeIdentity(grp, apply=True, scale=True, translate=True, rotate=True)
mel.eval('exportStaticMesh -root "|%s" -path "%s"' % (grp, args['hull']))
result = {'ride': os.path.getsize(args['ride'])}
'''


def write_stap_rider(root=EXPORT):
    """titan_hrc_nboo_stap.lat: battle_droid.lat with every row (deaths and incapacitation excepted) playing the
    riding pose; titan_hrc_nboo_stap.sat: the stock B1 meshes on it."""
    src = iff.parse_iff((DATA / "appearance/lat/battle_droid.lat").read_bytes())
    ver = src.first("LATT").forms()[0]
    held = 0
    for a in ver.forms("ANIM"):
        logical = a.first("INFO").data.split(b"\0")[0].decode()
        if any(k in logical for k in ("death", "dead", "incap")):
            continue
        a.children = [a.first("INFO"), _chunk("NAME", STAP_RIDE.encode() + b"\0")]
        held += 1
    (root / STAP_LAT).parent.mkdir(parents=True, exist_ok=True)
    (root / STAP_LAT).write_bytes(iff.serialize_iff(src))
    stock = wearable.read_sat(DATA / "appearance/battle_droid.sat")
    skt = stock["skeletons"][0][0]
    (root / STAP_SAT).write_bytes(wearable.write_sat(stock["mesh_generators"], stock["skeletons"],
                                                     create_animation_controller=True, lat=[(skt, STAP_LAT)]))
    return {"lat": STAP_LAT, "rows_held": held, "sat": STAP_SAT}


def take_lock():
    for _ in range(120):
        try:
            LOCK.mkdir(parents=True)
            (LOCK / "owner.txt").write_text("session: Battle of Naboo heroic (90873d83)\ntask: make_b1_unfold.py\n"
                                            f"taken: {time.strftime('%Y-%m-%dT%H:%M:%S')}\n")
            return True
        except FileExistsError:
            print("maya lock held:", (LOCK / "owner.txt").read_text() if (LOCK / "owner.txt").exists() else "?")
            time.sleep(30)
    return False


def release_lock():
    for f in LOCK.glob("*"):
        f.unlink()
    LOCK.rmdir()


async def main():
    OUT.mkdir(parents=True, exist_ok=True)
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            run = {"deltas": DELTAS, "unfold": str(EXPORT / UNFOLD).replace("\\", "/"),
                   "power_down": str(EXPORT / POWER_DOWN).replace("\\", "/"),
                   "folded": str(EXPORT / FOLDED).replace("\\", "/")}
            res = await s.call_tool("maya_python", {"code": "args = " + json.dumps(run) + "\n" + CODE,
                                                    "timeout_seconds": 900})
            text = "\n".join(getattr(c, "text", "") for c in res.content)
            data = json.loads(text)
            if not data.get("ok"):
                print(text[-3000:])
                return
            print(data["result"])
            target = data["result"].get("target", "")
            for f in (0, 120, 140, 160, 180):
                await s.call_tool("maya_python", {"code": f"cmds.currentTime({f})"})
                for az, tag in ((35, "q"), (90, "side")):
                    img = await s.call_tool("maya_render", {"target": target, "width": 480, "height": 480,
                                                            "azimuth": az, "elevation": 10})
                    for c in img.content:
                        if getattr(c, "data", None):
                            (OUT / f"b1_unfold_{f:03d}_{tag}.png").write_bytes(base64.b64decode(c.data))
            await s.call_tool("maya_scene", {"action": "new"})
    print(write_lat_and_sat())


if __name__ == "__main__":
    if not take_lock():
        raise SystemExit("could not take the maya lock")
    try:
        asyncio.run(main())
    finally:
        release_lock()
