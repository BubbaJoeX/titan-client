"""Geonosis: a 16 km ground planet built with the terrain package (the library behind the trn_* MCP tools) from
stock assets only.

    .venv\\Scripts\\python.exe examples\\make_geonosis.py [out.trn] [--register]   (default D:/exported/terrain/geonosis.trn)

--register also adds the planet to the server, client and god client data (terrain/planet.py: data/, dsrc/,
exe/linux/localOptions.cfg, SwgGodClient's buildout editor list).

The planet (Wookieepedia): hot, arid, irradiated, red rock deserts with mesas, buttes and mountains, 5 % surface
water with flash floods, rocky rings, fifteen moons (four major, icy Bahryn among them), one sun (Ea), 30-hour days
(environment cycle 9000 s; stock 24 h days are ~7200 s). The build: broad plains of red sand, flat-topped mesas
and buttes with terraced, cliffy sides, a ridged canyon network, impact craters with raised rims (the asteroid ring keeps bombarding it), and
fields of termite-mound rock spires - the Geonosians' hives. Landmarks: the outpost / landing field at the
origin, the Petranaki arena (a bowl cut into a mesa), the Stalgasin hive (a dense spire city), a droid foundry on a
flat pad with lava channels, and the catacomb canyon. Roads link the outpost to the landmarks. Surface water is
scarce (~5 %): a salt lake and oasis basins with local water tables, fed by flash-flood channels. The sky (copied
from Lok's red desert sky) gets four major moons - icy Bahryn among them - and the rocky ring.

Assets: Lok and Dathomir desert / canyon / cliff shaders, Mustafar spires, scorched rocks, dust devils and lava,
Lok desert grass tufts; sky and lighting: terrain/environment/geonosis.iff and datatables/environment/geonosis.iff
(Lok's, with the moons and ring added), written next to the terrain."""

from __future__ import annotations

import json
import math
import random
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

from swg_maya_mcp.terrain import author, generator  # noqa: E402
from swg_maya_mcp.terrain.tools import DATA_ROOTS  # noqa: E402

OUTPOST = (0.0, 0.0)
ARENA = (2600.0, 1800.0)
HIVE = (-2400.0, 2200.0)                  # Stalgasin hive spires, the capital
HIVES = {"Gehenbar hive": (6200.0, 6300.0), "Golbah hive": (-6500.0, 1800.0), "Trippa hive": (3000.0, 6200.0)}
# named areas (wiki points of interest), also the planet's regions: (x, z, radius)
AREAS = {
    "E'Y-Akh Desert": (-4600.0, -2600.0, 1500.0),       # a dune sea
    "Badlands of N'g'zi": (5200.0, 1200.0, 1300.0),     # canyon-cut badlands
    "Im'g'twe Hills": (-6200.0, -500.0, 1100.0),
    "Korakanni Mound": (-3300.0, -5000.0, 420.0),
    "Progate Temple": (3900.0, -600.0, 160.0),
    "Point Rain": (-1300.0, -6000.0, 650.0),            # the battle plain, and its caltrop field
    "Northern mountains": (-2500.0, 7000.0, 2600.0),
}
FOUNDRY = (1800.0, -2600.0)
CATACOMBS = [(-3600.0, -800.0), (-2600.0, -1500.0), (-1500.0, -1700.0), (-600.0, -2600.0), (300.0, -4200.0)]
# (x, z, radius): one salt lake and five oases, about 13 km2 of the 268 km2 map
BASINS = [(4800.0, -4300.0, 1900.0), (-5200.0, 4600.0, 650.0), (-1200.0, 5600.0, 450.0), (5600.0, 3900.0, 550.0),
          (-6000.0, -5200.0, 500.0), (900.0, 3600.0, 380.0)]
FLOOD_CHANNELS = [
    [(2200.0, -1400.0), (2900.0, -2100.0), (3500.0, -3000.0), (4100.0, -3600.0)],
    [(7000.0, -1500.0), (6400.0, -2600.0), (5900.0, -3300.0)],
    [(-3000.0, 6800.0), (-3900.0, 5900.0), (-4700.0, 5000.0)],
]
# Geonosis has fifteen moons, four of them major (icy Bahryn among them), and a rocky ring
SKY_EXTRAS = [("shader/cels_ice_moon.sht", 0.55, -60.0, 32.0),       # Bahryn
              ("shader/cels_moon_tiel.sht", 0.3, 120.0, 48.0),
              ("shader/cels_moon_earthy01.sht", 0.18, 200.0, 22.0),
              ("shader/cels_planet_ring.sht", 1.6, 35.0, 18.0)]     # the ring, seen from the ground


def build() -> author.TerrainDoc:
    doc = author.new_terrain("terrain/geonosis.trn", map_width=16384.0, chunk_width=8.0, tiles_per_chunk=2,
                             environment_cycle_time=9000.0, use_global_water_table=False,
                             collidable_max_distance=64.0, collidable_tile_size=16.0, collidable_tile_border=4.0,
                             non_collidable_max_distance=64.0, radial_max_distance=28.0, radial_tile_border=0.48,
                             far_radial_min_distance=120.0, far_radial_max_distance=500.0,
                             far_radial_tile_border=12.0, legacy_map=False)

    def shader(name, color, kids):
        return author.add_family(doc, "shader", {"name": name, "color": color, "shader_size": 4.0,
                                                 "children": [{"shader": k} for k in kids]})["id"]

    sand = shader("red sand", [200, 90, 50], ["dirt_redsandy", "dirt_redsandy_a1"])
    ash = shader("ash sand", [180, 120, 90], ["sand_dath_desertash", "sand_dath_desertash_a1", "sand_dath_desertash_a2"])
    floor = shader("canyon floor", [150, 80, 50], ["dirt_dath_desertcanyonfloor", "dirt_dath_desertcanyonfloor_a1",
                                                   "dirt_dath_desertcanyonfloor_a2"])
    cliff = shader("red cliff", [130, 40, 30], ["rock_dath_cliffred", "rock_dath_cliffred_a1", "rock_dath_cliffred_a2"])
    rust = shader("rust rock", [190, 100, 40], ["rock_rusted_orange", "rock_rusted_orange_a1", "rock_rusted_orange_a2"])
    mesa_top = shader("mesa top", [210, 120, 80], ["rock_beachcliff_red"])
    canyon = shader("canyon rock", [140, 70, 40], ["rock_dath_desertcanyon", "rock_dath_desertcanyon_a1",
                                                   "rock_dath_desertcanyon_a2"])
    slab = shader("plaza", [170, 170, 170], ["street_corl_concrete_a"])
    scorch = shader("crater scorch", [70, 60, 60], ["rock_mustafar_crater_grnd_s01", "rock_mustafar_crater_grnd_s02"])
    lava = shader("lava edge", [255, 80, 0], ["rock_mustafar_lava_edge_s01", "rock_mustafar_lava_edge_s02"])

    spires = author.add_family(doc, "flora", {"name": "hive spires", "density": 0.35, "children": [
        {"appearance": a, "should_scale": True, "min_scale": 0.8, "max_scale": 2.2} for a in (
            "rock_musta_lg_spire_lumpy.apt", "rock_musta_lg_spire_lumpy_a1.apt", "rock_musta_lg_spire_lumpy_a2.apt",
            "rock_musta_lg_spire_smooth.apt", "rock_musta_lg_spire_smooth_a1.apt",
            "rock_musta_lg_spire_skinny.apt")]})["id"]
    boulders = author.add_family(doc, "flora", {"name": "boulders", "density": 0.12, "children": [
        {"appearance": a, "should_scale": True, "min_scale": 0.7, "max_scale": 1.6} for a in (
            "rock_dath_desertboulder.apt", "rock_dath_desertboulder_a1.apt", "rock_dath_desertboulder_a2.apt",
            "rock_must_scorched_lrg.apt", "rock_must_scorched_med.apt")]})["id"]
    pebbles = author.add_family(doc, "flora", {"name": "scree", "density": 0.3, "children": [
        {"appearance": a} for a in ("rock_must_scorched_sml.apt", "rock_must_scorched_tiny.apt",
                                    "shrb_dsrt_brown.apt", "shrb_dsrt_brown_a1.apt")]})["id"]
    dust = author.add_family(doc, "flora", {"name": "dust devils", "density": 0.02, "children": [
        {"appearance": a} for a in ("must_dustdevil.prt", "must_dustdevil_2.prt", "must_dustdevil_3.prt")]})["id"]
    embers = author.add_family(doc, "flora", {"name": "lava flares", "density": 0.3, "children": [
        {"appearance": "must_lava_flare_small.prt"}, {"appearance": "must_lava_bubble.prt"}]})["id"]
    tufts = author.add_family(doc, "radial", {"name": "dry tufts", "density": 0.25, "children": [
        {"shader": s, "distance": 16.0, "min_width": 0.6, "max_width": 1.1, "min_height": 0.5, "max_height": 0.9,
         "should_sway": True, "displacement": 0.1, "period": 0.5} for s in ("radl_dsrt_grss_tuft",
                                                                         "radl_dsrt_grss_tuft_a1")]})["id"]
    tufts_far = author.add_family(doc, "radial", {"name": "dry tufts far", "density": 0.3, "children": [
        {"shader": "radl_far_lok_wastelands", "distance": 300.0, "min_width": 4.0, "max_width": 6.0,
         "min_height": 1.0, "max_height": 1.5}]})["id"]
    env_global = author.add_family(doc, "environment", {"name": "global"})["id"]
    env_desert = author.add_family(doc, "environment", {"name": "desert"})["id"]

    frac = {}
    for name, f in [("plains", dict(seed=4401, octaves=5, frequency=2.0, amplitude=0.45, scale_x=0.00035,
                                    scale_y=0.00035)),
                    ("detail", dict(seed=4402, octaves=3, frequency=2.5, amplitude=0.5, scale_x=0.012,
                                    scale_y=0.012)),
                    ("mesas", dict(seed=4403, octaves=3, frequency=2.0, amplitude=0.35, scale_x=0.0011,
                                   scale_y=0.0011)),
                    ("canyons", dict(seed=4404, octaves=2, frequency=2.2, amplitude=0.4, scale_x=0.0007,
                                     scale_y=0.0007, combination_rule=2)),
                    ("spire fields", dict(seed=4405, octaves=2, frequency=2.0, amplitude=0.5, scale_x=0.0009,
                                          scale_y=0.0009)),
                    ("patches", dict(seed=4406, octaves=2, frequency=2.0, amplitude=0.5, scale_x=0.006,
                                     scale_y=0.006))]:
        frac[name] = author.add_family(doc, "fractal", {"name": name, **f})["id"]

    # --- ground
    base = author.add_layer(doc, "", "ground")
    author.add_item(doc, base, "height_fractal", "plains", {"family_id": frac["plains"], "operation": 0,
                                                           "scale_y": 160.0})
    author.add_item(doc, base, "height_fractal", "detail", {"family_id": frac["detail"], "operation": 1,
                                                           "scale_y": 6.0})
    author.add_item(doc, base, "shader_constant", "red sand", {"family_id": sand})
    author.add_item(doc, base, "environment", "global", {"family_id": env_global})
    author.add_item(doc, base, "flora_dynamic_near", "tufts", {"family_id": tufts, "operation": 1})
    author.add_item(doc, base, "flora_dynamic_far", "tufts far", {"family_id": tufts_far, "operation": 1})
    author.add_item(doc, base, "flora_static_non_collidable", "scree", {"family_id": pebbles, "operation": 1})

    mesas = author.add_layer(doc, "", "mesas and buttes")
    author.add_item(doc, mesas, "fractal", "mesa mask", {"family_id": frac["mesas"], "low": 0.63, "high": 1.0,
                                                         "scale_y": 1.0, "feather_distance": 0.12,
                                                         "feather_function": 3})
    author.add_item(doc, mesas, "height_constant", "raise", {"operation": 1, "height": 95.0})
    author.add_item(doc, mesas, "height_terrace", "terraces", {"fraction": 0.85, "height": 32.0})
    author.add_item(doc, mesas, "flora_static_non_collidable", "no scree", {"family_id": pebbles, "remove_all": True})

    canyons = author.add_layer(doc, "", "canyon network")
    author.add_item(doc, canyons, "fractal", "ridges", {"family_id": frac["canyons"], "low": 0.93, "high": 1.0,
                                                        "scale_y": 1.0, "feather_distance": 0.6,
                                                        "feather_function": 1})
    author.add_item(doc, canyons, "height_constant", "cut", {"operation": 2, "height": 45.0})
    author.add_item(doc, canyons, "shader_constant", "floor", {"family_id": floor})

    # --- named landforms
    def area_layer(name, feather=0.45):
        x, z, r = AREAS[name]
        lp = author.add_layer(doc, "", name)
        author.add_item(doc, lp, "circle", name, {"center_x": x, "center_z": z, "radius": r, "feather_function": 3,
                                                  "feather_distance": feather})
        return lp
    dunes = author.add_family(doc, "fractal", {"name": "dunes", "seed": 4407, "octaves": 3, "frequency": 2.0,
                                               "amplitude": 0.4, "scale_x": 0.004, "scale_y": 0.011})["id"]
    ridges = author.add_family(doc, "fractal", {"name": "ridges", "seed": 4408, "octaves": 5, "frequency": 2.1,
                                                "amplitude": 0.5, "scale_x": 0.0012, "scale_y": 0.0012,
                                                "combination_rule": 2})["id"]
    hills = author.add_family(doc, "fractal", {"name": "hills", "seed": 4409, "octaves": 4, "frequency": 2.0,
                                               "amplitude": 0.5, "scale_x": 0.003, "scale_y": 0.003})["id"]
    badl = author.add_family(doc, "fractal", {"name": "badlands", "seed": 4410, "octaves": 3, "frequency": 2.3,
                                              "amplitude": 0.45, "scale_x": 0.004, "scale_y": 0.004,
                                              "combination_rule": 2})["id"]
    lp = area_layer("E'Y-Akh Desert", 0.5)
    author.add_item(doc, lp, "height_fractal", "dunes", {"family_id": dunes, "operation": 0, "scale_y": 18.0})
    author.add_item(doc, lp, "shader_constant", "ash sand", {"family_id": ash})
    author.add_item(doc, lp, "flora_static_non_collidable", "bare", {"family_id": pebbles, "remove_all": True})
    author.add_item(doc, lp, "flora_dynamic_near", "bare", {"family_id": tufts, "remove_all": True})
    lp = area_layer("Badlands of N'g'zi")
    author.add_item(doc, lp, "height_fractal", "gullies", {"family_id": badl, "operation": 2, "scale_y": 35.0})
    author.add_item(doc, lp, "height_terrace", "benches", {"fraction": 0.7, "height": 12.0})
    lp = area_layer("Im'g'twe Hills")
    author.add_item(doc, lp, "height_fractal", "hills", {"family_id": hills, "operation": 1, "scale_y": 70.0})
    lp = area_layer("Northern mountains", 0.6)
    author.add_item(doc, lp, "height_fractal", "peaks", {"family_id": ridges, "operation": 1, "scale_y": 420.0})
    lp = area_layer("Korakanni Mound", 0.95)
    author.add_item(doc, lp, "height_constant", "mound", {"operation": 1, "height": 140.0})
    author.add_item(doc, lp, "height_terrace", "rings", {"fraction": 0.75, "height": 20.0})

    # --- craters (rim first, then bowl)
    rnd = random.Random(19)
    craters = author.add_layer(doc, "", "impact craters")
    sites = [(rnd.uniform(-7000, 7000), rnd.uniform(-7000, 7000), rnd.uniform(40, 260)) for _ in range(40)]
    sites = [s for s in sites if min(math.dist(s[:2], p) for p in (OUTPOST, ARENA, HIVE, FOUNDRY)) > s[2] * 2 + 300]
    for i, (x, z, r) in enumerate(sites):
        rim = author.add_layer(doc, craters, f"crater {i} rim")
        author.add_item(doc, rim, "circle", "rim", {"center_x": x, "center_z": z, "radius": r * 1.45,
                                                    "feather_function": 3, "feather_distance": 0.55})
        author.add_item(doc, rim, "height_constant", "rim", {"operation": 1, "height": r * 0.12})
        bowl = author.add_layer(doc, craters, f"crater {i} bowl")
        author.add_item(doc, bowl, "circle", "bowl", {"center_x": x, "center_z": z, "radius": r,
                                                      "feather_function": 3, "feather_distance": 0.85})
        author.add_item(doc, bowl, "height_constant", "bowl", {"operation": 2, "height": r * 0.35})
        author.add_item(doc, bowl, "shader_constant", "scorch", {"family_id": scorch,
                                                                "use_feather_clamp_override": True,
                                                                "feather_clamp_override": 0.6})

    # --- scarce surface water (~5 % of the surface): a salt lake and oasis basins with local water tables, filled
    #     by flash-flood channels (rivers with water) that run down from the uplands
    water = author.add_layer(doc, "", "basins and flood channels")
    rnd = random.Random(5)
    for i, (x, z, r) in enumerate(BASINS):
        ground = generator.heights_at(doc, [[x, z]])[0]
        pts = []
        for k in range(14):
            a = 2 * math.pi * k / 14
            rr = r * rnd.uniform(0.7, 1.15)
            pts.append([x + rr * math.cos(a), z + rr * 0.8 * math.sin(a)])
        basin = author.add_layer(doc, water, f"basin {i}")
        author.add_item(doc, basin, "polygon", "shore", {"points": pts, "feather_function": 3,
                                                         "feather_distance": r * 0.45, "local_water_table": True,
                                                         "water_height": ground - 5.0, "water_shader_size": 16.0,
                                                         "water_shader": "wter_dsrt_bright"})
        author.add_item(doc, basin, "height_constant", "bed", {"operation": 0, "height": ground - 14.0})
        author.add_item(doc, basin, "shader_constant", "mud", {"family_id": floor})
        for t, fam in (("flora_static_collidable", boulders), ("flora_static_non_collidable", pebbles),
                       ("flora_dynamic_near", tufts)):
            author.add_item(doc, basin, t, "clear", {"family_id": fam, "remove_all": True})
    for i, pts in enumerate(FLOOD_CHANNELS):
        author.add_river(doc, [list(p) for p in pts], width=46.0, bank_family=canyon, bottom_family=floor,
                         trench_depth=7.0, feather=0.45, water=True, water_depth=2.5, water_width=14.0,
                         water_shader="wter_dsrt_bright", water_shader_size=12.0, velocity=1.5, parent=water,
                         name=f"flood channel {i}")

    # --- painting by slope / height / noise
    paint = author.add_layer(doc, "", "painting")
    cliffs = author.add_layer(doc, paint, "cliffs")
    author.add_item(doc, cliffs, "slope", "steep", {"min_angle": 38.0, "max_angle": 90.0, "feather_distance": 0.1})
    author.add_item(doc, cliffs, "shader_constant", "red cliff", {"family_id": cliff})
    author.add_item(doc, cliffs, "flora_static_non_collidable", "no scree", {"family_id": pebbles,
                                                                             "remove_all": True})
    author.add_item(doc, cliffs, "flora_dynamic_near", "no tufts", {"family_id": tufts, "remove_all": True})
    slopes = author.add_layer(doc, paint, "slopes")
    author.add_item(doc, slopes, "slope", "moderate", {"min_angle": 18.0, "max_angle": 38.0,
                                                       "feather_distance": 0.2})
    author.add_item(doc, slopes, "shader_constant", "rust", {"family_id": rust})
    author.add_item(doc, slopes, "flora_static_collidable", "boulders", {"family_id": boulders, "operation": 1})
    tops = author.add_layer(doc, paint, "mesa tops")
    author.add_item(doc, tops, "height", "high", {"low_height": 150.0, "high_height": 2000.0,
                                                  "feather_distance": 0.02})
    author.add_item(doc, tops, "slope", "flat", {"min_angle": 0.0, "max_angle": 18.0})
    author.add_item(doc, tops, "shader_constant", "mesa top", {"family_id": mesa_top})
    lows = author.add_layer(doc, paint, "canyon walls")
    author.add_item(doc, lows, "height", "low", {"low_height": -500.0, "high_height": 10.0,
                                                 "feather_distance": 0.05})
    author.add_item(doc, lows, "slope", "walls", {"min_angle": 20.0, "max_angle": 90.0})
    author.add_item(doc, lows, "shader_constant", "canyon rock", {"family_id": canyon})
    drift = author.add_layer(doc, paint, "ash drifts")
    author.add_item(doc, drift, "fractal", "patches", {"family_id": frac["patches"], "low": 0.62, "high": 1.0,
                                                       "scale_y": 1.0, "feather_distance": 0.3})
    author.add_item(doc, drift, "shader", "on sand", {"family_id": sand})
    author.add_item(doc, drift, "shader_replace", "sand to ash", {"source_family_id": sand,
                                                                  "destination_family_id": ash})
    author.add_item(doc, drift, "flora_static_non_collidable", "dust devils", {"family_id": dust, "operation": 1})
    author.add_item(doc, drift, "environment", "desert", {"family_id": env_desert})

    # --- spire fields (hives in the wild)
    fields = author.add_layer(doc, "", "spire fields")
    author.add_item(doc, fields, "fractal", "field mask", {"family_id": frac["spire fields"], "low": 0.7,
                                                           "high": 1.0, "scale_y": 1.0, "feather_distance": 0.3})
    author.add_item(doc, fields, "slope", "flat ground", {"min_angle": 0.0, "max_angle": 25.0})
    author.add_item(doc, fields, "flora_static_collidable", "spires", {"family_id": spires, "operation": 1})

    # --- hives: rock-mound spire cities (Stalgasin, the capital, and Gehenbar, Golbah, Trippa)
    def hive_city(name, center, radius, mounds, seed):
        lp = author.add_layer(doc, "", name)
        author.add_item(doc, lp, "circle", name, {"center_x": center[0], "center_z": center[1], "radius": radius,
                                                  "feather_function": 3, "feather_distance": 0.3})
        author.add_item(doc, lp, "flora_static_collidable", "spires", {"family_id": spires, "operation": 1,
                                                                       "density_override": True,
                                                                       "density_override_density": 0.9})
        author.add_item(doc, lp, "shader_constant", "ash", {"family_id": ash})
        r_ = random.Random(seed)
        for i in range(mounds):
            a, d = r_.uniform(0, 2 * math.pi), radius * 0.7 * math.sqrt(r_.random())
            x, z = center[0] + d * math.cos(a), center[1] + d * math.sin(a)
            mound = author.add_layer(doc, lp, f"{name} mound {i}")
            r = r_.uniform(14, 34)
            author.add_item(doc, mound, "circle", "mound", {"center_x": x, "center_z": z, "radius": r,
                                                            "feather_function": 1, "feather_distance": 1.0})
            author.add_item(doc, mound, "height_constant", "mound", {"operation": 1,
                                                                     "height": r * r_.uniform(2.0, 3.2)})
            author.add_item(doc, mound, "shader_constant", "rust", {"family_id": rust})

    hive_city("Stalgasin hive", HIVE, 650.0, 36, 77)
    for k, (name, c) in enumerate(HIVES.items()):
        hive_city(name, c, 380.0, 16, 100 + k)

    # --- Petranaki arena: a raised butte with a bowl and a sand floor
    arena = author.add_layer(doc, "", "Petranaki arena")
    butte = author.add_layer(doc, arena, "arena butte")
    author.add_item(doc, butte, "circle", "butte", {"center_x": ARENA[0], "center_z": ARENA[1], "radius": 330.0,
                                                    "feather_function": 3, "feather_distance": 0.35})
    author.add_item(doc, butte, "height_constant", "butte top", {"operation": 0, "height": 150.0})
    author.add_item(doc, butte, "height_terrace", "tiers", {"fraction": 0.8, "height": 25.0})
    author.add_item(doc, butte, "shader_constant", "rust", {"family_id": rust})
    author.add_flatten(doc, {"circle": [ARENA[0], ARENA[1], 95.0]}, height=126.0, feather=45.0,
                       parent=arena, name="arena floor", shader_family=sand)

    # --- Progate Temple (a plaza) and Point Rain (a flat, scorched battle plain with its caltrop field)
    tx, tz, tr = AREAS["Progate Temple"]
    th = generator.heights_at(doc, [[tx, tz]])[0]
    author.add_flatten(doc, {"circle": [tx, tz, tr * 0.6]}, height=round(th + 4.0, 1), feather=tr * 0.4,
                       name="Progate Temple plaza", shader_family=slab)
    px, pz, pr = AREAS["Point Rain"]
    ph = generator.heights_at(doc, [[px, pz]])[0]
    rain = author.add_flatten(doc, {"circle": [px, pz, pr * 0.7]}, height=round(ph, 1), feather=pr * 0.3,
                              name="Point Rain battle plain", shader_family=scorch, clear_flora=False)
    author.add_item(doc, rain, "flora_static_non_collidable", "caltrop field debris",
                    {"family_id": pebbles, "operation": 1, "density_override": True,
                     "density_override_density": 0.8})

    # --- the outpost / landing field and the droid foundry
    for (cx, cz), half, name, fam in ((OUTPOST, 90.0, "outpost landing field", slab),
                                      (FOUNDRY, 220.0, "droid foundry", slab)):
        h = generator.heights_at(doc, [[cx, cz]])[0]
        author.add_flatten(doc, {"rect": [cx - half, cz - half, cx + half, cz + half]}, height=round(h, 1),
                           feather=40.0, name=name, shader_family=fam)
    fh = doc.node(str(len(doc.layers) - 1))["items"][1]["params"]["height"]
    author.add_ribbon(doc, [[FOUNDRY[0] - 200, FOUNDRY[1] - 240, fh - 0.3], [FOUNDRY[0], FOUNDRY[1] - 250, fh - 0.3],
                            [FOUNDRY[0] + 200, FOUNDRY[1] - 240, fh - 0.3]], width=6.0, water_shader="wter_lava_01",
                      terrain_shader_family=lava, water_type="lava", velocity=0.3, name="foundry lava channel")
    flares = author.add_layer(doc, "", "foundry lava flares")
    author.add_item(doc, flares, "polyline", "channel", {"points": [[FOUNDRY[0] - 200, FOUNDRY[1] - 240],
                                                                    [FOUNDRY[0], FOUNDRY[1] - 250],
                                                                    [FOUNDRY[0] + 200, FOUNDRY[1] - 240]],
                                                         "width": 4.0})
    author.add_item(doc, flares, "flora_static_non_collidable", "flares", {"family_id": embers, "operation": 1})

    # --- catacombs: a deep dry gorge (a river without water)
    author.add_river(doc, [list(p) for p in CATACOMBS], width=90.0, bank_family=canyon, bottom_family=floor,
                     trench_depth=55.0, feather=0.35, water=False, name="catacomb gorge")

    # --- roads from the outpost
    for target, name in ((ARENA, "arena road"), (FOUNDRY, "foundry road"), (HIVE, "hive road")):
        mid = ((OUTPOST[0] + target[0]) / 2 + (target[1] - OUTPOST[1]) * 0.08,
               (OUTPOST[1] + target[1]) / 2 - (target[0] - OUTPOST[0]) * 0.08)
        pts = [[OUTPOST[0] + (target[0] - OUTPOST[0]) * 0.04, OUTPOST[1] + (target[1] - OUTPOST[1]) * 0.04],
               list(mid), [target[0] - (target[0] - mid[0]) * 0.12, target[1] - (target[1] - mid[1]) * 0.12]]
        author.add_road(doc, pts, width=10.0, shader_family=ash, feather=0.6, shader_feather=0.3, name=name)
    return doc


def write_environment(game_root: Path) -> list[str]:
    """Client sky / lighting for terrain/geonosis.trn (terrain/environment/geonosis.iff and
    datatables/environment/geonosis.iff, rows keyed by the environment families "global" and "desert"): Lok's red
    desert sky with Geonosis' major moons and its ring added (the env_create / env_edit tools do the same)."""
    from swg_maya_mcp.terrain import env
    sky, table = env.copy_from("lok", DATA_ROOTS)
    for shader, size, yaw, pitch in SKY_EXTRAS:
        env.set_envm(sky, "celestial", {"shader": shader, "size": size, "yaw": yaw, "pitch": pitch})
    return env.save("geonosis", sky, table, game_root)


def regions() -> list[dict]:
    """Named regions for the server's region table (datatables/region/region_geonosis)."""
    geo = {"E'Y-Akh Desert": "desert", "Badlands of N'g'zi": "canyon", "Im'g'twe Hills": "hills",
           "Korakanni Mound": "hills", "Progate Temple": "city", "Point Rain": "plains",
           "Northern mountains": "mountains"}
    out = [{"name": n, "x": x, "z": z, "radius": r, "geographical": geo[n],
            "buildable": 0 if n in ("Progate Temple", "Point Rain") else 1} for n, (x, z, r) in AREAS.items()]
    out += [{"name": "Stalgasin hive", "x": HIVE[0], "z": HIVE[1], "radius": 650.0, "geographical": "city",
             "buildable": 0},
            {"name": "Petranaki arena", "x": ARENA[0], "z": ARENA[1], "radius": 330.0, "geographical": "city",
             "buildable": 0},
            {"name": "Geonosis droid foundry", "x": FOUNDRY[0], "z": FOUNDRY[1], "radius": 300.0,
             "geographical": "city", "buildable": 0},
            {"name": "Geonosis outpost", "x": OUTPOST[0], "z": OUTPOST[1], "radius": 150.0, "geographical": "city",
             "buildable": 0},
            {"name": "Geonosian catacombs", "x": CATACOMBS[2][0], "z": CATACOMBS[2][1], "radius": 900.0,
             "geographical": "canyon", "buildable": 0}]
    out += [{"name": n, "x": c[0], "z": c[1], "radius": 380.0, "geographical": "city", "buildable": 0}
            for n, c in HIVES.items()]
    return out


def main(out: str, register: bool = False) -> None:
    t0 = time.time()
    doc = build()
    hd = generator.bake_height_data(doc, data_roots=DATA_ROOTS)
    print("height data:", [(r["name"], r["points"]) for r in hd])
    v = author.validate(doc)
    print("validation:", json.dumps(v, indent=1))
    print(doc.save(out), f"{time.time() - t0:.1f} s")
    print("environment:", write_environment(Path(out).resolve().parent.parent))
    if register:
        from swg_maya_mcp.terrain import env, planet
        sky, table, _ = env.load("geonosis", [str(Path(out).resolve().parent.parent)])
        res = planet.register("D:/titan", "geonosis", out, "Geonosis", regions=regions(), environment=(sky, table),
                              data_roots=DATA_ROOTS)
        print(json.dumps(res, indent=1))


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--register"]
    main(args[0] if args else "D:/exported/terrain/geonosis.trn", "--register" in sys.argv)
