"""Build the Atmo Flight Starport onto the stock ring starport (maya/swg_mcp/starport_ring.py) and make it spawnable:
.pob + cells + floors, exterior .lod (stock far LODs kept) with the overhead-map footprint, terrain flatten layer +
structure footprint + building template, rail checks, review renders (aerial, field, plan cutaways, interiors).

Run: python examples/make_atmo_starport.py   ->  /scene objectCreate object/building/titan/shared_titan_atmo_starport.iff x z 0
     python examples/make_atmo_starport.py --no-maya   redo the exterior .lod, template and terrain layer from the last
                                                        export (no Maya; reads <export>/build/titan_atmo_starport.json)"""
import asyncio
import base64
import json
import os
import sys
import tempfile
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

NAME = "titan_atmo_starport"
EXPORT = os.environ.get("TITAN_EXPORT_ROOT", "D:/exported")
RENDERS = Path(os.environ.get("FILLER_RENDER_DIR", os.path.join(tempfile.gettempdir(), "swg_fillers")))

CODE = r'''
import importlib, swg_mcp.pob_builder as pb, swg_mcp.filler as fl, swg_mcp.filler_plan as fp, swg_mcp.starport as sp
import swg_mcp.starport_ring as sr
for m in (pb, fl, fp, sp, sr):
    importlib.reload(m)
result = sr.build(args['name'], args['export_root'])
'''


BUILD_INFO = Path(EXPORT) / f"build/{NAME}.json"
# the full exterior (with the apron and paving over the terrain hole) is drawn out to here; beyond it the stock far
# LODs, which lack them, while the terrain there is drawn from chunks the hole isn't cut in
NEAR_LOD_RANGE = 550.0      # what the Maya build reported, for --no-maya


def text(res):
    return "\n".join(getattr(c, "text", "") for c in res.content)


async def main():
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            if "--no-maya" in sys.argv:
                await finish(s, json.loads(BUILD_INFO.read_text()))
                return
            await s.call_tool("swg_setup", {})
            res = await s.call_tool("maya_python", {"code": "args = " + json.dumps({"name": NAME, "export_root": EXPORT}) + "\n" + CODE,
                                                    "timeout_seconds": 1800})
            try:
                data = json.loads(text(res))
            except ValueError:
                print(text(res)[-4000:])
                return
            if not data.get("ok"):
                print(data.get("error"), (data.get("traceback") or "")[-2500:])
                return
            out = data["result"]
            print({k: out[k] for k in ("cells", "portals", "rewired", "unpaired", "rooms", "pads", "entrances", "towers", "well")})
            BUILD_INFO.parent.mkdir(parents=True, exist_ok=True)
            BUILD_INFO.write_text(json.dumps({"exclude": out["exclude"], "pads_layout": out["pads_layout"],
                                              "well": {k: out["well"][k] for k in ("shaft_r", "floor_y", "levels", "doors")},
                                              "apron": out["apron"], "shuttle": out["shuttle"],
                                              "bay_table": out["bay_table"]}, indent=1))
            await finish(s, out)
            RENDERS.mkdir(parents=True, exist_ok=True)
            views = [("aerial", {"view": "perspective", "azimuth": 200, "elevation": 40}),
                     ("plan_ground", {"view": "cutaway", "cut_height": 4.0}),
                     ("plan_upper", {"view": "cutaway", "cut_height": 11.0}),
                     ("field", {"view": "eye", "eye": [0, 9, -40], "look_at": [0, 2, 10], "fov": 85}),
                     ("west_concourse", {"view": "eye", "eye": [-24.0, 2.7, -8.0], "look_at": [-22.0, 2.4, 10.0], "fov": 85}),
                     ("east_access", {"view": "eye", "eye": [30.0, 2.7, -4.0], "look_at": [44.0, 2.4, 6.0], "fov": 85}),
                     ("well_down", {"view": "eye", "eye": [-1.5, 6.0, -10.0], "look_at": [-1.5, -40.0, 6.0], "fov": 95}),
                     ("hangar_ring", {"view": "eye", "eye": [20.5, -21.8, -12.0], "look_at": [0.0, -22.5, 16.0], "fov": 95}),
                     ("upper_storey", {"view": "eye", "eye": [-28.0, 10.2, -8.0], "look_at": [-40.0, 10.0, 10.0], "fov": 85}),
                     ("plan_checkpoint", {"view": "cutaway", "cut_height": 2.6})]
            for nm, kw in views:
                if nm.startswith("plan"):
                    await s.call_tool("maya_python", {"code": f"[cmds.setAttr(m + '.visibility', 0) for m in cmds.ls('|{NAME}|r0|mesh', long=True)]\nresult=1"})
                else:
                    await s.call_tool("maya_python", {"code": f"[cmds.setAttr(m + '.visibility', 1) for m in cmds.ls('|{NAME}|r0|mesh', long=True)]\nresult=1"})
                img = await s.call_tool("maya_render", {"width": 1000, "height": 700, **kw})
                for c in img.content:
                    if getattr(c, "data", None):
                        (RENDERS / f"{NAME}_{nm}.png").write_bytes(base64.b64decode(c.data))
            print("renders in", RENDERS)


def convex_hull(points):
    """Counter-clockwise convex hull of 2D points (monotone chain)."""
    pts = sorted(set((round(x, 4), round(z, 4)) for x, z in points))
    cross = lambda o, a, b: (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def mouth_edges(flr_path, well):
    """The bays' mouths onto the shaft: every level but the bottom one ends in a sheer drop, so the walk floor's
    edges along the shaft circle above the bottom level are uncrossable. Engine x is Maya -x; the circle is centred
    on the courtyard (Maya C = (-1.5, 0))."""
    from swg_maya_mcp import iff
    cx, cz, r, bottom = 1.5, 0.0, well["shaft_r"], well["floor_y"]

    def rule(a, b, et):
        on = lambda p: abs(((p[0] - cx) ** 2 + (p[2] - cz) ** 2) ** 0.5 - r) < 0.05
        return 0 if on(a) and on(b) and min(a[1], b[1]) > bottom + 1.0 else et
    return iff.set_floor_edge_types(flr_path, rule)


def pad_edges(flr_path, L):
    """The raised landing pads' walk-floor edges: the deck's rim (y = pad height) uncrossable where the guard rail
    stands - all round but the stair mouth, the stair ramp's sides too - and the field floor's edge round each pad
    and stair (y = field height) a wall base, open only at the stair's foot. Engine x is Maya -x."""
    from swg_maya_mcp import iff
    fy = L["field_y"]

    def on_seg(x, z, a, b, tol=0.05):
        (ax, az), (bx, bz) = a, b
        dx, dz = bx - ax, bz - az
        t = max(0.0, min(1.0, ((x - ax) * dx + (z - az) * dz) / ((dx * dx + dz * dz) or 1.0)))
        return abs(x - ax - t * dx) <= tol and abs(z - az - t * dz) <= tol

    rails, feet = [], []
    for (x0, z0, x1, z1), (sx0, sx1, sz_top, sz_foot) in zip(L["rects"], L["stairs"]):
        rails += [((x0, z0), (x1, z0)), ((x0, z0), (x0, z1)), ((x1, z0), (x1, z1)), ((x0, z1), (sx0, z1)), ((sx1, z1), (x1, z1)),
                  ((sx0, sz_top), (sx0, sz_foot)), ((sx1, sz_top), (sx1, sz_foot))]
        feet += rails[-7:-2] + [((sx, sz_top), (sx, sz_foot - (0.2 if sz_foot > sz_top else -0.2))) for sx in (sx0, sx1)]
        # (the stair's sides block down to its last 20 cm, where the ramp meets the field)

    def rule(a, b, et):
        pa, pb_ = (-a[0], a[2]), (-b[0], b[2])
        both = lambda segs: any(on_seg(*pa, *s_) and on_seg(*pb_, *s_) for s_ in segs)
        if max(a[1], b[1]) > fy + 0.02 and both(rails):     # the deck's rim and the stair's sloping sides
            return 0
        if max(a[1], b[1]) < fy + 0.02 and both(feet):      # the field floor round the pad and the stair
            return 2
        return et
    return iff.set_floor_edge_types(flr_path, rule)


def well_edges(flr_path, well):
    """The bays' walk floors: every open edge left crossable on a bay level that is not a doorway (lounge doors, the
    gate lift's door - floor vertices at their jambs) nor a welded seam is uncrossable (lounge fronts, lift columns):
    stepping off there would drop a level. Not a wall base: FloorMesh::canExitEdge lets a mover off a wall base edge
    when it heads along the edge's normal, which these merged r0 floors point outward (walked through in the client)."""
    from swg_maya_mcp import iff
    seams = {frozenset((tuple(round(c, 3) for c in a), tuple(round(c, 3) for c in b))) for a, b in iff.floor_seam_edges(flr_path)}
    levels, doors = well["levels"], well["doors"]

    def in_door(p):
        for x0, z0, x1, z1, y in doors:
            if abs(p[1] - y) > 0.05:
                continue
            dx, dz = x1 - x0, z1 - z0
            t = ((p[0] - x0) * dx + (p[2] - z0) * dz) / (dx * dx + dz * dz)
            if -0.01 <= t <= 1.01 and abs((p[0] - x0) * dz - (p[2] - z0) * dx) / (dx * dx + dz * dz) ** 0.5 < 0.05:
                return True
        return False

    def rule(a, b, et):
        if et not in (1, 2) or not any(abs(a[1] - y) < 0.05 and abs(b[1] - y) < 0.05 for y in levels):
            return et
        if in_door(a) and in_door(b):
            return et
        if frozenset((tuple(round(c, 3) for c in a), tuple(round(c, 3) for c in b))) in seams:
            return et
        return 0
    return iff.set_floor_edge_types(flr_path, rule)


def apron_edges(flr_path, apron):
    """The apron's inner edge (on the courtyard's paving circle, under the ring wall) is uncrossable: past it is the
    terrain hole over a bay, with no floor. Its other edges stay crossable (terrain, the stock ground floors)."""
    from swg_maya_mcp import iff
    cx, cz = apron["centre"]
    r, y = apron["inner_r"], apron["y"]
    on = lambda p: abs(p[1] - y) < 0.01 and abs(((p[0] - cx) ** 2 + (p[2] - cz) ** 2) ** 0.5 - r) < 0.3

    def rule(a, b, et):
        return 0 if on(a) and on(b) else et
    return iff.set_floor_edge_types(flr_path, rule)


BAYS_TAB = Path("D:/titan/dsrc/sku.0/sys.server/compiled/game/datatables/space/titan_starport_bays.tab")


def write_bays_table(rows, structure=f"object/building/titan/{NAME}.iff"):
    """Traffic control's bay list (space.atmo.starport_traffic): starport_ring.bay_table rows under this structure,
    rows of other structures kept. Compile it on the server with titan.sh sync."""
    cols = ["structure", "bay", "level", "kind", "reserved", "x", "y", "z", "yaw", "depth", "width", "lounge"]
    types = ["s", "i", "i", "s", "i", "f", "f", "f", "f", "f", "f", "s"]
    keep = []
    if BAYS_TAB.is_file():
        keep = [l for l in BAYS_TAB.read_text().splitlines()[2:] if l.strip() and not l.startswith(structure + "\t")]
    lines = ["\t".join(cols), "\t".join(types)] + keep
    lines += ["\t".join([structure] + [str(r[c]) for c in cols[1:]]) for r in rows]
    BAYS_TAB.write_text("\n".join(lines) + "\n")
    return {"path": str(BAYS_TAB), "rows": len(rows)}


async def finish(s, out):
    """Everything after the Maya export: exterior .lod, template + footprint, terrain layer, rail checks."""
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    from swg_maya_mcp import iff, rails
    data = "D:/titan/data/sku.0/sys.client/compiled/game"
    stock_lod = Path(data) / "appearance/lod/mun_all_starport_s01_u01_r0_mesh.lod"
    pob = Path(EXPORT) / f"appearance/{NAME}.pob"
    for fp in sorted((Path(EXPORT) / "appearance/collision").glob(f"{NAME}_r*_collision_floor0.flr")):
        seams = iff.open_floor_seams(fp)                    # welded seams (checkpoint lanes) would stop the player
        if seams["seams"]:
            print("seams opened", fp.name, seams["seams"])
    if out.get("well"):
        print("bay mouths", mouth_edges(Path(EXPORT) / f"appearance/collision/{NAME}_r0_collision_floor0.flr", out["well"]))
    if out.get("well", {}).get("doors"):
        print("bay floor edges", well_edges(Path(EXPORT) / f"appearance/collision/{NAME}_r0_collision_floor0.flr", out["well"]))
    if out.get("apron"):
        print("apron edges", apron_edges(Path(EXPORT) / f"appearance/collision/{NAME}_r0_collision_floor0.flr", out["apron"]))
    if out.get("well", {}).get("doors") or out.get("apron"):
        # the bays' floors are strips cut round the lounges: their T-junction seams go on (the typing above walls
        # every open edge it can't tell from a seam)
        print("r0 seams reopened", iff.open_floor_seams(Path(EXPORT) / f"appearance/collision/{NAME}_r0_collision_floor0.flr"))
    if out.get("pads_layout"):
        print("pad edges", pad_edges(Path(EXPORT) / f"appearance/collision/{NAME}_r0_collision_floor0.flr", out["pads_layout"]))
    if out.get("bay_table"):
        print("bays table", write_bays_table(out["bay_table"]))
    print("lod", iff.write_exterior_lod(EXPORT, pob, stock_lod=stock_lod, near_range=NEAR_LOD_RANGE))
    tpl = json.loads(text(await s.call_tool("swg_building_template", {"name": NAME, "feather": 16.0})))
    print("template", tpl.get("template"), "\nspawn", tpl.get("spawn"))
    lay = Path(EXPORT) / f"terrain/{NAME}.lay"
    # flatten along the building's own outline (the stock map shape) instead of a square, then cut the terrain out
    # exactly over the landing well's hangar ring (fine exclusion) - both "local" shapes that follow the building
    outline = iff.radar_outline(stock_lod)
    if out.get("pads_layout"):             # the yacht pads stand outside the ring: flatten under them too
        for x0, z0, x1, z1 in out["pads_layout"]["rects"]:
            outline += [(-x0, z0), (-x1, z0), (-x1, z1 + 1.0), (-x0, z1 + 1.0)]    # engine x = -Maya x; +1 m: the stairs
        outline = convex_hull(outline)
    hole = out["exclude"]
    if hole.get("polygon"):                # the bays run out past the building: flatten round them too
        outline = convex_hull(list(outline) + [tuple(p) for p in hole["polygon"]])
    print("flatten", iff.shape_building_layer(lay, outline, feather=12.0, margin=3.0, flora_margin=1.0))
    print("exclude", iff.add_exclude_layer(lay, name="local landing well hole",
                                           **({"polygon": [tuple(p) for p in hole["polygon"]]} if hole.get("polygon")
                                              else {"circle": tuple(hole["circle"])})))
    chk = rails.check(pob, EXPORT)
    print("rails ok", chk["ok"], chk["issues"][:5], "window portals", chk["window_portals"])


asyncio.run(main())
