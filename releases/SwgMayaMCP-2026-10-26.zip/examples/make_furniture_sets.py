"""Build the themed furniture sets (maya/swg_mcp/furniture.py): Hutt palace, Rebel Alliance and Galactic Empire,
five pieces each, and make every piece spawnable:

  texture/ + shader/frn_titan_*            generated materials (examples/frn_materials.py)
  appearance/frn_titan_<piece>.apt         -> appearance/lod/frn_titan_<piece>.lod: 4 detail levels, extent box,
                                              NULL collision (like stock furniture), the mesh's hardpoints
                                              (`foot` on seats and beds, `bed` on beds)
  object/tangible/furniture/titan/shared_frn_titan_<piece>.iff
                                           derived from a stock furniture template of the same kind, named from
  string/en/frn_titan_n.stf / _d.stf       (object names and descriptions)

Seats sit with the stock chair mechanics (the `foot` hardpoint; /sit with the piece targeted). Beds also need the
client's bed-rest hook (clientGame GamePlaybackScript, the `bed` hardpoint) and the stock bed animations
all_b_std_standing_to_laying_bed_multi / all_b_idl_sleeping_idle1 / all_b_std_laying_to_standing_bed_multi.ans,
which this script copies into the export tree (the client paks do not have them).

The headless Maya is shared: take D:/titan/.locks/maya first (see the swg-coordination memory note).

Run:   python examples/make_furniture_sets.py [piece ...]          (all 15 by default)
       python examples/make_furniture_sets.py --finish <built.json> (host side only, from furniture.build outputs)
       .venv/Scripts/python.exe examples/make_furniture_sets.py --build-only <raw.json> piece ...
                                         (Maya exports only: the venv has mcp but no numpy; then
                                          python examples/frn_materials.py and --finish <raw.json>)
Spawn: /scene objectCreate object/tangible/furniture/titan/shared_frn_titan_<piece>.iff x z heading
Then:  python examples/make_templates.py frn_titan    (dsrc .tpf sources for the WSL server)"""
import asyncio
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
from swg_maya_mcp import customization as C  # noqa: E402
from swg_maya_mcp import iff  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
CLIENT = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
SHARED = Path(os.environ.get("TITAN_SHARED_ROOT", "D:/titan/data/sku.0/sys.shared/compiled/game"))
LISTING = Path(os.environ.get("FRN_LISTING", os.path.join(tempfile.gettempdir(), "swg_furniture_sets", "built.json")))
LOD_RANGES = (12.0, 30.0, 80.0)
BED_ANIMS = ["all_b_std_standing_to_laying_bed_multi.ans", "all_b_idl_sleeping_idle1.ans",
             "all_b_std_laying_to_standing_bed_multi.ans"]
FRN = "object/tangible/furniture/"
BASES = {"seat": FRN + "modern/shared_chair_modern_style_01.iff", "bed": FRN + "all/shared_frn_all_bed_lg_s1.iff",
         "table": FRN + "modern/shared_table_modern_style_01.iff", "decor": FRN + "all/shared_frn_all_lamp_free_s01.iff",
         "cabinet": FRN + "modern/shared_armoire_modern_style_01.iff",
         "screen": FRN + "all/shared_frn_all_lamp_free_s01.iff",
         "painting": "object/tangible/painting/shared_frn_all_painting_ahsoka_tano_s01.iff",
         "rtcamera": "object/tangible/device/shared_rt_camera.iff",
         "interact": FRN + "modern/shared_chair_modern_style_01.iff",       # stations are sat on (`foot`)
         "lamp": FRN + "all/shared_frn_all_lamp_free_s01_lit.iff"}           # clientDataFile -> our light
# the station activities' animations (clientGame GamePlaybackScript cs_stations), copied like the bed ones
STATION_ANIMS = ["all_b_force_standing_to_meditation.ans", "all_b_force_meditation.ans",
                 "all_b_force_meditation_to_standing.ans", "all_b_idl_kneeling_idle1.ans", "all_b_std_kneeling_to_standing.ans",
                 "all_b_dnc_musician_gong_dance.ans", "all_b_int_wipe_surface.ans", "all_b_int_standing_pour_container.ans",
                 "all_b_int_use_data_terminal.ans", "all_b_int_skin_creature.ans", "all_b_int_use_console.ans"]
# piece -> (template base kind, name, description)
INFO = {
    "hutt_throne": ("seat", "Hutt Lounging Throne",
                    "A crime lord's lounging throne: a two-tier carved dais, deep velvet seat, a silk bolster sweeping "
                    "round to the armrests and a carved arch crowned with a brass sunburst."),
    "hutt_sarlacc_bed": ("bed", "Sarlacc Maw Bed",
                         "A round velvet bed set inside a sculpted Sarlacc maw, rows of bone teeth and all. Climb in "
                         "over the tongue. Sweet dreams of being slowly digested over a thousand years."),
    "hutt_hookah": ("decor", "Palace Hookah",
                    "A towering water pipe from a Hutt's audience chamber: green water in a caged glass globe, "
                    "glowing coals and three velvet hoses."),
    "hutt_pouf": ("seat", "Hutt Velvet Pouf", "A tufted velvet pouf on a brass claw-foot ring."),
    "hutt_table": ("table", "Hutt Banquet Table",
                   "A low carved banquet table at Hutt lounging height, with brass banding and a live-gorg jar."),
    "reb_xwing_chair": ("seat", "X-wing Cockpit Lounger",
                        "The cockpit section of a retired T-65, pilot seat and all, with the canopy raised and an "
                        "astromech still socketed behind. The instrument deck still lights up."),
    "reb_holotable": ("table", "Yavin War-Room Holotable",
                      "The Alliance briefing table from the Massassi temple, projecting the battle station's "
                      "superlaser dish and trench."),
    "reb_bunk": ("bed", "Echo Base Survival Bunk",
                 "A Hoth-issue cot with a thermal hood over the pillow, a thermal blanket and a footlocker."),
    "reb_crate_bench": ("seat", "Rebel Supply-Crate Bench",
                        "A bench improvised from two supply crates, a quilted flight-suit cushion and a salvaged "
                        "hull plate for a backrest."),
    "reb_locker": ("cabinet", "Alliance Gear Locker",
                   "A field locker standing open on blaster rifles, a trooper helmet and a flight suit."),
    "imp_pod": ("seat", "Imperial Meditation Pod",
                "A black clamshell meditation chamber: the upper shell lifts on chrome rams over a leather seat, "
                "toothed rims and a red-lit interior."),
    "imp_sd_table": ("table", "Star Destroyer Conference Table",
                     "A dagger-shaped command table in Star Destroyer grey, its bridge tower rendered as a hologram "
                     "over the stern."),
    "imp_bunk": ("bed", "Imperial Officer's Bunk",
                 "Regulation officer's quarters: gloss frame on a red-lit plinth, grey linen and the crest of the "
                 "Empire on the headboard."),
    "imp_chair": ("seat", "Imperial Officer's Chair", "A swivel command chair with a winged high back and red-lit armrests."),
    "imp_holo_crest": ("decor", "Imperial Holo-Crest Pedestal",
                       "A pedestal projecting the Imperial crest, with two TIE fighters on an endless patrol round it."),
    "imp_superlaser_console": ("seat", "Superlaser Fire-Control Station",
                               "A Death Star gunnery station: a seat facing a curved console with the firing lever "
                               "banks and the targeting display. Sit down and run the firing sequence."),
    "hutt_feast_lounge": ("seat", "Hutt Feasting Lounge",
                          "A velvet couch drawn up to a half-moon banquet board loaded with a roast, exotic fruit and a "
                          "bowl of live gorgs. Sit down and help yourself."),
    "imp_video_screen": ("screen", "Imperial Briefing Screen",
                         "A gloss-black briefing monolith with a 2 m display. Set it as a video player and only the "
                         "screen shows the stream; the frame keeps its finish."),
    "reb_video_screen": ("screen", "Alliance Field Briefing Screen",
                         "A riveted field display on a tripod with a keyboard shelf and a power crate. Set it as a "
                         "video player and only the screen shows the stream."),
    "hutt_video_screen": ("screen", "Hutt Palace Screen",
                          "A display in a carved wood and brass frame under a sunburst crown, silk drapes at the "
                          "sides. Set it as a video player and only the screen shows the stream."),
    "gilded_painting": ("painting", "Gilded Gallery Frame",
                        "An ornate gilded frame. Give it a magic painting URL and the image fills the canvas only."),
    "hutt_painting": ("painting", "Hutt Palace Frame",
                      "A carved wood frame with brass studs, a jewelled medallion and silk tassels, for a magic "
                      "painting."),
    "reb_painting": ("painting", "Alliance Salvage Frame",
                     "A frame cut from hull plating, squadron stripe and starbird plaque, for a magic painting."),
    "imp_painting": ("painting", "Imperial Frame",
                     "A stepped gloss-black frame with a chrome bevel, a red light strip and the crest, for a magic "
                     "painting."),
    "cam_droid": ("rtcamera", "RT Camera Droid",
                  "A hovering cam droid over its charging pad. Link it to an RT screen: the feed is shot from its "
                  "lens."),
}
LIGHTS = {}
import frn_sets  # noqa: E402
frn_sets.merge(info=INFO, lights=LIGHTS)
RELOAD = ("import importlib, swg_mcp.pob_builder as pb, swg_mcp.furniture as fu\n"
          "importlib.reload(fu)\n")


def template_rel(piece):
    kind = INFO[piece][0]
    if kind == "painting":                  # the client treats templates named "...painting..." as paintings
        return f"object/tangible/painting/titan/shared_frn_titan_{piece}.iff"
    if kind == "rtcamera":                  # the server template inherits object/tangible/device/rt_camera.iff
        return f"object/tangible/device/shared_frn_titan_rt_{piece}.iff"
    return f"{FRN}titan/shared_frn_titan_{piece}.iff"


def write_strings():
    for suffix, idx in (("n", 1), ("d", 2)):
        stf = {"flag": 1, "next_id": 1, "entries": [], "name_order": []}
        for piece, info in INFO.items():
            C.stf_set(stf, f"frn_titan_{piece}", info[idx])
        p = EXPORT / f"string/en/frn_titan_{suffix}.stf"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(C.write_stf(stf))


def copy_bed_animations():
    for a in BED_ANIMS + STATION_ANIMS:
        dst = EXPORT / "appearance/animation" / a
        if not dst.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(CLIENT / "appearance/animation" / a, dst)


def finish_piece(out):
    """Host side after furniture.build: the .lod (4 LODs, extent, NULL collision, hardpoints) and the template."""
    b = out["bounds"]
    lod = iff.write_static_lod(EXPORT, out["apt"], [], False, None, bounds=[b[:3], b[3:]], lods=out["lods"],
                               lod_ranges=LOD_RANGES)
    kind = INFO[out["name"]][0]
    rel = template_rel(out["name"])
    params = {"appearanceFilename": out["apt"]}
    if kind == "lamp":
        params["clientDataFile"] = None
    if out["name"] in LIGHTS:                # the light(s) on the piece's light hardpoints, like stock lit lamps
        cdf = f"clientdata/furniture/client_shared_frn_titan_{out['name']}.cdf"
        iff.write_client_data(EXPORT / cdf, hardpoint_lights=LIGHTS[out["name"]])
        params["clientDataFile"] = cdf
    iff.derive_template(SHARED / BASES[kind], EXPORT / rel, params,
                        string_ids={"objectName": ("frn_titan_n", f"frn_titan_{out['name']}"),
                                    "detailedDescription": ("frn_titan_d", f"frn_titan_{out['name']}")})
    return {**out, "template": rel, "lod": lod["lod"], "lod_count": lod["lods"], "base": BASES[kind],
            "size": [round(b[3] - b[0], 2), round(b[4] - b[1], 2), round(b[5] - b[2], 2)]}


def finish(built):
    write_strings()
    copy_bed_animations()
    made = [finish_piece(o) for o in built]
    LISTING.parent.mkdir(parents=True, exist_ok=True)
    LISTING.write_text(json.dumps(made, indent=1))
    for m in made:
        print(f"{m['name']:18s} {m['kind']:6s} lods {m['lod_count']} faces {m['faces']} size {m['size']} "
              f"hardpoints {[h[0] for h in m.get('hardpoints', [])]}")
    return made


async def build_all(pieces):
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    built = []
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            for piece in pieces:
                args = {"piece": piece, "export_root": str(EXPORT).replace("\\", "/")}
                res = await s.call_tool("maya_python", {"code": "args = " + json.dumps(args) + "\n" + RELOAD +
                                                        "result = fu.build(args['piece'], args['export_root'])",
                                                        "timeout_seconds": 900})
                data = json.loads("\n".join(getattr(c, "text", "") for c in res.content))
                if not data.get("ok"):
                    raise RuntimeError(f"{piece}: {data.get('error')} {(data.get('traceback') or '')[-1500:]}")
                built.append(data["result"])
                print("built", piece, flush=True)
            await s.call_tool("maya_scene", {"action": "new"})
    return built


def main(argv):
    if argv[:1] == ["--finish"]:
        finish(json.loads(Path(argv[1]).read_text()))
        return
    if argv[:1] == ["--build-only"]:        # Maya side only (an interpreter with mcp but maybe no numpy)
        Path(argv[1]).write_text(json.dumps(asyncio.run(build_all(argv[2:])), indent=1))
        return
    import frn_materials
    frn_materials.write_all(str(EXPORT))
    pieces = argv or list(INFO)
    finish(asyncio.run(build_all(pieces)))


if __name__ == "__main__":
    main(sys.argv[1:])
