"""Maya-free preview and lint of themed furniture pieces (maya/swg_mcp/furniture.py + frn_groups/): builds the
pieces' geometry in plain Python (maya.cmds stubbed), renders four textured views with a small numpy rasteriser
and checks the conventions. Faces seen from behind render MAGENTA: the client culls back faces, so magenta means
a hole in game (inside-out face, missing underside/back, single-sided sheet).

  python examples/frn_preview.py <group|piece> [...] [--out DIR] [--lod N]
      group = a frn_groups module name (sith, jedi, ...) or a theme prefix (hutt, imp, ...); writes
      DIR/<piece>.png (4 views, hardpoints marked, a 1.8 m scale post) and DIR/<group>_lineup.png, prints lint.

Lint: floor contact (min y ~ 0), face budget (LOD0 <= 8000, LOD3 <= 1200, LODs non-increasing), hardpoints per
kind (seat: foot; interact: foot + a station / seat-activity hardpoint; lamp: light hardpoints matching LIGHTS),
every slot mapped to an existing material, INFO present with the same kind."""
from __future__ import annotations

import math
import os
import sys
import types
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / "maya"))

# -- stub Maya so the geometry code imports --------------------------------------------------------------------
if "maya" not in sys.modules:
    maya = types.ModuleType("maya")
    maya.cmds = types.ModuleType("maya.cmds")
    maya.mel = types.ModuleType("maya.mel")
    maya.OpenMaya = types.ModuleType("maya.OpenMaya")
    sys.modules.update({"maya": maya, "maya.cmds": maya.cmds, "maya.mel": maya.mel, "maya.OpenMaya": maya.OpenMaya})
    api = types.ModuleType("maya.api")
    api.OpenMaya = types.ModuleType("maya.api.OpenMaya")
    sys.modules.update({"maya.api": api, "maya.api.OpenMaya": api.OpenMaya})

import frn_materials  # noqa: E402
from swg_mcp import furniture as fu  # noqa: E402
from swg_mcp import frn_groups  # noqa: E402

SEAT_ACTIVITIES = ("use_console", "eat")
W, H = 700, 520
_TEX = {}


def texture(key):
    if key not in _TEX:
        mats = frn_materials.all_mats()
        if key not in mats:
            _TEX[key] = (None, "a_simple")
        else:
            img = np.asarray(mats[key][1](), np.uint8)
            _TEX[key] = (img.astype(np.float32) / 255.0, mats[key][0])
    return _TEX[key]


def triangles(P):
    """[(slot, pts (n,3,3), uvs (n,3,2))] fan-triangulated from the accumulators."""
    out = []
    for slot, acc in P.acc.items():
        if not acc.counts:
            continue
        pts = np.asarray(acc.points, np.float64)
        uvs = np.asarray(acc.uvs, np.float64) if acc.uvs else np.zeros((1, 2))
        T, U = [], []
        k = 0
        for cnt in acc.counts:
            ids = acc.connects[k:k + cnt]
            uid = acc.uv_ids[k:k + cnt]
            for j in range(1, cnt - 1):
                T.append((ids[0], ids[j], ids[j + 1]))
                U.append((uid[0], uid[j], uid[j + 1]))
            k += cnt
        T, U = np.asarray(T), np.asarray(U)
        out.append((slot, pts[T], uvs[U]))
    return out


def look_at(eye, target):
    f = np.asarray(target, float) - eye
    f /= np.linalg.norm(f)
    r = np.cross(f, (0.0, 1.0, 0.0))
    r /= np.linalg.norm(r)
    u = np.cross(r, f)
    return f, r, u


def render(tris, theme, eye, target, fov=32.0, hardpoints=(), post=None):
    eye = np.asarray(eye, float)
    f, r, u = look_at(eye, target)
    focal = (W / 2) / math.tan(math.radians(fov) / 2)
    img = np.zeros((H, W, 3), np.float32) + np.array([0.16, 0.17, 0.19], np.float32)
    # floor grid
    yy, xx = np.mgrid[0:H, 0:W]
    zbuf = np.full((H, W), np.inf, np.float32)
    objbuf = np.zeros((H, W), np.int8)               # 0 empty, 1 front face, 2 back face (final visibility)
    light = np.array([0.45, 0.8, 0.55])
    light /= np.linalg.norm(light)
    stats = {"pix": 0, "back": 0}

    def project(p):                                    # (..., 3) -> screen x, y, depth
        d = p - eye
        z = d @ f
        return (W / 2 + focal * (d @ r) / z), (H / 2 - focal * (d @ u) / z), z

    alpha_jobs = []
    if post is not None:                              # scale post: a 1.8 m column
        x0, z0 = post
        q = np.array([[x0 - 0.1, 0, z0 - 0.1], [x0 + 0.1, 0, z0 - 0.1], [x0 + 0.1, 1.8, z0 - 0.1], [x0 - 0.1, 1.8, z0 - 0.1]])
        tris = list(tris) + [("__post__", np.array([[q[0], q[1], q[2]], [q[0], q[2], q[3]]]), np.zeros((2, 3, 2)))]
    for slot, pts, uvs in tris:
        if slot == "__post__":
            tex, eff = None, "post"
        else:
            key = fu.SLOTS.get(theme, {}).get(slot)
            tex, eff = texture(key) if key else (None, "a_simple")
        nrm = np.cross(pts[:, 1] - pts[:, 0], pts[:, 2] - pts[:, 0])
        ln = np.linalg.norm(nrm, axis=1)
        ok = ln > 1e-12
        nrm[ok] /= ln[ok, None]
        cen = pts.mean(axis=1)
        facing = np.einsum("ij,ij->i", nrm, eye - cen) > 0
        sx, sy, sz = project(pts)
        is_alpha = eff.startswith("a_alpha")
        for t in range(len(pts)):
            if not ok[t] or (sz[t] <= 0.05).any() or (is_alpha and not facing[t]):   # culled glow/glass back
                continue
            x0_, x1_ = int(max(0, math.floor(sx[t].min()))), int(min(W - 1, math.ceil(sx[t].max())))
            y0_, y1_ = int(max(0, math.floor(sy[t].min()))), int(min(H - 1, math.ceil(sy[t].max())))
            if x1_ < x0_ or y1_ < y0_:
                continue
            gx = xx[y0_:y1_ + 1, x0_:x1_ + 1] + 0.5
            gy = yy[y0_:y1_ + 1, x0_:x1_ + 1] + 0.5
            (ax, bx, cx), (ay, by, cy) = sx[t], sy[t]
            den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
            if abs(den) < 1e-9:
                continue
            w0 = ((by - cy) * (gx - cx) + (cx - bx) * (gy - cy)) / den
            w1 = ((cy - ay) * (gx - cx) + (ax - cx) * (gy - cy)) / den
            w2 = 1 - w0 - w1
            m = (w0 >= -1e-4) & (w1 >= -1e-4) & (w2 >= -1e-4)
            if not m.any():
                continue
            iz = w0 / sz[t][0] + w1 / sz[t][1] + w2 / sz[t][2]
            depth = 1.0 / iz
            zb = zbuf[y0_:y1_ + 1, x0_:x1_ + 1]
            m &= depth < zb - 1e-5
            if not m.any():
                continue
            if eff == "post":
                rgb = np.array([0.25, 0.45, 0.9])
                a = None
            elif not facing[t]:
                rgb = np.array([1.0, 0.0, 1.0])
                a = None
            else:
                if tex is None:
                    rgb = np.broadcast_to(np.array([0.6, 0.6, 0.6]), m.shape + (3,))
                    a = None
                else:
                    uu = (w0 * uvs[t][0, 0] / sz[t][0] + w1 * uvs[t][1, 0] / sz[t][1] + w2 * uvs[t][2, 0] / sz[t][2]) * depth
                    vv = (w0 * uvs[t][0, 1] / sz[t][0] + w1 * uvs[t][1, 1] / sz[t][1] + w2 * uvs[t][2, 1] / sz[t][2]) * depth
                    th, tw = tex.shape[:2]
                    ti = ((1.0 - (vv % 1.0)) * th).astype(int) % th
                    tj = ((uu % 1.0) * tw).astype(int) % tw
                    s = tex[ti, tj]
                    rgb, a = s[..., :3], s[..., 3]
                if "emis" not in eff:
                    shade = 0.38 + 0.62 * max(0.0, float(nrm[t] @ light)) + 0.12 * max(0.0, float(-nrm[t] @ light))
                    rgb = rgb * shade
            if is_alpha and facing[t]:
                alpha_jobs.append((y0_, y1_, x0_, x1_, m & True, depth, rgb, a, eff))
                continue
            sub = img[y0_:y1_ + 1, x0_:x1_ + 1]
            if np.ndim(rgb) == 1:
                sub[m] = rgb
            else:
                sub[m] = rgb[m]
            zb[m] = depth[m]
            ob = objbuf[y0_:y1_ + 1, x0_:x1_ + 1]
            ob[m] = 0 if slot == "__post__" else (1 if facing[t] else 3 if is_alpha else 2)   # 3: culled glow/glass
    for y0_, y1_, x0_, x1_, m, depth, rgb, a, eff in alpha_jobs:     # alpha surfaces over the opaque ones
        zb = zbuf[y0_:y1_ + 1, x0_:x1_ + 1]
        m = m & (depth < zb)
        if not m.any():
            continue
        sub = img[y0_:y1_ + 1, x0_:x1_ + 1]
        al = (a if a is not None else np.full(m.shape, 0.5))[m][:, None]
        src = rgb[m] if np.ndim(rgb) > 1 else rgb
        sub[m] = sub[m] + src * al if "emis" in eff else sub[m] * (1 - al) + src * al
    stats["pix"] = int((objbuf > 0).sum())
    stats["back"] = int((objbuf == 2).sum())
    out = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    d = ImageDraw.Draw(out)
    for hp in hardpoints:
        name, pos = hp[0], np.asarray(hp[1], float)
        x, y, z = project(pos)
        if z <= 0:
            continue
        colr = (60, 230, 90) if name == "foot" else (255, 220, 40) if name.startswith("light") else \
            (40, 220, 255) if name in fu.STATIONS else (255, 255, 255)
        d.ellipse([x - 5, y - 5, x + 5, y + 5], outline=colr, width=2)
        d.text((x + 7, y - 6), name, fill=colr)
        if len(hp) > 2:                                # facing arrow (yaw about y)
            yaw = math.radians(hp[2][1])
            tip = pos + 0.45 * np.array([math.sin(yaw), 0.0, math.cos(yaw)])
            tx, ty, tz = project(tip)
            if tz > 0:
                d.line([x, y, tx, ty], fill=colr, width=2)
    return out, stats


def views(bounds):
    lo, hi = np.asarray(bounds[:3]), np.asarray(bounds[3:])
    c = (lo + hi) / 2
    rad = max(0.5, float(np.linalg.norm(hi - lo)) / 2)
    dist = rad / math.tan(math.radians(16)) * (W / H) * 1.08
    tgt = c.copy()
    out = []
    for az, el in ((35, 22), (-40, 32), (150, 24), (90, 6)):
        a, e = math.radians(az), math.radians(el)
        eye = tgt + dist * np.array([math.sin(a) * math.cos(e), math.sin(e), math.cos(a) * math.cos(e)])
        out.append((az, el, eye, tgt))
    return out


def bounds_of(tris):
    allp = np.concatenate([p.reshape(-1, 3) for _, p, _ in tris])
    return list(allp.min(axis=0)) + list(allp.max(axis=0))


def lint(name, P0, faces, info, lights):
    issues = []
    kind = fu.PIECES[name][1]
    theme = name.split("_")[0]
    tris = triangles(P0)
    b = bounds_of(tris)
    if b[1] < -0.02:
        issues.append(f"sinks below the floor (min y {b[1]:.3f})")
    if b[1] > 0.01:
        issues.append(f"floats (min y {b[1]:.3f})")
    if faces[0] > 8000:
        issues.append(f"LOD0 {faces[0]} faces > 8000")
    if faces[3] > 1200:
        issues.append(f"LOD3 {faces[3]} faces > 1200")
    if any(faces[k + 1] > faces[k] for k in range(3)):
        issues.append(f"LOD faces not non-increasing {faces}")
    hps = [h[0] for h in P0.hardpoints]
    if kind in ("seat", "interact", "bed") and "foot" not in hps:
        issues.append("no foot hardpoint")
    if kind == "interact" and not any(h in fu.STATIONS or h in SEAT_ACTIVITIES for h in hps):
        issues.append("interact piece without a station / seat-activity hardpoint")
    if kind == "lamp":
        lh = [h for h in hps if h.startswith("light")]
        if not lh:
            issues.append("lamp without a light hardpoint")
        want = sorted(lt.get("hardpoint") for lt in lights.get(name, []))
        if want != sorted(lh):
            issues.append(f"LIGHTS hardpoints {want} != light hardpoints {sorted(lh)}")
    if kind != "lamp" and name in lights:
        issues.append("LIGHTS entry on a piece whose kind is not lamp (fine, but the template base keeps no light)")
    for slot in P0.acc:
        key = fu.SLOTS.get(theme, {}).get(slot)
        if not key:
            issues.append(f"slot {slot!r} not in SLOTS[{theme!r}]")
        elif key not in frn_materials.all_mats():
            issues.append(f"material {key!r} (slot {slot}) not in MATS")
    if name not in info:
        issues.append("no INFO entry")
    elif info[name][0] != kind:
        issues.append(f"INFO kind {info[name][0]!r} != PIECES kind {kind!r}")
    return issues, b


def preview_piece(name, out_dir, info, lights):
    Ps = [fu.build_piece(name, lod) for lod in range(4)]
    faces = [sum(len(a.counts) for a in P.acc.values()) for P in Ps]
    issues, b = lint(name, Ps[0], faces, info, lights)
    tris = triangles(Ps[0])
    theme = name.split("_")[0]
    sheet = Image.new("RGB", (W * 2, H * 2 + 70), (24, 24, 26))
    backs = []
    for i, (az, el, eye, tgt) in enumerate(views(b)):
        im, st = render(tris, theme, eye, tgt, hardpoints=Ps[0].hardpoints, post=(b[3] + 0.45, (b[2] + b[5]) / 2))
        backs.append(round(100.0 * st["back"] / max(1, st["pix"]), 2))
        ImageDraw.Draw(im).text((8, 6), f"az {az} el {el}  back-facing {backs[-1]}%", fill=(230, 230, 230))
        sheet.paste(im, ((i % 2) * W, 70 + (i // 2) * H))
    d = ImageDraw.Draw(sheet)
    d.text((8, 6), f"{name}  [{fu.PIECES[name][1]}]  faces {faces}  size {b[3]-b[0]:.2f} x {b[4]-b[1]:.2f} x {b[5]-b[2]:.2f} m"
           f"  hardpoints {[h[0] for h in Ps[0].hardpoints]}", fill=(255, 255, 255))
    d.text((8, 26), ("LINT: " + "; ".join(issues)) if issues else "lint ok", fill=(255, 120, 120) if issues else (120, 255, 120))
    d.text((8, 46), "magenta = back face (invisible in game)   blue post = 1.8 m", fill=(180, 180, 180))
    out = Path(out_dir) / f"{name}.png"
    sheet.save(out)
    return {"name": name, "faces": faces, "bounds": [round(v, 3) for v in b], "issues": issues, "back_pct": backs,
            "png": str(out)}


def lineup(names, out_png):
    """All pieces in a row, front 3/4 view, each built at its own origin and shifted along x."""
    allt, x, hps = [], 0.0, []
    themes = {}
    for name in names:
        P = fu.build_piece(name, 0)
        tris = triangles(P)
        b = bounds_of(tris)
        dx = x - b[0]
        for slot, pts, uvs in tris:
            q = pts.copy()
            q[..., 0] += dx
            allt.append((f"{name}|{slot}", q, uvs))
        themes[name] = name.split("_")[0]
        x += (b[3] - b[0]) + 0.6
    # render with per-piece slot lookups
    groups = {}
    for key, pts, uvs in allt:
        nm, slot = key.split("|")
        groups.setdefault(themes[nm], []).append((slot, pts, uvs))
    b = bounds_of([(None, p, None) for _, p, _ in allt])
    lo, hi = np.asarray(b[:3]), np.asarray(b[3:])
    c = (lo + hi) / 2
    span = float(hi[0] - lo[0])
    eye = c + np.array([span * 0.35, span * 0.32 + 1.0, span * 0.95 + 2.0])
    # one render per theme would not z-test against the others: merge into one theme map instead
    merged_theme = "__lineup__"
    fu.SLOTS[merged_theme] = {}
    tris = []
    for key, pts, uvs in allt:
        nm, slot = key.split("|")
        k = f"{themes[nm]}::{slot}"
        fu.SLOTS[merged_theme][k] = fu.SLOTS.get(themes[nm], {}).get(slot)
        tris.append((k, pts, uvs))
    global W, H
    W0, H0 = W, H
    W, H = 1800, 700
    try:
        im, _ = render(tris, merged_theme, eye, c, fov=40)
    finally:
        W, H = W0, H0
    im.save(out_png)
    return out_png


def resolve(arg):
    if arg in frn_groups.GROUPS:
        import importlib
        m = importlib.import_module(f"swg_mcp.frn_groups.{arg}")
        return list(m.PIECES)
    if arg in fu.PIECES:
        return [arg]
    return [n for n in fu.PIECES if n.split("_")[0] == arg]


def main(argv):
    out = Path(os.environ.get("TEMP", "/tmp")) / "frn_preview"
    lod = 0
    args = []
    k = 0
    while k < len(argv):
        if argv[k] == "--out":
            out = Path(argv[k + 1]); k += 2
        elif argv[k] == "--lod":
            lod = int(argv[k + 1]); k += 2
        else:
            args.append(argv[k]); k += 1
    out.mkdir(parents=True, exist_ok=True)
    import frn_sets
    info, lights = {}, {}
    import make_furniture_sets as mfs
    info.update(mfs.INFO)
    lights.update(mfs.LIGHTS)
    if frn_groups.ERRORS:
        print("frn_groups import problems:", {g: e for g, e in frn_groups.ERRORS.items() if e != "missing"})
    if frn_sets.ERRORS:
        print("frn_sets import problems:", {g: e for g, e in frn_sets.ERRORS.items() if e != "missing"})
    for arg in args:
        names = resolve(arg)
        if not names:
            print(f"{arg}: no pieces")
            continue
        for n in names:
            r = preview_piece(n, out, info, lights)
            print(f"{n:28s} faces {r['faces']} back% {r['back_pct']} {'LINT ' + '; '.join(r['issues']) if r['issues'] else 'ok'}"
                  f"  -> {r['png']}")
        if len(names) > 1:
            print("lineup ->", lineup(names, out / f"{arg}_lineup.png"))


if __name__ == "__main__":
    main(sys.argv[1:])
