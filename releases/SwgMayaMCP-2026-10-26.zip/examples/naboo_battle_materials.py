"""Materials of the Battle of Naboo heroic set (examples/make_naboo_battle.py): generated textures (numpy + Pillow,
system Python) and the .sht shaders that use them, written into the export tree so exportStaticMesh reuses them 1:1
(swgShaderPath = the absolute .sht path).

    python examples/naboo_battle_materials.py [export_root] [preview.png]

Vehicles (Trade Federation paint over bare metal, worn the way the reference renders show it):
  tf_mtt_paint        MTT hull: rust-red enamel, panel seams, rivet rows, scuffs to bare metal   a_specmap (alpha = spec)
  tf_aat_paint        AAT hull: ochre enamel, heavy soot streaks and chipped edges              a_specmap
  tf_aat_cream        AAT struts and sensor pods: bone-white enamel                            a_specmap
  tf_metal_dark       guns, rails, droid rack, undercarriage: blued gunmetal                   a_specmap
  tf_vent             louvred intake / exhaust panels (fit 0..1 on the panel)                  a_specmap
  tf_glow_red         AAT / MTT sensor slits and droid eyes: deep red, full bright             a_emis_full
Gungan Grand Army:
  nboo_shield_dome    the shield dome: pale lilac-blue, rippling like water, dark ripple spots a_alpha_emis_full
  nboo_shield_rim     where the dome meets the ground: a bright crackling band                  a_alpha_emis_full
  nboo_hand_shield    the warriors' energy shields: violet, brighter at the rim                 a_alpha_emis_full
  nboo_gungan_brass   generator housings, catapult fittings: patinated bronze                   a_specmap
  nboo_gungan_hide    straps and pads: tanned kaadu leather                                     a_simple
  nboo_gungan_glow    generator emitter bulbs, boomas: blue-white plasma                        a_emis_full
Effects:
  tf_plasma_bolt      AAT shell core: hot orange-white streak (alpha falls off along the bolt)  a_alpha_emis_full
  nboo_booma_glow     booma halo: blue-white soft glow                                          a_alpha_emis_full
Quest marker:
  titan_info_disk_historical   the Historical quest disc: an amber-gold medal with the Aurebesh Herf (H)   a_emis_full
Rally markers (where Jar Jar's narration sends the group):
  nboo_rally_beam     a gold light shaft fading upward                                          a_alpha_emis_full
  nboo_rally_ring     gold dashes on a faint band, on the ground round the objective            a_alpha_emis_full
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import iff  # noqa: E402

RNG_SEED = 1999          # the year of the battle's release; every texture derives its own seed from it


# ============================================================================
# noise helpers (tileable)
# ============================================================================

def value_noise(size, period, seed):
    """Tileable smooth value noise in [0, 1], `period` cells across."""
    rnd = np.random.default_rng(seed)
    g = rnd.random((period, period))
    t = (np.arange(size) + 0.5) * period / size
    i0 = np.floor(t).astype(int) % period
    i1 = (i0 + 1) % period
    f = t - np.floor(t)
    f = f * f * (3 - 2 * f)
    a = g[i0][:, i0] * (1 - f)[None, :] + g[i0][:, i1] * f[None, :]
    b = g[i1][:, i0] * (1 - f)[None, :] + g[i1][:, i1] * f[None, :]
    return a * (1 - f)[:, None] + b * f[:, None]


def fbm(size, base, octaves, seed, gain=0.5):
    out, amp, tot = np.zeros((size, size)), 1.0, 0.0
    for o in range(octaves):
        p = base << o
        if p > size:
            break
        out += value_noise(size, p, seed + o) * amp
        tot += amp
        amp *= gain
    return out / tot


def stretched_noise(size, px, py, seed):
    """Tileable value noise with different cell counts across and down (streaks: px small, py large)."""
    rnd = np.random.default_rng(seed)
    g = rnd.random((py, px))
    tx = (np.arange(size) + 0.5) * px / size
    ty = (np.arange(size) + 0.5) * py / size
    x0, y0 = np.floor(tx).astype(int) % px, np.floor(ty).astype(int) % py
    x1, y1 = (x0 + 1) % px, (y0 + 1) % py
    fx, fy = tx - np.floor(tx), ty - np.floor(ty)
    fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
    a = g[y0][:, x0] * (1 - fx)[None, :] + g[y0][:, x1] * fx[None, :]
    b = g[y1][:, x0] * (1 - fx)[None, :] + g[y1][:, x1] * fx[None, :]
    return a * (1 - fy)[:, None] + b * fy[:, None]


def worley(size, count, seed):
    """Tileable Worley noise: F1 and F2 - F1 (the second is ~0 on cell borders)."""
    rnd = np.random.default_rng(seed)
    pts = rnd.random((count, 2))
    pts = np.concatenate([pts + (dx, dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1)]).astype(np.float32)
    u = ((np.arange(size) + 0.5) / size).astype(np.float32)
    f1 = np.empty((size, size), np.float32)
    f2 = np.empty((size, size), np.float32)
    step = max(1, 2 ** 22 // (size * len(pts)))           # rows per pass, ~16 MB of distances
    for y0 in range(0, size, step):
        v = u[y0:y0 + step]
        d = (u[None, :, None] - pts[:, 0]) ** 2 + (v[:, None, None] - pts[:, 1]) ** 2
        two = np.partition(d, 1, axis=-1)[..., :2]
        f1[y0:y0 + step] = np.sqrt(two[..., 0])
        f2[y0:y0 + step] = np.sqrt(two[..., 1])
    return f1, f2 - f1


def grid_uv(size):
    u = (np.arange(size) + 0.5) / size
    return np.meshgrid(u, u)


def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


def line_mask(coord, period, width, offset=0.0):
    """Soft lines every `period` (UV units) of half-width `width`; tileable when 1/period is whole."""
    d = np.abs(((coord - offset) / period + 0.5) % 1.0 - 0.5) * period
    return np.exp(-(d / width) ** 2)


def rgba(r, g, b, a):
    return np.dstack([np.clip(c, 0, 255) for c in (r, g, b, a)]).astype(np.uint8)


# ============================================================================
# vehicle paint
# ============================================================================

def _scratches(size, seed, count):
    """Fine scratches to bare metal: short anti-aliased strokes, mostly near horizontal, drawn tileably."""
    rnd = np.random.default_rng(seed)
    ss = 2
    im = Image.new("L", (size * ss, size * ss), 0)
    d = ImageDraw.Draw(im)
    for _ in range(count):
        x, y = rnd.random() * size * ss, rnd.random() * size * ss
        ang = rnd.normal(0.0, 0.35) + (np.pi / 2 if rnd.random() < 0.15 else 0.0)
        ln = rnd.uniform(0.01, 0.06) * size * ss
        w = 1 if rnd.random() < 0.8 else 2
        x1, y1 = x + np.cos(ang) * ln, y + np.sin(ang) * ln
        for ox in (-size * ss, 0, size * ss):
            for oy in (-size * ss, 0, size * ss):
                d.line([(x + ox, y + oy), (x1 + ox, y1 + oy)], fill=int(rnd.uniform(140, 255)), width=w)
    im = im.resize((size, size), Image.LANCZOS)
    return np.asarray(im, float) / 255.0


def _panel_paint(size, seed, base, grime_col, scratch_col, panels=(4, 8), rivet_rows=True, soot=0.35,
                 chip=0.5, streak=0.6, streak_cols=96):
    """Worn enamel over steel. `base` RGB; panels = (seams across, seams down) per tile."""
    U, V = grid_uv(size)
    n_low = fbm(size, 2, 4, seed)
    n_mid = fbm(size, 8, 4, seed + 10)
    n_hi = fbm(size, 32, 3, seed + 20)
    # panel layout: staggered rows of plates, seams dark with a light lip
    rows = panels[1]
    row = np.floor(V * rows)
    stagger = (row % 2) * 0.5 / panels[0]
    seam_v = line_mask(V, 1.0 / rows, 0.0016)
    seam_u = line_mask((U + stagger) % 1.0, 1.0 / panels[0], 0.0016)
    seams = np.maximum(seam_u, seam_v)
    lip = np.maximum(line_mask(V, 1.0 / rows, 0.0016, 0.004), line_mask((U + stagger) % 1.0, 1.0 / panels[0], 0.0016, 0.004))
    # per-plate tint variation (repainted plates)
    plate_id = row * 131 + np.floor(((U + stagger) % 1.0) * panels[0]) * 17
    plate_tint = (np.sin(plate_id * 12.9898) * 43758.5453) % 1.0
    tint = 0.94 + 0.10 * plate_tint
    # rivets along seams
    riv = np.zeros_like(U)
    if rivet_rows:
        # one row just under every horizontal seam and one column beside every vertical seam
        pitch = 1.0 / (panels[0] * 16)
        dv = np.abs(((V - 0.008) * rows + 0.5) % 1.0 - 0.5) / rows
        du = np.abs((U / pitch + 0.5) % 1.0 - 0.5) * pitch
        riv = np.exp(-((du ** 2 + dv ** 2) / (0.0016 ** 2)))
        uc = ((U + stagger) % 1.0 - 0.009)
        du2 = np.abs((uc * panels[0] + 0.5) % 1.0 - 0.5) / panels[0]
        vpitch = 1.0 / (rows * 8)
        dv2 = np.abs((V / vpitch + 0.5) % 1.0 - 0.5) * vpitch
        riv = np.maximum(riv, np.exp(-((du2 ** 2 + dv2 ** 2) / (0.0016 ** 2))))
    # grime: vertical streaks from seams and rivets, darker at the plate bottoms
    streaks = stretched_noise(size, streak_cols, 3, seed + 30)
    streaks = smooth(0.45, 1.0, streaks) * (0.4 + 0.6 * n_low)
    in_plate_v = (V * rows) % 1.0
    pool = smooth(0.55, 1.0, in_plate_v) * 0.35
    grime = np.clip(streak * streaks + pool * n_mid + soot * smooth(0.55, 0.85, n_low), 0, 1)
    # chips and scratches to bare metal: edge-biased (near seams) plus fine scratch lines
    edge_near = np.maximum(seams, np.exp(-(np.minimum((V * rows) % 1.0, 1.0 - (V * rows) % 1.0) / 0.06)))
    chips = smooth(0.74 - 0.14 * edge_near * chip, 0.80 - 0.14 * edge_near * chip, n_hi * 0.6 + n_mid * 0.4)
    bare = np.clip(np.maximum(chips, _scratches(size, seed + 40, int(260 * chip)) * 0.85), 0, 1)

    paint = np.array(base, float)[None, None, :] * (tint * (0.88 + 0.18 * n_mid + 0.06 * n_hi))[..., None]
    gcol = np.array(grime_col, float)[None, None, :]
    scol = np.array(scratch_col, float)[None, None, :] * (0.85 + 0.3 * n_hi)[..., None]
    col = paint * (1 - grime[..., None] * 0.75) + gcol * grime[..., None] * 0.75
    col = col * (1 - bare[..., None]) + scol * bare[..., None]
    col = col * (1 - 0.55 * seams[..., None]) + 22 * lip[..., None]
    col = col * (1 - 0.35 * riv[..., None]) + 60 * riv[..., None] * (1 - grime[..., None])
    spec = 60 + 40 * n_hi + 150 * bare + 70 * riv - 50 * grime
    return rgba(col[..., 0], col[..., 1], col[..., 2], spec)


def tf_mtt_paint(size=1024):
    """Khaki enamel (the orthographic references), worn through to pale blue-grey primer in broad patches."""
    return _panel_paint(size, RNG_SEED + 100, (170, 150, 104), (66, 58, 40), (192, 200, 196), panels=(3, 4),
                        soot=0.2, chip=0.95, streak=0.45)


def tf_aat_paint(size=1024):
    return _panel_paint(size, RNG_SEED + 200, (196, 140, 58), (52, 38, 24), (176, 164, 140), panels=(3, 5),
                        soot=0.45, chip=0.75, streak=0.7, streak_cols=24)


def tf_aat_cream(size=512):
    return _panel_paint(size, RNG_SEED + 250, (214, 200, 160), (90, 74, 50), (190, 186, 176), panels=(2, 4),
                        soot=0.2, chip=0.45, streak=0.35)


def tf_metal_dark(size=512):
    U, V = grid_uv(size)
    n = fbm(size, 4, 5, RNG_SEED + 300)
    brush = stretched_noise(size, 2, 256, RNG_SEED + 301)
    wear = np.maximum(smooth(0.74, 0.86, fbm(size, 16, 3, RNG_SEED + 302)) * 0.7, _scratches(size, RNG_SEED + 303, 120) * 0.6)
    k = 0.75 + 0.35 * n + 0.08 * brush
    r, g, b = 58 * k + 70 * wear, 60 * k + 66 * wear, 66 * k + 60 * wear
    return rgba(r, g, b, 120 + 60 * brush + 70 * wear)


def tf_vent(size=256):
    """Louvres: 9 slats with dark gaps, framed (fit 0..1 on a panel)."""
    U, V = grid_uv(size)
    n = fbm(size, 8, 3, RNG_SEED + 400)
    slat = (V * 9) % 1.0
    shade = np.where(slat < 0.62, 0.55 + 0.6 * slat, 0.12)            # lit slat face, dark gap below it
    frame = np.maximum(smooth(0.93, 0.97, np.abs(U - 0.5) * 2), smooth(0.92, 0.96, np.abs(V - 0.5) * 2))
    k = shade * (1 - frame) + 0.85 * frame
    k *= 0.85 + 0.3 * n
    return rgba(70 * k, 66 * k, 62 * k, 90 + 80 * frame)


def tf_glow_red(size=64):
    U, V = grid_uv(size)
    c = 1.0 - 0.35 * np.hypot(U - 0.5, V - 0.5)
    return rgba(255 * c, 46 * c, 28 * c, 255 + 0 * U)


# ============================================================================
# Gungan Grand Army
# ============================================================================

def nboo_shield_dome(size=1024):
    """The film's shield: a lilac-blue membrane that ripples like water; darker ripple spots drift over it."""
    U, V = grid_uv(size)
    f1, edge = worley(size, 34, RNG_SEED + 500)
    _, edge2 = worley(size, 120, RNG_SEED + 501)
    n = fbm(size, 4, 5, RNG_SEED + 502)
    caustic = np.exp(-(edge / 0.02) ** 2) * 0.7 + np.exp(-(edge2 / 0.012) ** 2) * 0.35
    spots = smooth(0.70, 0.86, fbm(size, 16, 3, RNG_SEED + 503))
    k = 0.85 + 0.25 * n
    r = 168 * k + 70 * caustic - 40 * spots
    g = 182 * k + 66 * caustic - 36 * spots
    b = 255 * k
    # playtest: from inside (where the army fights) the full-strength membrane hid the battle; about half as dense
    a = 24 + 18 * n + 70 * caustic + 26 * spots
    return rgba(r, g, b, a)


def nboo_shield_rim(size=256):
    """Ground band (V: 0 = ground, 1 = top of the band): brightest at the ground, crackling streaks upward."""
    U, V = grid_uv(size)
    arcs = stretched_noise(size, 48, 2, RNG_SEED + 520)
    arcs = smooth(0.55, 0.95, arcs)
    fall = (1.0 - V) ** 2
    a = 255 * np.clip(fall * (0.55 + 0.6 * arcs), 0, 1)
    return rgba(190 + 65 * arcs, 205 + 50 * arcs, 255 + 0 * U, a)


def nboo_hand_shield(size=256):
    """A warrior's energy shield (fit 0..1 on the oval): violet, clear centre, bright rim, faint hex shimmer."""
    U, V = grid_uv(size)
    r = np.hypot((U - 0.5) * 2, (V - 0.5) * 2)
    rim = smooth(0.78, 0.98, r) * (1 - smooth(0.98, 1.02, r))
    n = fbm(size, 8, 3, RNG_SEED + 540)
    _, edge = worley(size, 40, RNG_SEED + 541)
    cells_ = np.exp(-(edge / 0.015) ** 2) * 0.35
    a = (40 + 30 * n + 70 * cells_) * (r < 1.0) + 210 * rim
    return rgba(180 + 60 * rim, 120 + 60 * rim + 40 * cells_, 255 + 0 * U, a)


def nboo_rally_beam(size=256):
    """Rally marker light shaft (U across a crossed plane, V up it): a gold core fading out sideways and upward,
    faint upward streaks so it reads as light, not a pole."""
    U, V = grid_uv(size)
    across = np.exp(-((U - 0.5) / 0.24) ** 2)
    up = (1.0 - V) ** 0.9 * smooth(0.0, 0.03, V)
    streak = smooth(0.35, 0.9, stretched_noise(size, 6, 40, RNG_SEED + 560))
    core = np.exp(-((U - 0.5) / 0.08) ** 2)
    # playtest: the first shaft was a faint green-yellow line against the sky; saturated gold, a solid core
    a = 255 * np.clip((0.55 * across + 0.6 * core) * up * (0.8 + 0.2 * streak) * 1.6, 0, 1)
    return rgba(255 + 0 * U, 172 + 70 * core, 40 + 150 * core, a)


def nboo_rally_ring(size=256):
    """Rally marker ground ring (U along the ring: one dash per tile, V across the band): gold dashes on a faint
    continuous band."""
    U, V = grid_uv(size)
    band = np.exp(-((V - 0.5) / 0.26) ** 2)
    dash = smooth(0.06, 0.12, U) * (1.0 - smooth(0.62, 0.68, U))
    a = 255 * np.clip(band * (0.28 + 0.72 * dash), 0, 1)
    return rgba(255 + 0 * U, 214 + 30 * dash, 120 + 60 * band, a)


def nboo_gungan_brass(size=512):
    U, V = grid_uv(size)
    n = fbm(size, 4, 5, RNG_SEED + 600)
    pat = smooth(0.55, 0.8, fbm(size, 8, 4, RNG_SEED + 601))           # verdigris patches
    hammered = fbm(size, 48, 2, RNG_SEED + 602)
    k = 0.8 + 0.3 * n + 0.1 * hammered
    r = (178 * k) * (1 - pat) + 92 * pat
    g = (128 * k) * (1 - pat) + 150 * pat
    b = (64 * k) * (1 - pat) + 120 * pat
    return rgba(r, g, b, 150 * (1 - pat) + 60 * hammered)


def nboo_gungan_hide(size=256):
    U, V = grid_uv(size)
    n = fbm(size, 8, 4, RNG_SEED + 650)
    grain = fbm(size, 64, 2, RNG_SEED + 651)
    k = 0.8 + 0.3 * n + 0.1 * grain
    return rgba(128 * k, 92 * k, 58 * k, 255 + 0 * U)


def nboo_gungan_glow(size=128):
    U, V = grid_uv(size)
    n = fbm(size, 4, 3, RNG_SEED + 700)
    _, edge = worley(size, 14, RNG_SEED + 701)
    vein = np.exp(-(edge / 0.03) ** 2)
    return rgba(150 + 90 * vein + 15 * n, 205 + 50 * vein, 255 + 0 * U, 255 + 0 * U)


# ============================================================================
# effects
# ============================================================================

def tf_plasma_bolt(size=256):
    """U along the bolt (0 = tail, 1 = head), V across: white-hot core, orange-red sheath, tail fading out."""
    U, V = grid_uv(size)
    across = np.abs(V - 0.5) * 2
    core = np.exp(-(across / 0.22) ** 2)
    sheath = np.exp(-(across / 0.6) ** 2)
    along = smooth(0.0, 0.75, U) * (1 - smooth(0.97, 1.0, U))
    r = 255 * np.ones_like(U)
    g = 90 + 165 * core
    b = 40 + 200 * core ** 2
    a = 255 * np.clip(sheath * along * 1.1, 0, 1)
    return rgba(r, g, b, a)


def nboo_booma_glow(size=128):
    U, V = grid_uv(size)
    d = np.hypot(U - 0.5, V - 0.5) * 2
    a = 255 * np.clip(1 - d, 0, 1) ** 1.6
    return rgba(170 + 85 * (1 - d), 215 + 40 * (1 - d), 255 + 0 * U, a)


# ============================================================================
# the Historical quest disc
# ============================================================================

def titan_info_disk_historical(size=256):
    """An amber-gold medal: raised rim, inner groove, ivory Aurebesh Herf (three bars, the middle one short),
    lit from the top left so it reads as metal even full bright. Same layout as the stock info_disk (the whole
    texture is the disc face, mapped planar)."""
    ss = 4
    S = size * ss
    U, V = grid_uv(S)
    x, y = (U - 0.5) * 2, (V - 0.5) * 2
    r = np.hypot(x, y)
    n = fbm(S, 8, 4, RNG_SEED + 800)
    # gold body: radial gradient + top-left light, darker toward the rim
    light = np.clip(0.75 - 0.35 * (x + y) / 1.4, 0.35, 1.1)
    k = (0.80 + 0.15 * n) * light
    col = np.stack([236 * k, 168 * k, 62 * k], -1)
    # rim (raised): bright bevel on the lit side, dark on the far side
    rim = smooth(0.80, 0.84, r) * (1 - smooth(0.98, 1.0, r))
    bevel = np.clip(-(x + y) / (r + 1e-6) * 0.5 + 0.5, 0, 1)
    rim_col = np.stack([255 * (0.55 + 0.45 * bevel), 214 * (0.5 + 0.5 * bevel), 120 * (0.45 + 0.55 * bevel)], -1)
    col = col * (1 - rim[..., None]) + rim_col * rim[..., None]
    groove = np.exp(-((r - 0.78) / 0.012) ** 2)
    col *= (1 - 0.6 * groove)[..., None]
    # Herf: three horizontal bars (top and bottom long, the middle one short), ivory with a dark drop shadow
    def bars(ox, oy):
        b = np.zeros_like(x)
        for cy, half_w in ((-0.36, 0.48), (0.0, 0.26), (0.36, 0.48)):
            b = np.maximum(b, (np.abs(x - ox) < half_w) * (np.abs(y - cy - oy) < 0.085))
        return b
    shadow = Image.fromarray((bars(0.035, 0.035) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(ss * 3))
    shadow = np.asarray(shadow) / 255.0
    glyph = bars(0.0, 0.0)
    col *= (1 - 0.55 * shadow * (1 - glyph))[..., None]
    ivory = np.stack([252 + 0 * x, 244 + 0 * x, 222 + 0 * x], -1) * (0.92 + 0.08 * n)[..., None]
    col = col * (1 - glyph[..., None]) + ivory * glyph[..., None]
    alpha = 255 * (r < 1.0)
    img = Image.fromarray(rgba(col[..., 0], col[..., 1], col[..., 2], alpha)).resize((size, size), Image.LANCZOS)
    return np.asarray(img)


# ============================================================================
# shaders
# ============================================================================

TEXTURES = {
    "tf_mtt_paint": tf_mtt_paint, "tf_aat_paint": tf_aat_paint, "tf_aat_cream": tf_aat_cream,
    "tf_metal_dark": tf_metal_dark, "tf_vent": tf_vent, "tf_glow_red": tf_glow_red,
    "nboo_shield_dome": nboo_shield_dome, "nboo_shield_rim": nboo_shield_rim, "nboo_hand_shield": nboo_hand_shield,
    "nboo_gungan_brass": nboo_gungan_brass, "nboo_gungan_hide": nboo_gungan_hide, "nboo_gungan_glow": nboo_gungan_glow,
    "tf_plasma_bolt": tf_plasma_bolt, "nboo_booma_glow": nboo_booma_glow,
    "titan_info_disk_historical": titan_info_disk_historical,
    "nboo_rally_beam": nboo_rally_beam, "nboo_rally_ring": nboo_rally_ring,
}
SPEC_PAINT = {"specular": (0.55, 0.52, 0.48), "power": 18.0}
SHADERS = {   # name -> (effect, texture, extras)
    "tf_mtt_paint": ("effect/a_specmap.eft", "tf_mtt_paint", SPEC_PAINT),
    "tf_aat_paint": ("effect/a_specmap.eft", "tf_aat_paint", SPEC_PAINT),
    "tf_aat_cream": ("effect/a_specmap.eft", "tf_aat_cream", SPEC_PAINT),
    "tf_metal_dark": ("effect/a_specmap.eft", "tf_metal_dark", {"specular": (0.75, 0.75, 0.8), "power": 30.0}),
    "tf_vent": ("effect/a_specmap.eft", "tf_vent", {"specular": (0.4, 0.4, 0.4), "power": 20.0}),
    "tf_glow_red": ("effect/a_emis_full.eft", "tf_glow_red", {}),
    "nboo_shield_dome": ("effect/a_alpha_emis_full.eft", "nboo_shield_dome", {"alpha_ref": 1}),
    "nboo_shield_rim": ("effect/a_alpha_emis_full.eft", "nboo_shield_rim", {"alpha_ref": 1}),
    "nboo_hand_shield": ("effect/a_alpha_emis_full.eft", "nboo_hand_shield", {"alpha_ref": 1}),
    "nboo_gungan_brass": ("effect/a_specmap.eft", "nboo_gungan_brass", {"specular": (0.7, 0.6, 0.4), "power": 22.0}),
    "nboo_gungan_hide": ("effect/a_simple.eft", "nboo_gungan_hide", {}),
    "nboo_gungan_glow": ("effect/a_emis_full.eft", "nboo_gungan_glow", {}),
    "tf_plasma_bolt": ("effect/a_alpha_emis_full.eft", "tf_plasma_bolt", {"alpha_ref": 1}),
    "nboo_booma_glow": ("effect/a_alpha_emis_full.eft", "nboo_booma_glow", {"alpha_ref": 1}),
    "titan_info_disk_historical": ("effect/a_emis_full.eft", "titan_info_disk_historical", {}),
    "nboo_rally_beam": ("effect/a_alpha_emis_full.eft", "nboo_rally_beam", {"alpha_ref": 1}),
    "nboo_rally_ring": ("effect/a_alpha_emis_full.eft", "nboo_rally_ring", {"alpha_ref": 1}),
}


def write_all(export_root, preview_png=None, only=None):
    root = Path(export_root)
    made, thumbs = {}, []
    for name, fn in TEXTURES.items():
        if only and name not in only:
            continue
        px = np.ascontiguousarray(fn())
        h, w = px.shape[:2]
        iff.write_dds_rgba(root / f"texture/{name}.dds", w, h, px.tobytes())
        thumbs.append((name, Image.fromarray(px, "RGBA")))
    for name, (effect, tex, extra) in SHADERS.items():
        if only and name not in only:
            continue
        iff.write_shader(root / f"shader/{name}.sht", effect, f"texture/{tex}.dds", **extra)
        made[name] = str(root / f"shader/{name}.sht").replace("\\", "/")
    if preview_png and thumbs:
        _preview(thumbs, preview_png)
    return made


def _preview(thumbs, path, cell=256):
    """Contact sheet: colour over a checker (alpha shown), name underneath."""
    cols = 5
    rows = (len(thumbs) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell, rows * (cell + 18)), (24, 24, 28))
    chk = Image.new("RGB", (cell, cell))
    d = ImageDraw.Draw(chk)
    for i in range(0, cell, 16):
        for j in range(0, cell, 16):
            d.rectangle([i, j, i + 15, j + 15], fill=(90, 90, 90) if (i // 16 + j // 16) % 2 else (140, 140, 140))
    dr = ImageDraw.Draw(sheet)
    for k, (name, im) in enumerate(thumbs):
        x, y = (k % cols) * cell, (k // cols) * (cell + 18)
        t = im.resize((cell, cell), Image.LANCZOS)
        bg = chk.copy()
        bg.paste(t, (0, 0), t)
        sheet.paste(bg, (x, y))
        dr.text((x + 4, y + cell + 3), name, fill=(230, 230, 230))
    sheet.save(path)


if __name__ == "__main__":
    print(write_all(sys.argv[1] if len(sys.argv) > 1 else os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"),
                    sys.argv[2] if len(sys.argv) > 2 else None))
