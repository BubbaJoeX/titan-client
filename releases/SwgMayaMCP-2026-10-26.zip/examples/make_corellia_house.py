"""Writes examples/titan_corl_garage_house.json: Corellian two-storey player house from a hand-drawn plan -
vehicle garage + workshop + halls on the entrance storey, a basement residence (entertaining room, master,
guest, kitchen, living) and a double-height stairwell with a stepped stair between them.
Plan scale 0.03 m per sketch pixel, 32 x 10 m. Run: python examples/make_corellia_house.py"""
import json
from pathlib import Path

LOW, TOP = -3.0, 0.8                    # basement / entrance storey floor heights; terrain at y = 0 (the building origin)

STUCCO = {"shader": "shader/ply_corl_stucco_fallback_c2d13.sht"}
FLOOR = {"shader": "shader/ply_corl_floor_a_cs9.sht"}
GARAGE_FLOOR = {"shader": "shader/floor_garage_floor_02.sht"}
TECH = {"shader": "shader/intr_medicalwall_tech_b_cd8.sht"}
ACCENT = {"shader": "shader/ply_corl_accent_c_cs8.sht", "color": [0.45, 0.47, 0.5]}
WINDOW_IN = {"shader": "shader/ply_window_blocks_a_aes14.sht", "color": [0.55, 0.62, 0.7]}
STAIR = {"shader": "shader/corellia_roof_metal_a_cds16.sht", "color": [0.5, 0.52, 0.55]}
DOOR = {"door_style": "door_corl_metal_s01"}


def mats(floor=FLOOR, wall=STUCCO, **extra):
    return {"wall": wall, "floor": floor, "window": WINDOW_IN, **extra}


def light(k=1.0, tint=(0.9, 0.95, 1.0)):
    return {"ambient": 1.0, "ambient_rgb": [0.40, 0.42, 0.46], "rgb": [c * k for c in tint], "intensity": 1.0,
            "constant": 0.0, "quadratic": 0.6,
            "parallel": [{"rgb": [0.42, 0.44, 0.48], "dir": [0.1, -1.0, -0.2]}, {"rgb": [0.20, 0.22, 0.26], "dir": [0.0, 1.0, 0.1]}]}


def wins(side, offsets, width=1.4, height=1.5, sill=1.1):
    return {"list": [{"side": side, "offset": o, "width": width, "height": height, "sill": sill} for o in offsets]}


rooms = [
    # ---- entrance storey (top floor of the sketch) ----------------------------------------------
    {"name": "vehicle_garage", "min": [0, 0], "max": [20, 10], "floor_y": TOP, "height": 5.0,
     "materials": mats(GARAGE_FLOOR, TECH), "windows": wins("-x", [0.0], width=3.2, height=1.4, sill=2.2),
     "light": light(1.2)},
    {"name": "workshop", "min": [20, 0], "max": [28, 4], "floor_y": TOP, "height": 3.6,
     "materials": mats(GARAGE_FLOOR, TECH), "windows": wins("-z", [-2.6, 0.0, 2.6]), "light": light(1.1)},
    {"name": "east_hall", "min": [28, 0], "max": [32, 10], "floor_y": TOP, "height": 3.6,
     "materials": mats(), "windows": wins("+x", [-3.0, 0.0, 3.0]), "light": light(1.0, (1.0, 0.95, 0.88))},
    {"name": "back_hall", "min": [20, 8], "max": [28, 10], "floor_y": TOP, "height": 3.2,
     "materials": mats(), "windows": wins("+z", [-2.0, 2.0], width=1.2), "light": light(0.9)},
    # stair: a stepped slope from the basement living room (low end) up to the east hall (high end)
    {"name": "stair", "min": [21.6, 4], "max": [28, 6.2], "height": 3.4,
     "slope": {"axis": "x", "y_min": LOW, "y_max": TOP, "steps": True, "ceiling_y": TOP + 3.6},
     "materials": mats(stair=STAIR), "light": light(1.1)},
    {"name": "storage", "polygon": [[20, 4], [21.6, 4], [21.6, 6.2], [28, 6.2], [28, 8], [20, 8]],
     "floor_y": TOP, "height": 3.2, "materials": mats(GARAGE_FLOOR, TECH), "light": light(0.8)},
    # ---- basement residence --------------------------------------------------------------------
    {"name": "entertaining", "polygon": [[0, 0], [7.5, 0], [7.5, 2.7], [10, 4.2], [10, 9.2], [7.2, 10], [0, 10]],
     "floor_y": LOW, "height": 3.4, "materials": mats(), "light": light(1.2, (1.0, 0.92, 0.85))},
    {"name": "master", "polygon": [[7.5, 0], [20, 0], [20, 4.2], [10, 4.2], [7.5, 2.7]],
     "floor_y": LOW, "height": 3.4, "materials": mats(), "light": light(1.0, (1.0, 0.9, 0.8))},
    {"name": "corridor", "min": [10, 4.2], "max": [20, 6.9], "floor_y": LOW, "height": 3.0,
     "materials": mats(), "light": light(0.9)},
    {"name": "guest", "polygon": [[10, 6.9], [20, 6.9], [20, 10], [7.2, 10], [10, 9.2]],
     "floor_y": LOW, "height": 3.4, "materials": mats(), "light": light(1.0, (1.0, 0.93, 0.85))},
    {"name": "kitchen", "min": [20, 0], "max": [28, 4], "floor_y": LOW, "height": 3.4,
     "materials": mats(wall=TECH), "light": light(1.2, (0.95, 1.0, 1.0))},
    {"name": "living", "polygon": [[20, 4], [21.6, 4], [21.6, 6.2], [28, 6.2], [28, 0], [32, 0], [32, 10], [20, 10]],
     "floor_y": LOW, "height": 3.4, "materials": mats(), "light": light(1.1, (1.0, 0.94, 0.86))},
]

door = lambda a, b, **kw: {"rooms": [a, b], "width": 1.6, "height": 2.9, **DOOR, **kw}
doors = [
    door("vehicle_garage", "workshop"),
    door("vehicle_garage", "back_hall", width=1.5),
    door("back_hall", "east_hall", width=1.5),
    door("stair", "east_hall", width=1.5),
    door("storage", "back_hall", width=1.4),                    # top of the stair
    door("entertaining", "master"),
    door("entertaining", "corridor"),
    door("entertaining", "guest", width=1.5),
    door("corridor", "living", width=1.5),
    door("stair", "living", width=1.5, edge=3),                # foot of the stair
    door("kitchen", "living", width=1.3, edge=2),               # kitchen south wall (sketch)
    door("kitchen", "living"),
]
entrances = [
    # the whole north face of the garage is a vehicle door (no door model: an open bay)
    {"room": "vehicle_garage", "side": "-z", "width": 16.0, "height": 4.2, "ramp_width": 17.0},
]
spec = {
    "name": "titan_corl_garage_house",
    "ground_y": 0.0,
    "trim": True,
    "collision_meshes": True,
    "shell_color": [0.78, 0.78, 0.76],
    "shell_materials": {"shader": "shader/corellia_marble_c_unlined_fallback_a2d13.sht"},
    "exterior": {
        "porch": {"shader": "shader/corellia_concrete_a_unlined_asb13.sht", "color": [0.62, 0.62, 0.6]},
        "trim": {"shader": "shader/corellia_verticala_trim_ads16.sht", "color": [0.55, 0.56, 0.58]},
        "window": {"shader": "shader/ply_window_blocks_a_aes14.sht", "color": [0.5, 0.58, 0.66]},
        "roof": {"shader": "shader/corellia_roof_metal_a_ads16.sht", "color": [0.45, 0.47, 0.5]},
    },
    "base": {"shader": "shader/corellia_concrete_a_unlined_asb13.sht", "margin": 1.2, "flare": 0.6, "depth": 1.6,
             "ramp_slope": 0.25},
    "trim_materials": ACCENT,
    "rooms": rooms,
    "doors": doors,
    "entrances": entrances,
    "lights": True,
}
out = Path(__file__).with_name("titan_corl_garage_house.json")
out.write_text(json.dumps(spec, indent=1), encoding="utf-8")
print("wrote", out, len(rooms), "rooms")
