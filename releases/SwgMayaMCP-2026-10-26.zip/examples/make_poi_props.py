"""Build the POI props (maya/swg_mcp/props.py): four placeable static props per adventurer planet, themed on
the factions of that planet's points of interest, and make each spawnable:
mesh + .lod with collision boxes and radar footprint + a static object template
object/static/structure/<dir>/shared_<prefix>_poi_<prop>_sNN.iff derived from the stock
corl_imprv_wall_4x16_s01 template. Suffixes skip every stock sNN, so no stock object is shadowed.
Review renders (one per planet) land in %TEMP%/swg_poi_props, with props.json listing every template.

The headless Maya is shared: take D:/titan/.locks/maya first (see the swg-coordination memory note).

Run: python examples/make_poi_props.py [planet ...]
Spawn: /scene objectCreate object/static/structure/<dir>/shared_<name>.iff x z heading"""
import asyncio
import base64
import json
import os
import sys
import tempfile
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import iff  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
CLIENT = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
RENDERS = Path(os.environ.get("POI_PROPS_RENDER_DIR", os.path.join(tempfile.gettempdir(), "swg_poi_props")))
BASE_TEMPLATE = CLIENT / "object/static/structure/corellia/shared_corl_imprv_wall_4x16_s01.iff"
PLANETS = ["tatooine", "corellia", "naboo", "lok", "endor", "yavin4", "rori", "dathomir", "dantooine", "talus"]

RELOAD = ("import importlib, swg_mcp.pob_builder as pb, swg_mcp.kit as kit, swg_mcp.props as props\n"
          "for m in (pb, kit, props):\n    importlib.reload(m)\n")


def text(res):
    return "\n".join(getattr(c, "text", "") for c in res.content)


async def call(s, code, args):
    res = await s.call_tool("maya_python", {"code": "args = " + json.dumps(args) + "\n" + RELOAD + code,
                                            "timeout_seconds": 600})
    data = json.loads(text(res))
    if not data.get("ok"):
        raise RuntimeError(f"{args}: {data.get('error')} {(data.get('traceback') or '')[-1500:]}")
    return data["result"]


def free_suffix(folder, prefix, prop):
    """First sNN with neither a stock template nor a stock appearance of that name."""
    for n in range(1, 100):
        name = f"{prefix}_poi_{prop}_s{n:02d}"
        if not (CLIENT / f"object/static/structure/{folder}/shared_{name}.iff").exists() and \
                not (CLIENT / f"appearance/thm_{name}.apt").exists():
            return n
    raise RuntimeError(f"no free suffix for {prefix} {prop}")


def finish_prop(out):
    """Host side after props.build: the .lod (collision boxes, radar footprint) and the static template."""
    b = out["bounds"]
    lod = iff.write_static_lod(EXPORT, out["apt"], out["boxes"], out["composite"], out["footprint"],
                               bounds=[b[:3], b[3:]])
    rel = f"object/static/structure/{out['dir']}/shared_{out['name']}.iff"
    iff.derive_template(BASE_TEMPLATE, EXPORT / rel, {"appearanceFilename": out["apt"]})
    return {"planet": out["planet"], "prop": out["prop"], "name": out["name"], "template": rel,
            "collision": lod["collision"], "boxes": lod["boxes"], "shaders": out["shaders"],
            "size": [round(b[3] - b[0], 2), round(b[4] - b[1], 2), round(b[5] - b[2], 2)]}


async def main(planets):
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    RENDERS.mkdir(parents=True, exist_ok=True)
    listing = RENDERS / "props.json"
    made = {m["name"]: m for m in json.loads(listing.read_text())} if listing.exists() else {}
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            names = await call(s, "result = {k: [list(props.PLANETS[k]), list(v)] for k, v in props.PROPS.items()}", {})
            for planet in planets:
                (folder, prefix), prop_names = names[planet]
                for prop in prop_names:
                    args = {"planet": planet, "prop": prop, "export_root": str(EXPORT).replace("\\", "/"),
                            "suffix": free_suffix(folder, prefix, prop)}
                    out = await call(s, "result = props.build(args['planet'], args['prop'], args['export_root'], "
                                        "args['suffix'])", args)
                    m = finish_prop(out)
                    made[m["name"]] = m
                    print(f"{m['name']:36s} {m['collision']:9s} boxes {m['boxes']:2d} size {m['size']}")
                await call(s, "result = props.preview(args['planet'])", {"planet": planet})
                img = await s.call_tool("maya_render", {"width": 1400, "height": 500, "azimuth": 25, "elevation": 15})
                for c in img.content:
                    if getattr(c, "data", None):
                        (RENDERS / f"poi_{planet}.png").write_bytes(base64.b64decode(c.data))
            await s.call_tool("maya_scene", {"action": "new"})
    listing.write_text(json.dumps(sorted(made.values(), key=lambda m: (m["planet"], m["prop"])), indent=1))
    print(f"{len(made)} props; renders + props.json in {RENDERS}")


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1:] or PLANETS))
