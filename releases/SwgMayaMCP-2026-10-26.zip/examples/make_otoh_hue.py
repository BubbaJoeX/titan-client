"""Player-hueable furniture variants of the Otoh Gunga pieces and a few Naboo kit decor pieces, the stock way:

  hue textures  texture/<name>_hue.dds: the original colours divided by the default palette colour (so the default
                index reproduces the original look), alpha = hue mask
  hue shaders   FORM CSHD (iff.write_custom_shader) like the stock furniture hue shaders:
                  nboo_otoh_rib_hue_hc8              h_color2         MAIN <- /private/index_color_1 (bronze ribs)
                  nboo_otoh_glow_core_hue_hcse25     h_color2w_specmap_emismap (opaque, emissive mask = 1)
                  nboo_otoh_glow_blue_hue_hcse25       "                     MAIN <- /private/index_color_2
                  nboo_otoh_glow_shell_hue_haefbs28  h_alpha_emis_full_bloom_soft (alpha glow, MAIN = colour)
                  thed_patinaroof_trim_hue_hcb13     h_color2_bump    MAIN <- /private/index_color_1 (kit trim)
  meshes        appearance/mesh/frn_<piece>.msh = the export's mesh with its SPS shader names swapped to the hue
                shaders; appearance/lod/frn_<piece>.lod (collision, hardpoints, radar kept) + appearance/frn_<piece>.apt
  templates     object/tangible/furniture/titan/shared_frn_<piece>.iff derived from the stock furniture template
                shared_frn_all_couch_lg_s1 with paletteColorCustomizationVariables declaring the variables (same
                palette + default as the shaders) - SharedTangibleObjectTemplate gives the object those
                customization variables, the CSHD shaders read them, /setHue changes them.

All palettes are palette/wr_cloth_general.pal (a 256-colour stock palette also used by furniture hue shaders); each
default index is picked so the hue texture comes out near neutral grey and the default reproduces the original
(rib 219 bronze, trim 150 patina green, glow 217 gold). Two glow textures can't be neutralised by any entry and
use a luminance-only hue texture instead: the shell (it shares index_color_2 with the gold cores, so by default it
is gold rather than deep amber) and the blue sphere (default 244 blue; its yellow dots / bright band turn blue).
The glass skin (nboo_otoh_glass_skin) stays as it is.

Offline test (debug client, no server scripts): /scene objectCreate <template> <x> <z> <heading>, /scene objectList,
/customization listVariables <id>, /customization setInt /private/index_color_1 <index> <id>.
On the server, GM: /setHue -target 1 <palette index | #RRGGBB | colour name> (variable 2 for the glow).

Run: python examples/make_otoh_hue.py           then: python examples/make_templates.py object/tangible/furniture/titan
Spawn (GM): /scene objectCreate object/tangible/furniture/titan/shared_frn_nboo_otoh_pod_sm.iff <x> <z> <heading>"""
from __future__ import annotations

import os
import struct
import sys
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import iff  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
CLIENT = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
SHARED = Path(os.environ.get("TITAN_SHARED_ROOT", "D:/titan/data/sku.0/sys.shared/compiled/game"))
FURNITURE_BASE = SHARED / "object/tangible/furniture/all/shared_frn_all_couch_lg_s1.iff"
PALETTE = "palette/wr_cloth_general.pal"
LKUP = ("LKUP", "texture\\specular_lookup_35.dds", b"\0\2\2\0\2\2\2")     # as in stock *_hcse25 shaders

# piece -> (source apt, objectName / detailedDescription (frn_n / frn_d names) or None to inherit, variables)
OTOH = {
    "nboo_otoh_pod_sm": ("thm_nboo_otoh_pod_sm_s01", "frn_lamp_free", "frn_lamp_free"),
    "nboo_otoh_pod_md": ("thm_nboo_otoh_pod_md_s01", "frn_lamp_free", "frn_lamp_free"),
    "nboo_otoh_pod_hanging": ("thm_nboo_otoh_pod_hanging_s01", "frn_lamp_free", "frn_lamp_free"),
    "nboo_otoh_stalk": ("thm_nboo_otoh_stalk_s01", "streetlamp", "streetlamp"),
    "nboo_otoh_sphere_blue": ("thm_nboo_otoh_sphere_blue_s01", "bubble_tank", "bubble_tank"),
}
KIT = {
    "nboo_imprv_planter_box": ("thm_nboo_imprv_planter_box_s01", "frn_potted_plant", None),
    "nboo_imprv_brazier": ("thm_nboo_imprv_brazier_s01", "brazier", None),
    "nboo_imprv_column_cap": ("thm_nboo_imprv_column_cap_s01", None, None),
}


def palette_colours(rel):
    b = (CLIENT / rel).read_bytes()
    n = struct.unpack_from("<H", b, 22)[0]
    return [tuple(b[24 + 4 * i:27 + 4 * i]) for i in range(n)]


def best_default(rgba, colours, step=4):
    """Default palette index for a hue texture derived from `rgba`: the hue texture (original / palette colour)
    should come out neutral grey of mid brightness like the stock *_hue.dds (so other palette entries tint it
    cleanly) without clipping (so the default index reproduces the original): entries clipping more than 5% of
    the pixels (beyond the least clipping entry) are out, then least residual colour, then grey level nearest 128."""
    px = [tuple(rgba[i:i + 3]) for i in range(0, len(rgba), 4 * step)]
    stats = []
    for idx, p in enumerate(colours):
        if min(p) == 0:
            continue
        clip, tot = 0, [0.0, 0.0, 0.0]
        for c in px:
            g = [c[ch] * 255 / p[ch] for ch in range(3)]
            clip += max(g) > 255.5
            for ch in range(3):
                tot[ch] += min(255.0, g[ch])
        mean = [t / len(px) for t in tot]
        top = max(mean) or 1.0
        residual = sum((m / top - 1.0) ** 2 for m in mean) ** 0.5
        stats.append((clip / len(px), residual + 0.25 * abs(top - 128) / 255, idx))
    limit = min(s[0] for s in stats) + 0.05          # textures already at full white clip under any colour
    return min((s for s in stats if s[0] <= limit), key=lambda s: s[1])[2]


def _lum(c):
    return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]


def nearest_hue(rgba, colours, min_bright=150):
    """Palette index nearest in hue (normalised colour) to the texture's mean colour, among bright entries."""
    n = len(rgba) // 4
    mean = [sum(rgba[ch::4]) / n for ch in range(3)]
    unit = [m / (max(mean) or 1) for m in mean]
    return min((i for i, p in enumerate(colours) if max(p) >= min_bright),
               key=lambda i: sum((a / max(colours[i]) - b) ** 2 for a, b in zip(colours[i], unit)))


def hue_texture(rgba, p, alpha, grey=False):
    """Original colour / palette colour (grey where they match), alpha = alpha(original alpha). grey: luminance
    only (for textures no palette entry neutralises: the default index then gives the original's brightness in
    the palette colour)."""
    out = bytearray(len(rgba))
    lp = _lum(p)
    for i in range(0, len(rgba), 4):
        if grey:
            out[i:i + 3] = bytes([min(255, round(_lum(rgba[i:i + 3]) * 255 / lp))] * 3)
        else:
            for ch in range(3):
                out[i + ch] = min(255, round(rgba[i + ch] * 255 / p[ch]))
        out[i + 3] = alpha(rgba[i + 3])
    return out


def stock_ssht(name):
    """The SSHT block of a stock / exported .sht."""
    for root in (EXPORT, CLIENT):
        f = root / name
        if f.is_file():
            return iff.parse_iff(f.read_bytes()).children[0]
    raise FileNotFoundError(name)


def matl(ssht):
    return ssht.forms()[0].forms("MATS")[0].forms()[0].first("MATL").data


def materials():
    """Hue textures + CSHD shaders; returns {original shader: (hue shader, variable)} and the defaults."""
    colours = palette_colours(PALETTE)
    made, defaults = {}, {}

    def tex(name, src_rel, alpha, p=None, grey=False):
        w, h, rgba = iff.read_dds_rgba((EXPORT if (EXPORT / src_rel).is_file() else CLIENT) / src_rel)
        idx = p if p is not None else nearest_hue(rgba, colours) if grey else best_default(rgba, colours)
        iff.write_dds_rgba(EXPORT / f"texture/{name}.dds", w, h, hue_texture(rgba, colours[idx], alpha, grey))
        return idx

    # bronze ribs: h_color2, alpha 0 = all MAIN (index_color_1); HUEB stays white
    rib = tex("nboo_otoh_rib_hue", "texture/nboo_otoh_rib.dds", lambda a: 0)
    spec = struct.unpack_from("<17f", matl(stock_ssht("shader/nboo_otoh_rib.sht")))
    iff.write_custom_shader(EXPORT / "shader/nboo_otoh_rib_hue_hc8.sht",
                            dict(effect="effect/h_color2.eft", texture="texture/nboo_otoh_rib_hue.dds",
                                 specular=spec[13:16], power=spec[16], alpha_ref=1),
                            pals=[("index_color_1", "MAIN", PALETTE, rib)], tfactors={"HUEB": 0xFFFFFFFF})
    made["shader/nboo_otoh_rib.sht"] = ("shader/nboo_otoh_rib_hue_hc8.sht", "/private/index_color_1")
    defaults["rib"] = rib

    # glows: index_color_2. Opaque cores: h_color2w_specmap_emismap (stock jedi throne layout), every sampler on
    # the one hue texture with alpha 255 = tinted, fully emissive; HUEB / SPEC have no effect (white, black spec).
    def emis_glow(src, grey=False):
        name = f"nboo_otoh_{src}_hue"
        idx = tex(name, f"texture/nboo_otoh_{src}.dds", lambda a: 255, grey=grey)
        t = f"texture/{name}.dds"
        iff.write_custom_shader(EXPORT / f"shader/{name}_hcse25.sht",
                                dict(effect="effect/h_color2w_specmap_emismap.eft", power=2.0,
                                     textures=[("EMIS", t), ("HUEB", t), LKUP, ("MAIN", t), ("SPEC", t)],
                                     alpha_ref=[("SPEC", 1)]),
                                pals=[("index_color_2", "MAIN", PALETTE, idx)],
                                tfactors={"BLCK": 0xFF000000, "HUEB": 0xFFFFFFFF})
        made[f"shader/nboo_otoh_{src}.sht"] = (f"shader/{name}_hcse25.sht", "/private/index_color_2")
        return idx
    defaults["glow"] = emis_glow("glow_core")
    defaults["glow_blue"] = emis_glow("glow_blue", grey=True)    # deep blue + yellow dots: no neutralising entry
    # alpha glow layer: h_alpha_emis_full_bloom_soft (stock hologram glow layout): colour = texture x MAIN, alpha =
    # texture alpha x view falloff (SOFT as the stock ewok cigar: soft edges only near the silhouette)
    name = "nboo_otoh_glow_shell_hue"
    # (luminance only: the shell shares index_color_2 with the gold cores, so by default it turns gold too)
    tex(name, "texture/nboo_otoh_glow_shell.dds", lambda a: a, defaults["glow"], grey=True)
    iff.write_custom_shader(EXPORT / f"shader/{name}_haefbs28.sht",
                            dict(effect="effect/h_alpha_emis_full_bloom_soft.eft", texture=f"texture/{name}.dds"),
                            pals=[("index_color_2", "MAIN", PALETTE, defaults["glow"])],
                            tfactors={"BLUM": 0xFF7F7F7F, "SOFT": 0xFFD6D6D6})
    made["shader/nboo_otoh_glow_shell.sht"] = (f"shader/{name}_haefbs28.sht", "/private/index_color_2")

    # kit trim: the stock bump shader turned h_color2_bump (stock bageraset_hue_body_hcb13 layout), normal map kept
    trim = tex("thed_patinaroof_trim_hue", "texture/thed_patinaroof_trim.dds", lambda a: 0)
    stock = stock_ssht("shader/thed_patinaroof_trim_asb13.sht")
    m = struct.unpack_from("<17f", matl(stock))
    iff.write_custom_shader(EXPORT / "shader/thed_patinaroof_trim_hue_hcb13.sht",
                            dict(effect="effect/h_color2_bump.eft", emissive=m[9:12], specular=m[13:16], power=m[16],
                                 textures=[("MAIN", "texture/thed_patinaroof_trim_hue.dds"),
                                           ("NRML", "texture/thed_patinaroof_trim_n.dds")],
                                 tcss=[("DOT3", 1), ("MAIN", 0), ("NRML", 0)], alpha_ref=1),
                            pals=[("index_color_1", "MAIN", PALETTE, trim)], tfactors={"HUEB": 0xFFFFFFFF})
    made["shader/thed_patinaroof_trim_asb13.sht"] = ("shader/thed_patinaroof_trim_hue_hcb13.sht",
                                                     "/private/index_color_1")
    defaults["trim"] = trim
    return made, defaults


def chld_meshes(lod):
    """Mesh paths a .lod's DATA/CHLD entries name (relative to appearance/)."""
    out = []

    def walk(b):
        for c in b.children:
            if c.is_form:
                walk(c)
            elif c.tag == "CHLD":
                out.append(c.data[4:].split(b"\0")[0].decode("latin1"))
    walk(iff.parse_iff(lod.read_bytes()))
    return out


def piece(name, src, obj_name, desc, made, defaults):
    """frn_<name>: mesh copies with hue shaders, .lod/.apt, shared furniture template."""
    apt_src = EXPORT / f"appearance/{src}.apt"
    lod_rel = iff.parse_iff(apt_src.read_bytes()).children[0].forms()[0].first("NAME").data.split(b"\0")[0].decode()
    meshes = chld_meshes(EXPORT / lod_rel)
    mesh_map, variables = {}, {}
    for i, m in enumerate(meshes):
        new = f"mesh/frn_{name}{'' if len(meshes) == 1 else f'_l{i}'}.msh"
        shaders = iff.read_msh_summary(EXPORT / "appearance" / m)["shaders"]
        swap = {s: made[s][0] for s in set(shaders) if s in made}
        if not swap:
            raise ValueError(f"{m}: no hueable shader in {shaders}")
        iff.replace_strings(EXPORT / "appearance" / m, EXPORT / "appearance" / new, swap)
        variables.update({made[s][1]: s for s in swap})
        mesh_map[m] = new
    lod_new = f"appearance/lod/frn_{name}.lod"
    iff.replace_strings(EXPORT / lod_rel, EXPORT / lod_new, mesh_map)
    apt_new = f"appearance/frn_{name}.apt"
    iff.replace_strings(apt_src, EXPORT / apt_new, {lod_rel: lod_new})

    pals = []
    for var in sorted(variables):
        sh = iff.read_custom_shader(EXPORT / made[variables[var]][0])
        p = next(p for p in sh["pals"] if "/private/" + p["var"] == var)
        default = p["default"]
        if var == "/private/index_color_2" and "shader/nboo_otoh_glow_blue.sht" in variables.values():
            default = defaults["glow_blue"]
        pals.append((var, p["palette"], default))
    strings = {"appearanceFilename": apt_new}
    cdf = f"clientdata/client_shared_{src[len('thm_'):]}.cdf"
    if (EXPORT / cdf).is_file():
        strings["clientDataFile"] = cdf
    ids = {"objectName": ("frn_n", obj_name) if obj_name else None,
           "detailedDescription": ("frn_d", desc) if desc else None}
    tpl = EXPORT / f"object/tangible/furniture/titan/shared_frn_{name}.iff"
    iff.derive_template(FURNITURE_BASE, tpl, strings, string_ids=ids, palette_vars=pals)
    return {"template": tpl.relative_to(EXPORT).as_posix(), "apt": apt_new, "lod": lod_new,
            "meshes": list(mesh_map.values()), "palette_vars": pals, "cdf": strings.get("clientDataFile")}


def main():
    sys.stdout.reconfigure(line_buffering=True)
    made, defaults = materials()
    colours = palette_colours(PALETTE)
    print("defaults (" + PALETTE + "):", {k: (v, colours[v]) for k, v in defaults.items()})
    for name, (src, obj, desc) in {**OTOH, **KIT}.items():
        r = piece(name, src, obj, desc, made, defaults)
        print(f"{r['template']}: {r['apt']} -> {r['meshes']}; vars {r['palette_vars']}; cdf {r['cdf']}")


if __name__ == "__main__":
    main()
