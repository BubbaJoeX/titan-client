"""Give every stock city filler building an interior (MCP tool pob_interior_for_stock -> maya/swg_mcp/filler.py)
and export it as a POB that overrides the stock template: the stock exterior mesh stays the r0 shell (entrance cut through it), rooms by
category, then .pob/.msh/.flr, the exterior .lod (overhead-map radar outline + the stock far LODs), a
structure footprint and object/building/<planet>/shared_<stock name>.iff pointing at the POB.

Run: python examples/make_fillers.py [filter-substring ...]
Env: FILLER_RENDER_DIR (review renders, default <scratch>/fillers), TITAN_EXPORT_ROOT, TITAN_DATA_ROOT."""
import asyncio
import base64
import json
import os
import sys
import tempfile
import time
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import iff  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
CLIENT = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
SHARED = CLIENT.parent.parent.parent / "sys.shared" / "compiled" / "game"
RENDERS = Path(os.environ.get("FILLER_RENDER_DIR", os.path.join(tempfile.gettempdir(), "swg_fillers")))
SPECS = Path(__file__).parent / "fillers"
THEME = {"tatooine": "tato", "corellia": "corl", "naboo": "nboo"}

async def main(filters):
    templates = sorted(t for t in SHARED.glob("object/building/*/shared_*filler*.iff") if t.parent.name in THEME)
    if filters:
        templates = [t for t in templates if any(f in t.name for f in filters)]
    # stock meshes that only exist inside the packed archives can't be imported (e.g. naboo style 11)
    templates = [t for t in templates if (CLIENT / (iff.template_strings(t).get("appearanceFilename") or "x")).exists()]
    RENDERS.mkdir(parents=True, exist_ok=True)
    SPECS.mkdir(exist_ok=True)
    report = []
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            for i, t in enumerate(templates):
                t0 = time.time()
                apt = iff.template_strings(t).get("appearanceFilename")
                name = "titan_" + Path(apt).stem
                entry = {"template": t.name, "name": name}
                try:
                    res = await s.call_tool("pob_interior_for_stock", {
                        "template": str(t.relative_to(SHARED)).replace("\\", "/"), "seed": i + 1,
                        "export_root": str(EXPORT).replace("\\", "/")})
                    text = "\n".join(getattr(c, "text", "") for c in res.content)
                    if res.is_error:
                        raise RuntimeError(text[-2500:])
                    out = json.loads(text)
                    entry["info"] = out["info"]
                    entry["cells"] = out["build"]["cells"]
                    entry["lod"] = out["exterior_lod"]
                    entry["rails"] = out["rails"]
                    (SPECS / f"{name}.json").write_text(json.dumps(out["spec"], indent=1), encoding="utf-8")
                    ent = out["spec"]["entrances"][0]
                    room = next(rm for rm in out["spec"]["rooms"] if rm["name"] == ent["room"])
                    fy = room["floor_y"]
                    n = {"+x": (1, 0), "-x": (-1, 0), "+z": (0, 1), "-z": (0, -1)}[ent["side"]]
                    ax, az = ent["at"]
                    inside = [ax - n[0] * 5.5, fy + 1.7, az - n[1] * 5.5]       # in the entry room, facing the door
                    outside = [ax + n[0] * (ent["reveal"] + 7), 1.7, az + n[1] * (ent["reveal"] + 7)]
                    views = (("cutaway", {"cut_height": out["info"]["floor_y"] + 2.4}),
                             ("perspective", {"azimuth": {"+z": 20, "-z": 200, "+x": 110, "-x": 290}[ent["side"]],
                                              "elevation": 12}),
                             ("eye", {"eye": inside, "look_at": [ax, fy + 1.3, az], "fov": 80}),
                             ("door", {"eye": outside, "look_at": [ax, fy + 1.5, az], "fov": 60}))
                    for view, kw in views:
                        hide = view == "cutaway"     # plan view: rooms only (the stock shell would cover them)
                        await s.call_tool("maya_python", {"code": f"cmds.setAttr('|{name}|r0|mesh.visibility', {0 if hide else 1})\nresult = 1"})
                        img = await s.call_tool("maya_render", {"view": "eye" if view == "door" else view,
                                                                "width": 800, "height": 600, **kw})
                        for c in img.content:
                            if getattr(c, "data", None):
                                (RENDERS / f"{name}_{view}.png").write_bytes(base64.b64decode(c.data))
                    entry["ok"] = entry["rails"]["ok"]
                except Exception as exc:     # keep going; the report lists failures
                    entry["ok"] = False
                    entry["error"] = str(exc)[-2500:]
                entry["seconds"] = round(time.time() - t0, 1)
                print(json.dumps({k: entry.get(k) for k in ("name", "ok", "cells", "info", "error", "seconds")}), flush=True)
                report.append(entry)
    out_path = RENDERS / "report.json"
    prev = json.loads(out_path.read_text()) if out_path.exists() and filters else []
    keep = {e["name"]: e for e in prev}
    keep.update({e["name"]: e for e in report})
    out_path.write_text(json.dumps(list(keep.values()), indent=1), encoding="utf-8")
    print(f"{sum(e['ok'] for e in report)}/{len(report)} ok; report {out_path}")


asyncio.run(main(sys.argv[1:]))
