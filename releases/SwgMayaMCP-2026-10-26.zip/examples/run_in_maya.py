"""Run a Python file inside the SwgMayaMCP headless Maya (plug-in loaded) and print its `result`.
Run: python examples/run_in_maya.py script.py"""
import asyncio
import json
import os
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main(path):
    code = open(path, encoding="utf-8").read()
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            res = await s.call_tool("maya_python", {"code": code})
            text = "\n".join(getattr(c, "text", "") for c in res.content)
            if os.environ.get("MAYA_RAW"):
                print(text)
                return
            try:
                data = json.loads(text)
            except ValueError:
                print(text)
                return
            flt = os.environ.get("MAYA_LOG_FILTER")
            if flt:
                print("\n".join(dict.fromkeys(l for l in str(data.get("stderr", "")).splitlines() if flt in l)))
            if data.get("ok", True) and "result" in data:
                print(json.dumps(data["result"], indent=1))
            else:
                print(text[-4000:])


asyncio.run(main(sys.argv[1]))
