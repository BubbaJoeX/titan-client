"""Materials of the themed furniture sets (examples/make_furniture_sets.py): generated textures (numpy, tileable)
and the .sht shaders that use them, written into the export tree as texture/frn_titan_<key>.dds and
shader/frn_titan_<key>.sht. maya/swg_mcp/furniture.py assigns them by key (swgShaderPath = the absolute .sht path).

Effects (all lit by cell/sun lights, so no color0 bake is needed - furniture is placed into any room):
  a_simple             matte surfaces (stone, fabric, canvas, wood)
  a_specmap            gloss where the texture alpha says so (brass, painted metal, Imperial black, chrome, velvet)
  a_envmask_specmap    supported, but not used: env_all_metl tiles into a mirror-ball checker on furniture
  a_emis_full          self-lit coals, screens, light strips
  a_alpha / a_alpha_emis_full   glass, water and holograms

Each MATS entry: key -> (effect, texture builder, specular grey, power). Builders return an (h, w, 4) uint8 RGBA
array, top row first. Re-run: python examples/frn_materials.py [export_root] [preview.png]"""
from __future__ import annotations

import math
import os
import struct
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import iff  # noqa: E402

N = 512
PREFIX = "frn_titan_"


# ---------------------------------------------------------------------------------------------------------------
# tileable noise and helpers (all arrays float32 in 0..1, shape (N, N))
# ---------------------------------------------------------------------------------------------------------------

def _rng(seed):
    return np.random.default_rng(seed)


def _upsample(grid, n=N):
    """Smooth tileable upsampling of a small random grid (bicubic-ish via smoothstep, wraps)."""
    g = grid.shape[0]
    t = np.arange(n) * g / n
    i0 = np.floor(t).astype(int) % g
    i1 = (i0 + 1) % g
    f = t - np.floor(t)
    f = f * f * (3 - 2 * f)
    rows = grid[i0][:, :] * (1 - f)[:, None] + grid[i1] * f[:, None]
    return rows[:, i0] * (1 - f)[None, :] + rows[:, i1] * f[None, :]


def fbm(seed, base=4, octaves=5, n=N, gain=0.5):
    r = _rng(seed)
    out, amp, tot = np.zeros((n, n), np.float32), 1.0, 0.0
    for o in range(octaves):
        g = base << o
        if g > n:
            break
        out += _upsample(r.random((g, g)).astype(np.float32), n) * amp
        tot += amp
        amp *= gain
    return out / tot


def coords(n=N):
    y, x = np.mgrid[0:n, 0:n].astype(np.float32) / n
    return x, y


def mix(a, b, t):
    t = np.clip(t, 0, 1)[..., None] if np.ndim(t) == 2 else t
    return a * (1 - t) + b * t


def col(rgb, shape=(N, N)):
    return np.broadcast_to(np.array(rgb, np.float32) / 255.0, shape + (3,)).copy()


def rgba(rgb, alpha=None):
    a = np.ones(rgb.shape[:2], np.float32) if alpha is None else np.broadcast_to(np.asarray(alpha, np.float32), rgb.shape[:2])
    out = np.concatenate([np.clip(rgb, 0, 1), np.clip(a, 0, 1)[..., None]], axis=2)
    return (out * 255 + 0.5).astype(np.uint8)


def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


def grooves(x, period, width):
    """1 in a groove line every `period` (0..1 units), soft edged."""
    d = np.abs(((x / period) % 1.0) - 0.5) * period
    return 1 - smooth(width * 0.5, width, period * 0.5 - d)


def lines(x, period, width):
    d = np.minimum((x % period), period - (x % period))
    return 1 - smooth(width * 0.5, width, d)


def bevel_panels(x, y, nx, ny, w=0.006):
    """Panel seams: darkening lines on a nx * ny grid plus a lit upper-left bevel."""
    sx, sy = (x * nx) % 1.0, (y * ny) % 1.0
    seam = np.maximum(1 - smooth(0, w * nx, sx), 1 - smooth(0, w * ny, sy))
    seam = np.maximum(seam, 1 - smooth(0, w * nx, 1 - sx))
    seam = np.maximum(seam, 1 - smooth(0, w * ny, 1 - sy))
    light = (1 - smooth(w * nx, 3 * w * nx, sx)) * 0.5 + (1 - smooth(w * ny, 3 * w * ny, sy)) * 0.5
    return seam, light


def disc_mask(x, y, cx, cy, r, soft=0.004):
    d = np.sqrt(((x - cx + 0.5) % 1.0 - 0.5) ** 2 + ((y - cy + 0.5) % 1.0 - 0.5) ** 2)
    return 1 - smooth(r - soft, r + soft, d)


# ---------------------------------------------------------------------------------------------------------------
# Hutt palace
# ---------------------------------------------------------------------------------------------------------------

def hutt_sandstone():
    x, y = coords()
    n = fbm(11, 4, 6)
    strata = 0.5 + 0.5 * np.sin((y + 0.05 * fbm(12, 2, 3)) * 2 * math.pi * 6)
    c = mix(col((182, 146, 102)), col((214, 182, 136)), n * 0.8 + strata * 0.2)
    pits = (fbm(13, 64, 2) > 0.72).astype(np.float32) * 0.18
    c = c * (1 - pits[..., None])
    return rgba(c)


def hutt_frieze():
    """Carved band: running Huttese meander between two rolled mouldings; tiles along u."""
    x, y = coords()
    base = hutt_sandstone()[..., :3].astype(np.float32) / 255
    mould = np.exp(-((y - 0.12) / 0.04) ** 2) + np.exp(-((y - 0.88) / 0.04) ** 2)
    grooves_ = lines(y, 1.0, 0.01) * 0 + (np.abs(y - 0.2) < 0.012) + (np.abs(y - 0.8) < 0.012)
    # meander: a square-wave key pattern, 4 repeats across
    u = (x * 4) % 1.0
    v = (y - 0.25) / 0.5
    inband = (v > 0) & (v < 1)
    key = ((np.abs(u - 0.5) < 0.38) & (np.abs(v - 0.5) < 0.38)) & ~((np.abs(u - 0.5) < 0.24) & (np.abs(v - 0.5) < 0.24))
    key |= (np.abs(u - 0.5) < 0.07) & (v > 0.38) & (v < 0.62)
    key |= (u < 0.12) & (np.abs(v - 0.12) < 0.07)
    key = key & inband
    shade = 1 + 0.25 * mould - 0.35 * key - 0.4 * grooves_
    return rgba(base * shade[..., None])


def hutt_velvet():
    """Deep red velvet, diamond buttoned (gold buttons), soft sheen in alpha."""
    x, y = coords()
    n = fbm(21, 8, 5)
    u, v = (x + y) * 4 % 1.0, (x - y) * 4 % 1.0
    tuft = np.minimum(np.minimum(u, 1 - u), np.minimum(v, 1 - v))      # 0 at crease lines
    puff = smooth(0.0, 0.25, tuft)
    c = col((120, 14, 22)) * (0.55 + 0.45 * puff)[..., None] + col((40, 0, 4)) * (1 - puff)[..., None] * 0.3
    c *= (0.9 + 0.2 * n)[..., None]
    btn = np.zeros_like(x)
    for bx in np.arange(0, 1.0001, 0.125):
        for by in np.arange(0, 1.0001, 0.125):
            if int(round((bx + by) / 0.125)) % 2 == 0:
                btn = np.maximum(btn, disc_mask(x, y, bx, by, 0.012))
    c = mix(c, col((230, 180, 70)), btn)
    return rgba(c, 0.25 + 0.35 * puff + 0.4 * btn)


def hutt_silk():
    """Gold-and-plum woven silk for bolsters and pillows (stripes + brocade dots)."""
    x, y = coords()
    stripe = 0.5 + 0.5 * np.sin(x * 2 * math.pi * 6)
    c = mix(col((92, 22, 70)), col((168, 64, 40)), smooth(0.4, 0.6, stripe))
    gold = (np.abs(((x * 12) % 1.0) - 0.5) < 0.06) | disc_mask(x * 6 % 1.0, y * 6 % 1.0, 0.5, 0.5, 0.12, 0.03).astype(bool)
    c = mix(c, col((222, 176, 80)), gold.astype(np.float32))
    c *= (0.9 + 0.15 * fbm(22, 64, 2))[..., None]
    return rgba(c, 0.2 + 0.6 * gold)


def hutt_brass():
    x, y = coords()
    n = fbm(31, 4, 5)
    c = mix(col((150, 104, 38)), col((236, 192, 102)), 0.35 + 0.5 * n)
    eng = (np.abs(((y * 8) % 1.0) - 0.5) < 0.02).astype(np.float32)        # engraved rings
    c *= (1 - 0.35 * eng)[..., None]
    return rgba(c, 0.85 - 0.5 * eng)


def hutt_wood():
    """Dark lacquered palace wood with carved grooves (grain along v)."""
    x, y = coords()
    grain = np.sin((x * 24 + 3 * fbm(41, 2, 4)) * math.pi) * 0.5 + 0.5
    c = mix(col((52, 26, 14)), col((96, 52, 26)), grain * 0.6 + fbm(42, 8, 4) * 0.4)
    carve = grooves(y, 0.25, 0.02)
    c *= (1 - 0.4 * carve)[..., None]
    return rgba(c, 0.45 - 0.3 * carve)


def hutt_flesh():
    """Sarlacc maw flesh: wet pinkish-brown with dark veins and pale ridges."""
    x, y = coords()
    n = fbm(51, 4, 6)
    v1 = np.abs(fbm(52, 6, 5) - 0.5)
    vein = 1 - smooth(0.0, 0.03, v1)
    ridge = 0.5 + 0.5 * np.sin((y * 10 + n * 2) * 2 * math.pi)
    c = mix(col((148, 82, 74)), col((196, 128, 112)), n * 0.7 + ridge * 0.3)
    c = mix(c, col((70, 20, 30)), vein * 0.8)
    return rgba(c, 0.55 + 0.4 * ridge)


def hutt_bone():
    x, y = coords()
    n = fbm(61, 4, 5)
    c = mix(col((198, 184, 150)), col((240, 232, 206)), n)
    c = mix(c, col((120, 100, 70)), smooth(0.55, 0.9, y) * 0.35)        # stained toward the root (v = 1)
    return rgba(c, 0.5)


def hutt_coals():
    x, y = coords()
    n = fbm(71, 8, 5)
    hot = smooth(0.45, 0.75, n)
    c = mix(col((40, 8, 2)), col((255, 120, 20)), hot)
    c = mix(c, col((255, 230, 140)), smooth(0.7, 0.85, n))
    return rgba(c)


def hutt_gorg_water():
    x, y = coords()
    n = fbm(81, 4, 5)
    c = mix(col((40, 110, 50)), col((120, 190, 80)), n)
    bub = np.zeros_like(x)
    r = _rng(82)
    for _ in range(40):
        bub = np.maximum(bub, disc_mask(x, y, r.random(), r.random(), 0.004 + 0.01 * r.random(), 0.003))
    c = mix(c, col((220, 255, 200)), bub)
    return rgba(c, 0.55 + 0.2 * n + 0.3 * bub)


def hutt_rug():
    """Round palace rug: concentric red/gold/indigo bands with a starburst (fit UVs, centre 0.5, 0.5)."""
    x, y = coords()
    dx, dy = x - 0.5, y - 0.5
    r = np.sqrt(dx * dx + dy * dy) * 2
    a = np.arctan2(dy, dx)
    bands = [(0.0, (150, 30, 30)), (0.18, (220, 170, 70)), (0.24, (40, 30, 90)), (0.55, (150, 30, 30)),
             (0.8, (220, 170, 70)), (0.86, (40, 30, 90)), (0.97, (220, 170, 70))]
    c = col(bands[0][1])
    for r0, rgb in bands[1:]:
        c = mix(c, col(rgb), smooth(r0 - 0.005, r0 + 0.005, r))
    star = (np.abs(np.sin(a * 8)) * (0.55 - 0.24) + 0.24 > r) & (r > 0.24) & (r < 0.55)
    c = mix(c, col((200, 120, 50)), star.astype(np.float32) * 0.8)
    fringe = smooth(0.97, 1.0, r)
    c *= (0.85 + 0.25 * fbm(91, 128, 2))[..., None]
    return rgba(c, 1 - fringe)


# ---------------------------------------------------------------------------------------------------------------
# Rebel Alliance
# ---------------------------------------------------------------------------------------------------------------

def reb_olive():
    x, y = coords()
    seam, light = bevel_panels(x, y, 2, 2)
    n = fbm(101, 8, 5)
    c = col((92, 98, 62)) * (0.85 + 0.25 * n)[..., None]
    chips = smooth(0.78, 0.8, fbm(102, 16, 4)) * (1 - seam)
    c = mix(c, col((150, 150, 140)), chips * 0.8)
    rv = np.zeros_like(x)
    for k in range(8):
        t = (k + 0.5) / 8
        for cx, cy in ((t, 0.03), (t, 0.53), (0.03, t), (0.53, t)):
            rv = np.maximum(rv, disc_mask(x, y, cx, cy, 0.006, 0.003))
    c = c * (1 - 0.6 * seam)[..., None] * (1 + 0.15 * light)[..., None]
    c = mix(c, col((60, 64, 40)), rv * 0.8)
    return rgba(c, 0.25 + 0.25 * rv - 0.2 * seam)


def reb_hull(stripe=False):
    """X-wing hull: off-white panels, grime, optional red squadron stripes along u."""
    x, y = coords()
    seam, light = bevel_panels(x, y, 3, 2, 0.004)
    n = fbm(111, 8, 5)
    c = col((214, 212, 204)) * (0.88 + 0.16 * n)[..., None]
    grime = smooth(0.62, 0.9, fbm(112, 4, 6))
    c = mix(c, col((120, 110, 96)), grime * 0.45)
    if stripe:
        band = ((y > 0.34) & (y < 0.46)) | ((y > 0.54) & (y < 0.66))
        c = mix(c, col((176, 34, 30)), band.astype(np.float32))
    c = c * (1 - 0.5 * seam)[..., None]
    return rgba(c, 0.45 - 0.25 * grime)


def reb_quilt():
    """Orange flight-suit quilting with stitch lines."""
    x, y = coords()
    u, v = (x * 6) % 1.0, (y * 3) % 1.0
    puff = np.sin(u * math.pi) * np.sin(v * math.pi)
    c = col((212, 92, 24)) * (0.6 + 0.45 * puff)[..., None]
    stitch = ((np.abs(u - 0.0) < 0.02) | (np.abs(v) < 0.03)) & (((y * 200) % 1.0) < 0.6)
    c = mix(c, col((240, 210, 170)), stitch.astype(np.float32) * 0.5)
    c *= (0.92 + 0.12 * fbm(121, 64, 2))[..., None]
    return rgba(c, 0.15 + 0.2 * puff)


def reb_canvas():
    x, y = coords()
    weave = (np.sin(x * N * math.pi / 2) * np.sin(y * N * math.pi / 2)) * 0.5 + 0.5
    c = col((150, 138, 98)) * (0.85 + 0.1 * weave + 0.12 * fbm(131, 8, 5))[..., None]
    return rgba(c)


def reb_blanket():
    """Grey-green thermal blanket with a quilted grid and a white edge stripe."""
    x, y = coords()
    u, v = (x * 4) % 1.0, (y * 4) % 1.0
    puff = np.sin(u * math.pi) ** 0.5 * np.sin(v * math.pi) ** 0.5
    c = col((92, 104, 92)) * (0.65 + 0.4 * puff)[..., None]
    edge = (y < 0.05) | ((y > 0.08) & (y < 0.1))
    c = mix(c, col((220, 220, 210)), edge.astype(np.float32))
    return rgba(c * (0.95 + 0.1 * fbm(141, 64, 2))[..., None])


def _starbird(x, y, cx=0.5, cy=0.5, s=0.44):
    """Alliance starbird mask (y up): a tapering central spike and two crescent wings rising from a joined base,
    each wing ending in a point; the spike stands between the wing tips."""
    dx, dy = (x - cx) / s, (y - cy) / s
    r = np.sqrt(dx * dx + dy * dy)
    spike = (dy > -0.72) & (dy < 1.0) & (np.abs(dx) < 0.03 + 0.17 * (1.0 - dy) / 1.72)
    wing = np.zeros_like(dx, bool)
    for sx in (-1, 1):
        ex = sx * dx
        inner = np.sqrt((ex - 0.12) ** 2 + (dy - 0.30) ** 2)
        wing |= (r < 0.98) & (inner > 0.60) & (ex > 0.05) & (dy < 0.05 + 0.8 * ex)
    base = (r < 0.98) & (dy < -0.62) & (np.abs(dx) < 0.5)
    return (spike | wing | base).astype(np.float32)


def reb_crest():
    x, y = coords()
    m = _starbird(x, 1 - y)
    c = mix(col((236, 232, 224)), col((180, 30, 26)), m)
    return rgba(c, 1.0 + 0 * m)


def reb_console():
    """Dark console face with key rows and small lamps (lamps are geometry with emissive screens)."""
    x, y = coords()
    seam, light = bevel_panels(x, y, 1, 2, 0.01)
    c = col((52, 56, 54)) * (0.9 + 0.2 * fbm(151, 8, 4))[..., None]
    keys = (((x * 12) % 1.0) > 0.15) & (((x * 12) % 1.0) < 0.85) & (((y * 10) % 1.0) > 0.2) & (((y * 10) % 1.0) < 0.75) & (y > 0.55)
    c = mix(c, col((96, 100, 98)), keys.astype(np.float32))
    lamps = np.zeros_like(x)
    r = _rng(152)
    for _ in range(14):
        lamps = np.maximum(lamps, disc_mask(x, y, r.random(), 0.1 + 0.35 * r.random(), 0.012, 0.004))
    c = mix(c, col((255, 190, 60)), lamps)
    return rgba(c * (1 - 0.5 * seam)[..., None], 0.3)


def reb_screen():
    """Self-lit tactical display: green grid, a planet arc and readout bars."""
    x, y = coords()
    c = col((4, 22, 12))
    grid = np.maximum(lines(x, 1 / 8, 0.004), lines(y, 1 / 8, 0.004))
    c = mix(c, col((30, 160, 80)), grid * 0.6)
    arc = np.abs(np.sqrt((x - 0.3) ** 2 + (y - 1.2) ** 2) - 0.85) < 0.006
    c = mix(c, col((120, 255, 150)), arc.astype(np.float32))
    bars = (x > 0.65) & (x < 0.95) & ((y * 10) % 1.0 < 0.5) & (x - 0.65 < 0.3 * fbm(161, 4, 1)[:, :1].repeat(N, 1))
    c = mix(c, col((255, 200, 60)), bars.astype(np.float32))
    return rgba(c)


def holo(seed, tint=(90, 180, 255), fill=0.42):
    """Hologram: latitude/longitude wire grid with scanlines; alpha = brightness (a_alpha_emis_full). The fill
    between the wires is opaque enough (0.42) that whatever is behind (a magenta test sky, a red wall) cannot
    tint the hologram; wires go to white-hot."""
    x, y = coords()
    wire = np.maximum(lines(x, 1 / 16, 0.006), lines(y, 1 / 8, 0.008))
    scan = 0.75 + 0.25 * np.sin(y * N * math.pi / 3)
    glow = np.clip(wire * 0.95 + fill, 0, 1)
    c = col(tint) * (0.85 + 0.3 * wire)[..., None] + col((255, 255, 255)) * (wire * 0.45)[..., None]
    return rgba(c, glow * scan)


def imp_holo_solid():
    """Dense hologram for solid shapes (the Star Destroyer bridge tower): panel lines over a bright fill."""
    x, y = coords()
    seam, light = bevel_panels(x, y, 4, 4, 0.01)
    c = col((140, 215, 255)) * (0.9 + 0.2 * light)[..., None] + col((255, 255, 255)) * (seam * 0.5)[..., None]
    return rgba(c, 0.62 + 0.3 * seam)


def reb_red():
    """Alliance squadron red: worn gloss paint."""
    c = col((178, 30, 26)) * (0.88 + 0.18 * fbm(301, 8, 4))[..., None]
    return rgba(c, 0.5)


def imp_screen():
    """Superlaser fire-control display (self-lit): green targeting grid, the planet in the reticle, firing bars."""
    x, y = coords()
    c = col((2, 18, 8))
    grid = np.maximum(lines(x, 1 / 10, 0.003), lines(y, 1 / 10, 0.003))
    c = mix(c, col((20, 110, 40)), grid * 0.7)
    d = np.sqrt((x - 0.42) ** 2 + (y - 0.48) ** 2)
    planet = (d < 0.2).astype(np.float32)
    c = mix(c, col((60, 200, 90)) * (0.6 + 0.6 * fbm(311, 6, 4))[..., None], planet)
    rings = ((np.abs(d - 0.26) < 0.004) | (np.abs(d - 0.32) < 0.003)).astype(np.float32)
    cross = (((np.abs(x - 0.42) < 0.003) | (np.abs(y - 0.48) < 0.003)) & (d > 0.22) & (d < 0.4)).astype(np.float32)
    c = mix(c, col((170, 255, 170)), np.maximum(rings, cross))
    bars = (x > 0.78) & (x < 0.95) & ((y * 12) % 1.0 < 0.55) & (y > 0.1) & (y < 0.9)
    lit = bars & (y > 0.35)
    c = mix(c, col((40, 90, 40)), bars.astype(np.float32))
    c = mix(c, col((255, 60, 40)), lit.astype(np.float32))
    return rgba(c)


def hutt_roast():
    """Glazed roast: dark crackled crust over red-brown meat."""
    x, y = coords()
    n = fbm(321, 6, 5)
    crack = 1 - smooth(0.0, 0.025, np.abs(fbm(322, 10, 3) - 0.5))
    c = mix(col((92, 40, 18)), col((168, 82, 36)), n)
    c = mix(c, col((50, 18, 8)), crack * 0.7)
    return rgba(c, 0.55 + 0.3 * n)


def hutt_fruit():
    """Exotic fruit skins in a 2 x 2 atlas (u, v quadrants): jogan orange, purple meiloorun, green pallie, yellow."""
    x, y = coords()
    n = fbm(331, 16, 4)
    q = (x > 0.5).astype(int) + 2 * (y > 0.5).astype(int)
    pal = np.array([(230, 120, 30), (110, 40, 120), (110, 170, 50), (225, 200, 60)], np.float32) / 255
    c = pal[q] * (0.8 + 0.35 * n)[..., None]
    return rgba(c, 0.7)


def reb_holo():
    return holo(171)


def reb_holo_dish():
    """Death Star superlaser dish + equatorial trench, drawn over the holo grid (fit on the dish cap)."""
    x, y = coords()
    base = holo(172).astype(np.float32) / 255
    d = np.sqrt((x - 0.5) ** 2 + (y - 0.5) ** 2)
    ring = (np.abs(d - 0.42) < 0.02) | (np.abs(d - 0.12) < 0.03) | (d < 0.04)
    spokes = (np.abs(np.sin(np.arctan2(y - 0.5, x - 0.5) * 4)) < 0.06) & (d < 0.42)
    m = (ring | spokes).astype(np.float32)
    rgb = mix(base[..., :3], col((200, 240, 255)), m)
    return rgba(rgb, np.maximum(base[..., 3], m))


# ---------------------------------------------------------------------------------------------------------------
# Galactic Empire
# ---------------------------------------------------------------------------------------------------------------

def imp_black():
    """Glossy black lacquer panels: faint seams, mirror alpha (envmask) except in the seams."""
    x, y = coords()
    seam, light = bevel_panels(x, y, 2, 4, 0.004)
    c = col((14, 14, 16)) * (1 + 0.6 * fbm(181, 4, 4))[..., None]
    c = c * (1 - 0.6 * seam)[..., None] + col((40, 40, 46)) * (light * 0.4)[..., None]
    return rgba(c, 0.55 - 0.45 * seam)


def imp_grey():
    """Star Destroyer deck grey: large panels with recessed grooves and tiny greebles."""
    x, y = coords()
    seam, light = bevel_panels(x, y, 2, 2, 0.006)
    g = grooves(x, 0.125, 0.008) * (((y * 2) % 1.0) > 0.7)
    n = fbm(191, 8, 5)
    c = col((116, 120, 126)) * (0.9 + 0.15 * n)[..., None]
    c = c * (1 - 0.55 * seam - 0.35 * g)[..., None] * (1 + 0.12 * light)[..., None]
    return rgba(c, 0.4 - 0.3 * seam)


def imp_white():
    """Stormtrooper armour white: gloss plastic with faint panel lines and black vent slots."""
    x, y = coords()
    seam, _ = bevel_panels(x, y, 2, 1, 0.003)
    c = col((236, 238, 240)) * (0.96 + 0.06 * fbm(201, 4, 4))[..., None]
    vents = ((x * 16) % 1.0 < 0.4) & (y > 0.8) & (y < 0.9) & (x > 0.25) & (x < 0.75)
    c = c * (1 - 0.35 * seam)[..., None]
    c = mix(c, col((30, 30, 34)), vents.astype(np.float32))
    return rgba(c, 0.75)


def imp_leather():
    """Black tufted leather (channel stitched)."""
    x, y = coords()
    u = (x * 5) % 1.0
    puff = np.sin(u * math.pi) ** 0.6
    c = col((22, 20, 22)) * (0.5 + 0.7 * puff)[..., None] * (0.9 + 0.2 * fbm(211, 32, 3))[..., None]
    stitch = (np.abs(u - 0.0) < 0.03) & (((y * 120) % 1.0) < 0.5)
    c = mix(c, col((80, 80, 84)), stitch.astype(np.float32))
    return rgba(c, 0.25 + 0.4 * puff)


def imp_red():
    """Red light strip: hot core across v, falloff to the edges (a_emis_full)."""
    x, y = coords()
    core = np.exp(-((y - 0.5) / 0.22) ** 2)
    c = mix(col((90, 0, 0)), col((255, 60, 40)), core)
    c = mix(c, col((255, 210, 190)), np.exp(-((y - 0.5) / 0.06) ** 2))
    seg = 1 - 0.25 * (np.abs(((x * 8) % 1.0) - 0.5) > 0.47)
    return rgba(c * seg[..., None])


def imp_crest():
    """Imperial crest: six-spoked cog roundel, white on black."""
    x, y = coords()
    dx, dy = x - 0.5, y - 0.5
    r = np.sqrt(dx * dx + dy * dy) / 0.45
    a = np.arctan2(dy, dx)
    ring = (r < 1.0) & (r > 0.86)
    hub = r < 0.28
    hubhole = r < 0.18
    sector = (a * 6 / (2 * math.pi)) % 1.0
    spokes = (np.abs(sector - 0.5) < 0.16 + 0.12 * (r - 0.28)) & (r > 0.28) & (r < 0.86)
    teeth = ((a * 12 / (2 * math.pi)) % 1.0 < 0.5) & (r >= 1.0) & (r < 1.07)
    m = ((ring | (hub & ~hubhole) | spokes | teeth)).astype(np.float32)
    c = mix(col((16, 16, 18)), col((236, 236, 236)), m)
    return rgba(c, 0.4 + 0.4 * m)


def imp_chrome():
    x, y = coords()
    c = mix(col((140, 144, 150)), col((220, 224, 230)), fbm(221, 2, 3))
    return rgba(c, 0.95)


def imp_holo():
    return holo(231, (120, 200, 255))


def imp_glass_red():
    """Smoked red viewport glass."""
    x, y = coords()
    c = col((120, 10, 10)) * (0.8 + 0.3 * fbm(241, 4, 3))[..., None]
    return rgba(c, 0.55)


def reb_glass():
    x, y = coords()
    c = col((170, 210, 230)) * (0.9 + 0.2 * fbm(251, 4, 3))[..., None]
    streak = np.exp(-(((x + y) % 0.5 - 0.25) / 0.03) ** 2) * 0.5
    return rgba(c + streak[..., None] * 0.3, 0.28 + 0.25 * streak)


def reb_r2():
    """Astromech dome: white with blue panels (u around, v from top 0 to rim 1) and the radar eye."""
    x, y = coords()
    c = col((226, 228, 232)) * (0.95 + 0.06 * fbm(261, 4, 3))[..., None]
    band = (y > 0.55) & (y < 0.8) & (((x * 8) % 1.0) > 0.15) & (((x * 8) % 1.0) < 0.75)
    top = (y > 0.18) & (y < 0.4) & (((x * 4 + 0.3) % 1.0) < 0.3)
    c = mix(c, col((40, 70, 170)), (band | top).astype(np.float32))
    eye = disc_mask(x, y, 0.5, 0.45, 0.05, 0.006)
    c = mix(c, col((20, 20, 24)), eye)
    c = mix(c, col((220, 40, 30)), disc_mask(x, y, 0.5, 0.45, 0.02, 0.006))
    rims = np.maximum(lines(y, 1.0, 0.006), (np.abs(y - 0.55) < 0.004) + (np.abs(y - 0.8) < 0.004))
    return rgba(c * (1 - 0.4 * rims)[..., None], 0.6)


def reb_gunmetal():
    x, y = coords()
    c = col((48, 50, 54)) * (0.85 + 0.3 * fbm(271, 8, 4))[..., None]
    knurl = (np.sin(x * N * 0.6) * np.sin(y * N * 0.6) > 0.6) & (y > 0.7)
    c = mix(c, col((30, 30, 32)), knurl.astype(np.float32))
    return rgba(c, 0.55)


def imp_linen():
    """Officer's bunk linen: cool grey wool with white piping along v = 0.06."""
    x, y = coords()
    weave = (np.sin(x * N * math.pi / 2) * np.sin(y * N * math.pi / 2)) * 0.5 + 0.5
    c = col((84, 88, 96)) * (0.88 + 0.08 * weave + 0.1 * fbm(281, 8, 4))[..., None]
    pipe = np.abs(y - 0.06) < 0.012
    c = mix(c, col((230, 232, 236)), pipe.astype(np.float32))
    return rgba(c)


def imp_pillow():
    x, y = coords()
    c = col((222, 224, 228)) * (0.9 + 0.1 * fbm(291, 8, 4))[..., None]
    return rgba(c)


def imp_holo_crest():
    """Holographic Imperial crest (fit on a disc): the crest as blue light, scanlines, alpha = brightness."""
    x, y = coords()
    m = (imp_crest()[..., 0] > 128).astype(np.float32)
    scan = 0.65 + 0.35 * np.sin(y * N * math.pi / 3)
    d = np.sqrt((x - 0.5) ** 2 + (y - 0.5) ** 2)
    halo = np.clip(0.45 - d, 0, 1) * 0.35
    c = col((70, 160, 255)) * (0.7 + 0.5 * m)[..., None] + col((200, 235, 255)) * (m * 0.15)[..., None]
    return rgba(c, np.clip(m * 0.98 + halo + 0.08, 0, 1) * scan)


def fruit_skin(k):
    """One fruit skin from the hutt_fruit palette (solid colour, mottled)."""
    pal = [(230, 120, 30), (110, 40, 120), (110, 170, 50), (225, 200, 60)]
    n = fbm(341 + k, 16, 4)
    c = col(pal[k]) * (0.8 + 0.35 * n)[..., None]
    return rgba(c, 0.7)


# ---------------------------------------------------------------------------------------------------------------
# media pieces: video screens (shader names contain "screen"), painting canvas ("canvas"), frames, cam droid.
# The client puts video / magic-painting / RT-camera textures only on screen and canvas shaders when an
# appearance has one, so these standby images are what shows until a stream or URL is set.
# ---------------------------------------------------------------------------------------------------------------

def _standby(bg, fg, emblem_mask, label_rgb):
    """Standby screen: dark gradient, a dim emblem in the middle, scan lines and a status bar at the bottom left
    (asymmetric on purpose: it shows the image orientation in a test)."""
    x, y = coords()
    c = mix(col(bg), col(tuple(int(v * 0.4) for v in bg)), y)
    c = mix(c, col(fg), emblem_mask * 0.55)
    scan = 0.92 + 0.08 * np.sin(y * N * math.pi / 2)
    c = c * scan[..., None]
    bar = (x > 0.04) & (x < 0.34) & (y > 0.88) & (y < 0.93)
    dot = disc_mask(x, y, 0.38, 0.905, 0.02, 0.004)
    c = mix(c, col(label_rgb), bar.astype(np.float32) * 0.9)
    c = mix(c, col((255, 60, 40)), dot)
    return rgba(c)


def imp_video_screen():
    x, y = coords()
    m = (imp_crest()[..., 0] > 128).astype(np.float32)
    # squash the square crest into the middle of a 16:9 screen
    xs = np.clip((x - 0.5) * 1.78 + 0.5, 0, 1)
    idx_x = (xs * (N - 1)).astype(int)
    m = m[(y * (N - 1)).astype(int), idx_x] * ((x > 0.22) & (x < 0.78))
    return _standby((10, 14, 22), (200, 30, 30), m, (180, 30, 30))


def reb_video_screen():
    x, y = coords()
    xs = np.clip((x - 0.5) * 1.78 + 0.5, 0, 1)
    m = _starbird(xs, 1 - y) * ((x > 0.22) & (x < 0.78))
    return _standby((14, 22, 18), (210, 160, 60), m, (230, 140, 40))


def hutt_video_screen():
    x, y = coords()
    xs = (x - 0.5) * 1.78
    d = np.sqrt(xs ** 2 + (y - 0.5) ** 2)
    a = np.arctan2(y - 0.5, xs)
    m = ((np.abs(d - 0.28) < 0.02) | ((d < 0.24) & (np.abs(np.sin(a * 6)) > 0.85)) | (d < 0.06)).astype(np.float32)
    return _standby((26, 14, 8), (230, 170, 70), m, (230, 170, 70))


def painting_canvas():
    """Placeholder canvas: twin suns setting over dunes (shown until a magic-painting URL is set)."""
    x, y = coords()
    sky = mix(col((250, 170, 90)), col((70, 50, 110)), smooth(0.15, 0.75, 1 - y))
    c = sky.copy()
    for sx, sy, r, rgb in ((0.62, 0.42, 0.07, (255, 240, 200)), (0.74, 0.47, 0.05, (255, 210, 150))):
        d = np.sqrt((x - sx) ** 2 + (y - sy) ** 2)
        c = mix(c, col(rgb), smooth(r, r * 0.8, d))
        c = c + col((255, 180, 100)) * (np.clip(0.25 - d, 0, 1) * 0.8)[..., None]
    n = fbm(351, 4, 4)
    for k, (base, amp, rgb) in enumerate(((0.62, 0.05, (190, 120, 70)), (0.72, 0.06, (150, 90, 55)), (0.84, 0.05, (110, 65, 45)))):
        ridge = base + amp * np.sin(x * math.pi * (2 + k) + k) + 0.03 * (n - 0.5)
        c = mix(c, col(rgb), (y > ridge).astype(np.float32))
    brush = 0.94 + 0.08 * fbm(352, 64, 2)
    return rgba(c * brush[..., None])


def gilt():
    """Gilded frame: warm gold leaf with acanthus scroll relief along v (frames sweep their profile along u)."""
    x, y = coords()
    n = fbm(361, 8, 4)
    scroll = 0.5 + 0.5 * np.sin(x * 2 * math.pi * 6 + np.sin(y * 2 * math.pi * 3) * 2)
    leaf = smooth(0.55, 0.75, scroll) * (np.abs(y - 0.5) < 0.3)
    c = mix(col((150, 105, 35)), col((245, 205, 110)), 0.4 + 0.4 * n)
    c = c * (0.75 + 0.35 * leaf)[..., None]
    rub = smooth(0.7, 0.9, fbm(362, 16, 3))
    c = mix(c, col((90, 55, 25)), rub * 0.35)
    return rgba(c, 0.8 - 0.3 * rub)


def cam_metal():
    """Cam droid shell: satin gunmetal with panel seams and small vents."""
    x, y = coords()
    seam, light = bevel_panels(x, y, 3, 2, 0.006)
    c = col((88, 92, 100)) * (0.9 + 0.15 * fbm(371, 8, 4))[..., None]
    vents = ((x * 24) % 1.0 < 0.45) & (y > 0.08) & (y < 0.16) & (x > 0.55) & (x < 0.9)
    c = c * (1 - 0.5 * seam)[..., None] * (1 + 0.1 * light)[..., None]
    c = mix(c, col((30, 30, 34)), vents.astype(np.float32))
    return rgba(c, 0.6 - 0.3 * seam)


def cam_lens():
    """Camera lens glass: deep blue iris rings with a bright core (self-lit, it reads as 'recording')."""
    x, y = coords()
    d = np.sqrt((x - 0.5) ** 2 + (y - 0.5) ** 2) * 2
    c = mix(col((10, 20, 40)), col((40, 90, 170)), smooth(0.9, 0.2, d))
    rings = (np.abs(np.sin(d * math.pi * 7)) > 0.92).astype(np.float32) * (d < 0.9)
    c = mix(c, col((120, 180, 255)), rings * 0.6)
    c = mix(c, col((230, 245, 255)), smooth(0.14, 0.05, d))
    hl = disc_mask(x, y, 0.36, 0.34, 0.06, 0.03)
    c = mix(c, col((255, 255, 255)), hl * 0.8)
    return rgba(c)


def cam_glow():
    """Repulsor / status glow: hot cyan core fading out (a_alpha_emis_full)."""
    x, y = coords()
    d = np.sqrt((x - 0.5) ** 2 + (y - 0.5) ** 2) * 2
    c = mix(col((180, 240, 255)), col((40, 140, 255)), smooth(0.0, 0.8, d))
    return rgba(c, np.clip(1.0 - d, 0, 1) ** 1.5)


# key -> effect, builder, specular grey, power
MATS = {
    "hutt_sandstone": ("a_simple", hutt_sandstone, 0, 0),
    "hutt_frieze": ("a_simple", hutt_frieze, 0, 0),
    "hutt_velvet": ("a_specmap", hutt_velvet, 0.35, 12),
    "hutt_silk": ("a_specmap", hutt_silk, 0.5, 20),
    "hutt_brass": ("a_specmap", hutt_brass, 0.7, 30),
    "hutt_wood": ("a_specmap", hutt_wood, 0.35, 25),
    "hutt_flesh": ("a_specmap", hutt_flesh, 0.6, 18),
    "hutt_bone": ("a_specmap", hutt_bone, 0.3, 20),
    "hutt_coals": ("a_emis_full", hutt_coals, 0, 0),
    "hutt_gorg_water": ("a_alpha", hutt_gorg_water, 0, 0),
    "hutt_rug": ("a_alpha", hutt_rug, 0, 0),
    "reb_olive": ("a_specmap", reb_olive, 0.3, 15),
    "reb_hull": ("a_specmap", reb_hull, 0.35, 20),
    "reb_hull_stripe": ("a_specmap", lambda: reb_hull(True), 0.35, 20),
    "reb_quilt": ("a_specmap", reb_quilt, 0.2, 10),
    "reb_canvas": ("a_simple", reb_canvas, 0, 0),
    "reb_blanket": ("a_simple", reb_blanket, 0, 0),
    "reb_crest": ("a_simple", reb_crest, 0, 0),
    "reb_console": ("a_specmap", reb_console, 0.3, 20),
    "reb_screen": ("a_emis_full", reb_screen, 0, 0),
    "reb_holo": ("a_alpha_emis_full", reb_holo, 0, 0),
    "reb_holo_dish": ("a_alpha_emis_full", reb_holo_dish, 0, 0),
    "imp_black": ("a_specmap", imp_black, 0.6, 40),
    "imp_grey": ("a_specmap", imp_grey, 0.35, 20),
    "imp_white": ("a_specmap", imp_white, 0.6, 35),
    "imp_leather": ("a_specmap", imp_leather, 0.35, 18),
    "imp_red": ("a_emis_full", imp_red, 0, 0),
    "imp_crest": ("a_specmap", imp_crest, 0.4, 25),
    "imp_chrome": ("a_specmap", imp_chrome, 0.9, 50),
    "imp_holo": ("a_alpha_emis_full", imp_holo, 0, 0),
    "imp_glass_red": ("a_alpha", imp_glass_red, 0, 0),
    "reb_glass": ("a_alpha", reb_glass, 0, 0),
    "reb_r2": ("a_specmap", reb_r2, 0.5, 30),
    "reb_gunmetal": ("a_specmap", reb_gunmetal, 0.5, 25),
    "imp_linen": ("a_simple", imp_linen, 0, 0),
    "imp_pillow": ("a_simple", imp_pillow, 0, 0),
    "imp_holo_crest": ("a_alpha_emis_full", imp_holo_crest, 0, 0),
    "imp_holo_solid": ("a_alpha_emis_full", imp_holo_solid, 0, 0),
    "reb_red": ("a_specmap", reb_red, 0.45, 25),
    "imp_screen": ("a_emis_full", imp_screen, 0, 0),
    "hutt_roast": ("a_specmap", hutt_roast, 0.5, 18),
    "hutt_fruit": ("a_specmap", hutt_fruit, 0.4, 22),
    "imp_video_screen": ("a_emis_full", imp_video_screen, 0, 0),
    "reb_video_screen": ("a_emis_full", reb_video_screen, 0, 0),
    "hutt_video_screen": ("a_emis_full", hutt_video_screen, 0, 0),
    "painting_canvas": ("a_simple", painting_canvas, 0, 0),
    "gilt": ("a_specmap", gilt, 0.7, 30),
    "cam_metal": ("a_specmap", cam_metal, 0.55, 30),
    "cam_lens": ("a_emis_full", cam_lens, 0, 0),
    "cam_glow": ("a_alpha_emis_full", cam_glow, 0, 0),
    "hutt_fruit_0": ("a_specmap", lambda: fruit_skin(0), 0.4, 22),
    "hutt_fruit_1": ("a_specmap", lambda: fruit_skin(1), 0.4, 22),
    "hutt_fruit_2": ("a_specmap", lambda: fruit_skin(2), 0.4, 22),
    "hutt_fruit_3": ("a_specmap", lambda: fruit_skin(3), 0.4, 22),
}
ENV = "texture/env_all_metl.dds"

_ALL = None


def all_mats(refresh=False):
    """MATS plus the themed groups' materials (examples/frn_sets/<group>.py, which may import this module)."""
    global _ALL
    if _ALL is None or refresh:
        import frn_sets
        _ALL = dict(MATS)
        frn_sets.merge(mats=_ALL)
    return _ALL


def write_dds(path, img):
    """Uncompressed A8R8G8B8 .dds with a box-filtered mip chain (numpy), like iff.write_dds_rgba."""
    h, w = img.shape[:2]
    levels = [img.astype(np.float32)]
    while levels[-1].shape[0] > 1 or levels[-1].shape[1] > 1:
        a = levels[-1]
        a = a[: a.shape[0] // 2 * 2 or 1, : a.shape[1] // 2 * 2 or 1]
        if a.shape[0] > 1:
            a = (a[0::2] + a[1::2]) / 2
        if a.shape[1] > 1:
            a = (a[:, 0::2] + a[:, 1::2]) / 2
        levels.append(a)
    hdr = struct.pack("<4sIIIIIII44x", b"DDS ", 124, 0x100F | 0x20000, h, w, w * 4, 0, len(levels))
    pf = struct.pack("<II4sIIIII", 32, 0x41, b"\0\0\0\0", 32, 0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000)
    caps = struct.pack("<IIII4x", 0x1000 | 0x400008, 0, 0, 0)
    body = b"".join(np.clip(lv + 0.5, 0, 255).astype(np.uint8)[..., [2, 1, 0, 3]].tobytes() for lv in levels)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_bytes(hdr + pf + caps + body)


def shader_path(key):
    return f"shader/{PREFIX}{key}.sht"


def write_shader(export_root, key):
    effect, _, spec, power = all_mats()[key]
    tex = f"texture/{PREFIX}{key}.dds"
    kw = {}
    if effect in ("a_specmap", "a_envmask_specmap"):
        textures = ([("ENVM", ENV, b"\0\2\2\0\2\2\2")] if effect == "a_envmask_specmap" else []) + \
            [("MAIN", tex), ("SPEC", tex)]
        kw = dict(textures=textures, tfactors={"BLCK": 0xFF000000}, alpha_ref=[("SPEC", 1)],
                  specular=(spec, spec, spec), power=power)
    elif effect.startswith("a_alpha"):
        kw = dict(texture=tex, alpha_ref=8)
    else:
        kw = dict(texture=tex)
    block = iff.shader_block(f"effect\\{effect}.eft", **kw)
    out = Path(export_root) / shader_path(key)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(iff.serialize_iff(iff._form("<root>", [block])))
    return out


def write_all(export_root, preview_png=None, keys=None):
    imgs = {}
    mats = all_mats(refresh=True)
    for key in keys or mats:
        img = mats[key][1]()
        write_dds(Path(export_root) / f"texture/{PREFIX}{key}.dds", img)
        write_shader(export_root, key)
        imgs[key] = img
    if preview_png:
        from PIL import Image, ImageDraw
        cols = 8
        rows = (len(imgs) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * 160, rows * 176), (30, 30, 30))
        d = ImageDraw.Draw(sheet)
        for i, (k, img) in enumerate(imgs.items()):
            im = Image.fromarray(img[..., :3]).resize((156, 156))
            sheet.paste(im, ((i % cols) * 160 + 2, (i // cols) * 176 + 2))
            d.text(((i % cols) * 160 + 4, (i // cols) * 176 + 160), k, fill=(255, 255, 255))
        sheet.save(preview_png)
    return sorted(imgs)


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("TITAN_EXPORT_ROOT", "D:/exported")
    print(write_all(root, sys.argv[2] if len(sys.argv) > 2 else None))
