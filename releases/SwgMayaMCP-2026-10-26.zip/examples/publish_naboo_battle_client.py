"""Publish the Battle of Naboo heroic's client-side data to where the game clients read it.

SwgTitan_d / SwgTitan_r read the titanpaks, `sys.client/built/game` (searchPath_00_11) and `D:/exported`
(searchPath_00_12) - not `D:/titan/data` (see the swg-client-search-paths memory note). The heroic's server work
compiles into `data`, so this copies what the client needs:

  new files              -> D:/exported/<path>                 (our templates, strings, quest and area tables)
                            the server reads D:/exported too (searchPath9, ahead of data), so after changing
                            any of these in data, re-run this script or the stale copy wins on the server as well
  changed stock tables   -> data/sku.0/sys.client/built/game/<path>
                            a client-only overlay: the server never reads it, so these copies can't hide a later
                            server-side change to the same table. Re-run this script after changing any of them.

    python examples/publish_naboo_battle_client.py [--dry-run]

Existing destination files that differ are kept as <name>.pre-naboo-publish once."""
from __future__ import annotations

import filecmp
import shutil
import sys
from pathlib import Path

DATA = Path("D:/titan/data/sku.0")
SHARED = DATA / "sys.shared/compiled/game"
SHARED_BUILT = DATA / "sys.shared/built/game"
CLIENT = DATA / "sys.client/compiled/game"
EXPORT = Path("D:/exported")
OVERLAY = DATA / "sys.client/built/game"

NEW = [  # (source root, glob relative to it)
    (SHARED, "object/mobile/titan/heroic/naboo/shared_*.iff"),
    (SHARED, "object/tangible/titan/heroic/naboo/shared_*.iff"),
    (SHARED, "object/weapon/ranged/vehicle/shared_titan_*.iff"),
    (SHARED, "datatables/buildout/areas_adventure_heroic.iff"),
    (SHARED, "datatables/questlist/quest/heroic_naboo_battle.iff"),
    (SHARED, "datatables/questtask/quest/heroic_naboo_battle.iff"),
    (CLIENT, "string/en/theme_park/heroic_naboo_battle.stf"),
    (CLIENT, "string/en/quest/ground/heroic_naboo_battle.stf"),
    (CLIENT, "datatables/loading/adventure_heroic.iff"),
    (CLIENT, "texture/ui_map_adventure_heroic.dds"),
]
CHANGED_STOCK = [
    (SHARED, "datatables/command/command_table_ground.iff"),
    (SHARED, "datatables/buildout/buildout_scenes.iff"),
    (SHARED, "misc/planet_crc_string_table.iff"),
    (SHARED_BUILT, "misc/quest_crc_string_table.iff"),
    (CLIENT, "string/en/instance.stf"),
    (CLIENT, "string/en/static_item_n.stf"),
    (CLIENT, "string/en/static_item_d.stf"),
    (CLIENT, "string/en/mob/creature_names.stf"),
    (CLIENT, "string/en/planet_n.stf"),
    (CLIENT, "string/en/zone_n.stf"),
    (CLIENT, "datatables/weapon/weapon.iff"),
    # The area buildout table has one name and two formats: the client's (shared_template_crc - WorldSnapshot
    # FATALs without it) and the server's (server_template_crc, the controller egg). The server reads D:/exported
    # (searchPath9), so the client copy - empty, the encounter spawns everything - must stay in the overlay.
    (CLIENT, "datatables/buildout/adventure_heroic/heroic_naboo_battle.iff"),
]


def publish(pairs, dest_root, dry):
    done = []
    for root, pattern in pairs:
        hits = sorted(root.glob(pattern))
        if not hits:
            raise SystemExit(f"missing: {root / pattern}")
        for src in hits:
            rel = src.relative_to(root)
            dst = dest_root / rel
            if dst.exists() and filecmp.cmp(src, dst, shallow=False):
                done.append(f"same     {rel}")
                continue
            if not dry:
                dst.parent.mkdir(parents=True, exist_ok=True)
                bak = dst.with_name(dst.name + ".pre-naboo-publish")
                if dst.exists() and not bak.exists():
                    shutil.copy2(dst, bak)
                shutil.copy2(src, dst)
            done.append(f"{'would ' if dry else ''}copy {rel}")
    return done


if __name__ == "__main__":
    dry = "--dry-run" in sys.argv
    for line in publish(NEW, EXPORT, dry):
        print("exported ", line)
    for line in publish(CHANGED_STOCK, OVERLAY, dry):
        print("overlay  ", line)
