"""Build the Otoh Gunga structure set (maya/swg_mcp/otoh_gunga.py) and make every piece spawnable:

  materials   examples/otoh_materials.py: generated textures + .sht shaders in the export tree
  hub         POB building nboo_otoh_hub (pob_build cells, dressed: glow domes, ribs, lantern, skins), stepwise with
              .mb checkpoints; exterior .lod with radar shape; object/building/titan/shared_nboo_otoh_hub.iff
              (+ .lay flatten layer, .sfp footprint, client data file)
  pieces      object/static/structure/naboo/shared_nboo_otoh_<piece>_s01.iff, each a .lod with collision boxes
              (the tube: its walk floor), radar footprint and the mesh hardpoints
  effects     clientdata/client_shared_nboo_otoh_<piece>.cdf: amber / blue lights carrying stock glow particles
              (pt_light_streetlamp_gold, pt_light_sm_lamp_gold, pt_light_streetlamp_blue) on the glow hardpoints,
              rising bubbles (pt_bubble_trail) and glowzee swarms (pt_flocking_glowzees) on the hub
  checks      swg_check on the .pob and every .flr; review renders in %TEMP%/swg_otoh

Run: python examples/make_otoh_gunga.py [hub] [pieces]   (default both)
Spawn: /scene objectCreate object/building/titan/shared_nboo_otoh_hub.iff <x> <z> <heading>
       /scene objectCreate object/static/structure/naboo/shared_nboo_otoh_pod_sm_s01.iff <x> <z> <heading>"""
import asyncio
import base64
import json
import math
import os
import sys
import tempfile
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
from swg_maya_mcp import iff  # noqa: E402
import otoh_materials  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
CLIENT = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
RENDERS = Path(os.environ.get("OTOH_RENDER_DIR", os.path.join(tempfile.gettempdir(), "swg_otoh")))
STATIC_BASE = CLIENT / "object/static/structure/corellia/shared_corl_imprv_wall_4x16_s01.iff"
PIECES = ["pod_sm", "pod_md", "pod_hanging", "sphere_blue", "tube", "stalk", "rib_arch", "rib_lattice", "dome_lg",
          "bubble_cluster"]

AMBER = {"rgb": (0.32, 0.18, 0.05), "constant": 0.1}
GOLD_GLOW = "appearance/pt_light_streetlamp_gold.prt"
LAMP_GLOW = "appearance/pt_light_sm_lamp_gold.prt"
BLUE_GLOW = "appearance/pt_light_streetlamp_blue.prt"
BUBBLES = "appearance/pt_bubble_trail.prt"
SWARM = "appearance/pt_flocking_glowzees.prt"
# hardpoint -> (light range, glow particle) per piece; children = (hardpoint, appearance)
EFFECTS = {
    "nboo_otoh_hub": {"lights": {"glow_top": (16.0, GOLD_GLOW), "glow_pod_east": (9.0, LAMP_GLOW),
                                 "glow_pod_west": (9.0, LAMP_GLOW), "glow_door": (8.0, LAMP_GLOW)},
                      "children": [("bubbles_top", BUBBLES), ("swarm", SWARM)]},
    "pod_sm": {"lights": {"glow_core": (8.0, LAMP_GLOW), "glow_top": (0, None)}, "children": [("glow_top", BUBBLES)]},
    "pod_md": {"lights": {"glow_core": (10.0, GOLD_GLOW)}, "children": [("glow_top", BUBBLES)]},
    "pod_hanging": {"lights": {"glow_core": (7.0, LAMP_GLOW)}, "children": []},
    "sphere_blue": {"lights": {"glow_blue": (8.0, BLUE_GLOW)}, "children": [], "rgb": (0.05, 0.14, 0.32)},
    "tube": {"lights": {"glow_mid": (6.0, LAMP_GLOW)}, "children": []},
    "stalk": {"lights": {"glow_top": (14.0, GOLD_GLOW)}, "children": []},
    "rib_arch": {"lights": {"glow_top": (8.0, LAMP_GLOW)}, "children": []},
    "rib_lattice": {"lights": {"glow_top": (8.0, LAMP_GLOW), "glow_pool": (7.0, None)}, "children": [("glow_pool", BUBBLES)]},
    "dome_lg": {"lights": {"glow_core": (14.0, GOLD_GLOW), "glow_low": (9.0, None)}, "children": [("glow_top", BUBBLES)]},
    "bubble_cluster": {"lights": {"glow_top": (9.0, LAMP_GLOW), "glow_core": (7.0, None)}, "children": []},
}

SETUP = ("import sys, importlib\np = 'D:/titan/support/MCP/SwgMayaMCP/maya'\nif p not in sys.path: sys.path.insert(0, p)\n"
         "import swg_mcp.pob_builder as pb, swg_mcp.kit as kit, swg_mcp.otoh_gunga as og\n"
         "for m in (pb, kit, og): importlib.reload(m)\nog.configure(args['shaders'])\n")


def text(res):
    return "\n".join(getattr(c, "text", "") for c in res.content)


def cdf(key, rel):
    fx = EFFECTS[key]
    lights = [dict(AMBER, rgb=fx.get("rgb", AMBER["rgb"]), range=rng, hardpoint=hp, appearance=prt or "")
              for hp, (rng, prt) in fx["lights"].items() if rng]
    children = [{"hardpoint": hp, "appearance": a} for hp, a in fx["children"]] + \
        [{"hardpoint": hp, "appearance": prt} for hp, (rng, prt) in fx["lights"].items() if not rng and prt]
    return iff.write_client_data(EXPORT / rel, hardpoint_lights=lights, hardpoint_children=children)


FRONT_Z = 13.1        # r0 floor edges beyond this (the porch in front of the foyer, its ramp) stay crossable


def seal_pad(pob):
    """The pad round the domes lies inside the glass skins, which are not collision: its open rim becomes
    uncrossable so nobody walks out through the glass. Only the entrance front (porch + ramp) meets the terrain."""
    r0_floor = EXPORT / iff.read_pob(pob)["cells"][0]["floor"]
    return iff.set_floor_edge_types(r0_floor, lambda a, b, et: 0 if et == 1 and (a[2] + b[2]) / 2 < FRONT_Z else et)


# bubble skins in engine space (otoh_gunga HUB_SKIN / POD_SKIN / POD_CX): centre, radius
SKINS = [((0.0, 3.0, 0.0), math.hypot(10.0, 3.0))] + \
    [((s * (12.6 + math.sqrt(4.5 ** 2 - 1.8 ** 2)), 2.6, 0.0), math.hypot(5.2, 2.6)) for s in (-1, 1)]


BOX_H, BOX_STEP = 0.45, 1.0      # glass fence: 0.9 m boxes every metre (gaps far narrower than a player)


def _glass_fence():
    """Maya-space box centres along the foot of each skin (outside the pad rim), skipping the arched openings,
    plus fences along the outer sides of the pad strips that run out through the openings, up to the porch."""
    centres = []
    open_hw = 2.5                                             # otoh_gunga.OPEN_HW
    pod_cx = 12.6 + math.sqrt(4.5 ** 2 - 1.8 ** 2)
    rings = [((0.0, 0.0), 10.0 + 0.35, [(0, 1), (1, 0), (-1, 0)]),   # hub: foyer +z, tubes +-x
             ((pod_cx, 0.0), 5.2 + 0.45, [(-1, 0)]), ((-pod_cx, 0.0), 5.2 + 0.45, [(1, 0)])]
    for (cx, cz), r, opens in rings:
        n = int(2 * math.pi * r / BOX_STEP) + 1
        for k in range(n):
            a = 2 * math.pi * k / n
            dx, dz = math.cos(a), math.sin(a)
            if any(dx * ox + dz * oz > 0 and abs(-dx * oz + dz * ox) * r < open_hw + BOX_H for ox, oz in opens):
                continue
            centres.append((cx + r * dx, cz + r * dz))
    side = open_hw + BOX_H
    for s in (-1, 1):
        x = 9.9
        while x < pod_cx - 5.2:                               # tube strips, between hub and pod skins
            centres += [(x, s * side), (-x, s * side)]
            x += BOX_STEP
        z = 9.9
        while z < FRONT_Z - 0.3:                              # foyer strips, up to the porch
            centres.append((s * side, z))
            z += BOX_STEP
    return [((x - BOX_H, -0.3, z - BOX_H), (x + BOX_H, 3.0, z + BOX_H)) for x, z in centres]


def glass_collision(lod):
    """Collision for the glass, in the r0 .lod's APPR: a composite of boxes along the skins' feet. Players on the
    terrain are only stopped by simple extents (CollisionDetect::testExtents ignores mesh extents, so the skin
    band in r0's CMSH only serves the camera); players on the pad are held by its sealed rim (seal_pad)."""
    return iff.set_lod_collision_boxes(EXPORT / lod, _glass_fence())


def finish_hub():
    """Host side after the hub export: sealed pad rim, exterior .lod (radar shape), template + .lay + .sfp, client
    data file."""
    pob = EXPORT / "appearance/nboo_otoh_hub.pob"
    out = {"seal": seal_pad(pob), "lod": iff.write_exterior_lod(EXPORT, pob)}
    # welded floor pieces leave open seam edges that stop the player mid-room (rail buildings:floor-seams)
    out["seams"] = {c["floor"]: iff.open_floor_seams(EXPORT / c["floor"])["seams"]
                    for c in iff.read_pob(pob)["cells"] if c.get("floor")}
    out["glass"] = glass_collision(out["lod"]["lod"])
    data = CLIENT.parent.parent.parent / "sys.shared/compiled/game"
    base = data / "object/building/player/shared_player_house_naboo_large_style_01.iff"
    r0_floor = iff.read_pob(pob)["cells"][0]["floor"]
    rect = iff.floor_bounds(EXPORT / r0_floor, pad=1.0)
    sfp = "footprint/building/titan/shared_nboo_otoh_hub.sfp"
    lay = "terrain/nboo_otoh_hub.lay"
    out["footprint"] = iff.write_footprint(EXPORT / sfp, rect)["size"]
    out["layer"] = iff.flatten_layer(CLIENT / iff.STOCK_FLATTEN_LAYER, EXPORT / lay, rect, 8.0)["path"]
    rel = "clientdata/client_shared_nboo_otoh_hub.cdf"
    out["cdf"] = cdf("nboo_otoh_hub", rel)
    out["template"] = iff.building_template(base, EXPORT / "object/building/titan/shared_nboo_otoh_hub.iff",
                                            "appearance/nboo_otoh_hub.pob",
                                            {"clientDataFile": rel, "structureFootprintFileName": sfp,
                                             "terrainModificationFileName": lay})["path"]
    return out


def finish_piece(piece, out):
    """Host side after a piece export: .lod (collision, radar, hardpoints), client data file, static template."""
    b = out["bounds"]
    lod = iff.write_static_lod(EXPORT, out["apt"], out["boxes"], out["composite"], out["footprint"],
                               floor=out.get("floor"), bounds=[b[:3], b[3:]], lods=out.get("lods"))
    rel = f"clientdata/client_shared_{out['name']}.cdf"
    fx = cdf(piece, rel)
    tpl = EXPORT / f"object/static/structure/naboo/shared_{out['name']}.iff"
    iff.derive_template(STATIC_BASE, tpl, {"appearanceFilename": out["apt"], "clientDataFile": rel})
    msh = iff.read_msh_summary(EXPORT / lod["mesh"])
    return {"piece": piece, "name": out["name"], "template": str(tpl.relative_to(EXPORT)).replace("\\", "/"),
            "collision": lod["collision"], "lods": lod.get("lods"), "floor": out.get("floor"), "hardpoints": _lod_hardpoints(EXPORT / lod["lod"]),
            "shaders": msh["shaders"], "effects": fx,
            "size": [round(b[3] - b[0], 2), round(b[4] - b[1], 2), round(b[5] - b[2], 2)]}


async def maya(s, code, args, timeout=900):
    res = await s.call_tool("maya_python", {"code": "args = " + json.dumps(args) + "\n" + SETUP + code, "timeout_seconds": timeout})
    data = json.loads(text(res))
    if not data.get("ok"):
        raise RuntimeError(f"{data.get('error')}\n{(data.get('traceback') or '')[-1500:]}")
    return data.get("result")


async def render(s, path, **kw):
    img = await s.call_tool("maya_render", kw)
    for c in img.content:
        if getattr(c, "data", None):
            path.write_bytes(base64.b64decode(c.data))


async def build_hub(s, shaders):
    ck = RENDERS / "otoh_hub_{}.mb"
    steps = [("og.hub_build()", "1_built"), ("og.hub_interior('|nboo_otoh_hub')", "2_interior"),
             ("og.hub_exterior('|nboo_otoh_hub')", "3_exterior")]
    for code, tag in steps:         # one Maya call per step, a checkpoint after each (long calls crash Maya)
        out = await maya(s, f"result = {code}\ncmds.file(rename=args['ck'])\ncmds.file(save=True, type='mayaBinary')",
                         {"shaders": shaders, "ck": str(ck).format(tag).replace("\\", "/")})
        print(tag, json.dumps(out)[:300])
    await maya(s, "result = og.hub_export('|nboo_otoh_hub', args['root'])", {"shaders": shaders, "root": str(EXPORT).replace("\\", "/")}, 1800)
    finish_hub()
    await maya(s, "og.look() if hasattr(og, 'look') else None\nresult = True", {"shaders": shaders})
    await render(s, RENDERS / "otoh_hub.png", width=1300, height=700, azimuth=25, elevation=18)
    res = await s.call_tool("swg_check", {"path": str(EXPORT / "appearance/nboo_otoh_hub.pob"), "export_root": str(EXPORT)})
    print("swg_check", text(res)[:1500])


async def build_pieces(s, shaders):
    made = []
    for piece in PIECES:
        out = await maya(s, "result = og.build(args['piece'], args['root'])",
                         {"shaders": shaders, "piece": piece, "root": str(EXPORT).replace("\\", "/")}, 600)
        row = finish_piece(piece, out)
        if out.get("floor"):
            iff.open_floor_seams(EXPORT / out["floor"])
            res = await s.call_tool("swg_check", {"path": str(EXPORT / out["floor"]), "export_root": str(EXPORT)})
            row["floor_check"] = json.loads(text(res)).get("ok")
        made.append(row)
        print(f"{out['name']:28s} {row['collision']:9s} size {row['size']} hardpoints {row['hardpoints']}")
    await maya(s, "result = og.preview()", {"shaders": shaders})
    await render(s, RENDERS / "otoh_pieces.png", width=1600, height=500, azimuth=15, elevation=12)
    (RENDERS / "otoh_pieces.json").write_text(json.dumps(made, indent=1))
    return made


def _lod_hardpoints(lod_path):
    root = iff.parse_iff(Path(lod_path).read_bytes())
    appr = root.first("DTLA").forms()[0].first("APPR").forms()[0]
    hpts = appr.first("HPTS")
    out = []
    for hp in (hpts.chunks("HPNT") if hpts is not None else []):
        r = iff.Reader(hp.data)
        r.transform()
        out.append(r.string())
    return out


async def main(what):
    RENDERS.mkdir(parents=True, exist_ok=True)
    made = otoh_materials.write_all(EXPORT, RENDERS / "otoh_textures.png")
    shaders = {slot: made[f"nboo_otoh_{n}"] for slot, n in (
        ("skin", "glass_skin"), ("veil", "glow_veil"), ("shell", "glow_shell"), ("core", "glow_core"), ("blue", "glow_blue"),
        ("rib", "rib"), ("wall_in", "wall_in"), ("mosaic", "floor_mosaic"))}
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {"export_root": str(EXPORT)})
            if "hub" in what:
                await build_hub(s, shaders)
            if "pieces" in what:
                await build_pieces(s, shaders)
    print("renders in", RENDERS)


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1:] or ["hub", "pieces"]))
