"""adventure_heroic: the Historical heroics scene, built like the stock adventure2 (Hoth) instance scene - a 16 km
map holding a 3 x 3 grid of 3.8 km tiles, 5 km apart, one tile per instance - with the terrain package (the
library behind the trn_* MCP tools) from stock Naboo assets.

    .venv\\Scripts\\python.exe examples\\make_adventure_heroic.py [out.trn] [--register]
                                                         (default D:/exported/terrain/adventure_heroic.trn)

--register also adds the scene to the server, client and god client data (terrain/planet.py: data/, dsrc/,
exe/linux/localOptions.cfg, SwgGodClient's buildout editor list). Take D:/titan/.locks/tables first.

Tiles (centres; instance-local coordinates are relative to them):
    01 (-5000, 5000)   02 (0, 5000)   03 (5000, 5000)
    04 (-5000, 0)      05 (0, 0)      06 (5000, 0)
    07 (-5000,-5000)   08 (0,-5000)   09 (5000,-5000)
Tile 05 is the Battle of Naboo (the Great Grass Plains); the others are reserved for later Historical heroics and
are left as the mountain backdrop that also fills the gaps between tiles.

The Great Grass Plains (tile 05), after the reference frame: a broad, gently rolling meadow of long green grass
between low hills, the Gungan army coming up out of the swamp in the west, the droid army over the eastern rise.
    swamp        x -1900..-1150   wet ground, pools under a local water table, swamp trees, reeds, frogs
    battle       x -150..+220     the compact battlefield: Gungan camp, shield dome, line and MTT pads
                                  (positions in examples/naboo_battle_layout.py; the dome pad is flat so its rim meets the ground)
    plain        x -900..+900     long green grass, no trees or rocks (the battle space)
    droid rise   x +1000..+1900   the slope the droid army crests (the MTTs glide down it)
    hills        |z| > 1250       a low ring of hills closing the view, sparse trees and rocks
"""

from __future__ import annotations

import json
import math
import random
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

from swg_maya_mcp.terrain import author, generator, trn  # noqa: E402
from swg_maya_mcp.terrain.tools import DATA_ROOTS  # noqa: E402

NAME = "adventure_heroic"
TILE_SIZE = 3800.0
TILES = {f"{i + 1:02d}": ((i % 3 - 1) * 5000.0, (1 - i // 3) * 5000.0) for i in range(9)}
NABOO_TILE = "05"

PLAIN_Y = 12.0          # the battle plain
SWAMP_Y = 8.5           # swamp ground (pools dip below the water table)
SWAMP_WATER_Y = 9.6
sys.path.insert(0, str(HERE / "examples"))
from naboo_battle_layout import CAMP as STAGING, DOME as SHIELD, MTT_PADS  # noqa: E402  (one layout for all)
# time of day locked for the scene (GroundEnvironment cycle fraction): late morning, the film's bright overcast
TIME_LOCK = 0.38


def naboo_families():
    """Stock Naboo families copied by name (same children, weights and sway)."""
    src = trn.TerrainDoc.load(next(Path(r) / "terrain/naboo.trn" for r in DATA_ROOTS
                                   if (Path(r) / "terrain/naboo.trn").exists()))
    return {g: {f["name"]: f for f in src.group(g)["families"]} for g in ("shader", "flora", "radial")}


def build() -> author.TerrainDoc:
    doc = author.new_terrain(f"terrain/{NAME}.trn", map_width=16384.0, chunk_width=8.0, tiles_per_chunk=2,
                             environment_cycle_time=10620.0, use_global_water_table=False,
                             collidable_max_distance=64.0, collidable_tile_size=12.0, collidable_tile_border=3.0,
                             non_collidable_max_distance=64.0, radial_max_distance=40.0, radial_tile_border=0.42,
                             far_radial_min_distance=105.0, far_radial_max_distance=700.0,
                             far_radial_tile_border=17.0, legacy_map=False)
    nb = naboo_families()

    def copy(group, name, **over):
        f = {k: v for k, v in nb[group][name].items() if k != "id"}
        f.update(over)
        return author.add_family(doc, group, f)["id"]

    # --- families
    grass = copy("shader", "nboo_grass_long_green")
    dry = copy("shader", "grss_dry_transgreen")
    mud = copy("shader", "mud_damp_dark")
    mud_y = copy("shader", "swmp_dirt_yellow")
    moss = copy("shader", "frst_ever_mossydirt")
    rock = copy("shader", "rock_GalloMtnsDark")
    leaf = copy("shader", "jung_ptch_grass")

    meadow = copy("radial", "Grasslandsgrass1", density=0.85)
    poppies = copy("radial", "Poppies", density=0.06)
    reeds = copy("radial", "radl_swmp_reeds")
    lake_tails = copy("radial", "radl_lake_tails")
    far_trees = copy("radial", "low_forest_far")
    swamp_far = copy("radial", "swamp_farRadial")

    swamp_trees = copy("flora", "SwampWaterTrees")
    knees = copy("flora", "SwampTreeKnees")
    cattails = copy("flora", "cattails")
    lily = copy("flora", "lilypads")
    frogs = copy("flora", "frogs")
    insects = copy("flora", "buzzing insects")
    butterflies = copy("flora", "butterflies")
    hill_trees = copy("flora", "TheedTrees", density=0.08)
    shrubs = copy("flora", "Shrublick_Plains_Large", density=0.05)
    rocks = copy("flora", "Greya Rocks", density=0.04)

    env_plain = author.add_family(doc, "environment", {"name": "main_base"})["id"]
    env_swamp = author.add_family(doc, "environment", {"name": "swamp_trans"})["id"]

    frac = {}
    for name, f in [("backdrop", dict(seed=1999, octaves=5, frequency=2.0, amplitude=0.5, scale_x=0.0007,
                                      scale_y=0.0007)),
                    ("roll", dict(seed=2001, octaves=3, frequency=2.0, amplitude=0.5, scale_x=0.0045,
                                  scale_y=0.0045)),
                    ("ripple", dict(seed=2002, octaves=3, frequency=2.2, amplitude=0.5, scale_x=0.02,
                                    scale_y=0.02)),
                    ("hills", dict(seed=2003, octaves=4, frequency=2.0, amplitude=0.5, scale_x=0.0018,
                                   scale_y=0.0018)),
                    ("swamp", dict(seed=2004, octaves=4, frequency=2.1, amplitude=0.5, scale_x=0.012,
                                   scale_y=0.012)),
                    ("patches", dict(seed=2005, octaves=3, frequency=2.0, amplitude=0.5, scale_x=0.008,
                                     scale_y=0.008))]:
        frac[name] = author.add_family(doc, "fractal", {"name": name, **f})["id"]

    # --- the map: mountain backdrop everywhere (fills the gaps between tiles and the reserved tiles)
    base = author.add_layer(doc, "", "backdrop")
    author.add_item(doc, base, "height_fractal", "mountains", {"family_id": frac["backdrop"], "operation": 0,
                                                              "scale_y": 150.0})
    author.add_item(doc, base, "height_fractal", "detail", {"family_id": frac["ripple"], "operation": 1,
                                                           "scale_y": 3.0})
    author.add_item(doc, base, "shader_constant", "grass", {"family_id": grass})
    author.add_item(doc, base, "environment", "main_base", {"family_id": env_plain})
    author.add_item(doc, base, "flora_dynamic_near", "meadow", {"family_id": meadow, "operation": 1})
    author.add_item(doc, base, "flora_dynamic_far", "far trees", {"family_id": far_trees, "operation": 1})
    author.add_item(doc, base, "flora_static_collidable", "hill trees", {"family_id": hill_trees, "operation": 1})
    author.add_item(doc, base, "flora_static_collidable", "rocks", {"family_id": rocks, "operation": 1})

    paint = author.add_layer(doc, "", "backdrop painting")
    steep = author.add_layer(doc, paint, "steep")
    author.add_item(doc, steep, "slope", "steep", {"min_angle": 32.0, "max_angle": 90.0, "feather_distance": 0.15})
    author.add_item(doc, steep, "shader_constant", "rock", {"family_id": rock})
    author.add_item(doc, steep, "flora_dynamic_near", "no grass", {"family_id": meadow, "remove_all": True})
    dryp = author.add_layer(doc, paint, "dry patches")
    author.add_item(doc, dryp, "fractal", "patches", {"family_id": frac["patches"], "low": 0.66, "high": 1.0,
                                                      "scale_y": 1.0, "feather_distance": 0.3})
    author.add_item(doc, dryp, "shader_constant", "dry grass", {"family_id": dry})

    naboo_tile(doc, TILES[NABOO_TILE], locals())
    return doc


def blob(cx, cz, rx, rz, seed, wobble=0.12, n=28):
    """An organic outline: an ellipse whose radius wanders by +-wobble (two low harmonics), as [[x, z], ...]."""
    rnd = random.Random(seed)
    k1, k2 = rnd.uniform(0, 2 * math.pi), rnd.uniform(0, 2 * math.pi)
    pts = []
    for i in range(n):
        a = 2 * math.pi * i / n
        w = 1.0 + wobble * (0.6 * math.sin(2 * a + k1) + 0.4 * math.sin(3 * a + k2))
        pts.append([round(cx + rx * w * math.cos(a), 2), round(cz + rz * w * math.sin(a), 2)])
    return pts


def naboo_tile(doc, c, f):
    """Tile 05, the Great Grass Plains. `f` holds the family ids from build()."""
    cx, cz = c
    half = TILE_SIZE / 2
    tile = author.add_layer(doc, "", f"Great_grass_plains_{NABOO_TILE}")

    def L(name, parent=tile):
        return author.add_layer(doc, parent, name)

    def poly(lp, name, pts, feather, **extra):
        author.add_item(doc, lp, "polygon", name, {"points": [[cx + x, cz + z] for x, z in pts],
                                                   "feather_function": 3, "feather_distance": feather, **extra})

    # the hills round the valley: the whole tile is lifted, so wherever the backdrop is low a ridge still closes
    # the view (the reference's soft blue hills); the valley below replaces it, feathered over 700 m
    rim = L("Hills")
    poly(rim, "tile", blob(0.0, 0.0, half - 250.0, half - 250.0, 3, 0.06, 36), 450.0)
    author.add_item(doc, rim, "height_fractal", "hills", {"family_id": f["frac"]["hills"], "operation": 1,
                                                         "scale_y": 70.0})
    author.add_item(doc, rim, "height_constant", "lift", {"operation": 1, "height": 20.0})

    ground = L("GroundHeight")
    poly(ground, "valley", blob(-200.0, 0.0, 2050.0, 1550.0, 7, 0.08), 600.0)
    author.add_item(doc, ground, "height_constant", "valley floor", {"operation": 0, "height": PLAIN_Y})
    author.add_item(doc, ground, "height_fractal", "rolling", {"family_id": f["frac"]["roll"], "operation": 1,
                                                              "scale_y": 5.0})
    author.add_item(doc, ground, "height_fractal", "ripple", {"family_id": f["frac"]["ripple"], "operation": 1,
                                                             "scale_y": 0.8})
    for fam in ("hill_trees", "rocks"):
        author.add_item(doc, ground, "flora_static_collidable", f"no {fam}", {"family_id": f[fam], "remove_all": True})
    author.add_item(doc, ground, "flora_dynamic_far", "no far trees", {"family_id": f["far_trees"],
                                                                       "remove_all": True})

    # the eastern rise the droid army comes over
    rise = L("droid rise")
    poly(rise, "droid rise", blob(1500.0, 0.0, 700.0, 1200.0, 11, 0.15), 450.0)
    author.add_item(doc, rise, "height_constant", "rise", {"operation": 1, "height": 26.0})
    author.add_item(doc, rise, "height_fractal", "rise hills", {"family_id": f["frac"]["hills"], "operation": 1,
                                                               "scale_y": 30.0})
    author.add_item(doc, rise, "flora_static_collidable", "rocks", {"family_id": f["rocks"], "operation": 1})

    # the swamp the Grand Army comes out of: low wet ground under a local water table, pools and islands
    swamp = L("Swamp")
    poly(swamp, "swamp", blob(-1450.0, 0.0, 480.0, 1150.0, 5, 0.14), 200.0, local_water_table=True,
         water_height=SWAMP_WATER_Y, water_shader_size=8.0, water_shader="wter_agrlt_swamp")
    author.add_item(doc, swamp, "height_constant", "swamp floor", {"operation": 0, "height": SWAMP_Y})
    author.add_item(doc, swamp, "height_fractal", "hummocks", {"family_id": f["frac"]["swamp"], "operation": 1,
                                                              "scale_y": 3.4})
    author.add_item(doc, swamp, "shader_constant", "mud", {"family_id": f["mud"]})
    author.add_item(doc, swamp, "environment", "swamp", {"family_id": f["env_swamp"]})
    author.add_item(doc, swamp, "flora_dynamic_near", "no meadow", {"family_id": f["meadow"], "remove_all": True})
    for t, fam in (("flora_static_collidable", "swamp_trees"), ("flora_static_collidable", "knees"),
                   ("flora_static_non_collidable", "cattails"), ("flora_static_non_collidable", "lily"),
                   ("flora_static_non_collidable", "frogs"), ("flora_static_non_collidable", "insects"),
                   ("flora_dynamic_near", "reeds"), ("flora_dynamic_far", "swamp_far")):
        author.add_item(doc, swamp, t, fam, {"family_id": f[fam], "operation": 1})
    edge = L("swamp edge")
    poly(edge, "treeline", blob(-1000.0, 0.0, 200.0, 1000.0, 9, 0.2), 140.0)
    author.add_item(doc, edge, "shader_constant", "moss", {"family_id": f["moss"]})
    author.add_item(doc, edge, "flora_static_collidable", "edge trees", {"family_id": f["swamp_trees"],
                                                                        "operation": 1, "density_override": True,
                                                                        "density_override_density": 0.06})
    author.add_item(doc, edge, "flora_dynamic_near", "lake tails", {"family_id": f["lake_tails"], "operation": 1})

    # the battle plain: long green grass, a scatter of poppies and butterflies, nothing to stand behind
    plain = L("Battle plain")
    poly(plain, "plain", blob(0.0, 0.0, 950.0, 900.0, 13, 0.08), 120.0)
    author.add_item(doc, plain, "shader_constant", "long grass", {"family_id": f["grass"]})
    author.add_item(doc, plain, "flora_dynamic_near", "poppies", {"family_id": f["poppies"], "operation": 1})
    author.add_item(doc, plain, "flora_static_non_collidable", "butterflies", {"family_id": f["butterflies"],
                                                                               "operation": 1})
    for fam in ("hill_trees", "rocks", "shrubs", "swamp_trees"):
        author.add_item(doc, plain, "flora_static_collidable", f"no {fam}", {"family_id": f[fam], "remove_all": True})
    worn = L("worn grass", plain)
    author.add_item(doc, worn, "fractal", "trampled", {"family_id": f["frac"]["patches"], "low": 0.72, "high": 1.0,
                                                       "scale_y": 1.0, "feather_distance": 0.35})
    author.add_item(doc, worn, "shader_constant", "trampled", {"family_id": f["leaf"]})

    # level pads: the staging hummock, the shield dome (its rim must meet the ground) and the MTT landings
    pads = L("Pads")
    # the Gungan camp sits inside the dome, on the shield pad; a trampled moss patch marks it
    author.add_flatten(doc, {"circle": [cx + STAGING[0], cz + STAGING[1], 20.0]}, height=PLAIN_Y,
                       feather=12.0, parent=pads, name="gungan camp", shader_family=f["moss"])
    sx, sz, sr = SHIELD
    author.add_flatten(doc, {"circle": [cx + sx, cz + sz, sr + 12.0]}, height=PLAIN_Y, feather=60.0, parent=pads,
                       name="shield pad", shader_family=f["grass"], clear_flora=False)
    for i, (x, z) in enumerate(MTT_PADS):
        author.add_flatten(doc, {"circle": [cx + x, cz + z, 26.0]}, height=PLAIN_Y + 0.6, feather=30.0, parent=pads,
                           name=f"mtt pad {i + 1}", shader_family=f["leaf"], clear_flora=False)


def write_environment(game_root: Path) -> list[str]:
    """Client sky / lighting for terrain/adventure_heroic.trn: Naboo's sky and its environment table (rows for
    the families main_base and swamp_trans), with the time of day locked."""
    from swg_maya_mcp.terrain import env
    sky, table = env.copy_from("naboo", DATA_ROOTS)
    env.set_envm(sky, "time_lock", {"locked": 1, "time": TIME_LOCK})
    return env.save(NAME, sky, table, game_root)


def regions() -> list[dict]:
    """Named regions for the server's region table (datatables/region/region_adventure_heroic)."""
    cx, cz = TILES[NABOO_TILE]
    return [{"name": "Great Grass Plains", "x": cx, "z": cz, "radius": 1850.0, "geographical": "plains",
             "buildable": 0}]


def main(out: str, register: bool = False) -> None:
    t0 = time.time()
    doc = build()
    hd = generator.bake_height_data(doc, data_roots=DATA_ROOTS)
    print("height data:", [(r["name"], r["points"]) for r in hd])
    v = author.validate(doc)
    print("validation:", json.dumps(v, indent=1))
    print(doc.save(out), f"{time.time() - t0:.1f} s")
    print("environment:", write_environment(Path(out).resolve().parent.parent))
    cx, cz = TILES[NABOO_TILE]
    probe = [[cx + x, cz + z] for x, z in ((0, 0), STAGING, SHIELD[:2], *MTT_PADS, (-1500, 0), (1500, 0), (0, 1500))]
    print("heights:", [round(h, 2) for h in generator.heights_at(doc, probe)])
    if register:
        from swg_maya_mcp.terrain import env, planet
        sky, table, _ = env.load(NAME, [str(Path(out).resolve().parent.parent)])
        res = planet.register("D:/titan", NAME, out, "Historical Heroics", regions=regions(), environment=(sky, table),
                              data_roots=DATA_ROOTS)
        print(json.dumps(res, indent=1))


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--register"]
    main(args[0] if args else f"D:/exported/terrain/{NAME}.trn", "--register" in sys.argv)
