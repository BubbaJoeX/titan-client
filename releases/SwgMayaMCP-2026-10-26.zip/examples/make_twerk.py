"""Author a looping twerk emote on the stock human body (all_b skeleton) and export it with SwgAns.

10 s loop at 30 fps (300 frames): a deep braced squat with a 3 Hz pelvic rock (the root pitches while thighs and
spine1 counter-rotate, so feet and chest stay planted) and a small bounce. Every 5 s a flourish: at 4-5 s a
hair-flip head roll with an overhead hand sweep, at 9-10 s a look back over the shoulder, a hand slap at the hip
and a deeper double bounce. Every curve returns to the base cycle at frame 300, so the loop is seamless.

Axis conventions on all_b (measured, +30 deg from bind, character faces +Z): thigh -X = hip flexion, shin +X =
knee bend, spine/root +X = lean forward, Head X = nod / Y = turn / Z = tilt, arm +Y = raise forward, arm -Z =
raise sideways (arm (0, 0, -150) = overhead), forearm -Y = elbow bend.

Run: python examples/make_twerk.py [out.ans]   (default <export root>/appearance/animation/titan_emt_twerk.ans)"""
import asyncio
import json
import os
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"), "appearance/animation/titan_emt_twerk.ans").replace("\\", "/")

CODE = r'''
import maya.cmds as cmds, maya.mel as mel, math, os
data = os.environ.get('TITAN_DATA_ROOT', 'D:/titan/data/sku.0/sys.client/compiled/game').replace(chr(92), '/')
cmds.file(new=True, force=True)
cmds.currentUnit(time='ntsc')
mel.eval('importSat -i "%s/appearance/hum_m.sat"' % data)
END = 300                    # 10 s loop
BEAT = 10.0                  # frames per rock (3 Hz)
TAU = 2.0 * math.pi

def joint(name):
    return [j for j in cmds.ls(type='joint', long=True) if j.split('|')[-1] == name][0]

def smooth(a, b, f):
    t = min(1.0, max(0.0, (f - a) / float(b - a)))
    return t * t * (3.0 - 2.0 * t)

def window(a, b, f, ramp=6):           # 0 -> 1 -> 0 over [a, b] with eased edges
    return smooth(a, a + ramp, f) * (1.0 - smooth(b - ramp, b, f))

def pose(f):
    """Degrees offsets from bind per joint, and the root's height offset (metres)."""
    rock = math.sin(TAU * f / BEAT)                     # pelvic rock
    bounce = 0.5 - 0.5 * math.cos(TAU * f / BEAT)       # 0..1 up-down, in phase with the rock
    sway = math.sin(TAU * f / (BEAT * 4))               # slow side-to-side
    fa = window(120, 150, f)                            # flourish A: 4-5 s
    fb = window(270, 300, f)                            # flourish B: 9-10 s
    flip = math.sin(math.pi * min(1.0, max(0.0, (f - 122) / 26.0)))           # 0 -> 1 -> 0 inside A
    dbl = math.sin(TAU * max(0.0, f - 274) / 12.0) ** 2 if 274 <= f <= 298 else 0.0   # double bounce inside B
    tilt = 14.0 * rock * (1.0 - 0.6 * fa)               # rocking eases off during the hair flip
    o = {}
    o['root__all_b_l0'] = (tilt, 4.0 * sway, 3.0 * sway)
    o['spine1'] = (44.0 - tilt + 6.0 * fb, 0.0, 0.0)
    o['spine2'] = (8.0 - 14.0 * fa, 22.0 * fb + 10.0 * fa * flip, 0.0)
    o['spine3'] = (4.0 - 8.0 * fa, 10.0 * fb, 0.0)
    o['neck'] = (-12.0 + 10.0 * fa, 12.0 * fb, 0.0)
    o['Head'] = (-22.0 + 30.0 * fa * flip, 40.0 * fb, 26.0 * fa * math.sin(math.pi * 2 * flip))
    for side, s in (('l', 1.0), ('r', -1.0)):
        o[side + 'Thigh'] = (-58.0 - tilt - 10.0 * fb * dbl, 0.0, s * 14.0)
        o[side + 'Shin'] = (72.0 + 14.0 * fb * dbl, 0.0, 0.0)
        o[side + 'Ankle'] = (-16.0 - 4.0 * fb * dbl, 0.0, 0.0)
        # hands braced on the knees
        o[side + 'Arm'] = (0.0, 48.0, s * 6.0)
        o[side + 'ForeArm'] = (0.0, -18.0, 0.0)
        o[side + 'Wrist'] = (0.0, 0.0, 0.0)
    # flourish A: right hand sweeps up overhead and back down to the knee
    k = fa * flip
    o['rArm'] = (0.0, 48.0 * (1.0 - k), -6.0 - 144.0 * k)       # (0, 0, -150) from bind = straight overhead
    o['rForeArm'] = (0.0, -18.0 + 8.0 * k, 0.0)
    o['rWrist'] = (0.0, 0.0, 30.0 * fa * flip)
    # flourish B: left hand comes off the knee to slap the hip on the double bounce
    slap = fb * (0.5 + 0.5 * math.cos(TAU * max(0.0, f - 274) / 12.0)) if 270 <= f <= 300 else 0.0
    o['lArm'] = (0.0, 48.0 - 70.0 * slap, 6.0 + 10.0 * slap)
    o['lForeArm'] = (0.0, -18.0 - 50.0 * slap, 0.0)
    drop = -0.20 + 0.035 * bounce - 0.05 * fb * dbl + 0.08 * fa * flip
    return o, drop

binds = {}
for name in pose(0)[0]:
    j = joint(name)
    binds[name] = (j, [math.degrees(v) for v in cmds.getAttr(j + '.swgBindRotate')[0]])
root = joint('root__all_b_l0')
ty0 = cmds.getAttr(root + '.swgBindTranslate')[0][1]
for f in range(END + 1):
    o, drop = pose(f)
    for name, (j, b) in binds.items():
        for axis, base, d in zip('XYZ', b, o[name]):
            cmds.setKeyframe(j, attribute='rotate' + axis, time=f, value=base + d)
    cmds.setKeyframe(root, attribute='translateY', time=f, value=ty0 + drop)
cmds.keyTangent(cmds.ls(type='joint'), inTangentType='linear', outTangentType='linear')
cmds.playbackOptions(minTime=0, maxTime=END, animationStartTime=0, animationEndTime=END)

out = args['out']
os.makedirs(os.path.dirname(out), exist_ok=True)
cmds.select(cmds.ls(type='joint'), r=True)
cmds.file(out, force=True, exportSelected=True, type='SwgAns', options=args.get('options', ''))
result = {'out': out, 'bytes': os.path.getsize(out)}
'''


async def main():
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            run_args = {"out": OUT, "options": os.environ.get("ANS_EXPORT_OPTIONS", "")}
            res = await s.call_tool("maya_python", {"code": "args = " + json.dumps(run_args) + "\n" + CODE})
            text = "\n".join(getattr(c, "text", "") for c in res.content)
            data = json.loads(text)
            if not data.get("ok"):
                print(text[-3000:])
                return
            print(data["result"])
            notes = [l for l in str(data.get("stderr", "")).splitlines() if l.startswith("ANS: export") or "WARN" in l or "channels" in l]
            print("\n".join(dict.fromkeys(notes)))


asyncio.run(main())
