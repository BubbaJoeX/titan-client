"""Paintable hulls for the Titan boardable vessels: the stock hull shaders turned into two-zone hue shaders, the way
the stock JTL ship paint jobs are built (awing_engine_s01_pattern01_a_tx_swap_hcse25, ab1_body_hcsc22):

  effect    the stock effect's hue twin: a_specmap_cbmp -> h_color2w_specmap_cbmp, a_specmap_bump ->
            h_color2w_specmap_bump, a_specmap_cbmp_emismap_bloom -> h_color2w_specmap_cbmp_emismap_bloom
  MAIN      the original colours with alpha = zone 1 mask (the light hull plating)  <- /private/index_color_1
  HUEB      the same colours with alpha = zone 2 mask (stripes / accent panels)     <- /private/index_color_2
  SPEC      the original MAIN alpha (the stock specular mask), now that MAIN alpha carries the zone mask
  palette   palette/titan_ship_paint.pal (64 colours, entry 0 white): the colour is multiplied in where a zone's
            mask is set, so index 0 keeps the stock look; zone 2 pixels that are saturated (the corvette's red
            bands) are divided by their default palette colour, so that default reproduces them too.

Every other texture (normal maps, emissive window maps) and the material block are kept from the stock shader.
The template's paletteColorCustomizationVariables use the same palette and defaults (make_titan_vessels.py), the
owner's radial Paint -> Hull / Trim opens the colour picker (space.vessel.vessel_controller).

Run on its own (python examples/vessel_paint.py lambda|corvette|nebulon) or through make_titan_vessels.py, which
calls paint() before the Maya build: the hue .sht files must exist when Maya assigns them."""
from __future__ import annotations

import copy
import json
import os
import struct
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import customization as cz  # noqa: E402
from swg_maya_mcp import iff  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
CLIENT = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
PALETTE = "palette/titan_ship_paint.pal"

HUE_EFFECT = {
    "effect\\a_specmap_cbmp.eft": "effect\\h_color2w_specmap_cbmp.eft",
    "effect\\a_specmap_bump.eft": "effect\\h_color2w_specmap_bump.eft",
    "effect\\a_specmap_cbmp_emismap_bloom.eft": "effect\\h_color2w_specmap_cbmp_emismap_bloom.eft",
    "effect\\a_specmap.eft": "effect\\h_color2w_specmap.eft",
    # no hue twin keeps the detail map: the hull loses its close-up detail texture (DETA), nothing else
    "effect\\a_specmap_cbmp_detail.eft": "effect\\h_color2w_specmap_cbmp.eft",
}
DROP_TEXTURES = {"effect\\a_specmap_cbmp_detail.eft": ("DETA",)}

# stock hull shader -> (hue shader name, zone-2 rule). "accent": saturated pixels (painted bands); "panels": the darker
# grey plating between the light panels (all-grey hulls have no saturated paint)
SHIPS = {
    "lambda": [("spc_lambda_shuttle_asc14", "titan_lambda_hull", "panels"),
               ("lambda_wing_asb14", "titan_lambda_wing", "panels"),
               ("lambda_ventral_asb14", "titan_lambda_ventral", "panels")],
    "corvette": [("corellian_corvette_main_simple_ascd21", "titan_corvette_hull", "accent"),
                 ("corellian_corvette_engines_simple_ascd21", "titan_corvette_engines", "accent"),
                 ("corellian_corvette_engines_simple_ascd21_b", "titan_corvette_engines_b", "accent")],
    "nebulon": [("nebulon_1_asceb28", "titan_nebulon_hull1", "panels"),
                ("nebulon_2_asceb28", "titan_nebulon_hull2", "panels")],
}


def paint_palette():
    """64 colours: entry 0 white (no tint), greys, then eight hues in six shades each, two metallics and six
    classic finishes (rebel cream, desert sand, olive drab, teal, crimson, deep-space navy)."""
    cols = [(255, 255, 255)]
    cols += [(v, v, v) for v in (224, 192, 160, 128, 96, 64, 40)]
    hues = [(200, 40, 35), (215, 110, 30), (220, 190, 50), (70, 150, 60), (40, 120, 140), (45, 80, 170),
            (110, 60, 150), (120, 85, 55)]
    for r, g, b in hues:
        for k in (1.15, 1.0, 0.82, 0.64, 0.48, 0.34):
            cols.append(tuple(max(0, min(255, round(c * k + (255 - c) * max(0.0, k - 1.0) * 2))) for c in (r, g, b)))
    cols += [(201, 168, 92), (150, 155, 165)]
    cols += [(232, 222, 196), (196, 170, 120), (110, 115, 70), (30, 140, 130), (150, 20, 40), (28, 34, 52)]
    return cols[:64]


def write_palette():
    out = EXPORT / PALETTE
    out.parent.mkdir(parents=True, exist_ok=True)
    cols = paint_palette()
    out.write_bytes(cz.write_pal([(r, g, b, 0) for r, g, b in cols]))
    return out, cols


def _smooth(x, a, b):
    t = np.clip((x - a) / (b - a), 0.0, 1.0)
    return t * t * (3 - 2 * t)


def zone_masks(rgb, rule):
    """(zone 1, zone 2) masks in 0..1 for an (n, 3) float array."""
    lum = rgb @ np.array([0.299, 0.587, 0.114])
    chroma = rgb.max(1) - rgb.min(1)
    light = np.percentile(lum, 85)
    grey = 1.0 - _smooth(chroma, 22, 40)
    z1 = grey * _smooth(lum, 0.45 * light, 0.55 * light)
    if rule == "accent":
        z2 = _smooth(chroma, 30, 48) * _smooth(lum, 25, 45)
    else:
        z2 = grey * _smooth(lum, 0.20 * light, 0.27 * light) * (1.0 - _smooth(lum, 0.45 * light, 0.55 * light))
    return z1, z2


def _ssht(rel):
    root = iff.parse_iff((CLIENT / rel).read_bytes())
    return root.children[0]


def hue_shader(stock, name, rule, cols, force2=None):
    """Hue textures + CSHD shader for one stock shader; returns its record (paths, zone-2 default). force2: the
    zone-2 default palette index to divide accents by (one default per variable for the whole ship)."""
    ssht = _ssht(f"shader/{stock}.sht")
    if ssht.tag != "SSHT":
        raise ValueError(f"{stock}: FORM {ssht.tag}")
    ver = ssht.forms()[0]
    effect = ver.first("NAME").data.rstrip(b"\0").decode()
    if effect not in HUE_EFFECT:
        raise ValueError(f"{stock}: no hue twin for {effect}")
    txms = ver.forms("TXMS")[0]
    txm = {t.forms()[0].first("DATA").data[:4][::-1].decode(): t for t in txms.forms("TXM ")}
    main_rel = txm["MAIN"].forms()[0].first("NAME").data.rstrip(b"\0").decode().replace("\\", "/")
    w, h, rgba = iff.read_dds_rgba(CLIENT / main_rel)
    px = np.frombuffer(bytes(rgba), np.uint8).reshape(-1, 4).astype(np.float32)
    rgb, spec = px[:, :3], px[:, 3]
    z1, z2 = zone_masks(rgb, rule)
    # zone 2 default: the palette colour nearest the accent pixels' mean (white for grey plating)
    default2 = 0
    if rule == "accent" and z2.sum() > 0.002 * len(z2):
        mean = (rgb * z2[:, None]).sum(0) / z2.sum()
        unit = mean / max(mean.max(), 1.0)
        default2 = force2 if force2 is not None else min(
            range(8, len(cols)), key=lambda i: float(((np.array(cols[i]) / max(cols[i]) - unit) ** 2).sum()))
        c2 = np.array(cols[default2], np.float32)
        tinted = np.clip(rgb * 255.0 / np.maximum(c2, 1.0), 0, 255)
        rgb = rgb * (1 - z2[:, None]) + tinted * z2[:, None]
    base = np.clip(rgb, 0, 255)
    tex = {}
    for tag, mask in (("MAIN", z1), ("HUEB", z2)):
        out = np.concatenate([base, (mask * 255)[:, None]], 1).round().astype(np.uint8)
        rel = f"texture/{name}_{'hue' if tag == 'MAIN' else 'hue2'}.dds"
        iff.write_dds_rgba(EXPORT / rel, w, h, out.tobytes())
        tex[tag] = rel
    spec_rel = f"texture/{name}_spec.dds"
    iff.write_dds_rgba(EXPORT / spec_rel, w, h, np.repeat(spec[:, None], 4, 1).round().astype(np.uint8).tobytes())
    tex["SPEC"] = spec_rel
    # the stock SSHT with the hue effect, MAIN swapped, HUEB / SPEC added (MAIN's sampler settings) and the factors
    new = copy.deepcopy(ssht)
    nver = new.forms()[0]
    nver.first("NAME").data = HUE_EFFECT[effect].encode() + b"\0"
    ntx = nver.forms("TXMS")[0]
    by_tag = {t.forms()[0].first("DATA").data[:4][::-1].decode(): t for t in ntx.forms("TXM ")}
    by_tag["MAIN"].forms()[0].first("NAME").data = tex["MAIN"].encode() + b"\0"
    for tag in DROP_TEXTURES.get(effect, ()):
        by_tag.pop(tag, None)
    if DROP_TEXTURES.get(effect):
        # the detail map had its own coordinate set (DETA 1, DOT3 2); without it the tangents are set 1, as the
        # re-exported mesh writes them
        tcss = nver.forms("TCSS")[0]
        tcss.children[0].data = b"3TOD\x01NIAM\x00LMRN\x00"
    for tag in ("HUEB", "SPEC"):
        t = copy.deepcopy(by_tag["MAIN"])
        d = t.forms()[0].first("DATA")
        d.data = tag.encode()[::-1] + d.data[4:]
        t.forms()[0].first("NAME").data = tex[tag].encode() + b"\0"
        by_tag[tag] = t
    ntx.children = [by_tag[k] for k in sorted(by_tag)]
    sht = f"shader/{name}_hue.sht"
    iff.write_custom_shader(EXPORT / sht, new, pals=[("index_color_1", "MAIN", PALETTE, 0),
                                                     ("index_color_2", "HUEB", PALETTE, default2)],
                            tfactors={"HUEB": 0xFFFFFFFF, "MAIN": 0xFFFFFFFF})
    return {"stock": f"shader/{stock}.sht", "shader": sht, "effect": HUE_EFFECT[effect], "textures": tex,
            "default2": default2, "zone1": round(float(z1.mean()), 3), "zone2": round(float(z2.mean()), 3)}


def paint(ship, shaders=None):
    """Palette + hue shaders for a ship; writes D:/exported/build/<ship>_paint.json (read by the Maya build)."""
    _, cols = write_palette()
    shaders = shaders or SHIPS[ship]
    made = [hue_shader(*shaders[0], cols)]
    # one default per variable: zone 2 takes the first shader's accent colour, the others are divided by it too
    default2 = made[0]["default2"]
    made += [hue_shader(s, n, r, cols, force2=default2 if default2 else None) for s, n, r in shaders[1:]]
    rec = {"palette": PALETTE, "defaults": {"/private/index_color_1": 0, "/private/index_color_2": default2},
           "shaders": made, "swap": {m["stock"]: m["shader"] for m in made}}
    out = EXPORT / f"build/titan_{ship}_paint.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rec, indent=1))
    return rec


if __name__ == "__main__":
    print(json.dumps(paint(sys.argv[1]), indent=1))
