"""Race shots (examples/make_races.py) in the offline client through the DevBridge.

  race_shots.py <tag> <out dir> [species_sex ...]       e.g. race_shots.py before D:/.../shots human_male human_female
  race_shots.py proto <out dir> human_female            one lineup, no sliders

Per race: a lineup 6 m ahead of the (hidden-behind) player - front, side, back - a wide shot and a face close-up
(narrow FOV, framed by measuring the head top against the magenta sky); CLOSE_ONLY=1 stops there; for 'after' also a slider row (chest/glutes/bulge at max, the stock sliders at their ends) and
a wearable on the player.
"""
import ctypes
import json
import os
import re
import shutil
import sys
import time
from ctypes import wintypes
from pathlib import Path

# a private LOCALAPPDATA keeps this client's bridge token away from other sessions' default token file
PRIVATE = Path(os.environ.get("RACES_LOCALAPPDATA", os.path.join(os.environ.get("TEMP", "."), "swg_race_shots")))
PRIVATE.mkdir(parents=True, exist_ok=True)
os.environ["LOCALAPPDATA"] = str(PRIVATE)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import client  # noqa: E402

u = ctypes.windll.user32
PORT = int(os.environ.get("RACES_PORT", "7061"))
try:
    b = client.ClientBridge(PORT)
    b.request("ping", timeout=5)
except Exception:
    print(client.launch(PORT, extra_args=["-s", "ClientGraphics", "windowed=1", "-s", "Direct3d9", "antiAlias=0", "screenShotBackBuffer=1"]), flush=True)
    b = client.ClientBridge(PORT)
tag, out = sys.argv[1], Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)
races = sys.argv[3:] or [f"{s}_{x}" for s in ["human", "twilek", "zabrak", "bothan", "rodian", "trandoshan", "moncal",
                                             "wookiee", "sullustan", "ithorian"] for x in ("male", "female")]


def client_hwnd():
    pid = json.loads(client.pinned_token_file(PORT).read_text())["pid"]
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(h, _):
        p = wintypes.DWORD()
        u.GetWindowThreadProcessId(h, ctypes.byref(p))
        if p.value == pid and u.IsWindowVisible(h):
            found.append(h)
        return True
    u.EnumWindows(cb, 0)
    return found[0] if found else None


def ex(line):
    r = b.request("exec", line=line)
    return r.get("result") or ""


def settle(frames=30):
    f0 = b.request("state")["result"]["frame"]
    t = time.time()
    while b.request("state")["result"]["frame"] < f0 + frames and time.time() - t < 30:
        time.sleep(0.2)


def shot(name):
    from PIL import Image
    for attempt in range(6):
        # the engine screenshot reads the front buffer (the desktop under the window): restore the window and keep
        # it on top of other sessions' clients while capturing, without taking focus
        h = client_hwnd()
        if h:
            if u.IsIconic(h):
                u.ShowWindow(h, 4)                   # SW_SHOWNOACTIVATE
            u.SetWindowPos(h, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010 | 0x0040)   # TOPMOST, no move/size/activate
            settle(20)
        r = b.request("screenshot", path=str(out / f"_{name}").replace("\\", "/"))
        if h:
            u.SetWindowPos(h, -2, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010)            # NOTOPMOST
        f = Path(r["result"]["file"])
        if not f.exists():
            settle(10)
            continue
        img = Image.open(f).convert("RGB")
        if max(img.getextrema(), key=lambda e: e[1])[1] > 10:
            dst = out / f"{name}.jpg"
            img.save(dst, quality=90)
            f.unlink()
            return dst
        f.unlink()
        settle(10)
    raise RuntimeError(f"{name}: black frames")


SLIDERS_AFTER = {
    "female": [("/shared_owner/blend_chest_large", 255), ("/shared_owner/blend_glutes", 255)],
    "male": [("/shared_owner/blend_bulge", 255), ("/shared_owner/blend_glutes", 255)],
}
STOCK_SLIDERS = [("/shared_owner/blend_fat", 255), ("/shared_owner/blend_muscle", 255)]


def face_top(species, sex):
    """Top of the head in the bind pose, from the race's l0 meshes (stock data)."""
    from swg_maya_mcp import iff, wearable as W
    stock = Path("D:/titan/data/sku.0/sys.client/compiled/game")
    sat = W.read_sat(stock / iff.template_strings(stock / f"object/creature/player/shared_{species}_{sex}.iff")["appearanceFilename"])
    top = 0.0
    for lmg in sat["mesh_generators"]:
        l0 = W.read_lmg(stock / lmg)[0]
        top = max(top, max(p[1] for p in W.read_mgn(stock / l0)["positions"]))
    return top


def head_height(species, sex):
    """Bind-pose height of the head mesh (l0), for the close-up distance."""
    from swg_maya_mcp import iff, wearable as W
    stock = Path("D:/titan/data/sku.0/sys.client/compiled/game")
    sat = W.read_sat(stock / iff.template_strings(stock / f"object/creature/player/shared_{species}_{sex}.iff")["appearanceFilename"])
    for lmg in sat["mesh_generators"]:
        l0 = W.read_lmg(stock / lmg)[0]
        if "head" in l0:
            ys = [p[1] for p in W.read_mgn(stock / l0)["positions"]]
            return max(ys) - min(ys)
    return 0.3


def raw_shot(name):
    """One capture as an RGB array (no black-frame retry bookkeeping beyond the shot() loop)."""
    import numpy as np
    from PIL import Image
    f = shot(name)
    a = np.asarray(Image.open(f).convert("RGB")).astype(int)
    f.unlink()
    return a


def head_top_row(a):
    """First row from the top, in the central band, where a run of non-sky (non-magenta) pixels starts."""
    h, w = a.shape[:2]
    band = a[:, int(w * 0.45):int(w * 0.55)]
    sky = (band[..., 0] > 190) & (band[..., 1] < 80) & (band[..., 2] > 190)
    solid = (~sky).sum(axis=1) >= 6
    # walk up from just above the horizon (the body, the pivot is below the head) to the first sky row, so labels
    # and bars floating above the head are not counted
    start = r = h // 2 - 6
    if not solid[r]:
        return None
    while r > 0 and solid[r - 1]:
        r -= 1
    if start - r < 24 and r > 0:                              # a name label over the horizon, not a head
        return None
    return r


def measure_head_top(x, z):
    """World height of the head top of the object standing at (x, z): two coarse shots with the pivot below the
    head (so the head top is against the sky), giving the row of the top and the pixels per metre."""
    ex("/scene cameraFov 60")
    rows = []
    for y in (0.9, 1.2):                                     # 7 m back: a 2.3 m Wookiee's head is still in frame
        b.request("camera", pivot=[x, y, z], distance=7.0, yaw=0, pitch=0)
        settle(15)
        rows.append(raw_shot("_measure"))
    r0, r1 = head_top_row(rows[0]), head_top_row(rows[1])
    if r0 is None or r1 is None or r1 <= r0:
        return None, None
    gain = (r1 - r0) / 0.3                                    # rows per metre of pivot height
    centre = rows[0].shape[0] / 2
    print(f"  measure rows {r0} {r1}", flush=True)
    return 0.9 + (centre - r0) / gain, gain


def frame_close(x, z, top_w, hh, gain7):
    """Close-up with the head top 12% below the frame top: correct the pivot from the close shot itself (spawned
    creatures don't always come out at the scale the coarse shot saw)."""
    import math
    d = max(0.8, hh * 3.4)
    # rows per metre at distance d and FOV 34, from the coarse 7 m / FOV 60 gain
    gain = (gain7 or 150.0) * 7.0 / d * math.tan(math.radians(30)) / math.tan(math.radians(17))
    y = top_w - hh * 0.42
    for _ in range(5):
        b.request("camera", pivot=[x, y, z], distance=d, yaw=0, pitch=0)
        settle(15)
        a = raw_shot("_frame")
        h = a.shape[0]
        r = head_top_row(a)
        if r is None:                                         # centre row is sky: the head is below the pivot
            y -= hh * 0.5
            continue
        if r <= 2:                                            # head top above the frame
            y += hh * 0.5
            continue
        if abs(r - 0.12 * h) < 0.03 * h:
            break
        y -= 0.8 * (r - 0.12 * h) / gain                    # a higher pivot moves the head down the frame
    b.request("camera", pivot=[x, y, z], distance=d, yaw=0, pitch=0)
    return y


def lineup(template, specs):
    ids = []
    for x, z, heading in specs:
        o = ex(f"/scene objectCreate {template} {x} {z} {heading}")
        ids += re.findall(r"object (\d+)", o)
    return ids


def clear(ids):
    for i in ids:
        ex(f"/scene objectDelete {i}")


ex("/scene drawNetworkIds 0")
ex("/scene drawObjectNames 0")
ex("/scene setTime 0.42")
results = {}
for race in races:
    species, sex = race.rsplit("_", 1)
    tmpl = f"object/creature/player/shared_{species}_{sex}.iff"
    if b.request("state")["result"].get("player"):
        ex(f"/scene load simple {species}_{sex}")           # in a scene: the scheduled scene change
    else:
        b.request("loadscene", avatar=tmpl)                  # login screen
    # the change is scheduled: wait until loading has started (or the player is gone), then until it is over
    t0 = time.time()
    while time.time() - t0 < 30:
        st = b.request("state")["result"]
        if st.get("scene_loading") or not st.get("player"):
            break
        time.sleep(0.1)
    t0 = time.time()
    while time.time() - t0 < 180:
        st = b.request("state")["result"]
        if st.get("player") and not st.get("scene_loading"):
            break
        time.sleep(1)
    settle(60)
    ex("/scene drawNetworkIds 0")
    ex("/scene drawObjectNames 0")
    ex("/scene setTime 0.42")
    ex("/devtest target clear")
    top = face_top(species, sex)
    mid = top * 0.55
    # lineup 5 m out: front, back, side; the free camera stands just ahead of the player, so the player is out of frame
    ids = lineup(tmpl, [(-1.7, 5, 180), (0.0, 5, 0), (1.7, 5, 90)])
    settle(40)
    ex("/devtest target clear")
    b.request("camera", pivot=[0.0, mid, 5.0], distance=4.4, yaw=0, pitch=2)
    settle(20)
    r = {"wide": str(shot(f"{tag}_{race}_wide"))}
    measured, gain7 = measure_head_top(-1.7, 5.0)
    hh = head_height(species, sex) * ((measured / top) if measured else 1.0)
    top_w = measured or top
    r["head_top"] = round(top_w, 3)
    ex("/scene cameraFov 34")
    r["close_pivot_y"] = round(frame_close(-1.7, 5.0, top_w, hh, gain7), 3)
    settle(20)
    r["close"] = str(shot(f"{tag}_{race}_close"))
    ex("/scene cameraFov 60")
    if tag != "before" and not os.environ.get("CLOSE_ONLY"):
        # sliders: [stock fat+muscle at max, side] [same, back] [new sliders at max, side] [same, back]
        clear(ids)
        ids = lineup(tmpl, [(-2.4, 6.5, 270), (-0.8, 6.5, 0), (0.8, 6.5, 270), (2.4, 6.5, 0)])
        for i in ids[:2]:
            for var, val in STOCK_SLIDERS:
                ex(f"/devtest custom set {var} {val} {i}")
        r["slider_output"] = [ex(f"/devtest custom set {var} {val} {i}").strip()
                              for i in ids[2:] for var, val in SLIDERS_AFTER[sex]]
        settle(40)
        b.request("camera", pivot=[0.0, mid, 6.5], distance=5.2, yaw=0, pitch=2)
        settle(20)
        r["sliders"] = str(shot(f"{tag}_{race}_sliders"))
        # wearables on the player with the new sliders at max: stock clothing must still fit and hide the body
        ex("/devtest target clear")
        for var, val in SLIDERS_AFTER[sex]:
            ex(f"/devtest custom set {var} {val}")
        r["equip"] = [ex(f"/scene equip {w}").strip() for w in (
            "object/tangible/wearables/shirt/shared_shirt_s03.iff",
            "object/tangible/wearables/pants/shared_pants_s01.iff")]
        r["persist"] = ex("/devtest custom persist").strip()
        settle(40)
        b.request("camera", pivot=[0.0, mid, 0.0], distance=2.6, yaw=180, pitch=2)
        settle(20)
        r["wearable_front"] = str(shot(f"{tag}_{race}_wearable_front"))
        b.request("camera", pivot=[0.0, mid, 0.0], distance=2.6, yaw=0, pitch=2)
        settle(20)
        r["wearable_back"] = str(shot(f"{tag}_{race}_wearable_back"))
    b.request("camera", mode="chase")
    clear(ids)
    results[race] = r
    print(race, r, flush=True)
jf = out / f"{tag}_shots.json"
merged = json.loads(jf.read_text()) if jf.exists() else {}
merged.update(results)
jf.write_text(json.dumps(merged, indent=1))
