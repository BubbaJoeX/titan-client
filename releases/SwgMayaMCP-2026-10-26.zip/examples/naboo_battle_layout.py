"""Battle of Naboo heroic: the battlefield layout in one place (docs/content/battle-of-naboo/README.md, section 2).

Positions are instance-local metres from the controller egg at the centre of adventure_heroic tile 05 (x east =
the droid side, z north). Everything a player walks between sits inside ~250 m:

    Gungan camp      (-112, 0)        Captain Tarpals, General Binks, the cloning point (instance entry)
    shield dome      (-60, 0) r 90    generators G1 (-94, 0), G2 (-56, 40), G3 (-56, -40); catapults (-12, +-58)
    Gungan line      an arc 12 m inside the dome's east rim, z -56..56
    MTT pads         (150, +-44)      the MTTs glide in from the droid rise (640, +-110)
    droid side       x 90..220        squads, the generator assault, the tank stations

Used by make_adventure_heroic.py (terrain pads) and write_spawn_table() below (the sequencer table). The Java side
mirrors DOME / LINE / GENERATORS in naboo_battle_lib.java; keep them in step.

    .venv\\Scripts\\python.exe examples\\naboo_battle_layout.py      (writes the dsrc spawn table)
"""
from __future__ import annotations

import math
from pathlib import Path

DSRC = Path("D:/titan/dsrc/sku.0/sys.server/compiled/game")
SPAWN_TABLE = DSRC / "datatables/spawning/heroic/heroic_naboo_battle.tab"

GROUND_Y = 13.0                       # sequencer start height; every spawned object snaps to the terrain
CAMP = (-112.0, 0.0)
DOME = (-60.0, 0.0, 90.0)             # centre x, z, radius (also naboo_battle.DOME_R and the lib constants)
LINE_R = DOME[2] - 12.0               # the Gungan line stands on this arc, facing east
GENERATORS = [(-94.0, 0.0), (-56.0, 40.0), (-56.0, -40.0)]
CATAPULTS = [(-12.0, 58.0), (-12.0, -58.0)]
CAPTURED_AAT = (-24.0, -30.0)
MTT_PADS = [(150.0, -44.0), (150.0, 44.0)]
MTT_START = [(640.0, -110.0), (640.0, 110.0)]
CLONE = (-120.0, 6.0)                 # cloning point (respawn), beside the camp

OBJ = "object/tangible/titan/heroic/naboo/"


def line_point(z: float, out: float = 0.0) -> tuple[float, float]:
    """The point of the Gungan line arc at z (out > 0 = further east, outside the dome)."""
    r = LINE_R + out
    return DOME[0] + math.sqrt(max(r * r - z * z, 0.0)), z


def _row(obj, spawn_id, trigger="", x=0.0, z=0.0, yaw=270.0, script="", objvars="", invulnerable="", comment=""):
    return [obj, spawn_id, trigger, "", f"{x:g}", f"{GROUND_Y:g}", f"{z:g}", f"{yaw:g}", script, objvars, "",
            invulnerable, comment, "", ""]


def _ov(**kv) -> str:
    parts = []
    for k, v in kv.items():
        kind = "string" if isinstance(v, str) else "int" if isinstance(v, int) else "float"
        parts.append(f"{kind}:hrc_nboo.{k}={v:g}" if kind == "float" else f"{kind}:hrc_nboo.{k}={v}")
    s = ",".join(parts)
    return f'"{s}"' if "," in s else s


def _squad(rows, mob_cycle, spawn_id, trigger, x0, z0, dz, n, attack):
    """A marching file: n droids from (x0, z0), every 4th of mob_cycle[1], 6 m apart east, dz apart sideways."""
    for i in range(n):
        mob = mob_cycle[1] if i % 4 == 0 else mob_cycle[0]
        rows.append(_row(mob, spawn_id, trigger, x0 + 6.0 * (i // 2), z0 + dz * (i % 2) + 3.0 * (i // 2),
                         objvars=_ov(attack=attack)))


def rows() -> list[list[str]]:
    r = []
    # ---- the Gungan camp (always there): Tarpals, General Binks, honour guard
    r.append(_row("hrc_nboo_gungan_officer", "tarpals", "", CAMP[0] + 6, CAMP[1] + 4, 90, "", _ov(role="tarpals"), "1",
                  "Captain Tarpals at the camp"))
    r.append(_row("hrc_nboo_jar_jar_binks", "jar_jar", "", CAMP[0] + 4, CAMP[1] - 5, 70, "", _ov(role="staging"), "1",
                  "General Binks tells the story"))
    for dx, dz in ((-6, 12), (-6, -12), (-14, 8), (-14, -8)):
        r.append(_row("hrc_nboo_gungan_warrior", "staging_gungan", "", CAMP[0] + dx, CAMP[1] + dz, 90, "",
                      _ov(role="staging"), "1", "camp honour guard"))
    # ---- shield generators on fambaas, the line, riders, catapults
    for i, (x, z) in enumerate(GENERATORS):
        r.append(_row("hrc_nboo_fambaa_generator", f"gen_{i + 1}", "", x, z, 90, "", f"int:hrc_nboo.gen={i + 1}", "",
                      f"shield generator {i + 1}"))
    for z in range(-56, 57, 16):
        x, _ = line_point(z)
        r.append(_row("hrc_nboo_gungan_warrior", "gungan_line", "", round(x, 1), z, 90, "", _ov(role="line"), "",
                      "the Gungan line"))
    for z in (-34.0, 34.0, -66.0, 66.0):
        x, _ = line_point(z, -14.0)
        r.append(_row("hrc_nboo_gungan_kaadu_rider", "gungan_riders", "", round(x, 1), z, 90, "", _ov(role="line"), "",
                      "kaadu rider behind the line"))
    for x, z in CATAPULTS:
        r.append(_row(OBJ + "catapult.iff", "catapult", "", x, z, 90, "theme_park.heroic.naboo_battle.catapult", "", "",
                      "Gungan catapult"))
    r.append(_row(OBJ + "shield_dome.iff", "dome", "dome_up", DOME[0], DOME[1], 0,
                  "theme_park.heroic.naboo_battle.shield_dome", "", "", f"Gungan shield dome r{DOME[2]:g}"))
    # ---- phase 1: STAP scouts harass the generators
    for x, z in ((300, 30), (300, -30), (330, 70), (330, -70)):
        r.append(_row("hrc_nboo_stap", "p1_stap", "p1_scouts", x, z, 270, "", _ov(attack="generators"), "",
                      "STAP scout (B1 rider)"))
    r.append(_row("deleteSpawn:p1_stap", "", "p1_reset", 0, 0, 0))
    # ---- phase 2: tanks shell the dome, MTTs land and unfold their racks, squads march
    for (x, z), (sx, sz) in (((600, -140), (210, -78)), ((600, 140), (210, 78)), ((620, 0), (190, 0))):
        r.append(_row("hrc_nboo_aat", "p2_aat", "p2_tanks", x, z, 270, "",
                      _ov(station_x=float(sx), station_z=float(sz), bombard=1), "", "AAT shelling the dome"))
    for (x, z), (px, pz) in zip(MTT_START, MTT_PADS):
        r.append(_row(OBJ + "mtt.iff", "p2_mtt", "p2_mtts", x, z, 270, "theme_park.heroic.naboo_battle.mtt",
                      _ov(pad_x=px, pad_z=pz), "", "MTT glides in to its pad"))
    _squad(r, ("hrc_nboo_b1", "hrc_nboo_b1_pilot"), "p2_droid", "p2_squad_a", 190, 22, 6, 8, "line")
    _squad(r, ("hrc_nboo_b1", "hrc_nboo_b1_pilot"), "p2_droid", "p2_squad_b", 190, -28, 6, 8, "line")
    for sid in ("p2_droid", "p2_aat", "p2_mtt"):
        r.append(_row(f"deleteSpawn:{sid}", "", "p2_reset", 0, 0, 0))
    # ---- phase 3: security droids and a file of B1s go for the generators
    _squad(r, ("hrc_nboo_b1_security", "hrc_nboo_b1_security"), "p3_droid", "p3_assault", 92, -10, 20, 6, "generators")
    _squad(r, ("hrc_nboo_b1", "hrc_nboo_b1_pilot"), "p3_droid", "p3_assault", 100, 40, 8, 6, "generators")
    _squad(r, ("hrc_nboo_b1", "hrc_nboo_b1_pilot"), "p3_droid", "p3_assault", 100, -48, 8, 6, "generators")
    _squad(r, ("hrc_nboo_b1", "hrc_nboo_b1_pilot"), "p3_droid", "p3_wave", 150, -12, 24, 6, "generators")
    r.append(_row("deleteSpawn:p3_droid", "", "p3_reset", 0, 0, 0))
    # ---- phase 4: the captured AAT against three tanks
    r.append(_row("hrc_nboo_aat_captured", "captured_aat", "p4_captured", CAPTURED_AAT[0], CAPTURED_AAT[1], 90, "", "",
                  "1", "the recaptured AAT (two seats)"))
    for (x, z), (sx, sz) in (((600, -140), (140, -66)), ((620, 0), (120, 0)), ((600, 140), (140, 66))):
        r.append(_row("hrc_nboo_aat", "p4_aat", "p4_enemies", x, z, 270, "",
                      _ov(station_x=float(sx), station_z=float(sz), counted=1), "", "enemy AAT (counted)"))
    _squad(r, ("hrc_nboo_b1", "hrc_nboo_b1_pilot"), "p4_droid", "p4_enemies", 160, -20, 40, 8, "line")
    for sid in ("p4_aat", "p4_droid"):
        r.append(_row(f"deleteSpawn:{sid}", "", "p4_reset", 0, 0, 0))
    # ---- phase 5: OOM-9's command tank and escort, then the holdout waves
    r.append(_row("hrc_nboo_aat_command", "p5_boss", "p5_boss", 640, 0, 270, "",
                  _ov(station_x=170.0, station_z=0.0, command=1), "", "OOM-9's command AAT (boss)"))
    _squad(r, ("hrc_nboo_b1", "hrc_nboo_b1_security"), "p5_escort", "p5_boss", 560, -14, 28, 12, "line")
    for z in (-60, 60):
        r.append(_row("hrc_nboo_stap", "p5_escort", "p5_boss", 540, z, 270, "", _ov(attack="line"), "",
                      "STAP escort (B1 rider)"))
    _squad(r, ("hrc_nboo_b1", "hrc_nboo_b1_security"), "p5_wave", "p5_wave", 190, -18, 36, 8, "line")
    for sid in ("p5_boss", "p5_escort", "p5_wave", "p5_commander"):
        r.append(_row(f"deleteSpawn:{sid}", "", "p5_reset", 0, 0, 0))
    return r


HEADER = ("object\tspawn_id\ttriggerId\troom\tloc_x\tloc_y\tloc_z\tyaw\tscript\tspawn_objvar\ttrigger_event\t"
          "isInvulnerable\tcomment\tpaths\trespawn\n"
          "s[required]\ts[none]\ts[default]\ts[none]\tf[0.0]\tf[0.0]\tf[0.0]\tf[0.0]\ts[none]\ts[none]\ts[none]\ti[0]\tc\t"
          "s[none]\ti[-1]\n")


def write_spawn_table(path: Path = SPAWN_TABLE) -> int:
    rs = rows()
    path.write_text(HEADER + "".join("\t".join(c) + "\n" for c in rs), encoding="utf-8", newline="\n")
    return len(rs)


if __name__ == "__main__":
    print(SPAWN_TABLE, write_spawn_table(), "rows")
