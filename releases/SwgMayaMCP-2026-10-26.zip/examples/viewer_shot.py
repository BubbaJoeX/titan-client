"""Screenshot an appearance in the stock asset Viewer (exe/win32_rel/Viewer_r.exe), which renders with the engine's
shaders and is steadier than the client for looking at meshes. Opens the file in its own Viewer instance (never
touches one already open), maximises the window and its document, captures it with PrintWindow and closes it.

  python examples/viewer_shot.py <.apt/.lod/.msh/.sat path> <out.png> [wait_s] [--keep]"""
import ctypes, subprocess, sys, time
from ctypes import wintypes
from PIL import Image
u = ctypes.windll.user32; g = ctypes.windll.gdi32
EXE = r"D:\titan\exe\win32_rel\Viewer_r.exe"
def windows(pid):
    out = []
    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(h, _):
        p = wintypes.DWORD(); u.GetWindowThreadProcessId(h, ctypes.byref(p))
        if p.value == pid and u.IsWindowVisible(h): out.append(h)
        return True
    u.EnumWindows(cb, 0); return out
def grab(h, path):
    r = wintypes.RECT(); u.GetWindowRect(h, ctypes.byref(r)); w, hh = r.right - r.left, r.bottom - r.top
    dc = u.GetWindowDC(h); mdc = g.CreateCompatibleDC(dc); bmp = g.CreateCompatibleBitmap(dc, w, hh); g.SelectObject(mdc, bmp)
    u.PrintWindow(h, mdc, 2)
    class BIH(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", ctypes.c_long), ("biHeight", ctypes.c_long), ("biPlanes", wintypes.WORD),
                    ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD), ("biSizeImage", wintypes.DWORD),
                    ("a", ctypes.c_long), ("b", ctypes.c_long), ("c", wintypes.DWORD), ("d", wintypes.DWORD)]
    bi = BIH(); bi.biSize = ctypes.sizeof(BIH); bi.biWidth = w; bi.biHeight = -hh; bi.biPlanes = 1; bi.biBitCount = 32
    buf = ctypes.create_string_buffer(w * hh * 4)
    g.GetDIBits(mdc, bmp, 0, hh, buf, ctypes.byref(bi), 0)
    Image.frombuffer("RGBA", (w, hh), buf, "raw", "BGRA", 0, 1).convert("RGB").save(path)
    g.DeleteObject(bmp); g.DeleteDC(mdc); u.ReleaseDC(h, dc)
if __name__ == "__main__":
    f, out = sys.argv[1], sys.argv[2]; wait = float(sys.argv[3]) if len(sys.argv) > 3 else 18   # the Viewer takes ~15 s to open with the full export tree
    p = subprocess.Popen([EXE, f], cwd=r"D:\titan\exe\win32_rel")
    time.sleep(wait)
    hs = windows(p.pid)
    print("pid", p.pid, "windows", len(hs))
    big = max(hs, key=lambda h: (lambda r: (u.GetWindowRect(h, ctypes.byref(r)), (r.right-r.left)*(r.bottom-r.top))[1])(wintypes.RECT())) if hs else None
    if big:
        u.ShowWindow(big, 3); time.sleep(1)
        kids = []
        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def cb2(h, _):
            b = ctypes.create_unicode_buffer(256); u.GetWindowTextW(h, b, 256)
            if b.value.lower().endswith((".apt", ".lod", ".msh", ".sat")): kids.append(h)
            return True
        u.EnumChildWindows(big, cb2, 0)
        for k in kids: u.ShowWindow(k, 3)
        time.sleep(3); grab(big, out); print(out)
    if "--keep" not in sys.argv:
        p.terminate()
