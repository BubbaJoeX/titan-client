"""Parity of the terrain port against the offline client: the Atmo starport's terrain layer (fine-exclusion landing
well, r 29 round local (1.5, 0)) placed at (45, 450) heading 0 in the Simple scene.

    .venv\Scripts\python.exe examples\terrain_parity_starport.py [port]     (default port 7081; launches a client)

Spawns the starport, then compares the client's heights (bridge `terrain`) with trn_heights / generator.heights_at:
on poles over the hole and pad, between poles, and in 10 m patches round the hole edge with the player standing at
each (so the client has full-detail chunks there). Prints per-sweep counts and the hole-edge disagreements."""

import json
import math
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

from swg_maya_mcp.terrain import trn, verify  # noqa: E402
from swg_maya_mcp.terrain.tools import DATA_ROOTS, _resolve  # noqa: E402

LAY = "D:/exported/terrain/titan_atmo_starport.lay"
TEMPLATE = "object/building/titan/shared_titan_atmo_starport.iff"
X, Z, CX, CZ = 45.0, 450.0, 46.5, 450.0


def main(port: int) -> None:
    if not verify._pin_file(port).exists():
        print(verify.launch_own(port, "D:/exported"))
    b = verify.bridge_for(port)
    verify._wait_scene(b, terrain="terrain/simple.trn")
    b.request("exec", line="/scene load simple", timeout=60)
    time.sleep(3)
    verify._wait_scene(b)
    world = trn.TerrainDoc.load(Path(DATA_ROOTS[0]) / "terrain/simple.trn")
    doc, info = verify.place_buildings(world, [{"layer": LAY, "x": X, "z": Z, "yaw": 0, "template": TEMPLATE}],
                                       _resolve, b, spawn=True)
    print("placed", info)
    b.request("exec", line=f"/warpme {CX} 3 {CZ + 38}")
    time.sleep(10)
    sweeps = verify.compare(doc, b, [{"center": [CX, CZ], "radius": 40, "step": 2},
                                     {"center": [CX, CZ], "radius": 34, "step": 0.5, "pole_aligned": False}],
                            data_roots=DATA_ROOTS, warp=False)
    for k in range(8):
        a = math.radians(k * 45 + 10)
        b.request("exec", line=f"/warpme {CX + 31 * math.cos(a):.2f} 3 {CZ + 31 * math.sin(a):.2f}")
        time.sleep(10)
        sweeps += verify.compare(doc, b, [{"center": [CX + 29 * math.cos(a), CZ + 29 * math.sin(a)], "radius": 5,
                                           "step": 0.11, "pole_aligned": False}], data_roots=DATA_ROOTS, warp=False)
    for s in sweeps:
        print(json.dumps({k: s[k] for k in ("center", "points", "compared", "holes_both", "mismatched_holes",
                                            "max_abs_diff")}))
    pts = sum(s["points"] for s in sweeps)
    bad = sum(s["mismatched_holes"] for s in sweeps)
    print(f"total {pts} points, heights max diff {max(s['max_abs_diff'] or 0 for s in sweeps)}, "
          f"hole membership agrees on {100 * (1 - bad / pts):.2f}%")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 7081)
