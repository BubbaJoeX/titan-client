"""Player race remaster: every playable base species (human, Twi'lek, Zabrak, Bothan, Rodian, Trandoshan,
Mon Calamari, Wookiee, Sullustan, Ithorian), both sexes - a faithful remaster plus more customization.

What it changes (stock files stay untouched; everything is written under D:/exported at the stock paths, which
the client and the server search before the stock data):

  templates  appearance/<species>_<sex>.sat + appearance/mesh/*.lmg: stock copies, so the Viewer opened on the .sat in
             D:/exported reads every mesh from there
  meshes     appearance/mesh/<species>_*_l0..l3.mgn
             - body morph blend targets: blend_chest_large (female), blend_glutes (all), blend_bulge (male),
               driven by new /shared_owner/ variables (races.py has the shapes)
             - coincident border normals of body/head/arms/hands welded (Trandoshan neck, Mon Cal wrists ...),
               DOT3 tangents re-orthogonalised
             vertex order, skinning, occlusion zones and existing blend targets are unchanged, so every stock
             wearable still fits and the existing sliders still work
  textures   texture/*.dds of every l0/l1 race shader and face texture renderer: 2x (4x for maps of 64 px or
             less) uncompressed reconstruction - DXT de-blocking, Lanczos, sharpening, normal-map micro detail
             (skin pores, Trandoshan scales); channel meanings (hue masks, spec masks, DXT5nm X/Y) preserved
  faces      texturerenderer/<species>_face.trt render at 2x (the composited face, brows, beards, freckles)
  sliders    customization/customization_id_manager.iff + dsrc mif: the three new variables (ids 127+, which
             CustomizationData version 4 persists); customization/asset_customization_manager.iff: the
             variables declared on every body .mgn; datatables/customization/customization_data: new sliders
             (Chest Size, Glutes, Bulge) and the stock blend targets no slider exposed (Wookiee nose
             protrusion, Mon Cal female ears, Trandoshan female torso); palette_columns: twice as many colours
             at character creation (the stock palettes already carry 256 curated entries); string/en/ui_cust
             labels

  python examples/make_races.py                      everything, all races
  python examples/make_races.py human                one species (meshes + textures); tables always cover all
  python examples/make_races.py --only meshes|textures|custom|tables
  python examples/make_races.py --no-compile         skip the WSL DataTableTool step
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import customization as C, iff, races as R, wearable as W  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
TITAN = Path(os.environ.get("TITAN_ROOT", "D:/titan"))
STOCK = TITAN / "data/sku.0/sys.client/compiled/game"
SHARED = TITAN / "data/sku.0/sys.shared/compiled/game"
DSRC_SHARED = TITAN / "dsrc/sku.0/sys.shared/compiled/game"
# the client and the Viewer find loose files next to their exe (exe/<platform>/customization/...) before any search
# path, D:/exported included, so the customization managers there must carry the new ids too
CLIENT_LOOSE = [TITAN / "exe" / d for d in ("win64_rel", "win32_rel", "win32")]
WSL = ["wsl.exe", "-d", os.environ.get("TITAN_WSL_DISTRO", "Titan"), "-u", "root", "--"]
TITAN_SH = "/mnt/d/titan/wsl/titan.sh"
REPORT = EXPORT / "appearance/mesh/titan_races_report.json"

# species -> (template prefix, normal-map micro detail for skin maps)
SPECIES = {
    "human": ("hum", "pores"), "twilek": ("twk", "pores"), "zabrak": ("zab", "pores"), "bothan": ("bth", None),
    "rodian": ("rod", "pores"), "trandoshan": ("trn", "scales"), "moncal": ("mon", "pores"),
    "wookiee": ("wke", None), "sullustan": ("sul", "pores"), "ithorian": ("ith", "pores"),
}
SEXES = ("male", "female")

NEW_VARIABLES = ["/shared_owner/blend_chest_large", "/shared_owner/blend_glutes", "/shared_owner/blend_bulge"]
LABELS = {"chest_size": "Chest Size", "glutes": "Glutes", "bulge": "Bulge"}
SKIP_TEXTURE_TAGS = {"ENVM", "LKUP"}


def player_template(species, sex):
    return iff.template_strings(STOCK / f"object/creature/player/shared_{species}_{sex}.iff")


def race_meshes(species, sex) -> list[list[str]]:
    """Mesh generator paths per .lmg: [[l0, l1, l2, l3], ...]."""
    sat = W.read_sat(STOCK / player_template(species, sex)["appearanceFilename"])
    return [W.read_lmg(STOCK / lmg) if lmg.endswith(".lmg") else [lmg] for lmg in sat["mesh_generators"]]


def morphs_for(sex):
    return [n for n, who in R.MORPHS.items() if who in ("all", sex)]


def stock_or_export(rel):
    return (EXPORT / rel) if (EXPORT / rel).exists() else (STOCK / rel)


# ----------------------------------------------------------------------------
# meshes
# ----------------------------------------------------------------------------

def copy_appearance_templates(species, sex):
    """Stock .sat and its .lmg files, byte for byte, next to the meshes: the Viewer adds D:/exported to its search
    path only for a file opened from under D:/exported/appearance/, and the .sat is what one opens."""
    sat = player_template(species, sex)["appearanceFilename"]
    files = [sat] + [lmg for lmg in W.read_sat(STOCK / sat)["mesh_generators"] if lmg.endswith(".lmg")]
    for rel in files:
        (EXPORT / rel).parent.mkdir(parents=True, exist_ok=True)
        (EXPORT / rel).write_bytes((STOCK / rel).read_bytes())
    return files


def build_meshes(species, sex):
    groups = race_meshes(species, sex)
    report = {}
    for level in range(max(len(g) for g in groups)):
        names = [g[level] for g in groups if level < len(g)]
        ms = {n: W.read_mgn(STOCK / n) for n in names}
        welded = R.weld_seam_normals(ms)
        for n, m in ms.items():
            r = {"welded_normals": welded.get(n, 0), "morphs": []}
            # stock trn_f_arms_l0..l3 name their skeleton "skeleton/all_b.skt" (no appearance/ prefix)
            fixed = [s if s.startswith("appearance/") else "appearance/" + s for s in m["skeletons"]]
            if fixed != m["skeletons"]:
                r["skeleton_path_fixed"] = m["skeletons"]
                m["skeletons"] = fixed
            if "_body_" in n.split("/")[-1]:
                for morph in morphs_for(sex):
                    s = R.add_blend_target(m, morph, R.morph_offsets(m, morph))
                    if s:
                        r["morphs"].append(s)
            out = EXPORT / n
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(W.write_mgn(m))
            report[n] = r
    return report


# ----------------------------------------------------------------------------
# textures
# ----------------------------------------------------------------------------

def race_shaders(species, sex) -> set[str]:
    out = set()
    for g in race_meshes(species, sex):
        for n in g:
            for s in W.read_mgn(STOCK / n)["shaders"]:
                out.add(s["name"])
    return out


def face_renderers(species, sex) -> set[str]:
    out = set()
    for g in race_meshes(species, sex):
        m = W.read_mgn(STOCK / g[0])
        trts = m["extra"].get("TRTS")
        if trts is not None:
            for c in trts.children:
                if c.tag == "TRT ":
                    out.add(c.data.split(b"\0")[0].decode("latin1"))
    return out


def texture_kind(tag):
    return {"MAIN": "color", "HUEB": "color", "SPEC": "spec", "CNRM": "normal"}.get(tag, "generic")


def remaster_texture(rel, kind, detail, done, seed):
    rel = rel.replace("\\", "/")
    if rel in done or "_sm" in Path(rel).stem or not (STOCK / rel).exists():
        return None
    w, h, px = iff.read_dds_rgba(STOCK / rel)
    rgba = np.frombuffer(bytes(px), np.uint8).reshape(h, w, 4)
    factor = 4 if max(w, h) <= 64 else 2
    out = R.remaster_rgba(rgba, kind, factor, detail if kind == "normal" else None, seed)
    R.write_dds_argb(EXPORT / rel, out)
    done[rel] = {"kind": kind, "from": [w, h], "to": [w * factor, h * factor], "detail": detail if kind == "normal" else None}
    return done[rel]


def build_textures(species, sex, done):
    detail = SPECIES[species][1]
    for sht in sorted(race_shaders(species, sex)):
        if Path(sht).stem.endswith("_sm") or not (STOCK / sht).exists():
            continue
        info = iff.read_custom_shader(STOCK / sht)
        for tag, tex in info["textures"].items():
            if tag in SKIP_TEXTURE_TAGS:
                continue
            # micro detail only on skin maps, not on wrinkle/face overlays, eyes or mouths
            d = detail if re.search(r"(body|head|skull|hand|arm|leccu)", Path(tex).stem) else None
            remaster_texture(tex, texture_kind(tag), d, done, seed=len(done))
    for trt in sorted(face_renderers(species, sex)):
        remaster_face_renderer(trt, done)


def remaster_face_renderer(trt, done):
    """Render the composited face at 2x (DEST width/height) and remaster its layer textures."""
    if trt in done:
        return
    root = iff.parse_iff((STOCK / trt).read_bytes())
    ver = root.first("BTRT").forms()[0]
    dest = ver.first("DEST")
    vals = list(np.frombuffer(dest.data, "<i4"))
    vals[0], vals[1] = vals[0] * 2, vals[1] * 2
    dest.data = np.array(vals, "<i4").tobytes()
    out = EXPORT / trt
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(iff.serialize_iff(root))
    names = ver.first("TXTS").first("INFO").data[4:].split(b"\0")[:-1]
    for n in names:
        remaster_texture(n.decode("latin1"), "color", None, done, seed=len(done))
    done[trt] = {"kind": "texture renderer", "size": vals[:2], "layers": len(names)}


# ----------------------------------------------------------------------------
# customization: ids, asset declarations, strings
# ----------------------------------------------------------------------------

def build_customization():
    """Customization id manager (shared dsrc mif + compiled iff) and asset customization manager."""
    mif = DSRC_SHARED / "customization/customization_id_manager.mif"
    backup = mif.with_suffix(".mif.pre-races")
    if not backup.exists():
        backup.write_bytes(mif.read_bytes())
    added = C.append_cidm_mif(mif, NEW_VARIABLES)
    names = [n for _, n in sorted((int(i), n) for i, n in re.findall(r'int16\s+(\d+)\s+cstring\s+"([^"]+)"',
                                                                        mif.read_bytes().decode("latin1")))]
    cidm = C.write_cidm(names)
    for root in (EXPORT, SHARED):
        p = root / "customization/customization_id_manager.iff"
        if root == SHARED and not p.with_suffix(".iff.pre-races").exists():
            p.with_suffix(".iff.pre-races").write_bytes(p.read_bytes())
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(cidm)

    acm_rel = "customization/asset_customization_manager.iff"
    loose = CLIENT_LOOSE[0] / acm_rel
    base = next(f for f in (loose.with_suffix(".iff.pre-races"), loose, STOCK / acm_rel) if f.exists())  # untouched copy
    acst = C.read_acst(base)
    declared = []
    for species in SPECIES:
        for sex in SEXES:
            for g in race_meshes(species, sex):
                for n in g:
                    if "_body_" not in n.split("/")[-1] or not (EXPORT / n).exists():
                        continue
                    m = W.read_mgn(EXPORT / n)
                    for t in m["blend_targets"]:
                        var = "/shared_owner/" + t["name"]
                        if var in NEW_VARIABLES:
                            C.add_asset_variable(acst, n, var, (0, 256), 0)
                            declared.append((n, var))
    data = C.write_acst(acst)
    for p in (EXPORT / "customization/asset_customization_manager.iff",):
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    for rel, content in (("customization/customization_id_manager.iff", cidm), (acm_rel, data)):
        for folder in CLIENT_LOOSE:
            loose = folder / rel
            if loose.exists():
                if not loose.with_suffix(".iff.pre-races").exists():
                    loose.with_suffix(".iff.pre-races").write_bytes(loose.read_bytes())
                loose.write_bytes(content)

    stf = C.read_stf(STOCK / "string/en/ui_cust.stf")
    for k, v in LABELS.items():
        C.stf_set(stf, k, v)
    p = EXPORT / "string/en/ui_cust.stf"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(C.write_stf(stf))
    return {"cidm_added": added, "cidm_count": len(names), "acst_declarations": len(declared)}


# ----------------------------------------------------------------------------
# datatables
# ----------------------------------------------------------------------------

GENERATED = "titan_races"


def _row(species_sex, group, name, variables, reverse="", skillmod_group="body", value="3"):
    cols = [species_sex, group, "hslider", name, variables, "", reverse, "", "", "", "", "", "", "", "",
            skillmod_group, value, "physical"]
    return "\t".join(cols)


def slider_rows(existing: list[list[str]]) -> list[str]:
    have = {(r[0], r[3]) for r in existing if len(r) > 4}
    rows = []
    for species in SPECIES:
        for sex in SEXES:
            ss = f"{species}_{sex}"
            if sex == "female":
                rows.append(_row(ss, "body", "chest_size", "blend_chest_large", value="9"))
            rows.append(_row(ss, "body", "glutes", "blend_glutes", value="7"))
            if sex == "male":
                rows.append(_row(ss, "body", "bulge", "blend_bulge", value="7"))
    # stock blend targets that had no slider
    extra = [("wookiee_male", "eyes_nose", "nose_protrusion", '"blend_nosedepth_0,blend_nosedepth_1"', "", "face", "6"),
             ("wookiee_female", "eyes_nose", "nose_protrusion", '"blend_nosedepth_0,blend_nosedepth_1"', "", "face", "6"),
             ("moncal_female", "face", "ear_shape", '"blend_ear_0,blend_ear_1"', "", "face", "5"),
             ("trandoshan_female", "body", "chest", "blend_flat_chest", "1", "body", "9")]
    for ss, grp, name, var, rev, sg, val in extra:
        if (ss, name) not in have:
            rows.append(_row(ss, grp, name, var, rev, sg, val))
    return [r for r in rows if tuple(r.split("\t")[0:4:3]) not in have]


def update_tables():
    """customization_data.tab (new sliders) and palette_columns.tab (more creation colours), in shared dsrc."""
    changed = []
    tab = DSRC_SHARED / "datatables/customization/customization_data.tab"
    raw = tab.read_bytes().decode("latin1")
    nl = "\r\n" if "\r\n" in raw else "\n"
    lines = raw.split(nl)
    if lines and lines[-1] == "":
        lines = lines[:-1]
    backup = tab.with_suffix(".tab.pre-races")
    if not backup.exists():
        backup.write_bytes(tab.read_bytes())
    base = backup.read_bytes().decode("latin1").split(nl)
    base = [l for l in base if l]
    new = slider_rows([l.split("\t") for l in base[2:]])
    # keep each species' rows together: insert after that species' last body row
    out = list(base)
    for r in new:
        ss, grp = r.split("\t")[:2]
        idx = max((i for i, l in enumerate(out) if l.split("\t")[:2] == [ss, grp]), default=None)
        if idx is None:
            idx = max(i for i, l in enumerate(out) if l.split("\t")[0] == ss)
        out.insert(idx + 1, r)
    if out != lines:
        tab.write_bytes((nl.join(out) + nl).encode("latin1"))
    changed.append(tab)

    tab = DSRC_SHARED / "datatables/customization/palette_columns.tab"
    raw = tab.read_bytes().decode("latin1")
    nl = "\r\n" if "\r\n" in raw else "\n"
    backup = tab.with_suffix(".tab.pre-races")
    if not backup.exists():
        backup.write_bytes(tab.read_bytes())
    base = [l for l in backup.read_bytes().decode("latin1").split(nl) if l]
    out = base[:2]
    for l in base[2:]:
        c = l.split("\t")
        if c[0].startswith("pc_") and len(c) > 2 and c[2].strip():
            pal = C.read_pal(STOCK / f"palette/{c[0]}.pal")
            c[2] = str(min(len(pal), int(c[2]) * 2))
        out.append("\t".join(c))
    tab.write_bytes((nl.join(out) + nl).encode("latin1"))
    changed.append(tab)
    return changed


def wsl(*args):
    r = subprocess.run(WSL + ["bash", TITAN_SH, *args], capture_output=True, text=True, encoding="utf8",
                       errors="replace", env={**os.environ, "MSYS_NO_PATHCONV": "1"})
    return r.returncode, (r.stdout + r.stderr)[-3000:]


def compile_tables(files):
    code, out = wsl("sync", *[str(f).replace("\\", "/") for f in files])
    print(out)
    if code:
        raise SystemExit(f"titan.sh sync failed ({code})")
    for f in files:
        rel = Path(f).relative_to(DSRC_SHARED).with_suffix(".iff")
        dst = EXPORT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes((SHARED / rel).read_bytes())
        print("deployed", dst)


# ----------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("species", nargs="*", default=list(SPECIES))
    ap.add_argument("--only", choices=["meshes", "textures", "custom", "tables"])
    ap.add_argument("--no-compile", action="store_true")
    a = ap.parse_args()
    report = json.loads(REPORT.read_text()) if REPORT.exists() else {}
    steps = [a.only] if a.only else ["meshes", "textures", "custom", "tables"]
    if "meshes" in steps:
        for sp in a.species:
            for sex in SEXES:
                report.setdefault("meshes", {}).update(build_meshes(sp, sex))
                for rel in copy_appearance_templates(sp, sex):
                    report.setdefault("appearance_templates", {})[rel] = "stock copy"
                print("meshes", sp, sex)
    if "textures" in steps:
        done = report.setdefault("textures", {})
        for sp in a.species:
            for sex in SEXES:
                n0 = len(done)
                build_textures(sp, sex, done)
                print("textures", sp, sex, len(done) - n0)
    if "custom" in steps:
        report["customization"] = build_customization()
        print("customization", report["customization"])
    if "tables" in steps:
        files = update_tables()
        if not a.no_compile:
            compile_tables(files)
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=1, default=str))


if __name__ == "__main__":
    main()
