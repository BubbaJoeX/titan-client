"""Writes examples/titan_royal_retreat.json: 12-room, two-storey Naboo player house test (winding stair,
domes, stages, windows, terrain base with ramps). Run: python examples/make_royal_retreat.py"""
import json
import math
from pathlib import Path

GROUND, UP = 1.0, 5.0                  # floor heights (terrain base top = GROUND)
apo = lambda r, n=16: r * math.cos(math.pi / n)
TOWER_W = 3 - apo(4)                   # stair tower's flat west face: the conservatory shares it
# library: an apse - straight bay along the hall's whole west wall, then a half-round end (no V-notches
# against the hall/foyer/conservatory, which the terrain base would have to fold into)
LIBRARY = [(-7, -6), (-7, 6), (-10, 6)] + [(-10 - 6 * math.sin(math.pi * k / 8), 6 * math.cos(math.pi * k / 8))
                                            for k in range(1, 8)] + [(-10, -6)]

WALL = {"shader": "shader/ply_nboo_marblewhite_ces17.sht"}
CARPET = {"shader": "shader/ply_nboo_carpetblue_cd8.sht"}
MARBLE = {"shader": "shader/nboo_intr_throne_marble_grey_cd8.sht"}
DECO = {"shader": "shader/ply_nboo_marblefloordec_ces17.sht"}
WINDOW_IN = {"shader": "shader/ply_thed_window_blue_ce9.sht", "color": [0.45, 0.55, 0.85]}


def mats(floor=CARPET, **extra):
    return {"wall": WALL, "floor": floor, "window": WINDOW_IN, **extra}


def light(warm=1.0, tint=(1.0, 0.94, 0.82)):
    return {"ambient": 1.0, "ambient_rgb": [0.42, 0.42, 0.46], "rgb": [c * warm for c in tint], "intensity": 1.0,
            "constant": 0.0, "quadratic": 0.6,
            "parallel": [{"rgb": [0.45, 0.44, 0.42], "dir": [0.2, -1.0, -0.3]}, {"rgb": [0.22, 0.24, 0.30], "dir": [0.0, 1.0, 0.2]}]}


def win(**kw):
    base = {"width": 1.2, "height": 2.0, "sill": 1.0, "spacing": 3.0}
    base.update(kw)
    return base


rooms = [
    # ---- ground floor --------------------------------------------------------------------------
    {"name": "grand_foyer", "min": [-7, 6], "max": [7, 14], "floor_y": GROUND, "height": 3.6,
     "materials": mats(MARBLE), "windows": win(), "light": light(1.1)},
    {"name": "great_hall", "min": [-7, -6], "max": [7, 6], "floor_y": GROUND, "height": 3.6,
     "materials": mats(DECO), "windows": win(width=1.0, height=1.8),
     "stages": [{"min": [2.5, -0.5], "max": [5.5, 2.5], "height": 0.5, "ramp": {"side": "-x", "width": 1.6, "length": 1.5}}],
     "light": light(1.2)},
    {"name": "library", "polygon": [list(p) for p in LIBRARY],
     "floor_y": GROUND, "height": 4.4, "dome": {"height": 3.0, "rings": 7},
     "materials": mats(CARPET), "windows": win(edge_step=2, height=2.2), "light": light(0.9, (1.0, 0.86, 0.66))},
    {"name": "dining", "min": [7, -6], "max": [15, 2], "floor_y": GROUND, "height": 3.6,
     "materials": mats(DECO), "windows": win(), "light": light(1.0)},
    {"name": "kitchen", "min": [7, 2], "max": [13, 8], "floor_y": GROUND, "height": 3.6,
     "materials": mats(MARBLE), "windows": win(spacing=2.6), "light": light(1.0, (1.0, 1.0, 0.95))},
    {"name": "stair_tower", "round": {"center": [3, -6 - apo(4)], "radius": 4, "segments": 16},
     "floor_y": GROUND, "height": 8.0, "dome": {"height": 1.8, "rings": 6},
     "spiral": {"y_to": UP, "column_radius": 0.6, "step_height": 0.2},
     "materials": mats(MARBLE, stair=MARBLE),
     "windows": {"list": [{"edge": 4, "width": 0.8, "height": 1.4, "sill": 1.4},
                          {"edge": 12, "width": 0.8, "height": 1.4, "sill": 2.8},
                          {"edge": 8, "width": 0.8, "height": 1.4, "sill": 5.6}]},
     "light": light(1.0)},
    {"name": "conservatory", "polygon": [[-7, -6], [TOWER_W, -6], [TOWER_W, -12], [-4, -14], [-7, -14], [-9, -11], [-9, -6]],
     "floor_y": GROUND, "height": 4.4, "materials": mats(DECO), "windows": win(width=1.4, height=2.4, sill=0.8, spacing=2.2),
     "light": light(1.0, (0.95, 1.0, 0.9))},
    # ---- upper floor ---------------------------------------------------------------------------
    {"name": "master_suite", "min": [-7, -6], "max": [1, 6], "floor_y": UP, "height": 3.8,
     "materials": mats(CARPET), "windows": win(),
     "stages": [{"min": [-6.5, 2.5], "max": [-3.0, 5.5], "height": 0.4, "ramp": {"side": "+x", "width": 1.4, "length": 1.2}}],
     "light": light(0.9, (1.0, 0.88, 0.75))},
    {"name": "study", "min": [1, -6], "max": [7, 0], "floor_y": UP, "height": 3.8,
     "materials": mats(CARPET), "windows": win(), "light": light(1.0)},
    {"name": "gallery", "min": [1, 0], "max": [7, 6], "floor_y": UP, "height": 3.8,
     "materials": mats(DECO), "windows": win(), "light": light(1.1)},
    {"name": "bath", "min": [-5, 6], "max": [5, 11], "floor_y": UP, "height": 3.4,
     "materials": mats(MARBLE), "windows": win(width=1.0, height=1.4, sill=1.6), "light": light(1.0, (0.92, 0.96, 1.0))},
    {"name": "solarium", "min": [7, -6], "max": [15, 2], "floor_y": UP, "height": 3.8,
     "materials": mats(DECO), "windows": win(width=1.6, height=2.4, sill=0.6, spacing=2.4), "light": light(1.1, (1.0, 1.0, 0.92))},
]

D1 = {"door_style": "ply_nboo_house_door_s01"}
D2 = {"door_style": "ply_nboo_house_door_s02"}
door = lambda a, b, **kw: {"rooms": [a, b], "width": 1.9, "height": 2.95, **kw}
doors = [
    door("grand_foyer", "great_hall", **D2),
    door("great_hall", "library", **D1),
    door("great_hall", "dining", **D1),
    door("great_hall", "kitchen", **D1),
    door("dining", "kitchen", style="arch"),
    {"rooms": ["great_hall", "stair_tower"], "width": 1.4, "height": 2.95},          # archway (tower edge is 1.56 m)
    door("great_hall", "conservatory", **D1),
    {"rooms": ["study", "stair_tower"], "width": 1.4, "height": 2.95},
    door("study", "gallery", **D1),
    door("gallery", "master_suite", **D1),
    door("study", "master_suite", style="arch"),
    door("master_suite", "bath", offset=-1.0, **D1),
    door("study", "solarium", **D2),
]
entrances = [
    {"room": "grand_foyer", "side": "+z", "width": 1.9, "height": 2.95, "door_style": "ply_nboo_house_door_s02", "ramp_width": 3.4},
    {"room": "conservatory", "side": "-x", "width": 1.9, "height": 2.95, "door_style": "ply_nboo_house_door_s01", "ramp_width": 2.4, "offset": 0.8},
]
spec = {
    "name": "titan_royal_retreat",
    "ground_y": 0.0,
    "trim": True,
    "collision_meshes": True,
    "shell_color": [0.80, 0.76, 0.68],
    "shell_materials": {"shader": "shader/thed_brick_largea_adb13.sht"},
    "exterior": {
        "porch": {"shader": "shader/thed_tile_floorb_asb13.sht", "color": [0.7, 0.68, 0.64]},
        "trim": {"shader": "shader/thed_trim_c_asb13.sht", "color": [0.75, 0.72, 0.66]},
        "window": {"shader": "shader/ply_thed_window_red_aeb14.sht", "color": [0.7, 0.35, 0.3]},
        "dome": {"shader": "shader/thed_patinaroof_as6.sht", "color": [0.35, 0.6, 0.55]},
        "roof": {"shader": "shader/thed_concreteb_adb13.sht", "color": [0.7, 0.68, 0.64]},
    },
    "base": {"shader": "shader/thed_concreteb_adb13.sht", "margin": 1.4, "flare": 0.7, "depth": 1.8, "ramp_slope": 0.3},
    "trim_materials": {"shader": "shader/thed_palace_trim_a1_cs8.sht", "color": [0.7, 0.62, 0.4]},
    "rooms": rooms,
    "doors": doors,
    "entrances": entrances,
    "lights": True,
}
out = Path(__file__).with_name("titan_royal_retreat.json")
out.write_text(json.dumps(spec, indent=1), encoding="utf-8")
print("wrote", out, len(rooms), "rooms")
