"""Preview renders of furniture.F-style builders (furniture.py, naboo_battle.py ...) WITHOUT Maya: the builders only
need maya.* at export time, so this stubs the maya modules, runs the builder, and rasterises the accumulated
polygons with numpy (z-buffer, textures from the export tree, Lambert + spec mask, soft normals like polySoftEdge).

    python examples/geo_preview.py <module> <builder> <out.png> [--az 35] [--el 18] [--size 1200x800]
                                   [--tex D:/exported] [--lod 0]

System Python (numpy + Pillow). The image is for checking shape and material placement; the client is the
reference for final looks.
"""
from __future__ import annotations

import argparse
import importlib
import math
import os
import sys
import types
from pathlib import Path

import numpy as np
from PIL import Image


def stub_maya():
    for m in ("maya", "maya.cmds", "maya.mel", "maya.api", "maya.api.OpenMaya"):
        sys.modules.setdefault(m, types.ModuleType(m))
    sys.modules["maya"].cmds = sys.modules["maya.cmds"]
    sys.modules["maya"].mel = sys.modules["maya.mel"]
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "maya"))


def triangles(P, slot_filter=None):
    """[(slot, tris (n,3,3), uvs (n,3,2))] from an F's accumulators (fan triangulation, Maya space)."""
    out = []
    for slot, acc in P.acc.items():
        if slot_filter and not slot_filter(slot):
            continue
        pts = np.array(acc.points, float)
        uvs = np.array(acc.uvs, float) if acc.uvs else np.zeros((0, 2))
        tri, tuv = [], []
        k = 0
        for c in acc.counts:
            ids = acc.connects[k:k + c]
            uid = acc.uv_ids[k:k + c]
            for j in range(1, c - 1):
                tri.append([ids[0], ids[j], ids[j + 1]])
                tuv.append([uid[0], uid[j], uid[j + 1]])
            k += c
        if tri:
            tri = np.array(tri)
            tuv = np.array(tuv)
            out.append((slot, pts, tri, uvs[tuv] if len(uvs) else np.zeros((len(tri), 3, 2))))
    return out


def soft_normals(pts, tri, angle=40.0):
    """Per-corner normals: face normals averaged over faces sharing a vertex within `angle` degrees."""
    a, b, c = pts[tri[:, 0]], pts[tri[:, 1]], pts[tri[:, 2]]
    fn = np.cross(b - a, c - a)
    area = np.linalg.norm(fn, axis=1, keepdims=True)
    fnu = fn / np.maximum(area, 1e-12)
    vsum = np.zeros((len(pts), 3))
    for j in range(3):
        np.add.at(vsum, tri[:, j], fn)
    out = np.zeros((len(tri), 3, 3))
    cosl = math.cos(math.radians(angle))
    # vertex-average, then fall back to the face normal where the average strays past the soft angle
    vn = vsum / np.maximum(np.linalg.norm(vsum, axis=1, keepdims=True), 1e-12)
    for j in range(3):
        n = vn[tri[:, j]]
        ok = (n * fnu).sum(1) > cosl
        out[:, j] = np.where(ok[:, None], n, fnu)
    return out, fnu


def load_tex(tex_root, name):
    from swg_maya_mcp import iff
    p = Path(tex_root) / "texture" / f"{name}.dds"
    if not p.exists():
        return None
    w, h, px = iff.read_dds_rgba(p)
    return np.frombuffer(bytes(px), np.uint8).reshape(h, w, 4).astype(float) / 255.0


def render(meshes, size=(1200, 800), az=35.0, el=18.0, dist=None, target=None, fov=34.0, slot_tex=None,
           slot_col=None, ground=True, sun=(-0.45, 0.8, 0.35)):
    W, H = size
    allp = np.concatenate([m[1][np.unique(m[2])] for m in meshes]) if meshes else np.zeros((1, 3))
    lo, hi = allp.min(0), allp.max(0)
    ctr = np.array(target) if target is not None else (lo + hi) / 2
    rad = np.linalg.norm(hi - lo) / 2
    dist = dist or rad / math.tan(math.radians(fov / 2)) * 1.05
    a, e = math.radians(az), math.radians(el)
    eye = ctr + dist * np.array([math.sin(a) * math.cos(e), math.sin(e), math.cos(a) * math.cos(e)])
    fwd = (ctr - eye) / np.linalg.norm(ctr - eye)
    right = np.cross(fwd, [0, 1, 0])
    right /= np.linalg.norm(right)
    up = np.cross(right, fwd)
    f = 1.0 / math.tan(math.radians(fov / 2))
    sunv = np.array(sun, float)
    sunv /= np.linalg.norm(sunv)

    img = np.zeros((H, W, 3))
    yy = np.linspace(0, 1, H)[:, None]
    img[:] = (np.array([0.62, 0.70, 0.82]) * (1 - yy) + np.array([0.86, 0.88, 0.90]) * yy)[:, None, :][:, 0][:, None, :]
    zbuf = np.full((H, W), np.inf)

    def project(p):
        d = p - eye
        x, y, z = d @ right, d @ up, d @ fwd
        return np.stack([W / 2 + x / z * f * H / 2, H / 2 - y / z * f * H / 2, z], -1)

    if ground:
        gy = lo[1]
        g = rad * 3
        quad = np.array([[ctr[0] - g, gy, ctr[2] - g], [ctr[0] + g, gy, ctr[2] - g], [ctr[0] + g, gy, ctr[2] + g],
                         [ctr[0] - g, gy, ctr[2] + g]])
        gm = (np.array([quad[[0, 1, 2]], quad[[0, 2, 3]]]), None, None, (0.36, 0.52, 0.27))
        _raster_tris(img, zbuf, project(gm[0]), np.tile([[0, 1, 0]], (2, 3, 1)).astype(float), None, None,
                     np.array(gm[3]), sunv, 0.0, ground_grid=(gm[0], eye))

    for slot, pts, tri, uv in meshes:
        key = slot.split(":")[0]
        tex = (slot_tex or {}).get(key)
        col = np.array((slot_col or {}).get(key, (0.7, 0.7, 0.7)), float)
        nrm, _ = soft_normals(pts, tri, 70.0 if key in ("glow", "shield") else 40.0)
        tris3 = pts[tri]
        _raster_tris(img, zbuf, project(tris3), nrm, uv, tex, col, sunv, 0.35 if tex is not None else 0.2,
                     emissive=key.endswith("glow") or key in ("plasma", "dome", "glow_red"))
    return Image.fromarray((np.clip(img, 0, 1) ** (1 / 1.1) * 255).astype(np.uint8))


def _raster_tris(img, zbuf, sp, nrm, uv, tex, col, sunv, spec, emissive=False, ground_grid=None):
    H, W = zbuf.shape
    for t in range(len(sp)):
        p = sp[t]
        if (p[:, 2] <= 0.05).any():
            continue
        x0, x1 = int(max(0, math.floor(p[:, 0].min()))), int(min(W - 1, math.ceil(p[:, 0].max())))
        y0, y1 = int(max(0, math.floor(p[:, 1].min()))), int(min(H - 1, math.ceil(p[:, 1].max())))
        if x1 < x0 or y1 < y0:
            continue
        (ax, ay, az), (bx, by, bz), (cx, cy, cz) = p
        den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
        if abs(den) < 1e-9:
            continue
        X, Y = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        w0 = ((by - cy) * (X - cx) + (cx - bx) * (Y - cy)) / den
        w1 = ((cy - ay) * (X - cx) + (ax - cx) * (Y - cy)) / den
        w2 = 1 - w0 - w1
        inside = (w0 >= -1e-6) & (w1 >= -1e-6) & (w2 >= -1e-6)
        if not inside.any():
            continue
        # perspective-correct weights
        iz = w0 / az + w1 / bz + w2 / cz
        z = 1.0 / iz
        sub = zbuf[y0:y1 + 1, x0:x1 + 1]
        m = inside & (z < sub)
        if not m.any():
            continue
        pw = np.stack([w0 / az, w1 / bz, w2 / cz], -1) * z[..., None]
        n = pw @ nrm[t]
        n /= np.maximum(np.linalg.norm(n, axis=-1, keepdims=True), 1e-9)
        lam = np.clip(n @ sunv, 0, 1)
        if tex is not None and uv is not None:
            u = pw @ uv[t][:, 0]
            v = pw @ uv[t][:, 1]
            th, tw = tex.shape[:2]
            tx = (np.floor((u % 1.0) * tw).astype(int)) % tw
            ty = (np.floor(((1 - v) % 1.0) * th).astype(int)) % th
            s = tex[ty, tx]
            base, mask = s[..., :3], s[..., 3]
            if emissive:
                c = base
            else:
                c = base * (0.42 + 0.75 * lam[..., None]) + spec * mask[..., None] * (lam[..., None] ** 8)
        else:
            if emissive:
                c = np.broadcast_to(col, n.shape)
            else:
                c = col * (0.42 + 0.75 * lam[..., None])
        if ground_grid is not None:
            c = np.broadcast_to(col * (0.55 + 0.45 * lam[..., None]), n.shape).copy()
        region = img[y0:y1 + 1, x0:x1 + 1]
        region[m] = c[m]
        sub[m] = z[m]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("module")
    ap.add_argument("builder")
    ap.add_argument("out")
    ap.add_argument("--az", type=float, default=35.0)
    ap.add_argument("--el", type=float, default=18.0)
    ap.add_argument("--size", default="1200x800")
    ap.add_argument("--tex", default=os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
    ap.add_argument("--lod", type=int, default=0)
    ap.add_argument("--dist", type=float, default=0.0)
    ap.add_argument("--state", default="")
    a = ap.parse_args()
    stub_maya()
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    mod = importlib.import_module(a.module)
    P = getattr(mod, a.builder)(a.lod, **({"state": a.state} if a.state else {}))
    meshes = triangles(P)
    slot_tex = {k: load_tex(a.tex, v) for k, v in getattr(mod, "PREVIEW_TEX", {}).items()}
    W, H = (int(x) for x in a.size.split("x"))
    im = render(meshes, (W, H), a.az, a.el, a.dist or None, slot_tex=slot_tex, slot_col=getattr(mod, "PREVIEW_COL", {}))
    im.save(a.out)
    print(a.out, sum(len(m[2]) for m in meshes), "triangles")


if __name__ == "__main__":
    main()
