"""Render a skeletal appearance posed by an animation at a few frames (headless Maya), for eyeballing imports
and exports. Run: python examples/anim_visual.py <animation.ans> <out_prefix> [frames...]
The appearance defaults to appearance/hum_m.sat (TITAN_ANIM_SAT overrides); a .ans path without a drive
resolves under TITAN_DATA_ROOT."""
import asyncio
import base64
import json
import os
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ANS = sys.argv[1]
PREFIX = sys.argv[2]
FRAMES = [float(f) for f in sys.argv[3:]] or [0.0]
SAT = os.environ.get("TITAN_ANIM_SAT", "appearance/hum_m.sat")

SETUP = r'''
import maya.cmds as cmds, maya.mel as mel, os
data = os.environ.get('TITAN_DATA_ROOT', 'D:/titan/data/sku.0/sys.client/compiled/game').replace(chr(92), '/')
anim = args['ans'] if ':' in args['ans'] else data + '/' + args['ans']
cmds.file(new=True, force=True)
mel.eval('importSat -i "%s"' % (data + '/' + args['sat']))
mel.eval('importAnimation -i "%s"' % anim)
meshes = [m for m in cmds.ls(type='mesh', long=True) if not cmds.getAttr(m + '.intermediateObject')]
# meshes the import left without a shading group (customisable skin shaders) would not render at all
unshaded = [m for m in meshes if not cmds.listConnections(m, type='shadingEngine')]
if unshaded:
    mat = cmds.shadingNode('lambert', asShader=True, name='anim_visual_grey')
    cmds.setAttr(mat + '.color', 0.62, 0.55, 0.5, type='double3')
    sg = cmds.sets(renderable=True, noSurfaceShader=True, empty=True, name=mat + 'SG')
    cmds.connectAttr(mat + '.outColor', sg + '.surfaceShader')
    cmds.sets(unshaded, edit=True, forceElement=sg)
# skin textures are near-white: the game tints them with the character's skin palette - do the same here
for f in cmds.ls(type='file'):
    if any(k in cmds.getAttr(f + '.fileTextureName') for k in ('_body', '_head', '_face')):
        cmds.setAttr(f + '.colorGain', 0.86, 0.64, 0.5, type='double3')
frame_on = '|'.join(meshes[0].split('|')[:3]) if meshes else ''      # e.g. |all_b|l0 - the LOD 0 meshes
result = {'meshes': len(meshes), 'joints': len(cmds.ls(type='joint')), 'target': frame_on,
          'range': [cmds.playbackOptions(q=True, min=True), cmds.playbackOptions(q=True, max=True)]}
'''


async def main():
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            args = json.dumps({"ans": ANS, "sat": SAT})
            res = await s.call_tool("maya_python", {"code": "args = " + args + "\n" + SETUP})
            text = "\n".join(getattr(c, "text", "") for c in res.content)
            if '"ok": false' in text:
                print(text[:1500]); return
            setup = json.loads(text).get("result")
            print(setup)
            for f in FRAMES:
                await s.call_tool("maya_python", {"code": f"cmds.currentTime({f})"})
                res = await s.call_tool("maya_render", {"target": setup["target"], "view": "perspective", "azimuth": float(os.environ.get("ANIM_VISUAL_AZIMUTH", "160")), "elevation": 8,
                                                        "width": 520, "height": 640})
                img = next((c for c in res.content if getattr(c, "type", "") == "image"), None)
                if img is None:
                    print("frame", f, "render failed:", "\n".join(getattr(c, "text", "") for c in res.content)[:400])
                    continue
                out = f"{PREFIX}_f{int(f):03d}.png"
                open(out, "wb").write(base64.b64decode(img.data))
                print("wrote", out)


asyncio.run(main())
