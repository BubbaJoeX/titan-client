"""Build the orbital station modelled on Nova Orion (maya/swg_mcp/station.py) and make it spawnable: .pob + cells +
floors, exterior .lod with the overhead-map footprint, terrain flatten layer + footprint + template, rail checks,
review renders (aerial, deck plans, interiors).

Run: python examples/make_station.py   ->  /scene objectCreate object/building/titan/shared_titan_orbital_station.iff x z 0"""
import asyncio
import base64
import json
import os
import sys
import tempfile
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

NAME = "titan_orbital_station"
EXPORT = os.environ.get("TITAN_EXPORT_ROOT", "D:/exported")
RENDERS = Path(os.environ.get("STATION_RENDER_DIR", os.path.join(tempfile.gettempdir(), "swg_station")))

CODE = r'''
import importlib, swg_mcp.pob_builder as pb, swg_mcp.filler as fl, swg_mcp.filler_plan as fp, swg_mcp.station as st
for m in (pb, fl, fp, st):
    importlib.reload(m)
cmds.scriptEditorInfo(suppressInfo=True, suppressResults=True, suppressWarnings=True)
result = st.build(args['name'], args['export_root'])
'''


def text(res):
    return "\n".join(getattr(c, "text", "") for c in res.content)


async def main():
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            res = await s.call_tool("maya_python", {"code": "args = " + json.dumps({"name": NAME, "export_root": EXPORT}) + "\n" + CODE,
                                                    "timeout_seconds": 2400})
            data = json.loads(text(res))
            if not data.get("ok"):
                print(data.get("error"), (data.get("traceback") or "")[-2500:])
                return
            out = data["result"]
            print({k: out[k] for k in ("cells", "rooms", "portals", "decks")})
            sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
            from swg_maya_mcp import iff, rails
            pob = Path(EXPORT) / f"appearance/{NAME}.pob"
            print("lod", iff.write_exterior_lod(EXPORT, pob))
            tpl = json.loads(text(await s.call_tool("swg_building_template", {"name": NAME, "feather": 12.0})))
            print("template", tpl.get("template", {}).get("path"), "\nspawn", tpl.get("spawn"))
            chk = rails.check(pob, EXPORT)
            print("rails ok", chk["ok"], chk["issues"][:6], "window portals", chk["window_portals"])
            RENDERS.mkdir(parents=True, exist_ok=True)
            views = [("aerial", {"view": "perspective", "azimuth": 35, "elevation": 35}),
                     ("deck_concourse", {"view": "cutaway", "cut_height": 4.0}),
                     ("deck_command", {"view": "cutaway", "cut_height": 20.0}),
                     ("rotunda", {"view": "eye", "eye": [0, 1.7, -9], "look_at": [0, 1.5, 10], "fov": 85}),
                     ("stairs", {"view": "eye", "eye": [-6, 1.7, -15], "look_at": [-6, 6, -28], "fov": 85})]
            for nm, kw in views:
                img = await s.call_tool("maya_render", {"width": 1000, "height": 700, **kw})
                for c in img.content:
                    if getattr(c, "data", None):
                        (RENDERS / f"{NAME}_{nm}.png").write_bytes(base64.b64decode(c.data))
            print("renders in", RENDERS)


asyncio.run(main())
