"""Author a short test emote on the stock human body in headless Maya and export it with SwgAns: on top of the
stock breathing idle, the right hand eases up into a salute and back (quaternion blend), with two head nods and a
slight torso turn layered on. 90 frames at 30 fps.

Run: python examples/make_test_animation.py [out.ans]
(default <export root>/appearance/animation/titan_test_salute.ans)"""
import asyncio
import json
import os
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"), "appearance/animation/titan_test_salute.ans").replace("\\", "/")

CODE = r'''
import maya.cmds as cmds, maya.mel as mel, math, os
import maya.api.OpenMaya as om2
data = os.environ.get('TITAN_DATA_ROOT', 'D:/titan/data/sku.0/sys.client/compiled/game').replace(chr(92), '/')
cmds.file(new=True, force=True)
mel.eval('importSat -i "%s/appearance/hum_m.sat"' % data)
# base: the stock breathing idle (keys every frame after import), so the body moves like a stock emote
mel.eval('importAnimation -i "%s/appearance/animation/all_b_idl_breathe_normally.ans"' % data)
END = 90

def joint(name):
    return [j for j in cmds.ls(type='joint', long=True) if j.split('|')[-1] == name][0]

def smooth(a, b, f):                   # 0 -> 1 eased between frames a and b
    t = min(1.0, max(0.0, (f - a) / float(b - a)))
    return t * t * (3.0 - 2.0 * t)

def weight(f):                          # salute: ease in 10-24, hold, ease out 62-80
    return smooth(10, 24, f) * (1.0 - smooth(62, 80, f))

def nod(f):                             # two head nods inside the hold, degrees
    if 30 <= f <= 54:
        return 14.0 * math.sin(math.pi * (f - 30) / 12.0) ** 2
    return 0.0

# salute target: offsets from the skeleton bind (degrees), reached at full weight
TARGET = {'rArm': (-10, -25, -95), 'rForeArm': (0, -105, 0), 'rWrist': (0, 0, 20)}
LAYER = {'Head': lambda f: (0, 0, nod(f)), 'spine2': lambda f: (0, 10 * weight(f), 0)}

def euler(j, f):
    return [math.radians(v) for v in cmds.getAttr(j + '.rotate', time=f)[0]]

baked = {}
for name in list(TARGET) + list(LAYER):
    j = joint(name)
    order = cmds.getAttr(j + '.rotateOrder')
    base = [euler(j, f) for f in range(END + 1)]
    bind = [math.degrees(v) for v in cmds.getAttr(j + '.swgBindRotate')[0]]
    out, prev = [], None
    for f in range(END + 1):
        idle = om2.MEulerRotation(base[f][0], base[f][1], base[f][2], order)
        if name in TARGET:
            tgt = om2.MEulerRotation(*[math.radians(b + d) for b, d in zip(bind, TARGET[name])], order)
            q = om2.MQuaternion.slerp(idle.asQuaternion(), tgt.asQuaternion(), weight(f))
        else:
            off = om2.MEulerRotation(*[math.radians(v) for v in LAYER[name](f)], order)
            q = off.asQuaternion() * idle.asQuaternion()      # offset applied in the joint's parent frame
        e = q.asEulerRotation(); e.reorderIt(order)
        if prev is not None:
            e.setToClosestSolution(prev)
        prev = e
        out.append([math.degrees(v) for v in (e.x, e.y, e.z)])
    baked[j] = out
for j, rows in baked.items():
    cmds.cutKey(j, attribute=['rotateX', 'rotateY', 'rotateZ'], clear=True)
    for f, r in enumerate(rows):
        for axis, v in zip('XYZ', r):
            cmds.setKeyframe(j, attribute='rotate' + axis, time=f, value=v)
cmds.playbackOptions(minTime=0, maxTime=END, animationStartTime=0, animationEndTime=END)

out = args['out']
os.makedirs(os.path.dirname(out), exist_ok=True)
cmds.select(cmds.ls(type='joint'), r=True)
cmds.file(out, force=True, exportSelected=True, type='SwgAns', options=args.get('options', ''))
result = {'out': out, 'bytes': os.path.getsize(out)}
'''


async def main():
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            run_args = {"out": OUT, "options": os.environ.get("ANS_EXPORT_OPTIONS", "")}
            res = await s.call_tool("maya_python", {"code": "args = " + json.dumps(run_args) + "\n" + CODE})
            text = "\n".join(getattr(c, "text", "") for c in res.content)
            data = json.loads(text)
            if not data.get("ok"):
                print(text[-3000:])
                return
            print(data["result"])
            notes = [l for l in str(data.get("stderr", "")).splitlines() if l.startswith("ANS: export") or "WARN" in l or "channels" in l]
            print("\n".join(dict.fromkeys(notes)))


asyncio.run(main())
