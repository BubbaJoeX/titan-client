"""Screenshots of the POI props (examples/make_poi_props.py) in the offline client, through the DevBridge.

  poi_props_shots.py <out dir> [planet ...]

Per planet: the four props in a row 8 m ahead of the player (facing it), a wide shot of the row and a framed
shot of each prop from 30 degrees above front-left; then a contact sheet poi_<planet>_sheet.jpg. The client
runs with a private LOCALAPPDATA so its bridge token stays off other sessions' default token file."""
import ctypes
import json
import os
import re
import sys
import tempfile
import time
from ctypes import wintypes
from pathlib import Path

PRIVATE = Path(os.environ.get("POI_LOCALAPPDATA", os.path.join(tempfile.gettempdir(), "swg_poi_props_client")))
PRIVATE.mkdir(parents=True, exist_ok=True)
os.environ["LOCALAPPDATA"] = str(PRIVATE)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import client  # noqa: E402

PORT = int(os.environ.get("POI_PORT", "7061"))
LISTING = Path(os.environ.get("POI_PROPS_RENDER_DIR", os.path.join(tempfile.gettempdir(), "swg_poi_props"))) / "props.json"
u = ctypes.windll.user32


def bridge():
    try:
        b = client.ClientBridge(PORT)
        b.request("ping", timeout=5)
        return b
    except Exception:
        print(client.launch(PORT, extra_args=["-s", "ClientGraphics", "windowed=1", "-s", "Direct3d9", "antiAlias=0",
                                              "screenShotBackBuffer=1"]), flush=True)
        return client.ClientBridge(PORT)


b = bridge()


def ex(line):
    return b.request("exec", line=line).get("result") or ""


def settle(frames=30):
    f0 = b.request("state")["result"]["frame"]
    t = time.time()
    while b.request("state")["result"]["frame"] < f0 + frames and time.time() - t < 30:
        time.sleep(0.2)


def client_hwnd():
    pid = json.loads(client.pinned_token_file(PORT).read_text())["pid"]
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(h, _):
        p = wintypes.DWORD()
        u.GetWindowThreadProcessId(h, ctypes.byref(p))
        if p.value == pid and u.IsWindowVisible(h):
            found.append(h)
        return True
    u.EnumWindows(cb, 0)
    return found[0] if found else None


def shot(out, name):
    from PIL import Image
    for _ in range(6):
        h = client_hwnd()
        if h:
            if u.IsIconic(h):
                u.ShowWindow(h, 4)
            u.SetWindowPos(h, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010 | 0x0040)
            settle(20)
        r = b.request("screenshot", path=str(out / f"_{name}").replace("\\", "/"))
        if h:
            u.SetWindowPos(h, -2, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010)
        f = Path(r["result"]["file"])
        if not f.exists():
            settle(10)
            continue
        img = Image.open(f).convert("RGB")
        f.unlink()
        if max(e[1] for e in img.getextrema()) > 10:
            dst = out / f"{name}.jpg"
            img.save(dst, quality=90)
            return dst
        settle(10)
    raise RuntimeError(f"{name}: black frames")


def ensure_scene():
    st = b.request("state")["result"]
    if not st.get("player"):
        b.request("loadscene", avatar="object/creature/player/shared_human_male.iff")
        t = time.time()
        while time.time() - t < 180:
            st = b.request("state")["result"]
            if st.get("player") and not st.get("scene_loading"):
                break
            time.sleep(1)
        settle(60)
    for line in ("/scene drawNetworkIds 0", "/scene drawObjectNames 0", "/scene setTime 0.42", "/devtest target clear"):
        ex(line)


def main(out, planets):
    from PIL import Image, ImageDraw
    out.mkdir(parents=True, exist_ok=True)
    props = json.loads(LISTING.read_text())
    ensure_scene()
    report = {}
    for planet in planets:
        rows = [m for m in props if m["planet"] == planet]
        ids, xs = [], [-9.0, -3.0, 3.0, 9.0]
        for m, x in zip(rows, xs):
            o = ex(f"/scene objectCreate {m['template']} {x} 8 180")
            found = re.findall(r"object (\d+)", o)
            if not found:
                raise RuntimeError(f"{m['template']}: {o}")
            ids.append(found[0])
        settle(60)
        ex("/devtest target clear")
        files = []
        b.request("camera", pivot=[0.0, 1.5, 8.0], distance=17.0, yaw=0, pitch=10)
        settle(20)
        files.append(shot(out, f"poi_{planet}_row"))
        for m, x in zip(rows, xs):
            h = m["size"][1]
            b.request("camera", pivot=[x, max(0.8, h * 0.45), 8.0], distance=max(3.5, max(m["size"]) * 1.7),
                      yaw=-25, pitch=18)
            settle(20)
            files.append(shot(out, m["name"]))
        b.request("camera", mode="chase")
        for i in ids:
            ex(f"/scene objectDelete {i}")
        # contact sheet: the row on top, the four props below
        sheet = Image.new("RGB", (1920, 1080 // 2 + 270), (20, 20, 20))
        sheet.paste(Image.open(files[0]).resize((960, 540)), (480, 0))
        d = ImageDraw.Draw(sheet)
        for k, f in enumerate(files[1:]):
            sheet.paste(Image.open(f).crop((240, 0, 1680, 810)).resize((480, 270)), (k * 480, 540))
            d.text((k * 480 + 6, 544), rows[k]["name"], fill=(255, 255, 255))
        d.text((486, 6), planet, fill=(255, 255, 255))
        sheet.save(out / f"poi_{planet}_sheet.jpg", quality=90)
        report[planet] = [str(f) for f in files]
        print(planet, "ok", flush=True)
    (out / "poi_shots.json").write_text(json.dumps(report, indent=1))


if __name__ == "__main__":
    main(Path(sys.argv[1]), sys.argv[2:] or ["tatooine", "corellia", "naboo", "lok", "endor", "yavin4", "rori",
                                             "dathomir", "dantooine", "talus"])
