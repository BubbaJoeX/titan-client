"""Build the Battle of Naboo heroic set (maya/swg_mcp/naboo_battle.py; design: docs/content/battle-of-naboo/README.md)
into the export tree:

  static pieces (MTT hull and its moving parts, AAT turret ...): built in the shared headless Maya, three detail
      levels each, wrapped in appearance/lod/<name>.lod with collision boxes where they block movement
  AAT hull: a skeletal appearance written here without Maya - a one-joint skeleton, the rigidly skinned mesh
      (three .mgn detail levels in an .lmg) and the .sat, with the stock vehicle hardpoints (player, passenger1,
      ground_effect, engine_sound) plus the turret, launcher and laser hardpoints

    python examples/naboo_battle_materials.py D:/exported          (system Python: numpy + Pillow)
    python examples/make_naboo_battle.py aat                        (system Python: the AAT, no Maya)
    .venv\\Scripts\\python.exe examples/make_naboo_battle.py [piece ...]   (venv: mcp; the Maya pieces)

Takes D:/titan/.locks/maya for the Maya part (see the swg-coordination memory note). A summary lands in
%TEMP%/titan_naboo_battle/assets.json."""
from __future__ import annotations

import asyncio
import json
import math
import os
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
from swg_maya_mcp import iff, wearable  # noqa: E402


def _stub_maya():
    """naboo_battle only needs maya.* at export time (inside Maya); stub it to build geometry here."""
    import types
    for m in ("maya", "maya.cmds", "maya.mel", "maya.api", "maya.api.OpenMaya"):
        sys.modules.setdefault(m, types.ModuleType(m))
    sys.modules["maya"].cmds = sys.modules["maya.cmds"]
    sys.modules["maya"].mel = sys.modules["maya.mel"]
    sys.path.insert(0, str(HERE.parent / "maya"))


_stub_maya()
from swg_mcp import naboo_battle as nb  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
OUT = Path(tempfile.gettempdir()) / "titan_naboo_battle"
LOCK = Path("D:/titan/.locks/maya")

# Maya-space collision boxes ((x0, y0, z0), (x1, y1, z1)) for pieces that block movement; parts have none
BOXES = {
    "catapult": [((-1.35, 0.0, -2.9), (1.35, 2.6, 2.4))],
    "mtt": [((-5.5, 0.9, -15.0), (5.5, 10.0, 3.6)), ((-3.5, 5.0, 0.2), (3.5, 12.6, 10.5)),
            ((-5.3, 0.9, 3.6), (5.3, 5.0, 14.9))],
}
LOD_RANGES = {"shield_dome": (600.0, 1500.0), "shield_generator": (50.0, 120.0), "catapult": (45.0, 110.0),
              "hand_shield": (25.0, 60.0), "booma": (40.0,), "mtt": (90.0, 220.0), "mtt_lid": (90.0, 220.0), "mtt_chin": (60.0, 150.0), "mtt_rack": (80.0, 200.0),
              "mtt_rack_empty": (80.0, 200.0), "aat_turret": (45.0, 120.0), "rally_marker": ()}

RELOAD = ("import importlib, swg_mcp.pob_builder as pb, swg_mcp.furniture as fu, swg_mcp.naboo_battle as nb\n"
          "for m in (pb, fu, nb):\n    importlib.reload(m)\n")


# ============================================================================
# the AAT hull: skeletal appearance, no Maya
# ============================================================================

AAT_SKT = "appearance/skeleton/titan_hrc_nboo_aat.skt"
AAT_SAT = "appearance/titan_hrc_nboo_aat.sat"
AAT_LMG = "appearance/mesh/titan_hrc_nboo_aat.lmg"


def _engine(p):
    return (-p[0], p[1], p[2])


def skinned_mesh(P, skeleton, joint="root", hardpoints=()):
    """A read_mgn-shaped dict from an F's accumulators: every vertex rigidly bound to `joint`; soft normals per
    slot (nb.SOFT_ANGLE); positions/normals mirrored to engine space, triangles wound so cross(b - a, c - a)
    follows the normal (as stock meshes are), V flipped like the static exporter. Needs numpy (system Python)."""
    import geo_preview
    positions, pos_ix = [], {}
    normals, nrm_ix = [], {}

    def pid(p):
        k = tuple(round(c, 5) for c in p)
        if k not in pos_ix:
            pos_ix[k] = len(positions)
            positions.append(k)
        return pos_ix[k]

    def nid(n):
        k = tuple(round(c, 4) for c in n)
        if k not in nrm_ix:
            nrm_ix[k] = len(normals)
            normals.append(k)
        return nrm_ix[k]

    shaders = []
    for slot, pts, tri, uv in geo_preview.triangles(P):
        corner_n, face_n = geo_preview.soft_normals(pts, tri, nb.SOFT_ANGLE.get(slot, 70.0))
        verts, vix, tris = [], {}, []
        for t in range(len(tri)):
            corners = []
            for j in range(3):
                pe = _engine(pts[tri[t][j]])
                ne = _engine(corner_n[t][j])
                key = (pid(pe), nid(ne), round(float(uv[t][j][0]), 5), round(1.0 - float(uv[t][j][1]), 5))
                if key not in vix:
                    vix[key] = len(verts)
                    verts.append(key)
                corners.append(vix[key])
            a, b, c = (positions[verts[k][0]] for k in corners)
            fe = _engine(face_n[t])
            cr = ((b[1] - a[1]) * (c[2] - a[2]) - (b[2] - a[2]) * (c[1] - a[1]),
                  (b[2] - a[2]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[2] - a[2]),
                  (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]))
            if cr[0] * fe[0] + cr[1] * fe[1] + cr[2] * fe[2] < 0:
                corners = [corners[0], corners[2], corners[1]]
            tris.append((-1, *corners))
        shaders.append({"name": f"shader/{nb.SLOT_TEX[slot]}.sht", "pidx": [v[0] for v in verts],
                        "nidx": [v[1] for v in verts], "dot3idx": None, "colors": None, "tc_dims": [2],
                        "tc_sets": [[c for v in verts for c in (v[2], v[3])]],
                        "prims": [{"type": "ITL", "tris": tris}]})
    hps = [{"name": n, "parent": joint, "rotation": (1.0, 0.0, 0.0, 0.0), "position": _engine(p)} for n, p in hardpoints]
    return {"max_transforms_per_vertex": 1, "max_transforms_per_shader": 1, "skeletons": [skeleton],
            "transforms": [joint], "positions": positions, "weights": [[(0, 1.0)] for _ in positions],
            "normals": normals, "dot3": None, "hardpoints": {"static": hps or None, "dynamic": None},
            "blend_targets": [], "occlusion_zones": [], "fully_occluded": None, "zone_combinations": [],
            "zones_this_occludes": [], "occlusion_layer": 0, "shaders": shaders, "extra": {}}


def build_aat(root=EXPORT):
    """titan_hrc_nboo_aat.sat -> .lmg -> three .mgn levels on a one-joint skeleton."""
    (root / AAT_SKT).parent.mkdir(parents=True, exist_ok=True)
    # root + joint2 like the stock vehicle skeletons (pv_speeder_bike, pv_landspeeder_luke); the mesh rides root
    (root / AAT_SKT).write_bytes(wearable.write_skt([{"name": "root", "parent": -1},
                                                     {"name": "joint2", "parent": 0}]))
    mgns, faces = [], []
    for lod in range(nb.LODS):
        P = nb.aat_hull(lod)
        hp = dict(P.hardpoints)
        extra = [("player", hp["seat_driver"]), ("passenger1", hp["seat_gunner"]), ("ground_effect", hp["hp_dust"]),
                 ("engine_sound", (0.0, 1.8, -3.0)), ("muzzle", hp["muzzle_launcher_2"])]
        m = skinned_mesh(P, AAT_SKT, "root", list(P.hardpoints) + extra)
        rel = f"appearance/mesh/titan_hrc_nboo_aat_l{lod}.mgn"
        (root / rel).parent.mkdir(parents=True, exist_ok=True)
        data = wearable.write_mgn(m)
        back = wearable.read_mgn(data)                     # the reader is the engine's loader, field for field
        assert len(back["positions"]) == len(m["positions"]) and len(back["shaders"]) == len(m["shaders"])
        (root / rel).write_bytes(data)
        mgns.append(rel)
        faces.append(sum(len(s["prims"][0]["tris"]) for s in m["shaders"]))
    (root / AAT_LMG).write_bytes(wearable.write_lmg(mgns))
    (root / AAT_SAT).write_bytes(wearable.write_sat([AAT_LMG], [(AAT_SKT, "")], create_animation_controller=True,
                                                    lat=[(AAT_SKT, "appearance/lat/monstrosity.lat")]))
    return {"name": "aat", "sat": AAT_SAT, "lmg": AAT_LMG, "mgns": mgns, "triangles": faces,
            "hardpoints": [h for h, _ in nb.aat_hull(0).hardpoints]}


# ============================================================================
# static pieces through Maya
# ============================================================================

def text(res):
    return "\n".join(getattr(c, "text", "") for c in res.content)


async def call(s, code, args):
    res = await s.call_tool("maya_python", {"code": "args = " + json.dumps(args) + "\n" + RELOAD + code,
                                            "timeout_seconds": 900})
    data = json.loads(text(res))
    if not data.get("ok"):
        raise RuntimeError(f"{args}: {data.get('error')} {(data.get('traceback') or '')[-1500:]}")
    return data["result"]


def finish(out):
    name = out["name"]
    boxes = BOXES.get(name, [])
    b = out["bounds"]
    lod = iff.write_static_lod(EXPORT, out["apt"], boxes, len(boxes) > 1, None, bounds=[b[:3], b[3:]],
                               lods=out["lods"], lod_ranges=LOD_RANGES.get(name, (60.0, 160.0)))
    return {"name": name, "apt": out["apt"], "lod": lod["lod"], "collision": lod["collision"], "faces": out["faces"],
            "hardpoints": [h[0] for h in out.get("hardpoints", [])],
            "size": [round(b[3] - b[0], 2), round(b[4] - b[1], 2), round(b[5] - b[2], 2)]}


def take_lock():
    owner = LOCK / "owner.txt"
    for _ in range(120):
        try:
            LOCK.mkdir(parents=True)
            owner.write_text(f"session: Battle of Naboo heroic (90873d83)\ntask: make_naboo_battle.py export\n"
                             f"taken: {time.strftime('%Y-%m-%dT%H:%M:%S')}\n")
            return True
        except FileExistsError:
            print("maya lock held:", owner.read_text() if owner.exists() else "?")
            time.sleep(30)
    return False


async def maya_pieces(names):
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    p = StdioServerParameters(command=sys.executable, args=[str(HERE.parent / "run_server.py")], env=dict(os.environ))
    made = []
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            for name in names:
                out = await call(s, "result = nb.build(args['name'], args['export_root'])",
                                 {"name": name, "export_root": str(EXPORT).replace("\\", "/")})
                m = finish(out)
                made.append(m)
                print(f"{name:16s} faces {m['faces']} size {m['size']} {m['collision']}")
            await s.call_tool("maya_scene", {"action": "new"})
    return made


def _has_numpy():
    try:
        import numpy  # noqa: F401
        return True
    except ImportError:
        print("no numpy here: build the AAT with the system Python (python examples/make_naboo_battle.py aat)")
        return False


def main(argv):
    no_maya = "--no-maya" in argv
    names = [a for a in argv if not a.startswith("--")]
    statics = [n for n in (names or nb.PIECES) if n in nb.PIECES]
    OUT.mkdir(parents=True, exist_ok=True)
    report = {"export_root": str(EXPORT), "pieces": [], "aat": None}
    if "aat" in names or (not names and _has_numpy()):
        report["aat"] = build_aat()
        print("aat", report["aat"]["triangles"], "triangles per level")
    if statics and not no_maya:
        if not take_lock():
            raise SystemExit("could not take the maya lock")
        try:
            report["pieces"] = asyncio.run(maya_pieces(statics))
        finally:
            for f in LOCK.glob("*"):
                f.unlink()
            LOCK.rmdir()
    (OUT / "assets.json").write_text(json.dumps(report, indent=1))
    print("report:", OUT / "assets.json")


if __name__ == "__main__":
    main(sys.argv[1:])
