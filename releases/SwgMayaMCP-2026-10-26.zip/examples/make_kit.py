"""Build the modular worldbuilding kit (maya/swg_mcp/kit.py) for every theme and make each piece spawnable:
mesh + .lod with collision (box / composite boxes like the stock gates) and radar footprint + a static object
template object/static/structure/<theme>/shared_<prefix>_imprv_<piece>_sNN.iff derived from the stock
corl_imprv_wall_4x16_s01 template. Suffixes skip every stock sNN, so no stock piece is shadowed.
Review renders (one row per theme) land in %TEMP%/swg_kit.

Run: python examples/make_kit.py [theme ...]   ->  /scene objectCreate object/static/structure/<dir>/shared_<name>.iff x z h"""
import asyncio
import base64
import json
import os
import sys
import tempfile
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import iff  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
CLIENT = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
RENDERS = Path(os.environ.get("KIT_RENDER_DIR", os.path.join(tempfile.gettempdir(), "swg_kit")))
BASE_TEMPLATE = CLIENT / "object/static/structure/corellia/shared_corl_imprv_wall_4x16_s01.iff"
THEMES = ["corellia", "naboo", "tatooine", "dantooine", "dathomir", "endor", "lok", "rori", "talus", "yavin"]
PIECES = ["wall_4x8", "wall_4x16", "wall_4x32", "wall_curve", "wall_low_1x8", "column", "pillar_tall", "pillar_ruined",
          "gate_sm", "gate_wide", "arch_sm", "arch_lg", "fence_4m", "fence_8m", "boundary_post", "beam_overhead",
          "pergola", "gazebo", "planter_box", "fountain_round", "brazier", "platform_8x8", "stair_small", "bridge_sm",
          "walkway_elevated", "stair_medium", "stair_large", "landing_4x4", "walkway_corner", "walkway_t",
          "walkway_cross", "walkway_end", "walkway_ramp", "walkway_stair", "wall_end_cap", "wall_coping_8",
          "column_cap"]      # = kit.PIECES: every stock structure type, in every planet's style
PREFIX = {"corellia": "corl", "naboo": "nboo", "tatooine": "tato", "dantooine": "dant", "dathomir": "dath",
          "endor": "endr", "lok": "lok", "rori": "rori", "talus": "talus", "yavin": "yavn"}

RELOAD = "import importlib, swg_mcp.pob_builder as pb, swg_mcp.kit as kit\nfor m in (pb, kit):\n    importlib.reload(m)\n"


def text(res):
    return "\n".join(getattr(c, "text", "") for c in res.content)


def free_suffix(theme, piece):
    """First sNN with neither a stock template nor a stock appearance of that name."""
    for n in range(1, 100):
        name = f"{PREFIX[theme]}_imprv_{piece}_s{n:02d}"
        if not (CLIENT / f"object/static/structure/{theme}/shared_{name}.iff").exists() and \
                not (CLIENT / f"appearance/thm_{name}.apt").exists():
            return n
    raise RuntimeError(f"no free suffix for {theme} {piece}")


def finish_piece(theme, piece, out):
    """Host side after kit.build: the .lod (collision boxes, floor, radar, hardpoints) and the static template."""
    b = out["bounds"]
    lod = iff.write_static_lod(EXPORT, out["apt"], out["boxes"], out["composite"], out["footprint"],
                               floor=out.get("floor"), bounds=[b[:3], b[3:]])
    tpl = EXPORT / f"object/static/structure/{out['dir']}/shared_{out['name']}.iff"
    iff.derive_template(BASE_TEMPLATE, tpl, {"appearanceFilename": out["apt"]})
    return {"theme": theme, "piece": piece, "name": out["name"],
            "template": f"object/static/structure/{out['dir']}/shared_{out['name']}.iff",
            "collision": lod["collision"], "boxes": lod["boxes"],
            "size": [round(b[3] - b[0], 2), round(b[4] - b[1], 2), round(b[5] - b[2], 2)]}


async def main(themes):
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    RENDERS.mkdir(parents=True, exist_ok=True)
    made = []
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            for theme in themes:
                for piece in PIECES:
                    suffix = free_suffix(theme, piece)
                    args = {"theme": theme, "piece": piece, "export_root": str(EXPORT).replace("\\", "/"), "suffix": suffix}
                    res = await s.call_tool("maya_python", {"code": "args = " + json.dumps(args) + "\n" + RELOAD +
                                                            "result = kit.build(args['theme'], args['piece'], args['export_root'], args['suffix'])",
                                                            "timeout_seconds": 600})
                    data = json.loads(text(res))
                    if not data.get("ok"):
                        print(theme, piece, "FAILED", data.get("error"), (data.get("traceback") or "")[-1200:])
                        continue
                    made.append(finish_piece(theme, piece, data["result"]))
                    m = made[-1]
                    print(f"{m['name']:34s} {m['collision']:9s} boxes {m['boxes']:2d} size {m['size']}")
                res = await s.call_tool("maya_python", {"code": "args = " + json.dumps({"theme": theme}) + "\n" + RELOAD +
                                                        "result = kit.preview(args['theme'])", "timeout_seconds": 600})
                img = await s.call_tool("maya_render", {"width": 1400, "height": 500, "azimuth": 20, "elevation": 18})
                for c in img.content:
                    if getattr(c, "data", None):
                        (RENDERS / f"kit_{theme}.png").write_bytes(base64.b64decode(c.data))
    (RENDERS / "kit.json").write_text(json.dumps(made, indent=1))
    print(f"{len(made)} pieces; renders + kit.json in {RENDERS}")


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1:] or THEMES))
