"""Write the lists behind the offline test menu's spawn picker and animation browser (clientGame DevTestTools).

    python examples/make_devtest_lists.py [--client-dir D:/titan/exe/win64_rel]

devtest_templates.txt: every shared object template (object/**/shared_*.iff) in the game data and D:/exported, except
intangibles and schematics, which do not spawn as anything visible. devtest_animations.txt: every .ans file name under
appearance/animation/. Both go into the client's working directory, where the client reads them once per run (restart
it to pick up a new list). Exported files win over stock ones of the same path, as on the client's search path."""

from __future__ import annotations

import argparse
from pathlib import Path

DATA = Path("D:/titan/data/sku.0")
EXPORT = Path("D:/exported")
SKIP = ("object/intangible/", "object/draft_schematic/", "object/manufacture_schematic/", "object/mission/",
        "object/waypoint/", "object/guild/", "object/player/", "object/group/", "object/token/", "object/universe/",
        "object/path_waypoint/", "object/cell/", "object/resource_container/")


def game_roots() -> list[Path]:
    roots = [EXPORT]
    for sys in ("sys.shared", "sys.client", "sys.server"):
        roots.append(DATA / sys / "compiled" / "game")
    return [r for r in roots if r.is_dir()]


def templates() -> list[str]:
    found: set[str] = set()
    for root in game_roots():
        base = root / "object"
        if not base.is_dir():
            continue
        for f in base.rglob("shared_*.iff"):
            rel = f.relative_to(root).as_posix().lower()
            if not rel.startswith(SKIP):
                found.add(rel)
    return sorted(found)


def animations() -> list[str]:
    found: set[str] = set()
    for root in game_roots():
        base = root / "appearance" / "animation"
        if base.is_dir():
            found.update(f.name.lower() for f in base.glob("*.ans"))
    return sorted(found)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--client-dir", default="D:/titan/exe/win64_rel")
    args = ap.parse_args()
    out = Path(args.client_dir)
    t = templates()
    a = animations()
    header = "# written by SwgMayaMCP examples/make_devtest_lists.py; one entry per line\n"
    (out / "devtest_templates.txt").write_text(header + "\n".join(t) + "\n", encoding="ascii")
    (out / "devtest_animations.txt").write_text(header + "\n".join(a) + "\n", encoding="ascii")
    print(f"{len(t)} templates, {len(a)} animations -> {out}")


if __name__ == "__main__":
    main()
