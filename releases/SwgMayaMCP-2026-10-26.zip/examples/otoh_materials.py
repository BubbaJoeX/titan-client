"""Materials of the Otoh Gunga set (examples/make_otoh_gunga.py): generated textures (tileable noise and cell
patterns, pure Python) and the .sht shaders that use them, written into the export tree so exportStaticMesh /
swg_pob_exportStructure reuse them 1:1 (swgShaderPath = the absolute .sht path).

  nboo_otoh_glass_skin   outer bubble skin: clear pale amber glass, bright caustic veins  effect a_alpha_emis_full
  nboo_otoh_glow_veil    under the skins: thin amber haze, lit windows and floor bands   effect a_alpha_emis_full
  nboo_otoh_glow_shell   interior domes and tube vaults: deep amber, denser          effect a_alpha_emis_full
  nboo_otoh_wall_in      interior walls: lit amber glass panes in bronze mullions    effect a_emis_full
  nboo_otoh_floor_mosaic radial amber and bronze inlay floor, centred on the tile corner  effect a_simple
  nboo_otoh_glow_core    lantern cores and hanging pods: hot gold, opaque            effect a_emis_full
  nboo_otoh_glow_blue    the blue-lit lower spheres                                  effect a_emis_full
  nboo_otoh_rib          organic bronze ribs, lattice, stalks (lit, specular)        effect a_simple

The emissive effects draw the texture at full brightness whatever the sun does, which is what makes the
bubbles read as lit from inside (the reference shot is deep water, nearly black outside the city)."""
from __future__ import annotations

import math
import os
import random
import sys
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import iff  # noqa: E402

SIZE = 256


def _hash_grid(period, seed):
    rnd = random.Random(seed)
    return [[rnd.random() for _ in range(period)] for _ in range(period)]


def _value_noise(grid, period, u, v):
    """Tileable smooth value noise, u/v in [0, 1)."""
    x, y = u * period, v * period
    x0, y0 = int(x) % period, int(y) % period
    x1, y1 = (x0 + 1) % period, (y0 + 1) % period
    fx, fy = x - int(x), y - int(y)
    sx, sy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
    a = grid[y0][x0] + (grid[y0][x1] - grid[y0][x0]) * sx
    b = grid[y1][x0] + (grid[y1][x1] - grid[y1][x0]) * sx
    return a + (b - a) * sy


def fbm(seed, octaves=4, base=4):
    grids = [(_hash_grid(base << o, seed + o), base << o) for o in range(octaves)]

    def f(u, v):
        s, amp, tot = 0.0, 1.0, 0.0
        for g, p in grids:
            s += _value_noise(g, p, u, v) * amp
            tot += amp
            amp *= 0.5
        return s / tot
    return f


def cells(seed, count=18):
    """Tileable Worley noise: returns (F1, F2 - F1) - the second is ~0 on cell borders (veins / lattice)."""
    rnd = random.Random(seed)
    pts = [(rnd.random(), rnd.random()) for _ in range(count)]
    pts = [(x + dx, y + dy) for x, y in pts for dx in (-1, 0, 1) for dy in (-1, 0, 1)]

    def f(u, v):
        ds = sorted((u - x) ** 2 + (v - y) ** 2 for x, y in pts)[:2]
        d1, d2 = math.sqrt(ds[0]), math.sqrt(ds[1])
        return d1, d2 - d1
    return f


def _clamp(c):
    return max(0, min(255, int(round(c))))


def _image(fn, size=SIZE):
    out = bytearray(size * size * 4)
    for y in range(size):
        v = (y + 0.5) / size
        for x in range(size):
            r, g, b, a = fn((x + 0.5) / size, v)
            i = (y * size + x) * 4
            out[i:i + 4] = bytes((_clamp(r), _clamp(g), _clamp(b), _clamp(a)))
    return out


def glass_skin():
    n, c = fbm(11), cells(12, 22)
    fine = fbm(13, 3, 16)

    def px(u, v):
        t = n(u, v)
        _, edge = c(u, v)
        vein = max(0.0, 1.0 - edge / 0.035) ** 2            # bright caustic veins along cell borders
        k = 0.82 + 0.3 * t + 0.08 * fine(u, v)
        r, g, b = 255 * k, 178 * k + 60 * vein, 92 * k + 70 * vein
        return r + 30 * vein, g, b, 26 + 30 * t + 150 * vein     # mostly clear: the veil and the cores show through
    return _image(px)


def glow_veil():
    """The layer under the skins: a thin amber haze with lit windows (bright dots) and warm floor bands, so a
    bubble reads as a lit city seen through clear glass rather than as a solid lamp."""
    n, c = fbm(61), cells(62, 26)
    lights = cells(63, 70)

    def px(u, v):
        t = n(u, v)
        _, edge = c(u, v)
        d1, _ = lights(u, v)
        vein = max(0.0, 1.0 - edge / 0.025) ** 2
        dot = max(0.0, 1.0 - d1 / 0.022) ** 1.3
        band = max(math.exp(-((v - 0.25) / 0.035) ** 2), math.exp(-((v - 0.62) / 0.03) ** 2))   # lit floor levels
        k = 0.85 + 0.3 * t
        r = 255 * k
        g = 138 * k + 50 * vein + 110 * dot + 55 * band
        b = 38 * k + 20 * vein + 110 * dot + 20 * band
        # dense enough to glow from afar (the skin over it is clear); dots and bands read as lit floors inside
        return r, g, b, 135 + 50 * t + 50 * vein + 120 * dot + 60 * band
    return _image(px)


def wall_in():
    """Interior walls (3 m tiles): lit amber glass panes between bronze mullions and a transom, faint veins."""
    n, c = fbm(71), cells(72, 16)
    spots = cells(73, 30)

    def px(u, v):
        t = n(u, v)
        _, edge = c(u, v)
        d1, _ = spots(u, v)
        mull = max(math.exp(-(min(u, 1 - u) / 0.025) ** 2), math.exp(-(abs(u - 0.5) / 0.012) ** 2),
                   math.exp(-(abs(v - 0.32) / 0.015) ** 2))
        vein = max(0.0, 1.0 - edge / 0.02) ** 2
        dot = max(0.0, 1.0 - d1 / 0.02) ** 1.5
        glow = 0.55 + 0.25 * t + 0.25 * (1.0 - v)                    # brighter low down, like light pooling
        r = (230 * glow + 25 * vein + 20 * dot) * (1 - mull) + 88 * mull
        g = (120 * glow + 60 * vein + 110 * dot) * (1 - mull) + 58 * mull
        b = (40 * glow + 25 * vein + 90 * dot) * (1 - mull) + 30 * mull
        return r, g, b, 255
    return _image(px)


MOSAIC = 512


def floor_mosaic():
    """Radial inlay floor: concentric bronze and amber rings with 16 spokes and a petal ring, centred on the tile
    CORNER (u, v = 0) so planar floor UVs (x / tile, z / tile) put a full rosette round the room centre."""
    n = fbm(81, 4, 8)
    grit = fbm(82, 3, 64)

    def px(u, v):
        du, dv = (u + 0.5) % 1.0 - 0.5, (v + 0.5) % 1.0 - 0.5         # offset from the nearest tile corner
        r = math.hypot(du, dv) * 2.0                                  # 0 centre .. 1 tile edge midpoint
        a = math.atan2(dv, du)
        t, g = n(u, v), grit(u, v)
        base = (58 + 26 * t + 14 * g, 44 + 18 * t + 10 * g, 30 + 12 * t + 6 * g)   # dark warm stone
        ring = max(math.exp(-((r - rr) / w) ** 2) for rr, w in ((0.12, 0.03), (0.34, 0.024), (0.38, 0.01),
                                                                 (0.62, 0.028), (0.88, 0.034)))
        spoke = math.exp(-((math.sin(8 * a) * r) / 0.035) ** 2) if 0.12 < r < 0.62 else 0.0
        petal = 0.0
        if 0.36 < r < 0.62:
            pr = (r - 0.36) / 0.26
            petal = max(0.0, 1.0 - abs(math.sin(8 * a + math.pi / 2)) / (0.55 * math.sin(math.pi * pr) + 1e-3))
        centre = max(0.0, 1.0 - r / 0.1)
        amber = min(1.0, 0.85 * petal + centre)
        bronze = min(1.0, ring + 0.8 * spoke)
        col = [base[i] * (1 - bronze) * (1 - amber) for i in range(3)]
        col = [col[0] + 225 * bronze + 255 * amber, col[1] + 150 * bronze + 170 * amber, col[2] + 60 * bronze + 70 * amber]
        return col[0], col[1], col[2], 90 + 120 * bronze          # alpha = specular mask (the inlay shines)
    return _image(px, MOSAIC)


def glow_shell():
    n, c = fbm(21), cells(22, 30)
    spots = cells(23, 40)

    def px(u, v):
        t = n(u, v)
        _, edge = c(u, v)
        d1, _ = spots(u, v)
        vein = max(0.0, 1.0 - edge / 0.03) ** 2
        dot = max(0.0, 1.0 - d1 / 0.028) ** 1.5              # little lights seen through the far wall
        k = 0.7 + 0.4 * t
        r = 238 * k + 17 * dot
        g = 122 * k + 55 * vein + 120 * dot
        b = 34 * k + 22 * vein + 110 * dot
        return r, g, b, 120 + 60 * t + 70 * vein + 60 * dot
    return _image(px)


def glow_core():
    n = fbm(31, 4, 8)

    def px(u, v):
        t = n(u, v)
        k = 0.82 + 0.3 * t
        return 255 * k, 205 * k, 120 * k, 255
    return _image(px)


def glow_blue():
    n, c = fbm(41), cells(42, 26)
    spots = cells(43, 24)

    def px(u, v):
        t = n(u, v)
        _, edge = c(u, v)
        d1, _ = spots(u, v)
        line = max(0.0, 1.0 - edge / 0.02)                    # dark panel seams
        band = math.exp(-((v - 0.5) / 0.08) ** 2)             # a lit band round the equator (v = 0.5)
        dot = max(0.0, 1.0 - d1 / 0.03) ** 1.5
        k = (0.55 + 0.45 * t) * (1 - 0.6 * line)
        r = 18 * k + 40 * band + 200 * dot
        g = 60 * k + 120 * band + 170 * dot
        b = 150 * k + 105 * band + 60 * dot
        return r, g, b, 255
    return _image(px)


def rib():
    n = fbm(51, 5, 4)
    grain = fbm(52, 3, 32)

    def px(u, v):
        t = n(u, v)
        groove = 0.5 + 0.5 * math.sin(u * 2 * math.pi * 6 + 3.0 * grain(u * 0.25, v))   # lengthwise grooves
        k = 0.62 + 0.38 * t + 0.18 * groove
        return 112 * k, 78 * k, 44 * k, 200 * groove       # alpha = specular mask
    return _image(px)


TEXTURES = {"nboo_otoh_glass_skin": glass_skin, "nboo_otoh_glow_veil": glow_veil, "nboo_otoh_glow_shell": glow_shell,
            "nboo_otoh_glow_core": glow_core, "nboo_otoh_glow_blue": glow_blue, "nboo_otoh_rib": rib,
            "nboo_otoh_wall_in": wall_in, "nboo_otoh_floor_mosaic": floor_mosaic}
SHADERS = {   # name -> (effect, texture, extras)
    "nboo_otoh_glass_skin": ("effect/a_alpha_emis_full.eft", "nboo_otoh_glass_skin", {"alpha_ref": 1}),
    "nboo_otoh_glow_veil": ("effect/a_alpha_emis_full.eft", "nboo_otoh_glow_veil", {"alpha_ref": 1}),
    "nboo_otoh_glow_shell": ("effect/a_alpha_emis_full.eft", "nboo_otoh_glow_shell", {"alpha_ref": 1}),
    "nboo_otoh_glow_core": ("effect/a_emis_full.eft", "nboo_otoh_glow_core", {}),
    "nboo_otoh_glow_blue": ("effect/a_emis_full.eft", "nboo_otoh_glow_blue", {}),
    "nboo_otoh_rib": ("effect/a_simple.eft", "nboo_otoh_rib", {"specular": (0.55, 0.45, 0.3), "power": 14.0}),
    "nboo_otoh_wall_in": ("effect/a_emis_full.eft", "nboo_otoh_wall_in", {}),
    "nboo_otoh_floor_mosaic": ("effect/a_simple.eft", "nboo_otoh_floor_mosaic", {"specular": (0.5, 0.4, 0.25), "power": 18.0}),
}


def write_all(export_root, preview_png=None):
    root = Path(export_root)
    made = {}
    images = []
    for name, fn in TEXTURES.items():
        px = fn()
        size = int(round((len(px) // 4) ** 0.5))
        iff.write_dds_rgba(root / f"texture/{name}.dds", size, size, px)
        images.append(px if size == SIZE else _downsample(px, size, SIZE))
    for name, (effect, tex, extra) in SHADERS.items():
        iff.write_shader(root / f"shader/{name}.sht", effect, f"texture/{tex}.dds", **extra)
        made[name] = str((root / f"shader/{name}.sht")).replace("\\", "/")
    if preview_png:
        _preview(images, preview_png)
    return made


def _downsample(px, size, to):
    step = size // to
    out = bytearray(to * to * 4)
    for y in range(to):
        for x in range(to):
            i, j = ((y * step) * size + x * step) * 4, (y * to + x) * 4
            out[j:j + 4] = px[i:i + 4]
    return out


def _preview(images, path):
    """Contact sheet: colour row over alpha row (no PIL in the venv: a minimal PNG)."""
    import struct
    import zlib
    w, h = SIZE * len(images), SIZE * 2
    rows = []
    for y in range(h):
        row = bytearray(b"\0")
        for px in images:
            for x in range(SIZE):
                i = ((y % SIZE) * SIZE + x) * 4
                row += bytes(px[i:i + 3]) if y < SIZE else bytes((px[i + 3],) * 3)
        rows.append(bytes(row))

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + \
        chunk(b"IDAT", zlib.compress(b"".join(rows), 6)) + chunk(b"IEND", b"")
    Path(path).write_bytes(png)


if __name__ == "__main__":
    print(write_all(sys.argv[1] if len(sys.argv) > 1 else os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"),
                    sys.argv[2] if len(sys.argv) > 2 else None))
