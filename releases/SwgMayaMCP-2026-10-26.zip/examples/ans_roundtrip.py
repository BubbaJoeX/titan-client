"""ANS round trip in headless Maya: import a stock skeleton + animation, sample every joint, export the .ans
(SwgAns), re-import it onto a fresh skeleton, sample again and report the largest differences.

Run: python examples/ans_roundtrip.py [skeleton.skt] [animation.ans] [out.ans]
(paths under TITAN_DATA_ROOT; out defaults to <export root>/appearance/animation/roundtrip_<name>.ans)"""
import asyncio
import json
import os
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

SKT = sys.argv[1] if len(sys.argv) > 1 else "appearance/skeleton/all_b.skt"
ANS = sys.argv[2] if len(sys.argv) > 2 else "appearance/animation/all_b_emt_wave1.ans"
OUT = sys.argv[3] if len(sys.argv) > 3 else os.path.join(
    os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"), "appearance/animation",
    "roundtrip_" + os.path.basename(ANS)).replace("\\", "/")

CODE = r'''
import maya.cmds as cmds, maya.mel as mel, math, os
data = os.environ.get('TITAN_DATA_ROOT', 'D:/titan/data/sku.0/sys.client/compiled/game').replace(chr(92), '/')

def scene_with(anim_path):
    cmds.file(new=True, force=True)
    mel.eval('importSkeleton -i "%s"' % (data + '/' + args['skt']))
    mel.eval('importAnimation -i "%s"' % anim_path)

def sample():
    joints = sorted(cmds.ls(type='joint'))
    t0, t1 = cmds.playbackOptions(q=True, min=True), cmds.playbackOptions(q=True, max=True)
    frames = [float(f) for f in range(int(round(t0)), int(round(t1)) + 1)]   # whole frames: what the file stores
    out = {}
    for f in frames:
        cmds.currentTime(f)
        for j in joints:
            short = j.split('|')[-1].split(':')[-1]
            m = cmds.xform(j, q=True, matrix=True, worldSpace=False)
            out.setdefault(short, []).append(m)
    return {'range': [t0, t1], 'frames': frames, 'joints': out}

scene_with(data + '/' + args['ans'])
a = sample()
roots = cmds.ls(assemblies=True)
cmds.select(cmds.ls(type='joint'), r=True)
os.makedirs(os.path.dirname(args['out']), exist_ok=True)
cmds.file(args['out'], force=True, exportSelected=True, type='SwgAns')
scene_with(args['out'])
b = sample()

worst_r, worst_t, missing = [], [], []
for j, ma in a['joints'].items():
    mb = b['joints'].get(j)
    if not mb:
        missing.append(j); continue
    for fi, (x, y) in enumerate(zip(ma, mb)):
        rot = max(abs(x[i] - y[i]) for i in (0,1,2,4,5,6,8,9,10))
        tr = max(abs(x[i] - y[i]) for i in (12,13,14))
        worst_r.append((rot, j, a['frames'][fi])); worst_t.append((tr, j, a['frames'][fi]))
worst_r.sort(reverse=True); worst_t.sort(reverse=True)
result = {'range_in': a['range'], 'range_out': b['range'], 'joints': len(a['joints']), 'missing': missing[:10],
          'worst_rotation': worst_r[:6], 'worst_translation': worst_t[:6],
          'out_bytes': os.path.getsize(args['out'])}
'''


async def main():
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {})
            args = json.dumps({"skt": SKT, "ans": ANS, "out": OUT})
            res = await s.call_tool("maya_python", {"code": "args = " + args + "\n" + CODE})
            print("\n".join(getattr(c, "text", "") for c in res.content))


asyncio.run(main())
