"""Build + export an example building through the MCP server (headless unless SWG_MAYA_MCP_MODE says otherwise).

    .venv\\Scripts\\python.exe examples\\build_example.py examples\\titan_outpost.json [export_root]

Writes <export_root>/appearance/<name>.pob (+ cell .apt/.msh, .flr floors, shaders), saves the Maya scene to
<export_root>/maya/<name>.ma and a plan view next to the .pob.
"""

import asyncio
import json
import os
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

HERE = Path(__file__).resolve().parent.parent


def payload(result):
    if result.is_error:
        raise SystemExit("tool error: " + " ".join(getattr(c, "text", "") for c in result.content))
    sc = result.structured_content
    if sc is not None:
        return sc.get("result", sc) if isinstance(sc, dict) and set(sc) == {"result"} else sc
    return json.loads(result.content[0].text)


async def main(spec_path: str, export_root: str) -> int:
    spec = json.loads(Path(spec_path).read_text(encoding="utf-8"))
    params = StdioServerParameters(command=sys.executable, args=[str(HERE / "run_server.py")],
                                   env={**os.environ, "SWG_MAYA_MCP_MODE": os.environ.get("SWG_MAYA_MCP_MODE", "auto")})
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as s:
            await s.initialize()
            built = payload(await s.call_tool("pob_build", {"spec": spec}))
            print(f"built {built['root']}: {built['cells']} cells, {len(built['portals'])} portals")
            for p in built["portals"]:
                print(f"  p{p['index']} {p['between'][0]}<->{p['between'][1]} at {p['center']} rotY={p['rotate_y']}")
            out = payload(await s.call_tool("pob_export_structure", {"root": built["root"], "export_root": export_root}))
            scene = str(Path(export_root) / "maya" / f"{spec['name']}.ma").replace("\\", "/")
            Path(scene).parent.mkdir(parents=True, exist_ok=True)
            payload(await s.call_tool("maya_scene", {"action": "save_as", "path": scene}))
            plan = payload(await s.call_tool("pob_floorplan", {"path": out["pob"], "data_root": export_root}))
            summary = out["pob_summary"]
            print("pob:", out["pob"])
            print("scene:", scene)
            print("plan:", plan["svg"])
            for c in summary["cells"]:
                print(f"  r{c['index']} {c['name']:9s} seeWorld={c['can_see_world']!s:5s} lights={c['light_count']} "
                      f"floor={'yes' if c['floor'] else 'no '} portals={[(p['portal_index'], int(p['clockwise']), p['target_cell']) for p in c['portals']]}")
            for cell, chk in out["floor_checks"].items():
                print(f"  {cell} floor: {chk['tris']} tris, parts={chk['parts']}, portal edges={chk['portal_edges_by_portal']}, "
                      f"problems={chk['problems'] or 'none'}")
            ok = not summary["issues"] and not summary.get("missing_files") and all(
                not f["problems"] and not f["downward_tris"] for f in out["floor_checks"].values())
            for c in summary["cells"][1:]:
                tagged = out["floor_checks"].get(f"r{c['index']}", {}).get("portal_edges_by_portal", {})
                missing = [p["portal_index"] for p in c["portals"]
                           if p.get("passable", True) and str(p["portal_index"]) not in tagged]   # windows aren't walked
                if missing:
                    print(f"  r{c['index']}: no floor edge for portal(s) {missing}")
                    ok = False
            # connectivity: one floor part per level (stages/ramps must join their level's floor)
            for r in built["rooms"]:
                parts = out["floor_checks"].get(r["cell"], {}).get("parts")
                if parts != r["expected_floor_parts"]:
                    print(f"  {r['cell']} {r['name']}: floor has {parts} part(s), expected {r['expected_floor_parts']}")
                    ok = False
                mc = out.get("mesh_checks", {}).get(r["cell"], {})
                print(f"  {r['cell']} {r['name']}: {mc.get('shader_slots')} shader slot(s), hardpoints {mc.get('hardpoints')}")
                if sorted(mc.get("hardpoints", [])) != sorted(r["hardpoints"]):
                    print(f"    expected hardpoints {r['hardpoints']}")
                    ok = False
                if mc.get("shader_slots", 0) < 2:
                    print("    expected wall + floor shader slots")
                    ok = False
            if out.get("texture_errors"):
                print("texture errors:")
                for line in out["texture_errors"]:
                    print("  " + line)
                ok = False
            print("issues:", summary["issues"] or "none", "| missing files:", summary.get("missing_files") or "none")
            print("RESULT:", "PASS" if ok else "FAIL")
            return 0 if ok else 1


if __name__ == "__main__":
    spec_file = sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).with_name("titan_outpost.json"))
    root = sys.argv[2] if len(sys.argv) > 2 else os.environ.get("TITAN_EXPORT_ROOT", "D:/exported")
    sys.exit(asyncio.run(main(spec_file, root)))
