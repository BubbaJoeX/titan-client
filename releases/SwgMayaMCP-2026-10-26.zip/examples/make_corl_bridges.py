"""Export the Corellia bridge junctions (maya/swg_mcp/corl_bridge.py) and make them spawnable next to the stock
bridges: appearance + walk floor, a .lod with composite box collision (pylons, parapets, lamp posts) and radar
footprint, a client data file for the lit variant's lamps, and object/static/structure/corellia/
shared_corl_imprv_bridge_<piece>_<style>.iff derived from the stock shared_corl_imprv_bridge_sm_s01 template.

Run: python examples/make_corl_bridges.py   (close any other headless Maya first; it starts its own)
Spawn: /scene objectCreate object/static/structure/corellia/shared_corl_imprv_bridge_4way_s01.iff <x> <z> <heading>
       then stock bridges with their ends on the junction's edges (bridge_sm: centre 3.75 + 8.12 m out)."""
import asyncio
import json
import os
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from swg_maya_mcp import iff  # noqa: E402

EXPORT = Path(os.environ.get("TITAN_EXPORT_ROOT", "D:/exported"))
CLIENT = Path(os.environ.get("TITAN_DATA_ROOT", "D:/titan/data/sku.0/sys.client/compiled/game"))
BASE_TEMPLATE = CLIENT / "object/static/structure/corellia/shared_corl_imprv_bridge_sm_s01.iff"
PIECES = ["4way", "3way", "corner", "4way_lit"]
STYLES = ["s01", "s02"]
LAMP = {"type": 1, "rgb": (0.16, 0.22, 0.3), "range": 10.0, "constant": 0.1,
        "appearance": "appearance/pt_light_streetlamp_blue.prt", "flags": 1}     # time-of-day aware, like streetlamps

RUN = ("import sys, importlib\np = 'D:/titan/support/MCP/SwgMayaMCP/maya'\nif p not in sys.path: sys.path.insert(0, p)\n"
       "import swg_mcp.pob_builder as pb, swg_mcp.kit as kit, swg_mcp.corl_bridge as cb\n"
       "for m in (pb, kit, cb): importlib.reload(m)\n")


def finish(out):
    """Host side after a junction export: lod (collision, floor, radar, hardpoints), cdf (lamps), template."""
    b = out["bounds"]
    lod = iff.write_static_lod(EXPORT, out["apt"], out["boxes"], True, out["footprint"], floor=out["floor"],
                               bounds=[b[:3], b[3:]])
    params = {"appearanceFilename": out["apt"]}
    if out["hardpoints"]:
        rel = f"clientdata/client_shared_{out['name']}.cdf"
        iff.write_client_data(EXPORT / rel, hardpoint_lights=[dict(LAMP, hardpoint=h) for h in out["hardpoints"]])
        params["clientDataFile"] = rel
    tpl = EXPORT / f"object/static/structure/corellia/shared_{out['name']}.iff"
    iff.derive_template(BASE_TEMPLATE, tpl, params)
    rep = iff.floor_report(iff.read_flr(EXPORT / out["floor"]))
    return {"name": out["name"], "template": str(tpl.relative_to(EXPORT)).replace("\\", "/"), "collision": lod["collision"],
            "boxes": lod["boxes"], "floor": {k: rep.get(k) for k in ("crossable_edges", "uncrossable_edges", "wallbase_edges")},
            "hardpoints": out["hardpoints"]}


async def main():
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(os.path.dirname(__file__), "..", "run_server.py")],
                              env=dict(os.environ))
    made = []
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            await s.call_tool("swg_setup", {"export_root": str(EXPORT)})
            for style in STYLES:
                for piece in PIECES:
                    args = {"piece": piece, "style": style, "root": str(EXPORT).replace("\\", "/")}
                    res = await s.call_tool("maya_python", {"code": "args = " + json.dumps(args) + "\n" + RUN +
                                                            "result = cb.build(args['piece'], args['style'], args['root'])",
                                                            "timeout_seconds": 600})
                    data = json.loads("\n".join(getattr(c, "text", "") for c in res.content))
                    if not data.get("ok"):
                        print(style, piece, "FAILED", data.get("error"))
                        continue
                    made.append(finish(data["result"]))
                    print(json.dumps(made[-1]))
    print(f"{len(made)} junctions")


if __name__ == "__main__":
    asyncio.run(main())
